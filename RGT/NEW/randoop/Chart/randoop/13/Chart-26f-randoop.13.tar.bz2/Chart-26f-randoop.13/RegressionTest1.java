import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        java.awt.Font font1 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer2.setDrawOutlines(true);
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer2.setBasePaint((java.awt.Paint) color5, false);
        org.jfree.chart.text.TextMeasurer textMeasurer9 = null;
        org.jfree.chart.text.TextBlock textBlock10 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color5, (float) (byte) -1, textMeasurer9);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor14 = null;
        java.awt.Shape shape18 = textBlock10.calculateBounds(graphics2D11, (float) 1, 100.0f, textBlockAnchor14, (float) 3, (float) (short) -1, (double) 0);
        java.awt.Font font21 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.text.TextBlock textBlock23 = org.jfree.chart.text.TextUtilities.createTextBlock("{0}", font21, (java.awt.Paint) color22);
        java.awt.Paint paint24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        textBlock10.addLine("{0}", font21, paint24);
        org.jfree.chart.text.TextLine textLine26 = new org.jfree.chart.text.TextLine();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions28 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((double) (byte) 100);
        boolean boolean29 = textLine26.equals((java.lang.Object) (byte) 100);
        textBlock10.addLine(textLine26);
        java.awt.Graphics2D graphics2D31 = null;
        org.jfree.chart.block.BlockBorder blockBorder38 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor39 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        boolean boolean40 = blockBorder38.equals((java.lang.Object) itemLabelAnchor39);
        org.jfree.chart.text.TextAnchor textAnchor41 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor42 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.jfree.chart.axis.AxisLocation axisLocation43 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        boolean boolean44 = textAnchor42.equals((java.lang.Object) axisLocation43);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition46 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor39, textAnchor41, textAnchor42, (double) 2);
        textLine26.draw(graphics2D31, (float) 8, (float) (-2208927600000L), textAnchor42, (float) (byte) 1, (float) '4', (double) 0);
        org.jfree.data.Range range51 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double52 = range51.getUpperBound();
        boolean boolean53 = textLine26.equals((java.lang.Object) double52);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(textBlock10);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(textBlock23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(categoryLabelPositions28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(textAnchor41);
        org.junit.Assert.assertNotNull(textAnchor42);
        org.junit.Assert.assertNotNull(axisLocation43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(range51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 1.0d + "'", double52 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDepthFactor((double) (byte) 1);
        piePlot3D1.setDepthFactor(0.0d);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer6 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer6.setDrawOutlines(true);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer6.setBasePaint((java.awt.Paint) color9, false);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer15 = null;
        org.jfree.chart.plot.PolarPlot polarPlot16 = new org.jfree.chart.plot.PolarPlot(xYDataset13, valueAxis14, polarItemRenderer15);
        java.lang.Object obj17 = null;
        boolean boolean18 = polarPlot16.equals(obj17);
        int int19 = polarPlot16.getSeriesCount();
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        polarPlot16.setAngleLabelPaint((java.awt.Paint) color20);
        statisticalLineAndShapeRenderer6.setSeriesFillPaint(2, (java.awt.Paint) color20);
        float[] floatArray27 = new float[] { (short) 10, 0, 100, '#' };
        float[] floatArray28 = color20.getColorComponents(floatArray27);
        piePlot3D1.setShadowPaint((java.awt.Paint) color20);
        piePlot3D1.setLabelLinkMargin((double) 10L);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertNotNull(floatArray28);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset2, valueAxis3, polarItemRenderer4);
        defaultCategoryDataset0.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot5);
        int int7 = defaultCategoryDataset0.getColumnCount();
        org.jfree.data.general.PieDataset pieDataset9 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, (java.lang.Comparable) 0.35d);
        double double10 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset9);
        org.jfree.chart.plot.RingPlot ringPlot11 = new org.jfree.chart.plot.RingPlot(pieDataset9);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long13 = segmentedTimeline12.getStartTime();
        int int14 = segmentedTimeline12.getSegmentsIncluded();
        long long17 = segmentedTimeline12.getExceptionSegmentCount(0L, (-1L));
        long long18 = segmentedTimeline12.getSegmentsGroupSize();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(4, 0);
        java.util.Date date22 = month21.getEnd();
        long long23 = segmentedTimeline12.getTime(date22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date22);
        org.jfree.data.general.PieDataset pieDataset27 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset9, (java.lang.Comparable) year24, (double) 1L, (-16744320));
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(pieDataset9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(segmentedTimeline12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-2208927600000L) + "'", long13 == (-2208927600000L));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 28 + "'", int14 == 28);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 86400000L + "'", long18 == 86400000L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-62125372800001L) + "'", long23 == (-62125372800001L));
        org.junit.Assert.assertNotNull(pieDataset27);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("");
        taskSeries1.fireSeriesChanged();
        org.jfree.data.gantt.Task task4 = taskSeries1.get("{0}");
        org.jfree.data.gantt.Task task6 = taskSeries1.get("({0}, {1}) = {3} - {4}");
        taskSeries1.removeAll();
        taskSeries1.setKey((java.lang.Comparable) 0.5d);
        org.junit.Assert.assertNull(task4);
        org.junit.Assert.assertNull(task6);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean1 = statisticalLineAndShapeRenderer0.getDrawOutlines();
        statisticalLineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(false);
        java.awt.Stroke stroke5 = statisticalLineAndShapeRenderer0.lookupSeriesStroke(28);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = statisticalLineAndShapeRenderer0.getBaseNegativeItemLabelPosition();
        java.awt.Paint paint7 = statisticalLineAndShapeRenderer0.getBaseOutlinePaint();
        java.awt.Font font10 = null;
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.jfree.chart.text.TextMeasurer textMeasurer13 = null;
        org.jfree.chart.text.TextBlock textBlock14 = org.jfree.chart.text.TextUtilities.createTextBlock("", font10, (java.awt.Paint) color11, (float) ' ', textMeasurer13);
        statisticalLineAndShapeRenderer0.setSeriesFillPaint((int) (byte) 100, (java.awt.Paint) color11, false);
        org.jfree.data.general.PieDataset pieDataset17 = null;
        org.jfree.chart.plot.RingPlot ringPlot18 = new org.jfree.chart.plot.RingPlot(pieDataset17);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        org.jfree.data.gantt.Task task21 = new org.jfree.data.gantt.Task("", (org.jfree.data.time.TimePeriod) year20);
        java.awt.Font font23 = null;
        java.awt.Color color24 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.jfree.chart.text.TextMeasurer textMeasurer26 = null;
        org.jfree.chart.text.TextBlock textBlock27 = org.jfree.chart.text.TextUtilities.createTextBlock("", font23, (java.awt.Paint) color24, (float) ' ', textMeasurer26);
        org.jfree.data.general.PieDataset pieDataset28 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D29 = new org.jfree.chart.plot.PiePlot3D(pieDataset28);
        piePlot3D29.setDepthFactor((double) (byte) 1);
        piePlot3D29.setDepthFactor(0.0d);
        java.awt.Stroke stroke34 = piePlot3D29.getLabelLinkStroke();
        boolean boolean35 = textBlock27.equals((java.lang.Object) stroke34);
        int int36 = year20.compareTo((java.lang.Object) stroke34);
        ringPlot18.setLabelOutlineStroke(stroke34);
        statisticalLineAndShapeRenderer0.setBaseOutlineStroke(stroke34);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(textBlock14);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(textBlock27);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("");
        taskSeries1.fireSeriesChanged();
        org.jfree.data.gantt.Task task4 = taskSeries1.get("{0}");
        org.jfree.data.gantt.Task task6 = taskSeries1.get("({0}, {1}) = {3} - {4}");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        taskSeries1.removeChangeListener(seriesChangeListener7);
        int int9 = taskSeries1.getItemCount();
        org.junit.Assert.assertNull(task4);
        org.junit.Assert.assertNull(task6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        double double0 = org.jfree.chart.renderer.category.LevelRenderer.DEFAULT_ITEM_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D2 = new org.jfree.chart.plot.PiePlot3D(pieDataset1);
        piePlot3D2.setDepthFactor((double) (byte) 1);
        java.awt.Color color5 = java.awt.Color.GRAY;
        piePlot3D2.setLabelLinkPaint((java.awt.Paint) color5);
        boolean boolean7 = strokeList0.equals((java.lang.Object) color5);
        java.awt.Stroke stroke9 = strokeList0.getStroke((int) '#');
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(stroke9);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer1 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean2 = statisticalLineAndShapeRenderer1.getDrawOutlines();
        statisticalLineAndShapeRenderer1.setAutoPopulateSeriesFillPaint(false);
        java.awt.Stroke stroke6 = statisticalLineAndShapeRenderer1.lookupSeriesStroke(28);
        lineAndShapeRenderer0.setBaseStroke(stroke6);
        lineAndShapeRenderer0.setBaseItemLabelsVisible(true, true);
        lineAndShapeRenderer0.setSeriesCreateEntities((int) (short) 100, (java.lang.Boolean) true);
        lineAndShapeRenderer0.setBaseSeriesVisible(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE8;
        java.lang.String str1 = itemLabelAnchor0.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ItemLabelAnchor.OUTSIDE8" + "'", str1.equals("ItemLabelAnchor.OUTSIDE8"));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        boolean boolean1 = textTitle0.getExpandToFitSpace();
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        textTitle0.setVerticalAlignment(verticalAlignment2);
        double double4 = textTitle0.getContentXOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        textTitle0.setPadding(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font4 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer5 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer5.setDrawOutlines(true);
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer5.setBasePaint((java.awt.Paint) color8, false);
        org.jfree.chart.text.TextMeasurer textMeasurer12 = null;
        org.jfree.chart.text.TextBlock textBlock13 = org.jfree.chart.text.TextUtilities.createTextBlock("", font4, (java.awt.Paint) color8, (float) (byte) -1, textMeasurer12);
        numberAxis2.setTickMarkPaint((java.awt.Paint) color8);
        boolean boolean15 = numberAxis2.isInverted();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer16 = null;
        org.jfree.chart.plot.PolarPlot polarPlot17 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, polarItemRenderer16);
        numberAxis2.zoomRange((double) (-1.0f), (double) (short) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = numberAxis2.getLabelInsets();
        double double22 = rectangleInsets21.getBottom();
        double double24 = rectangleInsets21.calculateTopInset((double) 'a');
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(textBlock13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 3.0d + "'", double22 == 3.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 3.0d + "'", double24 == 3.0d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        levelRenderer0.setSeriesCreateEntities(0, (java.lang.Boolean) true, true);
        levelRenderer0.setItemMargin(0.05d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(4, 0);
        java.util.Date date3 = month2.getEnd();
        int int4 = month2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month2.next();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor5 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        boolean boolean6 = blockBorder4.equals((java.lang.Object) itemLabelAnchor5);
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.jfree.chart.axis.AxisLocation axisLocation9 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        boolean boolean10 = textAnchor8.equals((java.lang.Object) axisLocation9);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor5, textAnchor7, textAnchor8, (double) 2);
        double double13 = itemLabelPosition12.getAngle();
        org.junit.Assert.assertNotNull(itemLabelAnchor5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.0d + "'", double13 == 2.0d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        java.awt.Font font1 = null;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis4, polarItemRenderer5);
        float float7 = polarPlot6.getBackgroundAlpha();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer8 = polarPlot6.getRenderer();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font1, (org.jfree.chart.plot.Plot) polarPlot6, false);
        jFreeChart10.setTitle("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]");
        java.awt.Image image13 = null;
        jFreeChart10.setBackgroundImage(image13);
        org.jfree.chart.title.TextTitle textTitle15 = null;
        jFreeChart10.setTitle(textTitle15);
        try {
            org.jfree.chart.plot.CategoryPlot categoryPlot17 = jFreeChart10.getCategoryPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PolarPlot cannot be cast to org.jfree.chart.plot.CategoryPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertNull(polarItemRenderer8);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        java.awt.Color color0 = java.awt.Color.CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis2.setInverted(true);
        boolean boolean5 = numberAxis2.isAxisLineVisible();
        boolean boolean6 = numberAxis2.getAutoRangeStickyZero();
        java.awt.Stroke stroke7 = numberAxis2.getAxisLineStroke();
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis2);
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot0.getRangeAxisLocation(0);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor11 = org.jfree.chart.axis.CategoryAnchor.END;
        categoryPlot0.setDomainGridlinePosition(categoryAnchor11);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(categoryAnchor11);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDepthFactor((double) (byte) 1);
        piePlot3D1.setDepthFactor(0.0d);
        java.awt.Stroke stroke6 = piePlot3D1.getLabelLinkStroke();
        double double7 = piePlot3D1.getShadowXOffset();
        java.lang.String str8 = piePlot3D1.getNoDataMessage();
        java.awt.Paint paint9 = piePlot3D1.getBaseSectionOutlinePaint();
        java.awt.Paint paint11 = piePlot3D1.getSectionOutlinePaint((java.lang.Comparable) 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font15 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer16 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer16.setDrawOutlines(true);
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer16.setBasePaint((java.awt.Paint) color19, false);
        org.jfree.chart.text.TextMeasurer textMeasurer23 = null;
        org.jfree.chart.text.TextBlock textBlock24 = org.jfree.chart.text.TextUtilities.createTextBlock("", font15, (java.awt.Paint) color19, (float) (byte) -1, textMeasurer23);
        numberAxis13.setTickMarkPaint((java.awt.Paint) color19);
        piePlot3D1.setLabelShadowPaint((java.awt.Paint) color19);
        org.jfree.chart.block.BlockContainer blockContainer27 = new org.jfree.chart.block.BlockContainer();
        blockContainer27.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer33 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder38 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer33.setFrame((org.jfree.chart.block.BlockFrame) blockBorder38);
        blockContainer27.add((org.jfree.chart.block.Block) blockContainer33);
        java.awt.Graphics2D graphics2D41 = null;
        org.jfree.chart.util.Size2D size2D42 = blockContainer33.arrange(graphics2D41);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor45 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D46 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D42, (double) '#', (double) 1.0f, rectangleAnchor45);
        boolean boolean47 = piePlot3D1.equals((java.lang.Object) rectangle2D46);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer48 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer48.setSeriesLinesVisible((int) (short) 10, true);
        java.awt.Stroke stroke53 = statisticalLineAndShapeRenderer48.lookupSeriesOutlineStroke((int) '#');
        piePlot3D1.setLabelOutlineStroke(stroke53);
        org.jfree.chart.axis.NumberAxis numberAxis56 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font58 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer59 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer59.setDrawOutlines(true);
        java.awt.Color color62 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer59.setBasePaint((java.awt.Paint) color62, false);
        org.jfree.chart.text.TextMeasurer textMeasurer66 = null;
        org.jfree.chart.text.TextBlock textBlock67 = org.jfree.chart.text.TextUtilities.createTextBlock("", font58, (java.awt.Paint) color62, (float) (byte) -1, textMeasurer66);
        numberAxis56.setTickMarkPaint((java.awt.Paint) color62);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit70 = new org.jfree.chart.axis.NumberTickUnit(0.0d);
        numberAxis56.setTickUnit(numberTickUnit70);
        int int73 = numberTickUnit70.compareTo((java.lang.Object) 10.0f);
        java.awt.Stroke stroke74 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        piePlot3D1.setSectionOutlineStroke((java.lang.Comparable) 10.0f, stroke74);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(textBlock24);
        org.junit.Assert.assertNotNull(size2D42);
        org.junit.Assert.assertNotNull(rectangleAnchor45);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertNotNull(textBlock67);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + (-1) + "'", int73 == (-1));
        org.junit.Assert.assertNotNull(stroke74);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        ringPlot1.setSeparatorsVisible(false);
        float float4 = ringPlot1.getForegroundAlpha();
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(1.0d, (double) (short) -1);
        boolean boolean3 = stackedBarRenderer3D2.isDrawBarOutline();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer4 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        stackedBarRenderer3D2.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer4);
        java.awt.Paint paint6 = stackedBarRenderer3D2.getWallPaint();
        stackedBarRenderer3D2.setBase((double) (-16744320));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((-1), 2, 28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Red");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis2.setInverted(true);
        boolean boolean5 = numberAxis2.isAxisLineVisible();
        boolean boolean6 = numberAxis2.getAutoRangeStickyZero();
        java.awt.Stroke stroke7 = numberAxis2.getAxisLineStroke();
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis2);
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot0.setRangeCrosshairStroke(stroke9);
        categoryPlot0.setDomainGridlinesVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot0.getRangeAxis(0);
        valueAxis14.setLabelToolTip("UnitType.ABSOLUTE");
        valueAxis14.setTickMarkOutsideLength((float) 0);
        double double19 = valueAxis14.getUpperMargin();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(valueAxis14);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.05d + "'", double19 == 0.05d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis2.setInverted(true);
        boolean boolean5 = numberAxis2.isAxisLineVisible();
        boolean boolean6 = numberAxis2.getAutoRangeStickyZero();
        java.awt.Stroke stroke7 = numberAxis2.getAxisLineStroke();
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis2);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.axis.AxisLocation axisLocation11 = categoryPlot0.getDomainAxisLocation((int) (short) -1);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder12 = categoryPlot0.getDatasetRenderingOrder();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(datasetRenderingOrder12);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean1 = statisticalLineAndShapeRenderer0.getDrawOutlines();
        statisticalLineAndShapeRenderer0.setBaseSeriesVisible(true, false);
        java.awt.Font font6 = null;
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) numberAxis9, polarItemRenderer10);
        float float12 = polarPlot11.getBackgroundAlpha();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer13 = polarPlot11.getRenderer();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font6, (org.jfree.chart.plot.Plot) polarPlot11, false);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent18 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) false, jFreeChart15, 6, 0);
        java.util.List list19 = null;
        try {
            jFreeChart15.setSubtitles(list19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'subtitles' argument.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 1.0f + "'", float12 == 1.0f);
        org.junit.Assert.assertNull(polarItemRenderer13);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = statisticalLineAndShapeRenderer0.getBaseItemLabelGenerator();
        statisticalLineAndShapeRenderer0.setSeriesItemLabelsVisible((int) '#', (java.lang.Boolean) true, false);
        statisticalLineAndShapeRenderer0.setSeriesLinesVisible(15, (java.lang.Boolean) true);
        org.junit.Assert.assertNull(categoryItemLabelGenerator1);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean1 = statisticalLineAndShapeRenderer0.getDrawOutlines();
        statisticalLineAndShapeRenderer0.setBaseSeriesVisible(true, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer7 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean8 = statisticalLineAndShapeRenderer7.getDrawOutlines();
        statisticalLineAndShapeRenderer7.setAutoPopulateSeriesFillPaint(false);
        java.awt.Stroke stroke12 = statisticalLineAndShapeRenderer7.lookupSeriesStroke(28);
        lineAndShapeRenderer6.setBaseStroke(stroke12);
        java.awt.Paint paint15 = lineAndShapeRenderer6.getSeriesFillPaint((int) '#');
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator20 = new org.jfree.chart.urls.StandardCategoryURLGenerator("", "({0}, {1}) = {3} - {4}", "{0}");
        lineAndShapeRenderer6.setSeriesURLGenerator(2, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator20, true);
        statisticalLineAndShapeRenderer0.setSeriesURLGenerator((int) (byte) 100, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator20, true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(paint15);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long1 = segmentedTimeline0.getStartTime();
        int int2 = segmentedTimeline0.getSegmentsIncluded();
        long long5 = segmentedTimeline0.getExceptionSegmentCount(0L, (-1L));
        long long6 = segmentedTimeline0.getSegmentsGroupSize();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(4, 0);
        java.util.Date date10 = month9.getEnd();
        long long11 = segmentedTimeline0.getTime(date10);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date10);
        java.util.Calendar calendar13 = null;
        try {
            long long14 = year12.getFirstMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-2208927600000L) + "'", long1 == (-2208927600000L));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28 + "'", int2 == 28);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 86400000L + "'", long6 == 86400000L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-62125372800001L) + "'", long11 == (-62125372800001L));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.getCopyright();
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDepthFactor((double) (byte) 1);
        piePlot3D1.setDepthFactor(0.0d);
        java.awt.Stroke[] strokeArray6 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        boolean boolean7 = piePlot3D1.equals((java.lang.Object) strokeArray6);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator8 = null;
        piePlot3D1.setLegendLabelURLGenerator(pieURLGenerator8);
        java.awt.Paint paint10 = piePlot3D1.getNoDataMessagePaint();
        org.junit.Assert.assertNotNull(strokeArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font3 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer4 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer4.setDrawOutlines(true);
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer4.setBasePaint((java.awt.Paint) color7, false);
        org.jfree.chart.text.TextMeasurer textMeasurer11 = null;
        org.jfree.chart.text.TextBlock textBlock12 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, (java.awt.Paint) color7, (float) (byte) -1, textMeasurer11);
        numberAxis1.setTickMarkPaint((java.awt.Paint) color7);
        numberAxis1.setAutoRange(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double18 = rectangleInsets16.calculateBottomOutset((double) 'a');
        double double19 = rectangleInsets16.getRight();
        numberAxis1.setTickLabelInsets(rectangleInsets16);
        org.jfree.data.Range range21 = null;
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.Range range24 = numberAxis23.getDefaultAutoRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint(range24, (double) (-1L));
        org.jfree.data.Range range27 = org.jfree.data.Range.combine(range21, range24);
        org.jfree.data.Range range28 = null;
        org.jfree.data.Range range29 = org.jfree.data.Range.combine(range27, range28);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.Range range32 = numberAxis31.getDefaultAutoRange();
        double double33 = range32.getCentralValue();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint34 = new org.jfree.chart.block.RectangleConstraint(range29, range32);
        numberAxis1.setRange(range29);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(textBlock12);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.5d + "'", double33 == 0.5d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        org.junit.Assert.assertNotNull(categoryAnchor0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 11, 0.25d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("{0}");
        java.lang.String str2 = labelBlock1.getToolTipText();
        java.lang.String str3 = labelBlock1.getURLText();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double6 = rectangleInsets4.calculateBottomOutset(4.0d);
        labelBlock1.setMargin(rectangleInsets4);
        double double9 = rectangleInsets4.trimWidth((double) 1577865599999L);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.577865599997E12d + "'", double9 == 1.577865599997E12d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        boolean boolean1 = textTitle0.getExpandToFitSpace();
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        textTitle0.setVerticalAlignment(verticalAlignment2);
        double double4 = textTitle0.getWidth();
        textTitle0.setURLText("hi!");
        java.awt.Paint paint7 = textTitle0.getPaint();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D0.setMaximumCategoryLabelWidthRatio((float) 86400000L);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer5 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean6 = statisticalLineAndShapeRenderer5.getDrawOutlines();
        statisticalLineAndShapeRenderer5.setAutoPopulateSeriesFillPaint(false);
        java.lang.Object obj9 = statisticalLineAndShapeRenderer5.clone();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        statisticalLineAndShapeRenderer5.setBaseStroke(stroke10);
        statisticalLineAndShapeRenderer5.setBaseItemLabelsVisible(false, false);
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        statisticalLineAndShapeRenderer5.setBaseFillPaint((java.awt.Paint) color15);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = null;
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font22 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer23 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer23.setDrawOutlines(true);
        java.awt.Color color26 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer23.setBasePaint((java.awt.Paint) color26, false);
        org.jfree.chart.text.TextMeasurer textMeasurer30 = null;
        org.jfree.chart.text.TextBlock textBlock31 = org.jfree.chart.text.TextUtilities.createTextBlock("", font22, (java.awt.Paint) color26, (float) (byte) -1, textMeasurer30);
        numberAxis20.setTickMarkPaint((java.awt.Paint) color26);
        org.jfree.chart.plot.Marker marker33 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset34 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range35 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset34);
        org.jfree.data.xy.XYDataset xYDataset36 = null;
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer38 = null;
        org.jfree.chart.plot.PolarPlot polarPlot39 = new org.jfree.chart.plot.PolarPlot(xYDataset36, valueAxis37, polarItemRenderer38);
        defaultCategoryDataset34.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot39);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo42 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo42);
        java.awt.geom.Point2D point2D44 = null;
        polarPlot39.zoomDomainAxes((double) '#', plotRenderingInfo43, point2D44);
        org.jfree.chart.block.BlockContainer blockContainer46 = new org.jfree.chart.block.BlockContainer();
        blockContainer46.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer52 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder57 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer52.setFrame((org.jfree.chart.block.BlockFrame) blockBorder57);
        blockContainer46.add((org.jfree.chart.block.Block) blockContainer52);
        java.awt.Graphics2D graphics2D60 = null;
        org.jfree.chart.util.Size2D size2D61 = blockContainer52.arrange(graphics2D60);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor64 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D65 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D61, (double) '#', (double) 1.0f, rectangleAnchor64);
        plotRenderingInfo43.setPlotArea(rectangle2D65);
        statisticalLineAndShapeRenderer5.drawRangeMarker(graphics2D17, categoryPlot18, (org.jfree.chart.axis.ValueAxis) numberAxis20, marker33, rectangle2D65);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity68 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D65);
        org.jfree.chart.util.RectangleEdge rectangleEdge69 = org.jfree.chart.util.RectangleEdge.TOP;
        boolean boolean71 = rectangleEdge69.equals((java.lang.Object) (-1.0f));
        double double72 = categoryAxis3D0.getCategoryEnd((int) 'a', 8, rectangle2D65, rectangleEdge69);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(textBlock31);
        org.junit.Assert.assertNull(range35);
        org.junit.Assert.assertNotNull(size2D61);
        org.junit.Assert.assertNotNull(rectangleAnchor64);
        org.junit.Assert.assertNotNull(rectangle2D65);
        org.junit.Assert.assertNotNull(rectangleEdge69);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 35.0d + "'", double72 == 35.0d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.lang.Number number3 = defaultBoxAndWhiskerCategoryDataset0.getMaxOutlier((java.lang.Comparable) '#', (java.lang.Comparable) (short) -1);
        org.junit.Assert.assertNull(number3);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.String str1 = rectangleInsets0.toString();
        double double3 = rectangleInsets0.trimHeight((double) 100);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str1.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 98.0d + "'", double3 == 98.0d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        java.awt.Color color0 = java.awt.Color.magenta;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDepthFactor((double) (byte) 1);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = piePlot3D1.getURLGenerator();
        piePlot3D1.setShadowXOffset((double) (byte) 0);
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        piePlot3D1.setLabelBackgroundPaint(paint7);
        org.junit.Assert.assertNull(pieURLGenerator4);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        boolean boolean1 = textTitle0.getExpandToFitSpace();
        java.lang.String str2 = textTitle0.getURLText();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font3 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer4 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer4.setDrawOutlines(true);
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer4.setBasePaint((java.awt.Paint) color7, false);
        org.jfree.chart.text.TextMeasurer textMeasurer11 = null;
        org.jfree.chart.text.TextBlock textBlock12 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, (java.awt.Paint) color7, (float) (byte) -1, textMeasurer11);
        numberAxis1.setTickMarkPaint((java.awt.Paint) color7);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit15 = new org.jfree.chart.axis.NumberTickUnit(0.0d);
        numberAxis1.setTickUnit(numberTickUnit15);
        java.awt.Paint paint17 = numberAxis1.getTickMarkPaint();
        boolean boolean18 = numberAxis1.isTickMarksVisible();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(textBlock12);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainCrosshairPaint();
        xYPlot0.mapDatasetToRangeAxis((int) (byte) 100, 28);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis6 = xYPlot0.getDomainAxisForDataset((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 'index' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = null;
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType4 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition6 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1, textAnchor2, (double) 2, categoryLabelWidthType4, (float) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'labelAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textAnchor2);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint2 = xYPlot1.getDomainCrosshairPaint();
        int int3 = xYPlot1.getSeriesCount();
        java.awt.Paint paint4 = xYPlot1.getRangeZeroBaselinePaint();
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        int int6 = xYPlot1.indexOf(xYDataset5);
        boolean boolean7 = defaultBoxAndWhiskerCategoryDataset0.hasListener((java.util.EventListener) xYPlot1);
        try {
            java.util.List list10 = defaultBoxAndWhiskerCategoryDataset0.getOutliers((int) (short) -1, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font4 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer5 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer5.setDrawOutlines(true);
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer5.setBasePaint((java.awt.Paint) color8, false);
        org.jfree.chart.text.TextMeasurer textMeasurer12 = null;
        org.jfree.chart.text.TextBlock textBlock13 = org.jfree.chart.text.TextUtilities.createTextBlock("", font4, (java.awt.Paint) color8, (float) (byte) -1, textMeasurer12);
        numberAxis2.setTickMarkPaint((java.awt.Paint) color8);
        boolean boolean15 = numberAxis2.isInverted();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer16 = null;
        org.jfree.chart.plot.PolarPlot polarPlot17 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, polarItemRenderer16);
        numberAxis2.zoomRange((double) (-1.0f), (double) (short) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = numberAxis2.getLabelInsets();
        double double23 = rectangleInsets21.calculateRightInset(0.25d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(textBlock13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 3.0d + "'", double23 == 3.0d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.lang.Object obj1 = defaultKeyedValues2D0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long1 = segmentedTimeline0.getStartTime();
        segmentedTimeline0.setStartTime(100L);
        int int4 = segmentedTimeline0.getSegmentsIncluded();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-2208927600000L) + "'", long1 == (-2208927600000L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 28 + "'", int4 == 28);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        java.awt.Paint paint0 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_WALL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDepthFactor((double) (byte) 1);
        piePlot3D1.setDepthFactor(0.0d);
        java.awt.Stroke stroke6 = piePlot3D1.getLabelLinkStroke();
        double double7 = piePlot3D1.getShadowXOffset();
        java.lang.String str8 = piePlot3D1.getNoDataMessage();
        java.awt.Paint paint9 = piePlot3D1.getBaseSectionOutlinePaint();
        java.awt.Paint paint11 = piePlot3D1.getSectionOutlinePaint((java.lang.Comparable) 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font15 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer16 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer16.setDrawOutlines(true);
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer16.setBasePaint((java.awt.Paint) color19, false);
        org.jfree.chart.text.TextMeasurer textMeasurer23 = null;
        org.jfree.chart.text.TextBlock textBlock24 = org.jfree.chart.text.TextUtilities.createTextBlock("", font15, (java.awt.Paint) color19, (float) (byte) -1, textMeasurer23);
        numberAxis13.setTickMarkPaint((java.awt.Paint) color19);
        piePlot3D1.setLabelShadowPaint((java.awt.Paint) color19);
        org.jfree.chart.block.BlockContainer blockContainer27 = new org.jfree.chart.block.BlockContainer();
        blockContainer27.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer33 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder38 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer33.setFrame((org.jfree.chart.block.BlockFrame) blockBorder38);
        blockContainer27.add((org.jfree.chart.block.Block) blockContainer33);
        java.awt.Graphics2D graphics2D41 = null;
        org.jfree.chart.util.Size2D size2D42 = blockContainer33.arrange(graphics2D41);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor45 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D46 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D42, (double) '#', (double) 1.0f, rectangleAnchor45);
        boolean boolean47 = piePlot3D1.equals((java.lang.Object) rectangle2D46);
        double double48 = piePlot3D1.getShadowXOffset();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(textBlock24);
        org.junit.Assert.assertNotNull(size2D42);
        org.junit.Assert.assertNotNull(rectangleAnchor45);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 4.0d + "'", double48 == 4.0d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.util.List list1 = defaultKeyedValues2D0.getRowKeys();
        defaultKeyedValues2D0.clear();
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean1 = statisticalLineAndShapeRenderer0.getDrawOutlines();
        statisticalLineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(false);
        java.lang.Object obj4 = statisticalLineAndShapeRenderer0.clone();
        java.awt.Stroke stroke5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        statisticalLineAndShapeRenderer0.setBaseStroke(stroke5);
        statisticalLineAndShapeRenderer0.setBaseItemLabelsVisible(false, false);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        statisticalLineAndShapeRenderer0.setBaseFillPaint((java.awt.Paint) color10);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = null;
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font17 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer18 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer18.setDrawOutlines(true);
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer18.setBasePaint((java.awt.Paint) color21, false);
        org.jfree.chart.text.TextMeasurer textMeasurer25 = null;
        org.jfree.chart.text.TextBlock textBlock26 = org.jfree.chart.text.TextUtilities.createTextBlock("", font17, (java.awt.Paint) color21, (float) (byte) -1, textMeasurer25);
        numberAxis15.setTickMarkPaint((java.awt.Paint) color21);
        org.jfree.chart.plot.Marker marker28 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset29 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset29);
        org.jfree.data.xy.XYDataset xYDataset31 = null;
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer33 = null;
        org.jfree.chart.plot.PolarPlot polarPlot34 = new org.jfree.chart.plot.PolarPlot(xYDataset31, valueAxis32, polarItemRenderer33);
        defaultCategoryDataset29.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot34);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo37 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo37);
        java.awt.geom.Point2D point2D39 = null;
        polarPlot34.zoomDomainAxes((double) '#', plotRenderingInfo38, point2D39);
        org.jfree.chart.block.BlockContainer blockContainer41 = new org.jfree.chart.block.BlockContainer();
        blockContainer41.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer47 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder52 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer47.setFrame((org.jfree.chart.block.BlockFrame) blockBorder52);
        blockContainer41.add((org.jfree.chart.block.Block) blockContainer47);
        java.awt.Graphics2D graphics2D55 = null;
        org.jfree.chart.util.Size2D size2D56 = blockContainer47.arrange(graphics2D55);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor59 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D60 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D56, (double) '#', (double) 1.0f, rectangleAnchor59);
        plotRenderingInfo38.setPlotArea(rectangle2D60);
        statisticalLineAndShapeRenderer0.drawRangeMarker(graphics2D12, categoryPlot13, (org.jfree.chart.axis.ValueAxis) numberAxis15, marker28, rectangle2D60);
        java.awt.Paint paint64 = statisticalLineAndShapeRenderer0.getSeriesOutlinePaint(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(textBlock26);
        org.junit.Assert.assertNull(range30);
        org.junit.Assert.assertNotNull(size2D56);
        org.junit.Assert.assertNotNull(rectangleAnchor59);
        org.junit.Assert.assertNotNull(rectangle2D60);
        org.junit.Assert.assertNull(paint64);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.RangeType rangeType2 = numberAxis1.getRangeType();
        java.lang.String str3 = rangeType2.toString();
        org.junit.Assert.assertNotNull(rangeType2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RangeType.FULL" + "'", str3.equals("RangeType.FULL"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer1 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean2 = statisticalLineAndShapeRenderer1.getDrawOutlines();
        statisticalLineAndShapeRenderer1.setAutoPopulateSeriesFillPaint(false);
        java.awt.Stroke stroke6 = statisticalLineAndShapeRenderer1.lookupSeriesStroke(28);
        lineAndShapeRenderer0.setBaseStroke(stroke6);
        java.awt.Paint paint9 = lineAndShapeRenderer0.getSeriesFillPaint((int) '#');
        java.awt.Stroke stroke12 = lineAndShapeRenderer0.getItemOutlineStroke(1, 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = lineAndShapeRenderer0.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        boolean boolean15 = lineAndShapeRenderer0.getAutoPopulateSeriesFillPaint();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        int int2 = xYPlot0.indexOf(xYDataset1);
        org.jfree.chart.util.Layer layer4 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(6, layer4);
        java.awt.Paint paint6 = xYPlot0.getRangeTickBandPaint();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder7 = null;
        try {
            xYPlot0.setSeriesRenderingOrder(seriesRenderingOrder7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(layer4);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNull(paint6);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation(0.0d, (double) (short) 1);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.Range range2 = numberAxis1.getDefaultAutoRange();
        numberAxis1.setAutoTickUnitSelection(false);
        numberAxis1.setAutoTickUnitSelection(false, true);
        org.junit.Assert.assertNotNull(range2);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("#ffff40", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis2.setInverted(true);
        boolean boolean5 = numberAxis2.isAxisLineVisible();
        boolean boolean6 = numberAxis2.getAutoRangeStickyZero();
        java.awt.Stroke stroke7 = numberAxis2.getAxisLineStroke();
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis2);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer9 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean10 = statisticalLineAndShapeRenderer9.getDrawOutlines();
        statisticalLineAndShapeRenderer9.setAutoPopulateSeriesFillPaint(false);
        java.lang.Object obj13 = statisticalLineAndShapeRenderer9.clone();
        java.awt.Stroke stroke14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        statisticalLineAndShapeRenderer9.setBaseStroke(stroke14);
        boolean boolean18 = statisticalLineAndShapeRenderer9.getItemShapeVisible((int) '4', (int) (byte) 10);
        java.awt.Font font20 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        statisticalLineAndShapeRenderer9.setSeriesItemLabelFont((int) 'a', font20);
        java.awt.Paint paint22 = statisticalLineAndShapeRenderer9.getErrorIndicatorPaint();
        int int23 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer9);
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font27 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer28 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer28.setDrawOutlines(true);
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer28.setBasePaint((java.awt.Paint) color31, false);
        org.jfree.chart.text.TextMeasurer textMeasurer35 = null;
        org.jfree.chart.text.TextBlock textBlock36 = org.jfree.chart.text.TextUtilities.createTextBlock("", font27, (java.awt.Paint) color31, (float) (byte) -1, textMeasurer35);
        numberAxis25.setTickMarkPaint((java.awt.Paint) color31);
        numberAxis25.setLabelURL("RectangleConstraintType.RANGE");
        boolean boolean40 = categoryPlot0.equals((java.lang.Object) numberAxis25);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = categoryPlot0.getDomainAxis((int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNull(paint22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(textBlock36);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNull(categoryAxis42);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis2.setInverted(true);
        boolean boolean5 = numberAxis2.isAxisLineVisible();
        boolean boolean6 = numberAxis2.getAutoRangeStickyZero();
        java.awt.Stroke stroke7 = numberAxis2.getAxisLineStroke();
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis2);
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot0.getRangeAxisLocation(0);
        float float11 = categoryPlot0.getBackgroundAlpha();
        org.jfree.chart.axis.AxisSpace axisSpace12 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = null;
        try {
            categoryPlot0.setInsets(rectangleInsets13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 1.0f + "'", float11 == 1.0f);
        org.junit.Assert.assertNull(axisSpace12);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D4 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        boolean boolean6 = categoryAxis3D4.equals((java.lang.Object) textAnchor5);
        categoryAxis3D4.setMaximumCategoryLabelWidthRatio((float) 60000L);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset11 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range12 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer15 = null;
        org.jfree.chart.plot.PolarPlot polarPlot16 = new org.jfree.chart.plot.PolarPlot(xYDataset13, valueAxis14, polarItemRenderer15);
        defaultCategoryDataset11.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot16);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo19);
        java.awt.geom.Point2D point2D21 = null;
        polarPlot16.zoomDomainAxes((double) '#', plotRenderingInfo20, point2D21);
        org.jfree.chart.block.BlockContainer blockContainer23 = new org.jfree.chart.block.BlockContainer();
        blockContainer23.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer29 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder34 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer29.setFrame((org.jfree.chart.block.BlockFrame) blockBorder34);
        blockContainer23.add((org.jfree.chart.block.Block) blockContainer29);
        java.awt.Graphics2D graphics2D37 = null;
        org.jfree.chart.util.Size2D size2D38 = blockContainer29.arrange(graphics2D37);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor41 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D42 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D38, (double) '#', (double) 1.0f, rectangleAnchor41);
        plotRenderingInfo20.setPlotArea(rectangle2D42);
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis46 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis46.setInverted(true);
        boolean boolean49 = numberAxis46.isAxisLineVisible();
        boolean boolean50 = numberAxis46.getAutoRangeStickyZero();
        java.awt.Stroke stroke51 = numberAxis46.getAxisLineStroke();
        categoryPlot44.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis46);
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = categoryPlot44.getDomainAxisEdge();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer54 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean55 = rectangleEdge53.equals((java.lang.Object) statisticalBarRenderer54);
        double double56 = categoryAxis3D4.getCategoryMiddle((-1), 100, rectangle2D42, rectangleEdge53);
        try {
            xYPlot0.drawBackground(graphics2D3, rectangle2D42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertNotNull(size2D38);
        org.junit.Assert.assertNotNull(rectangleAnchor41);
        org.junit.Assert.assertNotNull(rectangle2D42);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(rectangleEdge53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 35.0d + "'", double56 == 35.0d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues0.removeValue((java.lang.Comparable) "EXPAND");
        java.awt.Font font4 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer5 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer5.setDrawOutlines(true);
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer5.setBasePaint((java.awt.Paint) color8, false);
        org.jfree.chart.text.TextMeasurer textMeasurer12 = null;
        org.jfree.chart.text.TextBlock textBlock13 = org.jfree.chart.text.TextUtilities.createTextBlock("", font4, (java.awt.Paint) color8, (float) (byte) -1, textMeasurer12);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor17 = null;
        java.awt.Shape shape21 = textBlock13.calculateBounds(graphics2D14, (float) 1, 100.0f, textBlockAnchor17, (float) 3, (float) (short) -1, (double) 0);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset24 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range25 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset24);
        org.jfree.data.Range range26 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset24);
        java.lang.Comparable comparable27 = null;
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity29 = new org.jfree.chart.entity.CategoryItemEntity(shape21, "{0}", "EXPAND", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset24, comparable27, (java.lang.Comparable) 1.0d);
        org.jfree.chart.util.SortOrder sortOrder30 = org.jfree.chart.util.SortOrder.DESCENDING;
        boolean boolean31 = categoryItemEntity29.equals((java.lang.Object) sortOrder30);
        defaultKeyedValues0.sortByValues(sortOrder30);
        java.lang.Object obj33 = null;
        boolean boolean34 = defaultKeyedValues0.equals(obj33);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(textBlock13);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertNull(range26);
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        boolean boolean2 = categoryAxis3D0.equals((java.lang.Object) textAnchor1);
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D(pieDataset3);
        boolean boolean5 = piePlot3D4.getIgnoreNullValues();
        categoryAxis3D0.setPlot((org.jfree.chart.plot.Plot) piePlot3D4);
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.Range range2 = numberAxis1.getDefaultAutoRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = new org.jfree.chart.block.RectangleConstraint(range2, (double) (-1L));
        org.jfree.data.Range range6 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean8 = range6.contains((double) 2);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint(0.0d, range6);
        org.jfree.chart.block.BlockContainer blockContainer10 = new org.jfree.chart.block.BlockContainer();
        blockContainer10.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer16 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder21 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer16.setFrame((org.jfree.chart.block.BlockFrame) blockBorder21);
        blockContainer10.add((org.jfree.chart.block.Block) blockContainer16);
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.util.Size2D size2D25 = blockContainer16.arrange(graphics2D24);
        org.jfree.chart.util.Size2D size2D26 = rectangleConstraint9.calculateConstrainedSize(size2D25);
        org.jfree.chart.util.Size2D size2D27 = rectangleConstraint4.calculateConstrainedSize(size2D26);
        size2D27.width = 1.0f;
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(size2D25);
        org.junit.Assert.assertNotNull(size2D26);
        org.junit.Assert.assertNotNull(size2D27);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        try {
            keyedObjects2D0.removeRow(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font3 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer4 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer4.setDrawOutlines(true);
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer4.setBasePaint((java.awt.Paint) color7, false);
        org.jfree.chart.text.TextMeasurer textMeasurer11 = null;
        org.jfree.chart.text.TextBlock textBlock12 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, (java.awt.Paint) color7, (float) (byte) -1, textMeasurer11);
        numberAxis1.setTickMarkPaint((java.awt.Paint) color7);
        numberAxis1.configure();
        numberAxis1.setFixedAutoRange((double) (-1L));
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_RED;
        numberAxis1.setLabelPaint((java.awt.Paint) color17);
        double double19 = numberAxis1.getUpperBound();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(textBlock12);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long1 = segmentedTimeline0.getStartTime();
        int int2 = segmentedTimeline0.getSegmentsIncluded();
        long long5 = segmentedTimeline0.getExceptionSegmentCount(0L, (-1L));
        long long6 = segmentedTimeline0.getSegmentsGroupSize();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(4, 0);
        java.util.Date date10 = month9.getEnd();
        long long11 = segmentedTimeline0.getTime(date10);
        try {
            org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance(date10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-2208927600000L) + "'", long1 == (-2208927600000L));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28 + "'", int2 == 28);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 86400000L + "'", long6 == 86400000L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-62125372800001L) + "'", long11 == (-62125372800001L));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        int int2 = xYPlot0.indexOf(xYDataset1);
        org.jfree.chart.util.Layer layer4 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(6, layer4);
        org.jfree.chart.axis.AxisSpace axisSpace6 = xYPlot0.getFixedRangeAxisSpace();
        xYPlot0.clearDomainAxes();
        org.jfree.chart.axis.AxisLocation axisLocation9 = xYPlot0.getDomainAxisLocation((-16744320));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(layer4);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNull(axisSpace6);
        org.junit.Assert.assertNotNull(axisLocation9);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer4 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = null;
        statisticalLineAndShapeRenderer4.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator6, true);
        statisticalLineAndShapeRenderer4.setSeriesVisibleInLegend(0, (java.lang.Boolean) true, true);
        java.lang.Boolean boolean14 = statisticalLineAndShapeRenderer4.getSeriesVisibleInLegend(100);
        java.awt.Shape shape17 = statisticalLineAndShapeRenderer4.getItemShape((int) (short) 100, (int) (byte) -1);
        org.jfree.chart.block.BlockBorder blockBorder22 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor23 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        boolean boolean24 = blockBorder22.equals((java.lang.Object) itemLabelAnchor23);
        java.awt.Paint paint25 = blockBorder22.getPaint();
        try {
            org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem(attributedString0, "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", "ItemLabelAnchor.OUTSIDE8", "hi!", shape17, paint25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(boolean14);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(itemLabelAnchor23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = statisticalLineAndShapeRenderer0.getBaseItemLabelGenerator();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator3 = null;
        statisticalLineAndShapeRenderer0.setSeriesItemLabelGenerator((int) (byte) 100, categoryItemLabelGenerator3, true);
        java.lang.Object obj6 = null;
        boolean boolean7 = statisticalLineAndShapeRenderer0.equals(obj6);
        org.junit.Assert.assertNull(categoryItemLabelGenerator1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean1 = statisticalLineAndShapeRenderer0.getDrawOutlines();
        statisticalLineAndShapeRenderer0.setBaseSeriesVisible(true, false);
        java.lang.Boolean boolean6 = statisticalLineAndShapeRenderer0.getSeriesCreateEntities((int) (short) -1);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset7 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset7);
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer11 = null;
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot(xYDataset9, valueAxis10, polarItemRenderer11);
        defaultCategoryDataset7.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot12);
        java.awt.Image image14 = polarPlot12.getBackgroundImage();
        java.awt.Paint paint15 = polarPlot12.getBackgroundPaint();
        java.awt.Stroke stroke16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        polarPlot12.setRadiusGridlineStroke(stroke16);
        statisticalLineAndShapeRenderer0.setBaseOutlineStroke(stroke16);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNull(image14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.Range range4 = numberAxis3.getDefaultAutoRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint(range4, (double) (-1L));
        org.jfree.data.Range range7 = org.jfree.data.Range.combine(range1, range4);
        org.jfree.data.Range range8 = null;
        org.jfree.data.Range range9 = org.jfree.data.Range.combine(range7, range8);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((double) 1L, range9);
        org.jfree.data.Range range11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.Range range14 = numberAxis13.getDefaultAutoRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint(range14, (double) (-1L));
        org.jfree.data.Range range17 = org.jfree.data.Range.combine(range11, range14);
        org.jfree.data.Range range18 = null;
        org.jfree.data.Range range19 = org.jfree.data.Range.combine(range17, range18);
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = rectangleConstraint10.toRangeWidth(range18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNotNull(range19);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
        stackedBarRenderer0.setRenderAsPercentages(false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape2 = null;
        try {
            shapeList0.setShape((-1), shape2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer0.setDrawOutlines(true);
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer0.setBasePaint((java.awt.Paint) color3, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = statisticalLineAndShapeRenderer0.getSeriesNegativeItemLabelPosition(0);
        statisticalLineAndShapeRenderer0.setBaseLinesVisible(true);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis2.setInverted(true);
        boolean boolean5 = numberAxis2.isAxisLineVisible();
        boolean boolean6 = numberAxis2.getAutoRangeStickyZero();
        java.awt.Stroke stroke7 = numberAxis2.getAxisLineStroke();
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis2);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot0.getDomainAxisForDataset((int) ' ');
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset15 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset15);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot(xYDataset17, valueAxis18, polarItemRenderer19);
        defaultCategoryDataset15.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot20);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo23 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo23);
        java.awt.geom.Point2D point2D25 = null;
        polarPlot20.zoomDomainAxes((double) '#', plotRenderingInfo24, point2D25);
        org.jfree.chart.block.BlockContainer blockContainer27 = new org.jfree.chart.block.BlockContainer();
        blockContainer27.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer33 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder38 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer33.setFrame((org.jfree.chart.block.BlockFrame) blockBorder38);
        blockContainer27.add((org.jfree.chart.block.Block) blockContainer33);
        java.awt.Graphics2D graphics2D41 = null;
        org.jfree.chart.util.Size2D size2D42 = blockContainer33.arrange(graphics2D41);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor45 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D46 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D42, (double) '#', (double) 1.0f, rectangleAnchor45);
        plotRenderingInfo24.setPlotArea(rectangle2D46);
        categoryPlot12.handleClick(0, 0, plotRenderingInfo24);
        org.jfree.chart.util.Layer layer49 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection50 = categoryPlot12.getDomainMarkers(layer49);
        try {
            categoryPlot0.addDomainMarker(categoryMarker11, layer49);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(size2D42);
        org.junit.Assert.assertNotNull(rectangleAnchor45);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertNotNull(layer49);
        org.junit.Assert.assertNull(collection50);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean1 = statisticalLineAndShapeRenderer0.getDrawOutlines();
        statisticalLineAndShapeRenderer0.setBaseSeriesVisible(true, false);
        java.lang.Boolean boolean6 = statisticalLineAndShapeRenderer0.getSeriesCreateEntities((int) (short) -1);
        statisticalLineAndShapeRenderer0.setAutoPopulateSeriesShape(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(boolean6);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = new org.jfree.chart.axis.CategoryLabelPositions();
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font3 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer4 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer4.setDrawOutlines(true);
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer4.setBasePaint((java.awt.Paint) color7, false);
        org.jfree.chart.text.TextMeasurer textMeasurer11 = null;
        org.jfree.chart.text.TextBlock textBlock12 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, (java.awt.Paint) color7, (float) (byte) -1, textMeasurer11);
        numberAxis1.setTickMarkPaint((java.awt.Paint) color7);
        numberAxis1.setLabelURL("RectangleConstraintType.RANGE");
        boolean boolean16 = numberAxis1.isAutoTickUnitSelection();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(textBlock12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean1 = statisticalLineAndShapeRenderer0.getDrawOutlines();
        statisticalLineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(false);
        java.awt.Stroke stroke5 = statisticalLineAndShapeRenderer0.lookupSeriesStroke(28);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = statisticalLineAndShapeRenderer0.getBaseNegativeItemLabelPosition();
        double double7 = itemLabelPosition6.getAngle();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor8 = itemLabelPosition6.getItemLabelAnchor();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor8);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) '#');
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        java.lang.Class class0 = null;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline2 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long3 = segmentedTimeline2.getStartTime();
        int int4 = segmentedTimeline2.getSegmentsIncluded();
        long long7 = segmentedTimeline2.getExceptionSegmentCount(0L, (-1L));
        long long8 = segmentedTimeline2.getSegmentsGroupSize();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(4, 0);
        java.util.Date date12 = month11.getEnd();
        long long13 = segmentedTimeline2.getTime(date12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date12);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(4, 0);
        java.util.Date date18 = month17.getEnd();
        org.jfree.data.gantt.Task task19 = new org.jfree.data.gantt.Task("", date12, date18);
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date12, timeZone20);
        org.junit.Assert.assertNotNull(segmentedTimeline2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-2208927600000L) + "'", long3 == (-2208927600000L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 28 + "'", int4 == 28);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 86400000L + "'", long8 == 86400000L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-62125372800001L) + "'", long13 == (-62125372800001L));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNull(regularTimePeriod21);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis2.setInverted(true);
        boolean boolean5 = numberAxis2.isAxisLineVisible();
        boolean boolean6 = numberAxis2.getAutoRangeStickyZero();
        java.awt.Stroke stroke7 = numberAxis2.getAxisLineStroke();
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis2);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer9 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean10 = statisticalLineAndShapeRenderer9.getDrawOutlines();
        statisticalLineAndShapeRenderer9.setAutoPopulateSeriesFillPaint(false);
        java.lang.Object obj13 = statisticalLineAndShapeRenderer9.clone();
        java.awt.Stroke stroke14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        statisticalLineAndShapeRenderer9.setBaseStroke(stroke14);
        boolean boolean18 = statisticalLineAndShapeRenderer9.getItemShapeVisible((int) '4', (int) (byte) 10);
        java.awt.Font font20 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        statisticalLineAndShapeRenderer9.setSeriesItemLabelFont((int) 'a', font20);
        java.awt.Paint paint22 = statisticalLineAndShapeRenderer9.getErrorIndicatorPaint();
        int int23 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer9);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer24 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean25 = statisticalLineAndShapeRenderer24.getDrawOutlines();
        int int26 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer24);
        java.awt.Stroke stroke28 = statisticalLineAndShapeRenderer24.getSeriesOutlineStroke(255);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNull(paint22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNull(stroke28);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font3 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer4 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer4.setDrawOutlines(true);
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer4.setBasePaint((java.awt.Paint) color7, false);
        org.jfree.chart.text.TextMeasurer textMeasurer11 = null;
        org.jfree.chart.text.TextBlock textBlock12 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, (java.awt.Paint) color7, (float) (byte) -1, textMeasurer11);
        numberAxis1.setTickMarkPaint((java.awt.Paint) color7);
        boolean boolean14 = numberAxis1.isInverted();
        org.jfree.data.RangeType rangeType15 = numberAxis1.getRangeType();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(textBlock12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rangeType15);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline1 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long2 = segmentedTimeline1.getStartTime();
        int int3 = segmentedTimeline1.getSegmentsIncluded();
        long long6 = segmentedTimeline1.getExceptionSegmentCount(0L, (-1L));
        long long7 = segmentedTimeline1.getSegmentsGroupSize();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(4, 0);
        java.util.Date date11 = month10.getEnd();
        long long12 = segmentedTimeline1.getTime(date11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date11);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(4, 0);
        java.util.Date date17 = month16.getEnd();
        org.jfree.data.gantt.Task task18 = new org.jfree.data.gantt.Task("", date11, date17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D21 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        boolean boolean23 = categoryAxis3D21.equals((java.lang.Object) textAnchor22);
        org.jfree.chart.axis.DateTick dateTick25 = new org.jfree.chart.axis.DateTick(date17, "TextBlockAnchor.TOP_CENTER", textAnchor20, textAnchor22, (double) '#');
        double double26 = dateTick25.getAngle();
        org.junit.Assert.assertNotNull(segmentedTimeline1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2208927600000L) + "'", long2 == (-2208927600000L));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 28 + "'", int3 == 28);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 86400000L + "'", long7 == 86400000L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62125372800001L) + "'", long12 == (-62125372800001L));
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 35.0d + "'", double26 == 35.0d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = null;
        statisticalLineAndShapeRenderer0.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator2, true);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer5 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean6 = statisticalLineAndShapeRenderer5.getDrawOutlines();
        statisticalLineAndShapeRenderer5.setAutoPopulateSeriesFillPaint(false);
        java.awt.Stroke stroke10 = statisticalLineAndShapeRenderer5.lookupSeriesStroke(28);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = statisticalLineAndShapeRenderer5.getBaseNegativeItemLabelPosition();
        statisticalLineAndShapeRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition11);
        double double13 = itemLabelPosition11.getAngle();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor14 = itemLabelPosition11.getItemLabelAnchor();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor14);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("SortOrder.DESCENDING");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean1 = statisticalLineAndShapeRenderer0.getDrawOutlines();
        statisticalLineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(false);
        java.lang.Object obj4 = statisticalLineAndShapeRenderer0.clone();
        java.awt.Stroke stroke5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        statisticalLineAndShapeRenderer0.setBaseStroke(stroke5);
        statisticalLineAndShapeRenderer0.setBaseItemLabelsVisible(false, false);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        statisticalLineAndShapeRenderer0.setBaseFillPaint((java.awt.Paint) color10);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = null;
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font17 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer18 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer18.setDrawOutlines(true);
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer18.setBasePaint((java.awt.Paint) color21, false);
        org.jfree.chart.text.TextMeasurer textMeasurer25 = null;
        org.jfree.chart.text.TextBlock textBlock26 = org.jfree.chart.text.TextUtilities.createTextBlock("", font17, (java.awt.Paint) color21, (float) (byte) -1, textMeasurer25);
        numberAxis15.setTickMarkPaint((java.awt.Paint) color21);
        org.jfree.chart.plot.Marker marker28 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset29 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset29);
        org.jfree.data.xy.XYDataset xYDataset31 = null;
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer33 = null;
        org.jfree.chart.plot.PolarPlot polarPlot34 = new org.jfree.chart.plot.PolarPlot(xYDataset31, valueAxis32, polarItemRenderer33);
        defaultCategoryDataset29.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot34);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo37 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo37);
        java.awt.geom.Point2D point2D39 = null;
        polarPlot34.zoomDomainAxes((double) '#', plotRenderingInfo38, point2D39);
        org.jfree.chart.block.BlockContainer blockContainer41 = new org.jfree.chart.block.BlockContainer();
        blockContainer41.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer47 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder52 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer47.setFrame((org.jfree.chart.block.BlockFrame) blockBorder52);
        blockContainer41.add((org.jfree.chart.block.Block) blockContainer47);
        java.awt.Graphics2D graphics2D55 = null;
        org.jfree.chart.util.Size2D size2D56 = blockContainer47.arrange(graphics2D55);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor59 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D60 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D56, (double) '#', (double) 1.0f, rectangleAnchor59);
        plotRenderingInfo38.setPlotArea(rectangle2D60);
        statisticalLineAndShapeRenderer0.drawRangeMarker(graphics2D12, categoryPlot13, (org.jfree.chart.axis.ValueAxis) numberAxis15, marker28, rectangle2D60);
        java.awt.Shape shape63 = numberAxis15.getUpArrow();
        java.awt.Shape shape64 = numberAxis15.getDownArrow();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(textBlock26);
        org.junit.Assert.assertNull(range30);
        org.junit.Assert.assertNotNull(size2D56);
        org.junit.Assert.assertNotNull(rectangleAnchor59);
        org.junit.Assert.assertNotNull(rectangle2D60);
        org.junit.Assert.assertNotNull(shape63);
        org.junit.Assert.assertNotNull(shape64);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDepthFactor((double) (byte) 1);
        piePlot3D1.setDepthFactor(0.0d);
        java.awt.Stroke[] strokeArray6 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        boolean boolean7 = piePlot3D1.equals((java.lang.Object) strokeArray6);
        java.awt.Paint paint8 = piePlot3D1.getLabelShadowPaint();
        java.awt.Paint paint9 = piePlot3D1.getLabelBackgroundPaint();
        boolean boolean10 = piePlot3D1.getLabelLinksVisible();
        java.awt.Paint paint11 = piePlot3D1.getBaseSectionOutlinePaint();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D13 = new org.jfree.chart.plot.PiePlot3D(pieDataset12);
        piePlot3D13.setDepthFactor((double) (byte) 1);
        piePlot3D13.setDepthFactor(0.0d);
        java.awt.Stroke[] strokeArray18 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        boolean boolean19 = piePlot3D13.equals((java.lang.Object) strokeArray18);
        org.jfree.chart.util.Rotation rotation20 = piePlot3D13.getDirection();
        piePlot3D1.setDirection(rotation20);
        try {
            piePlot3D1.setInteriorGap((double) 28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'percent' (28.0) argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strokeArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(strokeArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(rotation20);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset2, valueAxis3, polarItemRenderer4);
        defaultCategoryDataset0.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot5);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo8);
        java.awt.geom.Point2D point2D10 = null;
        polarPlot5.zoomDomainAxes((double) '#', plotRenderingInfo9, point2D10);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo12 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo12);
        plotRenderingInfo9.addSubplotInfo(plotRenderingInfo13);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = plotRenderingInfo9.getSubplotInfo((int) (byte) 0);
        org.jfree.chart.renderer.RendererState rendererState17 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo16);
        org.jfree.chart.entity.EntityCollection entityCollection18 = rendererState17.getEntityCollection();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNotNull(plotRenderingInfo16);
        org.junit.Assert.assertNull(entityCollection18);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer0.setDrawOutlines(true);
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer0.setBasePaint((java.awt.Paint) color3, false);
        statisticalLineAndShapeRenderer0.setUseFillPaint(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = null;
        statisticalLineAndShapeRenderer0.notifyListeners(rendererChangeEvent8);
        java.lang.Object obj10 = statisticalLineAndShapeRenderer0.clone();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = statisticalLineAndShapeRenderer0.getPositiveItemLabelPosition(1, 0);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(itemLabelPosition13);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis2.setInverted(true);
        boolean boolean5 = numberAxis2.isAxisLineVisible();
        boolean boolean6 = numberAxis2.getAutoRangeStickyZero();
        java.awt.Stroke stroke7 = numberAxis2.getAxisLineStroke();
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis2);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer9 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean10 = statisticalLineAndShapeRenderer9.getDrawOutlines();
        statisticalLineAndShapeRenderer9.setAutoPopulateSeriesFillPaint(false);
        java.lang.Object obj13 = statisticalLineAndShapeRenderer9.clone();
        java.awt.Stroke stroke14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        statisticalLineAndShapeRenderer9.setBaseStroke(stroke14);
        boolean boolean18 = statisticalLineAndShapeRenderer9.getItemShapeVisible((int) '4', (int) (byte) 10);
        java.awt.Font font20 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        statisticalLineAndShapeRenderer9.setSeriesItemLabelFont((int) 'a', font20);
        java.awt.Paint paint22 = statisticalLineAndShapeRenderer9.getErrorIndicatorPaint();
        int int23 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer9);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer24 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean25 = statisticalLineAndShapeRenderer24.getDrawOutlines();
        int int26 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer24);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent27 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent27);
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint31 = xYPlot30.getDomainCrosshairPaint();
        int int32 = xYPlot30.getSeriesCount();
        java.awt.Paint paint33 = xYPlot30.getRangeZeroBaselinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation34 = xYPlot30.getRangeAxisLocation();
        try {
            categoryPlot0.setDomainAxisLocation((int) (byte) -1, axisLocation34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNull(paint22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(axisLocation34);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        boolean boolean2 = categoryAxis3D0.equals((java.lang.Object) textAnchor1);
        categoryAxis3D0.setMaximumCategoryLabelWidthRatio((float) 60000L);
        categoryAxis3D0.setFixedDimension(0.2d);
        categoryAxis3D0.configure();
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(0, (int) (byte) 10, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDepthFactor((double) (byte) 1);
        piePlot3D1.setDepthFactor(0.0d);
        piePlot3D1.setInteriorGap((double) 0.0f);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator8 = piePlot3D1.getURLGenerator();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand11 = numberAxis10.getMarkerBand();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand12 = numberAxis10.getMarkerBand();
        numberAxis10.setRangeAboutValue((double) 100L, 12.0d);
        boolean boolean16 = piePlot3D1.equals((java.lang.Object) 12.0d);
        org.junit.Assert.assertNull(pieURLGenerator8);
        org.junit.Assert.assertNull(markerAxisBand11);
        org.junit.Assert.assertNull(markerAxisBand12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.NEGATIVE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        boolean boolean3 = categoryAxis3D1.equals((java.lang.Object) textAnchor2);
        categoryAxis3D1.setMaximumCategoryLabelWidthRatio((float) 60000L);
        categoryAxis3D1.setFixedDimension(0.2d);
        boolean boolean8 = rangeType0.equals((java.lang.Object) categoryAxis3D1);
        org.junit.Assert.assertNotNull(rangeType0);
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis2.setInverted(true);
        boolean boolean5 = numberAxis2.isAxisLineVisible();
        boolean boolean6 = numberAxis2.getAutoRangeStickyZero();
        java.awt.Stroke stroke7 = numberAxis2.getAxisLineStroke();
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis2);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryPlot0.getAxisOffset();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        double[] doubleArray4 = new double[] {};
        double[] doubleArray5 = new double[] {};
        double[][] doubleArray6 = new double[][] { doubleArray4, doubleArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "ItemLabelAnchor.OUTSIDE8", doubleArray6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ClassContext", "ItemLabelAnchor.OUTSIDE8", doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertNotNull(categoryDataset8);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, polarItemRenderer3);
        float float5 = polarPlot4.getBackgroundAlpha();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = polarPlot4.getRenderer();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font11 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer12 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer12.setDrawOutlines(true);
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer12.setBasePaint((java.awt.Paint) color15, false);
        org.jfree.chart.text.TextMeasurer textMeasurer19 = null;
        org.jfree.chart.text.TextBlock textBlock20 = org.jfree.chart.text.TextUtilities.createTextBlock("", font11, (java.awt.Paint) color15, (float) (byte) -1, textMeasurer19);
        numberAxis9.setTickMarkPaint((java.awt.Paint) color15);
        boolean boolean22 = numberAxis9.isInverted();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer23 = null;
        org.jfree.chart.plot.PolarPlot polarPlot24 = new org.jfree.chart.plot.PolarPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) numberAxis9, polarItemRenderer23);
        numberAxis9.zoomRange((double) (-1.0f), (double) (short) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = numberAxis9.getLabelInsets();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent29 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis9);
        polarPlot4.axisChanged(axisChangeEvent29);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 1.0f + "'", float5 == 1.0f);
        org.junit.Assert.assertNull(polarItemRenderer6);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(textBlock20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(rectangleInsets28);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        java.awt.Font font1 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer2.setDrawOutlines(true);
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer2.setBasePaint((java.awt.Paint) color5, false);
        org.jfree.chart.text.TextMeasurer textMeasurer9 = null;
        org.jfree.chart.text.TextBlock textBlock10 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color5, (float) (byte) -1, textMeasurer9);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor14 = null;
        java.awt.Shape shape18 = textBlock10.calculateBounds(graphics2D11, (float) 1, 100.0f, textBlockAnchor14, (float) 3, (float) (short) -1, (double) 0);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset21 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range22 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset21);
        org.jfree.data.Range range23 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset21);
        java.lang.Comparable comparable24 = null;
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity26 = new org.jfree.chart.entity.CategoryItemEntity(shape18, "{0}", "EXPAND", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset21, comparable24, (java.lang.Comparable) 1.0d);
        java.lang.String str27 = categoryItemEntity26.toString();
        java.lang.Comparable comparable28 = categoryItemEntity26.getColumnKey();
        java.lang.String str29 = categoryItemEntity26.toString();
        java.lang.Comparable comparable30 = categoryItemEntity26.getColumnKey();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(textBlock10);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNull(range22);
        org.junit.Assert.assertNull(range23);
        org.junit.Assert.assertTrue("'" + comparable28 + "' != '" + 1.0d + "'", comparable28.equals(1.0d));
        org.junit.Assert.assertTrue("'" + comparable30 + "' != '" + 1.0d + "'", comparable30.equals(1.0d));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean1 = statisticalLineAndShapeRenderer0.getDrawOutlines();
        statisticalLineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(false);
        java.lang.Object obj4 = statisticalLineAndShapeRenderer0.clone();
        java.awt.Stroke stroke5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        statisticalLineAndShapeRenderer0.setBaseStroke(stroke5);
        statisticalLineAndShapeRenderer0.setBaseItemLabelsVisible(false, false);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        statisticalLineAndShapeRenderer0.setBaseFillPaint((java.awt.Paint) color10);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = null;
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font17 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer18 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer18.setDrawOutlines(true);
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer18.setBasePaint((java.awt.Paint) color21, false);
        org.jfree.chart.text.TextMeasurer textMeasurer25 = null;
        org.jfree.chart.text.TextBlock textBlock26 = org.jfree.chart.text.TextUtilities.createTextBlock("", font17, (java.awt.Paint) color21, (float) (byte) -1, textMeasurer25);
        numberAxis15.setTickMarkPaint((java.awt.Paint) color21);
        org.jfree.chart.plot.Marker marker28 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset29 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset29);
        org.jfree.data.xy.XYDataset xYDataset31 = null;
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer33 = null;
        org.jfree.chart.plot.PolarPlot polarPlot34 = new org.jfree.chart.plot.PolarPlot(xYDataset31, valueAxis32, polarItemRenderer33);
        defaultCategoryDataset29.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot34);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo37 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo37);
        java.awt.geom.Point2D point2D39 = null;
        polarPlot34.zoomDomainAxes((double) '#', plotRenderingInfo38, point2D39);
        org.jfree.chart.block.BlockContainer blockContainer41 = new org.jfree.chart.block.BlockContainer();
        blockContainer41.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer47 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder52 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer47.setFrame((org.jfree.chart.block.BlockFrame) blockBorder52);
        blockContainer41.add((org.jfree.chart.block.Block) blockContainer47);
        java.awt.Graphics2D graphics2D55 = null;
        org.jfree.chart.util.Size2D size2D56 = blockContainer47.arrange(graphics2D55);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor59 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D60 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D56, (double) '#', (double) 1.0f, rectangleAnchor59);
        plotRenderingInfo38.setPlotArea(rectangle2D60);
        statisticalLineAndShapeRenderer0.drawRangeMarker(graphics2D12, categoryPlot13, (org.jfree.chart.axis.ValueAxis) numberAxis15, marker28, rectangle2D60);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity63 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D60);
        org.jfree.chart.plot.CategoryPlot categoryPlot64 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis66 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis66.setInverted(true);
        boolean boolean69 = numberAxis66.isAxisLineVisible();
        boolean boolean70 = numberAxis66.getAutoRangeStickyZero();
        java.awt.Stroke stroke71 = numberAxis66.getAxisLineStroke();
        categoryPlot64.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis66);
        java.awt.Stroke stroke73 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot64.setRangeCrosshairStroke(stroke73);
        boolean boolean75 = legendItemEntity63.equals((java.lang.Object) categoryPlot64);
        java.awt.Stroke stroke76 = categoryPlot64.getRangeGridlineStroke();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(textBlock26);
        org.junit.Assert.assertNull(range30);
        org.junit.Assert.assertNotNull(size2D56);
        org.junit.Assert.assertNotNull(rectangleAnchor59);
        org.junit.Assert.assertNotNull(rectangle2D60);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNotNull(stroke71);
        org.junit.Assert.assertNotNull(stroke73);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(stroke76);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean1 = statisticalLineAndShapeRenderer0.getDrawOutlines();
        statisticalLineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(false);
        boolean boolean4 = statisticalLineAndShapeRenderer0.getBaseSeriesVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list2 = defaultCategoryDataset1.getRowKeys();
        org.jfree.data.KeyToGroupMap keyToGroupMap3 = new org.jfree.data.KeyToGroupMap();
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1, keyToGroupMap3);
        boolean boolean5 = rectangleAnchor0.equals((java.lang.Object) range4);
        java.awt.Font font7 = null;
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.jfree.chart.text.TextMeasurer textMeasurer10 = null;
        org.jfree.chart.text.TextBlock textBlock11 = org.jfree.chart.text.TextUtilities.createTextBlock("", font7, (java.awt.Paint) color8, (float) ' ', textMeasurer10);
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D13 = new org.jfree.chart.plot.PiePlot3D(pieDataset12);
        piePlot3D13.setDepthFactor((double) (byte) 1);
        piePlot3D13.setDepthFactor(0.0d);
        java.awt.Stroke stroke18 = piePlot3D13.getLabelLinkStroke();
        boolean boolean19 = textBlock11.equals((java.lang.Object) stroke18);
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor23 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        textBlock11.draw(graphics2D20, (float) (-1), (float) (-1L), textBlockAnchor23);
        java.lang.String str25 = textBlockAnchor23.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition26 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor23);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor27 = categoryLabelPosition26.getCategoryAnchor();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(textBlock11);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "TextBlockAnchor.TOP_CENTER" + "'", str25.equals("TextBlockAnchor.TOP_CENTER"));
        org.junit.Assert.assertNotNull(rectangleAnchor27);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer0.setDrawOutlines(true);
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer0.setBasePaint((java.awt.Paint) color3, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = statisticalLineAndShapeRenderer0.getSeriesNegativeItemLabelPosition(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = null;
        try {
            statisticalLineAndShapeRenderer0.setSeriesPositiveItemLabelPosition((-16744320), itemLabelPosition9, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("");
        taskSeries1.fireSeriesChanged();
        boolean boolean3 = taskSeries1.getNotify();
        taskSeries1.setNotify(false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer1 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean2 = statisticalLineAndShapeRenderer1.getDrawOutlines();
        statisticalLineAndShapeRenderer1.setAutoPopulateSeriesFillPaint(false);
        java.awt.Stroke stroke6 = statisticalLineAndShapeRenderer1.lookupSeriesStroke(28);
        lineAndShapeRenderer0.setBaseStroke(stroke6);
        lineAndShapeRenderer0.setSeriesItemLabelsVisible(28, (java.lang.Boolean) true);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer12 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean13 = statisticalLineAndShapeRenderer12.getDrawOutlines();
        statisticalLineAndShapeRenderer12.setAutoPopulateSeriesFillPaint(false);
        java.awt.Stroke stroke17 = statisticalLineAndShapeRenderer12.lookupSeriesStroke(28);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer20 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean21 = statisticalLineAndShapeRenderer20.getDrawOutlines();
        statisticalLineAndShapeRenderer20.setAutoPopulateSeriesFillPaint(false);
        java.awt.Stroke stroke25 = statisticalLineAndShapeRenderer20.lookupSeriesStroke(28);
        lineAndShapeRenderer19.setBaseStroke(stroke25);
        java.awt.Paint paint28 = lineAndShapeRenderer19.getSeriesFillPaint((int) '#');
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator33 = new org.jfree.chart.urls.StandardCategoryURLGenerator("", "({0}, {1}) = {3} - {4}", "{0}");
        lineAndShapeRenderer19.setSeriesURLGenerator(2, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator33, true);
        statisticalLineAndShapeRenderer12.setSeriesURLGenerator(8, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator33, true);
        try {
            lineAndShapeRenderer0.setSeriesURLGenerator((int) (short) -1, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator33, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNull(paint28);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        ringPlot1.setSeparatorsVisible(false);
        double double4 = ringPlot1.getMinimumArcAngleToDraw();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-5d + "'", double4 == 1.0E-5d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.DESCENDING;
        java.lang.String str1 = sortOrder0.toString();
        java.lang.String str2 = sortOrder0.toString();
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SortOrder.DESCENDING" + "'", str1.equals("SortOrder.DESCENDING"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SortOrder.DESCENDING" + "'", str2.equals("SortOrder.DESCENDING"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.Range range4 = numberAxis3.getDefaultAutoRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint(range4, (double) (-1L));
        org.jfree.data.Range range7 = org.jfree.data.Range.combine(range1, range4);
        org.jfree.data.Range range8 = null;
        org.jfree.data.Range range9 = org.jfree.data.Range.combine(range7, range8);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.Range range12 = numberAxis11.getDefaultAutoRange();
        double double13 = range12.getCentralValue();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint(range9, range12);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType15 = org.jfree.chart.block.LengthConstraintType.RANGE;
        java.lang.String str16 = lengthConstraintType15.toString();
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.Range range20 = numberAxis19.getDefaultAutoRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType21 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = new org.jfree.chart.block.RectangleConstraint((double) (short) -1, range12, lengthConstraintType15, 1.0d, range20, lengthConstraintType21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'heightType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.5d + "'", double13 == 0.5d);
        org.junit.Assert.assertNotNull(lengthConstraintType15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "RectangleConstraintType.RANGE" + "'", str16.equals("RectangleConstraintType.RANGE"));
        org.junit.Assert.assertNotNull(range20);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder11 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer6.setFrame((org.jfree.chart.block.BlockFrame) blockBorder11);
        blockContainer0.add((org.jfree.chart.block.Block) blockContainer6);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.util.Size2D size2D15 = blockContainer6.arrange(graphics2D14);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D19 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D15, (double) '#', (double) 1.0f, rectangleAnchor18);
        double double20 = size2D15.height;
        double double21 = size2D15.height;
        double double22 = size2D15.width;
        org.junit.Assert.assertNotNull(size2D15);
        org.junit.Assert.assertNotNull(rectangleAnchor18);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 36.0d + "'", double20 == 36.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 36.0d + "'", double21 == 36.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.renderer.category.LayeredBarRenderer layeredBarRenderer0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
        layeredBarRenderer0.setSeriesBarWidth(11, (double) (-62125372800001L));
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer5 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer5.setDrawOutlines(true);
        java.awt.Paint paint8 = statisticalLineAndShapeRenderer5.getBasePaint();
        layeredBarRenderer0.setSeriesOutlinePaint((int) ' ', paint8, false);
        java.awt.Stroke stroke11 = layeredBarRenderer0.getBaseStroke();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset16 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset16);
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer20 = null;
        org.jfree.chart.plot.PolarPlot polarPlot21 = new org.jfree.chart.plot.PolarPlot(xYDataset18, valueAxis19, polarItemRenderer20);
        defaultCategoryDataset16.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot21);
        int int23 = defaultCategoryDataset16.getColumnCount();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D24.clearCategoryLabelToolTips();
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer29 = null;
        org.jfree.chart.plot.PolarPlot polarPlot30 = new org.jfree.chart.plot.PolarPlot(xYDataset26, (org.jfree.chart.axis.ValueAxis) numberAxis28, polarItemRenderer29);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer31 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer32 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean33 = statisticalLineAndShapeRenderer32.getDrawOutlines();
        statisticalLineAndShapeRenderer32.setAutoPopulateSeriesFillPaint(false);
        java.awt.Stroke stroke37 = statisticalLineAndShapeRenderer32.lookupSeriesStroke(28);
        lineAndShapeRenderer31.setBaseStroke(stroke37);
        java.awt.Paint paint40 = lineAndShapeRenderer31.getSeriesFillPaint((int) '#');
        java.awt.Stroke stroke43 = lineAndShapeRenderer31.getItemOutlineStroke(1, 10);
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset16, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D24, (org.jfree.chart.axis.ValueAxis) numberAxis28, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer31);
        org.jfree.chart.axis.NumberAxis numberAxis46 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand47 = numberAxis46.getMarkerBand();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand48 = numberAxis46.getMarkerBand();
        java.lang.String str49 = numberAxis46.getLabel();
        org.jfree.data.category.CategoryDataset categoryDataset50 = null;
        try {
            layeredBarRenderer0.drawItem(graphics2D12, categoryItemRendererState13, rectangle2D14, categoryPlot15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D24, (org.jfree.chart.axis.ValueAxis) numberAxis46, categoryDataset50, (int) (short) 1, 11, 2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNull(paint40);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNull(markerAxisBand47);
        org.junit.Assert.assertNull(markerAxisBand48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "hi!" + "'", str49.equals("hi!"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.renderer.category.LayeredBarRenderer layeredBarRenderer0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
        layeredBarRenderer0.setSeriesBarWidth(11, (double) (-62125372800001L));
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer5 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer5.setDrawOutlines(true);
        java.awt.Paint paint8 = statisticalLineAndShapeRenderer5.getBasePaint();
        layeredBarRenderer0.setSeriesOutlinePaint((int) ' ', paint8, false);
        double double12 = layeredBarRenderer0.getSeriesBarWidth(0);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer1 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean2 = statisticalLineAndShapeRenderer1.getDrawOutlines();
        statisticalLineAndShapeRenderer1.setAutoPopulateSeriesFillPaint(false);
        java.awt.Stroke stroke6 = statisticalLineAndShapeRenderer1.lookupSeriesStroke(28);
        lineAndShapeRenderer0.setBaseStroke(stroke6);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator8 = lineAndShapeRenderer0.getLegendItemLabelGenerator();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator8);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("PlotOrientation.HORIZONTAL");
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean1 = statisticalLineAndShapeRenderer0.getDrawOutlines();
        statisticalLineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(false);
        java.lang.Object obj4 = statisticalLineAndShapeRenderer0.clone();
        java.awt.Stroke stroke5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        statisticalLineAndShapeRenderer0.setBaseStroke(stroke5);
        statisticalLineAndShapeRenderer0.setBaseItemLabelsVisible(false, false);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        statisticalLineAndShapeRenderer0.setBaseFillPaint((java.awt.Paint) color10);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = null;
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font17 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer18 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer18.setDrawOutlines(true);
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer18.setBasePaint((java.awt.Paint) color21, false);
        org.jfree.chart.text.TextMeasurer textMeasurer25 = null;
        org.jfree.chart.text.TextBlock textBlock26 = org.jfree.chart.text.TextUtilities.createTextBlock("", font17, (java.awt.Paint) color21, (float) (byte) -1, textMeasurer25);
        numberAxis15.setTickMarkPaint((java.awt.Paint) color21);
        org.jfree.chart.plot.Marker marker28 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset29 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset29);
        org.jfree.data.xy.XYDataset xYDataset31 = null;
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer33 = null;
        org.jfree.chart.plot.PolarPlot polarPlot34 = new org.jfree.chart.plot.PolarPlot(xYDataset31, valueAxis32, polarItemRenderer33);
        defaultCategoryDataset29.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot34);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo37 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo37);
        java.awt.geom.Point2D point2D39 = null;
        polarPlot34.zoomDomainAxes((double) '#', plotRenderingInfo38, point2D39);
        org.jfree.chart.block.BlockContainer blockContainer41 = new org.jfree.chart.block.BlockContainer();
        blockContainer41.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer47 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder52 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer47.setFrame((org.jfree.chart.block.BlockFrame) blockBorder52);
        blockContainer41.add((org.jfree.chart.block.Block) blockContainer47);
        java.awt.Graphics2D graphics2D55 = null;
        org.jfree.chart.util.Size2D size2D56 = blockContainer47.arrange(graphics2D55);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor59 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D60 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D56, (double) '#', (double) 1.0f, rectangleAnchor59);
        plotRenderingInfo38.setPlotArea(rectangle2D60);
        statisticalLineAndShapeRenderer0.drawRangeMarker(graphics2D12, categoryPlot13, (org.jfree.chart.axis.ValueAxis) numberAxis15, marker28, rectangle2D60);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity63 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D60);
        java.lang.String str64 = legendItemEntity63.toString();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(textBlock26);
        org.junit.Assert.assertNull(range30);
        org.junit.Assert.assertNotNull(size2D56);
        org.junit.Assert.assertNotNull(rectangleAnchor59);
        org.junit.Assert.assertNotNull(rectangle2D60);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null" + "'", str64.equals("LegendItemEntity: seriesKey=null, dataset=null"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(4, 0);
        int int3 = month2.getMonth();
        int int4 = month2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month2.next();
        long long6 = month2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62125372800001L) + "'", long6 == (-62125372800001L));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean1 = statisticalLineAndShapeRenderer0.getDrawOutlines();
        boolean boolean2 = statisticalLineAndShapeRenderer0.getUseOutlinePaint();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(3, 5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis2.setInverted(true);
        boolean boolean5 = numberAxis2.isAxisLineVisible();
        boolean boolean6 = numberAxis2.getAutoRangeStickyZero();
        java.awt.Stroke stroke7 = numberAxis2.getAxisLineStroke();
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis2);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer9 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean10 = statisticalLineAndShapeRenderer9.getDrawOutlines();
        statisticalLineAndShapeRenderer9.setAutoPopulateSeriesFillPaint(false);
        java.lang.Object obj13 = statisticalLineAndShapeRenderer9.clone();
        java.awt.Stroke stroke14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        statisticalLineAndShapeRenderer9.setBaseStroke(stroke14);
        boolean boolean18 = statisticalLineAndShapeRenderer9.getItemShapeVisible((int) '4', (int) (byte) 10);
        java.awt.Font font20 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        statisticalLineAndShapeRenderer9.setSeriesItemLabelFont((int) 'a', font20);
        java.awt.Paint paint22 = statisticalLineAndShapeRenderer9.getErrorIndicatorPaint();
        int int23 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer9);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer24 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean25 = statisticalLineAndShapeRenderer24.getDrawOutlines();
        int int26 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer24);
        org.jfree.chart.plot.Marker marker27 = null;
        try {
            categoryPlot0.addRangeMarker(marker27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNull(paint22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) (-1));
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset2 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list3 = defaultCategoryDataset2.getRowKeys();
        axisState1.setTicks(list3);
        org.junit.Assert.assertNotNull(list3);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis2.setInverted(true);
        boolean boolean5 = numberAxis2.isAxisLineVisible();
        boolean boolean6 = numberAxis2.getAutoRangeStickyZero();
        java.awt.Stroke stroke7 = numberAxis2.getAxisLineStroke();
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis2);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer9 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean10 = statisticalLineAndShapeRenderer9.getDrawOutlines();
        statisticalLineAndShapeRenderer9.setAutoPopulateSeriesFillPaint(false);
        java.lang.Object obj13 = statisticalLineAndShapeRenderer9.clone();
        java.awt.Stroke stroke14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        statisticalLineAndShapeRenderer9.setBaseStroke(stroke14);
        boolean boolean18 = statisticalLineAndShapeRenderer9.getItemShapeVisible((int) '4', (int) (byte) 10);
        java.awt.Font font20 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        statisticalLineAndShapeRenderer9.setSeriesItemLabelFont((int) 'a', font20);
        java.awt.Paint paint22 = statisticalLineAndShapeRenderer9.getErrorIndicatorPaint();
        int int23 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer9);
        org.jfree.chart.util.SortOrder sortOrder24 = categoryPlot0.getColumnRenderingOrder();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNull(paint22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(sortOrder24);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.lang.Object obj1 = shapeList0.clone();
        java.awt.Shape shape3 = null;
        shapeList0.setShape(0, shape3);
        java.awt.Font font7 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer8 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer8.setDrawOutlines(true);
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer8.setBasePaint((java.awt.Paint) color11, false);
        org.jfree.chart.text.TextMeasurer textMeasurer15 = null;
        org.jfree.chart.text.TextBlock textBlock16 = org.jfree.chart.text.TextUtilities.createTextBlock("", font7, (java.awt.Paint) color11, (float) (byte) -1, textMeasurer15);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor20 = null;
        java.awt.Shape shape24 = textBlock16.calculateBounds(graphics2D17, (float) 1, 100.0f, textBlockAnchor20, (float) 3, (float) (short) -1, (double) 0);
        java.awt.Shape shape27 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape24, (double) (-1.0f), 3.0d);
        shapeList0.setShape((int) (short) 0, shape24);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(textBlock16);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(shape27);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.renderer.OutlierListCollection outlierListCollection0 = new org.jfree.chart.renderer.OutlierListCollection();
        java.util.Iterator iterator1 = outlierListCollection0.iterator();
        org.jfree.chart.renderer.Outlier outlier2 = null;
        boolean boolean3 = outlierListCollection0.add(outlier2);
        org.junit.Assert.assertNotNull(iterator1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("EXPAND", "", "", "EXPAND");
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D6 = new org.jfree.chart.plot.PiePlot3D(pieDataset5);
        java.awt.Font font7 = piePlot3D6.getLabelFont();
        boolean boolean8 = library4.equals((java.lang.Object) piePlot3D6);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer9 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean10 = statisticalLineAndShapeRenderer9.getDrawOutlines();
        statisticalLineAndShapeRenderer9.setAutoPopulateSeriesFillPaint(false);
        java.awt.Stroke stroke14 = statisticalLineAndShapeRenderer9.lookupSeriesStroke(28);
        boolean boolean15 = library4.equals((java.lang.Object) stroke14);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement0.clear();
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle();
        boolean boolean3 = textTitle2.getExpandToFitSpace();
        textTitle2.setURLText("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        org.jfree.chart.renderer.OutlierListCollection outlierListCollection6 = new org.jfree.chart.renderer.OutlierListCollection();
        flowArrangement0.add((org.jfree.chart.block.Block) textTitle2, (java.lang.Object) outlierListCollection6);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDepthFactor((double) (byte) 1);
        piePlot3D1.setDepthFactor(0.0d);
        java.awt.Stroke[] strokeArray6 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        boolean boolean7 = piePlot3D1.equals((java.lang.Object) strokeArray6);
        java.awt.Paint paint8 = piePlot3D1.getLabelShadowPaint();
        java.awt.Paint paint9 = piePlot3D1.getLabelBackgroundPaint();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = piePlot3D1.getLegendItems();
        java.lang.Object obj11 = null;
        boolean boolean12 = piePlot3D1.equals(obj11);
        org.junit.Assert.assertNotNull(strokeArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        int int2 = xYPlot0.indexOf(xYDataset1);
        org.jfree.chart.util.Layer layer4 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(6, layer4);
        org.jfree.chart.axis.AxisSpace axisSpace6 = xYPlot0.getFixedRangeAxisSpace();
        xYPlot0.clearDomainAxes();
        xYPlot0.setRangeCrosshairValue((double) (-1.0f), true);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = xYPlot0.getRenderer();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(layer4);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNull(axisSpace6);
        org.junit.Assert.assertNull(xYItemRenderer11);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues0.removeValue((java.lang.Comparable) "EXPAND");
        java.awt.Font font4 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer5 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer5.setDrawOutlines(true);
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer5.setBasePaint((java.awt.Paint) color8, false);
        org.jfree.chart.text.TextMeasurer textMeasurer12 = null;
        org.jfree.chart.text.TextBlock textBlock13 = org.jfree.chart.text.TextUtilities.createTextBlock("", font4, (java.awt.Paint) color8, (float) (byte) -1, textMeasurer12);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor17 = null;
        java.awt.Shape shape21 = textBlock13.calculateBounds(graphics2D14, (float) 1, 100.0f, textBlockAnchor17, (float) 3, (float) (short) -1, (double) 0);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset24 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range25 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset24);
        org.jfree.data.Range range26 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset24);
        java.lang.Comparable comparable27 = null;
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity29 = new org.jfree.chart.entity.CategoryItemEntity(shape21, "{0}", "EXPAND", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset24, comparable27, (java.lang.Comparable) 1.0d);
        org.jfree.chart.util.SortOrder sortOrder30 = org.jfree.chart.util.SortOrder.DESCENDING;
        boolean boolean31 = categoryItemEntity29.equals((java.lang.Object) sortOrder30);
        defaultKeyedValues0.sortByValues(sortOrder30);
        defaultKeyedValues0.clear();
        defaultKeyedValues0.removeValue((java.lang.Comparable) 10L);
        try {
            java.lang.Number number37 = defaultKeyedValues0.getValue(255);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 255, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(textBlock13);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertNull(range26);
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        boolean boolean1 = textTitle0.getExpandToFitSpace();
        textTitle0.setNotify(false);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.data.Range range6 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean8 = range6.contains((double) 2);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint(0.0d, range6);
        org.jfree.chart.block.BlockContainer blockContainer10 = new org.jfree.chart.block.BlockContainer();
        blockContainer10.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer16 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder21 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer16.setFrame((org.jfree.chart.block.BlockFrame) blockBorder21);
        blockContainer10.add((org.jfree.chart.block.Block) blockContainer16);
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.util.Size2D size2D25 = blockContainer16.arrange(graphics2D24);
        org.jfree.chart.util.Size2D size2D26 = rectangleConstraint9.calculateConstrainedSize(size2D25);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint28 = rectangleConstraint9.toFixedHeight((double) 6);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint29 = rectangleConstraint9.toUnconstrainedHeight();
        try {
            org.jfree.chart.util.Size2D size2D30 = textTitle0.arrange(graphics2D4, rectangleConstraint9);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(size2D25);
        org.junit.Assert.assertNotNull(size2D26);
        org.junit.Assert.assertNotNull(rectangleConstraint28);
        org.junit.Assert.assertNotNull(rectangleConstraint29);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, polarItemRenderer3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = polarPlot4.getRenderer();
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) numberAxis8, polarItemRenderer9);
        org.jfree.data.general.DatasetGroup datasetGroup11 = polarPlot10.getDatasetGroup();
        java.awt.Paint paint12 = polarPlot10.getAngleGridlinePaint();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer13 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean14 = statisticalLineAndShapeRenderer13.getDrawOutlines();
        statisticalLineAndShapeRenderer13.setAutoPopulateSeriesFillPaint(false);
        java.awt.Stroke stroke18 = statisticalLineAndShapeRenderer13.lookupSeriesStroke(28);
        polarPlot10.setRadiusGridlineStroke(stroke18);
        polarPlot4.setRadiusGridlineStroke(stroke18);
        org.junit.Assert.assertNull(polarItemRenderer5);
        org.junit.Assert.assertNull(datasetGroup11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(255);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (255) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        java.awt.Font font1 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer2.setDrawOutlines(true);
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer2.setBasePaint((java.awt.Paint) color5, false);
        org.jfree.chart.text.TextMeasurer textMeasurer9 = null;
        org.jfree.chart.text.TextBlock textBlock10 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color5, (float) (byte) -1, textMeasurer9);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor14 = null;
        java.awt.Shape shape18 = textBlock10.calculateBounds(graphics2D11, (float) 1, 100.0f, textBlockAnchor14, (float) 3, (float) (short) -1, (double) 0);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset21 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range22 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset21);
        org.jfree.data.Range range23 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset21);
        java.lang.Comparable comparable24 = null;
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity26 = new org.jfree.chart.entity.CategoryItemEntity(shape18, "{0}", "EXPAND", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset21, comparable24, (java.lang.Comparable) 1.0d);
        java.lang.String str27 = categoryItemEntity26.getURLText();
        java.lang.Comparable comparable28 = categoryItemEntity26.getColumnKey();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(textBlock10);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNull(range22);
        org.junit.Assert.assertNull(range23);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "EXPAND" + "'", str27.equals("EXPAND"));
        org.junit.Assert.assertTrue("'" + comparable28 + "' != '" + 1.0d + "'", comparable28.equals(1.0d));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long1 = segmentedTimeline0.getStartTime();
        int int2 = segmentedTimeline0.getSegmentsIncluded();
        long long5 = segmentedTimeline0.getExceptionSegmentCount(0L, (-1L));
        segmentedTimeline0.setAdjustForDaylightSaving(true);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline9 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long10 = segmentedTimeline9.getStartTime();
        int int11 = segmentedTimeline9.getSegmentsIncluded();
        long long14 = segmentedTimeline9.getExceptionSegmentCount(0L, (-1L));
        long long15 = segmentedTimeline9.getSegmentsGroupSize();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(4, 0);
        java.util.Date date19 = month18.getEnd();
        long long20 = segmentedTimeline9.getTime(date19);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date19);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(4, 0);
        java.util.Date date25 = month24.getEnd();
        org.jfree.data.gantt.Task task26 = new org.jfree.data.gantt.Task("", date19, date25);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline27 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long28 = segmentedTimeline27.getStartTime();
        int int29 = segmentedTimeline27.getSegmentsIncluded();
        long long32 = segmentedTimeline27.getExceptionSegmentCount(0L, (-1L));
        long long33 = segmentedTimeline27.getSegmentsGroupSize();
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month(4, 0);
        java.util.Date date37 = month36.getEnd();
        long long38 = segmentedTimeline27.getTime(date37);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date19, date37);
        long long40 = segmentedTimeline0.getTime(date37);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-2208927600000L) + "'", long1 == (-2208927600000L));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28 + "'", int2 == 28);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(segmentedTimeline9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-2208927600000L) + "'", long10 == (-2208927600000L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 28 + "'", int11 == 28);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 86400000L + "'", long15 == 86400000L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-62125372800001L) + "'", long20 == (-62125372800001L));
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(segmentedTimeline27);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-2208927600000L) + "'", long28 == (-2208927600000L));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 28 + "'", int29 == 28);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 86400000L + "'", long33 == 86400000L);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-62125372800001L) + "'", long38 == (-62125372800001L));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-62125372800001L) + "'", long40 == (-62125372800001L));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset3 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset3);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset5, valueAxis6, polarItemRenderer7);
        defaultCategoryDataset3.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot8);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo11);
        java.awt.geom.Point2D point2D13 = null;
        polarPlot8.zoomDomainAxes((double) '#', plotRenderingInfo12, point2D13);
        org.jfree.chart.block.BlockContainer blockContainer15 = new org.jfree.chart.block.BlockContainer();
        blockContainer15.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer21 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder26 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer21.setFrame((org.jfree.chart.block.BlockFrame) blockBorder26);
        blockContainer15.add((org.jfree.chart.block.Block) blockContainer21);
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.util.Size2D size2D30 = blockContainer21.arrange(graphics2D29);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D34 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D30, (double) '#', (double) 1.0f, rectangleAnchor33);
        plotRenderingInfo12.setPlotArea(rectangle2D34);
        categoryPlot0.handleClick(0, 0, plotRenderingInfo12);
        org.jfree.chart.util.Layer layer38 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection39 = categoryPlot0.getRangeMarkers(0, layer38);
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis43.setInverted(true);
        boolean boolean46 = numberAxis43.isAxisLineVisible();
        boolean boolean47 = numberAxis43.getAutoRangeStickyZero();
        java.awt.Stroke stroke48 = numberAxis43.getAxisLineStroke();
        categoryPlot41.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis43);
        org.jfree.chart.axis.AxisLocation axisLocation51 = categoryPlot41.getRangeAxisLocation(0);
        categoryPlot0.setDomainAxisLocation((int) (short) 0, axisLocation51);
        org.jfree.chart.util.SortOrder sortOrder53 = categoryPlot0.getRowRenderingOrder();
        org.jfree.chart.axis.NumberAxis numberAxis55 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis55.setInverted(true);
        boolean boolean58 = numberAxis55.isAxisLineVisible();
        boolean boolean59 = numberAxis55.getAutoRangeStickyZero();
        boolean boolean60 = categoryPlot0.equals((java.lang.Object) boolean59);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNotNull(size2D30);
        org.junit.Assert.assertNotNull(rectangleAnchor33);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNotNull(layer38);
        org.junit.Assert.assertNull(collection39);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(axisLocation51);
        org.junit.Assert.assertNotNull(sortOrder53);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        ganttRenderer0.setSeriesOutlineStroke(15, stroke2);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.junit.Assert.assertNotNull(plotOrientation0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double3 = rectangleInsets1.calculateBottomOutset((double) 'a');
        textTitle0.setPadding(rectangleInsets1);
        java.lang.String str5 = textTitle0.getToolTipText();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean1 = statisticalLineAndShapeRenderer0.getDrawOutlines();
        statisticalLineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(false);
        java.lang.Object obj4 = statisticalLineAndShapeRenderer0.clone();
        java.awt.Stroke stroke5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        statisticalLineAndShapeRenderer0.setBaseStroke(stroke5);
        statisticalLineAndShapeRenderer0.setBaseItemLabelsVisible(false, false);
        boolean boolean12 = statisticalLineAndShapeRenderer0.getItemLineVisible(31, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font3 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer4 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer4.setDrawOutlines(true);
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer4.setBasePaint((java.awt.Paint) color7, false);
        org.jfree.chart.text.TextMeasurer textMeasurer11 = null;
        org.jfree.chart.text.TextBlock textBlock12 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, (java.awt.Paint) color7, (float) (byte) -1, textMeasurer11);
        numberAxis1.setTickMarkPaint((java.awt.Paint) color7);
        numberAxis1.setAutoRange(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double18 = rectangleInsets16.calculateBottomOutset((double) 'a');
        double double19 = rectangleInsets16.getRight();
        numberAxis1.setTickLabelInsets(rectangleInsets16);
        java.awt.Font font25 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand26 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis1, 1.0E-5d, 0.0d, (double) ' ', 0.0d, font25);
        java.awt.Graphics2D graphics2D27 = null;
        double double28 = markerAxisBand26.getHeight(graphics2D27);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(textBlock12);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis2.setInverted(true);
        boolean boolean5 = numberAxis2.isAxisLineVisible();
        boolean boolean6 = numberAxis2.getAutoRangeStickyZero();
        java.awt.Stroke stroke7 = numberAxis2.getAxisLineStroke();
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis2);
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot0.getRangeAxisLocation(0);
        categoryPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer13 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean14 = statisticalLineAndShapeRenderer13.getDrawOutlines();
        statisticalLineAndShapeRenderer13.setAutoPopulateSeriesFillPaint(false);
        java.awt.Stroke stroke18 = statisticalLineAndShapeRenderer13.lookupSeriesStroke(28);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = statisticalLineAndShapeRenderer13.getBaseNegativeItemLabelPosition();
        org.jfree.data.general.PieDataset pieDataset20 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D21 = new org.jfree.chart.plot.PiePlot3D(pieDataset20);
        piePlot3D21.setDepthFactor((double) (byte) 1);
        piePlot3D21.setDepthFactor(0.0d);
        java.awt.Stroke stroke26 = piePlot3D21.getLabelLinkStroke();
        double double27 = piePlot3D21.getShadowXOffset();
        java.lang.String str28 = piePlot3D21.getNoDataMessage();
        java.awt.Paint paint29 = piePlot3D21.getBaseSectionOutlinePaint();
        org.jfree.data.general.PieDataset pieDataset30 = null;
        piePlot3D21.setDataset(pieDataset30);
        java.awt.Stroke stroke32 = piePlot3D21.getBaseSectionOutlineStroke();
        statisticalLineAndShapeRenderer13.setBaseStroke(stroke32, true);
        java.awt.Shape shape36 = statisticalLineAndShapeRenderer13.getSeriesShape((int) (short) 0);
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer13, true);
        org.jfree.chart.plot.Marker marker40 = null;
        org.jfree.chart.plot.XYPlot xYPlot41 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset42 = null;
        int int43 = xYPlot41.indexOf(xYDataset42);
        org.jfree.chart.util.Layer layer45 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection46 = xYPlot41.getRangeMarkers(6, layer45);
        org.jfree.chart.axis.ValueAxis valueAxis48 = xYPlot41.getRangeAxis(2);
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis51 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis51.setInverted(true);
        boolean boolean54 = numberAxis51.isAxisLineVisible();
        boolean boolean55 = numberAxis51.getAutoRangeStickyZero();
        java.awt.Stroke stroke56 = numberAxis51.getAxisLineStroke();
        categoryPlot49.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis51);
        org.jfree.chart.util.RectangleEdge rectangleEdge58 = categoryPlot49.getDomainAxisEdge();
        org.jfree.chart.plot.XYPlot xYPlot59 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset60 = null;
        int int61 = xYPlot59.indexOf(xYDataset60);
        org.jfree.chart.util.Layer layer63 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection64 = xYPlot59.getRangeMarkers(6, layer63);
        java.util.Collection collection65 = categoryPlot49.getDomainMarkers(layer63);
        java.util.Collection collection66 = xYPlot41.getRangeMarkers(layer63);
        try {
            categoryPlot0.addRangeMarker((int) (byte) 100, marker40, layer63);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 4.0d + "'", double27 == 4.0d);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNull(shape36);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(layer45);
        org.junit.Assert.assertNull(collection46);
        org.junit.Assert.assertNull(valueAxis48);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNotNull(rectangleEdge58);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertNotNull(layer63);
        org.junit.Assert.assertNull(collection64);
        org.junit.Assert.assertNull(collection65);
        org.junit.Assert.assertNull(collection66);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font4 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer5 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer5.setDrawOutlines(true);
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer5.setBasePaint((java.awt.Paint) color8, false);
        org.jfree.chart.text.TextMeasurer textMeasurer12 = null;
        org.jfree.chart.text.TextBlock textBlock13 = org.jfree.chart.text.TextUtilities.createTextBlock("", font4, (java.awt.Paint) color8, (float) (byte) -1, textMeasurer12);
        numberAxis2.setTickMarkPaint((java.awt.Paint) color8);
        boolean boolean15 = numberAxis2.isInverted();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer16 = null;
        org.jfree.chart.plot.PolarPlot polarPlot17 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, polarItemRenderer16);
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        try {
            java.awt.Point point21 = polarPlot17.translateValueThetaRadiusToJava2D(0.35d, (double) (-62125372800001L), rectangle2D20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(textBlock13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainCrosshairPaint();
        int int2 = xYPlot0.getSeriesCount();
        java.awt.Paint paint3 = xYPlot0.getRangeZeroBaselinePaint();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        int int5 = xYPlot0.indexOf(xYDataset4);
        boolean boolean6 = xYPlot0.isRangeZoomable();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean1 = statisticalLineAndShapeRenderer0.getDrawOutlines();
        java.awt.Paint paint3 = null;
        statisticalLineAndShapeRenderer0.setSeriesFillPaint(2958465, paint3, true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int1 = dateTickUnit0.getCalendarField();
        int int2 = dateTickUnit0.getCalendarField();
        org.junit.Assert.assertNotNull(dateTickUnit0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer0.setSeriesLinesVisible((int) (short) 10, true);
        java.awt.Stroke stroke5 = statisticalLineAndShapeRenderer0.getSeriesOutlineStroke(0);
        statisticalLineAndShapeRenderer0.setBaseShapesVisible(false);
        org.junit.Assert.assertNull(stroke5);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        int int1 = defaultKeyedValues2D0.getColumnCount();
        java.util.List list2 = defaultKeyedValues2D0.getColumnKeys();
        defaultKeyedValues2D0.clear();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainCrosshairPaint();
        int int2 = xYPlot0.getSeriesCount();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot0.setDatasetRenderingOrder(datasetRenderingOrder3);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray5 = new org.jfree.chart.axis.ValueAxis[] {};
        xYPlot0.setRangeAxes(valueAxisArray5);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(datasetRenderingOrder3);
        org.junit.Assert.assertNotNull(valueAxisArray5);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.data.resources.DataPackageResources dataPackageResources0 = new org.jfree.data.resources.DataPackageResources();
        java.util.Set<java.lang.String> strSet1 = dataPackageResources0.keySet();
        boolean boolean3 = dataPackageResources0.containsKey("{0}");
        try {
            java.lang.Object obj5 = dataPackageResources0.getObject("({0}, {1}) = {3} - {4}");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.data.resources.DataPackageResources, key ({0}, {1}) = {3} - {4}");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(strSet1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset2, valueAxis3, polarItemRenderer4);
        defaultCategoryDataset0.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot5);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D9 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(1.0d, (double) (short) -1);
        boolean boolean10 = stackedBarRenderer3D9.isDrawBarOutline();
        boolean boolean11 = polarPlot5.equals((java.lang.Object) stackedBarRenderer3D9);
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint13 = xYPlot12.getDomainCrosshairPaint();
        xYPlot12.mapDatasetToRangeAxis((int) (byte) 100, 28);
        xYPlot12.setRangeZeroBaselineVisible(false);
        boolean boolean19 = stackedBarRenderer3D9.equals((java.lang.Object) false);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        java.awt.Font font1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color2, (float) ' ', textMeasurer4);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D7 = new org.jfree.chart.plot.PiePlot3D(pieDataset6);
        piePlot3D7.setDepthFactor((double) (byte) 1);
        piePlot3D7.setDepthFactor(0.0d);
        java.awt.Stroke stroke12 = piePlot3D7.getLabelLinkStroke();
        boolean boolean13 = textBlock5.equals((java.lang.Object) stroke12);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor17 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        textBlock5.draw(graphics2D14, (float) (-1), (float) (-1L), textBlockAnchor17);
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double22 = rectangleInsets20.calculateBottomOutset((double) 'a');
        textTitle19.setPadding(rectangleInsets20);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment24 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.data.Range range26 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean28 = range26.contains((double) 2);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint29 = new org.jfree.chart.block.RectangleConstraint(0.0d, range26);
        org.jfree.chart.block.BlockContainer blockContainer30 = new org.jfree.chart.block.BlockContainer();
        blockContainer30.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer36 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder41 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer36.setFrame((org.jfree.chart.block.BlockFrame) blockBorder41);
        blockContainer30.add((org.jfree.chart.block.Block) blockContainer36);
        java.awt.Graphics2D graphics2D44 = null;
        org.jfree.chart.util.Size2D size2D45 = blockContainer36.arrange(graphics2D44);
        org.jfree.chart.util.Size2D size2D46 = rectangleConstraint29.calculateConstrainedSize(size2D45);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint48 = rectangleConstraint29.toFixedWidth((double) 2);
        boolean boolean49 = horizontalAlignment24.equals((java.lang.Object) rectangleConstraint29);
        org.jfree.chart.title.TextTitle textTitle50 = new org.jfree.chart.title.TextTitle();
        boolean boolean51 = textTitle50.getExpandToFitSpace();
        org.jfree.chart.util.VerticalAlignment verticalAlignment52 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        textTitle50.setVerticalAlignment(verticalAlignment52);
        org.jfree.chart.block.FlowArrangement flowArrangement56 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment24, verticalAlignment52, 35.0d, (double) (byte) 100);
        textTitle19.setTextAlignment(horizontalAlignment24);
        textBlock5.setLineAlignment(horizontalAlignment24);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor17);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment24);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(size2D45);
        org.junit.Assert.assertNotNull(size2D46);
        org.junit.Assert.assertNotNull(rectangleConstraint48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(verticalAlignment52);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 100L, 10.0d);
        boolean boolean6 = columnArrangement4.equals((java.lang.Object) 1.0d);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset7 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list8 = defaultCategoryDataset7.getRowKeys();
        boolean boolean9 = columnArrangement4.equals((java.lang.Object) list8);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.renderer.category.LayeredBarRenderer layeredBarRenderer0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
        layeredBarRenderer0.setSeriesBarWidth(11, (double) (-62125372800001L));
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer5 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer5.setDrawOutlines(true);
        java.awt.Paint paint8 = statisticalLineAndShapeRenderer5.getBasePaint();
        layeredBarRenderer0.setSeriesOutlinePaint((int) ' ', paint8, false);
        double double12 = layeredBarRenderer0.getSeriesBarWidth((int) '#');
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean3 = range1.contains((double) 2);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = new org.jfree.chart.block.RectangleConstraint(0.0d, range1);
        boolean boolean7 = range1.intersects((double) 'a', (double) (byte) 100);
        org.jfree.data.Range range9 = org.jfree.data.Range.shift(range1, (double) 8);
        org.jfree.data.Range range12 = org.jfree.data.Range.shift(range9, 2.0d, true);
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(range12);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("Range[0.0,1.0]");
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDepthFactor((double) (byte) 1);
        int int4 = piePlot3D1.getPieIndex();
        boolean boolean5 = piePlot3D1.getIgnoreNullValues();
        boolean boolean6 = piePlot3D1.getSectionOutlinesVisible();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("SortOrder.DESCENDING", timeZone1);
        try {
            dateAxis2.setRange((double) 28, (double) 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("SortOrder.DESCENDING", timeZone1);
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = dateAxis2.getTickUnit();
        int int4 = dateTickUnit3.getRollCount();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font4 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer5 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer5.setDrawOutlines(true);
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer5.setBasePaint((java.awt.Paint) color8, false);
        org.jfree.chart.text.TextMeasurer textMeasurer12 = null;
        org.jfree.chart.text.TextBlock textBlock13 = org.jfree.chart.text.TextUtilities.createTextBlock("", font4, (java.awt.Paint) color8, (float) (byte) -1, textMeasurer12);
        numberAxis2.setTickMarkPaint((java.awt.Paint) color8);
        boolean boolean15 = numberAxis2.isInverted();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer16 = null;
        org.jfree.chart.plot.PolarPlot polarPlot17 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, polarItemRenderer16);
        numberAxis2.zoomRange((double) (-1.0f), (double) (short) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = numberAxis2.getLabelInsets();
        double double22 = numberAxis2.getLowerBound();
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(textBlock13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + (-1.05d) + "'", double22 == (-1.05d));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDepthFactor((double) (byte) 1);
        piePlot3D1.setDepthFactor(0.0d);
        java.awt.Stroke[] strokeArray6 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        boolean boolean7 = piePlot3D1.equals((java.lang.Object) strokeArray6);
        java.awt.Paint paint8 = piePlot3D1.getLabelShadowPaint();
        float float9 = piePlot3D1.getBackgroundImageAlpha();
        org.junit.Assert.assertNotNull(strokeArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.5f + "'", float9 == 0.5f);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        boolean boolean2 = categoryAxis3D0.equals((java.lang.Object) textAnchor1);
        categoryAxis3D0.setMaximumCategoryLabelWidthRatio((float) 60000L);
        categoryAxis3D0.setFixedDimension(0.2d);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D7 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions9 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((double) (byte) 100);
        categoryAxis3D7.setCategoryLabelPositions(categoryLabelPositions9);
        categoryAxis3D0.setCategoryLabelPositions(categoryLabelPositions9);
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions9);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDepthFactor((double) (byte) 1);
        piePlot3D1.setDepthFactor(0.0d);
        java.awt.Stroke[] strokeArray6 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        boolean boolean7 = piePlot3D1.equals((java.lang.Object) strokeArray6);
        java.awt.Paint paint8 = piePlot3D1.getLabelShadowPaint();
        java.awt.Paint paint9 = piePlot3D1.getLabelBackgroundPaint();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = piePlot3D1.getLegendItems();
        java.lang.Object obj11 = legendItemCollection10.clone();
        org.junit.Assert.assertNotNull(strokeArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        ringPlot1.setSectionDepth(10.0d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean1 = statisticalLineAndShapeRenderer0.getDrawOutlines();
        statisticalLineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(false);
        java.awt.Stroke stroke5 = statisticalLineAndShapeRenderer0.lookupSeriesStroke(28);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = statisticalLineAndShapeRenderer0.getBaseNegativeItemLabelPosition();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D(pieDataset7);
        piePlot3D8.setDepthFactor((double) (byte) 1);
        piePlot3D8.setDepthFactor(0.0d);
        java.awt.Stroke stroke13 = piePlot3D8.getLabelLinkStroke();
        double double14 = piePlot3D8.getShadowXOffset();
        java.lang.String str15 = piePlot3D8.getNoDataMessage();
        java.awt.Paint paint16 = piePlot3D8.getBaseSectionOutlinePaint();
        org.jfree.data.general.PieDataset pieDataset17 = null;
        piePlot3D8.setDataset(pieDataset17);
        java.awt.Stroke stroke19 = piePlot3D8.getBaseSectionOutlineStroke();
        statisticalLineAndShapeRenderer0.setBaseStroke(stroke19, true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent22 = null;
        statisticalLineAndShapeRenderer0.notifyListeners(rendererChangeEvent22);
        java.awt.Font font25 = null;
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer29 = null;
        org.jfree.chart.plot.PolarPlot polarPlot30 = new org.jfree.chart.plot.PolarPlot(xYDataset26, (org.jfree.chart.axis.ValueAxis) numberAxis28, polarItemRenderer29);
        float float31 = polarPlot30.getBackgroundAlpha();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer32 = polarPlot30.getRenderer();
        org.jfree.chart.JFreeChart jFreeChart34 = new org.jfree.chart.JFreeChart("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font25, (org.jfree.chart.plot.Plot) polarPlot30, false);
        jFreeChart34.setTitle("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]");
        java.awt.Image image37 = null;
        jFreeChart34.setBackgroundImage(image37);
        org.jfree.chart.title.TextTitle textTitle39 = null;
        jFreeChart34.setTitle(textTitle39);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent43 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) statisticalLineAndShapeRenderer0, jFreeChart34, 2, (int) (byte) 0);
        int int44 = jFreeChart34.getBackgroundImageAlignment();
        jFreeChart34.setBackgroundImageAlignment((int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + 1.0f + "'", float31 == 1.0f);
        org.junit.Assert.assertNull(polarItemRenderer32);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 15 + "'", int44 == 15);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot(xYDataset3, valueAxis4, polarItemRenderer5);
        defaultCategoryDataset1.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot6);
        java.awt.Image image8 = polarPlot6.getBackgroundImage();
        boolean boolean9 = paintList0.equals((java.lang.Object) image8);
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNull(image8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("");
        taskSeries1.fireSeriesChanged();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        taskSeries1.removeChangeListener(seriesChangeListener3);
        java.lang.String str5 = taskSeries1.getDescription();
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
        java.awt.Font font2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer3.setDrawOutlines(true);
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer3.setBasePaint((java.awt.Paint) color6, false);
        org.jfree.chart.text.TextMeasurer textMeasurer10 = null;
        org.jfree.chart.text.TextBlock textBlock11 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, (java.awt.Paint) color6, (float) (byte) -1, textMeasurer10);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor15 = null;
        java.awt.Shape shape19 = textBlock11.calculateBounds(graphics2D12, (float) 1, 100.0f, textBlockAnchor15, (float) 3, (float) (short) -1, (double) 0);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset22 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range23 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset22);
        org.jfree.data.Range range24 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset22);
        java.lang.Comparable comparable25 = null;
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity27 = new org.jfree.chart.entity.CategoryItemEntity(shape19, "{0}", "EXPAND", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset22, comparable25, (java.lang.Comparable) 1.0d);
        org.jfree.data.Range range28 = stackedBarRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset22);
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(4, 0);
        java.util.Date date32 = month31.getEnd();
        int int33 = month31.getYearValue();
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month(4, 0);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer37 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean38 = statisticalLineAndShapeRenderer37.getDrawOutlines();
        statisticalLineAndShapeRenderer37.setAutoPopulateSeriesFillPaint(false);
        java.lang.Object obj41 = statisticalLineAndShapeRenderer37.clone();
        java.awt.Stroke stroke42 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        statisticalLineAndShapeRenderer37.setBaseStroke(stroke42);
        boolean boolean46 = statisticalLineAndShapeRenderer37.getItemShapeVisible((int) '4', (int) (byte) 10);
        java.awt.Font font48 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        statisticalLineAndShapeRenderer37.setSeriesItemLabelFont((int) 'a', font48);
        int int50 = month36.compareTo((java.lang.Object) statisticalLineAndShapeRenderer37);
        defaultCategoryDataset22.removeValue((java.lang.Comparable) month31, (java.lang.Comparable) int50);
        java.util.Calendar calendar52 = null;
        try {
            long long53 = month31.getFirstMillisecond(calendar52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(textBlock11);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNull(range23);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(obj41);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(font48);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateBottomInset((double) 8);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean3 = range1.contains((double) 2);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = new org.jfree.chart.block.RectangleConstraint(0.0d, range1);
        double double5 = rectangleConstraint4.getWidth();
        org.jfree.data.Range range6 = rectangleConstraint4.getWidthRange();
        org.jfree.data.Range range7 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = rectangleConstraint4.toRangeWidth(range7);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = rectangleConstraint4.toUnconstrainedWidth();
        org.jfree.data.Range range10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.Range range13 = numberAxis12.getDefaultAutoRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = new org.jfree.chart.block.RectangleConstraint(range13, (double) (-1L));
        org.jfree.data.Range range16 = org.jfree.data.Range.combine(range10, range13);
        org.jfree.data.Range range17 = null;
        org.jfree.data.Range range18 = org.jfree.data.Range.combine(range16, range17);
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.Range range21 = numberAxis20.getDefaultAutoRange();
        double double22 = range21.getCentralValue();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = new org.jfree.chart.block.RectangleConstraint(range18, range21);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint24 = rectangleConstraint4.toRangeHeight(range21);
        org.jfree.data.Range range25 = rectangleConstraint24.getHeightRange();
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(rectangleConstraint8);
        org.junit.Assert.assertNotNull(rectangleConstraint9);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.5d + "'", double22 == 0.5d);
        org.junit.Assert.assertNotNull(rectangleConstraint24);
        org.junit.Assert.assertNotNull(range25);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font4 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer5 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer5.setDrawOutlines(true);
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer5.setBasePaint((java.awt.Paint) color8, false);
        org.jfree.chart.text.TextMeasurer textMeasurer12 = null;
        org.jfree.chart.text.TextBlock textBlock13 = org.jfree.chart.text.TextUtilities.createTextBlock("", font4, (java.awt.Paint) color8, (float) (byte) -1, textMeasurer12);
        numberAxis2.setTickMarkPaint((java.awt.Paint) color8);
        boolean boolean15 = numberAxis2.isInverted();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer16 = null;
        org.jfree.chart.plot.PolarPlot polarPlot17 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, polarItemRenderer16);
        numberAxis2.zoomRange((double) (-1.0f), (double) (short) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = numberAxis2.getLabelInsets();
        numberAxis2.setLowerBound((double) 86400000L);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset24 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range25 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset24);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer28 = null;
        org.jfree.chart.plot.PolarPlot polarPlot29 = new org.jfree.chart.plot.PolarPlot(xYDataset26, valueAxis27, polarItemRenderer28);
        defaultCategoryDataset24.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot29);
        java.awt.Image image31 = polarPlot29.getBackgroundImage();
        java.awt.Paint paint32 = polarPlot29.getBackgroundPaint();
        java.awt.Stroke stroke33 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        polarPlot29.setRadiusGridlineStroke(stroke33);
        numberAxis2.setTickMarkStroke(stroke33);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(textBlock13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertNull(image31);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(stroke33);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainCrosshairPaint();
        int int2 = xYPlot0.getSeriesCount();
        java.awt.Paint paint3 = xYPlot0.getRangeZeroBaselinePaint();
        boolean boolean4 = xYPlot0.isRangeCrosshairVisible();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset7 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset7);
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer11 = null;
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot(xYDataset9, valueAxis10, polarItemRenderer11);
        defaultCategoryDataset7.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot12);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo15);
        java.awt.geom.Point2D point2D17 = null;
        polarPlot12.zoomDomainAxes((double) '#', plotRenderingInfo16, point2D17);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo19);
        plotRenderingInfo16.addSubplotInfo(plotRenderingInfo20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = plotRenderingInfo16.getSubplotInfo((int) (byte) 0);
        org.jfree.chart.renderer.RendererState rendererState24 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo23);
        java.awt.geom.Point2D point2D25 = null;
        xYPlot0.zoomDomainAxes((double) ' ', (double) (-62125372800001L), plotRenderingInfo23, point2D25);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(plotRenderingInfo23);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        statisticalLineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        java.lang.Boolean boolean8 = statisticalLineAndShapeRenderer0.getSeriesVisibleInLegend((int) '#');
        org.junit.Assert.assertNull(boolean8);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = numberAxis1.getMarkerBand();
        numberAxis1.setLabelAngle((double) 11);
        org.junit.Assert.assertNull(markerAxisBand2);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer0.setSeriesLinesVisible((int) (short) 10, true);
        statisticalLineAndShapeRenderer0.setUseOutlinePaint(true);
        java.awt.Stroke stroke6 = statisticalLineAndShapeRenderer0.getBaseOutlineStroke();
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.chart.util.Layer layer0 = org.jfree.chart.util.Layer.BACKGROUND;
        org.junit.Assert.assertNotNull(layer0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D2 = new org.jfree.chart.plot.PiePlot3D(pieDataset1);
        piePlot3D2.setDepthFactor((double) (byte) 1);
        java.awt.Color color5 = java.awt.Color.GRAY;
        piePlot3D2.setLabelLinkPaint((java.awt.Paint) color5);
        boolean boolean7 = strokeList0.equals((java.lang.Object) color5);
        strokeList0.clear();
        java.lang.Object obj9 = strokeList0.clone();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long1 = segmentedTimeline0.getStartTime();
        int int2 = segmentedTimeline0.getSegmentsIncluded();
        long long5 = segmentedTimeline0.getExceptionSegmentCount(0L, (-1L));
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline6 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        java.util.Date date8 = segmentedTimeline6.getDate(0L);
        boolean boolean9 = segmentedTimeline0.containsDomainValue(date8);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-2208927600000L) + "'", long1 == (-2208927600000L));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28 + "'", int2 == 28);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(segmentedTimeline6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) 2019L);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDepthFactor((double) (byte) 1);
        piePlot3D1.setDepthFactor(0.0d);
        java.awt.Stroke[] strokeArray6 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        boolean boolean7 = piePlot3D1.equals((java.lang.Object) strokeArray6);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator8 = null;
        piePlot3D1.setLegendLabelURLGenerator(pieURLGenerator8);
        java.awt.Paint paint10 = piePlot3D1.getLabelOutlinePaint();
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D12 = new org.jfree.chart.plot.PiePlot3D(pieDataset11);
        piePlot3D12.setDepthFactor((double) (byte) 1);
        piePlot3D12.setDepthFactor(0.0d);
        piePlot3D12.setInteriorGap((double) 0.0f);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator19 = piePlot3D12.getURLGenerator();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator20 = piePlot3D12.getLabelGenerator();
        piePlot3D1.setLabelGenerator(pieSectionLabelGenerator20);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier22 = piePlot3D1.getDrawingSupplier();
        org.junit.Assert.assertNotNull(strokeArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(pieURLGenerator19);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator20);
        org.junit.Assert.assertNotNull(drawingSupplier22);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainCrosshairPaint();
        xYPlot0.clearRangeAxes();
        xYPlot0.mapDatasetToDomainAxis((int) '4', (int) (short) 0);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = xYPlot0.getRenderer();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(xYItemRenderer6);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean1 = statisticalLineAndShapeRenderer0.getDrawOutlines();
        statisticalLineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(false);
        java.lang.Object obj4 = statisticalLineAndShapeRenderer0.clone();
        java.awt.Stroke stroke5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        statisticalLineAndShapeRenderer0.setBaseStroke(stroke5);
        statisticalLineAndShapeRenderer0.setBaseItemLabelsVisible(false, false);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        statisticalLineAndShapeRenderer0.setBaseFillPaint((java.awt.Paint) color10);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = null;
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font17 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer18 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer18.setDrawOutlines(true);
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer18.setBasePaint((java.awt.Paint) color21, false);
        org.jfree.chart.text.TextMeasurer textMeasurer25 = null;
        org.jfree.chart.text.TextBlock textBlock26 = org.jfree.chart.text.TextUtilities.createTextBlock("", font17, (java.awt.Paint) color21, (float) (byte) -1, textMeasurer25);
        numberAxis15.setTickMarkPaint((java.awt.Paint) color21);
        org.jfree.chart.plot.Marker marker28 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset29 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset29);
        org.jfree.data.xy.XYDataset xYDataset31 = null;
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer33 = null;
        org.jfree.chart.plot.PolarPlot polarPlot34 = new org.jfree.chart.plot.PolarPlot(xYDataset31, valueAxis32, polarItemRenderer33);
        defaultCategoryDataset29.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot34);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo37 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo37);
        java.awt.geom.Point2D point2D39 = null;
        polarPlot34.zoomDomainAxes((double) '#', plotRenderingInfo38, point2D39);
        org.jfree.chart.block.BlockContainer blockContainer41 = new org.jfree.chart.block.BlockContainer();
        blockContainer41.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer47 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder52 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer47.setFrame((org.jfree.chart.block.BlockFrame) blockBorder52);
        blockContainer41.add((org.jfree.chart.block.Block) blockContainer47);
        java.awt.Graphics2D graphics2D55 = null;
        org.jfree.chart.util.Size2D size2D56 = blockContainer47.arrange(graphics2D55);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor59 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D60 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D56, (double) '#', (double) 1.0f, rectangleAnchor59);
        plotRenderingInfo38.setPlotArea(rectangle2D60);
        statisticalLineAndShapeRenderer0.drawRangeMarker(graphics2D12, categoryPlot13, (org.jfree.chart.axis.ValueAxis) numberAxis15, marker28, rectangle2D60);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity63 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D60);
        java.lang.Object obj64 = legendItemEntity63.clone();
        legendItemEntity63.setToolTipText("UnitType.ABSOLUTE");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(textBlock26);
        org.junit.Assert.assertNull(range30);
        org.junit.Assert.assertNotNull(size2D56);
        org.junit.Assert.assertNotNull(rectangleAnchor59);
        org.junit.Assert.assertNotNull(rectangle2D60);
        org.junit.Assert.assertNotNull(obj64);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean3 = range1.contains((double) 2);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = new org.jfree.chart.block.RectangleConstraint(0.0d, range1);
        double double5 = rectangleConstraint4.getWidth();
        org.jfree.data.Range range6 = rectangleConstraint4.getWidthRange();
        org.jfree.data.Range range7 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = rectangleConstraint4.toRangeWidth(range7);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = rectangleConstraint4.toUnconstrainedWidth();
        org.jfree.data.Range range10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.Range range13 = numberAxis12.getDefaultAutoRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = new org.jfree.chart.block.RectangleConstraint(range13, (double) (-1L));
        org.jfree.data.Range range16 = org.jfree.data.Range.combine(range10, range13);
        org.jfree.data.Range range17 = null;
        org.jfree.data.Range range18 = org.jfree.data.Range.combine(range16, range17);
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.Range range21 = numberAxis20.getDefaultAutoRange();
        double double22 = range21.getCentralValue();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = new org.jfree.chart.block.RectangleConstraint(range18, range21);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint24 = rectangleConstraint4.toRangeHeight(range21);
        org.jfree.data.Range range27 = org.jfree.data.Range.shift(range21, 1.0E-5d, false);
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(rectangleConstraint8);
        org.junit.Assert.assertNotNull(rectangleConstraint9);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.5d + "'", double22 == 0.5d);
        org.junit.Assert.assertNotNull(rectangleConstraint24);
        org.junit.Assert.assertNotNull(range27);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(4, 0);
        java.util.Date date3 = month2.getEnd();
        org.jfree.data.DefaultKeyedValue defaultKeyedValue5 = new org.jfree.data.DefaultKeyedValue((java.lang.Comparable) month2, (java.lang.Number) 0.35d);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDepthFactor((double) (byte) 1);
        piePlot3D1.setDepthFactor(0.0d);
        java.awt.Stroke stroke6 = piePlot3D1.getLabelLinkStroke();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        piePlot3D1.setDataset(pieDataset7);
        java.lang.Object obj9 = piePlot3D1.clone();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor10 = piePlot3D1.getLabelDistributor();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator11 = piePlot3D1.getLegendLabelGenerator();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor10);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator11);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.extendWidth((double) 2019L);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2019.0d + "'", double2 == 2019.0d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset3 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset3);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset5, valueAxis6, polarItemRenderer7);
        defaultCategoryDataset3.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot8);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo11);
        java.awt.geom.Point2D point2D13 = null;
        polarPlot8.zoomDomainAxes((double) '#', plotRenderingInfo12, point2D13);
        org.jfree.chart.block.BlockContainer blockContainer15 = new org.jfree.chart.block.BlockContainer();
        blockContainer15.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer21 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder26 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer21.setFrame((org.jfree.chart.block.BlockFrame) blockBorder26);
        blockContainer15.add((org.jfree.chart.block.Block) blockContainer21);
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.util.Size2D size2D30 = blockContainer21.arrange(graphics2D29);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D34 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D30, (double) '#', (double) 1.0f, rectangleAnchor33);
        plotRenderingInfo12.setPlotArea(rectangle2D34);
        categoryPlot0.handleClick(0, 0, plotRenderingInfo12);
        org.jfree.chart.util.Layer layer38 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection39 = categoryPlot0.getRangeMarkers(0, layer38);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = categoryPlot0.getRenderer((int) (short) 1);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNotNull(size2D30);
        org.junit.Assert.assertNotNull(rectangleAnchor33);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNotNull(layer38);
        org.junit.Assert.assertNull(collection39);
        org.junit.Assert.assertNull(categoryItemRenderer41);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        java.awt.Font font1 = null;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis4, polarItemRenderer5);
        float float7 = polarPlot6.getBackgroundAlpha();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer8 = polarPlot6.getRenderer();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font1, (org.jfree.chart.plot.Plot) polarPlot6, false);
        org.jfree.chart.title.TextTitle textTitle11 = null;
        jFreeChart10.setTitle(textTitle11);
        jFreeChart10.setBackgroundImageAlpha((float) 0L);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertNull(polarItemRenderer8);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = numberAxis1.getMarkerBand();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = numberAxis1.getMarkerBand();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = numberAxis1.getLabelInsets();
        numberAxis1.setNegativeArrowVisible(false);
        org.junit.Assert.assertNull(markerAxisBand2);
        org.junit.Assert.assertNull(markerAxisBand3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(1.0d, (double) (short) -1);
        boolean boolean3 = stackedBarRenderer3D2.isDrawBarOutline();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = stackedBarRenderer3D2.getBaseURLGenerator();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = null;
        stackedBarRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator5);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(categoryURLGenerator4);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("4/30/01 11:59 PM");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        double double1 = xYPlot0.getRangeCrosshairValue();
        xYPlot0.setDomainCrosshairValue((double) 0.0f, false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        java.lang.Object obj4 = null;
        boolean boolean5 = polarPlot3.equals(obj4);
        polarPlot3.setAngleLabelsVisible(true);
        polarPlot3.setAngleGridlinesVisible(true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline1 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long2 = segmentedTimeline1.getStartTime();
        int int3 = segmentedTimeline1.getSegmentsIncluded();
        long long6 = segmentedTimeline1.getExceptionSegmentCount(0L, (-1L));
        long long7 = segmentedTimeline1.getSegmentsGroupSize();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(4, 0);
        java.util.Date date11 = month10.getEnd();
        long long12 = segmentedTimeline1.getTime(date11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date11);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(4, 0);
        java.util.Date date17 = month16.getEnd();
        org.jfree.data.gantt.Task task18 = new org.jfree.data.gantt.Task("", date11, date17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D21 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        boolean boolean23 = categoryAxis3D21.equals((java.lang.Object) textAnchor22);
        org.jfree.chart.axis.DateTick dateTick25 = new org.jfree.chart.axis.DateTick(date17, "TextBlockAnchor.TOP_CENTER", textAnchor20, textAnchor22, (double) '#');
        java.lang.String str26 = dateTick25.toString();
        org.junit.Assert.assertNotNull(segmentedTimeline1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2208927600000L) + "'", long2 == (-2208927600000L));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 28 + "'", int3 == 28);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 86400000L + "'", long7 == 86400000L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62125372800001L) + "'", long12 == (-62125372800001L));
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "TextBlockAnchor.TOP_CENTER" + "'", str26.equals("TextBlockAnchor.TOP_CENTER"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D2 = new org.jfree.chart.plot.PiePlot3D(pieDataset1);
        piePlot3D2.setDepthFactor((double) (byte) 1);
        piePlot3D2.setDepthFactor(0.0d);
        java.awt.Stroke[] strokeArray7 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        boolean boolean8 = piePlot3D2.equals((java.lang.Object) strokeArray7);
        java.awt.Paint paint9 = piePlot3D2.getLabelShadowPaint();
        java.awt.Paint paint10 = piePlot3D2.getLabelBackgroundPaint();
        boolean boolean11 = piePlot3D2.getLabelLinksVisible();
        boolean boolean12 = paintList0.equals((java.lang.Object) boolean11);
        java.awt.Paint paint14 = paintList0.getPaint(2958465);
        org.junit.Assert.assertNotNull(strokeArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(paint14);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = null;
        statisticalLineAndShapeRenderer0.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator2, true);
        statisticalLineAndShapeRenderer0.setSeriesVisibleInLegend(0, (java.lang.Boolean) true, true);
        java.lang.Boolean boolean10 = statisticalLineAndShapeRenderer0.getSeriesVisibleInLegend(100);
        java.awt.Shape shape13 = statisticalLineAndShapeRenderer0.getItemShape((int) (short) 100, (int) (byte) -1);
        java.awt.Paint paint15 = statisticalLineAndShapeRenderer0.getSeriesFillPaint(2);
        org.junit.Assert.assertNull(boolean10);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNull(paint15);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        org.jfree.chart.ui.Library[] libraryArray1 = projectInfo0.getOptionalLibraries();
        java.lang.String str2 = projectInfo0.getCopyright();
        org.junit.Assert.assertNotNull(libraryArray1);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis2.setInverted(true);
        boolean boolean5 = numberAxis2.isAxisLineVisible();
        boolean boolean6 = numberAxis2.getAutoRangeStickyZero();
        java.awt.Stroke stroke7 = numberAxis2.getAxisLineStroke();
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis2);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        int int12 = xYPlot10.indexOf(xYDataset11);
        org.jfree.chart.util.Layer layer14 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection15 = xYPlot10.getRangeMarkers(6, layer14);
        java.util.Collection collection16 = categoryPlot0.getDomainMarkers(layer14);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis20.setInverted(true);
        boolean boolean23 = numberAxis20.isAxisLineVisible();
        boolean boolean24 = numberAxis20.getAutoRangeStickyZero();
        java.awt.Stroke stroke25 = numberAxis20.getAxisLineStroke();
        categoryPlot18.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis20);
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = categoryPlot18.getDomainAxisForDataset((int) ' ');
        org.jfree.chart.axis.AxisLocation axisLocation29 = categoryPlot18.getDomainAxisLocation();
        categoryPlot0.setDomainAxisLocation(0, axisLocation29, true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(layer14);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNull(collection16);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNull(categoryAxis28);
        org.junit.Assert.assertNotNull(axisLocation29);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = null;
        statisticalLineAndShapeRenderer0.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator2, true);
        statisticalLineAndShapeRenderer0.setSeriesVisibleInLegend(0, (java.lang.Boolean) true, true);
        java.lang.Boolean boolean10 = statisticalLineAndShapeRenderer0.getSeriesVisibleInLegend(100);
        boolean boolean13 = statisticalLineAndShapeRenderer0.getItemShapeVisible(0, 8);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis17.setInverted(true);
        boolean boolean20 = numberAxis17.isAxisLineVisible();
        boolean boolean21 = numberAxis17.getAutoRangeStickyZero();
        java.awt.Stroke stroke22 = numberAxis17.getAxisLineStroke();
        categoryPlot15.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis17);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer24 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean25 = statisticalLineAndShapeRenderer24.getDrawOutlines();
        statisticalLineAndShapeRenderer24.setAutoPopulateSeriesFillPaint(false);
        java.lang.Object obj28 = statisticalLineAndShapeRenderer24.clone();
        java.awt.Stroke stroke29 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        statisticalLineAndShapeRenderer24.setBaseStroke(stroke29);
        boolean boolean33 = statisticalLineAndShapeRenderer24.getItemShapeVisible((int) '4', (int) (byte) 10);
        java.awt.Font font35 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        statisticalLineAndShapeRenderer24.setSeriesItemLabelFont((int) 'a', font35);
        java.awt.Paint paint37 = statisticalLineAndShapeRenderer24.getErrorIndicatorPaint();
        int int38 = categoryPlot15.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer24);
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        try {
            statisticalLineAndShapeRenderer0.drawDomainGridline(graphics2D14, categoryPlot15, rectangle2D39, 0.2d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(boolean10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNull(paint37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        java.awt.Font font1 = null;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis4, polarItemRenderer5);
        float float7 = polarPlot6.getBackgroundAlpha();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer8 = polarPlot6.getRenderer();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font1, (org.jfree.chart.plot.Plot) polarPlot6, false);
        org.jfree.chart.entity.EntityCollection entityCollection13 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = new org.jfree.chart.ChartRenderingInfo(entityCollection13);
        java.lang.Object obj15 = chartRenderingInfo14.clone();
        jFreeChart10.handleClick((int) '4', 2019, chartRenderingInfo14);
        chartRenderingInfo14.clear();
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertNull(polarItemRenderer8);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setInverted(true);
        boolean boolean4 = numberAxis1.isAxisLineVisible();
        boolean boolean5 = numberAxis1.getAutoRangeStickyZero();
        boolean boolean6 = numberAxis1.isAxisLineVisible();
        org.jfree.chart.plot.Plot plot7 = numberAxis1.getPlot();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(plot7);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        int int1 = defaultKeyedValues2D0.getColumnCount();
        try {
            defaultKeyedValues2D0.removeColumn(2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2019, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font3 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer4 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer4.setDrawOutlines(true);
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer4.setBasePaint((java.awt.Paint) color7, false);
        org.jfree.chart.text.TextMeasurer textMeasurer11 = null;
        org.jfree.chart.text.TextBlock textBlock12 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, (java.awt.Paint) color7, (float) (byte) -1, textMeasurer11);
        numberAxis1.setTickMarkPaint((java.awt.Paint) color7);
        numberAxis1.configure();
        numberAxis1.setTickMarksVisible(false);
        numberAxis1.setFixedDimension((double) 2958465);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(textBlock12);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.chart.entity.EntityCollection entityCollection0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo(entityCollection0);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D(pieDataset2);
        piePlot3D3.setDepthFactor((double) (byte) 1);
        piePlot3D3.setDepthFactor(0.0d);
        java.awt.Stroke stroke8 = piePlot3D3.getLabelLinkStroke();
        double double9 = piePlot3D3.getShadowXOffset();
        java.lang.String str10 = piePlot3D3.getNoDataMessage();
        java.awt.Paint paint11 = piePlot3D3.getBaseSectionOutlinePaint();
        java.awt.Paint paint13 = piePlot3D3.getSectionOutlinePaint((java.lang.Comparable) 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font17 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer18 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer18.setDrawOutlines(true);
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer18.setBasePaint((java.awt.Paint) color21, false);
        org.jfree.chart.text.TextMeasurer textMeasurer25 = null;
        org.jfree.chart.text.TextBlock textBlock26 = org.jfree.chart.text.TextUtilities.createTextBlock("", font17, (java.awt.Paint) color21, (float) (byte) -1, textMeasurer25);
        numberAxis15.setTickMarkPaint((java.awt.Paint) color21);
        piePlot3D3.setLabelShadowPaint((java.awt.Paint) color21);
        org.jfree.chart.block.BlockContainer blockContainer29 = new org.jfree.chart.block.BlockContainer();
        blockContainer29.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer35 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder40 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer35.setFrame((org.jfree.chart.block.BlockFrame) blockBorder40);
        blockContainer29.add((org.jfree.chart.block.Block) blockContainer35);
        java.awt.Graphics2D graphics2D43 = null;
        org.jfree.chart.util.Size2D size2D44 = blockContainer35.arrange(graphics2D43);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor47 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D48 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D44, (double) '#', (double) 1.0f, rectangleAnchor47);
        boolean boolean49 = piePlot3D3.equals((java.lang.Object) rectangle2D48);
        chartRenderingInfo1.setChartArea(rectangle2D48);
        chartRenderingInfo1.clear();
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 4.0d + "'", double9 == 4.0d);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(textBlock26);
        org.junit.Assert.assertNotNull(size2D44);
        org.junit.Assert.assertNotNull(rectangleAnchor47);
        org.junit.Assert.assertNotNull(rectangle2D48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean1 = statisticalLineAndShapeRenderer0.getDrawOutlines();
        statisticalLineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(false);
        java.lang.Object obj4 = statisticalLineAndShapeRenderer0.clone();
        java.awt.Stroke stroke5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        statisticalLineAndShapeRenderer0.setBaseStroke(stroke5);
        statisticalLineAndShapeRenderer0.setBaseItemLabelsVisible(false, false);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        statisticalLineAndShapeRenderer0.setBaseFillPaint((java.awt.Paint) color10);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = null;
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font17 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer18 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer18.setDrawOutlines(true);
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer18.setBasePaint((java.awt.Paint) color21, false);
        org.jfree.chart.text.TextMeasurer textMeasurer25 = null;
        org.jfree.chart.text.TextBlock textBlock26 = org.jfree.chart.text.TextUtilities.createTextBlock("", font17, (java.awt.Paint) color21, (float) (byte) -1, textMeasurer25);
        numberAxis15.setTickMarkPaint((java.awt.Paint) color21);
        org.jfree.chart.plot.Marker marker28 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset29 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset29);
        org.jfree.data.xy.XYDataset xYDataset31 = null;
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer33 = null;
        org.jfree.chart.plot.PolarPlot polarPlot34 = new org.jfree.chart.plot.PolarPlot(xYDataset31, valueAxis32, polarItemRenderer33);
        defaultCategoryDataset29.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot34);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo37 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo37);
        java.awt.geom.Point2D point2D39 = null;
        polarPlot34.zoomDomainAxes((double) '#', plotRenderingInfo38, point2D39);
        org.jfree.chart.block.BlockContainer blockContainer41 = new org.jfree.chart.block.BlockContainer();
        blockContainer41.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer47 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder52 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer47.setFrame((org.jfree.chart.block.BlockFrame) blockBorder52);
        blockContainer41.add((org.jfree.chart.block.Block) blockContainer47);
        java.awt.Graphics2D graphics2D55 = null;
        org.jfree.chart.util.Size2D size2D56 = blockContainer47.arrange(graphics2D55);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor59 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D60 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D56, (double) '#', (double) 1.0f, rectangleAnchor59);
        plotRenderingInfo38.setPlotArea(rectangle2D60);
        statisticalLineAndShapeRenderer0.drawRangeMarker(graphics2D12, categoryPlot13, (org.jfree.chart.axis.ValueAxis) numberAxis15, marker28, rectangle2D60);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity63 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D60);
        java.lang.Object obj64 = legendItemEntity63.clone();
        legendItemEntity63.setSeriesKey((java.lang.Comparable) (-1.0f));
        java.lang.Object obj67 = legendItemEntity63.clone();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(textBlock26);
        org.junit.Assert.assertNull(range30);
        org.junit.Assert.assertNotNull(size2D56);
        org.junit.Assert.assertNotNull(rectangleAnchor59);
        org.junit.Assert.assertNotNull(rectangle2D60);
        org.junit.Assert.assertNotNull(obj64);
        org.junit.Assert.assertNotNull(obj67);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis2.setInverted(true);
        boolean boolean5 = numberAxis2.isAxisLineVisible();
        boolean boolean6 = numberAxis2.getAutoRangeStickyZero();
        java.awt.Stroke stroke7 = numberAxis2.getAxisLineStroke();
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis2);
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot0.getRangeAxisLocation(0);
        float float11 = categoryPlot0.getBackgroundAlpha();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset15 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset15);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot(xYDataset17, valueAxis18, polarItemRenderer19);
        defaultCategoryDataset15.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot20);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo23 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo23);
        java.awt.geom.Point2D point2D25 = null;
        polarPlot20.zoomDomainAxes((double) '#', plotRenderingInfo24, point2D25);
        org.jfree.chart.block.BlockContainer blockContainer27 = new org.jfree.chart.block.BlockContainer();
        blockContainer27.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer33 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder38 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer33.setFrame((org.jfree.chart.block.BlockFrame) blockBorder38);
        blockContainer27.add((org.jfree.chart.block.Block) blockContainer33);
        java.awt.Graphics2D graphics2D41 = null;
        org.jfree.chart.util.Size2D size2D42 = blockContainer33.arrange(graphics2D41);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor45 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D46 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D42, (double) '#', (double) 1.0f, rectangleAnchor45);
        plotRenderingInfo24.setPlotArea(rectangle2D46);
        categoryPlot12.handleClick(0, 0, plotRenderingInfo24);
        org.jfree.chart.util.Layer layer50 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection51 = categoryPlot12.getRangeMarkers(0, layer50);
        java.util.Collection collection52 = categoryPlot0.getDomainMarkers(layer50);
        org.jfree.chart.axis.AxisLocation axisLocation54 = null;
        categoryPlot0.setRangeAxisLocation(10, axisLocation54, false);
        org.jfree.chart.util.Layer layer58 = null;
        java.util.Collection collection59 = categoryPlot0.getRangeMarkers(28, layer58);
        org.jfree.data.xy.XYDataset xYDataset60 = null;
        org.jfree.chart.axis.NumberAxis numberAxis62 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer63 = null;
        org.jfree.chart.plot.PolarPlot polarPlot64 = new org.jfree.chart.plot.PolarPlot(xYDataset60, (org.jfree.chart.axis.ValueAxis) numberAxis62, polarItemRenderer63);
        java.awt.Font font65 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        polarPlot64.setAngleLabelFont(font65);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer67 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer67.setDrawOutlines(true);
        java.awt.Color color70 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer67.setBasePaint((java.awt.Paint) color70, false);
        org.jfree.data.xy.XYDataset xYDataset74 = null;
        org.jfree.chart.axis.ValueAxis valueAxis75 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer76 = null;
        org.jfree.chart.plot.PolarPlot polarPlot77 = new org.jfree.chart.plot.PolarPlot(xYDataset74, valueAxis75, polarItemRenderer76);
        java.lang.Object obj78 = null;
        boolean boolean79 = polarPlot77.equals(obj78);
        int int80 = polarPlot77.getSeriesCount();
        java.awt.Color color81 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        polarPlot77.setAngleLabelPaint((java.awt.Paint) color81);
        statisticalLineAndShapeRenderer67.setSeriesFillPaint(2, (java.awt.Paint) color81);
        java.awt.Stroke stroke86 = statisticalLineAndShapeRenderer67.getItemStroke(0, 10);
        java.lang.Boolean boolean88 = statisticalLineAndShapeRenderer67.getSeriesCreateEntities((int) (short) -1);
        java.awt.Font font89 = statisticalLineAndShapeRenderer67.getBaseItemLabelFont();
        polarPlot64.setAngleLabelFont(font89);
        org.jfree.chart.plot.PlotOrientation plotOrientation91 = polarPlot64.getOrientation();
        categoryPlot0.setOrientation(plotOrientation91);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 1.0f + "'", float11 == 1.0f);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(size2D42);
        org.junit.Assert.assertNotNull(rectangleAnchor45);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertNotNull(layer50);
        org.junit.Assert.assertNull(collection51);
        org.junit.Assert.assertNull(collection52);
        org.junit.Assert.assertNull(collection59);
        org.junit.Assert.assertNotNull(font65);
        org.junit.Assert.assertNotNull(color70);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 0 + "'", int80 == 0);
        org.junit.Assert.assertNotNull(color81);
        org.junit.Assert.assertNotNull(stroke86);
        org.junit.Assert.assertNull(boolean88);
        org.junit.Assert.assertNotNull(font89);
        org.junit.Assert.assertNotNull(plotOrientation91);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        boolean boolean1 = textTitle0.getExpandToFitSpace();
        textTitle0.setNotify(false);
        java.awt.Paint paint4 = textTitle0.getBackgroundPaint();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(paint4);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font3 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer4 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer4.setDrawOutlines(true);
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer4.setBasePaint((java.awt.Paint) color7, false);
        org.jfree.chart.text.TextMeasurer textMeasurer11 = null;
        org.jfree.chart.text.TextBlock textBlock12 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, (java.awt.Paint) color7, (float) (byte) -1, textMeasurer11);
        numberAxis1.setTickMarkPaint((java.awt.Paint) color7);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit15 = new org.jfree.chart.axis.NumberTickUnit(0.0d);
        numberAxis1.setTickUnit(numberTickUnit15);
        java.awt.Paint paint17 = numberAxis1.getTickMarkPaint();
        boolean boolean18 = numberAxis1.getAutoRangeStickyZero();
        numberAxis1.setInverted(true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(textBlock12);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        boolean boolean1 = textTitle0.getExpandToFitSpace();
        textTitle0.setNotify(false);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font9 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer10 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer10.setDrawOutlines(true);
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer10.setBasePaint((java.awt.Paint) color13, false);
        org.jfree.chart.text.TextMeasurer textMeasurer17 = null;
        org.jfree.chart.text.TextBlock textBlock18 = org.jfree.chart.text.TextUtilities.createTextBlock("", font9, (java.awt.Paint) color13, (float) (byte) -1, textMeasurer17);
        numberAxis7.setTickMarkPaint((java.awt.Paint) color13);
        numberAxis7.configure();
        numberAxis7.setFixedAutoRange((double) (-1L));
        org.jfree.chart.axis.NumberTickUnit numberTickUnit23 = numberAxis7.getTickUnit();
        boolean boolean24 = verticalAlignment5.equals((java.lang.Object) numberTickUnit23);
        boolean boolean25 = verticalAlignment4.equals((java.lang.Object) boolean24);
        textTitle0.setVerticalAlignment(verticalAlignment4);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(verticalAlignment5);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(textBlock18);
        org.junit.Assert.assertNotNull(numberTickUnit23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
        int int1 = stackedBarRenderer0.getPassCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        java.lang.Number number4 = null;
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D8 = new org.jfree.data.DefaultKeyedValues2D();
        java.util.List list9 = defaultKeyedValues2D8.getRowKeys();
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem10 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 2.0d, (java.lang.Number) 100L, (java.lang.Number) (-2208960000000L), (java.lang.Number) (-1.0d), number4, (java.lang.Number) 2019L, (java.lang.Number) 0.05d, (java.lang.Number) 2, list9);
        java.lang.Number number11 = boxAndWhiskerItem10.getMean();
        java.util.List list12 = boxAndWhiskerItem10.getOutliers();
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 2.0d + "'", number11.equals(2.0d));
        org.junit.Assert.assertNotNull(list12);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean3 = range1.contains((double) 2);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = new org.jfree.chart.block.RectangleConstraint(0.0d, range1);
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer();
        blockContainer5.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer11 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder16 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer11.setFrame((org.jfree.chart.block.BlockFrame) blockBorder16);
        blockContainer5.add((org.jfree.chart.block.Block) blockContainer11);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.util.Size2D size2D20 = blockContainer11.arrange(graphics2D19);
        org.jfree.chart.util.Size2D size2D21 = rectangleConstraint4.calculateConstrainedSize(size2D20);
        double double22 = size2D21.getWidth();
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(size2D20);
        org.junit.Assert.assertNotNull(size2D21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("{0}");
        int int2 = categoryAxis3D1.getCategoryLabelPositionOffset();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.NONE;
        java.lang.String str1 = lengthConstraintType0.toString();
        org.junit.Assert.assertNotNull(lengthConstraintType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "LengthConstraintType.NONE" + "'", str1.equals("LengthConstraintType.NONE"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset2, valueAxis3, polarItemRenderer4);
        defaultCategoryDataset0.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot5);
        polarPlot5.setOutlineVisible(false);
        java.awt.Paint paint9 = polarPlot5.getRadiusGridlinePaint();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font3 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer4 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer4.setDrawOutlines(true);
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer4.setBasePaint((java.awt.Paint) color7, false);
        org.jfree.chart.text.TextMeasurer textMeasurer11 = null;
        org.jfree.chart.text.TextBlock textBlock12 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, (java.awt.Paint) color7, (float) (byte) -1, textMeasurer11);
        numberAxis1.setTickMarkPaint((java.awt.Paint) color7);
        numberAxis1.setAutoRange(false);
        double double16 = numberAxis1.getAutoRangeMinimumSize();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis19.setInverted(true);
        boolean boolean22 = numberAxis19.isAxisLineVisible();
        boolean boolean23 = numberAxis19.getAutoRangeStickyZero();
        java.awt.Stroke stroke24 = numberAxis19.getAxisLineStroke();
        categoryPlot17.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis19);
        java.awt.Stroke stroke26 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot17.setRangeCrosshairStroke(stroke26);
        categoryPlot17.setDomainGridlinesVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis31 = categoryPlot17.getRangeAxis(0);
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double34 = rectangleInsets32.calculateBottomOutset((double) 'a');
        double double35 = rectangleInsets32.getRight();
        categoryPlot17.setAxisOffset(rectangleInsets32);
        numberAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot17);
        float float38 = numberAxis1.getTickMarkOutsideLength();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(textBlock12);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0E-8d + "'", double16 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(valueAxis31);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34 == 1.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.0d + "'", double35 == 1.0d);
        org.junit.Assert.assertTrue("'" + float38 + "' != '" + 2.0f + "'", float38 == 2.0f);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(1.0d, (double) (short) -1);
        boolean boolean3 = stackedBarRenderer3D2.isDrawBarOutline();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer4 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        stackedBarRenderer3D2.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer4);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset6 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range7 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset6);
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset6);
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset6);
        int int11 = defaultCategoryDataset6.getRowIndex((java.lang.Comparable) 10L);
        org.jfree.data.Range range12 = stackedBarRenderer3D2.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset6);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNull(range12);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = statisticalLineAndShapeRenderer0.getBaseItemLabelGenerator();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator3 = null;
        statisticalLineAndShapeRenderer0.setSeriesItemLabelGenerator((int) (byte) 100, categoryItemLabelGenerator3, true);
        statisticalLineAndShapeRenderer0.setItemLabelAnchorOffset((double) 255);
        org.junit.Assert.assertNull(categoryItemLabelGenerator1);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis2.setInverted(true);
        boolean boolean5 = numberAxis2.isAxisLineVisible();
        boolean boolean6 = numberAxis2.getAutoRangeStickyZero();
        java.awt.Stroke stroke7 = numberAxis2.getAxisLineStroke();
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis2);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace9);
        categoryPlot0.setRangeCrosshairValue(0.0d, true);
        categoryPlot0.setRangeGridlinesVisible(true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setInverted(true);
        java.awt.Font font4 = numberAxis1.getTickLabelFont();
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Color color4 = java.awt.Color.getHSBColor((-1.0f), 0.0f, (float) 11);
        boolean boolean5 = stackedAreaRenderer0.equals((java.lang.Object) 11);
        java.lang.Object obj6 = stackedAreaRenderer0.clone();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("{0}", graphics2D1, (float) 2958465, (float) 10, (double) (byte) 100, (float) (-2208960000000L), (float) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        java.lang.Object obj4 = null;
        boolean boolean5 = polarPlot3.equals(obj4);
        polarPlot3.setAngleLabelsVisible(true);
        org.jfree.chart.plot.Plot plot8 = polarPlot3.getParent();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(plot8);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((double) (byte) 100);
        categoryAxis3D0.setCategoryLabelPositions(categoryLabelPositions2);
        double double4 = categoryAxis3D0.getLowerMargin();
        categoryAxis3D0.configure();
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        int int2 = xYPlot0.indexOf(xYDataset1);
        org.jfree.chart.util.Layer layer4 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(6, layer4);
        org.jfree.chart.axis.ValueAxis valueAxis7 = xYPlot0.getRangeAxis(2);
        org.jfree.chart.plot.Marker marker8 = null;
        try {
            xYPlot0.addDomainMarker(marker8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(layer4);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNull(valueAxis7);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("SortOrder.DESCENDING", timeZone1);
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = dateAxis2.getTickUnit();
        java.util.TimeZone timeZone5 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("SortOrder.DESCENDING", timeZone5);
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = dateAxis6.getTickUnit();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline8 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long9 = segmentedTimeline8.getStartTime();
        int int10 = segmentedTimeline8.getSegmentsIncluded();
        long long13 = segmentedTimeline8.getExceptionSegmentCount(0L, (-1L));
        long long14 = segmentedTimeline8.getSegmentsGroupSize();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(4, 0);
        java.util.Date date18 = month17.getEnd();
        long long19 = segmentedTimeline8.getTime(date18);
        java.lang.String str20 = dateTickUnit7.dateToString(date18);
        java.util.Date date21 = dateAxis2.calculateLowestVisibleTickValue(dateTickUnit7);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(dateTickUnit7);
        org.junit.Assert.assertNotNull(segmentedTimeline8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-2208927600000L) + "'", long9 == (-2208927600000L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 28 + "'", int10 == 28);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 86400000L + "'", long14 == 86400000L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-62125372800001L) + "'", long19 == (-62125372800001L));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "4/30/01 11:59 PM" + "'", str20.equals("4/30/01 11:59 PM"));
        org.junit.Assert.assertNotNull(date21);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long1 = segmentedTimeline0.getStartTime();
        int int2 = segmentedTimeline0.getSegmentsExcluded();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-2208927600000L) + "'", long1 == (-2208927600000L));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 68 + "'", int2 == 68);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis2.setInverted(true);
        boolean boolean5 = numberAxis2.isAxisLineVisible();
        boolean boolean6 = numberAxis2.getAutoRangeStickyZero();
        java.awt.Stroke stroke7 = numberAxis2.getAxisLineStroke();
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis2);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer9 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean10 = statisticalLineAndShapeRenderer9.getDrawOutlines();
        statisticalLineAndShapeRenderer9.setAutoPopulateSeriesFillPaint(false);
        java.lang.Object obj13 = statisticalLineAndShapeRenderer9.clone();
        java.awt.Stroke stroke14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        statisticalLineAndShapeRenderer9.setBaseStroke(stroke14);
        boolean boolean18 = statisticalLineAndShapeRenderer9.getItemShapeVisible((int) '4', (int) (byte) 10);
        java.awt.Font font20 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        statisticalLineAndShapeRenderer9.setSeriesItemLabelFont((int) 'a', font20);
        java.awt.Paint paint22 = statisticalLineAndShapeRenderer9.getErrorIndicatorPaint();
        int int23 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer9);
        boolean boolean24 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset28 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range29 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset28);
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer32 = null;
        org.jfree.chart.plot.PolarPlot polarPlot33 = new org.jfree.chart.plot.PolarPlot(xYDataset30, valueAxis31, polarItemRenderer32);
        defaultCategoryDataset28.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot33);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo36 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo36);
        java.awt.geom.Point2D point2D38 = null;
        polarPlot33.zoomDomainAxes((double) '#', plotRenderingInfo37, point2D38);
        org.jfree.chart.block.BlockContainer blockContainer40 = new org.jfree.chart.block.BlockContainer();
        blockContainer40.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer46 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder51 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer46.setFrame((org.jfree.chart.block.BlockFrame) blockBorder51);
        blockContainer40.add((org.jfree.chart.block.Block) blockContainer46);
        java.awt.Graphics2D graphics2D54 = null;
        org.jfree.chart.util.Size2D size2D55 = blockContainer46.arrange(graphics2D54);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor58 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D59 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D55, (double) '#', (double) 1.0f, rectangleAnchor58);
        plotRenderingInfo37.setPlotArea(rectangle2D59);
        categoryPlot25.handleClick(0, 0, plotRenderingInfo37);
        org.jfree.chart.util.Layer layer63 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection64 = categoryPlot25.getRangeMarkers(0, layer63);
        org.jfree.chart.plot.CategoryPlot categoryPlot66 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis68 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis68.setInverted(true);
        boolean boolean71 = numberAxis68.isAxisLineVisible();
        boolean boolean72 = numberAxis68.getAutoRangeStickyZero();
        java.awt.Stroke stroke73 = numberAxis68.getAxisLineStroke();
        categoryPlot66.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis68);
        org.jfree.chart.axis.AxisLocation axisLocation76 = categoryPlot66.getRangeAxisLocation(0);
        categoryPlot25.setDomainAxisLocation((int) (short) 0, axisLocation76);
        org.jfree.chart.axis.AxisLocation axisLocation78 = axisLocation76.getOpposite();
        categoryPlot0.setDomainAxisLocation(axisLocation76);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNull(paint22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(range29);
        org.junit.Assert.assertNotNull(size2D55);
        org.junit.Assert.assertNotNull(rectangleAnchor58);
        org.junit.Assert.assertNotNull(rectangle2D59);
        org.junit.Assert.assertNotNull(layer63);
        org.junit.Assert.assertNull(collection64);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertNotNull(stroke73);
        org.junit.Assert.assertNotNull(axisLocation76);
        org.junit.Assert.assertNotNull(axisLocation78);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis2.setInverted(true);
        boolean boolean5 = numberAxis2.isAxisLineVisible();
        boolean boolean6 = numberAxis2.getAutoRangeStickyZero();
        java.awt.Stroke stroke7 = numberAxis2.getAxisLineStroke();
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis2);
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot0.getRangeAxisLocation(0);
        org.jfree.chart.axis.AxisSpace axisSpace11 = categoryPlot0.getFixedDomainAxisSpace();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNull(axisSpace11);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke1 = defaultDrawingSupplier0.getNextStroke();
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        java.awt.Font font2 = piePlot3D1.getLabelFont();
        java.awt.Color color4 = java.awt.Color.YELLOW;
        piePlot3D1.setSectionPaint((java.lang.Comparable) "EXPAND", (java.awt.Paint) color4);
        piePlot3D1.setShadowXOffset((double) 2019L);
        java.awt.Paint paint8 = piePlot3D1.getLabelLinkPaint();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean1 = statisticalLineAndShapeRenderer0.getDrawOutlines();
        statisticalLineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(false);
        java.lang.Object obj4 = statisticalLineAndShapeRenderer0.clone();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis7.setInverted(true);
        boolean boolean10 = numberAxis7.isAxisLineVisible();
        boolean boolean11 = numberAxis7.getAutoRangeStickyZero();
        java.awt.Stroke stroke12 = numberAxis7.getAxisLineStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis15.setInverted(true);
        boolean boolean18 = numberAxis15.isAxisLineVisible();
        boolean boolean19 = numberAxis15.getAutoRangeStickyZero();
        java.awt.Stroke stroke20 = numberAxis15.getAxisLineStroke();
        categoryPlot13.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis15);
        org.jfree.chart.axis.AxisLocation axisLocation23 = categoryPlot13.getRangeAxisLocation(0);
        float float24 = categoryPlot13.getBackgroundAlpha();
        numberAxis7.setPlot((org.jfree.chart.plot.Plot) categoryPlot13);
        org.jfree.chart.block.BlockContainer blockContainer26 = new org.jfree.chart.block.BlockContainer();
        blockContainer26.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer32 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder37 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer32.setFrame((org.jfree.chart.block.BlockFrame) blockBorder37);
        blockContainer26.add((org.jfree.chart.block.Block) blockContainer32);
        java.awt.Graphics2D graphics2D40 = null;
        org.jfree.chart.util.Size2D size2D41 = blockContainer32.arrange(graphics2D40);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D45 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D41, (double) '#', (double) 1.0f, rectangleAnchor44);
        try {
            statisticalLineAndShapeRenderer0.drawOutline(graphics2D5, categoryPlot13, rectangle2D45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 1.0f + "'", float24 == 1.0f);
        org.junit.Assert.assertNotNull(size2D41);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
        org.junit.Assert.assertNotNull(rectangle2D45);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(1.0d, (double) (short) -1);
        boolean boolean3 = stackedBarRenderer3D2.isDrawBarOutline();
        double double4 = stackedBarRenderer3D2.getYOffset();
        stackedBarRenderer3D2.setItemLabelAnchorOffset((double) (byte) 0);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D(pieDataset7);
        piePlot3D8.setDepthFactor((double) (byte) 1);
        piePlot3D8.setDepthFactor(0.0d);
        java.awt.Stroke stroke13 = piePlot3D8.getLabelLinkStroke();
        double double14 = piePlot3D8.getShadowXOffset();
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        int int16 = color15.getTransparency();
        piePlot3D8.setLabelLinkPaint((java.awt.Paint) color15);
        stackedBarRenderer3D2.setWallPaint((java.awt.Paint) color15);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.0d) + "'", double4 == (-1.0d));
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("{0}");
        labelBlock1.setToolTipText("poly");
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer();
        blockContainer5.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer11 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder16 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer11.setFrame((org.jfree.chart.block.BlockFrame) blockBorder16);
        blockContainer5.add((org.jfree.chart.block.Block) blockContainer11);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.util.Size2D size2D20 = blockContainer11.arrange(graphics2D19);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D24 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D20, (double) '#', (double) 1.0f, rectangleAnchor23);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset25 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range26 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset25);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer29 = null;
        org.jfree.chart.plot.PolarPlot polarPlot30 = new org.jfree.chart.plot.PolarPlot(xYDataset27, valueAxis28, polarItemRenderer29);
        defaultCategoryDataset25.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot30);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D34 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(1.0d, (double) (short) -1);
        boolean boolean35 = stackedBarRenderer3D34.isDrawBarOutline();
        boolean boolean36 = polarPlot30.equals((java.lang.Object) stackedBarRenderer3D34);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer37 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator39 = null;
        statisticalLineAndShapeRenderer37.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator39, true);
        statisticalLineAndShapeRenderer37.setSeriesVisibleInLegend(0, (java.lang.Boolean) true, true);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D48 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(1.0d, (double) (short) -1);
        boolean boolean49 = stackedBarRenderer3D48.isDrawBarOutline();
        java.awt.Paint paint50 = stackedBarRenderer3D48.getWallPaint();
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator52 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("({0}, {1}) = {3} - {4}");
        stackedBarRenderer3D48.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator52);
        statisticalLineAndShapeRenderer37.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator52);
        stackedBarRenderer3D34.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator52);
        java.awt.Paint paint56 = stackedBarRenderer3D34.getWallPaint();
        try {
            java.lang.Object obj57 = labelBlock1.draw(graphics2D4, rectangle2D24, (java.lang.Object) stackedBarRenderer3D34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(size2D20);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertNull(range26);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNotNull(paint56);
    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test268");
//        java.util.TimeZone timeZone0 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
//        org.junit.Assert.assertNull(timeZone0);
//    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        boolean boolean2 = categoryAxis3D0.equals((java.lang.Object) textAnchor1);
        categoryAxis3D0.setMaximumCategoryLabelWidthRatio((float) 60000L);
        categoryAxis3D0.setFixedDimension(0.2d);
        int int7 = categoryAxis3D0.getMaximumCategoryLabelLines();
        categoryAxis3D0.setCategoryLabelPositionOffset(28);
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Color color2 = java.awt.Color.getColor("hi!", color1);
        java.lang.String str3 = color1.toString();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java.awt.Color[r=0,g=128,b=128]" + "'", str3.equals("java.awt.Color[r=0,g=128,b=128]"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean1 = statisticalLineAndShapeRenderer0.getDrawOutlines();
        statisticalLineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(false);
        java.lang.Object obj4 = statisticalLineAndShapeRenderer0.clone();
        java.awt.Stroke stroke5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        statisticalLineAndShapeRenderer0.setBaseStroke(stroke5);
        boolean boolean9 = statisticalLineAndShapeRenderer0.getItemShapeVisible((int) '4', (int) (byte) 10);
        java.awt.Font font11 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        statisticalLineAndShapeRenderer0.setSeriesItemLabelFont((int) 'a', font11);
        java.lang.Boolean boolean14 = statisticalLineAndShapeRenderer0.getSeriesLinesVisible(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = statisticalLineAndShapeRenderer0.getNegativeItemLabelPosition(6, 255);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNull(boolean14);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDepthFactor((double) (byte) 1);
        piePlot3D1.setDepthFactor(0.0d);
        java.awt.Stroke stroke6 = piePlot3D1.getLabelLinkStroke();
        double double7 = piePlot3D1.getShadowXOffset();
        java.lang.String str8 = piePlot3D1.getNoDataMessage();
        java.awt.Paint paint9 = piePlot3D1.getBaseSectionOutlinePaint();
        org.jfree.data.general.PieDataset pieDataset10 = null;
        piePlot3D1.setDataset(pieDataset10);
        org.jfree.chart.plot.Plot plot12 = piePlot3D1.getParent();
        piePlot3D1.setShadowYOffset((double) 1577865599999L);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(plot12);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        java.awt.Font font1 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer2.setDrawOutlines(true);
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer2.setBasePaint((java.awt.Paint) color5, false);
        org.jfree.chart.text.TextMeasurer textMeasurer9 = null;
        org.jfree.chart.text.TextBlock textBlock10 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color5, (float) (byte) -1, textMeasurer9);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor14 = null;
        java.awt.Shape shape18 = textBlock10.calculateBounds(graphics2D11, (float) 1, 100.0f, textBlockAnchor14, (float) 3, (float) (short) -1, (double) 0);
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape18, (double) (-1.0f), 3.0d);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer22 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean23 = statisticalLineAndShapeRenderer22.getDrawOutlines();
        statisticalLineAndShapeRenderer22.setAutoPopulateSeriesFillPaint(false);
        java.lang.Object obj26 = statisticalLineAndShapeRenderer22.clone();
        java.awt.Stroke stroke27 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        statisticalLineAndShapeRenderer22.setBaseStroke(stroke27);
        statisticalLineAndShapeRenderer22.setBaseItemLabelsVisible(false, false);
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        statisticalLineAndShapeRenderer22.setBaseFillPaint((java.awt.Paint) color32);
        org.jfree.chart.title.LegendGraphic legendGraphic34 = new org.jfree.chart.title.LegendGraphic(shape21, (java.awt.Paint) color32);
        java.awt.Color color35 = java.awt.Color.LIGHT_GRAY;
        org.jfree.chart.title.LegendGraphic legendGraphic36 = new org.jfree.chart.title.LegendGraphic(shape21, (java.awt.Paint) color35);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(textBlock10);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(color35);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset2, valueAxis3, polarItemRenderer4);
        defaultCategoryDataset0.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot5);
        int int7 = defaultCategoryDataset0.getColumnCount();
        org.jfree.data.general.PieDataset pieDataset9 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, (java.lang.Comparable) 0.35d);
        org.jfree.data.general.DatasetGroup datasetGroup10 = defaultCategoryDataset0.getGroup();
        org.jfree.data.general.PieDataset pieDataset12 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, (java.lang.Comparable) 1577865599999L);
        java.util.List list13 = defaultCategoryDataset0.getRowKeys();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(pieDataset9);
        org.junit.Assert.assertNotNull(datasetGroup10);
        org.junit.Assert.assertNotNull(pieDataset12);
        org.junit.Assert.assertNotNull(list13);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset2, valueAxis3, polarItemRenderer4);
        defaultCategoryDataset0.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot5);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo8);
        java.awt.geom.Point2D point2D10 = null;
        polarPlot5.zoomDomainAxes((double) '#', plotRenderingInfo9, point2D10);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo12 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo12);
        plotRenderingInfo9.addSubplotInfo(plotRenderingInfo13);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = plotRenderingInfo9.getSubplotInfo((int) (byte) 0);
        org.jfree.chart.renderer.RendererState rendererState17 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = rendererState17.getInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = rendererState17.getInfo();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNotNull(plotRenderingInfo16);
        org.junit.Assert.assertNotNull(plotRenderingInfo18);
        org.junit.Assert.assertNotNull(plotRenderingInfo19);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_CENTER", timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        boolean boolean1 = textTitle0.getExpandToFitSpace();
        java.lang.String str2 = textTitle0.getURLText();
        java.lang.Object obj3 = textTitle0.clone();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long1 = segmentedTimeline0.getStartTime();
        int int2 = segmentedTimeline0.getSegmentsIncluded();
        long long5 = segmentedTimeline0.getExceptionSegmentCount(0L, (-1L));
        long long6 = segmentedTimeline0.getSegmentsGroupSize();
        int int7 = segmentedTimeline0.getSegmentsIncluded();
        org.jfree.chart.ui.ProjectInfo projectInfo8 = org.jfree.chart.JFreeChart.INFO;
        boolean boolean9 = segmentedTimeline0.equals((java.lang.Object) projectInfo8);
        int int10 = segmentedTimeline0.getGroupSegmentCount();
        long long11 = segmentedTimeline0.getSegmentsIncludedSize();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-2208927600000L) + "'", long1 == (-2208927600000L));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28 + "'", int2 == 28);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 86400000L + "'", long6 == 86400000L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 28 + "'", int7 == 28);
        org.junit.Assert.assertNotNull(projectInfo8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 96 + "'", int10 == 96);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 25200000L + "'", long11 == 25200000L);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDepthFactor((double) (byte) 1);
        piePlot3D1.setDepthFactor(0.0d);
        java.awt.Stroke stroke6 = piePlot3D1.getLabelLinkStroke();
        double double7 = piePlot3D1.getShadowXOffset();
        java.lang.String str8 = piePlot3D1.getNoDataMessage();
        java.awt.Shape shape9 = piePlot3D1.getLegendItemShape();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer10 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer10.setDrawOutlines(true);
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer10.setBasePaint((java.awt.Paint) color13, false);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot(xYDataset17, valueAxis18, polarItemRenderer19);
        java.lang.Object obj21 = null;
        boolean boolean22 = polarPlot20.equals(obj21);
        int int23 = polarPlot20.getSeriesCount();
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        polarPlot20.setAngleLabelPaint((java.awt.Paint) color24);
        statisticalLineAndShapeRenderer10.setSeriesFillPaint(2, (java.awt.Paint) color24);
        piePlot3D1.setLabelPaint((java.awt.Paint) color24);
        java.awt.Paint paint28 = piePlot3D1.getLabelBackgroundPaint();
        piePlot3D1.setIgnoreNullValues(false);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(paint28);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset0, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDepthFactor((double) (byte) 1);
        piePlot3D1.setDepthFactor(0.0d);
        piePlot3D1.setInteriorGap((double) 0.0f);
        java.awt.Shape shape8 = piePlot3D1.getLegendItemShape();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer9 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = statisticalLineAndShapeRenderer9.getBaseItemLabelGenerator();
        statisticalLineAndShapeRenderer9.setBaseSeriesVisibleInLegend(false);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D14 = new org.jfree.chart.plot.PiePlot3D(pieDataset13);
        java.awt.Font font15 = piePlot3D14.getLabelFont();
        statisticalLineAndShapeRenderer9.setBaseItemLabelFont(font15);
        piePlot3D1.setNoDataMessageFont(font15);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNull(categoryItemLabelGenerator10);
        org.junit.Assert.assertNotNull(font15);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDepthFactor((double) (byte) 1);
        piePlot3D1.setDepthFactor(0.0d);
        java.awt.Stroke stroke6 = piePlot3D1.getLabelLinkStroke();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        piePlot3D1.setDataset(pieDataset7);
        java.lang.Object obj9 = piePlot3D1.clone();
        double double10 = piePlot3D1.getLabelLinkMargin();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis12.setInverted(true);
        boolean boolean15 = numberAxis12.isAxisLineVisible();
        boolean boolean16 = numberAxis12.getAutoRangeStickyZero();
        java.awt.Font font17 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        numberAxis12.setTickLabelFont(font17);
        piePlot3D1.setLabelFont(font17);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.05d + "'", double10 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(font17);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        java.awt.Image image0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE;
        org.junit.Assert.assertNull(image0);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset2, valueAxis3, polarItemRenderer4);
        defaultCategoryDataset0.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot5);
        java.awt.Paint paint7 = polarPlot5.getRadiusGridlinePaint();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement0.clear();
        flowArrangement0.clear();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset3 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset3);
        defaultCategoryDataset3.removeColumn((java.lang.Comparable) 100L);
        defaultCategoryDataset3.removeColumn((java.lang.Comparable) 0.2d);
        java.lang.Comparable comparable9 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer10 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement0, (org.jfree.data.general.Dataset) defaultCategoryDataset3, comparable9);
        try {
            defaultCategoryDataset3.removeColumn(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range4);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = statisticalLineAndShapeRenderer0.getBaseItemLabelGenerator();
        statisticalLineAndShapeRenderer0.setSeriesItemLabelsVisible(15, (java.lang.Boolean) true);
        java.awt.Paint paint6 = statisticalLineAndShapeRenderer0.getSeriesPaint(0);
        java.awt.Stroke stroke7 = statisticalLineAndShapeRenderer0.getBaseOutlineStroke();
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        int int11 = xYPlot9.indexOf(xYDataset10);
        xYPlot9.setRangeGridlinesVisible(false);
        java.awt.Paint paint14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot9.setRangeTickBandPaint(paint14);
        try {
            statisticalLineAndShapeRenderer0.setSeriesPaint((-1), paint14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryItemLabelGenerator1);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("TextBlockAnchor.TOP_CENTER");
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean1 = statisticalLineAndShapeRenderer0.getDrawOutlines();
        statisticalLineAndShapeRenderer0.setBaseSeriesVisible(true, false);
        java.awt.Font font6 = null;
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) numberAxis9, polarItemRenderer10);
        float float12 = polarPlot11.getBackgroundAlpha();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer13 = polarPlot11.getRenderer();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font6, (org.jfree.chart.plot.Plot) polarPlot11, false);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent18 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) false, jFreeChart15, 6, 0);
        org.jfree.chart.title.LegendTitle legendTitle19 = jFreeChart15.getLegend();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = jFreeChart15.getPadding();
        try {
            java.awt.image.BufferedImage bufferedImage23 = jFreeChart15.createBufferedImage(96, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (96) and height (0) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 1.0f + "'", float12 == 1.0f);
        org.junit.Assert.assertNull(polarItemRenderer13);
        org.junit.Assert.assertNull(legendTitle19);
        org.junit.Assert.assertNotNull(rectangleInsets20);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((double) (byte) 100);
        categoryAxis3D0.setCategoryLabelPositions(categoryLabelPositions2);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) numberAxis6, polarItemRenderer7);
        org.jfree.data.general.DatasetGroup datasetGroup9 = polarPlot8.getDatasetGroup();
        java.awt.Paint paint10 = polarPlot8.getAngleGridlinePaint();
        boolean boolean11 = categoryLabelPositions2.equals((java.lang.Object) polarPlot8);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset14 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range15 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset14);
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer18 = null;
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot(xYDataset16, valueAxis17, polarItemRenderer18);
        defaultCategoryDataset14.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot19);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo22 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo22);
        java.awt.geom.Point2D point2D24 = null;
        polarPlot19.zoomDomainAxes((double) '#', plotRenderingInfo23, point2D24);
        org.jfree.chart.block.BlockContainer blockContainer26 = new org.jfree.chart.block.BlockContainer();
        blockContainer26.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer32 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder37 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer32.setFrame((org.jfree.chart.block.BlockFrame) blockBorder37);
        blockContainer26.add((org.jfree.chart.block.Block) blockContainer32);
        java.awt.Graphics2D graphics2D40 = null;
        org.jfree.chart.util.Size2D size2D41 = blockContainer32.arrange(graphics2D40);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D45 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D41, (double) '#', (double) 1.0f, rectangleAnchor44);
        plotRenderingInfo23.setPlotArea(rectangle2D45);
        java.awt.geom.Point2D point2D47 = null;
        polarPlot8.zoomRangeAxes((double) (-2208960000000L), 90.0d, plotRenderingInfo23, point2D47);
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertNull(datasetGroup9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNotNull(size2D41);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
        org.junit.Assert.assertNotNull(rectangle2D45);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.Range range3 = numberAxis2.getDefaultAutoRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint(range3, (double) (-1L));
        org.jfree.data.Range range6 = org.jfree.data.Range.combine(range0, range3);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint(range6, 1.0d);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(range6);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        java.awt.Paint paint0 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean1 = statisticalLineAndShapeRenderer0.getDrawOutlines();
        statisticalLineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(false);
        java.awt.Stroke stroke5 = statisticalLineAndShapeRenderer0.lookupSeriesStroke(28);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = statisticalLineAndShapeRenderer0.getBaseNegativeItemLabelPosition();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D(pieDataset7);
        piePlot3D8.setDepthFactor((double) (byte) 1);
        piePlot3D8.setDepthFactor(0.0d);
        java.awt.Stroke stroke13 = piePlot3D8.getLabelLinkStroke();
        double double14 = piePlot3D8.getShadowXOffset();
        java.lang.String str15 = piePlot3D8.getNoDataMessage();
        java.awt.Paint paint16 = piePlot3D8.getBaseSectionOutlinePaint();
        org.jfree.data.general.PieDataset pieDataset17 = null;
        piePlot3D8.setDataset(pieDataset17);
        java.awt.Stroke stroke19 = piePlot3D8.getBaseSectionOutlineStroke();
        statisticalLineAndShapeRenderer0.setBaseStroke(stroke19, true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent22 = null;
        statisticalLineAndShapeRenderer0.notifyListeners(rendererChangeEvent22);
        java.awt.Font font25 = null;
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer29 = null;
        org.jfree.chart.plot.PolarPlot polarPlot30 = new org.jfree.chart.plot.PolarPlot(xYDataset26, (org.jfree.chart.axis.ValueAxis) numberAxis28, polarItemRenderer29);
        float float31 = polarPlot30.getBackgroundAlpha();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer32 = polarPlot30.getRenderer();
        org.jfree.chart.JFreeChart jFreeChart34 = new org.jfree.chart.JFreeChart("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font25, (org.jfree.chart.plot.Plot) polarPlot30, false);
        jFreeChart34.setTitle("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]");
        java.awt.Image image37 = null;
        jFreeChart34.setBackgroundImage(image37);
        org.jfree.chart.title.TextTitle textTitle39 = null;
        jFreeChart34.setTitle(textTitle39);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent43 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) statisticalLineAndShapeRenderer0, jFreeChart34, 2, (int) (byte) 0);
        java.lang.Object obj44 = jFreeChart34.getTextAntiAlias();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + 1.0f + "'", float31 == 1.0f);
        org.junit.Assert.assertNull(polarItemRenderer32);
        org.junit.Assert.assertNull(obj44);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean1 = statisticalLineAndShapeRenderer0.getDrawOutlines();
        statisticalLineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(false);
        java.lang.Object obj4 = statisticalLineAndShapeRenderer0.clone();
        java.awt.Stroke stroke5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        statisticalLineAndShapeRenderer0.setBaseStroke(stroke5);
        statisticalLineAndShapeRenderer0.setBaseItemLabelsVisible(false, false);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        statisticalLineAndShapeRenderer0.setBaseFillPaint((java.awt.Paint) color10);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = null;
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font17 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer18 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer18.setDrawOutlines(true);
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer18.setBasePaint((java.awt.Paint) color21, false);
        org.jfree.chart.text.TextMeasurer textMeasurer25 = null;
        org.jfree.chart.text.TextBlock textBlock26 = org.jfree.chart.text.TextUtilities.createTextBlock("", font17, (java.awt.Paint) color21, (float) (byte) -1, textMeasurer25);
        numberAxis15.setTickMarkPaint((java.awt.Paint) color21);
        org.jfree.chart.plot.Marker marker28 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset29 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset29);
        org.jfree.data.xy.XYDataset xYDataset31 = null;
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer33 = null;
        org.jfree.chart.plot.PolarPlot polarPlot34 = new org.jfree.chart.plot.PolarPlot(xYDataset31, valueAxis32, polarItemRenderer33);
        defaultCategoryDataset29.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot34);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo37 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo37);
        java.awt.geom.Point2D point2D39 = null;
        polarPlot34.zoomDomainAxes((double) '#', plotRenderingInfo38, point2D39);
        org.jfree.chart.block.BlockContainer blockContainer41 = new org.jfree.chart.block.BlockContainer();
        blockContainer41.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer47 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder52 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer47.setFrame((org.jfree.chart.block.BlockFrame) blockBorder52);
        blockContainer41.add((org.jfree.chart.block.Block) blockContainer47);
        java.awt.Graphics2D graphics2D55 = null;
        org.jfree.chart.util.Size2D size2D56 = blockContainer47.arrange(graphics2D55);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor59 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D60 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D56, (double) '#', (double) 1.0f, rectangleAnchor59);
        plotRenderingInfo38.setPlotArea(rectangle2D60);
        statisticalLineAndShapeRenderer0.drawRangeMarker(graphics2D12, categoryPlot13, (org.jfree.chart.axis.ValueAxis) numberAxis15, marker28, rectangle2D60);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity63 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D60);
        java.lang.Object obj64 = legendItemEntity63.clone();
        legendItemEntity63.setURLText("Range[0.0,1.0]");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(textBlock26);
        org.junit.Assert.assertNull(range30);
        org.junit.Assert.assertNotNull(size2D56);
        org.junit.Assert.assertNotNull(rectangleAnchor59);
        org.junit.Assert.assertNotNull(rectangle2D60);
        org.junit.Assert.assertNotNull(obj64);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        int int2 = xYPlot0.indexOf(xYDataset1);
        xYPlot0.setDomainCrosshairLockedOnData(true);
        xYPlot0.setWeight((int) '#');
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint8 = xYPlot7.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = xYPlot7.getRangeAxisEdge();
        java.awt.Paint paint10 = xYPlot7.getDomainGridlinePaint();
        xYPlot0.setRangeCrosshairPaint(paint10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.event.TitleChangeListener titleChangeListener1 = null;
        textTitle0.removeChangeListener(titleChangeListener1);
        java.lang.String str3 = textTitle0.getURLText();
        textTitle0.setText("org.jfree.chart.event.ChartProgressEvent[source=false]");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = null;
        statisticalLineAndShapeRenderer0.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator2, true);
        statisticalLineAndShapeRenderer0.setSeriesVisibleInLegend(0, (java.lang.Boolean) true, true);
        java.lang.Boolean boolean10 = statisticalLineAndShapeRenderer0.getSeriesVisibleInLegend(100);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        int int12 = color11.getTransparency();
        java.awt.Color color13 = color11.darker();
        statisticalLineAndShapeRenderer0.setErrorIndicatorPaint((java.awt.Paint) color11);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        int int17 = xYPlot15.indexOf(xYDataset16);
        org.jfree.chart.util.Layer layer19 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection20 = xYPlot15.getRangeMarkers(6, layer19);
        org.jfree.chart.axis.AxisSpace axisSpace21 = xYPlot15.getFixedRangeAxisSpace();
        xYPlot15.clearDomainAxes();
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font26 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer27 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer27.setDrawOutlines(true);
        java.awt.Color color30 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer27.setBasePaint((java.awt.Paint) color30, false);
        org.jfree.chart.text.TextMeasurer textMeasurer34 = null;
        org.jfree.chart.text.TextBlock textBlock35 = org.jfree.chart.text.TextUtilities.createTextBlock("", font26, (java.awt.Paint) color30, (float) (byte) -1, textMeasurer34);
        numberAxis24.setTickMarkPaint((java.awt.Paint) color30);
        numberAxis24.configure();
        numberAxis24.setFixedAutoRange((double) (-1L));
        java.awt.Color color40 = org.jfree.chart.ChartColor.LIGHT_RED;
        numberAxis24.setLabelPaint((java.awt.Paint) color40);
        xYPlot15.setRangeZeroBaselinePaint((java.awt.Paint) color40);
        boolean boolean43 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color11, (java.awt.Paint) color40);
        org.junit.Assert.assertNull(boolean10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(layer19);
        org.junit.Assert.assertNull(collection20);
        org.junit.Assert.assertNull(axisSpace21);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(textBlock35);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("SortOrder.DESCENDING", timeZone1);
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = null;
        try {
            java.util.Date date4 = dateAxis2.calculateHighestVisibleTickValue(dateTickUnit3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean1 = statisticalLineAndShapeRenderer0.getDrawOutlines();
        statisticalLineAndShapeRenderer0.setBaseSeriesVisible(true, false);
        java.awt.Font font6 = null;
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) numberAxis9, polarItemRenderer10);
        float float12 = polarPlot11.getBackgroundAlpha();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer13 = polarPlot11.getRenderer();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font6, (org.jfree.chart.plot.Plot) polarPlot11, false);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent18 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) false, jFreeChart15, 6, 0);
        java.lang.String str19 = chartProgressEvent18.toString();
        int int20 = chartProgressEvent18.getType();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 1.0f + "'", float12 == 1.0f);
        org.junit.Assert.assertNull(polarItemRenderer13);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.jfree.chart.event.ChartProgressEvent[source=false]" + "'", str19.equals("org.jfree.chart.event.ChartProgressEvent[source=false]"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = statisticalLineAndShapeRenderer0.getBaseItemLabelGenerator();
        statisticalLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = null;
        statisticalLineAndShapeRenderer0.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition5, true);
        org.junit.Assert.assertNull(categoryItemLabelGenerator1);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset2, valueAxis3, polarItemRenderer4);
        defaultCategoryDataset0.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot5);
        int int7 = defaultCategoryDataset0.getColumnCount();
        org.jfree.data.general.PieDataset pieDataset9 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, (java.lang.Comparable) 0.35d);
        org.jfree.data.general.DatasetGroup datasetGroup10 = defaultCategoryDataset0.getGroup();
        org.jfree.data.general.DatasetGroup datasetGroup11 = null;
        try {
            defaultCategoryDataset0.setGroup(datasetGroup11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'group' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(pieDataset9);
        org.junit.Assert.assertNotNull(datasetGroup10);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = statisticalLineAndShapeRenderer0.getBaseItemLabelGenerator();
        statisticalLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D5 = new org.jfree.chart.plot.PiePlot3D(pieDataset4);
        java.awt.Font font6 = piePlot3D5.getLabelFont();
        statisticalLineAndShapeRenderer0.setBaseItemLabelFont(font6);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = statisticalLineAndShapeRenderer0.getNegativeItemLabelPosition((int) (short) 0, 0);
        double double11 = itemLabelPosition10.getAngle();
        org.junit.Assert.assertNull(categoryItemLabelGenerator1);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis2.setInverted(true);
        boolean boolean5 = numberAxis2.isAxisLineVisible();
        boolean boolean6 = numberAxis2.getAutoRangeStickyZero();
        java.awt.Stroke stroke7 = numberAxis2.getAxisLineStroke();
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis2);
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot0.getRangeAxisLocation(0);
        float float11 = categoryPlot0.getBackgroundAlpha();
        org.jfree.chart.axis.AxisSpace axisSpace12 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation14 = categoryPlot0.getRangeAxisLocation(3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 1.0f + "'", float11 == 1.0f);
        org.junit.Assert.assertNull(axisSpace12);
        org.junit.Assert.assertNotNull(axisLocation14);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand5 = numberAxis4.getMarkerBand();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = numberAxis4.getMarkerBand();
        numberAxis4.setRangeAboutValue((double) 100L, 12.0d);
        org.jfree.data.general.DatasetGroup datasetGroup11 = new org.jfree.data.general.DatasetGroup("");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer12 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = statisticalLineAndShapeRenderer12.getBaseItemLabelGenerator();
        statisticalLineAndShapeRenderer12.setBaseSeriesVisibleInLegend(false);
        statisticalLineAndShapeRenderer12.setDrawOutlines(false);
        statisticalLineAndShapeRenderer12.setAutoPopulateSeriesOutlineStroke(true);
        boolean boolean20 = datasetGroup11.equals((java.lang.Object) statisticalLineAndShapeRenderer12);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer12);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNull(markerAxisBand5);
        org.junit.Assert.assertNull(markerAxisBand6);
        org.junit.Assert.assertNull(categoryItemLabelGenerator13);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        boolean boolean4 = polarPlot3.isAngleGridlinesVisible();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        int int1 = defaultBoxAndWhiskerCategoryDataset0.getRowCount();
        org.jfree.data.general.DatasetGroup datasetGroup3 = new org.jfree.data.general.DatasetGroup("");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer4 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = statisticalLineAndShapeRenderer4.getBaseItemLabelGenerator();
        statisticalLineAndShapeRenderer4.setBaseSeriesVisibleInLegend(false);
        statisticalLineAndShapeRenderer4.setDrawOutlines(false);
        statisticalLineAndShapeRenderer4.setAutoPopulateSeriesOutlineStroke(true);
        boolean boolean12 = datasetGroup3.equals((java.lang.Object) statisticalLineAndShapeRenderer4);
        defaultBoxAndWhiskerCategoryDataset0.setGroup(datasetGroup3);
        try {
            java.lang.Number number16 = defaultBoxAndWhiskerCategoryDataset0.getValue((int) (byte) 100, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNull(categoryItemLabelGenerator5);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit((-16744320), (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DateTickUnit.getMillisecondCount() : unit must be one of the constants YEAR, MONTH, DAY, HOUR, MINUTE, SECOND or MILLISECOND defined in the DateTickUnit class. Do *not* use the constants defined in java.util.Calendar.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        java.awt.Font font1 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer2.setDrawOutlines(true);
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer2.setBasePaint((java.awt.Paint) color5, false);
        org.jfree.chart.text.TextMeasurer textMeasurer9 = null;
        org.jfree.chart.text.TextBlock textBlock10 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color5, (float) (byte) -1, textMeasurer9);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor14 = null;
        java.awt.Shape shape18 = textBlock10.calculateBounds(graphics2D11, (float) 1, 100.0f, textBlockAnchor14, (float) 3, (float) (short) -1, (double) 0);
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape18, (double) (-1.0f), 3.0d);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer22 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean23 = statisticalLineAndShapeRenderer22.getDrawOutlines();
        statisticalLineAndShapeRenderer22.setAutoPopulateSeriesFillPaint(false);
        java.lang.Object obj26 = statisticalLineAndShapeRenderer22.clone();
        java.awt.Stroke stroke27 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        statisticalLineAndShapeRenderer22.setBaseStroke(stroke27);
        statisticalLineAndShapeRenderer22.setBaseItemLabelsVisible(false, false);
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        statisticalLineAndShapeRenderer22.setBaseFillPaint((java.awt.Paint) color32);
        org.jfree.chart.title.LegendGraphic legendGraphic34 = new org.jfree.chart.title.LegendGraphic(shape21, (java.awt.Paint) color32);
        java.awt.Shape shape35 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor36 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.Shape shape39 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape35, rectangleAnchor36, (double) (-2208927600000L), (double) (byte) 0);
        legendGraphic34.setShapeAnchor(rectangleAnchor36);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(textBlock10);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(rectangleAnchor36);
        org.junit.Assert.assertNotNull(shape39);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset3 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset3);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset5, valueAxis6, polarItemRenderer7);
        defaultCategoryDataset3.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot8);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo11);
        java.awt.geom.Point2D point2D13 = null;
        polarPlot8.zoomDomainAxes((double) '#', plotRenderingInfo12, point2D13);
        org.jfree.chart.block.BlockContainer blockContainer15 = new org.jfree.chart.block.BlockContainer();
        blockContainer15.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer21 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder26 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer21.setFrame((org.jfree.chart.block.BlockFrame) blockBorder26);
        blockContainer15.add((org.jfree.chart.block.Block) blockContainer21);
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.util.Size2D size2D30 = blockContainer21.arrange(graphics2D29);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D34 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D30, (double) '#', (double) 1.0f, rectangleAnchor33);
        plotRenderingInfo12.setPlotArea(rectangle2D34);
        categoryPlot0.handleClick(0, 0, plotRenderingInfo12);
        org.jfree.chart.util.Layer layer38 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection39 = categoryPlot0.getRangeMarkers(0, layer38);
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis43.setInverted(true);
        boolean boolean46 = numberAxis43.isAxisLineVisible();
        boolean boolean47 = numberAxis43.getAutoRangeStickyZero();
        java.awt.Stroke stroke48 = numberAxis43.getAxisLineStroke();
        categoryPlot41.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis43);
        org.jfree.chart.axis.AxisLocation axisLocation51 = categoryPlot41.getRangeAxisLocation(0);
        categoryPlot0.setDomainAxisLocation((int) (short) 0, axisLocation51);
        org.jfree.chart.plot.XYPlot xYPlot54 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint55 = xYPlot54.getDomainCrosshairPaint();
        int int56 = xYPlot54.getSeriesCount();
        java.awt.Paint paint57 = xYPlot54.getRangeZeroBaselinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation58 = xYPlot54.getRangeAxisLocation();
        categoryPlot0.setDomainAxisLocation(8, axisLocation58, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets61 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double63 = rectangleInsets61.calculateBottomOutset((double) 'a');
        double double65 = rectangleInsets61.calculateLeftInset((double) 28);
        categoryPlot0.setAxisOffset(rectangleInsets61);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNotNull(size2D30);
        org.junit.Assert.assertNotNull(rectangleAnchor33);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNotNull(layer38);
        org.junit.Assert.assertNull(collection39);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(axisLocation51);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertNotNull(axisLocation58);
        org.junit.Assert.assertNotNull(rectangleInsets61);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 1.0d + "'", double63 == 1.0d);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 1.0d + "'", double65 == 1.0d);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset2, valueAxis3, polarItemRenderer4);
        defaultCategoryDataset0.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot5);
        int int7 = defaultCategoryDataset0.getColumnCount();
        org.jfree.data.general.PieDataset pieDataset9 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, (java.lang.Comparable) 0.35d);
        org.jfree.data.general.DatasetGroup datasetGroup10 = defaultCategoryDataset0.getGroup();
        java.lang.Number number11 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(pieDataset9);
        org.junit.Assert.assertNotNull(datasetGroup10);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 0.0d + "'", number11.equals(0.0d));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainCrosshairPaint();
        xYPlot0.clearRangeAxes();
        xYPlot0.mapDatasetToDomainAxis((int) '4', (int) (short) 0);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D7 = new org.jfree.chart.plot.PiePlot3D(pieDataset6);
        piePlot3D7.setDepthFactor((double) (byte) 1);
        piePlot3D7.setDepthFactor(0.0d);
        java.awt.Stroke stroke12 = piePlot3D7.getLabelLinkStroke();
        double double13 = piePlot3D7.getShadowXOffset();
        java.lang.String str14 = piePlot3D7.getNoDataMessage();
        java.awt.Shape shape15 = piePlot3D7.getLegendItemShape();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer16 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer16.setDrawOutlines(true);
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer16.setBasePaint((java.awt.Paint) color19, false);
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer25 = null;
        org.jfree.chart.plot.PolarPlot polarPlot26 = new org.jfree.chart.plot.PolarPlot(xYDataset23, valueAxis24, polarItemRenderer25);
        java.lang.Object obj27 = null;
        boolean boolean28 = polarPlot26.equals(obj27);
        int int29 = polarPlot26.getSeriesCount();
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        polarPlot26.setAngleLabelPaint((java.awt.Paint) color30);
        statisticalLineAndShapeRenderer16.setSeriesFillPaint(2, (java.awt.Paint) color30);
        piePlot3D7.setLabelPaint((java.awt.Paint) color30);
        java.awt.Paint paint34 = piePlot3D7.getLabelBackgroundPaint();
        xYPlot0.setRangeGridlinePaint(paint34);
        java.awt.Stroke stroke36 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        xYPlot0.setOutlineStroke(stroke36);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.0d + "'", double13 == 4.0d);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(stroke36);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((double) (-2208927600000L), numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean1 = statisticalLineAndShapeRenderer0.getDrawOutlines();
        statisticalLineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(false);
        java.lang.Object obj4 = statisticalLineAndShapeRenderer0.clone();
        java.awt.Stroke stroke5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        statisticalLineAndShapeRenderer0.setBaseStroke(stroke5);
        java.awt.Stroke stroke8 = statisticalLineAndShapeRenderer0.getSeriesStroke((int) (short) 0);
        statisticalLineAndShapeRenderer0.setBaseSeriesVisible(true, false);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D14 = new org.jfree.chart.plot.PiePlot3D(pieDataset13);
        piePlot3D14.setDepthFactor((double) (byte) 1);
        piePlot3D14.setDepthFactor(0.0d);
        piePlot3D14.setInteriorGap((double) 0.0f);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator21 = piePlot3D14.getURLGenerator();
        org.jfree.data.general.PieDataset pieDataset22 = piePlot3D14.getDataset();
        java.awt.Paint paint23 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        piePlot3D14.setShadowPaint(paint23);
        statisticalLineAndShapeRenderer0.setSeriesFillPaint(2019, paint23);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(stroke8);
        org.junit.Assert.assertNull(pieURLGenerator21);
        org.junit.Assert.assertNull(pieDataset22);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        java.awt.Paint paint2 = null;
        try {
            ringPlot1.setSeparatorPaint(paint2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer1 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean2 = statisticalLineAndShapeRenderer1.getDrawOutlines();
        statisticalLineAndShapeRenderer1.setAutoPopulateSeriesFillPaint(false);
        java.awt.Stroke stroke6 = statisticalLineAndShapeRenderer1.lookupSeriesStroke(28);
        lineAndShapeRenderer0.setBaseStroke(stroke6);
        java.awt.Paint paint9 = lineAndShapeRenderer0.getSeriesFillPaint((int) '#');
        java.awt.Stroke stroke12 = lineAndShapeRenderer0.getItemOutlineStroke(1, 10);
        org.jfree.chart.LegendItem legendItem15 = lineAndShapeRenderer0.getLegendItem((int) (short) 1, (int) (byte) -1);
        java.lang.Boolean boolean17 = lineAndShapeRenderer0.getSeriesShapesFilled((-1));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(legendItem15);
        org.junit.Assert.assertNull(boolean17);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.data.resources.DataPackageResources dataPackageResources0 = new org.jfree.data.resources.DataPackageResources();
        java.util.Set<java.lang.String> strSet1 = dataPackageResources0.keySet();
        boolean boolean3 = dataPackageResources0.containsKey("{0}");
        try {
            java.lang.String[] strArray5 = dataPackageResources0.getStringArray("");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.data.resources.DataPackageResources, key ");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(strSet1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.lang.Number number3 = defaultBoxAndWhiskerCategoryDataset0.getQ3Value((java.lang.Comparable) (byte) 1, (java.lang.Comparable) 100.0f);
        org.jfree.data.general.PieDataset pieDataset5 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0, 255);
        java.lang.Comparable comparable7 = null;
        java.lang.Number number8 = defaultBoxAndWhiskerCategoryDataset0.getMedianValue((java.lang.Comparable) 19.0d, comparable7);
        org.jfree.data.Range range10 = defaultBoxAndWhiskerCategoryDataset0.getRangeBounds(false);
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNotNull(pieDataset5);
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNotNull(range10);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.lang.Number number3 = defaultBoxAndWhiskerCategoryDataset0.getQ3Value((java.lang.Comparable) (byte) 1, (java.lang.Comparable) 100.0f);
        org.jfree.data.general.PieDataset pieDataset5 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0, 255);
        java.lang.Comparable comparable7 = null;
        java.lang.Number number8 = defaultBoxAndWhiskerCategoryDataset0.getMedianValue((java.lang.Comparable) 19.0d, comparable7);
        int int10 = defaultBoxAndWhiskerCategoryDataset0.getRowIndex((java.lang.Comparable) 60000L);
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNotNull(pieDataset5);
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        ringPlot1.setSeparatorsVisible(false);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.Font font6 = null;
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.jfree.chart.text.TextMeasurer textMeasurer9 = null;
        org.jfree.chart.text.TextBlock textBlock10 = org.jfree.chart.text.TextUtilities.createTextBlock("", font6, (java.awt.Paint) color7, (float) ' ', textMeasurer9);
        java.awt.image.ColorModel colorModel11 = null;
        java.awt.Rectangle rectangle12 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer13 = new org.jfree.chart.renderer.category.StackedBarRenderer();
        org.jfree.chart.block.BlockContainer blockContainer14 = new org.jfree.chart.block.BlockContainer();
        blockContainer14.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer20 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder25 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer20.setFrame((org.jfree.chart.block.BlockFrame) blockBorder25);
        blockContainer14.add((org.jfree.chart.block.Block) blockContainer20);
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.util.Size2D size2D29 = blockContainer20.arrange(graphics2D28);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor32 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D33 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D29, (double) '#', (double) 1.0f, rectangleAnchor32);
        boolean boolean34 = stackedBarRenderer13.equals((java.lang.Object) rectangle2D33);
        java.awt.geom.AffineTransform affineTransform35 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer36 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean37 = statisticalLineAndShapeRenderer36.getDrawOutlines();
        statisticalLineAndShapeRenderer36.setAutoPopulateSeriesFillPaint(false);
        java.awt.Stroke stroke41 = statisticalLineAndShapeRenderer36.lookupSeriesStroke(28);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition42 = statisticalLineAndShapeRenderer36.getBaseNegativeItemLabelPosition();
        org.jfree.data.general.PieDataset pieDataset43 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D44 = new org.jfree.chart.plot.PiePlot3D(pieDataset43);
        piePlot3D44.setDepthFactor((double) (byte) 1);
        piePlot3D44.setDepthFactor(0.0d);
        java.awt.Stroke stroke49 = piePlot3D44.getLabelLinkStroke();
        double double50 = piePlot3D44.getShadowXOffset();
        java.lang.String str51 = piePlot3D44.getNoDataMessage();
        java.awt.Paint paint52 = piePlot3D44.getBaseSectionOutlinePaint();
        org.jfree.data.general.PieDataset pieDataset53 = null;
        piePlot3D44.setDataset(pieDataset53);
        java.awt.Stroke stroke55 = piePlot3D44.getBaseSectionOutlineStroke();
        statisticalLineAndShapeRenderer36.setBaseStroke(stroke55, true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent58 = null;
        statisticalLineAndShapeRenderer36.notifyListeners(rendererChangeEvent58);
        java.awt.Font font61 = null;
        org.jfree.data.xy.XYDataset xYDataset62 = null;
        org.jfree.chart.axis.NumberAxis numberAxis64 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer65 = null;
        org.jfree.chart.plot.PolarPlot polarPlot66 = new org.jfree.chart.plot.PolarPlot(xYDataset62, (org.jfree.chart.axis.ValueAxis) numberAxis64, polarItemRenderer65);
        float float67 = polarPlot66.getBackgroundAlpha();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer68 = polarPlot66.getRenderer();
        org.jfree.chart.JFreeChart jFreeChart70 = new org.jfree.chart.JFreeChart("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font61, (org.jfree.chart.plot.Plot) polarPlot66, false);
        jFreeChart70.setTitle("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]");
        java.awt.Image image73 = null;
        jFreeChart70.setBackgroundImage(image73);
        org.jfree.chart.title.TextTitle textTitle75 = null;
        jFreeChart70.setTitle(textTitle75);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent79 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) statisticalLineAndShapeRenderer36, jFreeChart70, 2, (int) (byte) 0);
        int int80 = jFreeChart70.getBackgroundImageAlignment();
        java.awt.RenderingHints renderingHints81 = jFreeChart70.getRenderingHints();
        java.awt.PaintContext paintContext82 = color7.createContext(colorModel11, rectangle12, rectangle2D33, affineTransform35, renderingHints81);
        try {
            ringPlot1.drawBackground(graphics2D4, (java.awt.geom.Rectangle2D) rectangle12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(textBlock10);
        org.junit.Assert.assertNotNull(size2D29);
        org.junit.Assert.assertNotNull(rectangleAnchor32);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(itemLabelPosition42);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 4.0d + "'", double50 == 4.0d);
        org.junit.Assert.assertNull(str51);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertTrue("'" + float67 + "' != '" + 1.0f + "'", float67 == 1.0f);
        org.junit.Assert.assertNull(polarItemRenderer68);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 15 + "'", int80 == 15);
        org.junit.Assert.assertNotNull(renderingHints81);
        org.junit.Assert.assertNotNull(paintContext82);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        boolean boolean2 = categoryAxis3D0.equals((java.lang.Object) textAnchor1);
        categoryAxis3D0.setMaximumCategoryLabelWidthRatio((float) 60000L);
        categoryAxis3D0.setFixedDimension(0.2d);
        categoryAxis3D0.clearCategoryLabelToolTips();
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.RANGE;
        java.lang.String str1 = lengthConstraintType0.toString();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean3 = statisticalLineAndShapeRenderer2.getDrawOutlines();
        statisticalLineAndShapeRenderer2.setAutoPopulateSeriesFillPaint(false);
        java.lang.Object obj6 = statisticalLineAndShapeRenderer2.clone();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        statisticalLineAndShapeRenderer2.setBaseStroke(stroke7);
        boolean boolean9 = lengthConstraintType0.equals((java.lang.Object) stroke7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) boolean9);
        java.lang.String str11 = seriesChangeEvent10.toString();
        org.junit.Assert.assertNotNull(lengthConstraintType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleConstraintType.RANGE" + "'", str1.equals("RectangleConstraintType.RANGE"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=false]" + "'", str11.equals("org.jfree.data.general.SeriesChangeEvent[source=false]"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        int int2 = xYPlot0.indexOf(xYDataset1);
        boolean boolean3 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = xYPlot0.getRangeAxisEdge();
        java.awt.Paint paint5 = xYPlot0.getDomainCrosshairPaint();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("");
        taskSeries1.fireSeriesChanged();
        org.jfree.data.gantt.Task task4 = taskSeries1.get("{0}");
        org.jfree.data.gantt.Task task6 = taskSeries1.get("({0}, {1}) = {3} - {4}");
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        taskSeries1.addPropertyChangeListener(propertyChangeListener7);
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        taskSeries1.removePropertyChangeListener(propertyChangeListener9);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.gantt.Task task13 = new org.jfree.data.gantt.Task("", (org.jfree.data.time.TimePeriod) year12);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(4, 0);
        int int17 = month16.getMonth();
        int int18 = month16.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month16.next();
        task13.setDuration((org.jfree.data.time.TimePeriod) month16);
        taskSeries1.add(task13);
        org.junit.Assert.assertNull(task4);
        org.junit.Assert.assertNull(task6);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(xYDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font4 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer5 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer5.setDrawOutlines(true);
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer5.setBasePaint((java.awt.Paint) color8, false);
        org.jfree.chart.text.TextMeasurer textMeasurer12 = null;
        org.jfree.chart.text.TextBlock textBlock13 = org.jfree.chart.text.TextUtilities.createTextBlock("", font4, (java.awt.Paint) color8, (float) (byte) -1, textMeasurer12);
        numberAxis2.setTickMarkPaint((java.awt.Paint) color8);
        boolean boolean15 = numberAxis2.isInverted();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer16 = null;
        org.jfree.chart.plot.PolarPlot polarPlot17 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, polarItemRenderer16);
        numberAxis2.zoomRange((double) (-1.0f), (double) (short) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = numberAxis2.getLabelInsets();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent22 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis2);
        numberAxis2.setAutoRangeStickyZero(false);
        boolean boolean25 = numberAxis2.isNegativeArrowVisible();
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(textBlock13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainCrosshairPaint();
        int int2 = xYPlot0.getSeriesCount();
        org.jfree.chart.axis.AxisLocation axisLocation4 = null;
        xYPlot0.setRangeAxisLocation((int) (byte) 100, axisLocation4);
        java.awt.Paint paint6 = xYPlot0.getDomainCrosshairPaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.chart.block.BlockResult blockResult0 = new org.jfree.chart.block.BlockResult();
        org.jfree.chart.entity.EntityCollection entityCollection1 = blockResult0.getEntityCollection();
        org.jfree.chart.entity.EntityCollection entityCollection2 = blockResult0.getEntityCollection();
        org.junit.Assert.assertNull(entityCollection1);
        org.junit.Assert.assertNull(entityCollection2);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(1.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = stackedBarRenderer3D2.getGradientPaintTransformer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = stackedBarRenderer3D2.getBaseItemLabelGenerator();
        double double5 = stackedBarRenderer3D2.getItemMargin();
        org.junit.Assert.assertNotNull(gradientPaintTransformer3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean1 = statisticalLineAndShapeRenderer0.getDrawOutlines();
        statisticalLineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(false);
        java.awt.Stroke stroke5 = statisticalLineAndShapeRenderer0.lookupSeriesStroke(28);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = statisticalLineAndShapeRenderer0.getBaseNegativeItemLabelPosition();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D(pieDataset7);
        piePlot3D8.setDepthFactor((double) (byte) 1);
        piePlot3D8.setDepthFactor(0.0d);
        java.awt.Stroke stroke13 = piePlot3D8.getLabelLinkStroke();
        double double14 = piePlot3D8.getShadowXOffset();
        java.lang.String str15 = piePlot3D8.getNoDataMessage();
        java.awt.Paint paint16 = piePlot3D8.getBaseSectionOutlinePaint();
        org.jfree.data.general.PieDataset pieDataset17 = null;
        piePlot3D8.setDataset(pieDataset17);
        java.awt.Stroke stroke19 = piePlot3D8.getBaseSectionOutlineStroke();
        statisticalLineAndShapeRenderer0.setBaseStroke(stroke19, true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent22 = null;
        statisticalLineAndShapeRenderer0.notifyListeners(rendererChangeEvent22);
        java.awt.Font font25 = null;
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer29 = null;
        org.jfree.chart.plot.PolarPlot polarPlot30 = new org.jfree.chart.plot.PolarPlot(xYDataset26, (org.jfree.chart.axis.ValueAxis) numberAxis28, polarItemRenderer29);
        float float31 = polarPlot30.getBackgroundAlpha();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer32 = polarPlot30.getRenderer();
        org.jfree.chart.JFreeChart jFreeChart34 = new org.jfree.chart.JFreeChart("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font25, (org.jfree.chart.plot.Plot) polarPlot30, false);
        jFreeChart34.setTitle("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]");
        java.awt.Image image37 = null;
        jFreeChart34.setBackgroundImage(image37);
        org.jfree.chart.title.TextTitle textTitle39 = null;
        jFreeChart34.setTitle(textTitle39);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent43 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) statisticalLineAndShapeRenderer0, jFreeChart34, 2, (int) (byte) 0);
        int int44 = jFreeChart34.getBackgroundImageAlignment();
        java.awt.RenderingHints renderingHints45 = jFreeChart34.getRenderingHints();
        org.jfree.chart.title.TextTitle textTitle46 = new org.jfree.chart.title.TextTitle();
        boolean boolean47 = textTitle46.getExpandToFitSpace();
        org.jfree.chart.util.VerticalAlignment verticalAlignment48 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        textTitle46.setVerticalAlignment(verticalAlignment48);
        jFreeChart34.addSubtitle((org.jfree.chart.title.Title) textTitle46);
        java.awt.Font font51 = textTitle46.getFont();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + 1.0f + "'", float31 == 1.0f);
        org.junit.Assert.assertNull(polarItemRenderer32);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 15 + "'", int44 == 15);
        org.junit.Assert.assertNotNull(renderingHints45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(verticalAlignment48);
        org.junit.Assert.assertNotNull(font51);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (byte) -1, (double) (byte) 0);
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        barRenderer3D2.setWallPaint((java.awt.Paint) color3);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis2.setInverted(true);
        boolean boolean5 = numberAxis2.isAxisLineVisible();
        boolean boolean6 = numberAxis2.getAutoRangeStickyZero();
        java.awt.Stroke stroke7 = numberAxis2.getAxisLineStroke();
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis2);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.util.SortOrder sortOrder10 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot0.setColumnRenderingOrder(sortOrder10);
        boolean boolean12 = categoryPlot0.isRangeGridlinesVisible();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDepthFactor((double) (byte) 1);
        piePlot3D1.setDepthFactor(0.0d);
        java.awt.Stroke stroke6 = piePlot3D1.getLabelLinkStroke();
        double double7 = piePlot3D1.getShadowXOffset();
        java.lang.String str8 = piePlot3D1.getNoDataMessage();
        java.awt.Paint paint9 = piePlot3D1.getBaseSectionOutlinePaint();
        org.jfree.data.general.PieDataset pieDataset10 = null;
        piePlot3D1.setDataset(pieDataset10);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator12 = null;
        piePlot3D1.setLegendLabelURLGenerator(pieURLGenerator12);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent14 = null;
        piePlot3D1.datasetChanged(datasetChangeEvent14);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDepthFactor((double) (byte) 1);
        piePlot3D1.setDepthFactor(0.0d);
        piePlot3D1.setInteriorGap((double) 0.0f);
        java.awt.Shape shape8 = piePlot3D1.getLegendItemShape();
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape8);
        chartEntity9.setToolTipText("#ffff40");
        java.lang.String str12 = chartEntity9.getShapeType();
        org.jfree.data.Range range14 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean16 = range14.contains((double) 2);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = new org.jfree.chart.block.RectangleConstraint(0.0d, range14);
        double double18 = rectangleConstraint17.getWidth();
        double double19 = rectangleConstraint17.getWidth();
        org.jfree.data.Range range20 = rectangleConstraint17.getHeightRange();
        boolean boolean21 = chartEntity9.equals((java.lang.Object) rectangleConstraint17);
        java.lang.String str22 = chartEntity9.getToolTipText();
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "poly" + "'", str12.equals("poly"));
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "#ffff40" + "'", str22.equals("#ffff40"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.data.KeyToGroupMap keyToGroupMap0 = new org.jfree.data.KeyToGroupMap();
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int2 = year1.getYear();
        java.util.TimeZone timeZone4 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("SortOrder.DESCENDING", timeZone4);
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = dateAxis5.getTickUnit();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline8 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long9 = segmentedTimeline8.getStartTime();
        int int10 = segmentedTimeline8.getSegmentsIncluded();
        long long13 = segmentedTimeline8.getExceptionSegmentCount(0L, (-1L));
        long long14 = segmentedTimeline8.getSegmentsGroupSize();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(4, 0);
        java.util.Date date18 = month17.getEnd();
        long long19 = segmentedTimeline8.getTime(date18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date18);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(4, 0);
        java.util.Date date24 = month23.getEnd();
        org.jfree.data.gantt.Task task25 = new org.jfree.data.gantt.Task("", date18, date24);
        java.util.Date date26 = dateTickUnit6.addToDate(date18);
        keyToGroupMap0.mapKeyToGroup((java.lang.Comparable) int2, (java.lang.Comparable) date18);
        int int29 = keyToGroupMap0.getKeyCount((java.lang.Comparable) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(dateTickUnit6);
        org.junit.Assert.assertNotNull(segmentedTimeline8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-2208927600000L) + "'", long9 == (-2208927600000L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 28 + "'", int10 == 28);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 86400000L + "'", long14 == 86400000L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-62125372800001L) + "'", long19 == (-62125372800001L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
        blockContainer1.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer7 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer7.setFrame((org.jfree.chart.block.BlockFrame) blockBorder12);
        blockContainer1.add((org.jfree.chart.block.Block) blockContainer7);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.util.Size2D size2D16 = blockContainer7.arrange(graphics2D15);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D20 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D16, (double) '#', (double) 1.0f, rectangleAnchor19);
        boolean boolean21 = stackedBarRenderer0.equals((java.lang.Object) rectangle2D20);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator24 = stackedBarRenderer0.getItemLabelGenerator(0, 6);
        org.junit.Assert.assertNotNull(size2D16);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator24);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset3 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset3);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset5, valueAxis6, polarItemRenderer7);
        defaultCategoryDataset3.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot8);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo11);
        java.awt.geom.Point2D point2D13 = null;
        polarPlot8.zoomDomainAxes((double) '#', plotRenderingInfo12, point2D13);
        org.jfree.chart.block.BlockContainer blockContainer15 = new org.jfree.chart.block.BlockContainer();
        blockContainer15.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer21 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder26 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer21.setFrame((org.jfree.chart.block.BlockFrame) blockBorder26);
        blockContainer15.add((org.jfree.chart.block.Block) blockContainer21);
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.util.Size2D size2D30 = blockContainer21.arrange(graphics2D29);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D34 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D30, (double) '#', (double) 1.0f, rectangleAnchor33);
        plotRenderingInfo12.setPlotArea(rectangle2D34);
        categoryPlot0.handleClick(0, 0, plotRenderingInfo12);
        org.jfree.chart.util.Layer layer38 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection39 = categoryPlot0.getRangeMarkers(0, layer38);
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis43.setInverted(true);
        boolean boolean46 = numberAxis43.isAxisLineVisible();
        boolean boolean47 = numberAxis43.getAutoRangeStickyZero();
        java.awt.Stroke stroke48 = numberAxis43.getAxisLineStroke();
        categoryPlot41.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis43);
        org.jfree.chart.axis.AxisLocation axisLocation51 = categoryPlot41.getRangeAxisLocation(0);
        categoryPlot0.setDomainAxisLocation((int) (short) 0, axisLocation51);
        org.jfree.chart.axis.AxisLocation axisLocation53 = categoryPlot0.getRangeAxisLocation();
        categoryPlot0.clearRangeMarkers(0);
        try {
            categoryPlot0.zoom((-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNotNull(size2D30);
        org.junit.Assert.assertNotNull(rectangleAnchor33);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNotNull(layer38);
        org.junit.Assert.assertNull(collection39);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(axisLocation51);
        org.junit.Assert.assertNotNull(axisLocation53);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        int int2 = xYPlot0.indexOf(xYDataset1);
        org.jfree.chart.util.Layer layer4 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(6, layer4);
        org.jfree.chart.axis.ValueAxis valueAxis7 = xYPlot0.getRangeAxis(2);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis10.setInverted(true);
        boolean boolean13 = numberAxis10.isAxisLineVisible();
        boolean boolean14 = numberAxis10.getAutoRangeStickyZero();
        java.awt.Stroke stroke15 = numberAxis10.getAxisLineStroke();
        categoryPlot8.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis10);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot8.getDomainAxisEdge();
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        int int20 = xYPlot18.indexOf(xYDataset19);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection23 = xYPlot18.getRangeMarkers(6, layer22);
        java.util.Collection collection24 = categoryPlot8.getDomainMarkers(layer22);
        java.util.Collection collection25 = xYPlot0.getRangeMarkers(layer22);
        org.jfree.chart.axis.ValueAxis valueAxis26 = xYPlot0.getDomainAxis();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(layer4);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertNull(valueAxis26);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font4 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer5 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer5.setDrawOutlines(true);
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer5.setBasePaint((java.awt.Paint) color8, false);
        org.jfree.chart.text.TextMeasurer textMeasurer12 = null;
        org.jfree.chart.text.TextBlock textBlock13 = org.jfree.chart.text.TextUtilities.createTextBlock("", font4, (java.awt.Paint) color8, (float) (byte) -1, textMeasurer12);
        numberAxis2.setTickMarkPaint((java.awt.Paint) color8);
        boolean boolean15 = numberAxis2.isInverted();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer16 = null;
        org.jfree.chart.plot.PolarPlot polarPlot17 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, polarItemRenderer16);
        numberAxis2.zoomRange((double) (-1.0f), (double) (short) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = numberAxis2.getLabelInsets();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent22 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis2);
        java.awt.Font font24 = null;
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer28 = null;
        org.jfree.chart.plot.PolarPlot polarPlot29 = new org.jfree.chart.plot.PolarPlot(xYDataset25, (org.jfree.chart.axis.ValueAxis) numberAxis27, polarItemRenderer28);
        float float30 = polarPlot29.getBackgroundAlpha();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer31 = polarPlot29.getRenderer();
        org.jfree.chart.JFreeChart jFreeChart33 = new org.jfree.chart.JFreeChart("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font24, (org.jfree.chart.plot.Plot) polarPlot29, false);
        jFreeChart33.setTitle("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]");
        axisChangeEvent22.setChart(jFreeChart33);
        try {
            java.awt.image.BufferedImage bufferedImage39 = jFreeChart33.createBufferedImage((int) '#', (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (35) and height (-1) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(textBlock13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 1.0f + "'", float30 == 1.0f);
        org.junit.Assert.assertNull(polarItemRenderer31);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        int int2 = xYPlot0.indexOf(xYDataset1);
        org.jfree.chart.util.Layer layer4 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(6, layer4);
        org.jfree.chart.axis.AxisSpace axisSpace6 = xYPlot0.getFixedRangeAxisSpace();
        java.awt.Paint paint8 = xYPlot0.getQuadrantPaint((int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(layer4);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNull(axisSpace6);
        org.junit.Assert.assertNull(paint8);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(1, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = statisticalLineAndShapeRenderer0.getBaseItemLabelGenerator();
        statisticalLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D5 = new org.jfree.chart.plot.PiePlot3D(pieDataset4);
        java.awt.Font font6 = piePlot3D5.getLabelFont();
        statisticalLineAndShapeRenderer0.setBaseItemLabelFont(font6);
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator12 = new org.jfree.chart.urls.StandardCategoryURLGenerator("", "({0}, {1}) = {3} - {4}", "{0}");
        statisticalLineAndShapeRenderer0.setSeriesURLGenerator((int) (byte) 100, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator12);
        statisticalLineAndShapeRenderer0.setBaseShapesFilled(false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator1);
        org.junit.Assert.assertNotNull(font6);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) (short) 1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "First" + "'", str1.equals("First"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        levelRenderer0.setSeriesCreateEntities(0, (java.lang.Boolean) true, true);
        double double5 = levelRenderer0.getMaximumItemWidth();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis2.setInverted(true);
        boolean boolean5 = numberAxis2.isAxisLineVisible();
        boolean boolean6 = numberAxis2.getAutoRangeStickyZero();
        java.awt.Stroke stroke7 = numberAxis2.getAxisLineStroke();
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis2);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot0.getDomainAxisForDataset((int) ' ');
        java.awt.Font font12 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer13 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer13.setDrawOutlines(true);
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer13.setBasePaint((java.awt.Paint) color16, false);
        org.jfree.chart.text.TextMeasurer textMeasurer20 = null;
        org.jfree.chart.text.TextBlock textBlock21 = org.jfree.chart.text.TextUtilities.createTextBlock("", font12, (java.awt.Paint) color16, (float) (byte) -1, textMeasurer20);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor25 = null;
        java.awt.Shape shape29 = textBlock21.calculateBounds(graphics2D22, (float) 1, 100.0f, textBlockAnchor25, (float) 3, (float) (short) -1, (double) 0);
        java.awt.Shape shape32 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape29, (double) (-1.0f), 3.0d);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer33 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean34 = statisticalLineAndShapeRenderer33.getDrawOutlines();
        statisticalLineAndShapeRenderer33.setAutoPopulateSeriesFillPaint(false);
        java.lang.Object obj37 = statisticalLineAndShapeRenderer33.clone();
        java.awt.Stroke stroke38 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        statisticalLineAndShapeRenderer33.setBaseStroke(stroke38);
        statisticalLineAndShapeRenderer33.setBaseItemLabelsVisible(false, false);
        java.awt.Color color43 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        statisticalLineAndShapeRenderer33.setBaseFillPaint((java.awt.Paint) color43);
        org.jfree.chart.title.LegendGraphic legendGraphic45 = new org.jfree.chart.title.LegendGraphic(shape32, (java.awt.Paint) color43);
        boolean boolean46 = legendGraphic45.isShapeOutlineVisible();
        legendGraphic45.setLineVisible(false);
        java.awt.Paint paint49 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        legendGraphic45.setLinePaint(paint49);
        categoryPlot0.setRangeCrosshairPaint(paint49);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(textBlock21);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(paint49);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        double double1 = ganttRenderer0.getItemMargin();
        java.awt.Stroke stroke2 = ganttRenderer0.getBaseOutlineStroke();
        ganttRenderer0.setStartPercent((double) 2019L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean1 = statisticalLineAndShapeRenderer0.getDrawOutlines();
        statisticalLineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(false);
        java.awt.Stroke stroke5 = statisticalLineAndShapeRenderer0.lookupSeriesStroke(28);
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalLineAndShapeRenderer0);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double9 = rectangleInsets7.calculateBottomOutset((double) 'a');
        double double11 = rectangleInsets7.calculateLeftInset((double) 28);
        org.jfree.chart.util.UnitType unitType12 = rectangleInsets7.getUnitType();
        legendTitle6.setItemLabelPadding(rectangleInsets7);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = legendTitle6.getLegendItemGraphicLocation();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D15 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.text.TextAnchor textAnchor16 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        boolean boolean17 = categoryAxis3D15.equals((java.lang.Object) textAnchor16);
        categoryAxis3D15.setMaximumCategoryLabelWidthRatio((float) 60000L);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset22 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range23 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset22);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer26 = null;
        org.jfree.chart.plot.PolarPlot polarPlot27 = new org.jfree.chart.plot.PolarPlot(xYDataset24, valueAxis25, polarItemRenderer26);
        defaultCategoryDataset22.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot27);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo30 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo30);
        java.awt.geom.Point2D point2D32 = null;
        polarPlot27.zoomDomainAxes((double) '#', plotRenderingInfo31, point2D32);
        org.jfree.chart.block.BlockContainer blockContainer34 = new org.jfree.chart.block.BlockContainer();
        blockContainer34.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer40 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder45 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer40.setFrame((org.jfree.chart.block.BlockFrame) blockBorder45);
        blockContainer34.add((org.jfree.chart.block.Block) blockContainer40);
        java.awt.Graphics2D graphics2D48 = null;
        org.jfree.chart.util.Size2D size2D49 = blockContainer40.arrange(graphics2D48);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor52 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D53 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D49, (double) '#', (double) 1.0f, rectangleAnchor52);
        plotRenderingInfo31.setPlotArea(rectangle2D53);
        org.jfree.chart.plot.CategoryPlot categoryPlot55 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis57 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis57.setInverted(true);
        boolean boolean60 = numberAxis57.isAxisLineVisible();
        boolean boolean61 = numberAxis57.getAutoRangeStickyZero();
        java.awt.Stroke stroke62 = numberAxis57.getAxisLineStroke();
        categoryPlot55.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis57);
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = categoryPlot55.getDomainAxisEdge();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer65 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean66 = rectangleEdge64.equals((java.lang.Object) statisticalBarRenderer65);
        double double67 = categoryAxis3D15.getCategoryMiddle((-1), 100, rectangle2D53, rectangleEdge64);
        legendTitle6.setLegendItemGraphicEdge(rectangleEdge64);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNotNull(unitType12);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertNotNull(textAnchor16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(range23);
        org.junit.Assert.assertNotNull(size2D49);
        org.junit.Assert.assertNotNull(rectangleAnchor52);
        org.junit.Assert.assertNotNull(rectangle2D53);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(stroke62);
        org.junit.Assert.assertNotNull(rectangleEdge64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 35.0d + "'", double67 == 35.0d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = null;
        statisticalLineAndShapeRenderer0.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator2, true);
        statisticalLineAndShapeRenderer0.setSeriesVisibleInLegend(0, (java.lang.Boolean) true, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = statisticalLineAndShapeRenderer0.getBaseToolTipGenerator();
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer12 = null;
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot(xYDataset10, valueAxis11, polarItemRenderer12);
        polarPlot13.setAngleLabelsVisible(true);
        polarPlot13.clearCornerTextItems();
        boolean boolean17 = statisticalLineAndShapeRenderer0.equals((java.lang.Object) polarPlot13);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent18 = null;
        polarPlot13.notifyListeners(plotChangeEvent18);
        org.jfree.chart.LegendItemCollection legendItemCollection20 = polarPlot13.getLegendItems();
        org.junit.Assert.assertNull(categoryToolTipGenerator9);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(legendItemCollection20);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis3.setInverted(true);
        boolean boolean6 = numberAxis3.isAxisLineVisible();
        boolean boolean7 = numberAxis3.getAutoRangeStickyZero();
        java.awt.Stroke stroke8 = numberAxis3.getAxisLineStroke();
        categoryPlot1.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis3);
        java.awt.Font font11 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer12 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer12.setDrawOutlines(true);
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer12.setBasePaint((java.awt.Paint) color15, false);
        org.jfree.chart.text.TextMeasurer textMeasurer19 = null;
        org.jfree.chart.text.TextBlock textBlock20 = org.jfree.chart.text.TextUtilities.createTextBlock("", font11, (java.awt.Paint) color15, (float) (byte) -1, textMeasurer19);
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor24 = null;
        java.awt.Shape shape28 = textBlock20.calculateBounds(graphics2D21, (float) 1, 100.0f, textBlockAnchor24, (float) 3, (float) (short) -1, (double) 0);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset31 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range32 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset31);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset31);
        java.lang.Comparable comparable34 = null;
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity36 = new org.jfree.chart.entity.CategoryItemEntity(shape28, "{0}", "EXPAND", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset31, comparable34, (java.lang.Comparable) 1.0d);
        org.jfree.chart.util.SortOrder sortOrder37 = org.jfree.chart.util.SortOrder.DESCENDING;
        boolean boolean38 = categoryItemEntity36.equals((java.lang.Object) sortOrder37);
        categoryPlot1.setColumnRenderingOrder(sortOrder37);
        boolean boolean40 = datasetRenderingOrder0.equals((java.lang.Object) sortOrder37);
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(textBlock20);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNull(range32);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertNotNull(sortOrder37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement0.clear();
        flowArrangement0.clear();
        org.jfree.chart.block.BlockContainer blockContainer3 = new org.jfree.chart.block.BlockContainer();
        blockContainer3.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer9 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder14 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer9.setFrame((org.jfree.chart.block.BlockFrame) blockBorder14);
        blockContainer3.add((org.jfree.chart.block.Block) blockContainer9);
        double double17 = blockContainer3.getContentXOffset();
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.data.Range range20 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean22 = range20.contains((double) 2);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = new org.jfree.chart.block.RectangleConstraint(0.0d, range20);
        double double24 = rectangleConstraint23.getWidth();
        org.jfree.data.Range range25 = rectangleConstraint23.getWidthRange();
        org.jfree.data.Range range26 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint27 = rectangleConstraint23.toRangeWidth(range26);
        org.jfree.chart.util.Size2D size2D28 = flowArrangement0.arrange(blockContainer3, graphics2D18, rectangleConstraint27);
        java.lang.Object obj29 = size2D28.clone();
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertNotNull(rectangleConstraint27);
        org.junit.Assert.assertNotNull(size2D28);
        org.junit.Assert.assertNotNull(obj29);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setInverted(true);
        numberAxis1.setAutoTickUnitSelection(false);
        boolean boolean6 = numberAxis1.getAutoRangeIncludesZero();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainCrosshairPaint();
        int int2 = xYPlot0.getSeriesCount();
        org.jfree.chart.axis.AxisLocation axisLocation4 = null;
        xYPlot0.setRangeAxisLocation((int) (byte) 100, axisLocation4);
        java.lang.Object obj6 = xYPlot0.clone();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis2.setInverted(true);
        boolean boolean5 = numberAxis2.isAxisLineVisible();
        boolean boolean6 = numberAxis2.getAutoRangeStickyZero();
        java.awt.Stroke stroke7 = numberAxis2.getAxisLineStroke();
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis2);
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot0.getRangeAxisLocation(0);
        categoryPlot0.setAnchorValue((double) 1L);
        org.jfree.chart.axis.AxisLocation axisLocation14 = null;
        categoryPlot0.setRangeAxisLocation((int) (short) 10, axisLocation14, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = categoryPlot0.getRenderer((int) '#');
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo20);
        java.awt.geom.Point2D point2D22 = null;
        categoryPlot0.zoomRangeAxes((double) 3, plotRenderingInfo21, point2D22);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNull(categoryItemRenderer18);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean1 = statisticalLineAndShapeRenderer0.getDrawOutlines();
        statisticalLineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(false);
        java.lang.Object obj4 = statisticalLineAndShapeRenderer0.clone();
        java.awt.Stroke stroke5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        statisticalLineAndShapeRenderer0.setBaseStroke(stroke5);
        statisticalLineAndShapeRenderer0.setBaseItemLabelsVisible(false, false);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        statisticalLineAndShapeRenderer0.setBaseFillPaint((java.awt.Paint) color10);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = null;
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font17 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer18 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer18.setDrawOutlines(true);
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer18.setBasePaint((java.awt.Paint) color21, false);
        org.jfree.chart.text.TextMeasurer textMeasurer25 = null;
        org.jfree.chart.text.TextBlock textBlock26 = org.jfree.chart.text.TextUtilities.createTextBlock("", font17, (java.awt.Paint) color21, (float) (byte) -1, textMeasurer25);
        numberAxis15.setTickMarkPaint((java.awt.Paint) color21);
        org.jfree.chart.plot.Marker marker28 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset29 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset29);
        org.jfree.data.xy.XYDataset xYDataset31 = null;
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer33 = null;
        org.jfree.chart.plot.PolarPlot polarPlot34 = new org.jfree.chart.plot.PolarPlot(xYDataset31, valueAxis32, polarItemRenderer33);
        defaultCategoryDataset29.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot34);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo37 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo37);
        java.awt.geom.Point2D point2D39 = null;
        polarPlot34.zoomDomainAxes((double) '#', plotRenderingInfo38, point2D39);
        org.jfree.chart.block.BlockContainer blockContainer41 = new org.jfree.chart.block.BlockContainer();
        blockContainer41.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer47 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder52 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer47.setFrame((org.jfree.chart.block.BlockFrame) blockBorder52);
        blockContainer41.add((org.jfree.chart.block.Block) blockContainer47);
        java.awt.Graphics2D graphics2D55 = null;
        org.jfree.chart.util.Size2D size2D56 = blockContainer47.arrange(graphics2D55);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor59 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D60 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D56, (double) '#', (double) 1.0f, rectangleAnchor59);
        plotRenderingInfo38.setPlotArea(rectangle2D60);
        statisticalLineAndShapeRenderer0.drawRangeMarker(graphics2D12, categoryPlot13, (org.jfree.chart.axis.ValueAxis) numberAxis15, marker28, rectangle2D60);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity63 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D60);
        org.jfree.chart.plot.XYPlot xYPlot64 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset65 = null;
        int int66 = xYPlot64.indexOf(xYDataset65);
        boolean boolean67 = xYPlot64.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge68 = xYPlot64.getRangeAxisEdge();
        double double69 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D60, rectangleEdge68);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(textBlock26);
        org.junit.Assert.assertNull(range30);
        org.junit.Assert.assertNotNull(size2D56);
        org.junit.Assert.assertNotNull(rectangleAnchor59);
        org.junit.Assert.assertNotNull(rectangle2D60);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertNotNull(rectangleEdge68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 35.0d + "'", double69 == 35.0d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("({0}, {1}) = {3} - {4}");
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D(pieDataset2);
        piePlot3D3.setDepthFactor((double) (byte) 1);
        piePlot3D3.setDepthFactor(0.0d);
        java.awt.Stroke[] strokeArray8 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        boolean boolean9 = piePlot3D3.equals((java.lang.Object) strokeArray8);
        org.jfree.chart.util.Rotation rotation10 = piePlot3D3.getDirection();
        boolean boolean11 = standardCategorySeriesLabelGenerator1.equals((java.lang.Object) piePlot3D3);
        org.junit.Assert.assertNotNull(strokeArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rotation10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        org.jfree.chart.ui.Library[] libraryArray1 = projectInfo0.getOptionalLibraries();
        java.awt.Image image2 = projectInfo0.getLogo();
        org.jfree.chart.ui.Library[] libraryArray3 = projectInfo0.getLibraries();
        projectInfo0.setLicenceText("TextBlockAnchor.TOP_CENTER");
        java.lang.String str6 = projectInfo0.getName();
        org.junit.Assert.assertNotNull(libraryArray1);
        org.junit.Assert.assertNull(image2);
        org.junit.Assert.assertNotNull(libraryArray3);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        double double1 = categoryAxis3D0.getUpperMargin();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long4 = segmentedTimeline3.getStartTime();
        int int5 = segmentedTimeline3.getSegmentsIncluded();
        long long8 = segmentedTimeline3.getExceptionSegmentCount(0L, (-1L));
        long long9 = segmentedTimeline3.getSegmentsGroupSize();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(4, 0);
        java.util.Date date13 = month12.getEnd();
        long long14 = segmentedTimeline3.getTime(date13);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date13);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(4, 0);
        java.util.Date date19 = month18.getEnd();
        org.jfree.data.gantt.Task task20 = new org.jfree.data.gantt.Task("", date13, date19);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline21 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long22 = segmentedTimeline21.getStartTime();
        int int23 = segmentedTimeline21.getSegmentsIncluded();
        long long26 = segmentedTimeline21.getExceptionSegmentCount(0L, (-1L));
        long long27 = segmentedTimeline21.getSegmentsGroupSize();
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month(4, 0);
        java.util.Date date31 = month30.getEnd();
        long long32 = segmentedTimeline21.getTime(date31);
        org.jfree.data.time.DateRange dateRange33 = new org.jfree.data.time.DateRange(date19, date31);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer34 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer34.setDrawOutlines(true);
        java.awt.Color color37 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer34.setBasePaint((java.awt.Paint) color37, false);
        org.jfree.data.xy.XYDataset xYDataset41 = null;
        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer43 = null;
        org.jfree.chart.plot.PolarPlot polarPlot44 = new org.jfree.chart.plot.PolarPlot(xYDataset41, valueAxis42, polarItemRenderer43);
        java.lang.Object obj45 = null;
        boolean boolean46 = polarPlot44.equals(obj45);
        int int47 = polarPlot44.getSeriesCount();
        java.awt.Color color48 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        polarPlot44.setAngleLabelPaint((java.awt.Paint) color48);
        statisticalLineAndShapeRenderer34.setSeriesFillPaint(2, (java.awt.Paint) color48);
        java.awt.Paint paint51 = statisticalLineAndShapeRenderer34.getBaseFillPaint();
        categoryAxis3D0.setTickLabelPaint((java.lang.Comparable) date19, paint51);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.05d + "'", double1 == 0.05d);
        org.junit.Assert.assertNotNull(segmentedTimeline3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-2208927600000L) + "'", long4 == (-2208927600000L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 28 + "'", int5 == 28);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 86400000L + "'", long9 == 86400000L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-62125372800001L) + "'", long14 == (-62125372800001L));
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(segmentedTimeline21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-2208927600000L) + "'", long22 == (-2208927600000L));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 28 + "'", int23 == 28);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 86400000L + "'", long27 == 86400000L);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-62125372800001L) + "'", long32 == (-62125372800001L));
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNotNull(paint51);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainCrosshairPaint();
        xYPlot0.clearRangeAxes();
        xYPlot0.mapDatasetToDomainAxis((int) '4', (int) (short) 0);
        boolean boolean6 = xYPlot0.isRangeZeroBaselineVisible();
        java.awt.Stroke stroke7 = xYPlot0.getDomainGridlineStroke();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long1 = segmentedTimeline0.getStartTime();
        int int2 = segmentedTimeline0.getSegmentsIncluded();
        long long5 = segmentedTimeline0.getExceptionSegmentCount(0L, (-1L));
        long long6 = segmentedTimeline0.getSegmentsGroupSize();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(4, 0);
        java.util.Date date10 = month9.getEnd();
        long long11 = segmentedTimeline0.getTime(date10);
        long long12 = segmentedTimeline0.getSegmentsExcludedSize();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-2208927600000L) + "'", long1 == (-2208927600000L));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28 + "'", int2 == 28);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 86400000L + "'", long6 == 86400000L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-62125372800001L) + "'", long11 == (-62125372800001L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 61200000L + "'", long12 == 61200000L);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = statisticalLineAndShapeRenderer0.getBaseItemLabelGenerator();
        statisticalLineAndShapeRenderer0.setSeriesItemLabelsVisible(15, (java.lang.Boolean) true);
        statisticalLineAndShapeRenderer0.setSeriesVisible((int) '4', (java.lang.Boolean) false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator1);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("");
        taskSeries1.fireSeriesChanged();
        org.jfree.data.gantt.Task task4 = taskSeries1.get("{0}");
        int int5 = taskSeries1.getItemCount();
        org.junit.Assert.assertNull(task4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("");
        org.jfree.chart.block.BlockContainer blockContainer2 = new org.jfree.chart.block.BlockContainer();
        blockContainer2.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer8 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder13 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer8.setFrame((org.jfree.chart.block.BlockFrame) blockBorder13);
        blockContainer2.add((org.jfree.chart.block.Block) blockContainer8);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.util.Size2D size2D17 = blockContainer8.arrange(graphics2D16);
        blockContainer8.setWidth((double) (-1L));
        boolean boolean20 = datasetGroup1.equals((java.lang.Object) (-1L));
        org.junit.Assert.assertNotNull(size2D17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = statisticalLineAndShapeRenderer0.getBaseItemLabelGenerator();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator3 = null;
        statisticalLineAndShapeRenderer0.setSeriesItemLabelGenerator((int) (byte) 100, categoryItemLabelGenerator3, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = null;
        statisticalLineAndShapeRenderer0.setSeriesNegativeItemLabelPosition(2019, itemLabelPosition7, false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator1);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues1 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues1.removeValue((java.lang.Comparable) "EXPAND");
        java.awt.Font font5 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer6 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer6.setDrawOutlines(true);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer6.setBasePaint((java.awt.Paint) color9, false);
        org.jfree.chart.text.TextMeasurer textMeasurer13 = null;
        org.jfree.chart.text.TextBlock textBlock14 = org.jfree.chart.text.TextUtilities.createTextBlock("", font5, (java.awt.Paint) color9, (float) (byte) -1, textMeasurer13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor18 = null;
        java.awt.Shape shape22 = textBlock14.calculateBounds(graphics2D15, (float) 1, 100.0f, textBlockAnchor18, (float) 3, (float) (short) -1, (double) 0);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset25 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range26 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset25);
        org.jfree.data.Range range27 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset25);
        java.lang.Comparable comparable28 = null;
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity30 = new org.jfree.chart.entity.CategoryItemEntity(shape22, "{0}", "EXPAND", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset25, comparable28, (java.lang.Comparable) 1.0d);
        org.jfree.chart.util.SortOrder sortOrder31 = org.jfree.chart.util.SortOrder.DESCENDING;
        boolean boolean32 = categoryItemEntity30.equals((java.lang.Object) sortOrder31);
        defaultKeyedValues1.sortByValues(sortOrder31);
        org.jfree.data.category.CategoryDataset categoryDataset34 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) 2019, (org.jfree.data.KeyedValues) defaultKeyedValues1);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(textBlock14);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNull(range26);
        org.junit.Assert.assertNull(range27);
        org.junit.Assert.assertNotNull(sortOrder31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(categoryDataset34);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        int int1 = defaultBoxAndWhiskerCategoryDataset0.getRowCount();
        org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0, (int) 'a');
        try {
            java.lang.Number number6 = defaultBoxAndWhiskerCategoryDataset0.getQ3Value((int) (short) 10, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(pieDataset3);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        levelRenderer0.setSeriesCreateEntities(0, (java.lang.Boolean) true, true);
        double double5 = levelRenderer0.getItemMargin();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long1 = segmentedTimeline0.getStartTime();
        int int2 = segmentedTimeline0.getSegmentsIncluded();
        long long5 = segmentedTimeline0.getExceptionSegmentCount(0L, (-1L));
        long long6 = segmentedTimeline0.getSegmentsGroupSize();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(4, 0);
        java.util.Date date10 = month9.getEnd();
        long long11 = segmentedTimeline0.getTime(date10);
        long long13 = segmentedTimeline0.getTimeFromLong(0L);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-2208927600000L) + "'", long1 == (-2208927600000L));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28 + "'", int2 == 28);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 86400000L + "'", long6 == 86400000L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-62125372800001L) + "'", long11 == (-62125372800001L));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.text.TextBlock textBlock3 = org.jfree.chart.text.TextUtilities.createTextBlock("{0}", font1, (java.awt.Paint) color2);
        java.awt.Font font5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        int int7 = color6.getTransparency();
        java.awt.Color color8 = color6.darker();
        textBlock3.addLine("PlotOrientation.HORIZONTAL", font5, (java.awt.Paint) color6);
        java.util.List list10 = textBlock3.getLines();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textBlock3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(list10);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        ganttRenderer0.setAutoPopulateSeriesShape(true);
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D(pieDataset3);
        piePlot3D4.setDepthFactor((double) (byte) 1);
        piePlot3D4.setDepthFactor(0.0d);
        java.awt.Stroke stroke9 = piePlot3D4.getLabelLinkStroke();
        double double10 = piePlot3D4.getShadowXOffset();
        java.lang.String str11 = piePlot3D4.getNoDataMessage();
        java.awt.Paint paint12 = piePlot3D4.getLabelBackgroundPaint();
        ganttRenderer0.setIncompletePaint(paint12);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer1 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer1.setDrawOutlines(true);
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer1.setBasePaint((java.awt.Paint) color4, false);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot(xYDataset8, valueAxis9, polarItemRenderer10);
        java.lang.Object obj12 = null;
        boolean boolean13 = polarPlot11.equals(obj12);
        int int14 = polarPlot11.getSeriesCount();
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        polarPlot11.setAngleLabelPaint((java.awt.Paint) color15);
        statisticalLineAndShapeRenderer1.setSeriesFillPaint(2, (java.awt.Paint) color15);
        java.awt.Stroke stroke20 = statisticalLineAndShapeRenderer1.getItemStroke(0, 10);
        java.lang.Boolean boolean22 = statisticalLineAndShapeRenderer1.getSeriesCreateEntities((int) (short) -1);
        java.awt.Font font23 = statisticalLineAndShapeRenderer1.getBaseItemLabelFont();
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle("RectangleConstraintType.RANGE", font23);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNull(boolean22);
        org.junit.Assert.assertNotNull(font23);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        java.awt.Font font1 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer2.setDrawOutlines(true);
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer2.setBasePaint((java.awt.Paint) color5, false);
        org.jfree.chart.text.TextMeasurer textMeasurer9 = null;
        org.jfree.chart.text.TextBlock textBlock10 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color5, (float) (byte) -1, textMeasurer9);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor14 = null;
        java.awt.Shape shape18 = textBlock10.calculateBounds(graphics2D11, (float) 1, 100.0f, textBlockAnchor14, (float) 3, (float) (short) -1, (double) 0);
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape18, (double) (-1.0f), 3.0d);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer22 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean23 = statisticalLineAndShapeRenderer22.getDrawOutlines();
        statisticalLineAndShapeRenderer22.setAutoPopulateSeriesFillPaint(false);
        java.lang.Object obj26 = statisticalLineAndShapeRenderer22.clone();
        java.awt.Stroke stroke27 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        statisticalLineAndShapeRenderer22.setBaseStroke(stroke27);
        statisticalLineAndShapeRenderer22.setBaseItemLabelsVisible(false, false);
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        statisticalLineAndShapeRenderer22.setBaseFillPaint((java.awt.Paint) color32);
        org.jfree.chart.title.LegendGraphic legendGraphic34 = new org.jfree.chart.title.LegendGraphic(shape21, (java.awt.Paint) color32);
        boolean boolean35 = legendGraphic34.isShapeOutlineVisible();
        legendGraphic34.setLineVisible(false);
        java.awt.Paint paint38 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        legendGraphic34.setLinePaint(paint38);
        boolean boolean40 = legendGraphic34.isShapeVisible();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(textBlock10);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double1 = rectangleInsets0.getTop();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        try {
            java.lang.Comparable comparable3 = defaultKeyedValues2D1.getColumnKey((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint2 = xYPlot1.getDomainCrosshairPaint();
        int int3 = xYPlot1.getSeriesCount();
        java.awt.Paint paint4 = xYPlot1.getRangeZeroBaselinePaint();
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        int int6 = xYPlot1.indexOf(xYDataset5);
        boolean boolean7 = defaultBoxAndWhiskerCategoryDataset0.hasListener((java.util.EventListener) xYPlot1);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.Range range11 = numberAxis10.getDefaultAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.RangeType rangeType14 = numberAxis13.getRangeType();
        numberAxis10.setRangeType(rangeType14);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer16 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer16.setDrawOutlines(true);
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer16.setBasePaint((java.awt.Paint) color19, false);
        statisticalLineAndShapeRenderer16.setUseFillPaint(false);
        java.awt.Shape shape25 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 1L);
        statisticalLineAndShapeRenderer16.setBaseShape(shape25);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity29 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis10, shape25, "#ffff40", "SortOrder.DESCENDING");
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent30 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis10);
        xYPlot1.setRangeAxis((int) (byte) 0, (org.jfree.chart.axis.ValueAxis) numberAxis10);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(rangeType14);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(shape25);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        org.jfree.chart.ui.Library[] libraryArray1 = projectInfo0.getOptionalLibraries();
        java.awt.Image image2 = projectInfo0.getLogo();
        org.jfree.chart.ui.Library[] libraryArray3 = projectInfo0.getLibraries();
        org.jfree.chart.ui.ProjectInfo projectInfo4 = new org.jfree.chart.ui.ProjectInfo();
        java.awt.Image image5 = projectInfo4.getLogo();
        java.awt.Image image6 = null;
        projectInfo4.setLogo(image6);
        projectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo4);
        org.junit.Assert.assertNotNull(libraryArray1);
        org.junit.Assert.assertNull(image2);
        org.junit.Assert.assertNotNull(libraryArray3);
        org.junit.Assert.assertNull(image5);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.jfree.chart.block.Arrangement arrangement0 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer1 = new org.jfree.chart.renderer.category.StackedBarRenderer();
        java.awt.Font font3 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer4 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer4.setDrawOutlines(true);
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer4.setBasePaint((java.awt.Paint) color7, false);
        org.jfree.chart.text.TextMeasurer textMeasurer11 = null;
        org.jfree.chart.text.TextBlock textBlock12 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, (java.awt.Paint) color7, (float) (byte) -1, textMeasurer11);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor16 = null;
        java.awt.Shape shape20 = textBlock12.calculateBounds(graphics2D13, (float) 1, 100.0f, textBlockAnchor16, (float) 3, (float) (short) -1, (double) 0);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset23 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range24 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset23);
        org.jfree.data.Range range25 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset23);
        java.lang.Comparable comparable26 = null;
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity28 = new org.jfree.chart.entity.CategoryItemEntity(shape20, "{0}", "EXPAND", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset23, comparable26, (java.lang.Comparable) 1.0d);
        org.jfree.data.Range range29 = stackedBarRenderer1.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset23);
        java.lang.Number number30 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset23);
        java.util.TimeZone timeZone32 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("SortOrder.DESCENDING", timeZone32);
        org.jfree.chart.axis.DateTickUnit dateTickUnit34 = dateAxis33.getTickUnit();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline36 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long37 = segmentedTimeline36.getStartTime();
        int int38 = segmentedTimeline36.getSegmentsIncluded();
        long long41 = segmentedTimeline36.getExceptionSegmentCount(0L, (-1L));
        long long42 = segmentedTimeline36.getSegmentsGroupSize();
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month(4, 0);
        java.util.Date date46 = month45.getEnd();
        long long47 = segmentedTimeline36.getTime(date46);
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(date46);
        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month(4, 0);
        java.util.Date date52 = month51.getEnd();
        org.jfree.data.gantt.Task task53 = new org.jfree.data.gantt.Task("", date46, date52);
        java.util.Date date54 = dateTickUnit34.addToDate(date46);
        try {
            org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer55 = new org.jfree.chart.title.LegendItemBlockContainer(arrangement0, (org.jfree.data.general.Dataset) defaultCategoryDataset23, (java.lang.Comparable) date54);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(textBlock12);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertNull(range29);
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertNotNull(dateTickUnit34);
        org.junit.Assert.assertNotNull(segmentedTimeline36);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-2208927600000L) + "'", long37 == (-2208927600000L));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 28 + "'", int38 == 28);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 86400000L + "'", long42 == 86400000L);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-62125372800001L) + "'", long47 == (-62125372800001L));
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNotNull(date54);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font4 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer5 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer5.setDrawOutlines(true);
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer5.setBasePaint((java.awt.Paint) color8, false);
        org.jfree.chart.text.TextMeasurer textMeasurer12 = null;
        org.jfree.chart.text.TextBlock textBlock13 = org.jfree.chart.text.TextUtilities.createTextBlock("", font4, (java.awt.Paint) color8, (float) (byte) -1, textMeasurer12);
        numberAxis2.setTickMarkPaint((java.awt.Paint) color8);
        boolean boolean15 = numberAxis2.isInverted();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer16 = null;
        org.jfree.chart.plot.PolarPlot polarPlot17 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, polarItemRenderer16);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo20);
        java.awt.geom.Point2D point2D22 = null;
        polarPlot17.zoomDomainAxes(1.0E-5d, (double) 10, plotRenderingInfo21, point2D22);
        polarPlot17.setRadiusGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis27.setInverted(true);
        boolean boolean30 = numberAxis27.isAxisLineVisible();
        boolean boolean31 = numberAxis27.getAutoRangeStickyZero();
        java.awt.Stroke stroke32 = numberAxis27.getAxisLineStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis35.setInverted(true);
        boolean boolean38 = numberAxis35.isAxisLineVisible();
        boolean boolean39 = numberAxis35.getAutoRangeStickyZero();
        java.awt.Stroke stroke40 = numberAxis35.getAxisLineStroke();
        categoryPlot33.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis35);
        org.jfree.chart.axis.AxisLocation axisLocation43 = categoryPlot33.getRangeAxisLocation(0);
        float float44 = categoryPlot33.getBackgroundAlpha();
        numberAxis27.setPlot((org.jfree.chart.plot.Plot) categoryPlot33);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D46 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D46.setMaximumCategoryLabelWidthRatio((float) 86400000L);
        int int49 = categoryPlot33.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D46);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer50 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean51 = statisticalLineAndShapeRenderer50.getDrawOutlines();
        statisticalLineAndShapeRenderer50.setAutoPopulateSeriesFillPaint(false);
        java.awt.Stroke stroke55 = statisticalLineAndShapeRenderer50.lookupSeriesStroke(28);
        org.jfree.chart.LegendItemCollection legendItemCollection56 = statisticalLineAndShapeRenderer50.getLegendItems();
        categoryPlot33.setFixedLegendItems(legendItemCollection56);
        boolean boolean58 = polarPlot17.equals((java.lang.Object) categoryPlot33);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(textBlock13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(axisLocation43);
        org.junit.Assert.assertTrue("'" + float44 + "' != '" + 1.0f + "'", float44 == 1.0f);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(legendItemCollection56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        java.awt.Font font1 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer2.setDrawOutlines(true);
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer2.setBasePaint((java.awt.Paint) color5, false);
        org.jfree.chart.text.TextMeasurer textMeasurer9 = null;
        org.jfree.chart.text.TextBlock textBlock10 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color5, (float) (byte) -1, textMeasurer9);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor14 = null;
        java.awt.Shape shape18 = textBlock10.calculateBounds(graphics2D11, (float) 1, 100.0f, textBlockAnchor14, (float) 3, (float) (short) -1, (double) 0);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset21 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range22 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset21);
        org.jfree.data.Range range23 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset21);
        java.lang.Comparable comparable24 = null;
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity26 = new org.jfree.chart.entity.CategoryItemEntity(shape18, "{0}", "EXPAND", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset21, comparable24, (java.lang.Comparable) 1.0d);
        org.jfree.data.category.CategoryDataset categoryDataset27 = categoryItemEntity26.getDataset();
        java.lang.String str28 = categoryItemEntity26.getToolTipText();
        java.lang.Comparable comparable29 = categoryItemEntity26.getRowKey();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(textBlock10);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNull(range22);
        org.junit.Assert.assertNull(range23);
        org.junit.Assert.assertNotNull(categoryDataset27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "{0}" + "'", str28.equals("{0}"));
        org.junit.Assert.assertNull(comparable29);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = numberAxis1.getMarkerBand();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = numberAxis1.getMarkerBand();
        org.jfree.chart.plot.Plot plot4 = numberAxis1.getPlot();
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle();
        boolean boolean10 = textTitle9.getExpandToFitSpace();
        textTitle9.setNotify(false);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.text.TextAnchor textAnchor14 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        boolean boolean15 = categoryAxis3D13.equals((java.lang.Object) textAnchor14);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.gantt.Task task18 = new org.jfree.data.gantt.Task("", (org.jfree.data.time.TimePeriod) year17);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(4, 0);
        int int22 = month21.getMonth();
        int int23 = month21.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month21.next();
        task18.setDuration((org.jfree.data.time.TimePeriod) month21);
        java.awt.Font font26 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        categoryAxis3D13.setTickLabelFont((java.lang.Comparable) month21, font26);
        textTitle9.setFont(font26);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand29 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis1, (double) (short) 1, (double) 5, (double) (short) 0, (-1.05d), font26);
        org.junit.Assert.assertNull(markerAxisBand2);
        org.junit.Assert.assertNull(markerAxisBand3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(textAnchor14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(font26);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint2 = xYPlot1.getDomainCrosshairPaint();
        int int3 = xYPlot1.getSeriesCount();
        java.awt.Paint paint4 = xYPlot1.getRangeZeroBaselinePaint();
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        int int6 = xYPlot1.indexOf(xYDataset5);
        boolean boolean7 = defaultBoxAndWhiskerCategoryDataset0.hasListener((java.util.EventListener) xYPlot1);
        org.jfree.chart.axis.AxisLocation axisLocation9 = xYPlot1.getRangeAxisLocation((int) 'a');
        org.jfree.chart.axis.ValueAxis valueAxis11 = xYPlot1.getDomainAxis(96);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNull(valueAxis11);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType1 = org.jfree.chart.renderer.AreaRendererEndType.TAPER;
        stackedAreaRenderer0.setEndType(areaRendererEndType1);
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType3 = stackedAreaRenderer0.getEndType();
        org.junit.Assert.assertNotNull(areaRendererEndType1);
        org.junit.Assert.assertNotNull(areaRendererEndType3);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis2.setInverted(true);
        boolean boolean5 = numberAxis2.isAxisLineVisible();
        boolean boolean6 = numberAxis2.getAutoRangeStickyZero();
        java.awt.Stroke stroke7 = numberAxis2.getAxisLineStroke();
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis2);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer9 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean10 = statisticalLineAndShapeRenderer9.getDrawOutlines();
        statisticalLineAndShapeRenderer9.setAutoPopulateSeriesFillPaint(false);
        java.lang.Object obj13 = statisticalLineAndShapeRenderer9.clone();
        java.awt.Stroke stroke14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        statisticalLineAndShapeRenderer9.setBaseStroke(stroke14);
        boolean boolean18 = statisticalLineAndShapeRenderer9.getItemShapeVisible((int) '4', (int) (byte) 10);
        java.awt.Font font20 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        statisticalLineAndShapeRenderer9.setSeriesItemLabelFont((int) 'a', font20);
        java.awt.Paint paint22 = statisticalLineAndShapeRenderer9.getErrorIndicatorPaint();
        int int23 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer9);
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font27 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer28 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer28.setDrawOutlines(true);
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer28.setBasePaint((java.awt.Paint) color31, false);
        org.jfree.chart.text.TextMeasurer textMeasurer35 = null;
        org.jfree.chart.text.TextBlock textBlock36 = org.jfree.chart.text.TextUtilities.createTextBlock("", font27, (java.awt.Paint) color31, (float) (byte) -1, textMeasurer35);
        numberAxis25.setTickMarkPaint((java.awt.Paint) color31);
        numberAxis25.setLabelURL("RectangleConstraintType.RANGE");
        boolean boolean40 = categoryPlot0.equals((java.lang.Object) numberAxis25);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand41 = numberAxis25.getMarkerBand();
        try {
            numberAxis25.setRange(90.0d, 10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (90.0) <= upper (10.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNull(paint22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(textBlock36);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNull(markerAxisBand41);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis2.setInverted(true);
        boolean boolean5 = numberAxis2.isAxisLineVisible();
        boolean boolean6 = numberAxis2.getAutoRangeStickyZero();
        java.awt.Stroke stroke7 = numberAxis2.getAxisLineStroke();
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis2);
        double double9 = categoryPlot0.getAnchorValue();
        org.jfree.data.DefaultKeyedValues defaultKeyedValues11 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues11.removeValue((java.lang.Comparable) "EXPAND");
        java.awt.Font font15 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer16 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer16.setDrawOutlines(true);
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer16.setBasePaint((java.awt.Paint) color19, false);
        org.jfree.chart.text.TextMeasurer textMeasurer23 = null;
        org.jfree.chart.text.TextBlock textBlock24 = org.jfree.chart.text.TextUtilities.createTextBlock("", font15, (java.awt.Paint) color19, (float) (byte) -1, textMeasurer23);
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor28 = null;
        java.awt.Shape shape32 = textBlock24.calculateBounds(graphics2D25, (float) 1, 100.0f, textBlockAnchor28, (float) 3, (float) (short) -1, (double) 0);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset35 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range36 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset35);
        org.jfree.data.Range range37 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset35);
        java.lang.Comparable comparable38 = null;
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity40 = new org.jfree.chart.entity.CategoryItemEntity(shape32, "{0}", "EXPAND", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset35, comparable38, (java.lang.Comparable) 1.0d);
        org.jfree.chart.util.SortOrder sortOrder41 = org.jfree.chart.util.SortOrder.DESCENDING;
        boolean boolean42 = categoryItemEntity40.equals((java.lang.Object) sortOrder41);
        defaultKeyedValues11.sortByValues(sortOrder41);
        org.jfree.data.category.CategoryDataset categoryDataset44 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) (short) 10, (org.jfree.data.KeyedValues) defaultKeyedValues11);
        java.lang.Number number45 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset44);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer46 = categoryPlot0.getRendererForDataset(categoryDataset44);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(textBlock24);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNull(range36);
        org.junit.Assert.assertNull(range37);
        org.junit.Assert.assertNotNull(sortOrder41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(categoryDataset44);
        org.junit.Assert.assertTrue("'" + number45 + "' != '" + 0.0d + "'", number45.equals(0.0d));
        org.junit.Assert.assertNull(categoryItemRenderer46);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        java.text.AttributedString attributedString0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeAttributedString(attributedString0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (byte) -1, (double) (byte) 0);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis6.setInverted(true);
        boolean boolean9 = numberAxis6.isAxisLineVisible();
        boolean boolean10 = numberAxis6.getAutoRangeStickyZero();
        java.awt.Stroke stroke11 = numberAxis6.getAxisLineStroke();
        categoryPlot4.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis6);
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot4.setRangeCrosshairStroke(stroke13);
        categoryPlot4.setDomainGridlinesVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis18 = categoryPlot4.getRangeAxis(0);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = categoryPlot4.getRangeAxisEdge();
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font23 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer24 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer24.setDrawOutlines(true);
        java.awt.Color color27 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer24.setBasePaint((java.awt.Paint) color27, false);
        org.jfree.chart.text.TextMeasurer textMeasurer31 = null;
        org.jfree.chart.text.TextBlock textBlock32 = org.jfree.chart.text.TextUtilities.createTextBlock("", font23, (java.awt.Paint) color27, (float) (byte) -1, textMeasurer31);
        numberAxis21.setTickMarkPaint((java.awt.Paint) color27);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit35 = new org.jfree.chart.axis.NumberTickUnit(0.0d);
        numberAxis21.setTickUnit(numberTickUnit35);
        java.awt.Paint paint37 = numberAxis21.getTickMarkPaint();
        boolean boolean38 = numberAxis21.getAutoRangeStickyZero();
        java.awt.Color color40 = java.awt.Color.GRAY;
        org.jfree.data.xy.XYDataset xYDataset41 = null;
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer44 = null;
        org.jfree.chart.plot.PolarPlot polarPlot45 = new org.jfree.chart.plot.PolarPlot(xYDataset41, (org.jfree.chart.axis.ValueAxis) numberAxis43, polarItemRenderer44);
        org.jfree.data.general.DatasetGroup datasetGroup46 = polarPlot45.getDatasetGroup();
        java.awt.Paint paint47 = polarPlot45.getAngleGridlinePaint();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer48 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean49 = statisticalLineAndShapeRenderer48.getDrawOutlines();
        statisticalLineAndShapeRenderer48.setAutoPopulateSeriesFillPaint(false);
        java.awt.Stroke stroke53 = statisticalLineAndShapeRenderer48.lookupSeriesStroke(28);
        polarPlot45.setRadiusGridlineStroke(stroke53);
        org.jfree.chart.plot.ValueMarker valueMarker55 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color40, stroke53);
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer56 = new org.jfree.chart.renderer.category.StackedBarRenderer();
        org.jfree.chart.block.BlockContainer blockContainer57 = new org.jfree.chart.block.BlockContainer();
        blockContainer57.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer63 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder68 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer63.setFrame((org.jfree.chart.block.BlockFrame) blockBorder68);
        blockContainer57.add((org.jfree.chart.block.Block) blockContainer63);
        java.awt.Graphics2D graphics2D71 = null;
        org.jfree.chart.util.Size2D size2D72 = blockContainer63.arrange(graphics2D71);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor75 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D76 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D72, (double) '#', (double) 1.0f, rectangleAnchor75);
        boolean boolean77 = stackedBarRenderer56.equals((java.lang.Object) rectangle2D76);
        barRenderer3D2.drawRangeMarker(graphics2D3, categoryPlot4, (org.jfree.chart.axis.ValueAxis) numberAxis21, (org.jfree.chart.plot.Marker) valueMarker55, rectangle2D76);
        numberAxis21.setAutoRangeStickyZero(false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(valueAxis18);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(textBlock32);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNull(datasetGroup46);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(size2D72);
        org.junit.Assert.assertNotNull(rectangleAnchor75);
        org.junit.Assert.assertNotNull(rectangle2D76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = null;
        statisticalLineAndShapeRenderer0.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator2, true);
        statisticalLineAndShapeRenderer0.setSeriesVisibleInLegend(0, (java.lang.Boolean) true, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = statisticalLineAndShapeRenderer0.getBaseToolTipGenerator();
        boolean boolean10 = statisticalLineAndShapeRenderer0.getBaseShapesVisible();
        org.junit.Assert.assertNull(categoryToolTipGenerator9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.lang.Object obj1 = shapeList0.clone();
        java.lang.Object obj2 = shapeList0.clone();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        keyedObjects2D0.setObject((java.lang.Object) 1L, (java.lang.Comparable) 12.0d, (java.lang.Comparable) "UnitType.ABSOLUTE");
        keyedObjects2D0.removeRow(0);
        int int8 = keyedObjects2D0.getColumnIndex((java.lang.Comparable) (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        java.awt.Font font1 = null;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis4, polarItemRenderer5);
        float float7 = polarPlot6.getBackgroundAlpha();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer8 = polarPlot6.getRenderer();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font1, (org.jfree.chart.plot.Plot) polarPlot6, false);
        org.jfree.chart.title.TextTitle textTitle11 = null;
        jFreeChart10.setTitle(textTitle11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double15 = rectangleInsets13.calculateBottomOutset((double) 'a');
        double double16 = rectangleInsets13.getRight();
        jFreeChart10.setPadding(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertNull(polarItemRenderer8);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType0 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        java.lang.String str1 = categoryLabelWidthType0.toString();
        org.junit.Assert.assertNotNull(categoryLabelWidthType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CategoryLabelWidthType.CATEGORY" + "'", str1.equals("CategoryLabelWidthType.CATEGORY"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        levelRenderer0.setSeriesCreateEntities(0, (java.lang.Boolean) true, true);
        org.jfree.chart.LegendItem legendItem7 = levelRenderer0.getLegendItem((int) (short) 100, 7);
        org.junit.Assert.assertNull(legendItem7);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(1.05d);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        java.awt.Font font1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color2, (float) ' ', textMeasurer4);
        java.awt.image.ColorModel colorModel6 = null;
        java.awt.Rectangle rectangle7 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer8 = new org.jfree.chart.renderer.category.StackedBarRenderer();
        org.jfree.chart.block.BlockContainer blockContainer9 = new org.jfree.chart.block.BlockContainer();
        blockContainer9.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer15 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder20 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer15.setFrame((org.jfree.chart.block.BlockFrame) blockBorder20);
        blockContainer9.add((org.jfree.chart.block.Block) blockContainer15);
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.util.Size2D size2D24 = blockContainer15.arrange(graphics2D23);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor27 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D28 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D24, (double) '#', (double) 1.0f, rectangleAnchor27);
        boolean boolean29 = stackedBarRenderer8.equals((java.lang.Object) rectangle2D28);
        java.awt.geom.AffineTransform affineTransform30 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer31 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean32 = statisticalLineAndShapeRenderer31.getDrawOutlines();
        statisticalLineAndShapeRenderer31.setAutoPopulateSeriesFillPaint(false);
        java.awt.Stroke stroke36 = statisticalLineAndShapeRenderer31.lookupSeriesStroke(28);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition37 = statisticalLineAndShapeRenderer31.getBaseNegativeItemLabelPosition();
        org.jfree.data.general.PieDataset pieDataset38 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D39 = new org.jfree.chart.plot.PiePlot3D(pieDataset38);
        piePlot3D39.setDepthFactor((double) (byte) 1);
        piePlot3D39.setDepthFactor(0.0d);
        java.awt.Stroke stroke44 = piePlot3D39.getLabelLinkStroke();
        double double45 = piePlot3D39.getShadowXOffset();
        java.lang.String str46 = piePlot3D39.getNoDataMessage();
        java.awt.Paint paint47 = piePlot3D39.getBaseSectionOutlinePaint();
        org.jfree.data.general.PieDataset pieDataset48 = null;
        piePlot3D39.setDataset(pieDataset48);
        java.awt.Stroke stroke50 = piePlot3D39.getBaseSectionOutlineStroke();
        statisticalLineAndShapeRenderer31.setBaseStroke(stroke50, true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent53 = null;
        statisticalLineAndShapeRenderer31.notifyListeners(rendererChangeEvent53);
        java.awt.Font font56 = null;
        org.jfree.data.xy.XYDataset xYDataset57 = null;
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer60 = null;
        org.jfree.chart.plot.PolarPlot polarPlot61 = new org.jfree.chart.plot.PolarPlot(xYDataset57, (org.jfree.chart.axis.ValueAxis) numberAxis59, polarItemRenderer60);
        float float62 = polarPlot61.getBackgroundAlpha();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer63 = polarPlot61.getRenderer();
        org.jfree.chart.JFreeChart jFreeChart65 = new org.jfree.chart.JFreeChart("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font56, (org.jfree.chart.plot.Plot) polarPlot61, false);
        jFreeChart65.setTitle("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]");
        java.awt.Image image68 = null;
        jFreeChart65.setBackgroundImage(image68);
        org.jfree.chart.title.TextTitle textTitle70 = null;
        jFreeChart65.setTitle(textTitle70);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent74 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) statisticalLineAndShapeRenderer31, jFreeChart65, 2, (int) (byte) 0);
        int int75 = jFreeChart65.getBackgroundImageAlignment();
        java.awt.RenderingHints renderingHints76 = jFreeChart65.getRenderingHints();
        java.awt.PaintContext paintContext77 = color2.createContext(colorModel6, rectangle7, rectangle2D28, affineTransform30, renderingHints76);
        org.jfree.chart.block.BlockBorder blockBorder78 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color2);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNotNull(size2D24);
        org.junit.Assert.assertNotNull(rectangleAnchor27);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(itemLabelPosition37);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 4.0d + "'", double45 == 4.0d);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertTrue("'" + float62 + "' != '" + 1.0f + "'", float62 == 1.0f);
        org.junit.Assert.assertNull(polarItemRenderer63);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 15 + "'", int75 == 15);
        org.junit.Assert.assertNotNull(renderingHints76);
        org.junit.Assert.assertNotNull(paintContext77);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean1 = statisticalLineAndShapeRenderer0.getDrawOutlines();
        statisticalLineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(false);
        java.awt.Stroke stroke5 = statisticalLineAndShapeRenderer0.lookupSeriesStroke(28);
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalLineAndShapeRenderer0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.jfree.data.Range range8 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.Range range11 = numberAxis10.getDefaultAutoRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint(range11, (double) (-1L));
        org.jfree.data.Range range14 = org.jfree.data.Range.combine(range8, range11);
        boolean boolean17 = range11.intersects((double) (byte) -1, (double) (short) 100);
        boolean boolean18 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) rectangleAnchor7, (java.lang.Object) (byte) -1);
        legendTitle6.setLegendItemGraphicAnchor(rectangleAnchor7);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = null;
        try {
            legendTitle6.setLegendItemGraphicAnchor(rectangleAnchor20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'anchor' point.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean1 = statisticalLineAndShapeRenderer0.getDrawOutlines();
        statisticalLineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(false);
        java.lang.Object obj4 = statisticalLineAndShapeRenderer0.clone();
        java.awt.Stroke stroke5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        statisticalLineAndShapeRenderer0.setBaseStroke(stroke5);
        statisticalLineAndShapeRenderer0.setBaseItemLabelsVisible(false, false);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        statisticalLineAndShapeRenderer0.setBaseFillPaint((java.awt.Paint) color10);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = null;
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font17 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer18 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer18.setDrawOutlines(true);
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer18.setBasePaint((java.awt.Paint) color21, false);
        org.jfree.chart.text.TextMeasurer textMeasurer25 = null;
        org.jfree.chart.text.TextBlock textBlock26 = org.jfree.chart.text.TextUtilities.createTextBlock("", font17, (java.awt.Paint) color21, (float) (byte) -1, textMeasurer25);
        numberAxis15.setTickMarkPaint((java.awt.Paint) color21);
        org.jfree.chart.plot.Marker marker28 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset29 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset29);
        org.jfree.data.xy.XYDataset xYDataset31 = null;
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer33 = null;
        org.jfree.chart.plot.PolarPlot polarPlot34 = new org.jfree.chart.plot.PolarPlot(xYDataset31, valueAxis32, polarItemRenderer33);
        defaultCategoryDataset29.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot34);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo37 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo37);
        java.awt.geom.Point2D point2D39 = null;
        polarPlot34.zoomDomainAxes((double) '#', plotRenderingInfo38, point2D39);
        org.jfree.chart.block.BlockContainer blockContainer41 = new org.jfree.chart.block.BlockContainer();
        blockContainer41.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer47 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder52 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer47.setFrame((org.jfree.chart.block.BlockFrame) blockBorder52);
        blockContainer41.add((org.jfree.chart.block.Block) blockContainer47);
        java.awt.Graphics2D graphics2D55 = null;
        org.jfree.chart.util.Size2D size2D56 = blockContainer47.arrange(graphics2D55);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor59 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D60 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D56, (double) '#', (double) 1.0f, rectangleAnchor59);
        plotRenderingInfo38.setPlotArea(rectangle2D60);
        statisticalLineAndShapeRenderer0.drawRangeMarker(graphics2D12, categoryPlot13, (org.jfree.chart.axis.ValueAxis) numberAxis15, marker28, rectangle2D60);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity63 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D60);
        java.lang.Object obj64 = legendItemEntity63.clone();
        java.lang.Object obj65 = legendItemEntity63.clone();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(textBlock26);
        org.junit.Assert.assertNull(range30);
        org.junit.Assert.assertNotNull(size2D56);
        org.junit.Assert.assertNotNull(rectangleAnchor59);
        org.junit.Assert.assertNotNull(rectangle2D60);
        org.junit.Assert.assertNotNull(obj64);
        org.junit.Assert.assertNotNull(obj65);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis2.setInverted(true);
        boolean boolean5 = numberAxis2.isAxisLineVisible();
        boolean boolean6 = numberAxis2.getAutoRangeStickyZero();
        java.awt.Stroke stroke7 = numberAxis2.getAxisLineStroke();
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis2);
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot0.getRangeAxisLocation(0);
        categoryPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer13 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean14 = statisticalLineAndShapeRenderer13.getDrawOutlines();
        statisticalLineAndShapeRenderer13.setAutoPopulateSeriesFillPaint(false);
        java.awt.Stroke stroke18 = statisticalLineAndShapeRenderer13.lookupSeriesStroke(28);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = statisticalLineAndShapeRenderer13.getBaseNegativeItemLabelPosition();
        org.jfree.data.general.PieDataset pieDataset20 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D21 = new org.jfree.chart.plot.PiePlot3D(pieDataset20);
        piePlot3D21.setDepthFactor((double) (byte) 1);
        piePlot3D21.setDepthFactor(0.0d);
        java.awt.Stroke stroke26 = piePlot3D21.getLabelLinkStroke();
        double double27 = piePlot3D21.getShadowXOffset();
        java.lang.String str28 = piePlot3D21.getNoDataMessage();
        java.awt.Paint paint29 = piePlot3D21.getBaseSectionOutlinePaint();
        org.jfree.data.general.PieDataset pieDataset30 = null;
        piePlot3D21.setDataset(pieDataset30);
        java.awt.Stroke stroke32 = piePlot3D21.getBaseSectionOutlineStroke();
        statisticalLineAndShapeRenderer13.setBaseStroke(stroke32, true);
        java.awt.Shape shape36 = statisticalLineAndShapeRenderer13.getSeriesShape((int) (short) 0);
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer13, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = null;
        java.awt.geom.Point2D point2D42 = null;
        categoryPlot0.zoomDomainAxes((double) 7, (double) (short) 0, plotRenderingInfo41, point2D42);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 4.0d + "'", double27 == 4.0d);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNull(shape36);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        org.jfree.chart.ui.Library[] libraryArray1 = projectInfo0.getOptionalLibraries();
        java.util.List list2 = projectInfo0.getContributors();
        java.util.List list3 = projectInfo0.getContributors();
        projectInfo0.setLicenceName("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        projectInfo0.addOptionalLibrary("LengthConstraintType.NONE");
        org.junit.Assert.assertNotNull(libraryArray1);
        org.junit.Assert.assertNull(list2);
        org.junit.Assert.assertNull(list3);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        int int2 = xYPlot0.indexOf(xYDataset1);
        org.jfree.chart.util.Layer layer4 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(6, layer4);
        org.jfree.chart.axis.ValueAxis valueAxis7 = xYPlot0.getRangeAxis(2);
        java.awt.Paint paint8 = xYPlot0.getDomainCrosshairPaint();
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot0.getRangeAxis();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(layer4);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(valueAxis9);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.util.Date date1 = dateRange0.getLowerDate();
        java.util.Date date2 = dateRange0.getLowerDate();
        org.junit.Assert.assertNotNull(dateRange0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) (-1));
        axisState1.cursorLeft(0.0d);
        java.util.List list4 = null;
        axisState1.setTicks(list4);
        double double6 = axisState1.getMax();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("RectangleConstraintType.RANGE", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        double double2 = ringPlot1.getSectionDepth();
        java.awt.Stroke stroke3 = ringPlot1.getSeparatorStroke();
        double double4 = ringPlot1.getOuterSeparatorExtension();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        keyedObjects2D0.setObject((java.lang.Object) 1L, (java.lang.Comparable) 12.0d, (java.lang.Comparable) "UnitType.ABSOLUTE");
        keyedObjects2D0.removeRow(0);
        try {
            java.lang.Object obj9 = keyedObjects2D0.getObject(7, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis3.setInverted(true);
        boolean boolean6 = numberAxis3.isAxisLineVisible();
        boolean boolean7 = numberAxis3.getAutoRangeStickyZero();
        java.awt.Stroke stroke8 = numberAxis3.getAxisLineStroke();
        categoryPlot1.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis3);
        org.jfree.chart.axis.AxisLocation axisLocation11 = categoryPlot1.getRangeAxisLocation(0);
        categoryPlot1.setRangeGridlinesVisible(false);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer14 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean15 = statisticalLineAndShapeRenderer14.getDrawOutlines();
        statisticalLineAndShapeRenderer14.setAutoPopulateSeriesFillPaint(false);
        java.awt.Stroke stroke19 = statisticalLineAndShapeRenderer14.lookupSeriesStroke(28);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = statisticalLineAndShapeRenderer14.getBaseNegativeItemLabelPosition();
        org.jfree.data.general.PieDataset pieDataset21 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D22 = new org.jfree.chart.plot.PiePlot3D(pieDataset21);
        piePlot3D22.setDepthFactor((double) (byte) 1);
        piePlot3D22.setDepthFactor(0.0d);
        java.awt.Stroke stroke27 = piePlot3D22.getLabelLinkStroke();
        double double28 = piePlot3D22.getShadowXOffset();
        java.lang.String str29 = piePlot3D22.getNoDataMessage();
        java.awt.Paint paint30 = piePlot3D22.getBaseSectionOutlinePaint();
        org.jfree.data.general.PieDataset pieDataset31 = null;
        piePlot3D22.setDataset(pieDataset31);
        java.awt.Stroke stroke33 = piePlot3D22.getBaseSectionOutlineStroke();
        statisticalLineAndShapeRenderer14.setBaseStroke(stroke33, true);
        java.awt.Shape shape37 = statisticalLineAndShapeRenderer14.getSeriesShape((int) (short) 0);
        categoryPlot1.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer14, true);
        java.awt.Stroke stroke42 = statisticalLineAndShapeRenderer14.getItemStroke(0, 28);
        boolean boolean43 = centerArrangement0.equals((java.lang.Object) 28);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(itemLabelPosition20);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 4.0d + "'", double28 == 4.0d);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNull(shape37);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        java.lang.Class class1 = null;
        java.lang.Class class2 = null;
        java.lang.Object obj3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("LegendItemEntity: seriesKey=null, dataset=null", class1, class2);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis2.setInverted(true);
        boolean boolean5 = numberAxis2.isAxisLineVisible();
        boolean boolean6 = numberAxis2.getAutoRangeStickyZero();
        java.awt.Stroke stroke7 = numberAxis2.getAxisLineStroke();
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis2);
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot0.getRangeAxisLocation(0);
        categoryPlot0.setAnchorValue((double) 1L);
        java.awt.Image image13 = null;
        categoryPlot0.setBackgroundImage(image13);
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand17 = numberAxis16.getMarkerBand();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand18 = numberAxis16.getMarkerBand();
        java.lang.String str19 = numberAxis16.getLabel();
        org.jfree.data.Range range20 = numberAxis16.getDefaultAutoRange();
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis16);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNull(markerAxisBand17);
        org.junit.Assert.assertNull(markerAxisBand18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertNotNull(range20);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        int int0 = org.jfree.chart.axis.DateTickUnit.HOUR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset2, valueAxis3, polarItemRenderer4);
        defaultCategoryDataset0.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot5);
        int int7 = defaultCategoryDataset0.getColumnCount();
        org.jfree.data.general.PieDataset pieDataset9 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, (java.lang.Comparable) 0.35d);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline11 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long12 = segmentedTimeline11.getStartTime();
        int int13 = segmentedTimeline11.getSegmentsIncluded();
        long long16 = segmentedTimeline11.getExceptionSegmentCount(0L, (-1L));
        long long17 = segmentedTimeline11.getSegmentsGroupSize();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(4, 0);
        java.util.Date date21 = month20.getEnd();
        long long22 = segmentedTimeline11.getTime(date21);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date21);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(4, 0);
        java.util.Date date27 = month26.getEnd();
        org.jfree.data.gantt.Task task28 = new org.jfree.data.gantt.Task("", date21, date27);
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone29;
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date27, timeZone29);
        defaultCategoryDataset0.removeValue((java.lang.Comparable) year31, (java.lang.Comparable) 1577865599999L);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(pieDataset9);
        org.junit.Assert.assertNotNull(segmentedTimeline11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-2208927600000L) + "'", long12 == (-2208927600000L));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 28 + "'", int13 == 28);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 86400000L + "'", long17 == 86400000L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-62125372800001L) + "'", long22 == (-62125372800001L));
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone29);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        java.awt.Font font1 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer2.setDrawOutlines(true);
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer2.setBasePaint((java.awt.Paint) color5, false);
        org.jfree.chart.text.TextMeasurer textMeasurer9 = null;
        org.jfree.chart.text.TextBlock textBlock10 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color5, (float) (byte) -1, textMeasurer9);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor14 = null;
        java.awt.Shape shape18 = textBlock10.calculateBounds(graphics2D11, (float) 1, 100.0f, textBlockAnchor14, (float) 3, (float) (short) -1, (double) 0);
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape18, (double) (-1.0f), 3.0d);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer22 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean23 = statisticalLineAndShapeRenderer22.getDrawOutlines();
        statisticalLineAndShapeRenderer22.setAutoPopulateSeriesFillPaint(false);
        java.lang.Object obj26 = statisticalLineAndShapeRenderer22.clone();
        java.awt.Stroke stroke27 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        statisticalLineAndShapeRenderer22.setBaseStroke(stroke27);
        statisticalLineAndShapeRenderer22.setBaseItemLabelsVisible(false, false);
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        statisticalLineAndShapeRenderer22.setBaseFillPaint((java.awt.Paint) color32);
        org.jfree.chart.title.LegendGraphic legendGraphic34 = new org.jfree.chart.title.LegendGraphic(shape21, (java.awt.Paint) color32);
        boolean boolean35 = legendGraphic34.isShapeOutlineVisible();
        legendGraphic34.setLineVisible(false);
        java.awt.Stroke stroke38 = legendGraphic34.getOutlineStroke();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(textBlock10);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(stroke38);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint2 = xYPlot1.getDomainCrosshairPaint();
        int int3 = xYPlot1.getSeriesCount();
        java.awt.Paint paint4 = xYPlot1.getRangeZeroBaselinePaint();
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        int int6 = xYPlot1.indexOf(xYDataset5);
        boolean boolean7 = defaultBoxAndWhiskerCategoryDataset0.hasListener((java.util.EventListener) xYPlot1);
        org.jfree.chart.axis.AxisLocation axisLocation9 = xYPlot1.getRangeAxisLocation((int) 'a');
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font13 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer14 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer14.setDrawOutlines(true);
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer14.setBasePaint((java.awt.Paint) color17, false);
        org.jfree.chart.text.TextMeasurer textMeasurer21 = null;
        org.jfree.chart.text.TextBlock textBlock22 = org.jfree.chart.text.TextUtilities.createTextBlock("", font13, (java.awt.Paint) color17, (float) (byte) -1, textMeasurer21);
        numberAxis11.setTickMarkPaint((java.awt.Paint) color17);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit25 = new org.jfree.chart.axis.NumberTickUnit(0.0d);
        numberAxis11.setTickUnit(numberTickUnit25);
        int int27 = xYPlot1.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis11);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(textBlock22);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer1 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer1.setDrawOutlines(true);
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer1.setBasePaint((java.awt.Paint) color4, false);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot(xYDataset8, valueAxis9, polarItemRenderer10);
        java.lang.Object obj12 = null;
        boolean boolean13 = polarPlot11.equals(obj12);
        int int14 = polarPlot11.getSeriesCount();
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        polarPlot11.setAngleLabelPaint((java.awt.Paint) color15);
        statisticalLineAndShapeRenderer1.setSeriesFillPaint(2, (java.awt.Paint) color15);
        java.awt.Stroke stroke20 = statisticalLineAndShapeRenderer1.getItemStroke(0, 10);
        java.lang.Boolean boolean22 = statisticalLineAndShapeRenderer1.getSeriesCreateEntities((int) (short) -1);
        java.awt.Font font23 = statisticalLineAndShapeRenderer1.getBaseItemLabelFont();
        org.jfree.chart.text.TextFragment textFragment24 = new org.jfree.chart.text.TextFragment("", font23);
        org.jfree.data.general.PieDataset pieDataset25 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D26 = new org.jfree.chart.plot.PiePlot3D(pieDataset25);
        piePlot3D26.setDepthFactor((double) (byte) 1);
        piePlot3D26.setDepthFactor(0.0d);
        piePlot3D26.setInteriorGap((double) 0.0f);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator33 = piePlot3D26.getURLGenerator();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator34 = piePlot3D26.getLabelGenerator();
        boolean boolean35 = textFragment24.equals((java.lang.Object) piePlot3D26);
        org.jfree.data.xy.XYDataset xYDataset36 = null;
        org.jfree.chart.axis.NumberAxis numberAxis38 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer39 = null;
        org.jfree.chart.plot.PolarPlot polarPlot40 = new org.jfree.chart.plot.PolarPlot(xYDataset36, (org.jfree.chart.axis.ValueAxis) numberAxis38, polarItemRenderer39);
        float float41 = polarPlot40.getBackgroundAlpha();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer42 = polarPlot40.getRenderer();
        java.awt.Stroke stroke43 = polarPlot40.getRadiusGridlineStroke();
        org.jfree.data.general.DatasetGroup datasetGroup44 = polarPlot40.getDatasetGroup();
        boolean boolean45 = textFragment24.equals((java.lang.Object) datasetGroup44);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNull(boolean22);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNull(pieURLGenerator33);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + float41 + "' != '" + 1.0f + "'", float41 == 1.0f);
        org.junit.Assert.assertNull(polarItemRenderer42);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNull(datasetGroup44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        java.lang.Object obj4 = null;
        boolean boolean5 = polarPlot3.equals(obj4);
        int int6 = polarPlot3.getSeriesCount();
        boolean boolean7 = polarPlot3.isRangeZoomable();
        polarPlot3.setRadiusGridlinesVisible(false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke1 = lineBorder0.getStroke();
        java.awt.Paint paint2 = lineBorder0.getPaint();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDepthFactor((double) (byte) 1);
        piePlot3D1.setDepthFactor(0.0d);
        piePlot3D1.setInteriorGap((double) 0.0f);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator8 = piePlot3D1.getURLGenerator();
        org.jfree.data.general.PieDataset pieDataset9 = piePlot3D1.getDataset();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = piePlot3D1.getLegendLabelToolTipGenerator();
        java.awt.Paint paint12 = piePlot3D1.getSectionPaint((java.lang.Comparable) 36.0d);
        int int13 = piePlot3D1.getBackgroundImageAlignment();
        org.junit.Assert.assertNull(pieURLGenerator8);
        org.junit.Assert.assertNull(pieDataset9);
        org.junit.Assert.assertNull(pieSectionLabelGenerator10);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis4.setInverted(true);
        boolean boolean7 = numberAxis4.isAxisLineVisible();
        boolean boolean8 = numberAxis4.getAutoRangeStickyZero();
        java.awt.Stroke stroke9 = numberAxis4.getAxisLineStroke();
        categoryPlot2.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis4);
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot2.setRangeCrosshairStroke(stroke11);
        strokeList0.setStroke(96, stroke11);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDepthFactor((double) (byte) 1);
        piePlot3D1.setDepthFactor(0.0d);
        piePlot3D1.setInteriorGap((double) 0.0f);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator8 = piePlot3D1.getURLGenerator();
        org.jfree.data.general.PieDataset pieDataset9 = piePlot3D1.getDataset();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = piePlot3D1.getLegendLabelToolTipGenerator();
        java.awt.Paint paint12 = piePlot3D1.getSectionPaint((java.lang.Comparable) 36.0d);
        org.jfree.chart.util.Rotation rotation13 = piePlot3D1.getDirection();
        org.junit.Assert.assertNull(pieURLGenerator8);
        org.junit.Assert.assertNull(pieDataset9);
        org.junit.Assert.assertNull(pieSectionLabelGenerator10);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNotNull(rotation13);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = defaultCategoryDataset0.getGroup();
        int int2 = defaultCategoryDataset0.getColumnCount();
        org.junit.Assert.assertNotNull(datasetGroup1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = statisticalLineAndShapeRenderer0.getBaseItemLabelGenerator();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator3 = null;
        statisticalLineAndShapeRenderer0.setSeriesItemLabelGenerator((int) (byte) 100, categoryItemLabelGenerator3, true);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement10 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment6, verticalAlignment7, (double) 'a', (double) 60000L);
        org.jfree.chart.block.BlockContainer blockContainer11 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement10);
        boolean boolean12 = statisticalLineAndShapeRenderer0.equals((java.lang.Object) blockContainer11);
        org.junit.Assert.assertNull(categoryItemLabelGenerator1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long1 = segmentedTimeline0.getStartTime();
        int int2 = segmentedTimeline0.getSegmentsIncluded();
        long long5 = segmentedTimeline0.getExceptionSegmentCount(0L, (-1L));
        long long6 = segmentedTimeline0.getSegmentsGroupSize();
        int int7 = segmentedTimeline0.getSegmentsIncluded();
        long long9 = segmentedTimeline0.toMillisecond((-2208927599903L));
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-2208927600000L) + "'", long1 == (-2208927600000L));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28 + "'", int2 == 28);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 86400000L + "'", long6 == 86400000L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 28 + "'", int7 == 28);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-9782341199903L) + "'", long9 == (-9782341199903L));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        statisticalLineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer7 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean8 = statisticalLineAndShapeRenderer7.getDrawOutlines();
        statisticalLineAndShapeRenderer7.setAutoPopulateSeriesFillPaint(false);
        java.awt.Stroke stroke12 = statisticalLineAndShapeRenderer7.lookupSeriesStroke(28);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = statisticalLineAndShapeRenderer7.getBaseNegativeItemLabelPosition();
        double double14 = itemLabelPosition13.getAngle();
        statisticalLineAndShapeRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition13);
        org.jfree.chart.text.TextAnchor textAnchor16 = itemLabelPosition13.getRotationAnchor();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(itemLabelPosition13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(textAnchor16);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis2.setInverted(true);
        boolean boolean5 = numberAxis2.isAxisLineVisible();
        boolean boolean6 = numberAxis2.getAutoRangeStickyZero();
        java.awt.Stroke stroke7 = numberAxis2.getAxisLineStroke();
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis2);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer9 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean10 = statisticalLineAndShapeRenderer9.getDrawOutlines();
        statisticalLineAndShapeRenderer9.setAutoPopulateSeriesFillPaint(false);
        java.lang.Object obj13 = statisticalLineAndShapeRenderer9.clone();
        java.awt.Stroke stroke14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        statisticalLineAndShapeRenderer9.setBaseStroke(stroke14);
        boolean boolean18 = statisticalLineAndShapeRenderer9.getItemShapeVisible((int) '4', (int) (byte) 10);
        java.awt.Font font20 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        statisticalLineAndShapeRenderer9.setSeriesItemLabelFont((int) 'a', font20);
        java.awt.Paint paint22 = statisticalLineAndShapeRenderer9.getErrorIndicatorPaint();
        int int23 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer9);
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font27 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer28 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer28.setDrawOutlines(true);
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer28.setBasePaint((java.awt.Paint) color31, false);
        org.jfree.chart.text.TextMeasurer textMeasurer35 = null;
        org.jfree.chart.text.TextBlock textBlock36 = org.jfree.chart.text.TextUtilities.createTextBlock("", font27, (java.awt.Paint) color31, (float) (byte) -1, textMeasurer35);
        numberAxis25.setTickMarkPaint((java.awt.Paint) color31);
        numberAxis25.setLabelURL("RectangleConstraintType.RANGE");
        boolean boolean40 = categoryPlot0.equals((java.lang.Object) numberAxis25);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand41 = numberAxis25.getMarkerBand();
        numberAxis25.setUpperBound((double) (-16744320));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNull(paint22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(textBlock36);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNull(markerAxisBand41);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        java.text.DateFormat dateFormat1 = null;
        try {
            org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator2 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("LengthConstraintType.NONE", dateFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(1.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = stackedBarRenderer3D2.getGradientPaintTransformer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = stackedBarRenderer3D2.getBaseItemLabelGenerator();
        double double5 = stackedBarRenderer3D2.getXOffset();
        org.junit.Assert.assertNotNull(gradientPaintTransformer3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean1 = statisticalLineAndShapeRenderer0.getDrawOutlines();
        statisticalLineAndShapeRenderer0.setBaseSeriesVisible(true, false);
        java.awt.Font font6 = null;
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) numberAxis9, polarItemRenderer10);
        float float12 = polarPlot11.getBackgroundAlpha();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer13 = polarPlot11.getRenderer();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font6, (org.jfree.chart.plot.Plot) polarPlot11, false);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent18 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) false, jFreeChart15, 6, 0);
        org.jfree.chart.title.LegendTitle legendTitle19 = jFreeChart15.getLegend();
        jFreeChart15.setBorderVisible(false);
        org.jfree.chart.event.ChartProgressListener chartProgressListener22 = null;
        jFreeChart15.addProgressListener(chartProgressListener22);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 1.0f + "'", float12 == 1.0f);
        org.junit.Assert.assertNull(polarItemRenderer13);
        org.junit.Assert.assertNull(legendTitle19);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(1.0d, (double) (short) -1);
        boolean boolean3 = stackedBarRenderer3D2.isDrawBarOutline();
        double double4 = stackedBarRenderer3D2.getYOffset();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset5 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range7 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset5, true);
        org.jfree.data.Range range8 = stackedBarRenderer3D2.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset5);
        boolean boolean9 = stackedBarRenderer3D2.isDrawBarOutline();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis13.setInverted(true);
        boolean boolean16 = numberAxis13.isAxisLineVisible();
        boolean boolean17 = numberAxis13.getAutoRangeStickyZero();
        java.awt.Stroke stroke18 = numberAxis13.getAxisLineStroke();
        categoryPlot11.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis13);
        org.jfree.chart.axis.AxisLocation axisLocation21 = categoryPlot11.getRangeAxisLocation(0);
        categoryPlot11.setRangeGridlinesVisible(false);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer24 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean25 = statisticalLineAndShapeRenderer24.getDrawOutlines();
        statisticalLineAndShapeRenderer24.setAutoPopulateSeriesFillPaint(false);
        java.awt.Stroke stroke29 = statisticalLineAndShapeRenderer24.lookupSeriesStroke(28);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition30 = statisticalLineAndShapeRenderer24.getBaseNegativeItemLabelPosition();
        org.jfree.data.general.PieDataset pieDataset31 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D32 = new org.jfree.chart.plot.PiePlot3D(pieDataset31);
        piePlot3D32.setDepthFactor((double) (byte) 1);
        piePlot3D32.setDepthFactor(0.0d);
        java.awt.Stroke stroke37 = piePlot3D32.getLabelLinkStroke();
        double double38 = piePlot3D32.getShadowXOffset();
        java.lang.String str39 = piePlot3D32.getNoDataMessage();
        java.awt.Paint paint40 = piePlot3D32.getBaseSectionOutlinePaint();
        org.jfree.data.general.PieDataset pieDataset41 = null;
        piePlot3D32.setDataset(pieDataset41);
        java.awt.Stroke stroke43 = piePlot3D32.getBaseSectionOutlineStroke();
        statisticalLineAndShapeRenderer24.setBaseStroke(stroke43, true);
        java.awt.Shape shape47 = statisticalLineAndShapeRenderer24.getSeriesShape((int) (short) 0);
        categoryPlot11.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer24, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray51 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis50 };
        categoryPlot11.setDomainAxes(categoryAxisArray51);
        org.jfree.chart.axis.NumberAxis numberAxis54 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis54.setInverted(true);
        boolean boolean57 = numberAxis54.isAxisLineVisible();
        boolean boolean58 = numberAxis54.getAutoRangeStickyZero();
        java.awt.Stroke stroke59 = numberAxis54.getAxisLineStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis62 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis62.setInverted(true);
        boolean boolean65 = numberAxis62.isAxisLineVisible();
        boolean boolean66 = numberAxis62.getAutoRangeStickyZero();
        java.awt.Stroke stroke67 = numberAxis62.getAxisLineStroke();
        categoryPlot60.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis62);
        org.jfree.chart.axis.AxisLocation axisLocation70 = categoryPlot60.getRangeAxisLocation(0);
        float float71 = categoryPlot60.getBackgroundAlpha();
        numberAxis54.setPlot((org.jfree.chart.plot.Plot) categoryPlot60);
        org.jfree.chart.block.BlockContainer blockContainer73 = new org.jfree.chart.block.BlockContainer();
        blockContainer73.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer79 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder84 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer79.setFrame((org.jfree.chart.block.BlockFrame) blockBorder84);
        blockContainer73.add((org.jfree.chart.block.Block) blockContainer79);
        java.awt.Graphics2D graphics2D87 = null;
        org.jfree.chart.util.Size2D size2D88 = blockContainer79.arrange(graphics2D87);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor91 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D92 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D88, (double) '#', (double) 1.0f, rectangleAnchor91);
        try {
            stackedBarRenderer3D2.drawRangeGridline(graphics2D10, categoryPlot11, (org.jfree.chart.axis.ValueAxis) numberAxis54, rectangle2D92, (double) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.0d) + "'", double4 == (-1.0d));
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(itemLabelPosition30);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 4.0d + "'", double38 == 4.0d);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNull(shape47);
        org.junit.Assert.assertNotNull(categoryAxisArray51);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertNotNull(stroke67);
        org.junit.Assert.assertNotNull(axisLocation70);
        org.junit.Assert.assertTrue("'" + float71 + "' != '" + 1.0f + "'", float71 == 1.0f);
        org.junit.Assert.assertNotNull(size2D88);
        org.junit.Assert.assertNotNull(rectangleAnchor91);
        org.junit.Assert.assertNotNull(rectangle2D92);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        java.awt.Font font1 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer2.setDrawOutlines(true);
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer2.setBasePaint((java.awt.Paint) color5, false);
        org.jfree.chart.text.TextMeasurer textMeasurer9 = null;
        org.jfree.chart.text.TextBlock textBlock10 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color5, (float) (byte) -1, textMeasurer9);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D12 = textBlock10.calculateDimensions(graphics2D11);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(textBlock10);
        org.junit.Assert.assertNotNull(size2D12);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font3 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer4 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer4.setDrawOutlines(true);
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer4.setBasePaint((java.awt.Paint) color7, false);
        org.jfree.chart.text.TextMeasurer textMeasurer11 = null;
        org.jfree.chart.text.TextBlock textBlock12 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, (java.awt.Paint) color7, (float) (byte) -1, textMeasurer11);
        numberAxis1.setTickMarkPaint((java.awt.Paint) color7);
        numberAxis1.setAutoRange(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double18 = rectangleInsets16.calculateBottomOutset((double) 'a');
        double double19 = rectangleInsets16.getRight();
        numberAxis1.setTickLabelInsets(rectangleInsets16);
        numberAxis1.configure();
        boolean boolean22 = numberAxis1.isVisible();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(textBlock12);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDepthFactor((double) (byte) 1);
        piePlot3D1.setDepthFactor(0.0d);
        java.awt.Stroke[] strokeArray6 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        boolean boolean7 = piePlot3D1.equals((java.lang.Object) strokeArray6);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator8 = null;
        piePlot3D1.setLegendLabelURLGenerator(pieURLGenerator8);
        piePlot3D1.setPieIndex((int) '4');
        org.junit.Assert.assertNotNull(strokeArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("RangeType.FULL", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font3 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer4 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer4.setDrawOutlines(true);
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer4.setBasePaint((java.awt.Paint) color7, false);
        org.jfree.chart.text.TextMeasurer textMeasurer11 = null;
        org.jfree.chart.text.TextBlock textBlock12 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, (java.awt.Paint) color7, (float) (byte) -1, textMeasurer11);
        numberAxis1.setTickMarkPaint((java.awt.Paint) color7);
        numberAxis1.setAutoRange(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double18 = rectangleInsets16.calculateBottomOutset((double) 'a');
        double double19 = rectangleInsets16.getRight();
        numberAxis1.setTickLabelInsets(rectangleInsets16);
        double double22 = rectangleInsets16.calculateRightOutset((double) 10);
        double double23 = rectangleInsets16.getRight();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(textBlock12);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        boolean boolean2 = categoryAxis3D0.equals((java.lang.Object) textAnchor1);
        categoryAxis3D0.setMaximumCategoryLabelWidthRatio((float) 60000L);
        java.lang.String str5 = categoryAxis3D0.getLabelURL();
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(0);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.Range range2 = numberAxis1.getDefaultAutoRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = new org.jfree.chart.block.RectangleConstraint(range2, (double) (-1L));
        org.jfree.data.Range range6 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean8 = range6.contains((double) 2);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint(0.0d, range6);
        org.jfree.chart.block.BlockContainer blockContainer10 = new org.jfree.chart.block.BlockContainer();
        blockContainer10.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer16 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder21 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer16.setFrame((org.jfree.chart.block.BlockFrame) blockBorder21);
        blockContainer10.add((org.jfree.chart.block.Block) blockContainer16);
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.util.Size2D size2D25 = blockContainer16.arrange(graphics2D24);
        org.jfree.chart.util.Size2D size2D26 = rectangleConstraint9.calculateConstrainedSize(size2D25);
        org.jfree.chart.util.Size2D size2D27 = rectangleConstraint4.calculateConstrainedSize(size2D26);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint28 = rectangleConstraint4.toUnconstrainedWidth();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(size2D25);
        org.junit.Assert.assertNotNull(size2D26);
        org.junit.Assert.assertNotNull(size2D27);
        org.junit.Assert.assertNotNull(rectangleConstraint28);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 4, 0.0d);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis6.setInverted(true);
        boolean boolean9 = numberAxis6.isAxisLineVisible();
        boolean boolean10 = numberAxis6.getAutoRangeStickyZero();
        java.awt.Stroke stroke11 = numberAxis6.getAxisLineStroke();
        categoryPlot4.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.axis.AxisLocation axisLocation14 = categoryPlot4.getRangeAxisLocation(0);
        float float15 = categoryPlot4.getBackgroundAlpha();
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font19 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer20 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer20.setDrawOutlines(true);
        java.awt.Color color23 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer20.setBasePaint((java.awt.Paint) color23, false);
        org.jfree.chart.text.TextMeasurer textMeasurer27 = null;
        org.jfree.chart.text.TextBlock textBlock28 = org.jfree.chart.text.TextUtilities.createTextBlock("", font19, (java.awt.Paint) color23, (float) (byte) -1, textMeasurer27);
        numberAxis17.setTickMarkPaint((java.awt.Paint) color23);
        numberAxis17.configure();
        numberAxis17.setFixedAutoRange((double) (-1L));
        org.jfree.chart.axis.NumberTickUnit numberTickUnit33 = numberAxis17.getTickUnit();
        org.jfree.chart.plot.Marker marker34 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer35 = new org.jfree.chart.renderer.category.StackedBarRenderer();
        org.jfree.chart.block.BlockContainer blockContainer36 = new org.jfree.chart.block.BlockContainer();
        blockContainer36.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer42 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder47 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer42.setFrame((org.jfree.chart.block.BlockFrame) blockBorder47);
        blockContainer36.add((org.jfree.chart.block.Block) blockContainer42);
        java.awt.Graphics2D graphics2D50 = null;
        org.jfree.chart.util.Size2D size2D51 = blockContainer42.arrange(graphics2D50);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor54 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D55 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D51, (double) '#', (double) 1.0f, rectangleAnchor54);
        boolean boolean56 = stackedBarRenderer35.equals((java.lang.Object) rectangle2D55);
        barRenderer3D2.drawRangeMarker(graphics2D3, categoryPlot4, (org.jfree.chart.axis.ValueAxis) numberAxis17, marker34, rectangle2D55);
        java.lang.Object obj58 = null;
        boolean boolean59 = categoryPlot4.equals(obj58);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 1.0f + "'", float15 == 1.0f);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(textBlock28);
        org.junit.Assert.assertNotNull(numberTickUnit33);
        org.junit.Assert.assertNotNull(size2D51);
        org.junit.Assert.assertNotNull(rectangleAnchor54);
        org.junit.Assert.assertNotNull(rectangle2D55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.Range range2 = numberAxis1.getDefaultAutoRange();
        numberAxis1.setAutoTickUnitSelection(false);
        java.lang.String str5 = numberAxis1.getLabelURL();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(1.0d, (double) (short) -1);
        boolean boolean3 = stackedBarRenderer3D2.isDrawBarOutline();
        stackedBarRenderer3D2.setSeriesVisibleInLegend(1, (java.lang.Boolean) true, true);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis11.setInverted(true);
        boolean boolean14 = numberAxis11.isAxisLineVisible();
        boolean boolean15 = numberAxis11.getAutoRangeStickyZero();
        java.awt.Stroke stroke16 = numberAxis11.getAxisLineStroke();
        categoryPlot9.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis11);
        org.jfree.chart.axis.AxisSpace axisSpace18 = null;
        categoryPlot9.setFixedRangeAxisSpace(axisSpace18);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        categoryPlot9.setDomainAxis(categoryAxis20);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset22 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range23 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset22);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer26 = null;
        org.jfree.chart.plot.PolarPlot polarPlot27 = new org.jfree.chart.plot.PolarPlot(xYDataset24, valueAxis25, polarItemRenderer26);
        defaultCategoryDataset22.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot27);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo30 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo30);
        java.awt.geom.Point2D point2D32 = null;
        polarPlot27.zoomDomainAxes((double) '#', plotRenderingInfo31, point2D32);
        org.jfree.chart.block.BlockContainer blockContainer34 = new org.jfree.chart.block.BlockContainer();
        blockContainer34.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer40 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder45 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer40.setFrame((org.jfree.chart.block.BlockFrame) blockBorder45);
        blockContainer34.add((org.jfree.chart.block.Block) blockContainer40);
        java.awt.Graphics2D graphics2D48 = null;
        org.jfree.chart.util.Size2D size2D49 = blockContainer40.arrange(graphics2D48);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor52 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D53 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D49, (double) '#', (double) 1.0f, rectangleAnchor52);
        plotRenderingInfo31.setPlotArea(rectangle2D53);
        try {
            stackedBarRenderer3D2.drawBackground(graphics2D8, categoryPlot9, rectangle2D53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(range23);
        org.junit.Assert.assertNotNull(size2D49);
        org.junit.Assert.assertNotNull(rectangleAnchor52);
        org.junit.Assert.assertNotNull(rectangle2D53);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainCrosshairPaint();
        xYPlot0.clearRangeAxes();
        xYPlot0.mapDatasetToDomainAxis((int) '4', (int) (short) 0);
        boolean boolean6 = xYPlot0.isRangeZeroBaselineVisible();
        java.awt.Paint paint7 = null;
        xYPlot0.setDomainTickBandPaint(paint7);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        keyedObjects2D0.setObject((java.lang.Object) 1L, (java.lang.Comparable) 12.0d, (java.lang.Comparable) "UnitType.ABSOLUTE");
        int int6 = keyedObjects2D0.getColumnIndex((java.lang.Comparable) (-2208927599903L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("SortOrder.DESCENDING", timeZone1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.AxisState axisState5 = new org.jfree.chart.axis.AxisState((double) (-1));
        axisState5.cursorLeft(0.0d);
        java.util.List list8 = null;
        axisState5.setTicks(list8);
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer10 = new org.jfree.chart.renderer.category.StackedBarRenderer();
        org.jfree.chart.block.BlockContainer blockContainer11 = new org.jfree.chart.block.BlockContainer();
        blockContainer11.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer17 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder22 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer17.setFrame((org.jfree.chart.block.BlockFrame) blockBorder22);
        blockContainer11.add((org.jfree.chart.block.Block) blockContainer17);
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.util.Size2D size2D26 = blockContainer17.arrange(graphics2D25);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor29 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D30 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D26, (double) '#', (double) 1.0f, rectangleAnchor29);
        boolean boolean31 = stackedBarRenderer10.equals((java.lang.Object) rectangle2D30);
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint33 = xYPlot32.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = xYPlot32.getRangeAxisEdge();
        try {
            java.util.List list35 = dateAxis2.refreshTicks(graphics2D3, axisState5, rectangle2D30, rectangleEdge34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(size2D26);
        org.junit.Assert.assertNotNull(rectangleAnchor29);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(rectangleEdge34);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1, textAnchor2, (double) (-16744320));
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertNotNull(textAnchor2);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = xYPlot0.getFixedLegendItems();
        org.jfree.chart.axis.AxisLocation axisLocation4 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot0.setDomainAxisLocation(11, axisLocation4);
        org.junit.Assert.assertNull(legendItemCollection2);
        org.junit.Assert.assertNotNull(axisLocation4);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis2.setInverted(true);
        boolean boolean5 = numberAxis2.isAxisLineVisible();
        boolean boolean6 = numberAxis2.getAutoRangeStickyZero();
        java.awt.Stroke stroke7 = numberAxis2.getAxisLineStroke();
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis2);
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot0.setRangeCrosshairStroke(stroke9);
        categoryPlot0.setDomainGridlinesVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot0.getRangeAxis(0);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset18 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range19 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset18);
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer22 = null;
        org.jfree.chart.plot.PolarPlot polarPlot23 = new org.jfree.chart.plot.PolarPlot(xYDataset20, valueAxis21, polarItemRenderer22);
        defaultCategoryDataset18.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot23);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo26);
        java.awt.geom.Point2D point2D28 = null;
        polarPlot23.zoomDomainAxes((double) '#', plotRenderingInfo27, point2D28);
        org.jfree.chart.block.BlockContainer blockContainer30 = new org.jfree.chart.block.BlockContainer();
        blockContainer30.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer36 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder41 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer36.setFrame((org.jfree.chart.block.BlockFrame) blockBorder41);
        blockContainer30.add((org.jfree.chart.block.Block) blockContainer36);
        java.awt.Graphics2D graphics2D44 = null;
        org.jfree.chart.util.Size2D size2D45 = blockContainer36.arrange(graphics2D44);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor48 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D49 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D45, (double) '#', (double) 1.0f, rectangleAnchor48);
        plotRenderingInfo27.setPlotArea(rectangle2D49);
        categoryPlot15.handleClick(0, 0, plotRenderingInfo27);
        org.jfree.chart.util.Layer layer53 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection54 = categoryPlot15.getRangeMarkers(0, layer53);
        org.jfree.chart.plot.CategoryPlot categoryPlot56 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis58 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis58.setInverted(true);
        boolean boolean61 = numberAxis58.isAxisLineVisible();
        boolean boolean62 = numberAxis58.getAutoRangeStickyZero();
        java.awt.Stroke stroke63 = numberAxis58.getAxisLineStroke();
        categoryPlot56.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis58);
        org.jfree.chart.axis.AxisLocation axisLocation66 = categoryPlot56.getRangeAxisLocation(0);
        categoryPlot15.setDomainAxisLocation((int) (short) 0, axisLocation66);
        org.jfree.chart.plot.XYPlot xYPlot69 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint70 = xYPlot69.getDomainCrosshairPaint();
        int int71 = xYPlot69.getSeriesCount();
        java.awt.Paint paint72 = xYPlot69.getRangeZeroBaselinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation73 = xYPlot69.getRangeAxisLocation();
        categoryPlot15.setDomainAxisLocation(8, axisLocation73, true);
        categoryPlot0.setRangeAxisLocation(axisLocation73, false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(valueAxis14);
        org.junit.Assert.assertNull(range19);
        org.junit.Assert.assertNotNull(size2D45);
        org.junit.Assert.assertNotNull(rectangleAnchor48);
        org.junit.Assert.assertNotNull(rectangle2D49);
        org.junit.Assert.assertNotNull(layer53);
        org.junit.Assert.assertNull(collection54);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(stroke63);
        org.junit.Assert.assertNotNull(axisLocation66);
        org.junit.Assert.assertNotNull(paint70);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
        org.junit.Assert.assertNotNull(paint72);
        org.junit.Assert.assertNotNull(axisLocation73);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = null;
        statisticalLineAndShapeRenderer0.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator2, true);
        statisticalLineAndShapeRenderer0.setSeriesVisibleInLegend(0, (java.lang.Boolean) true, true);
        java.lang.Boolean boolean10 = statisticalLineAndShapeRenderer0.getSeriesVisibleInLegend(100);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        int int12 = color11.getTransparency();
        java.awt.Color color13 = color11.darker();
        statisticalLineAndShapeRenderer0.setErrorIndicatorPaint((java.awt.Paint) color11);
        java.awt.Paint paint15 = statisticalLineAndShapeRenderer0.getBaseItemLabelPaint();
        org.junit.Assert.assertNull(boolean10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis2.setInverted(true);
        boolean boolean5 = numberAxis2.isAxisLineVisible();
        boolean boolean6 = numberAxis2.getAutoRangeStickyZero();
        java.awt.Stroke stroke7 = numberAxis2.getAxisLineStroke();
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis2);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        categoryPlot0.setRangeAxis(10, valueAxis11, true);
        categoryPlot0.configureRangeAxes();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleEdge9);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues0.removeValue((java.lang.Comparable) "EXPAND");
        java.awt.Font font4 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer5 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer5.setDrawOutlines(true);
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer5.setBasePaint((java.awt.Paint) color8, false);
        org.jfree.chart.text.TextMeasurer textMeasurer12 = null;
        org.jfree.chart.text.TextBlock textBlock13 = org.jfree.chart.text.TextUtilities.createTextBlock("", font4, (java.awt.Paint) color8, (float) (byte) -1, textMeasurer12);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor17 = null;
        java.awt.Shape shape21 = textBlock13.calculateBounds(graphics2D14, (float) 1, 100.0f, textBlockAnchor17, (float) 3, (float) (short) -1, (double) 0);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset24 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range25 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset24);
        org.jfree.data.Range range26 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset24);
        java.lang.Comparable comparable27 = null;
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity29 = new org.jfree.chart.entity.CategoryItemEntity(shape21, "{0}", "EXPAND", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset24, comparable27, (java.lang.Comparable) 1.0d);
        org.jfree.chart.util.SortOrder sortOrder30 = org.jfree.chart.util.SortOrder.DESCENDING;
        boolean boolean31 = categoryItemEntity29.equals((java.lang.Object) sortOrder30);
        defaultKeyedValues0.sortByValues(sortOrder30);
        org.jfree.data.KeyToGroupMap keyToGroupMap33 = new org.jfree.data.KeyToGroupMap();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        int int35 = year34.getYear();
        java.util.TimeZone timeZone37 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("SortOrder.DESCENDING", timeZone37);
        org.jfree.chart.axis.DateTickUnit dateTickUnit39 = dateAxis38.getTickUnit();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline41 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long42 = segmentedTimeline41.getStartTime();
        int int43 = segmentedTimeline41.getSegmentsIncluded();
        long long46 = segmentedTimeline41.getExceptionSegmentCount(0L, (-1L));
        long long47 = segmentedTimeline41.getSegmentsGroupSize();
        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month(4, 0);
        java.util.Date date51 = month50.getEnd();
        long long52 = segmentedTimeline41.getTime(date51);
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date51);
        org.jfree.data.time.Month month56 = new org.jfree.data.time.Month(4, 0);
        java.util.Date date57 = month56.getEnd();
        org.jfree.data.gantt.Task task58 = new org.jfree.data.gantt.Task("", date51, date57);
        java.util.Date date59 = dateTickUnit39.addToDate(date51);
        keyToGroupMap33.mapKeyToGroup((java.lang.Comparable) int35, (java.lang.Comparable) date51);
        defaultKeyedValues0.setValue((java.lang.Comparable) date51, 1.0E-8d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(textBlock13);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertNull(range26);
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2019 + "'", int35 == 2019);
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertNotNull(dateTickUnit39);
        org.junit.Assert.assertNotNull(segmentedTimeline41);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-2208927600000L) + "'", long42 == (-2208927600000L));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 28 + "'", int43 == 28);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 86400000L + "'", long47 == 86400000L);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + (-62125372800001L) + "'", long52 == (-62125372800001L));
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertNotNull(date59);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues0.removeValue((java.lang.Comparable) "EXPAND");
        java.awt.Font font4 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer5 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer5.setDrawOutlines(true);
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer5.setBasePaint((java.awt.Paint) color8, false);
        org.jfree.chart.text.TextMeasurer textMeasurer12 = null;
        org.jfree.chart.text.TextBlock textBlock13 = org.jfree.chart.text.TextUtilities.createTextBlock("", font4, (java.awt.Paint) color8, (float) (byte) -1, textMeasurer12);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor17 = null;
        java.awt.Shape shape21 = textBlock13.calculateBounds(graphics2D14, (float) 1, 100.0f, textBlockAnchor17, (float) 3, (float) (short) -1, (double) 0);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset24 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range25 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset24);
        org.jfree.data.Range range26 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset24);
        java.lang.Comparable comparable27 = null;
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity29 = new org.jfree.chart.entity.CategoryItemEntity(shape21, "{0}", "EXPAND", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset24, comparable27, (java.lang.Comparable) 1.0d);
        org.jfree.chart.util.SortOrder sortOrder30 = org.jfree.chart.util.SortOrder.DESCENDING;
        boolean boolean31 = categoryItemEntity29.equals((java.lang.Object) sortOrder30);
        defaultKeyedValues0.sortByValues(sortOrder30);
        java.lang.Comparable comparable33 = null;
        try {
            defaultKeyedValues0.setValue(comparable33, (double) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(textBlock13);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertNull(range26);
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis2.setInverted(true);
        boolean boolean5 = numberAxis2.isAxisLineVisible();
        boolean boolean6 = numberAxis2.getAutoRangeStickyZero();
        java.awt.Stroke stroke7 = numberAxis2.getAxisLineStroke();
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis2);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer9 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean10 = statisticalLineAndShapeRenderer9.getDrawOutlines();
        statisticalLineAndShapeRenderer9.setAutoPopulateSeriesFillPaint(false);
        java.lang.Object obj13 = statisticalLineAndShapeRenderer9.clone();
        java.awt.Stroke stroke14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        statisticalLineAndShapeRenderer9.setBaseStroke(stroke14);
        boolean boolean18 = statisticalLineAndShapeRenderer9.getItemShapeVisible((int) '4', (int) (byte) 10);
        java.awt.Font font20 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        statisticalLineAndShapeRenderer9.setSeriesItemLabelFont((int) 'a', font20);
        java.awt.Paint paint22 = statisticalLineAndShapeRenderer9.getErrorIndicatorPaint();
        int int23 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer9);
        boolean boolean24 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer25 = new org.jfree.chart.renderer.category.StackedBarRenderer();
        java.awt.Font font27 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer28 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer28.setDrawOutlines(true);
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer28.setBasePaint((java.awt.Paint) color31, false);
        org.jfree.chart.text.TextMeasurer textMeasurer35 = null;
        org.jfree.chart.text.TextBlock textBlock36 = org.jfree.chart.text.TextUtilities.createTextBlock("", font27, (java.awt.Paint) color31, (float) (byte) -1, textMeasurer35);
        java.awt.Graphics2D graphics2D37 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor40 = null;
        java.awt.Shape shape44 = textBlock36.calculateBounds(graphics2D37, (float) 1, 100.0f, textBlockAnchor40, (float) 3, (float) (short) -1, (double) 0);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset47 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range48 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset47);
        org.jfree.data.Range range49 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset47);
        java.lang.Comparable comparable50 = null;
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity52 = new org.jfree.chart.entity.CategoryItemEntity(shape44, "{0}", "EXPAND", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset47, comparable50, (java.lang.Comparable) 1.0d);
        org.jfree.data.Range range53 = stackedBarRenderer25.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset47);
        java.lang.Number number54 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset47);
        java.lang.Object obj55 = defaultCategoryDataset47.clone();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer56 = categoryPlot0.getRendererForDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset47);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNull(paint22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(textBlock36);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertNull(range48);
        org.junit.Assert.assertNull(range49);
        org.junit.Assert.assertNull(range53);
        org.junit.Assert.assertNull(number54);
        org.junit.Assert.assertNotNull(obj55);
        org.junit.Assert.assertNull(categoryItemRenderer56);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainCrosshairPaint();
        xYPlot0.clearRangeAxes();
        xYPlot0.mapDatasetToDomainAxis((int) '4', (int) (short) 0);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D7 = new org.jfree.chart.plot.PiePlot3D(pieDataset6);
        piePlot3D7.setDepthFactor((double) (byte) 1);
        piePlot3D7.setDepthFactor(0.0d);
        java.awt.Stroke stroke12 = piePlot3D7.getLabelLinkStroke();
        double double13 = piePlot3D7.getShadowXOffset();
        java.lang.String str14 = piePlot3D7.getNoDataMessage();
        java.awt.Shape shape15 = piePlot3D7.getLegendItemShape();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer16 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer16.setDrawOutlines(true);
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer16.setBasePaint((java.awt.Paint) color19, false);
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer25 = null;
        org.jfree.chart.plot.PolarPlot polarPlot26 = new org.jfree.chart.plot.PolarPlot(xYDataset23, valueAxis24, polarItemRenderer25);
        java.lang.Object obj27 = null;
        boolean boolean28 = polarPlot26.equals(obj27);
        int int29 = polarPlot26.getSeriesCount();
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        polarPlot26.setAngleLabelPaint((java.awt.Paint) color30);
        statisticalLineAndShapeRenderer16.setSeriesFillPaint(2, (java.awt.Paint) color30);
        piePlot3D7.setLabelPaint((java.awt.Paint) color30);
        java.awt.Paint paint34 = piePlot3D7.getLabelBackgroundPaint();
        xYPlot0.setRangeGridlinePaint(paint34);
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset40 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset40);
        org.jfree.data.xy.XYDataset xYDataset42 = null;
        org.jfree.chart.axis.ValueAxis valueAxis43 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer44 = null;
        org.jfree.chart.plot.PolarPlot polarPlot45 = new org.jfree.chart.plot.PolarPlot(xYDataset42, valueAxis43, polarItemRenderer44);
        defaultCategoryDataset40.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot45);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo48 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo48);
        java.awt.geom.Point2D point2D50 = null;
        polarPlot45.zoomDomainAxes((double) '#', plotRenderingInfo49, point2D50);
        org.jfree.chart.block.BlockContainer blockContainer52 = new org.jfree.chart.block.BlockContainer();
        blockContainer52.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer58 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder63 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer58.setFrame((org.jfree.chart.block.BlockFrame) blockBorder63);
        blockContainer52.add((org.jfree.chart.block.Block) blockContainer58);
        java.awt.Graphics2D graphics2D66 = null;
        org.jfree.chart.util.Size2D size2D67 = blockContainer58.arrange(graphics2D66);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor70 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D71 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D67, (double) '#', (double) 1.0f, rectangleAnchor70);
        plotRenderingInfo49.setPlotArea(rectangle2D71);
        categoryPlot37.handleClick(0, 0, plotRenderingInfo49);
        org.jfree.chart.util.Layer layer75 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection76 = categoryPlot37.getRangeMarkers(0, layer75);
        org.jfree.chart.axis.AxisLocation axisLocation77 = categoryPlot37.getRangeAxisLocation();
        xYPlot0.setDomainAxisLocation((int) ' ', axisLocation77);
        java.awt.Color color79 = java.awt.Color.YELLOW;
        xYPlot0.setRangeCrosshairPaint((java.awt.Paint) color79);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.0d + "'", double13 == 4.0d);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNull(range41);
        org.junit.Assert.assertNotNull(size2D67);
        org.junit.Assert.assertNotNull(rectangleAnchor70);
        org.junit.Assert.assertNotNull(rectangle2D71);
        org.junit.Assert.assertNotNull(layer75);
        org.junit.Assert.assertNull(collection76);
        org.junit.Assert.assertNotNull(axisLocation77);
        org.junit.Assert.assertNotNull(color79);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets0.calculateRightInset(12.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        int int2 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean1 = statisticalLineAndShapeRenderer0.getDrawOutlines();
        statisticalLineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(false);
        java.lang.Object obj4 = statisticalLineAndShapeRenderer0.clone();
        java.awt.Stroke stroke5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        statisticalLineAndShapeRenderer0.setBaseStroke(stroke5);
        java.lang.Boolean boolean8 = statisticalLineAndShapeRenderer0.getSeriesShapesVisible((int) (byte) -1);
        boolean boolean11 = statisticalLineAndShapeRenderer0.getItemShapeFilled((int) (byte) 100, (int) (short) -1);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer13 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean14 = statisticalLineAndShapeRenderer13.getDrawOutlines();
        statisticalLineAndShapeRenderer13.setAutoPopulateSeriesFillPaint(false);
        java.awt.Stroke stroke18 = statisticalLineAndShapeRenderer13.lookupSeriesStroke(28);
        lineAndShapeRenderer12.setBaseStroke(stroke18);
        lineAndShapeRenderer12.setBaseItemLabelsVisible(true, true);
        lineAndShapeRenderer12.setSeriesCreateEntities((int) (short) 100, (java.lang.Boolean) true);
        lineAndShapeRenderer12.setBaseShapesVisible(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator28 = lineAndShapeRenderer12.getLegendItemLabelGenerator();
        statisticalLineAndShapeRenderer0.setLegendItemLabelGenerator(categorySeriesLabelGenerator28);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(boolean8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator28);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer1 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean2 = statisticalLineAndShapeRenderer1.getDrawOutlines();
        statisticalLineAndShapeRenderer1.setAutoPopulateSeriesFillPaint(false);
        java.awt.Stroke stroke6 = statisticalLineAndShapeRenderer1.lookupSeriesStroke(28);
        lineAndShapeRenderer0.setBaseStroke(stroke6);
        lineAndShapeRenderer0.setSeriesItemLabelsVisible(28, (java.lang.Boolean) true);
        java.awt.Paint paint11 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        lineAndShapeRenderer0.setBaseFillPaint(paint11);
        lineAndShapeRenderer0.setSeriesCreateEntities((int) (byte) 100, (java.lang.Boolean) false, true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDepthFactor((double) (byte) 1);
        piePlot3D1.setDepthFactor(0.0d);
        piePlot3D1.setInteriorGap((double) 0.0f);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator8 = piePlot3D1.getURLGenerator();
        org.jfree.data.general.PieDataset pieDataset9 = piePlot3D1.getDataset();
        java.awt.Paint paint10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        piePlot3D1.setShadowPaint(paint10);
        org.jfree.data.general.PieDataset pieDataset12 = null;
        piePlot3D1.setDataset(pieDataset12);
        java.awt.Stroke stroke14 = piePlot3D1.getLabelLinkStroke();
        org.junit.Assert.assertNull(pieURLGenerator8);
        org.junit.Assert.assertNull(pieDataset9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = numberAxis1.getMarkerBand();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = numberAxis1.getMarkerBand();
        org.jfree.data.Range range4 = numberAxis1.getRange();
        org.junit.Assert.assertNull(markerAxisBand2);
        org.junit.Assert.assertNull(markerAxisBand3);
        org.junit.Assert.assertNotNull(range4);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        polarPlot3.removeCornerTextItem("hi!");
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = polarPlot3.getOrientation();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        polarPlot3.datasetChanged(datasetChangeEvent7);
        org.junit.Assert.assertNotNull(plotOrientation6);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, (float) (byte) 100);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font3 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer4 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer4.setDrawOutlines(true);
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer4.setBasePaint((java.awt.Paint) color7, false);
        org.jfree.chart.text.TextMeasurer textMeasurer11 = null;
        org.jfree.chart.text.TextBlock textBlock12 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, (java.awt.Paint) color7, (float) (byte) -1, textMeasurer11);
        numberAxis1.setTickMarkPaint((java.awt.Paint) color7);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit15 = new org.jfree.chart.axis.NumberTickUnit(0.0d);
        numberAxis1.setTickUnit(numberTickUnit15);
        java.awt.Paint paint17 = numberAxis1.getTickMarkPaint();
        double double18 = numberAxis1.getFixedDimension();
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint20 = xYPlot19.getDomainCrosshairPaint();
        int int21 = xYPlot19.getSeriesCount();
        java.awt.Paint paint22 = xYPlot19.getRangeZeroBaselinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation23 = xYPlot19.getRangeAxisLocation();
        org.jfree.chart.axis.AxisLocation axisLocation24 = xYPlot19.getRangeAxisLocation();
        numberAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot19);
        boolean boolean26 = numberAxis1.isInverted();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(textBlock12);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        int int2 = xYPlot0.indexOf(xYDataset1);
        boolean boolean3 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = xYPlot0.getRangeAxisEdge();
        java.awt.Paint paint5 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer7 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean8 = statisticalLineAndShapeRenderer7.getDrawOutlines();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = null;
        statisticalLineAndShapeRenderer7.setSeriesNegativeItemLabelPosition((int) ' ', itemLabelPosition10);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = null;
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font17 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer18 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer18.setDrawOutlines(true);
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer18.setBasePaint((java.awt.Paint) color21, false);
        org.jfree.chart.text.TextMeasurer textMeasurer25 = null;
        org.jfree.chart.text.TextBlock textBlock26 = org.jfree.chart.text.TextUtilities.createTextBlock("", font17, (java.awt.Paint) color21, (float) (byte) -1, textMeasurer25);
        numberAxis15.setTickMarkPaint((java.awt.Paint) color21);
        numberAxis15.configure();
        org.jfree.chart.plot.Marker marker29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        statisticalLineAndShapeRenderer7.drawRangeMarker(graphics2D12, categoryPlot13, (org.jfree.chart.axis.ValueAxis) numberAxis15, marker29, rectangle2D30);
        boolean boolean32 = numberAxis15.isNegativeArrowVisible();
        xYPlot0.setRangeAxis(11, (org.jfree.chart.axis.ValueAxis) numberAxis15, false);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(textBlock26);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.event.TitleChangeListener titleChangeListener1 = null;
        textTitle0.removeChangeListener(titleChangeListener1);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = textTitle0.getHorizontalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = textTitle0.getPadding();
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer1 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean2 = statisticalLineAndShapeRenderer1.getDrawOutlines();
        statisticalLineAndShapeRenderer1.setAutoPopulateSeriesFillPaint(false);
        java.awt.Stroke stroke6 = statisticalLineAndShapeRenderer1.lookupSeriesStroke(28);
        lineAndShapeRenderer0.setBaseStroke(stroke6);
        java.awt.Paint paint9 = lineAndShapeRenderer0.getSeriesFillPaint((int) '#');
        java.awt.Stroke stroke12 = lineAndShapeRenderer0.getItemOutlineStroke(1, 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = lineAndShapeRenderer0.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline17 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long18 = segmentedTimeline17.getStartTime();
        int int19 = segmentedTimeline17.getSegmentsIncluded();
        long long22 = segmentedTimeline17.getExceptionSegmentCount(0L, (-1L));
        long long23 = segmentedTimeline17.getSegmentsGroupSize();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(4, 0);
        java.util.Date date27 = month26.getEnd();
        long long28 = segmentedTimeline17.getTime(date27);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date27);
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(4, 0);
        java.util.Date date33 = month32.getEnd();
        org.jfree.data.gantt.Task task34 = new org.jfree.data.gantt.Task("", date27, date33);
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset36 = null;
        int int37 = xYPlot35.indexOf(xYDataset36);
        org.jfree.chart.util.Layer layer39 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection40 = xYPlot35.getRangeMarkers(6, layer39);
        org.jfree.chart.axis.AxisSpace axisSpace41 = xYPlot35.getFixedRangeAxisSpace();
        xYPlot35.clearDomainAxes();
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font46 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer47 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer47.setDrawOutlines(true);
        java.awt.Color color50 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer47.setBasePaint((java.awt.Paint) color50, false);
        org.jfree.chart.text.TextMeasurer textMeasurer54 = null;
        org.jfree.chart.text.TextBlock textBlock55 = org.jfree.chart.text.TextUtilities.createTextBlock("", font46, (java.awt.Paint) color50, (float) (byte) -1, textMeasurer54);
        numberAxis44.setTickMarkPaint((java.awt.Paint) color50);
        numberAxis44.configure();
        numberAxis44.setFixedAutoRange((double) (-1L));
        java.awt.Color color60 = org.jfree.chart.ChartColor.LIGHT_RED;
        numberAxis44.setLabelPaint((java.awt.Paint) color60);
        xYPlot35.setRangeZeroBaselinePaint((java.awt.Paint) color60);
        boolean boolean63 = task34.equals((java.lang.Object) color60);
        lineAndShapeRenderer0.setSeriesPaint(255, (java.awt.Paint) color60, true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertNotNull(segmentedTimeline17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-2208927600000L) + "'", long18 == (-2208927600000L));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 28 + "'", int19 == 28);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 86400000L + "'", long23 == 86400000L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-62125372800001L) + "'", long28 == (-62125372800001L));
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(layer39);
        org.junit.Assert.assertNull(collection40);
        org.junit.Assert.assertNull(axisSpace41);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(textBlock55);
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.FlowArrangement flowArrangement1 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement1.clear();
        flowArrangement1.clear();
        org.jfree.chart.block.BlockContainer blockContainer4 = new org.jfree.chart.block.BlockContainer();
        blockContainer4.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer10 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer10.setFrame((org.jfree.chart.block.BlockFrame) blockBorder15);
        blockContainer4.add((org.jfree.chart.block.Block) blockContainer10);
        double double18 = blockContainer4.getContentXOffset();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.data.Range range21 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean23 = range21.contains((double) 2);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint24 = new org.jfree.chart.block.RectangleConstraint(0.0d, range21);
        double double25 = rectangleConstraint24.getWidth();
        org.jfree.data.Range range26 = rectangleConstraint24.getWidthRange();
        org.jfree.data.Range range27 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint28 = rectangleConstraint24.toRangeWidth(range27);
        org.jfree.chart.util.Size2D size2D29 = flowArrangement1.arrange(blockContainer4, graphics2D19, rectangleConstraint28);
        java.lang.Object obj30 = blockContainer4.clone();
        org.jfree.chart.block.Arrangement arrangement31 = blockContainer4.getArrangement();
        java.awt.Font font33 = null;
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer37 = null;
        org.jfree.chart.plot.PolarPlot polarPlot38 = new org.jfree.chart.plot.PolarPlot(xYDataset34, (org.jfree.chart.axis.ValueAxis) numberAxis36, polarItemRenderer37);
        float float39 = polarPlot38.getBackgroundAlpha();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer40 = polarPlot38.getRenderer();
        org.jfree.chart.JFreeChart jFreeChart42 = new org.jfree.chart.JFreeChart("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font33, (org.jfree.chart.plot.Plot) polarPlot38, false);
        org.jfree.chart.event.ChartProgressListener chartProgressListener43 = null;
        jFreeChart42.addProgressListener(chartProgressListener43);
        centerArrangement0.add((org.jfree.chart.block.Block) blockContainer4, (java.lang.Object) chartProgressListener43);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNull(range26);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertNotNull(rectangleConstraint28);
        org.junit.Assert.assertNotNull(size2D29);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertNotNull(arrangement31);
        org.junit.Assert.assertTrue("'" + float39 + "' != '" + 1.0f + "'", float39 == 1.0f);
        org.junit.Assert.assertNull(polarItemRenderer40);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addYears((int) (byte) -1, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        java.awt.Font font1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color2, (float) ' ', textMeasurer4);
        java.awt.image.ColorModel colorModel6 = null;
        java.awt.Rectangle rectangle7 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer8 = new org.jfree.chart.renderer.category.StackedBarRenderer();
        org.jfree.chart.block.BlockContainer blockContainer9 = new org.jfree.chart.block.BlockContainer();
        blockContainer9.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer15 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder20 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer15.setFrame((org.jfree.chart.block.BlockFrame) blockBorder20);
        blockContainer9.add((org.jfree.chart.block.Block) blockContainer15);
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.util.Size2D size2D24 = blockContainer15.arrange(graphics2D23);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor27 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D28 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D24, (double) '#', (double) 1.0f, rectangleAnchor27);
        boolean boolean29 = stackedBarRenderer8.equals((java.lang.Object) rectangle2D28);
        java.awt.geom.AffineTransform affineTransform30 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer31 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean32 = statisticalLineAndShapeRenderer31.getDrawOutlines();
        statisticalLineAndShapeRenderer31.setAutoPopulateSeriesFillPaint(false);
        java.awt.Stroke stroke36 = statisticalLineAndShapeRenderer31.lookupSeriesStroke(28);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition37 = statisticalLineAndShapeRenderer31.getBaseNegativeItemLabelPosition();
        org.jfree.data.general.PieDataset pieDataset38 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D39 = new org.jfree.chart.plot.PiePlot3D(pieDataset38);
        piePlot3D39.setDepthFactor((double) (byte) 1);
        piePlot3D39.setDepthFactor(0.0d);
        java.awt.Stroke stroke44 = piePlot3D39.getLabelLinkStroke();
        double double45 = piePlot3D39.getShadowXOffset();
        java.lang.String str46 = piePlot3D39.getNoDataMessage();
        java.awt.Paint paint47 = piePlot3D39.getBaseSectionOutlinePaint();
        org.jfree.data.general.PieDataset pieDataset48 = null;
        piePlot3D39.setDataset(pieDataset48);
        java.awt.Stroke stroke50 = piePlot3D39.getBaseSectionOutlineStroke();
        statisticalLineAndShapeRenderer31.setBaseStroke(stroke50, true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent53 = null;
        statisticalLineAndShapeRenderer31.notifyListeners(rendererChangeEvent53);
        java.awt.Font font56 = null;
        org.jfree.data.xy.XYDataset xYDataset57 = null;
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer60 = null;
        org.jfree.chart.plot.PolarPlot polarPlot61 = new org.jfree.chart.plot.PolarPlot(xYDataset57, (org.jfree.chart.axis.ValueAxis) numberAxis59, polarItemRenderer60);
        float float62 = polarPlot61.getBackgroundAlpha();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer63 = polarPlot61.getRenderer();
        org.jfree.chart.JFreeChart jFreeChart65 = new org.jfree.chart.JFreeChart("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font56, (org.jfree.chart.plot.Plot) polarPlot61, false);
        jFreeChart65.setTitle("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]");
        java.awt.Image image68 = null;
        jFreeChart65.setBackgroundImage(image68);
        org.jfree.chart.title.TextTitle textTitle70 = null;
        jFreeChart65.setTitle(textTitle70);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent74 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) statisticalLineAndShapeRenderer31, jFreeChart65, 2, (int) (byte) 0);
        int int75 = jFreeChart65.getBackgroundImageAlignment();
        java.awt.RenderingHints renderingHints76 = jFreeChart65.getRenderingHints();
        java.awt.PaintContext paintContext77 = color2.createContext(colorModel6, rectangle7, rectangle2D28, affineTransform30, renderingHints76);
        java.lang.String str78 = color2.toString();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNotNull(size2D24);
        org.junit.Assert.assertNotNull(rectangleAnchor27);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(itemLabelPosition37);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 4.0d + "'", double45 == 4.0d);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertTrue("'" + float62 + "' != '" + 1.0f + "'", float62 == 1.0f);
        org.junit.Assert.assertNull(polarItemRenderer63);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 15 + "'", int75 == 15);
        org.junit.Assert.assertNotNull(renderingHints76);
        org.junit.Assert.assertNotNull(paintContext77);
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "java.awt.Color[r=64,g=64,b=255]" + "'", str78.equals("java.awt.Color[r=64,g=64,b=255]"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("LegendItemEntity: seriesKey=null, dataset=null");
        java.lang.Throwable[] throwableArray2 = unknownKeyException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3, polarItemRenderer4);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        polarPlot5.setAngleLabelFont(font6);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        int int10 = xYPlot8.indexOf(xYDataset9);
        org.jfree.chart.util.Layer layer12 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection13 = xYPlot8.getRangeMarkers(6, layer12);
        org.jfree.chart.axis.AxisSpace axisSpace14 = xYPlot8.getFixedRangeAxisSpace();
        xYPlot8.clearDomainAxes();
        xYPlot8.setRangeCrosshairValue((double) (-1.0f), true);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("RangeType.FULL", font6, (org.jfree.chart.plot.Plot) xYPlot8, false);
        jFreeChart20.setBorderVisible(true);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(layer12);
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertNull(axisSpace14);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(7);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-458) + "'", int1 == (-458));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis2.setInverted(true);
        boolean boolean5 = numberAxis2.isAxisLineVisible();
        boolean boolean6 = numberAxis2.getAutoRangeStickyZero();
        java.awt.Stroke stroke7 = numberAxis2.getAxisLineStroke();
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis2);
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot0.setRangeCrosshairStroke(stroke9);
        categoryPlot0.setDomainGridlinesVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot0.getRangeAxis(0);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.plot.PlotOrientation plotOrientation16 = categoryPlot0.getOrientation();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(valueAxis14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(plotOrientation16);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset2, valueAxis3, polarItemRenderer4);
        defaultCategoryDataset0.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot5);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D9 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(1.0d, (double) (short) -1);
        boolean boolean10 = stackedBarRenderer3D9.isDrawBarOutline();
        boolean boolean11 = polarPlot5.equals((java.lang.Object) stackedBarRenderer3D9);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset14 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range15 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset14);
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer18 = null;
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot(xYDataset16, valueAxis17, polarItemRenderer18);
        defaultCategoryDataset14.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot19);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo22 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo22);
        java.awt.geom.Point2D point2D24 = null;
        polarPlot19.zoomDomainAxes((double) '#', plotRenderingInfo23, point2D24);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo26);
        plotRenderingInfo23.addSubplotInfo(plotRenderingInfo27);
        java.awt.geom.Point2D point2D29 = null;
        polarPlot5.zoomDomainAxes((double) 255, 1.0E-8d, plotRenderingInfo23, point2D29);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(range15);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = null;
        statisticalLineAndShapeRenderer0.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator2, true);
        java.awt.Paint paint6 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        statisticalLineAndShapeRenderer0.setSeriesItemLabelPaint(4, paint6);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset8 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset8);
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer12 = null;
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot(xYDataset10, valueAxis11, polarItemRenderer12);
        defaultCategoryDataset8.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot13);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D17 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(1.0d, (double) (short) -1);
        boolean boolean18 = stackedBarRenderer3D17.isDrawBarOutline();
        boolean boolean19 = polarPlot13.equals((java.lang.Object) stackedBarRenderer3D17);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer20 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator22 = null;
        statisticalLineAndShapeRenderer20.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator22, true);
        statisticalLineAndShapeRenderer20.setSeriesVisibleInLegend(0, (java.lang.Boolean) true, true);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(1.0d, (double) (short) -1);
        boolean boolean32 = stackedBarRenderer3D31.isDrawBarOutline();
        java.awt.Paint paint33 = stackedBarRenderer3D31.getWallPaint();
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator35 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("({0}, {1}) = {3} - {4}");
        stackedBarRenderer3D31.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator35);
        statisticalLineAndShapeRenderer20.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator35);
        stackedBarRenderer3D17.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator35);
        statisticalLineAndShapeRenderer0.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator35);
        statisticalLineAndShapeRenderer0.setItemLabelAnchorOffset(0.0d);
        statisticalLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(paint33);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font4 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer5 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer5.setDrawOutlines(true);
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer5.setBasePaint((java.awt.Paint) color8, false);
        org.jfree.chart.text.TextMeasurer textMeasurer12 = null;
        org.jfree.chart.text.TextBlock textBlock13 = org.jfree.chart.text.TextUtilities.createTextBlock("", font4, (java.awt.Paint) color8, (float) (byte) -1, textMeasurer12);
        numberAxis2.setTickMarkPaint((java.awt.Paint) color8);
        numberAxis2.configure();
        numberAxis2.setFixedAutoRange((double) (-1L));
        org.jfree.chart.axis.NumberTickUnit numberTickUnit18 = numberAxis2.getTickUnit();
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.Range range21 = numberAxis20.getDefaultAutoRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = new org.jfree.chart.block.RectangleConstraint(range21, (double) (-1L));
        numberAxis2.setRangeWithMargins(range21, false, false);
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis2);
        numberAxis2.setAutoTickUnitSelection(false, true);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(textBlock13);
        org.junit.Assert.assertNotNull(numberTickUnit18);
        org.junit.Assert.assertNotNull(range21);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font4 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer5 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer5.setDrawOutlines(true);
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer5.setBasePaint((java.awt.Paint) color8, false);
        org.jfree.chart.text.TextMeasurer textMeasurer12 = null;
        org.jfree.chart.text.TextBlock textBlock13 = org.jfree.chart.text.TextUtilities.createTextBlock("", font4, (java.awt.Paint) color8, (float) (byte) -1, textMeasurer12);
        numberAxis2.setTickMarkPaint((java.awt.Paint) color8);
        boolean boolean15 = numberAxis2.isInverted();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer16 = null;
        org.jfree.chart.plot.PolarPlot polarPlot17 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, polarItemRenderer16);
        numberAxis2.zoomRange((double) (-1.0f), (double) (short) 0);
        java.awt.Paint paint21 = numberAxis2.getTickLabelPaint();
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double25 = rectangleInsets23.calculateBottomOutset((double) 'a');
        textTitle22.setPadding(rectangleInsets23);
        java.awt.Paint paint27 = textTitle22.getPaint();
        numberAxis2.setLabelPaint(paint27);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(textBlock13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean1 = statisticalLineAndShapeRenderer0.getDrawOutlines();
        statisticalLineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(false);
        java.awt.Stroke stroke5 = statisticalLineAndShapeRenderer0.lookupSeriesStroke(28);
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalLineAndShapeRenderer0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.jfree.data.Range range8 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.Range range11 = numberAxis10.getDefaultAutoRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint(range11, (double) (-1L));
        org.jfree.data.Range range14 = org.jfree.data.Range.combine(range8, range11);
        boolean boolean17 = range11.intersects((double) (byte) -1, (double) (short) 100);
        boolean boolean18 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) rectangleAnchor7, (java.lang.Object) (byte) -1);
        legendTitle6.setLegendItemGraphicAnchor(rectangleAnchor7);
        java.awt.Paint paint20 = legendTitle6.getItemPaint();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        java.awt.Font font1 = null;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis4, polarItemRenderer5);
        float float7 = polarPlot6.getBackgroundAlpha();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer8 = polarPlot6.getRenderer();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font1, (org.jfree.chart.plot.Plot) polarPlot6, false);
        org.jfree.chart.title.TextTitle textTitle11 = null;
        jFreeChart10.setTitle(textTitle11);
        boolean boolean13 = jFreeChart10.isBorderVisible();
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertNull(polarItemRenderer8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.lang.Number number3 = defaultBoxAndWhiskerCategoryDataset0.getQ3Value((java.lang.Comparable) (byte) 1, (java.lang.Comparable) 100.0f);
        org.jfree.data.general.PieDataset pieDataset5 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0, 255);
        double double6 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset5);
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNotNull(pieDataset5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean3 = range1.contains((double) 2);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = new org.jfree.chart.block.RectangleConstraint(0.0d, range1);
        double double5 = rectangleConstraint4.getWidth();
        double double6 = rectangleConstraint4.getWidth();
        org.jfree.data.Range range7 = rectangleConstraint4.getHeightRange();
        java.lang.String str8 = rectangleConstraint4.toString();
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]" + "'", str8.equals("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]"));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("SortOrder.DESCENDING", timeZone1);
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = dateAxis2.getTickUnit();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long6 = segmentedTimeline5.getStartTime();
        int int7 = segmentedTimeline5.getSegmentsIncluded();
        long long10 = segmentedTimeline5.getExceptionSegmentCount(0L, (-1L));
        long long11 = segmentedTimeline5.getSegmentsGroupSize();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(4, 0);
        java.util.Date date15 = month14.getEnd();
        long long16 = segmentedTimeline5.getTime(date15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date15);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(4, 0);
        java.util.Date date21 = month20.getEnd();
        org.jfree.data.gantt.Task task22 = new org.jfree.data.gantt.Task("", date15, date21);
        java.util.Date date23 = dateTickUnit3.addToDate(date15);
        org.jfree.data.general.PieDataset pieDataset24 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D25 = new org.jfree.chart.plot.PiePlot3D(pieDataset24);
        piePlot3D25.setDepthFactor((double) (byte) 1);
        piePlot3D25.setDepthFactor(0.0d);
        java.awt.Stroke stroke30 = piePlot3D25.getLabelLinkStroke();
        double double31 = piePlot3D25.getShadowXOffset();
        java.lang.String str32 = piePlot3D25.getNoDataMessage();
        java.awt.Paint paint33 = piePlot3D25.getBaseSectionOutlinePaint();
        java.awt.Paint paint35 = piePlot3D25.getSectionOutlinePaint((java.lang.Comparable) 0.0d);
        boolean boolean36 = dateTickUnit3.equals((java.lang.Object) 0.0d);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(segmentedTimeline5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-2208927600000L) + "'", long6 == (-2208927600000L));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 28 + "'", int7 == 28);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 86400000L + "'", long11 == 86400000L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-62125372800001L) + "'", long16 == (-62125372800001L));
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 4.0d + "'", double31 == 4.0d);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        int int2 = xYPlot0.indexOf(xYDataset1);
        org.jfree.chart.util.Layer layer4 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(6, layer4);
        java.awt.Paint paint6 = xYPlot0.getRangeTickBandPaint();
        java.awt.Paint paint7 = xYPlot0.getDomainTickBandPaint();
        boolean boolean8 = xYPlot0.isDomainZoomable();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(layer4);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean1 = statisticalLineAndShapeRenderer0.getDrawOutlines();
        statisticalLineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(false);
        java.lang.Boolean boolean5 = statisticalLineAndShapeRenderer0.getSeriesItemLabelsVisible((int) 'a');
        statisticalLineAndShapeRenderer0.setDrawOutlines(false);
        try {
            statisticalLineAndShapeRenderer0.setSeriesVisible((int) (byte) -1, (java.lang.Boolean) true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(boolean5);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        java.awt.Font font1 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer2.setDrawOutlines(true);
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer2.setBasePaint((java.awt.Paint) color5, false);
        org.jfree.chart.text.TextMeasurer textMeasurer9 = null;
        org.jfree.chart.text.TextBlock textBlock10 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color5, (float) (byte) -1, textMeasurer9);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor14 = null;
        java.awt.Shape shape18 = textBlock10.calculateBounds(graphics2D11, (float) 1, 100.0f, textBlockAnchor14, (float) 3, (float) (short) -1, (double) 0);
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape18, (double) (-1.0f), 3.0d);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer22 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean23 = statisticalLineAndShapeRenderer22.getDrawOutlines();
        statisticalLineAndShapeRenderer22.setAutoPopulateSeriesFillPaint(false);
        java.lang.Object obj26 = statisticalLineAndShapeRenderer22.clone();
        java.awt.Stroke stroke27 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        statisticalLineAndShapeRenderer22.setBaseStroke(stroke27);
        statisticalLineAndShapeRenderer22.setBaseItemLabelsVisible(false, false);
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        statisticalLineAndShapeRenderer22.setBaseFillPaint((java.awt.Paint) color32);
        org.jfree.chart.title.LegendGraphic legendGraphic34 = new org.jfree.chart.title.LegendGraphic(shape21, (java.awt.Paint) color32);
        boolean boolean35 = legendGraphic34.isShapeOutlineVisible();
        legendGraphic34.setLineVisible(false);
        java.awt.Paint paint38 = legendGraphic34.getLinePaint();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(textBlock10);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(paint38);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainCrosshairPaint();
        int int2 = xYPlot0.getSeriesCount();
        org.jfree.chart.axis.AxisLocation axisLocation4 = null;
        xYPlot0.setRangeAxisLocation((int) (byte) 100, axisLocation4);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis9.setInverted(true);
        boolean boolean12 = numberAxis9.isAxisLineVisible();
        boolean boolean13 = numberAxis9.getAutoRangeStickyZero();
        java.awt.Stroke stroke14 = numberAxis9.getAxisLineStroke();
        categoryPlot7.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis9);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = categoryPlot7.getDomainAxisForDataset((int) ' ');
        org.jfree.chart.axis.AxisLocation axisLocation18 = categoryPlot7.getDomainAxisLocation();
        try {
            xYPlot0.setRangeAxisLocation((int) (short) -1, axisLocation18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(categoryAxis17);
        org.junit.Assert.assertNotNull(axisLocation18);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, polarItemRenderer3);
        java.awt.Font font5 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        polarPlot4.setAngleLabelFont(font5);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset9 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset9);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer13 = null;
        org.jfree.chart.plot.PolarPlot polarPlot14 = new org.jfree.chart.plot.PolarPlot(xYDataset11, valueAxis12, polarItemRenderer13);
        defaultCategoryDataset9.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot14);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo17);
        java.awt.geom.Point2D point2D19 = null;
        polarPlot14.zoomDomainAxes((double) '#', plotRenderingInfo18, point2D19);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo21 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo21);
        plotRenderingInfo18.addSubplotInfo(plotRenderingInfo22);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = plotRenderingInfo18.getSubplotInfo((int) (byte) 0);
        java.awt.geom.Point2D point2D26 = null;
        polarPlot4.zoomRangeAxes(0.0d, 0.0d, plotRenderingInfo18, point2D26);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D30 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 4, 0.0d);
        java.awt.Graphics2D graphics2D31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis34.setInverted(true);
        boolean boolean37 = numberAxis34.isAxisLineVisible();
        boolean boolean38 = numberAxis34.getAutoRangeStickyZero();
        java.awt.Stroke stroke39 = numberAxis34.getAxisLineStroke();
        categoryPlot32.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis34);
        org.jfree.chart.axis.AxisLocation axisLocation42 = categoryPlot32.getRangeAxisLocation(0);
        float float43 = categoryPlot32.getBackgroundAlpha();
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font47 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer48 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer48.setDrawOutlines(true);
        java.awt.Color color51 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer48.setBasePaint((java.awt.Paint) color51, false);
        org.jfree.chart.text.TextMeasurer textMeasurer55 = null;
        org.jfree.chart.text.TextBlock textBlock56 = org.jfree.chart.text.TextUtilities.createTextBlock("", font47, (java.awt.Paint) color51, (float) (byte) -1, textMeasurer55);
        numberAxis45.setTickMarkPaint((java.awt.Paint) color51);
        numberAxis45.configure();
        numberAxis45.setFixedAutoRange((double) (-1L));
        org.jfree.chart.axis.NumberTickUnit numberTickUnit61 = numberAxis45.getTickUnit();
        org.jfree.chart.plot.Marker marker62 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer63 = new org.jfree.chart.renderer.category.StackedBarRenderer();
        org.jfree.chart.block.BlockContainer blockContainer64 = new org.jfree.chart.block.BlockContainer();
        blockContainer64.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer70 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder75 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer70.setFrame((org.jfree.chart.block.BlockFrame) blockBorder75);
        blockContainer64.add((org.jfree.chart.block.Block) blockContainer70);
        java.awt.Graphics2D graphics2D78 = null;
        org.jfree.chart.util.Size2D size2D79 = blockContainer70.arrange(graphics2D78);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor82 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D83 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D79, (double) '#', (double) 1.0f, rectangleAnchor82);
        boolean boolean84 = stackedBarRenderer63.equals((java.lang.Object) rectangle2D83);
        barRenderer3D30.drawRangeMarker(graphics2D31, categoryPlot32, (org.jfree.chart.axis.ValueAxis) numberAxis45, marker62, rectangle2D83);
        plotRenderingInfo18.setPlotArea(rectangle2D83);
        java.awt.geom.Rectangle2D rectangle2D87 = plotRenderingInfo18.getPlotArea();
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNotNull(plotRenderingInfo25);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(axisLocation42);
        org.junit.Assert.assertTrue("'" + float43 + "' != '" + 1.0f + "'", float43 == 1.0f);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(textBlock56);
        org.junit.Assert.assertNotNull(numberTickUnit61);
        org.junit.Assert.assertNotNull(size2D79);
        org.junit.Assert.assertNotNull(rectangleAnchor82);
        org.junit.Assert.assertNotNull(rectangle2D83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNotNull(rectangle2D87);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainCrosshairPaint();
        int int2 = xYPlot0.getSeriesCount();
        java.awt.Paint paint3 = xYPlot0.getRangeTickBandPaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNull(paint3);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline1 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long2 = segmentedTimeline1.getStartTime();
        int int3 = segmentedTimeline1.getSegmentsIncluded();
        long long6 = segmentedTimeline1.getExceptionSegmentCount(0L, (-1L));
        long long7 = segmentedTimeline1.getSegmentsGroupSize();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(4, 0);
        java.util.Date date11 = month10.getEnd();
        long long12 = segmentedTimeline1.getTime(date11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date11);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(4, 0);
        java.util.Date date17 = month16.getEnd();
        org.jfree.data.gantt.Task task18 = new org.jfree.data.gantt.Task("", date11, date17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D21 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        boolean boolean23 = categoryAxis3D21.equals((java.lang.Object) textAnchor22);
        org.jfree.chart.axis.DateTick dateTick25 = new org.jfree.chart.axis.DateTick(date17, "TextBlockAnchor.TOP_CENTER", textAnchor20, textAnchor22, (double) '#');
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(4, 0);
        int int29 = month28.getMonth();
        int int30 = month28.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month28.next();
        boolean boolean32 = dateTick25.equals((java.lang.Object) regularTimePeriod31);
        double double33 = dateTick25.getValue();
        java.lang.String str34 = dateTick25.getText();
        org.junit.Assert.assertNotNull(segmentedTimeline1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2208927600000L) + "'", long2 == (-2208927600000L));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 28 + "'", int3 == 28);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 86400000L + "'", long7 == 86400000L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62125372800001L) + "'", long12 == (-62125372800001L));
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 4 + "'", int29 == 4);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + (-6.2125372800001E13d) + "'", double33 == (-6.2125372800001E13d));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "TextBlockAnchor.TOP_CENTER" + "'", str34.equals("TextBlockAnchor.TOP_CENTER"));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.gantt.Task task2 = new org.jfree.data.gantt.Task("", (org.jfree.data.time.TimePeriod) year1);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(4, 0);
        int int6 = month5.getMonth();
        int int7 = month5.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month5.next();
        task2.setDuration((org.jfree.data.time.TimePeriod) month5);
        int int10 = month5.getMonth();
        long long11 = month5.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-62159500800000L) + "'", long11 == (-62159500800000L));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean1 = statisticalLineAndShapeRenderer0.getDrawOutlines();
        statisticalLineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(false);
        java.awt.Stroke stroke5 = statisticalLineAndShapeRenderer0.lookupSeriesStroke(28);
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalLineAndShapeRenderer0);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double9 = rectangleInsets7.calculateBottomOutset((double) 'a');
        double double11 = rectangleInsets7.calculateLeftInset((double) 28);
        org.jfree.chart.util.UnitType unitType12 = rectangleInsets7.getUnitType();
        legendTitle6.setItemLabelPadding(rectangleInsets7);
        java.lang.Object obj14 = legendTitle6.clone();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNotNull(unitType12);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        int int1 = defaultBoxAndWhiskerCategoryDataset0.getRowCount();
        org.jfree.data.general.DatasetGroup datasetGroup3 = new org.jfree.data.general.DatasetGroup("");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer4 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = statisticalLineAndShapeRenderer4.getBaseItemLabelGenerator();
        statisticalLineAndShapeRenderer4.setBaseSeriesVisibleInLegend(false);
        statisticalLineAndShapeRenderer4.setDrawOutlines(false);
        statisticalLineAndShapeRenderer4.setAutoPopulateSeriesOutlineStroke(true);
        boolean boolean12 = datasetGroup3.equals((java.lang.Object) statisticalLineAndShapeRenderer4);
        defaultBoxAndWhiskerCategoryDataset0.setGroup(datasetGroup3);
        try {
            java.lang.Number number16 = defaultBoxAndWhiskerCategoryDataset0.getMinOutlier((int) (short) 1, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNull(categoryItemLabelGenerator5);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        java.awt.Font font1 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer2.setDrawOutlines(true);
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer2.setBasePaint((java.awt.Paint) color5, false);
        org.jfree.chart.text.TextMeasurer textMeasurer9 = null;
        org.jfree.chart.text.TextBlock textBlock10 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color5, (float) (byte) -1, textMeasurer9);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor14 = null;
        java.awt.Shape shape18 = textBlock10.calculateBounds(graphics2D11, (float) 1, 100.0f, textBlockAnchor14, (float) 3, (float) (short) -1, (double) 0);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset21 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range22 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset21);
        org.jfree.data.Range range23 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset21);
        java.lang.Comparable comparable24 = null;
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity26 = new org.jfree.chart.entity.CategoryItemEntity(shape18, "{0}", "EXPAND", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset21, comparable24, (java.lang.Comparable) 1.0d);
        java.lang.String str27 = categoryItemEntity26.getURLText();
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month(4, 0);
        java.util.Date date31 = month30.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = month30.previous();
        categoryItemEntity26.setColumnKey((java.lang.Comparable) month30);
        java.util.Calendar calendar34 = null;
        try {
            long long35 = month30.getMiddleMillisecond(calendar34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(textBlock10);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNull(range22);
        org.junit.Assert.assertNull(range23);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "EXPAND" + "'", str27.equals("EXPAND"));
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
    }
}

