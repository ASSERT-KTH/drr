import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis2.setInverted(true);
        boolean boolean5 = numberAxis2.isAxisLineVisible();
        boolean boolean6 = numberAxis2.getAutoRangeStickyZero();
        java.awt.Stroke stroke7 = numberAxis2.getAxisLineStroke();
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis2);
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot0.setRangeCrosshairStroke(stroke9);
        categoryPlot0.setDomainGridlinesVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot0.getRangeAxis(0);
        java.util.List list15 = categoryPlot0.getCategories();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(valueAxis14);
        org.junit.Assert.assertNull(list15);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test02");
        java.awt.Font font1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color2, (float) ' ', textMeasurer4);
        java.awt.image.ColorModel colorModel6 = null;
        java.awt.Rectangle rectangle7 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer8 = new org.jfree.chart.renderer.category.StackedBarRenderer();
        org.jfree.chart.block.BlockContainer blockContainer9 = new org.jfree.chart.block.BlockContainer();
        blockContainer9.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer15 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder20 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer15.setFrame((org.jfree.chart.block.BlockFrame) blockBorder20);
        blockContainer9.add((org.jfree.chart.block.Block) blockContainer15);
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.util.Size2D size2D24 = blockContainer15.arrange(graphics2D23);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor27 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D28 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D24, (double) '#', (double) 1.0f, rectangleAnchor27);
        boolean boolean29 = stackedBarRenderer8.equals((java.lang.Object) rectangle2D28);
        java.awt.geom.AffineTransform affineTransform30 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer31 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean32 = statisticalLineAndShapeRenderer31.getDrawOutlines();
        statisticalLineAndShapeRenderer31.setAutoPopulateSeriesFillPaint(false);
        java.awt.Stroke stroke36 = statisticalLineAndShapeRenderer31.lookupSeriesStroke(28);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition37 = statisticalLineAndShapeRenderer31.getBaseNegativeItemLabelPosition();
        org.jfree.data.general.PieDataset pieDataset38 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D39 = new org.jfree.chart.plot.PiePlot3D(pieDataset38);
        piePlot3D39.setDepthFactor((double) (byte) 1);
        piePlot3D39.setDepthFactor(0.0d);
        java.awt.Stroke stroke44 = piePlot3D39.getLabelLinkStroke();
        double double45 = piePlot3D39.getShadowXOffset();
        java.lang.String str46 = piePlot3D39.getNoDataMessage();
        java.awt.Paint paint47 = piePlot3D39.getBaseSectionOutlinePaint();
        org.jfree.data.general.PieDataset pieDataset48 = null;
        piePlot3D39.setDataset(pieDataset48);
        java.awt.Stroke stroke50 = piePlot3D39.getBaseSectionOutlineStroke();
        statisticalLineAndShapeRenderer31.setBaseStroke(stroke50, true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent53 = null;
        statisticalLineAndShapeRenderer31.notifyListeners(rendererChangeEvent53);
        java.awt.Font font56 = null;
        org.jfree.data.xy.XYDataset xYDataset57 = null;
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer60 = null;
        org.jfree.chart.plot.PolarPlot polarPlot61 = new org.jfree.chart.plot.PolarPlot(xYDataset57, (org.jfree.chart.axis.ValueAxis) numberAxis59, polarItemRenderer60);
        float float62 = polarPlot61.getBackgroundAlpha();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer63 = polarPlot61.getRenderer();
        org.jfree.chart.JFreeChart jFreeChart65 = new org.jfree.chart.JFreeChart("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font56, (org.jfree.chart.plot.Plot) polarPlot61, false);
        jFreeChart65.setTitle("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]");
        java.awt.Image image68 = null;
        jFreeChart65.setBackgroundImage(image68);
        org.jfree.chart.title.TextTitle textTitle70 = null;
        jFreeChart65.setTitle(textTitle70);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent74 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) statisticalLineAndShapeRenderer31, jFreeChart65, 2, (int) (byte) 0);
        int int75 = jFreeChart65.getBackgroundImageAlignment();
        java.awt.RenderingHints renderingHints76 = jFreeChart65.getRenderingHints();
        java.awt.PaintContext paintContext77 = color2.createContext(colorModel6, rectangle7, rectangle2D28, affineTransform30, renderingHints76);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity78 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D28);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNotNull(size2D24);
        org.junit.Assert.assertNotNull(rectangleAnchor27);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(itemLabelPosition37);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 4.0d + "'", double45 == 4.0d);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertTrue("'" + float62 + "' != '" + 1.0f + "'", float62 == 1.0f);
        org.junit.Assert.assertNull(polarItemRenderer63);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 15 + "'", int75 == 15);
        org.junit.Assert.assertNotNull(renderingHints76);
        org.junit.Assert.assertNotNull(paintContext77);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test03");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) (-1));
        axisState1.cursorLeft((double) 5);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test04");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        java.util.Date date2 = segmentedTimeline0.getDate(0L);
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2, timeZone3);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test05");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean1 = statisticalLineAndShapeRenderer0.getDrawOutlines();
        statisticalLineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(false);
        java.awt.Stroke stroke5 = statisticalLineAndShapeRenderer0.lookupSeriesStroke(28);
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalLineAndShapeRenderer0);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double9 = rectangleInsets7.calculateBottomOutset((double) 'a');
        double double11 = rectangleInsets7.calculateLeftInset((double) 28);
        double double13 = rectangleInsets7.calculateTopOutset(0.4d);
        legendTitle6.setItemLabelPadding(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test06");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = statisticalLineAndShapeRenderer0.getBaseItemLabelGenerator();
        statisticalLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false);
        java.lang.Boolean boolean5 = statisticalLineAndShapeRenderer0.getSeriesCreateEntities(255);
        java.awt.Paint paint6 = statisticalLineAndShapeRenderer0.getBasePaint();
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        int int9 = xYPlot7.indexOf(xYDataset8);
        xYPlot7.setRangeGridlinesVisible(false);
        java.awt.Paint paint12 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot7.setRangeTickBandPaint(paint12);
        statisticalLineAndShapeRenderer0.setBaseFillPaint(paint12, false);
        statisticalLineAndShapeRenderer0.setSeriesLinesVisible(3, true);
        java.awt.Paint paint21 = statisticalLineAndShapeRenderer0.getItemLabelPaint(255, (int) '#');
        org.junit.Assert.assertNull(categoryItemLabelGenerator1);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test07");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("");
        taskSeries1.fireSeriesChanged();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        taskSeries1.removeChangeListener(seriesChangeListener3);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.gantt.Task task7 = new org.jfree.data.gantt.Task("", (org.jfree.data.time.TimePeriod) year6);
        taskSeries1.remove(task7);
        taskSeries1.setKey((java.lang.Comparable) "poly");
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test08");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.axis.AxisCollection axisCollection1 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list2 = axisCollection1.getAxesAtRight();
        boolean boolean3 = unitType0.equals((java.lang.Object) list2);
        java.lang.String str4 = unitType0.toString();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UnitType.ABSOLUTE" + "'", str4.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test09");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        int int2 = xYPlot0.indexOf(xYDataset1);
        org.jfree.chart.util.Layer layer4 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(6, layer4);
        java.awt.Paint paint6 = xYPlot0.getRangeTickBandPaint();
        java.awt.Paint paint7 = xYPlot0.getDomainTickBandPaint();
        java.awt.Paint paint8 = xYPlot0.getRangeGridlinePaint();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(layer4);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test10");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(1.0d, (double) (short) -1);
        boolean boolean3 = stackedBarRenderer3D2.isDrawBarOutline();
        double double4 = stackedBarRenderer3D2.getYOffset();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset5 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range7 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset5, true);
        org.jfree.data.Range range8 = stackedBarRenderer3D2.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset5);
        boolean boolean9 = stackedBarRenderer3D2.isDrawBarOutline();
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset10 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.lang.Number number13 = defaultBoxAndWhiskerCategoryDataset10.getQ3Value((java.lang.Comparable) (byte) 1, (java.lang.Comparable) 100.0f);
        org.jfree.data.general.PieDataset pieDataset15 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset10, 255);
        org.jfree.data.Range range16 = stackedBarRenderer3D2.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.0d) + "'", double4 == (-1.0d));
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertNotNull(pieDataset15);
        org.junit.Assert.assertNull(range16);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test11");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = statisticalLineAndShapeRenderer0.getBaseItemLabelGenerator();
        boolean boolean4 = statisticalLineAndShapeRenderer0.getItemLineVisible(8, (int) (byte) 0);
        java.awt.Paint paint6 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        statisticalLineAndShapeRenderer0.setSeriesPaint(0, paint6);
        org.junit.Assert.assertNull(categoryItemLabelGenerator1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test12");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge();
        java.awt.Paint paint3 = xYPlot0.getRangeCrosshairPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset8 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset8);
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer12 = null;
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot(xYDataset10, valueAxis11, polarItemRenderer12);
        defaultCategoryDataset8.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot13);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo16);
        java.awt.geom.Point2D point2D18 = null;
        polarPlot13.zoomDomainAxes((double) '#', plotRenderingInfo17, point2D18);
        org.jfree.chart.block.BlockContainer blockContainer20 = new org.jfree.chart.block.BlockContainer();
        blockContainer20.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer26 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder31 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer26.setFrame((org.jfree.chart.block.BlockFrame) blockBorder31);
        blockContainer20.add((org.jfree.chart.block.Block) blockContainer26);
        java.awt.Graphics2D graphics2D34 = null;
        org.jfree.chart.util.Size2D size2D35 = blockContainer26.arrange(graphics2D34);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor38 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D39 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D35, (double) '#', (double) 1.0f, rectangleAnchor38);
        plotRenderingInfo17.setPlotArea(rectangle2D39);
        categoryPlot5.handleClick(0, 0, plotRenderingInfo17);
        org.jfree.chart.util.Layer layer43 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection44 = categoryPlot5.getRangeMarkers(0, layer43);
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis48 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis48.setInverted(true);
        boolean boolean51 = numberAxis48.isAxisLineVisible();
        boolean boolean52 = numberAxis48.getAutoRangeStickyZero();
        java.awt.Stroke stroke53 = numberAxis48.getAxisLineStroke();
        categoryPlot46.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis48);
        org.jfree.chart.axis.AxisLocation axisLocation56 = categoryPlot46.getRangeAxisLocation(0);
        categoryPlot5.setDomainAxisLocation((int) (short) 0, axisLocation56);
        org.jfree.chart.axis.AxisLocation axisLocation58 = axisLocation56.getOpposite();
        xYPlot0.setDomainAxisLocation(0, axisLocation58);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertNotNull(size2D35);
        org.junit.Assert.assertNotNull(rectangleAnchor38);
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertNotNull(layer43);
        org.junit.Assert.assertNull(collection44);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(axisLocation56);
        org.junit.Assert.assertNotNull(axisLocation58);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test13");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.awt.Image image1 = projectInfo0.getLogo();
        projectInfo0.setCopyright("Layer.FOREGROUND");
        org.junit.Assert.assertNull(image1);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test14");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.Range range2 = numberAxis1.getDefaultAutoRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = new org.jfree.chart.block.RectangleConstraint(range2, (double) (-1L));
        org.jfree.data.Range range6 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean8 = range6.contains((double) 2);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint(0.0d, range6);
        org.jfree.chart.block.BlockContainer blockContainer10 = new org.jfree.chart.block.BlockContainer();
        blockContainer10.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer16 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder21 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer16.setFrame((org.jfree.chart.block.BlockFrame) blockBorder21);
        blockContainer10.add((org.jfree.chart.block.Block) blockContainer16);
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.util.Size2D size2D25 = blockContainer16.arrange(graphics2D24);
        org.jfree.chart.util.Size2D size2D26 = rectangleConstraint9.calculateConstrainedSize(size2D25);
        org.jfree.chart.util.Size2D size2D27 = rectangleConstraint4.calculateConstrainedSize(size2D26);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis30.setInverted(true);
        boolean boolean33 = numberAxis30.isAxisLineVisible();
        boolean boolean34 = numberAxis30.getAutoRangeStickyZero();
        java.awt.Stroke stroke35 = numberAxis30.getAxisLineStroke();
        categoryPlot28.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis30);
        org.jfree.chart.axis.AxisLocation axisLocation38 = categoryPlot28.getRangeAxisLocation(0);
        categoryPlot28.setRangeGridlinesVisible(false);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer41 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean42 = statisticalLineAndShapeRenderer41.getDrawOutlines();
        statisticalLineAndShapeRenderer41.setAutoPopulateSeriesFillPaint(false);
        java.awt.Stroke stroke46 = statisticalLineAndShapeRenderer41.lookupSeriesStroke(28);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition47 = statisticalLineAndShapeRenderer41.getBaseNegativeItemLabelPosition();
        org.jfree.data.general.PieDataset pieDataset48 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D49 = new org.jfree.chart.plot.PiePlot3D(pieDataset48);
        piePlot3D49.setDepthFactor((double) (byte) 1);
        piePlot3D49.setDepthFactor(0.0d);
        java.awt.Stroke stroke54 = piePlot3D49.getLabelLinkStroke();
        double double55 = piePlot3D49.getShadowXOffset();
        java.lang.String str56 = piePlot3D49.getNoDataMessage();
        java.awt.Paint paint57 = piePlot3D49.getBaseSectionOutlinePaint();
        org.jfree.data.general.PieDataset pieDataset58 = null;
        piePlot3D49.setDataset(pieDataset58);
        java.awt.Stroke stroke60 = piePlot3D49.getBaseSectionOutlineStroke();
        statisticalLineAndShapeRenderer41.setBaseStroke(stroke60, true);
        java.awt.Shape shape64 = statisticalLineAndShapeRenderer41.getSeriesShape((int) (short) 0);
        categoryPlot28.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer41, true);
        categoryPlot28.configureDomainAxes();
        boolean boolean68 = size2D27.equals((java.lang.Object) categoryPlot28);
        org.jfree.chart.util.SortOrder sortOrder69 = categoryPlot28.getColumnRenderingOrder();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(size2D25);
        org.junit.Assert.assertNotNull(size2D26);
        org.junit.Assert.assertNotNull(size2D27);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(itemLabelPosition47);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 4.0d + "'", double55 == 4.0d);
        org.junit.Assert.assertNull(str56);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertNull(shape64);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(sortOrder69);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test15");
        java.awt.Font font1 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer2.setDrawOutlines(true);
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer2.setBasePaint((java.awt.Paint) color5, false);
        org.jfree.chart.text.TextMeasurer textMeasurer9 = null;
        org.jfree.chart.text.TextBlock textBlock10 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color5, (float) (byte) -1, textMeasurer9);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor14 = null;
        java.awt.Shape shape18 = textBlock10.calculateBounds(graphics2D11, (float) 1, 100.0f, textBlockAnchor14, (float) 3, (float) (short) -1, (double) 0);
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape18, (double) (-1.0f), 3.0d);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer22 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean23 = statisticalLineAndShapeRenderer22.getDrawOutlines();
        statisticalLineAndShapeRenderer22.setAutoPopulateSeriesFillPaint(false);
        java.lang.Object obj26 = statisticalLineAndShapeRenderer22.clone();
        java.awt.Stroke stroke27 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        statisticalLineAndShapeRenderer22.setBaseStroke(stroke27);
        statisticalLineAndShapeRenderer22.setBaseItemLabelsVisible(false, false);
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        statisticalLineAndShapeRenderer22.setBaseFillPaint((java.awt.Paint) color32);
        org.jfree.chart.title.LegendGraphic legendGraphic34 = new org.jfree.chart.title.LegendGraphic(shape21, (java.awt.Paint) color32);
        java.awt.Paint paint35 = legendGraphic34.getLinePaint();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(textBlock10);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNull(paint35);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test16");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainCrosshairPaint();
        xYPlot0.clearRangeAxes();
        boolean boolean3 = xYPlot0.isRangeZeroBaselineVisible();
        boolean boolean4 = xYPlot0.isDomainGridlinesVisible();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder5 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.RangeType rangeType8 = numberAxis7.getRangeType();
        java.awt.Stroke stroke9 = numberAxis7.getAxisLineStroke();
        xYPlot0.setRangeCrosshairStroke(stroke9);
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D12 = new org.jfree.chart.plot.PiePlot3D(pieDataset11);
        piePlot3D12.setDepthFactor((double) (byte) 1);
        piePlot3D12.setDepthFactor(0.0d);
        java.awt.Stroke stroke17 = piePlot3D12.getLabelLinkStroke();
        xYPlot0.setDomainZeroBaselineStroke(stroke17);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder5);
        org.junit.Assert.assertNotNull(rangeType8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test17");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 6, 1.0E-8d, (-6.2125372800001E13d), 2019.0d);
        double double7 = rectangleInsets5.calculateLeftInset((double) (byte) 0);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0E-8d + "'", double7 == 1.0E-8d);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test18");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean1 = statisticalLineAndShapeRenderer0.getDrawOutlines();
        statisticalLineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(false);
        java.awt.Stroke stroke5 = statisticalLineAndShapeRenderer0.lookupSeriesStroke(28);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = statisticalLineAndShapeRenderer0.getBaseNegativeItemLabelPosition();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = statisticalLineAndShapeRenderer0.getSeriesPositiveItemLabelPosition(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test19");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis2.setInverted(true);
        boolean boolean5 = numberAxis2.isAxisLineVisible();
        boolean boolean6 = numberAxis2.getAutoRangeStickyZero();
        java.awt.Stroke stroke7 = numberAxis2.getAxisLineStroke();
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis2);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer9 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean10 = statisticalLineAndShapeRenderer9.getDrawOutlines();
        statisticalLineAndShapeRenderer9.setAutoPopulateSeriesFillPaint(false);
        java.lang.Object obj13 = statisticalLineAndShapeRenderer9.clone();
        java.awt.Stroke stroke14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        statisticalLineAndShapeRenderer9.setBaseStroke(stroke14);
        boolean boolean18 = statisticalLineAndShapeRenderer9.getItemShapeVisible((int) '4', (int) (byte) 10);
        java.awt.Font font20 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        statisticalLineAndShapeRenderer9.setSeriesItemLabelFont((int) 'a', font20);
        java.awt.Paint paint22 = statisticalLineAndShapeRenderer9.getErrorIndicatorPaint();
        int int23 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer9);
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font27 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer28 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer28.setDrawOutlines(true);
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer28.setBasePaint((java.awt.Paint) color31, false);
        org.jfree.chart.text.TextMeasurer textMeasurer35 = null;
        org.jfree.chart.text.TextBlock textBlock36 = org.jfree.chart.text.TextUtilities.createTextBlock("", font27, (java.awt.Paint) color31, (float) (byte) -1, textMeasurer35);
        numberAxis25.setTickMarkPaint((java.awt.Paint) color31);
        numberAxis25.setLabelURL("RectangleConstraintType.RANGE");
        boolean boolean40 = categoryPlot0.equals((java.lang.Object) numberAxis25);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand41 = numberAxis25.getMarkerBand();
        java.text.NumberFormat numberFormat42 = numberAxis25.getNumberFormatOverride();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNull(paint22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(textBlock36);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNull(markerAxisBand41);
        org.junit.Assert.assertNull(numberFormat42);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test20");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean1 = statisticalLineAndShapeRenderer0.getDrawOutlines();
        statisticalLineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(false);
        java.awt.Stroke stroke5 = statisticalLineAndShapeRenderer0.lookupSeriesStroke(28);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = statisticalLineAndShapeRenderer0.getBaseNegativeItemLabelPosition();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D(pieDataset7);
        piePlot3D8.setDepthFactor((double) (byte) 1);
        piePlot3D8.setDepthFactor(0.0d);
        java.awt.Stroke stroke13 = piePlot3D8.getLabelLinkStroke();
        double double14 = piePlot3D8.getShadowXOffset();
        java.lang.String str15 = piePlot3D8.getNoDataMessage();
        java.awt.Paint paint16 = piePlot3D8.getBaseSectionOutlinePaint();
        org.jfree.data.general.PieDataset pieDataset17 = null;
        piePlot3D8.setDataset(pieDataset17);
        java.awt.Stroke stroke19 = piePlot3D8.getBaseSectionOutlineStroke();
        statisticalLineAndShapeRenderer0.setBaseStroke(stroke19, true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent22 = null;
        statisticalLineAndShapeRenderer0.notifyListeners(rendererChangeEvent22);
        java.awt.Font font25 = null;
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer29 = null;
        org.jfree.chart.plot.PolarPlot polarPlot30 = new org.jfree.chart.plot.PolarPlot(xYDataset26, (org.jfree.chart.axis.ValueAxis) numberAxis28, polarItemRenderer29);
        float float31 = polarPlot30.getBackgroundAlpha();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer32 = polarPlot30.getRenderer();
        org.jfree.chart.JFreeChart jFreeChart34 = new org.jfree.chart.JFreeChart("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font25, (org.jfree.chart.plot.Plot) polarPlot30, false);
        jFreeChart34.setTitle("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]");
        java.awt.Image image37 = null;
        jFreeChart34.setBackgroundImage(image37);
        org.jfree.chart.title.TextTitle textTitle39 = null;
        jFreeChart34.setTitle(textTitle39);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent43 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) statisticalLineAndShapeRenderer0, jFreeChart34, 2, (int) (byte) 0);
        int int44 = jFreeChart34.getBackgroundImageAlignment();
        java.awt.RenderingHints renderingHints45 = jFreeChart34.getRenderingHints();
        org.jfree.chart.title.TextTitle textTitle46 = new org.jfree.chart.title.TextTitle();
        boolean boolean47 = textTitle46.getExpandToFitSpace();
        org.jfree.chart.util.VerticalAlignment verticalAlignment48 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        textTitle46.setVerticalAlignment(verticalAlignment48);
        jFreeChart34.addSubtitle((org.jfree.chart.title.Title) textTitle46);
        org.jfree.chart.title.Title title52 = jFreeChart34.getSubtitle(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + 1.0f + "'", float31 == 1.0f);
        org.junit.Assert.assertNull(polarItemRenderer32);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 15 + "'", int44 == 15);
        org.junit.Assert.assertNotNull(renderingHints45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(verticalAlignment48);
        org.junit.Assert.assertNotNull(title52);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test21");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font4 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer5 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer5.setDrawOutlines(true);
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer5.setBasePaint((java.awt.Paint) color8, false);
        org.jfree.chart.text.TextMeasurer textMeasurer12 = null;
        org.jfree.chart.text.TextBlock textBlock13 = org.jfree.chart.text.TextUtilities.createTextBlock("", font4, (java.awt.Paint) color8, (float) (byte) -1, textMeasurer12);
        numberAxis2.setTickMarkPaint((java.awt.Paint) color8);
        boolean boolean15 = numberAxis2.isInverted();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer16 = null;
        org.jfree.chart.plot.PolarPlot polarPlot17 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, polarItemRenderer16);
        numberAxis2.zoomRange((double) (-1.0f), (double) (short) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = numberAxis2.getLabelInsets();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent22 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis2);
        java.awt.Font font24 = null;
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer28 = null;
        org.jfree.chart.plot.PolarPlot polarPlot29 = new org.jfree.chart.plot.PolarPlot(xYDataset25, (org.jfree.chart.axis.ValueAxis) numberAxis27, polarItemRenderer28);
        float float30 = polarPlot29.getBackgroundAlpha();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer31 = polarPlot29.getRenderer();
        org.jfree.chart.JFreeChart jFreeChart33 = new org.jfree.chart.JFreeChart("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font24, (org.jfree.chart.plot.Plot) polarPlot29, false);
        jFreeChart33.setTitle("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]");
        axisChangeEvent22.setChart(jFreeChart33);
        try {
            org.jfree.chart.plot.CategoryPlot categoryPlot37 = jFreeChart33.getCategoryPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PolarPlot cannot be cast to org.jfree.chart.plot.CategoryPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(textBlock13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 1.0f + "'", float30 == 1.0f);
        org.junit.Assert.assertNull(polarItemRenderer31);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test22");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer1 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator3 = null;
        statisticalLineAndShapeRenderer1.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator3, true);
        java.awt.Paint paint7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        statisticalLineAndShapeRenderer1.setSeriesItemLabelPaint(4, paint7);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset9 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset9);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer13 = null;
        org.jfree.chart.plot.PolarPlot polarPlot14 = new org.jfree.chart.plot.PolarPlot(xYDataset11, valueAxis12, polarItemRenderer13);
        defaultCategoryDataset9.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot14);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(1.0d, (double) (short) -1);
        boolean boolean19 = stackedBarRenderer3D18.isDrawBarOutline();
        boolean boolean20 = polarPlot14.equals((java.lang.Object) stackedBarRenderer3D18);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer21 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator23 = null;
        statisticalLineAndShapeRenderer21.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator23, true);
        statisticalLineAndShapeRenderer21.setSeriesVisibleInLegend(0, (java.lang.Boolean) true, true);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D32 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(1.0d, (double) (short) -1);
        boolean boolean33 = stackedBarRenderer3D32.isDrawBarOutline();
        java.awt.Paint paint34 = stackedBarRenderer3D32.getWallPaint();
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator36 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("({0}, {1}) = {3} - {4}");
        stackedBarRenderer3D32.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator36);
        statisticalLineAndShapeRenderer21.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator36);
        stackedBarRenderer3D18.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator36);
        statisticalLineAndShapeRenderer1.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator36);
        statisticalLineAndShapeRenderer1.setItemLabelAnchorOffset(0.0d);
        boolean boolean43 = statisticalLineAndShapeRenderer1.getUseOutlinePaint();
        java.lang.Class<?> wildcardClass44 = statisticalLineAndShapeRenderer1.getClass();
        java.io.InputStream inputStream45 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("First", (java.lang.Class) wildcardClass44);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertNull(inputStream45);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test23");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean1 = statisticalLineAndShapeRenderer0.getDrawOutlines();
        statisticalLineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(false);
        java.lang.Object obj4 = statisticalLineAndShapeRenderer0.clone();
        java.awt.Stroke stroke5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        statisticalLineAndShapeRenderer0.setBaseStroke(stroke5);
        statisticalLineAndShapeRenderer0.setBaseItemLabelsVisible(false, false);
        boolean boolean10 = statisticalLineAndShapeRenderer0.getUseFillPaint();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test24");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis2.setInverted(true);
        boolean boolean5 = numberAxis2.isAxisLineVisible();
        boolean boolean6 = numberAxis2.getAutoRangeStickyZero();
        java.awt.Stroke stroke7 = numberAxis2.getAxisLineStroke();
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis2);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer9 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean10 = statisticalLineAndShapeRenderer9.getDrawOutlines();
        statisticalLineAndShapeRenderer9.setAutoPopulateSeriesFillPaint(false);
        java.lang.Object obj13 = statisticalLineAndShapeRenderer9.clone();
        java.awt.Stroke stroke14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        statisticalLineAndShapeRenderer9.setBaseStroke(stroke14);
        boolean boolean18 = statisticalLineAndShapeRenderer9.getItemShapeVisible((int) '4', (int) (byte) 10);
        java.awt.Font font20 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        statisticalLineAndShapeRenderer9.setSeriesItemLabelFont((int) 'a', font20);
        java.awt.Paint paint22 = statisticalLineAndShapeRenderer9.getErrorIndicatorPaint();
        int int23 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer9);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer24 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean25 = statisticalLineAndShapeRenderer24.getDrawOutlines();
        int int26 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer24);
        statisticalLineAndShapeRenderer24.setBaseShapesFilled(false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer29 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer30 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean31 = statisticalLineAndShapeRenderer30.getDrawOutlines();
        statisticalLineAndShapeRenderer30.setAutoPopulateSeriesFillPaint(false);
        java.awt.Stroke stroke35 = statisticalLineAndShapeRenderer30.lookupSeriesStroke(28);
        lineAndShapeRenderer29.setBaseStroke(stroke35);
        lineAndShapeRenderer29.setBaseItemLabelsVisible(true, true);
        lineAndShapeRenderer29.setSeriesCreateEntities((int) (short) 100, (java.lang.Boolean) true);
        lineAndShapeRenderer29.setBaseShapesVisible(false);
        boolean boolean45 = statisticalLineAndShapeRenderer24.equals((java.lang.Object) lineAndShapeRenderer29);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNull(paint22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test25");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font4 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer5 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer5.setDrawOutlines(true);
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer5.setBasePaint((java.awt.Paint) color8, false);
        org.jfree.chart.text.TextMeasurer textMeasurer12 = null;
        org.jfree.chart.text.TextBlock textBlock13 = org.jfree.chart.text.TextUtilities.createTextBlock("", font4, (java.awt.Paint) color8, (float) (byte) -1, textMeasurer12);
        numberAxis2.setTickMarkPaint((java.awt.Paint) color8);
        boolean boolean15 = numberAxis2.isInverted();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer16 = null;
        org.jfree.chart.plot.PolarPlot polarPlot17 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, polarItemRenderer16);
        numberAxis2.zoomRange((double) (-1.0f), (double) (short) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = numberAxis2.getLabelInsets();
        numberAxis2.setLowerBound((double) 86400000L);
        numberAxis2.setUpperBound((double) ' ');
        double double26 = numberAxis2.getLabelAngle();
        numberAxis2.setNegativeArrowVisible(false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(textBlock13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test26");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_90;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test27");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        boolean boolean1 = textTitle0.getExpandToFitSpace();
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        textTitle0.setVerticalAlignment(verticalAlignment2);
        double double4 = textTitle0.getWidth();
        textTitle0.setURLText("hi!");
        java.lang.Object obj7 = textTitle0.clone();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test28");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean1 = statisticalLineAndShapeRenderer0.getDrawOutlines();
        statisticalLineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(false);
        java.awt.Stroke stroke5 = statisticalLineAndShapeRenderer0.lookupSeriesStroke(28);
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalLineAndShapeRenderer0);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double9 = rectangleInsets7.calculateBottomOutset((double) 'a');
        double double11 = rectangleInsets7.calculateLeftInset((double) 28);
        org.jfree.chart.util.UnitType unitType12 = rectangleInsets7.getUnitType();
        legendTitle6.setItemLabelPadding(rectangleInsets7);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = null;
        legendTitle6.setLegendItemGraphicLocation(rectangleAnchor14);
        java.awt.Paint paint16 = legendTitle6.getBackgroundPaint();
        java.awt.Paint paint17 = legendTitle6.getBackgroundPaint();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNotNull(unitType12);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNull(paint17);
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test29");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        try {
            java.awt.Paint paint3 = xYPlot0.getQuadrantPaint((-458));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test30");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(1.0d, (double) (short) -1);
        boolean boolean4 = stackedBarRenderer3D3.isDrawBarOutline();
        double double5 = stackedBarRenderer3D3.getYOffset();
        stackedBarRenderer3D3.setItemLabelAnchorOffset((double) (byte) 0);
        java.awt.Paint paint8 = stackedBarRenderer3D3.getWallPaint();
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D10 = new org.jfree.chart.plot.PiePlot3D(pieDataset9);
        piePlot3D10.setDepthFactor((double) (byte) 1);
        piePlot3D10.setDepthFactor(0.0d);
        java.awt.Stroke stroke15 = piePlot3D10.getLabelLinkStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10.0d, paint8, stroke15);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer17 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer18 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean19 = statisticalLineAndShapeRenderer18.getDrawOutlines();
        statisticalLineAndShapeRenderer18.setAutoPopulateSeriesFillPaint(false);
        java.awt.Stroke stroke23 = statisticalLineAndShapeRenderer18.lookupSeriesStroke(28);
        lineAndShapeRenderer17.setBaseStroke(stroke23);
        lineAndShapeRenderer17.setSeriesItemLabelsVisible(28, (java.lang.Boolean) true);
        java.awt.Stroke stroke29 = lineAndShapeRenderer17.lookupSeriesStroke(15);
        categoryMarker16.setStroke(stroke29);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(stroke29);
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test31");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean1 = statisticalLineAndShapeRenderer0.getDrawOutlines();
        statisticalLineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(false);
        java.lang.Object obj4 = statisticalLineAndShapeRenderer0.clone();
        java.awt.Stroke stroke5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        statisticalLineAndShapeRenderer0.setBaseStroke(stroke5);
        boolean boolean9 = statisticalLineAndShapeRenderer0.getItemShapeVisible((int) '4', (int) (byte) 10);
        java.awt.Font font11 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        statisticalLineAndShapeRenderer0.setSeriesItemLabelFont((int) 'a', font11);
        java.lang.Boolean boolean14 = statisticalLineAndShapeRenderer0.getSeriesLinesVisible(0);
        java.awt.Shape shape15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.Shape shape19 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape15, rectangleAnchor16, (double) (-2208927600000L), (double) (byte) 0);
        statisticalLineAndShapeRenderer0.setBaseShape(shape15);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset21 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range22 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset21);
        defaultCategoryDataset21.removeColumn((java.lang.Comparable) 100L);
        defaultCategoryDataset21.removeColumn((java.lang.Comparable) 0.2d);
        org.jfree.data.Range range27 = statisticalLineAndShapeRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset21);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNull(boolean14);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNull(range22);
        org.junit.Assert.assertNull(range27);
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test32");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test33");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.awt.Font font2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer3.setDrawOutlines(true);
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer3.setBasePaint((java.awt.Paint) color6, false);
        org.jfree.chart.text.TextMeasurer textMeasurer10 = null;
        org.jfree.chart.text.TextBlock textBlock11 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, (java.awt.Paint) color6, (float) (byte) -1, textMeasurer10);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor15 = null;
        java.awt.Shape shape19 = textBlock11.calculateBounds(graphics2D12, (float) 1, 100.0f, textBlockAnchor15, (float) 3, (float) (short) -1, (double) 0);
        java.awt.Font font22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.text.TextBlock textBlock24 = org.jfree.chart.text.TextUtilities.createTextBlock("{0}", font22, (java.awt.Paint) color23);
        java.awt.Paint paint25 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        textBlock11.addLine("{0}", font22, paint25);
        org.jfree.chart.text.TextLine textLine27 = new org.jfree.chart.text.TextLine();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions29 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((double) (byte) 100);
        boolean boolean30 = textLine27.equals((java.lang.Object) (byte) 100);
        textBlock11.addLine(textLine27);
        boolean boolean32 = boxAndWhiskerRenderer0.equals((java.lang.Object) textLine27);
        boxAndWhiskerRenderer0.setItemMargin(10.0d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(textBlock11);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(textBlock24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(categoryLabelPositions29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test34");
        org.jfree.chart.renderer.category.LayeredBarRenderer layeredBarRenderer0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
        layeredBarRenderer0.setSeriesBarWidth(11, (double) (-62125372800001L));
        boolean boolean4 = layeredBarRenderer0.getAutoPopulateSeriesStroke();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test35");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer0.setFrame((org.jfree.chart.block.BlockFrame) blockBorder5);
        blockContainer0.clear();
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test36");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test37");
        org.jfree.data.KeyedValues keyedValues1 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) "ItemLabelAnchor.OUTSIDE8", keyedValues1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowData' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test38");
        java.lang.String str0 = org.jfree.chart.ui.Licences.GPL;
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test39");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDepthFactor((double) (byte) 1);
        piePlot3D1.setDepthFactor(0.0d);
        java.awt.Stroke stroke6 = piePlot3D1.getLabelLinkStroke();
        double double7 = piePlot3D1.getShadowXOffset();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        int int9 = color8.getTransparency();
        piePlot3D1.setLabelLinkPaint((java.awt.Paint) color8);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor11 = piePlot3D1.getLabelDistributor();
        org.jfree.chart.plot.Plot plot12 = piePlot3D1.getRootPlot();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor11);
        org.junit.Assert.assertNotNull(plot12);
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test40");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDepthFactor((double) (byte) 1);
        piePlot3D1.setDepthFactor(0.0d);
        java.awt.Stroke[] strokeArray6 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        boolean boolean7 = piePlot3D1.equals((java.lang.Object) strokeArray6);
        java.awt.Paint paint8 = piePlot3D1.getLabelShadowPaint();
        java.awt.Paint paint9 = piePlot3D1.getLabelBackgroundPaint();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = piePlot3D1.getLegendItems();
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer11 = new org.jfree.chart.renderer.category.GanttRenderer();
        double double12 = ganttRenderer11.getItemMargin();
        java.awt.Stroke stroke13 = ganttRenderer11.getBaseOutlineStroke();
        boolean boolean14 = legendItemCollection10.equals((java.lang.Object) ganttRenderer11);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = ganttRenderer11.getNegativeItemLabelPositionFallback();
        org.junit.Assert.assertNotNull(strokeArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.2d + "'", double12 == 0.2d);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(itemLabelPosition15);
    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test41");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean1 = statisticalLineAndShapeRenderer0.getDrawOutlines();
        statisticalLineAndShapeRenderer0.setBaseSeriesVisible(true, false);
        java.awt.Font font6 = null;
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) numberAxis9, polarItemRenderer10);
        float float12 = polarPlot11.getBackgroundAlpha();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer13 = polarPlot11.getRenderer();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font6, (org.jfree.chart.plot.Plot) polarPlot11, false);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent18 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) false, jFreeChart15, 6, 0);
        boolean boolean19 = jFreeChart15.isBorderVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 1.0f + "'", float12 == 1.0f);
        org.junit.Assert.assertNull(polarItemRenderer13);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test42");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset2, valueAxis3, polarItemRenderer4);
        defaultCategoryDataset0.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot5);
        java.awt.Image image7 = polarPlot5.getBackgroundImage();
        java.awt.Paint paint8 = polarPlot5.getBackgroundPaint();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = polarPlot5.getRenderer();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        polarPlot5.rendererChanged(rendererChangeEvent10);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNull(image7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(polarItemRenderer9);
    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test43");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = xYPlot1.getLegendItems();
        xYPlot0.setFixedLegendItems(legendItemCollection2);
        xYPlot0.setWeight((int) 'a');
        org.junit.Assert.assertNotNull(legendItemCollection2);
    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test44");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDepthFactor((double) (byte) 1);
        piePlot3D1.setDepthFactor(0.0d);
        java.awt.Stroke stroke6 = piePlot3D1.getLabelLinkStroke();
        double double7 = piePlot3D1.getShadowXOffset();
        java.lang.String str8 = piePlot3D1.getNoDataMessage();
        java.awt.Paint paint9 = piePlot3D1.getBaseSectionOutlinePaint();
        org.jfree.data.general.PieDataset pieDataset10 = null;
        piePlot3D1.setDataset(pieDataset10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.Range range14 = numberAxis13.getDefaultAutoRange();
        double double15 = range14.getCentralValue();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer16 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator17 = statisticalLineAndShapeRenderer16.getBaseItemLabelGenerator();
        statisticalLineAndShapeRenderer16.setBaseSeriesVisibleInLegend(false);
        java.lang.Boolean boolean21 = statisticalLineAndShapeRenderer16.getSeriesCreateEntities(255);
        java.awt.Paint paint22 = statisticalLineAndShapeRenderer16.getBasePaint();
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        int int25 = xYPlot23.indexOf(xYDataset24);
        xYPlot23.setRangeGridlinesVisible(false);
        java.awt.Paint paint28 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot23.setRangeTickBandPaint(paint28);
        statisticalLineAndShapeRenderer16.setBaseFillPaint(paint28, false);
        boolean boolean32 = range14.equals((java.lang.Object) paint28);
        piePlot3D1.setLabelShadowPaint(paint28);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer34 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator36 = null;
        statisticalLineAndShapeRenderer34.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator36, true);
        statisticalLineAndShapeRenderer34.setSeriesVisibleInLegend(0, (java.lang.Boolean) true, true);
        java.lang.Boolean boolean44 = statisticalLineAndShapeRenderer34.getSeriesVisibleInLegend(100);
        java.awt.Shape shape47 = statisticalLineAndShapeRenderer34.getItemShape((int) (short) 100, (int) (byte) -1);
        piePlot3D1.setLegendItemShape(shape47);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.5d + "'", double15 == 0.5d);
        org.junit.Assert.assertNull(categoryItemLabelGenerator17);
        org.junit.Assert.assertNull(boolean21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(boolean44);
        org.junit.Assert.assertNotNull(shape47);
    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test45");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDepthFactor((double) (byte) 1);
        piePlot3D1.setDepthFactor(0.0d);
        java.awt.Stroke stroke6 = piePlot3D1.getLabelLinkStroke();
        double double7 = piePlot3D1.getShadowXOffset();
        java.lang.String str8 = piePlot3D1.getNoDataMessage();
        java.awt.Paint paint9 = piePlot3D1.getBaseSectionOutlinePaint();
        org.jfree.data.general.PieDataset pieDataset10 = null;
        piePlot3D1.setDataset(pieDataset10);
        org.jfree.chart.plot.Plot plot12 = piePlot3D1.getParent();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset14 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range15 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset14);
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer18 = null;
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot(xYDataset16, valueAxis17, polarItemRenderer18);
        defaultCategoryDataset14.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot19);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo22 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo22);
        java.awt.geom.Point2D point2D24 = null;
        polarPlot19.zoomDomainAxes((double) '#', plotRenderingInfo23, point2D24);
        org.jfree.chart.block.BlockContainer blockContainer26 = new org.jfree.chart.block.BlockContainer();
        blockContainer26.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer32 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder37 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer32.setFrame((org.jfree.chart.block.BlockFrame) blockBorder37);
        blockContainer26.add((org.jfree.chart.block.Block) blockContainer32);
        java.awt.Graphics2D graphics2D40 = null;
        org.jfree.chart.util.Size2D size2D41 = blockContainer32.arrange(graphics2D40);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D45 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D41, (double) '#', (double) 1.0f, rectangleAnchor44);
        plotRenderingInfo23.setPlotArea(rectangle2D45);
        piePlot3D1.drawBackgroundImage(graphics2D13, rectangle2D45);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier48 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        piePlot3D1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier48);
        java.lang.Object obj50 = defaultDrawingSupplier48.clone();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(plot12);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNotNull(size2D41);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertNotNull(obj50);
    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test46");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset2, valueAxis3, polarItemRenderer4);
        defaultCategoryDataset0.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot5);
        int int7 = defaultCategoryDataset0.getColumnCount();
        org.jfree.data.general.PieDataset pieDataset9 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, (java.lang.Comparable) 0.35d);
        double double10 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset9);
        org.jfree.chart.plot.RingPlot ringPlot11 = new org.jfree.chart.plot.RingPlot(pieDataset9);
        ringPlot11.setSeparatorsVisible(false);
        boolean boolean14 = ringPlot11.getSeparatorsVisible();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(pieDataset9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test47");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDepthFactor((double) (byte) 1);
        piePlot3D1.setDepthFactor(0.0d);
        java.awt.Stroke stroke6 = piePlot3D1.getLabelLinkStroke();
        double double7 = piePlot3D1.getShadowXOffset();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        int int9 = color8.getTransparency();
        piePlot3D1.setLabelLinkPaint((java.awt.Paint) color8);
        piePlot3D1.zoom((double) (-62125372800001L));
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test48");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, polarItemRenderer3);
        org.jfree.data.general.DatasetGroup datasetGroup5 = polarPlot4.getDatasetGroup();
        java.awt.Paint paint6 = polarPlot4.getAngleGridlinePaint();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer7 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean8 = statisticalLineAndShapeRenderer7.getDrawOutlines();
        statisticalLineAndShapeRenderer7.setAutoPopulateSeriesFillPaint(false);
        java.awt.Stroke stroke12 = statisticalLineAndShapeRenderer7.lookupSeriesStroke(28);
        polarPlot4.setRadiusGridlineStroke(stroke12);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent14 = null;
        polarPlot4.notifyListeners(plotChangeEvent14);
        java.awt.Font font16 = polarPlot4.getAngleLabelFont();
        org.junit.Assert.assertNull(datasetGroup5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(font16);
    }

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test49");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer0.setDrawOutlines(true);
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer0.setBasePaint((java.awt.Paint) color3, false);
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset7, valueAxis8, polarItemRenderer9);
        java.lang.Object obj11 = null;
        boolean boolean12 = polarPlot10.equals(obj11);
        int int13 = polarPlot10.getSeriesCount();
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        polarPlot10.setAngleLabelPaint((java.awt.Paint) color14);
        statisticalLineAndShapeRenderer0.setSeriesFillPaint(2, (java.awt.Paint) color14);
        java.awt.Paint paint17 = statisticalLineAndShapeRenderer0.getBaseFillPaint();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D19 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        boolean boolean21 = categoryAxis3D19.equals((java.lang.Object) textAnchor20);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        org.jfree.data.gantt.Task task24 = new org.jfree.data.gantt.Task("", (org.jfree.data.time.TimePeriod) year23);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(4, 0);
        int int28 = month27.getMonth();
        int int29 = month27.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month27.next();
        task24.setDuration((org.jfree.data.time.TimePeriod) month27);
        java.awt.Font font32 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        categoryAxis3D19.setTickLabelFont((java.lang.Comparable) month27, font32);
        statisticalLineAndShapeRenderer0.setSeriesItemLabelFont((int) (short) 10, font32, false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 4 + "'", int28 == 4);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(font32);
    }

    @Test
    public void test50() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test50");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean1 = statisticalLineAndShapeRenderer0.getDrawOutlines();
        statisticalLineAndShapeRenderer0.setBaseSeriesVisible(true, false);
        java.lang.Boolean boolean6 = statisticalLineAndShapeRenderer0.getSeriesCreateEntities((int) (short) -1);
        java.util.TimeZone timeZone9 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("SortOrder.DESCENDING", timeZone9);
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer12 = new org.jfree.chart.renderer.category.StackedBarRenderer();
        org.jfree.chart.block.BlockContainer blockContainer13 = new org.jfree.chart.block.BlockContainer();
        blockContainer13.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer19 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder24 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer19.setFrame((org.jfree.chart.block.BlockFrame) blockBorder24);
        blockContainer13.add((org.jfree.chart.block.Block) blockContainer19);
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.util.Size2D size2D28 = blockContainer19.arrange(graphics2D27);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor31 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D32 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D28, (double) '#', (double) 1.0f, rectangleAnchor31);
        boolean boolean33 = stackedBarRenderer12.equals((java.lang.Object) rectangle2D32);
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis36.setInverted(true);
        boolean boolean39 = numberAxis36.isAxisLineVisible();
        boolean boolean40 = numberAxis36.getAutoRangeStickyZero();
        java.awt.Stroke stroke41 = numberAxis36.getAxisLineStroke();
        categoryPlot34.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis36);
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = categoryPlot34.getDomainAxisEdge();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer44 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean45 = rectangleEdge43.equals((java.lang.Object) statisticalBarRenderer44);
        double double46 = dateAxis10.valueToJava2D((double) (-2208960000000L), rectangle2D32, rectangleEdge43);
        try {
            statisticalLineAndShapeRenderer0.setSeriesShape((-16744320), (java.awt.Shape) rectangle2D32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(size2D28);
        org.junit.Assert.assertNotNull(rectangleAnchor31);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(rectangleEdge43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 35.0d + "'", double46 == 35.0d);
    }

    @Test
    public void test51() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test51");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long1 = segmentedTimeline0.getStartTime();
        int int2 = segmentedTimeline0.getSegmentsIncluded();
        long long5 = segmentedTimeline0.getExceptionSegmentCount(0L, (-1L));
        long long6 = segmentedTimeline0.getSegmentsGroupSize();
        int int7 = segmentedTimeline0.getSegmentsIncluded();
        org.jfree.chart.ui.ProjectInfo projectInfo8 = org.jfree.chart.JFreeChart.INFO;
        boolean boolean9 = segmentedTimeline0.equals((java.lang.Object) projectInfo8);
        int int10 = segmentedTimeline0.getGroupSegmentCount();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline11 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long12 = segmentedTimeline11.getStartTime();
        int int13 = segmentedTimeline11.getSegmentsIncluded();
        long long16 = segmentedTimeline11.getExceptionSegmentCount(0L, (-1L));
        long long17 = segmentedTimeline11.getSegmentsGroupSize();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(4, 0);
        java.util.Date date21 = month20.getEnd();
        long long22 = segmentedTimeline11.getTime(date21);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date21);
        long long24 = segmentedTimeline0.toTimelineValue(date21);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-2208927600000L) + "'", long1 == (-2208927600000L));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28 + "'", int2 == 28);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 86400000L + "'", long6 == 86400000L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 28 + "'", int7 == 28);
        org.junit.Assert.assertNotNull(projectInfo8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 96 + "'", int10 == 96);
        org.junit.Assert.assertNotNull(segmentedTimeline11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-2208927600000L) + "'", long12 == (-2208927600000L));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 28 + "'", int13 == 28);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 86400000L + "'", long17 == 86400000L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-62125372800001L) + "'", long22 == (-62125372800001L));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-17475652800001L) + "'", long24 == (-17475652800001L));
    }

    @Test
    public void test52() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test52");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis2.setInverted(true);
        boolean boolean5 = numberAxis2.isAxisLineVisible();
        boolean boolean6 = numberAxis2.getAutoRangeStickyZero();
        java.awt.Stroke stroke7 = numberAxis2.getAxisLineStroke();
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis2);
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot0.getRangeAxisLocation(0);
        categoryPlot0.setAnchorValue((double) 1L);
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot0.getRangeAxis((int) (short) -1);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor15 = categoryPlot0.getDomainGridlinePosition();
        java.lang.String str16 = categoryAnchor15.toString();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertNotNull(categoryAnchor15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "CategoryAnchor.MIDDLE" + "'", str16.equals("CategoryAnchor.MIDDLE"));
    }

    @Test
    public void test53() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test53");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font3 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer4 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer4.setDrawOutlines(true);
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer4.setBasePaint((java.awt.Paint) color7, false);
        org.jfree.chart.text.TextMeasurer textMeasurer11 = null;
        org.jfree.chart.text.TextBlock textBlock12 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, (java.awt.Paint) color7, (float) (byte) -1, textMeasurer11);
        numberAxis1.setTickMarkPaint((java.awt.Paint) color7);
        numberAxis1.configure();
        numberAxis1.setFixedAutoRange((double) (-1L));
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_RED;
        numberAxis1.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.axis.TickUnitSource tickUnitSource19 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        numberAxis1.setStandardTickUnits(tickUnitSource19);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(textBlock12);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(tickUnitSource19);
    }

    @Test
    public void test54() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test54");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.setBottom(0.0d);
    }

    @Test
    public void test55() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test55");
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("SortOrder.DESCENDING", timeZone1);
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = dateAxis2.getTickUnit();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long6 = segmentedTimeline5.getStartTime();
        int int7 = segmentedTimeline5.getSegmentsIncluded();
        long long10 = segmentedTimeline5.getExceptionSegmentCount(0L, (-1L));
        long long11 = segmentedTimeline5.getSegmentsGroupSize();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(4, 0);
        java.util.Date date15 = month14.getEnd();
        long long16 = segmentedTimeline5.getTime(date15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date15);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(4, 0);
        java.util.Date date21 = month20.getEnd();
        org.jfree.data.gantt.Task task22 = new org.jfree.data.gantt.Task("", date15, date21);
        java.util.Date date23 = dateTickUnit3.addToDate(date15);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date23);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(segmentedTimeline5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-2208927600000L) + "'", long6 == (-2208927600000L));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 28 + "'", int7 == 28);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 86400000L + "'", long11 == 86400000L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-62125372800001L) + "'", long16 == (-62125372800001L));
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(date23);
    }

    @Test
    public void test56() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test56");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        boolean boolean2 = categoryAxis3D0.equals((java.lang.Object) textAnchor1);
        categoryAxis3D0.setMaximumCategoryLabelWidthRatio((float) 60000L);
        categoryAxis3D0.setFixedDimension(0.2d);
        int int7 = categoryAxis3D0.getMaximumCategoryLabelLines();
        java.awt.Font font9 = categoryAxis3D0.getTickLabelFont((java.lang.Comparable) 1.05d);
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test57() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test57");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.TableOrder tableOrder1 = multiplePiePlot0.getDataExtractOrder();
        org.junit.Assert.assertNotNull(tableOrder1);
    }

    @Test
    public void test58() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test58");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D2 = new org.jfree.chart.plot.PiePlot3D(pieDataset1);
        piePlot3D2.setDepthFactor((double) (byte) 1);
        java.awt.Color color5 = java.awt.Color.GRAY;
        piePlot3D2.setLabelLinkPaint((java.awt.Paint) color5);
        boolean boolean7 = strokeList0.equals((java.lang.Object) color5);
        strokeList0.clear();
        strokeList0.clear();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test59() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test59");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = xYPlot0.getFixedLegendItems();
        java.awt.Stroke stroke3 = xYPlot0.getRangeGridlineStroke();
        org.junit.Assert.assertNull(legendItemCollection2);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test60() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test60");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(1.0d, (double) (short) -1);
        boolean boolean4 = stackedBarRenderer3D3.isDrawBarOutline();
        double double5 = stackedBarRenderer3D3.getYOffset();
        stackedBarRenderer3D3.setItemLabelAnchorOffset((double) (byte) 0);
        java.awt.Paint paint8 = stackedBarRenderer3D3.getWallPaint();
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D10 = new org.jfree.chart.plot.PiePlot3D(pieDataset9);
        piePlot3D10.setDepthFactor((double) (byte) 1);
        piePlot3D10.setDepthFactor(0.0d);
        java.awt.Stroke stroke15 = piePlot3D10.getLabelLinkStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10.0d, paint8, stroke15);
        java.awt.Paint paint17 = categoryMarker16.getPaint();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test61() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test61");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(1.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = stackedBarRenderer3D2.getGradientPaintTransformer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = stackedBarRenderer3D2.getBaseItemLabelGenerator();
        stackedBarRenderer3D2.setBaseSeriesVisible(false);
        java.awt.Paint paint9 = stackedBarRenderer3D2.getItemLabelPaint(0, 1);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState11 = null;
        org.jfree.chart.block.BlockContainer blockContainer12 = new org.jfree.chart.block.BlockContainer();
        blockContainer12.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer18 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder23 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer18.setFrame((org.jfree.chart.block.BlockFrame) blockBorder23);
        blockContainer12.add((org.jfree.chart.block.Block) blockContainer18);
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.util.Size2D size2D27 = blockContainer18.arrange(graphics2D26);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor30 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D31 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D27, (double) '#', (double) 1.0f, rectangleAnchor30);
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis34.setInverted(true);
        boolean boolean37 = numberAxis34.isAxisLineVisible();
        boolean boolean38 = numberAxis34.getAutoRangeStickyZero();
        java.awt.Stroke stroke39 = numberAxis34.getAxisLineStroke();
        categoryPlot32.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis34);
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = categoryPlot32.getDomainAxisEdge();
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        int int44 = xYPlot42.indexOf(xYDataset43);
        org.jfree.chart.util.Layer layer46 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection47 = xYPlot42.getRangeMarkers(6, layer46);
        java.util.Collection collection48 = categoryPlot32.getDomainMarkers(layer46);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer49 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator50 = statisticalLineAndShapeRenderer49.getBaseItemLabelGenerator();
        statisticalLineAndShapeRenderer49.setBaseSeriesVisibleInLegend(false);
        java.lang.Boolean boolean54 = statisticalLineAndShapeRenderer49.getSeriesCreateEntities(255);
        java.awt.Paint paint55 = statisticalLineAndShapeRenderer49.getBasePaint();
        org.jfree.chart.plot.XYPlot xYPlot56 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset57 = null;
        int int58 = xYPlot56.indexOf(xYDataset57);
        xYPlot56.setRangeGridlinesVisible(false);
        java.awt.Paint paint61 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot56.setRangeTickBandPaint(paint61);
        statisticalLineAndShapeRenderer49.setBaseFillPaint(paint61, false);
        categoryPlot32.setBackgroundPaint(paint61);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D66 = new org.jfree.chart.axis.CategoryAxis3D();
        double double67 = categoryAxis3D66.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis69 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font71 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer72 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer72.setDrawOutlines(true);
        java.awt.Color color75 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer72.setBasePaint((java.awt.Paint) color75, false);
        org.jfree.chart.text.TextMeasurer textMeasurer79 = null;
        org.jfree.chart.text.TextBlock textBlock80 = org.jfree.chart.text.TextUtilities.createTextBlock("", font71, (java.awt.Paint) color75, (float) (byte) -1, textMeasurer79);
        numberAxis69.setTickMarkPaint((java.awt.Paint) color75);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit83 = new org.jfree.chart.axis.NumberTickUnit(0.0d);
        numberAxis69.setTickUnit(numberTickUnit83);
        java.awt.Paint paint85 = numberAxis69.getTickMarkPaint();
        numberAxis69.setAutoRange(false);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset88 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.lang.Number number91 = defaultBoxAndWhiskerCategoryDataset88.getQ3Value((java.lang.Comparable) (byte) 1, (java.lang.Comparable) 100.0f);
        java.util.List list92 = defaultBoxAndWhiskerCategoryDataset88.getColumnKeys();
        try {
            stackedBarRenderer3D2.drawItem(graphics2D10, categoryItemRendererState11, rectangle2D31, categoryPlot32, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D66, (org.jfree.chart.axis.ValueAxis) numberAxis69, (org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset88, (int) (byte) 10, (int) (short) 100, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gradientPaintTransformer3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(size2D27);
        org.junit.Assert.assertNotNull(rectangleAnchor30);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(layer46);
        org.junit.Assert.assertNull(collection47);
        org.junit.Assert.assertNull(collection48);
        org.junit.Assert.assertNull(categoryItemLabelGenerator50);
        org.junit.Assert.assertNull(boolean54);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNotNull(paint61);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.05d + "'", double67 == 0.05d);
        org.junit.Assert.assertNotNull(color75);
        org.junit.Assert.assertNotNull(textBlock80);
        org.junit.Assert.assertNotNull(paint85);
        org.junit.Assert.assertNull(number91);
        org.junit.Assert.assertNotNull(list92);
    }

    @Test
    public void test62() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test62");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        int int2 = xYPlot0.indexOf(xYDataset1);
        boolean boolean3 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = xYPlot0.getRangeAxisEdge();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset9 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset9);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer13 = null;
        org.jfree.chart.plot.PolarPlot polarPlot14 = new org.jfree.chart.plot.PolarPlot(xYDataset11, valueAxis12, polarItemRenderer13);
        defaultCategoryDataset9.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot14);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo17);
        java.awt.geom.Point2D point2D19 = null;
        polarPlot14.zoomDomainAxes((double) '#', plotRenderingInfo18, point2D19);
        org.jfree.chart.block.BlockContainer blockContainer21 = new org.jfree.chart.block.BlockContainer();
        blockContainer21.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer27 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder32 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer27.setFrame((org.jfree.chart.block.BlockFrame) blockBorder32);
        blockContainer21.add((org.jfree.chart.block.Block) blockContainer27);
        java.awt.Graphics2D graphics2D35 = null;
        org.jfree.chart.util.Size2D size2D36 = blockContainer27.arrange(graphics2D35);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor39 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D40 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D36, (double) '#', (double) 1.0f, rectangleAnchor39);
        plotRenderingInfo18.setPlotArea(rectangle2D40);
        categoryPlot6.handleClick(0, 0, plotRenderingInfo18);
        java.awt.geom.Point2D point2D43 = null;
        xYPlot0.zoomDomainAxes((double) (byte) 1, plotRenderingInfo18, point2D43);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNotNull(size2D36);
        org.junit.Assert.assertNotNull(rectangleAnchor39);
        org.junit.Assert.assertNotNull(rectangle2D40);
    }
}

