import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.awt.Shape shape0 = null;
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape0, (double) (byte) -1, 0.0f, (float) '#');
        org.junit.Assert.assertNull(shape4);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.awt.Graphics2D graphics2D0 = null;
        java.awt.Shape shape1 = null;
        try {
            org.jfree.chart.util.ShapeUtilities.drawRotatedShape(graphics2D0, shape1, (double) '#', (float) 1, (float) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int int0 = org.jfree.data.time.SerialDate.FIRST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = org.jfree.chart.text.TextUtilities.drawAlignedString("", graphics2D1, (-1.0f), (float) (byte) 100, textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("", "", "hi!", "");
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.chart.util.UnitType unitType0 = null;
        try {
            org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 100, (double) (byte) 0, (double) 100.0f, (double) 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unitType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        java.util.TimeZone timeZone0 = null;
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone0;
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeStroke(stroke0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            java.awt.Point point7 = polarPlot3.translateValueThetaRadiusToJava2D(10.0d, (double) 100, rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((double) (short) 10);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, (-1.0f), (float) (short) 10, (double) 0L, (float) (short) 1, (float) (byte) 10);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean1 = statisticalLineAndShapeRenderer0.getDrawOutlines();
        statisticalLineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(false);
        java.lang.Object obj4 = statisticalLineAndShapeRenderer0.clone();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo9);
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState11 = statisticalLineAndShapeRenderer0.initialise(graphics2D5, rectangle2D6, categoryPlot7, (int) (byte) 0, plotRenderingInfo10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        polarPlot3.removeCornerTextItem("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = null;
        try {
            polarPlot3.setInsets(rectangleInsets6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        polarPlot3.removeCornerTextItem("hi!");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo7);
        java.awt.geom.Point2D point2D9 = null;
        try {
            polarPlot3.zoomRangeAxes((double) 10L, plotRenderingInfo8, point2D9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        int int0 = org.jfree.data.time.SerialDate.SECOND_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        java.awt.Color color0 = java.awt.Color.yellow;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_SECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        java.awt.Shape shape0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        java.lang.Comparable comparable5 = null;
        try {
            org.jfree.chart.entity.CategoryItemEntity categoryItemEntity6 = new org.jfree.chart.entity.CategoryItemEntity(shape0, "", "", categoryDataset3, (java.lang.Comparable) (-1), comparable5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        double double0 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_X_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 12.0d + "'", double0 == 12.0d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        java.awt.geom.Arc2D arc2D0 = null;
        java.awt.geom.Arc2D arc2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(arc2D0, arc2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset2, valueAxis3, polarItemRenderer4);
        defaultCategoryDataset0.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        polarPlot5.setRadiusGridlineStroke(stroke7);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, polarItemRenderer3);
        java.awt.Font font5 = null;
        try {
            numberAxis2.setLabelFont(font5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("hi!", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        try {
            double double2 = piePlot3D1.getMaximumExplodePercent();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.chart.plot.Marker marker0 = null;
        try {
            org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = new org.jfree.chart.event.MarkerChangeEvent(marker0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer4 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean5 = statisticalLineAndShapeRenderer4.getDrawOutlines();
        statisticalLineAndShapeRenderer4.setAutoPopulateSeriesFillPaint(false);
        java.lang.Object obj8 = statisticalLineAndShapeRenderer4.clone();
        java.awt.Stroke stroke9 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        statisticalLineAndShapeRenderer4.setBaseStroke(stroke9);
        try {
            org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color1, stroke2, (java.awt.Paint) color3, stroke9, (float) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(1.0d, (double) (short) -1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset9 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset9);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset9);
        try {
            stackedBarRenderer3D2.drawItem(graphics2D3, categoryItemRendererState4, rectangle2D5, categoryPlot6, categoryAxis7, valueAxis8, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset9, 0, (int) (byte) 10, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNull(range11);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("hi!", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        polarPlot3.removeCornerTextItem("hi!");
        try {
            polarPlot3.setBackgroundImageAlpha((float) 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = null;
        java.awt.Paint paint5 = null;
        try {
            org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem(attributedString0, "hi!", "hi!", "", shape4, paint5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean1 = statisticalLineAndShapeRenderer0.getDrawOutlines();
        statisticalLineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(false);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            statisticalLineAndShapeRenderer0.drawOutline(graphics2D4, categoryPlot5, rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        java.lang.String str0 = org.jfree.chart.labels.StandardCategorySeriesLabelGenerator.DEFAULT_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 100, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((double) '4');
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator2 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("{0}", numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        java.lang.Comparable[] comparableArray1 = new java.lang.Comparable[] { (-1) };
        java.lang.Comparable[] comparableArray7 = new java.lang.Comparable[] { true, 12.0d, 100.0f, (short) 0, 1.0d };
        java.lang.Number[][] numberArray8 = new java.lang.Number[][] {};
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 4.0d, (byte) 0, 3, 0, 100L };
        java.lang.Number[] numberArray20 = new java.lang.Number[] { 4.0d, (byte) 0, 3, 0, 100L };
        java.lang.Number[][] numberArray21 = new java.lang.Number[][] { numberArray14, numberArray20 };
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset22 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray1, comparableArray7, numberArray8, numberArray21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset: the number of series in the start value dataset does not match the number of series in the end value dataset.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray1);
        org.junit.Assert.assertNotNull(comparableArray7);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray21);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.MINUTE_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 60000L + "'", long0 == 60000L);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        java.text.DateFormat dateFormat2 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit((int) (short) 100, (int) (short) -1, dateFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DateTickUnit.getMillisecondCount() : unit must be one of the constants YEAR, MONTH, DAY, HOUR, MINUTE, SECOND or MILLISECOND defined in the DateTickUnit class. Do *not* use the constants defined in java.util.Calendar.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setInverted(true);
        boolean boolean4 = numberAxis1.isAxisLineVisible();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) numberAxis8, polarItemRenderer9);
        float float11 = polarPlot10.getBackgroundAlpha();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer12 = polarPlot10.getRenderer();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.util.RectangleEdge.TOP;
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace16 = numberAxis1.reserveSpace(graphics2D5, (org.jfree.chart.plot.Plot) polarPlot10, rectangle2D13, rectangleEdge14, axisSpace15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 1.0f + "'", float11 == 1.0f);
        org.junit.Assert.assertNull(polarItemRenderer12);
        org.junit.Assert.assertNotNull(rectangleEdge14);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        int int0 = org.jfree.data.time.SerialDate.MONDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.FULL;
        org.junit.Assert.assertNotNull(rangeType0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean1 = statisticalLineAndShapeRenderer0.getDrawOutlines();
        java.lang.Object obj2 = statisticalLineAndShapeRenderer0.clone();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        int int0 = org.jfree.chart.axis.DateTickUnit.DAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDepthFactor((double) (byte) 1);
        piePlot3D1.setDepthFactor(0.0d);
        java.awt.Stroke[] strokeArray6 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        boolean boolean7 = piePlot3D1.equals((java.lang.Object) strokeArray6);
        try {
            double double8 = piePlot3D1.getMaximumExplodePercent();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strokeArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font3 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer4 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer4.setDrawOutlines(true);
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer4.setBasePaint((java.awt.Paint) color7, false);
        org.jfree.chart.text.TextMeasurer textMeasurer11 = null;
        org.jfree.chart.text.TextBlock textBlock12 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, (java.awt.Paint) color7, (float) (byte) -1, textMeasurer11);
        numberAxis1.setTickMarkPaint((java.awt.Paint) color7);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit14 = null;
        try {
            numberAxis1.setTickUnit(numberTickUnit14, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(textBlock12);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(15, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DateTickUnit.getMillisecondCount() : unit must be one of the constants YEAR, MONTH, DAY, HOUR, MINUTE, SECOND or MILLISECOND defined in the DateTickUnit class. Do *not* use the constants defined in java.util.Calendar.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        java.lang.String str0 = org.jfree.chart.labels.IntervalCategoryToolTipGenerator.DEFAULT_TOOL_TIP_FORMAT_STRING;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "({0}, {1}) = {3} - {4}" + "'", str0.equals("({0}, {1}) = {3} - {4}"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.Range range2 = numberAxis1.getDefaultAutoRange();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.util.RectangleEdge.TOP;
        try {
            double double6 = numberAxis1.java2DToValue((double) (byte) 1, rectangle2D4, rectangleEdge5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(rectangleEdge5);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Stroke stroke1 = org.jfree.chart.util.SerialUtilities.readStroke(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDepthFactor((double) (byte) 1);
        piePlot3D1.setDepthFactor(0.0d);
        java.awt.Stroke stroke6 = piePlot3D1.getLabelLinkStroke();
        double double7 = piePlot3D1.getShadowXOffset();
        java.lang.String str8 = piePlot3D1.getNoDataMessage();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator9 = piePlot3D1.getToolTipGenerator();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNull(pieToolTipGenerator9);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.chart.text.TextBlock textBlock1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = null;
        org.jfree.chart.text.TextAnchor textAnchor3 = null;
        try {
            org.jfree.chart.axis.CategoryTick categoryTick5 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) (-2208927599903L), textBlock1, textBlockAnchor2, textAnchor3, (double) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rotationAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        int int0 = org.jfree.chart.axis.DateTickUnit.MILLISECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(15, (int) '4', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.lang.String str1 = lengthAdjustmentType0.toString();
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "EXPAND" + "'", str1.equals("EXPAND"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit0 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        org.junit.Assert.assertNotNull(numberTickUnit0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("");
        boolean boolean3 = taskSeries1.equals((java.lang.Object) 1L);
        org.jfree.data.gantt.Task task4 = null;
        taskSeries1.remove(task4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        taskSeries1.removePropertyChangeListener(propertyChangeListener6);
        try {
            org.jfree.data.gantt.Task task9 = taskSeries1.get((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(1.0d, (double) (short) -1);
        double double3 = stackedBarRenderer3D2.getMaximumBarWidth();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_UPPER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2958465 + "'", int0 == 2958465);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            boolean boolean2 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D0, rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.START;
        org.junit.Assert.assertNotNull(categoryAnchor0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        java.awt.Color color0 = java.awt.Color.orange;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = statisticalLineAndShapeRenderer0.getBaseItemLabelGenerator();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            statisticalLineAndShapeRenderer0.drawDomainMarker(graphics2D2, categoryPlot3, categoryAxis4, categoryMarker5, rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryItemLabelGenerator1);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        java.awt.geom.GeneralPath generalPath0 = null;
        java.awt.geom.GeneralPath generalPath1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(generalPath0, generalPath1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        double[] doubleArray6 = new double[] { 3, (-1.0f), 4.0d, 10.0f, 15, '4' };
        double[] doubleArray13 = new double[] { 3, (-1.0f), 4.0d, 10.0f, 15, '4' };
        double[] doubleArray20 = new double[] { 3, (-1.0f), 4.0d, 10.0f, 15, '4' };
        double[] doubleArray27 = new double[] { 3, (-1.0f), 4.0d, 10.0f, 15, '4' };
        double[][] doubleArray28 = new double[][] { doubleArray6, doubleArray13, doubleArray20, doubleArray27 };
        double[][] doubleArray29 = null;
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset30 = new org.jfree.data.category.DefaultIntervalCategoryDataset(doubleArray28, doubleArray29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'data' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDepthFactor((double) (byte) 1);
        piePlot3D1.setDepthFactor(0.0d);
        java.awt.Stroke stroke6 = piePlot3D1.getLabelLinkStroke();
        java.awt.Stroke stroke8 = null;
        piePlot3D1.setSectionOutlineStroke((java.lang.Comparable) "EXPAND", stroke8);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean1 = statisticalLineAndShapeRenderer0.getDrawOutlines();
        statisticalLineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(false);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment4, verticalAlignment5, (double) 100L, 10.0d);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement13 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment9, verticalAlignment10, (double) 100L, 10.0d);
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalLineAndShapeRenderer0, (org.jfree.chart.block.Arrangement) columnArrangement8, (org.jfree.chart.block.Arrangement) columnArrangement13);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset17 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range18 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset17);
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer21 = null;
        org.jfree.chart.plot.PolarPlot polarPlot22 = new org.jfree.chart.plot.PolarPlot(xYDataset19, valueAxis20, polarItemRenderer21);
        defaultCategoryDataset17.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot22);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo25 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo25);
        java.awt.geom.Point2D point2D27 = null;
        polarPlot22.zoomDomainAxes((double) '#', plotRenderingInfo26, point2D27);
        try {
            java.lang.Object obj29 = legendTitle14.draw(graphics2D15, rectangle2D16, (java.lang.Object) plotRenderingInfo26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(range18);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("RectangleConstraintType.RANGE", graphics2D1, (double) 3, (float) 6, (float) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape5 = null;
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset7, valueAxis8, polarItemRenderer9);
        polarPlot10.removeCornerTextItem("hi!");
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_RED;
        polarPlot10.setNoDataMessagePaint((java.awt.Paint) color13);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(1.0d, (double) (short) -1);
        boolean boolean19 = stackedBarRenderer3D18.isDrawBarOutline();
        java.awt.Paint paint20 = stackedBarRenderer3D18.getWallPaint();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer21 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean22 = statisticalLineAndShapeRenderer21.getDrawOutlines();
        statisticalLineAndShapeRenderer21.setAutoPopulateSeriesFillPaint(false);
        java.awt.Stroke stroke26 = statisticalLineAndShapeRenderer21.lookupSeriesStroke(28);
        java.awt.Shape shape28 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Stroke stroke29 = null;
        org.jfree.data.general.PieDataset pieDataset30 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D31 = new org.jfree.chart.plot.PiePlot3D(pieDataset30);
        piePlot3D31.setDepthFactor((double) (byte) 1);
        piePlot3D31.setDepthFactor(0.0d);
        java.awt.Stroke stroke36 = piePlot3D31.getLabelLinkStroke();
        double double37 = piePlot3D31.getShadowXOffset();
        java.lang.String str38 = piePlot3D31.getNoDataMessage();
        java.awt.Shape shape39 = piePlot3D31.getLegendItemShape();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer40 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer40.setDrawOutlines(true);
        java.awt.Color color43 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer40.setBasePaint((java.awt.Paint) color43, false);
        org.jfree.data.xy.XYDataset xYDataset47 = null;
        org.jfree.chart.axis.ValueAxis valueAxis48 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer49 = null;
        org.jfree.chart.plot.PolarPlot polarPlot50 = new org.jfree.chart.plot.PolarPlot(xYDataset47, valueAxis48, polarItemRenderer49);
        java.lang.Object obj51 = null;
        boolean boolean52 = polarPlot50.equals(obj51);
        int int53 = polarPlot50.getSeriesCount();
        java.awt.Color color54 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        polarPlot50.setAngleLabelPaint((java.awt.Paint) color54);
        statisticalLineAndShapeRenderer40.setSeriesFillPaint(2, (java.awt.Paint) color54);
        piePlot3D31.setLabelPaint((java.awt.Paint) color54);
        try {
            org.jfree.chart.LegendItem legendItem58 = new org.jfree.chart.LegendItem(attributedString0, "", "", "", false, shape5, false, (java.awt.Paint) color13, false, paint20, stroke26, false, shape28, stroke29, (java.awt.Paint) color54);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 4.0d + "'", double37 == 4.0d);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNotNull(color54);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset2, valueAxis3, polarItemRenderer4);
        defaultCategoryDataset0.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot5);
        java.awt.Image image7 = polarPlot5.getBackgroundImage();
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        polarPlot5.setDataset(xYDataset8);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNull(image7);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = null;
        try {
            textTitle0.setMargin(rectangleInsets1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'margin' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        java.text.DateFormat dateFormat1 = null;
        try {
            org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator2 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("hi!", dateFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.data.resources.DataPackageResources dataPackageResources0 = new org.jfree.data.resources.DataPackageResources();
        java.util.Set<java.lang.String> strSet1 = dataPackageResources0.keySet();
        try {
            java.util.Collection collection2 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) strSet1);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(strSet1);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((double) (byte) 100);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions1, categoryLabelPosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'left' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        try {
            java.awt.Color color1 = java.awt.Color.decode("({0}, {1}) = {3} - {4}");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"({0}, {1}) = {3} - {4}\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer0.setSeriesShapesVisible((int) '4', false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        java.lang.String str0 = org.jfree.chart.ui.Licences.LGPL;
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        java.lang.Comparable comparable0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3, polarItemRenderer4);
        org.jfree.data.general.DatasetGroup datasetGroup6 = polarPlot5.getDatasetGroup();
        java.awt.Paint paint7 = polarPlot5.getAngleGridlinePaint();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer9 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean10 = statisticalLineAndShapeRenderer9.getDrawOutlines();
        statisticalLineAndShapeRenderer9.setAutoPopulateSeriesFillPaint(false);
        java.awt.Stroke stroke14 = statisticalLineAndShapeRenderer9.lookupSeriesStroke(28);
        lineAndShapeRenderer8.setBaseStroke(stroke14);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer16 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer16.setDrawOutlines(true);
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer16.setBasePaint((java.awt.Paint) color19, false);
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer25 = null;
        org.jfree.chart.plot.PolarPlot polarPlot26 = new org.jfree.chart.plot.PolarPlot(xYDataset23, valueAxis24, polarItemRenderer25);
        java.lang.Object obj27 = null;
        boolean boolean28 = polarPlot26.equals(obj27);
        int int29 = polarPlot26.getSeriesCount();
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        polarPlot26.setAngleLabelPaint((java.awt.Paint) color30);
        statisticalLineAndShapeRenderer16.setSeriesFillPaint(2, (java.awt.Paint) color30);
        java.awt.Stroke stroke33 = null;
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker35 = new org.jfree.chart.plot.CategoryMarker(comparable0, paint7, stroke14, (java.awt.Paint) color30, stroke33, (float) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(datasetGroup6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(color30);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        boolean boolean1 = textTitle0.getExpandToFitSpace();
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = null;
        try {
            textTitle0.setVerticalAlignment(verticalAlignment2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'alignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.event.TitleChangeListener titleChangeListener1 = null;
        textTitle0.removeChangeListener(titleChangeListener1);
        java.awt.Paint paint3 = null;
        try {
            textTitle0.setPaint(paint3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long1 = segmentedTimeline0.getStartTime();
        int int2 = segmentedTimeline0.getSegmentsIncluded();
        long long5 = segmentedTimeline0.getExceptionSegmentCount(0L, (-1L));
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline6 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long8 = segmentedTimeline6.toMillisecond((long) 'a');
        segmentedTimeline0.setBaseTimeline(segmentedTimeline6);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-2208927600000L) + "'", long1 == (-2208927600000L));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28 + "'", int2 == 28);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(segmentedTimeline6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-2208927599903L) + "'", long8 == (-2208927599903L));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset2, valueAxis3, polarItemRenderer4);
        defaultCategoryDataset0.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot5);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo8);
        java.awt.geom.Point2D point2D10 = null;
        polarPlot5.zoomDomainAxes((double) '#', plotRenderingInfo9, point2D10);
        polarPlot5.removeCornerTextItem("RectangleConstraintType.RANGE");
        org.jfree.chart.axis.ValueAxis valueAxis14 = polarPlot5.getAxis();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNull(valueAxis14);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.image.ColorModel colorModel1 = null;
        java.awt.Rectangle rectangle2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.AffineTransform affineTransform4 = null;
        java.awt.RenderingHints renderingHints5 = null;
        java.awt.PaintContext paintContext6 = color0.createContext(colorModel1, rectangle2, rectangle2D3, affineTransform4, renderingHints5);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paintContext6);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean1 = statisticalLineAndShapeRenderer0.getDrawOutlines();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = null;
        statisticalLineAndShapeRenderer0.setSeriesNegativeItemLabelPosition((int) ' ', itemLabelPosition3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            statisticalLineAndShapeRenderer0.drawBackground(graphics2D5, categoryPlot6, rectangle2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) (-1), 0.0d);
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer();
        blockContainer5.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.data.Range range13 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean15 = range13.contains((double) 2);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint(0.0d, range13);
        try {
            org.jfree.chart.util.Size2D size2D17 = columnArrangement4.arrange(blockContainer5, graphics2D11, rectangleConstraint16);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType1 = org.jfree.chart.block.LengthConstraintType.RANGE;
        java.lang.String str2 = lengthConstraintType1.toString();
        boolean boolean3 = rectangleAnchor0.equals((java.lang.Object) str2);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(lengthConstraintType1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RectangleConstraintType.RANGE" + "'", str2.equals("RectangleConstraintType.RANGE"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(true);
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 10.0d, 100.0f, 28, (byte) 100 };
        java.lang.Number[][] numberArray7 = new java.lang.Number[][] { numberArray6 };
        java.lang.Number[] numberArray12 = new java.lang.Number[] { 0.2d, (short) 1, (byte) -1, (byte) 1 };
        java.lang.Number[][] numberArray13 = new java.lang.Number[][] { numberArray12 };
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset14 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray1, numberArray7, numberArray13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of series keys does not match the number of series in the data.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray13);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        int int0 = org.jfree.chart.axis.DateTickUnit.YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean1 = statisticalLineAndShapeRenderer0.getDrawOutlines();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = null;
        statisticalLineAndShapeRenderer0.setSeriesNegativeItemLabelPosition((int) ' ', itemLabelPosition3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font10 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer11 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer11.setDrawOutlines(true);
        java.awt.Color color14 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer11.setBasePaint((java.awt.Paint) color14, false);
        org.jfree.chart.text.TextMeasurer textMeasurer18 = null;
        org.jfree.chart.text.TextBlock textBlock19 = org.jfree.chart.text.TextUtilities.createTextBlock("", font10, (java.awt.Paint) color14, (float) (byte) -1, textMeasurer18);
        numberAxis8.setTickMarkPaint((java.awt.Paint) color14);
        numberAxis8.configure();
        org.jfree.chart.plot.Marker marker22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        statisticalLineAndShapeRenderer0.drawRangeMarker(graphics2D5, categoryPlot6, (org.jfree.chart.axis.ValueAxis) numberAxis8, marker22, rectangle2D23);
        statisticalLineAndShapeRenderer0.setSeriesVisible(3, (java.lang.Boolean) false, false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(textBlock19);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = statisticalLineAndShapeRenderer0.getBaseItemLabelGenerator();
        statisticalLineAndShapeRenderer0.setSeriesItemLabelsVisible((int) '#', (java.lang.Boolean) true, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = null;
        statisticalLineAndShapeRenderer0.setLegendItemURLGenerator(categorySeriesLabelGenerator6);
        org.junit.Assert.assertNull(categoryItemLabelGenerator1);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_FINISHED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.Range range3 = numberAxis2.getDefaultAutoRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint(range3, (double) (-1L));
        org.jfree.data.Range range6 = org.jfree.data.Range.combine(range0, range3);
        try {
            org.jfree.data.Range range9 = org.jfree.data.Range.expand(range3, (double) (-2208927600000L), (double) 60000L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (2.2089276E12) <= upper (60001.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(range6);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_STARTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("RectangleConstraintType.RANGE", graphics2D1, (float) 0, (float) (-1), (double) 'a', 0.0f, (float) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        java.awt.Color color0 = java.awt.Color.white;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        java.lang.ClassLoader classLoader0 = null;
        try {
            java.util.ResourceBundle.clearCache(classLoader0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Comparable comparable1 = null;
        try {
            int int2 = defaultCategoryDataset0.getRowIndex(comparable1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.POSITIVE;
        org.junit.Assert.assertNotNull(rangeType0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer1 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean2 = statisticalLineAndShapeRenderer1.getDrawOutlines();
        statisticalLineAndShapeRenderer1.setAutoPopulateSeriesFillPaint(false);
        java.lang.Object obj5 = statisticalLineAndShapeRenderer1.clone();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        statisticalLineAndShapeRenderer1.setBaseStroke(stroke6);
        boolean boolean10 = statisticalLineAndShapeRenderer1.getItemShapeVisible((int) '4', (int) (byte) 10);
        java.awt.Font font12 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        statisticalLineAndShapeRenderer1.setSeriesItemLabelFont((int) 'a', font12);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer15 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean16 = statisticalLineAndShapeRenderer15.getDrawOutlines();
        statisticalLineAndShapeRenderer15.setAutoPopulateSeriesFillPaint(false);
        java.awt.Stroke stroke20 = statisticalLineAndShapeRenderer15.lookupSeriesStroke(28);
        lineAndShapeRenderer14.setBaseStroke(stroke20);
        lineAndShapeRenderer14.setSeriesItemLabelsVisible(28, (java.lang.Boolean) true);
        java.awt.Paint paint25 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        lineAndShapeRenderer14.setBaseFillPaint(paint25);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = org.jfree.chart.util.RectangleEdge.TOP;
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge27);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment29 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment30 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double33 = rectangleInsets31.calculateBottomOutset((double) 'a');
        try {
            org.jfree.chart.title.TextTitle textTitle34 = new org.jfree.chart.title.TextTitle("{0}", font12, paint25, rectangleEdge27, horizontalAlignment29, verticalAlignment30, rectangleInsets31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'horizontalAlignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.0d + "'", double33 == 1.0d);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        java.lang.Class class0 = null;
        java.util.Date date1 = null;
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date1, timeZone2);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNull(regularTimePeriod3);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        java.lang.Object obj4 = null;
        boolean boolean5 = polarPlot3.equals(obj4);
        int int6 = polarPlot3.getSeriesCount();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        polarPlot3.setAngleLabelPaint((java.awt.Paint) color7);
        int int9 = polarPlot3.getSeriesCount();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (-1));
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets0.calculateBottomOutset(4.0d);
        double double3 = rectangleInsets0.getLeft();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean4 = statisticalLineAndShapeRenderer3.getDrawOutlines();
        statisticalLineAndShapeRenderer3.setAutoPopulateSeriesFillPaint(false);
        java.awt.Stroke stroke8 = statisticalLineAndShapeRenderer3.lookupSeriesStroke(28);
        lineAndShapeRenderer2.setBaseStroke(stroke8);
        java.awt.Paint paint11 = lineAndShapeRenderer2.getSeriesFillPaint((int) '#');
        java.awt.Stroke stroke14 = lineAndShapeRenderer2.getItemOutlineStroke(1, 10);
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Stroke stroke16 = null;
        try {
            org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color1, stroke14, (java.awt.Paint) color15, stroke16, (float) 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        int int0 = org.jfree.data.time.SerialDate.NEAREST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        int int1 = color0.getGreen();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.RangeType rangeType2 = numberAxis1.getRangeType();
        boolean boolean3 = numberAxis1.isTickMarksVisible();
        org.junit.Assert.assertNotNull(rangeType2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        java.lang.Object obj4 = null;
        boolean boolean5 = polarPlot3.equals(obj4);
        int int6 = polarPlot3.getSeriesCount();
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.geom.Point2D point2D9 = null;
        org.jfree.chart.plot.PlotState plotState10 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset11 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range12 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer15 = null;
        org.jfree.chart.plot.PolarPlot polarPlot16 = new org.jfree.chart.plot.PolarPlot(xYDataset13, valueAxis14, polarItemRenderer15);
        defaultCategoryDataset11.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot16);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo19);
        java.awt.geom.Point2D point2D21 = null;
        polarPlot16.zoomDomainAxes((double) '#', plotRenderingInfo20, point2D21);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo23 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo23);
        plotRenderingInfo20.addSubplotInfo(plotRenderingInfo24);
        try {
            polarPlot3.draw(graphics2D7, rectangle2D8, point2D9, plotState10, plotRenderingInfo20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(range12);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = null;
        statisticalLineAndShapeRenderer0.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator2, true);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer5 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean6 = statisticalLineAndShapeRenderer5.getDrawOutlines();
        statisticalLineAndShapeRenderer5.setAutoPopulateSeriesFillPaint(false);
        java.awt.Stroke stroke10 = statisticalLineAndShapeRenderer5.lookupSeriesStroke(28);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = statisticalLineAndShapeRenderer5.getBaseNegativeItemLabelPosition();
        statisticalLineAndShapeRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition11);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator13 = statisticalLineAndShapeRenderer0.getBaseURLGenerator();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
        org.junit.Assert.assertNull(categoryURLGenerator13);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit(0.0d);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator3 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("({0}, {1}) = {3} - {4}");
        boolean boolean4 = numberTickUnit1.equals((java.lang.Object) "({0}, {1}) = {3} - {4}");
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) '#', true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setInverted(true);
        boolean boolean4 = numberAxis1.isAxisLineVisible();
        boolean boolean5 = numberAxis1.getAutoRangeStickyZero();
        org.jfree.data.Range range6 = null;
        try {
            numberAxis1.setRangeWithMargins(range6, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator2 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("EXPAND", numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset2, valueAxis3, polarItemRenderer4);
        defaultCategoryDataset0.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot5);
        int int7 = defaultCategoryDataset0.getColumnCount();
        try {
            java.lang.Number number10 = defaultCategoryDataset0.getValue((java.lang.Comparable) 11, (java.lang.Comparable) 60000L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: 60000");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = null;
        statisticalLineAndShapeRenderer0.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator2, true);
        statisticalLineAndShapeRenderer0.setSeriesVisibleInLegend(0, (java.lang.Boolean) true, true);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(1.0d, (double) (short) -1);
        boolean boolean12 = stackedBarRenderer3D11.isDrawBarOutline();
        java.awt.Paint paint13 = stackedBarRenderer3D11.getWallPaint();
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator15 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("({0}, {1}) = {3} - {4}");
        stackedBarRenderer3D11.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator15);
        statisticalLineAndShapeRenderer0.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator15);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        try {
            java.lang.String str20 = standardCategorySeriesLabelGenerator15.generateLabel(categoryDataset18, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number) 10.0f, (java.lang.Number) 86400000L);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        boolean boolean0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.Range range2 = numberAxis1.getDefaultAutoRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = new org.jfree.chart.block.RectangleConstraint(range2, (double) (-1L));
        boolean boolean6 = range2.equals((java.lang.Object) true);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        boolean boolean2 = blockBorder0.equals((java.lang.Object) ' ');
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        double double0 = org.jfree.chart.plot.PiePlot.MAX_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.4d + "'", double0 == 0.4d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font3 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer4 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer4.setDrawOutlines(true);
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer4.setBasePaint((java.awt.Paint) color7, false);
        org.jfree.chart.text.TextMeasurer textMeasurer11 = null;
        org.jfree.chart.text.TextBlock textBlock12 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, (java.awt.Paint) color7, (float) (byte) -1, textMeasurer11);
        numberAxis1.setTickMarkPaint((java.awt.Paint) color7);
        boolean boolean14 = numberAxis1.isInverted();
        numberAxis1.setAutoRangeMinimumSize(1.0d);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(textBlock12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder11 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer6.setFrame((org.jfree.chart.block.BlockFrame) blockBorder11);
        blockContainer0.add((org.jfree.chart.block.Block) blockContainer6);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.util.Size2D size2D15 = blockContainer6.arrange(graphics2D14);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit17 = new org.jfree.chart.axis.NumberTickUnit(0.0d);
        boolean boolean18 = blockContainer6.equals((java.lang.Object) 0.0d);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.block.BlockContainer blockContainer20 = new org.jfree.chart.block.BlockContainer();
        blockContainer20.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer26 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder31 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer26.setFrame((org.jfree.chart.block.BlockFrame) blockBorder31);
        blockContainer20.add((org.jfree.chart.block.Block) blockContainer26);
        java.awt.Graphics2D graphics2D34 = null;
        org.jfree.chart.util.Size2D size2D35 = blockContainer26.arrange(graphics2D34);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor38 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D39 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D35, (double) '#', (double) 1.0f, rectangleAnchor38);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer40 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator42 = null;
        statisticalLineAndShapeRenderer40.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator42, true);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer45 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean46 = statisticalLineAndShapeRenderer45.getDrawOutlines();
        statisticalLineAndShapeRenderer45.setAutoPopulateSeriesFillPaint(false);
        java.awt.Stroke stroke50 = statisticalLineAndShapeRenderer45.lookupSeriesStroke(28);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition51 = statisticalLineAndShapeRenderer45.getBaseNegativeItemLabelPosition();
        statisticalLineAndShapeRenderer40.setBasePositiveItemLabelPosition(itemLabelPosition51);
        try {
            java.lang.Object obj53 = blockContainer6.draw(graphics2D19, rectangle2D39, (java.lang.Object) itemLabelPosition51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(size2D15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(size2D35);
        org.junit.Assert.assertNotNull(rectangleAnchor38);
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(itemLabelPosition51);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDepthFactor((double) (byte) 1);
        piePlot3D1.setCircular(true, true);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = null;
        try {
            piePlot3D1.setLegendLabelGenerator(pieSectionLabelGenerator7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'generator' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_START_ANGLE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 90.0d + "'", double0 == 90.0d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        double double0 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_Y_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 8.0d + "'", double0 == 8.0d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder11 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer6.setFrame((org.jfree.chart.block.BlockFrame) blockBorder11);
        blockContainer0.add((org.jfree.chart.block.Block) blockContainer6);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.util.Size2D size2D15 = blockContainer6.arrange(graphics2D14);
        org.jfree.chart.block.Block block16 = null;
        org.jfree.data.general.PieDataset pieDataset17 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D18 = new org.jfree.chart.plot.PiePlot3D(pieDataset17);
        piePlot3D18.setDepthFactor((double) (byte) 1);
        piePlot3D18.setDepthFactor(0.0d);
        java.awt.Stroke stroke23 = piePlot3D18.getLabelLinkStroke();
        double double24 = piePlot3D18.getShadowXOffset();
        java.lang.String str25 = piePlot3D18.getNoDataMessage();
        java.awt.Shape shape26 = piePlot3D18.getLegendItemShape();
        try {
            blockContainer6.add(block16, (java.lang.Object) shape26);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.awt.geom.Ellipse2D$Double cannot be cast to org.jfree.chart.util.RectangleEdge");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(size2D15);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 4.0d + "'", double24 == 4.0d);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNotNull(shape26);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        java.awt.Paint paint1 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType2 = org.jfree.chart.block.LengthConstraintType.RANGE;
        java.lang.String str3 = lengthConstraintType2.toString();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer4 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean5 = statisticalLineAndShapeRenderer4.getDrawOutlines();
        statisticalLineAndShapeRenderer4.setAutoPopulateSeriesFillPaint(false);
        java.lang.Object obj8 = statisticalLineAndShapeRenderer4.clone();
        java.awt.Stroke stroke9 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        statisticalLineAndShapeRenderer4.setBaseStroke(stroke9);
        boolean boolean11 = lengthConstraintType2.equals((java.lang.Object) stroke9);
        try {
            org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker(0.0d, paint1, stroke9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(lengthConstraintType2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleConstraintType.RANGE" + "'", str3.equals("RectangleConstraintType.RANGE"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.data.resources.DataPackageResources dataPackageResources0 = new org.jfree.data.resources.DataPackageResources();
        java.util.Enumeration<java.lang.String> strEnumeration1 = dataPackageResources0.getKeys();
        org.junit.Assert.assertNotNull(strEnumeration1);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str1 = org.jfree.chart.util.PaintUtilities.colorToString(color0);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#ffff40" + "'", str1.equals("#ffff40"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_MINIMUM_ARC_ANGLE_TO_DRAW;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-5d + "'", double0 == 1.0E-5d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, polarItemRenderer3);
        float float5 = polarPlot4.getBackgroundAlpha();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = polarPlot4.getRenderer();
        java.awt.Stroke stroke7 = polarPlot4.getRadiusGridlineStroke();
        boolean boolean8 = polarPlot4.isRadiusGridlinesVisible();
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 1.0f + "'", float5 == 1.0f);
        org.junit.Assert.assertNull(polarItemRenderer6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = null;
        statisticalLineAndShapeRenderer0.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator2, true);
        statisticalLineAndShapeRenderer0.setSeriesVisibleInLegend(0, (java.lang.Boolean) true, true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = statisticalLineAndShapeRenderer0.getSeriesURLGenerator(15);
        org.junit.Assert.assertNull(categoryURLGenerator10);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.Range range3 = numberAxis2.getDefaultAutoRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint(range3, (double) (-1L));
        org.jfree.data.Range range6 = org.jfree.data.Range.combine(range0, range3);
        org.jfree.data.Range range7 = null;
        org.jfree.data.Range range8 = org.jfree.data.Range.combine(range6, range7);
        org.jfree.data.time.DateRange dateRange9 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.data.Range range10 = org.jfree.data.Range.combine(range7, (org.jfree.data.Range) dateRange9);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(dateRange9);
        org.junit.Assert.assertNotNull(range10);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset2 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset2);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset4, valueAxis5, polarItemRenderer6);
        defaultCategoryDataset2.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot7);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo10);
        java.awt.geom.Point2D point2D12 = null;
        polarPlot7.zoomDomainAxes((double) '#', plotRenderingInfo11, point2D12);
        org.jfree.chart.block.BlockContainer blockContainer14 = new org.jfree.chart.block.BlockContainer();
        blockContainer14.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer20 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder25 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer20.setFrame((org.jfree.chart.block.BlockFrame) blockBorder25);
        blockContainer14.add((org.jfree.chart.block.Block) blockContainer20);
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.util.Size2D size2D29 = blockContainer20.arrange(graphics2D28);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor32 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D33 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D29, (double) '#', (double) 1.0f, rectangleAnchor32);
        plotRenderingInfo11.setPlotArea(rectangle2D33);
        org.jfree.chart.block.BlockContainer blockContainer35 = new org.jfree.chart.block.BlockContainer();
        blockContainer35.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer41 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder46 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer41.setFrame((org.jfree.chart.block.BlockFrame) blockBorder46);
        blockContainer35.add((org.jfree.chart.block.Block) blockContainer41);
        java.awt.Graphics2D graphics2D49 = null;
        org.jfree.chart.util.Size2D size2D50 = blockContainer41.arrange(graphics2D49);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor53 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D54 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D50, (double) '#', (double) 1.0f, rectangleAnchor53);
        double double55 = size2D50.height;
        try {
            java.lang.Object obj56 = blockContainer0.draw(graphics2D1, rectangle2D33, (java.lang.Object) double55);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(size2D29);
        org.junit.Assert.assertNotNull(rectangleAnchor32);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertNotNull(size2D50);
        org.junit.Assert.assertNotNull(rectangleAnchor53);
        org.junit.Assert.assertNotNull(rectangle2D54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 36.0d + "'", double55 == 36.0d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 0, 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, polarItemRenderer3);
        org.jfree.data.general.DatasetGroup datasetGroup5 = polarPlot4.getDatasetGroup();
        java.awt.Paint paint6 = polarPlot4.getAngleGridlinePaint();
        java.lang.Object obj7 = polarPlot4.clone();
        java.awt.Font font8 = polarPlot4.getAngleLabelFont();
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D10 = new org.jfree.chart.plot.PiePlot3D(pieDataset9);
        piePlot3D10.setDepthFactor((double) (byte) 1);
        piePlot3D10.setDepthFactor(0.0d);
        java.awt.Stroke stroke15 = piePlot3D10.getLabelLinkStroke();
        double double16 = piePlot3D10.getShadowXOffset();
        java.lang.String str17 = piePlot3D10.getNoDataMessage();
        java.awt.Paint paint18 = piePlot3D10.getBaseSectionOutlinePaint();
        polarPlot4.setRadiusGridlinePaint(paint18);
        org.junit.Assert.assertNull(datasetGroup5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D(pieDataset3);
        piePlot3D4.setDepthFactor((double) (byte) 1);
        piePlot3D4.setDepthFactor(0.0d);
        java.awt.Stroke stroke9 = piePlot3D4.getLabelLinkStroke();
        double double10 = piePlot3D4.getShadowXOffset();
        java.lang.String str11 = piePlot3D4.getNoDataMessage();
        java.awt.Paint paint12 = piePlot3D4.getBaseSectionOutlinePaint();
        org.jfree.data.general.PieDataset pieDataset13 = null;
        piePlot3D4.setDataset(pieDataset13);
        org.jfree.chart.plot.Plot plot15 = piePlot3D4.getParent();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset17 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range18 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset17);
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer21 = null;
        org.jfree.chart.plot.PolarPlot polarPlot22 = new org.jfree.chart.plot.PolarPlot(xYDataset19, valueAxis20, polarItemRenderer21);
        defaultCategoryDataset17.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot22);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo25 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo25);
        java.awt.geom.Point2D point2D27 = null;
        polarPlot22.zoomDomainAxes((double) '#', plotRenderingInfo26, point2D27);
        org.jfree.chart.block.BlockContainer blockContainer29 = new org.jfree.chart.block.BlockContainer();
        blockContainer29.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer35 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder40 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer35.setFrame((org.jfree.chart.block.BlockFrame) blockBorder40);
        blockContainer29.add((org.jfree.chart.block.Block) blockContainer35);
        java.awt.Graphics2D graphics2D43 = null;
        org.jfree.chart.util.Size2D size2D44 = blockContainer35.arrange(graphics2D43);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor47 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D48 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D44, (double) '#', (double) 1.0f, rectangleAnchor47);
        plotRenderingInfo26.setPlotArea(rectangle2D48);
        piePlot3D4.drawBackgroundImage(graphics2D16, rectangle2D48);
        try {
            lineAndShapeRenderer0.drawBackground(graphics2D1, categoryPlot2, rectangle2D48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(plot15);
        org.junit.Assert.assertNull(range18);
        org.junit.Assert.assertNotNull(size2D44);
        org.junit.Assert.assertNotNull(rectangleAnchor47);
        org.junit.Assert.assertNotNull(rectangle2D48);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D2 = new org.jfree.chart.plot.PiePlot3D(pieDataset1);
        piePlot3D2.setDepthFactor((double) (byte) 1);
        piePlot3D2.setDepthFactor(0.0d);
        java.awt.Stroke stroke7 = piePlot3D2.getLabelLinkStroke();
        double double8 = piePlot3D2.getShadowXOffset();
        java.lang.String str9 = piePlot3D2.getNoDataMessage();
        java.awt.Shape shape10 = piePlot3D2.getLegendItemShape();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer11 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer11.setDrawOutlines(true);
        java.awt.Color color14 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer11.setBasePaint((java.awt.Paint) color14, false);
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer20 = null;
        org.jfree.chart.plot.PolarPlot polarPlot21 = new org.jfree.chart.plot.PolarPlot(xYDataset18, valueAxis19, polarItemRenderer20);
        java.lang.Object obj22 = null;
        boolean boolean23 = polarPlot21.equals(obj22);
        int int24 = polarPlot21.getSeriesCount();
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        polarPlot21.setAngleLabelPaint((java.awt.Paint) color25);
        statisticalLineAndShapeRenderer11.setSeriesFillPaint(2, (java.awt.Paint) color25);
        piePlot3D2.setLabelPaint((java.awt.Paint) color25);
        java.awt.Paint paint29 = piePlot3D2.getLabelBackgroundPaint();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer30 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer30.setSeriesLinesVisible((int) (short) 10, true);
        java.awt.Stroke stroke35 = statisticalLineAndShapeRenderer30.lookupSeriesOutlineStroke((int) '#');
        org.jfree.data.general.PieDataset pieDataset36 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D37 = new org.jfree.chart.plot.PiePlot3D(pieDataset36);
        piePlot3D37.setDepthFactor((double) (byte) 1);
        piePlot3D37.setDepthFactor(0.0d);
        java.awt.Stroke[] strokeArray42 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        boolean boolean43 = piePlot3D37.equals((java.lang.Object) strokeArray42);
        java.awt.Paint paint44 = piePlot3D37.getLabelShadowPaint();
        java.awt.Paint paint45 = piePlot3D37.getLabelBackgroundPaint();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer46 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer46.setDrawOutlines(true);
        java.awt.Color color49 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer46.setBasePaint((java.awt.Paint) color49, false);
        org.jfree.data.xy.XYDataset xYDataset53 = null;
        org.jfree.chart.axis.ValueAxis valueAxis54 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer55 = null;
        org.jfree.chart.plot.PolarPlot polarPlot56 = new org.jfree.chart.plot.PolarPlot(xYDataset53, valueAxis54, polarItemRenderer55);
        java.lang.Object obj57 = null;
        boolean boolean58 = polarPlot56.equals(obj57);
        int int59 = polarPlot56.getSeriesCount();
        java.awt.Color color60 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        polarPlot56.setAngleLabelPaint((java.awt.Paint) color60);
        statisticalLineAndShapeRenderer46.setSeriesFillPaint(2, (java.awt.Paint) color60);
        java.awt.Stroke stroke65 = statisticalLineAndShapeRenderer46.getItemStroke(0, 10);
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker67 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleConstraintType.RANGE", paint29, stroke35, paint45, stroke65, (float) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(strokeArray42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertNotNull(stroke65);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDepthFactor((double) (byte) 1);
        piePlot3D1.setDepthFactor(0.0d);
        piePlot3D1.setInteriorGap((double) 0.0f);
        java.awt.Shape shape8 = piePlot3D1.getLegendItemShape();
        double double9 = piePlot3D1.getInteriorGap();
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.CENTER;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDepthFactor((double) (byte) 1);
        piePlot3D1.setDepthFactor(0.0d);
        java.awt.Stroke stroke6 = piePlot3D1.getLabelLinkStroke();
        double double7 = piePlot3D1.getShadowXOffset();
        java.lang.String str8 = piePlot3D1.getNoDataMessage();
        java.awt.Paint paint9 = piePlot3D1.getBaseSectionOutlinePaint();
        org.jfree.data.general.PieDataset pieDataset10 = null;
        piePlot3D1.setDataset(pieDataset10);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator12 = null;
        piePlot3D1.setLegendLabelURLGenerator(pieURLGenerator12);
        piePlot3D1.setMaximumLabelWidth((double) 0L);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDepthFactor((double) (byte) 1);
        piePlot3D1.setDepthFactor(0.0d);
        java.awt.Stroke stroke6 = piePlot3D1.getLabelLinkStroke();
        double double7 = piePlot3D1.getShadowXOffset();
        java.lang.String str8 = piePlot3D1.getNoDataMessage();
        java.awt.Paint paint9 = piePlot3D1.getBaseSectionOutlinePaint();
        org.jfree.data.general.PieDataset pieDataset10 = null;
        piePlot3D1.setDataset(pieDataset10);
        org.jfree.chart.plot.Plot plot12 = piePlot3D1.getParent();
        try {
            org.jfree.chart.plot.DrawingSupplier drawingSupplier13 = plot12.getDrawingSupplier();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(plot12);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        java.text.DateFormatSymbols dateFormatSymbols0 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        org.junit.Assert.assertNotNull(dateFormatSymbols0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState2 = null;
        org.jfree.chart.block.BlockContainer blockContainer3 = new org.jfree.chart.block.BlockContainer();
        blockContainer3.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer9 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder14 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer9.setFrame((org.jfree.chart.block.BlockFrame) blockBorder14);
        blockContainer3.add((org.jfree.chart.block.Block) blockContainer9);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.util.Size2D size2D18 = blockContainer9.arrange(graphics2D17);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D22 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D18, (double) '#', (double) 1.0f, rectangleAnchor21);
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D24.clearCategoryLabelToolTips();
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font29 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer30 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer30.setDrawOutlines(true);
        java.awt.Color color33 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer30.setBasePaint((java.awt.Paint) color33, false);
        org.jfree.chart.text.TextMeasurer textMeasurer37 = null;
        org.jfree.chart.text.TextBlock textBlock38 = org.jfree.chart.text.TextUtilities.createTextBlock("", font29, (java.awt.Paint) color33, (float) (byte) -1, textMeasurer37);
        numberAxis27.setTickMarkPaint((java.awt.Paint) color33);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset40 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup41 = defaultCategoryDataset40.getGroup();
        try {
            ganttRenderer0.drawItem(graphics2D1, categoryItemRendererState2, rectangle2D22, categoryPlot23, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D24, (org.jfree.chart.axis.ValueAxis) numberAxis27, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset40, 0, 10, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(size2D18);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(textBlock38);
        org.junit.Assert.assertNotNull(datasetGroup41);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        try {
            defaultKeyedValues0.insertValue((int) '4', (java.lang.Comparable) 1.0d, (java.lang.Number) 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 'position' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        int int1 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        int int0 = org.jfree.data.time.SerialDate.LAST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer1 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean2 = statisticalLineAndShapeRenderer1.getDrawOutlines();
        statisticalLineAndShapeRenderer1.setAutoPopulateSeriesFillPaint(false);
        java.awt.Stroke stroke6 = statisticalLineAndShapeRenderer1.lookupSeriesStroke(28);
        lineAndShapeRenderer0.setBaseStroke(stroke6);
        java.awt.Paint paint9 = lineAndShapeRenderer0.getSeriesFillPaint((int) '#');
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor16 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        boolean boolean17 = blockBorder15.equals((java.lang.Object) itemLabelAnchor16);
        org.jfree.chart.text.TextAnchor textAnchor18 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor19 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.jfree.chart.axis.AxisLocation axisLocation20 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        boolean boolean21 = textAnchor19.equals((java.lang.Object) axisLocation20);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition23 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor16, textAnchor18, textAnchor19, (double) 2);
        try {
            lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition((int) (short) -1, itemLabelPosition23, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertNotNull(itemLabelAnchor16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(textAnchor18);
        org.junit.Assert.assertNotNull(textAnchor19);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("({0}, {1}) = {3} - {4}");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset2, valueAxis3, polarItemRenderer4);
        defaultCategoryDataset0.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot5);
        int int7 = defaultCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D8 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D8.clearCategoryLabelToolTips();
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer13 = null;
        org.jfree.chart.plot.PolarPlot polarPlot14 = new org.jfree.chart.plot.PolarPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) numberAxis12, polarItemRenderer13);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer16 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean17 = statisticalLineAndShapeRenderer16.getDrawOutlines();
        statisticalLineAndShapeRenderer16.setAutoPopulateSeriesFillPaint(false);
        java.awt.Stroke stroke21 = statisticalLineAndShapeRenderer16.lookupSeriesStroke(28);
        lineAndShapeRenderer15.setBaseStroke(stroke21);
        java.awt.Paint paint24 = lineAndShapeRenderer15.getSeriesFillPaint((int) '#');
        java.awt.Stroke stroke27 = lineAndShapeRenderer15.getItemOutlineStroke(1, 10);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D8, (org.jfree.chart.axis.ValueAxis) numberAxis12, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer15);
        org.jfree.chart.axis.AxisLocation axisLocation29 = null;
        try {
            categoryPlot28.setDomainAxisLocation(axisLocation29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNull(paint24);
        org.junit.Assert.assertNotNull(stroke27);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font3 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer4 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer4.setDrawOutlines(true);
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer4.setBasePaint((java.awt.Paint) color7, false);
        org.jfree.chart.text.TextMeasurer textMeasurer11 = null;
        org.jfree.chart.text.TextBlock textBlock12 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, (java.awt.Paint) color7, (float) (byte) -1, textMeasurer11);
        numberAxis1.setTickMarkPaint((java.awt.Paint) color7);
        numberAxis1.configure();
        numberAxis1.setFixedAutoRange((double) (-1L));
        org.jfree.chart.axis.NumberTickUnit numberTickUnit17 = numberAxis1.getTickUnit();
        numberAxis1.resizeRange(90.0d);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(textBlock12);
        org.junit.Assert.assertNotNull(numberTickUnit17);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        java.awt.Color color0 = java.awt.Color.black;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        int int0 = org.jfree.chart.axis.DateTickUnit.MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(1.0d, (double) (short) -1);
        boolean boolean3 = stackedBarRenderer3D2.isDrawBarOutline();
        boolean boolean4 = stackedBarRenderer3D2.getAutoPopulateSeriesShape();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        try {
            java.lang.Comparable comparable2 = defaultBoxAndWhiskerCategoryDataset0.getColumnKey(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        java.lang.String str1 = unitType0.toString();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UnitType.ABSOLUTE" + "'", str1.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer0.setSeriesLinesVisible((int) (short) 10, true);
        java.awt.Stroke stroke5 = statisticalLineAndShapeRenderer0.lookupSeriesOutlineStroke((int) '#');
        java.awt.Font font6 = statisticalLineAndShapeRenderer0.getBaseItemLabelFont();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(font6);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        boolean boolean2 = ringPlot1.getSeparatorsVisible();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        boolean boolean1 = textTitle0.getExpandToFitSpace();
        java.lang.String str2 = textTitle0.getText();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, polarItemRenderer3);
        double double5 = polarPlot4.getMaxRadius();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.05d + "'", double5 == 1.05d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder11 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer6.setFrame((org.jfree.chart.block.BlockFrame) blockBorder11);
        blockContainer0.add((org.jfree.chart.block.Block) blockContainer6);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.util.Size2D size2D15 = blockContainer6.arrange(graphics2D14);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit17 = new org.jfree.chart.axis.NumberTickUnit(0.0d);
        boolean boolean18 = blockContainer6.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder19 = new org.jfree.chart.block.BlockBorder();
        blockContainer6.setFrame((org.jfree.chart.block.BlockFrame) blockBorder19);
        java.util.List list21 = blockContainer6.getBlocks();
        org.junit.Assert.assertNotNull(size2D15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(list21);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        java.lang.Comparable comparable3 = null;
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        int int5 = year4.getYear();
        try {
            defaultCategoryDataset0.setValue((java.lang.Number) 0.0f, comparable3, (java.lang.Comparable) int5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        java.text.AttributedString attributedString0 = null;
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D5 = new org.jfree.chart.plot.PiePlot3D(pieDataset4);
        piePlot3D5.setDepthFactor((double) (byte) 1);
        piePlot3D5.setDepthFactor(0.0d);
        java.awt.Stroke stroke10 = piePlot3D5.getLabelLinkStroke();
        double double11 = piePlot3D5.getShadowXOffset();
        java.lang.String str12 = piePlot3D5.getNoDataMessage();
        java.awt.Shape shape13 = piePlot3D5.getLegendItemShape();
        java.awt.Shape shape14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        boolean boolean15 = org.jfree.chart.util.ShapeUtilities.equal(shape13, shape14);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.gantt.Task task18 = new org.jfree.data.gantt.Task("", (org.jfree.data.time.TimePeriod) year17);
        java.awt.Font font20 = null;
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.jfree.chart.text.TextMeasurer textMeasurer23 = null;
        org.jfree.chart.text.TextBlock textBlock24 = org.jfree.chart.text.TextUtilities.createTextBlock("", font20, (java.awt.Paint) color21, (float) ' ', textMeasurer23);
        org.jfree.data.general.PieDataset pieDataset25 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D26 = new org.jfree.chart.plot.PiePlot3D(pieDataset25);
        piePlot3D26.setDepthFactor((double) (byte) 1);
        piePlot3D26.setDepthFactor(0.0d);
        java.awt.Stroke stroke31 = piePlot3D26.getLabelLinkStroke();
        boolean boolean32 = textBlock24.equals((java.lang.Object) stroke31);
        int int33 = year17.compareTo((java.lang.Object) stroke31);
        java.awt.Color color35 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Color color36 = java.awt.Color.getColor("hi!", color35);
        try {
            org.jfree.chart.LegendItem legendItem37 = new org.jfree.chart.LegendItem(attributedString0, "EXPAND", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "{0}", shape14, stroke31, (java.awt.Paint) color35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(textBlock24);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(color36);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean1 = statisticalLineAndShapeRenderer0.getDrawOutlines();
        statisticalLineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(false);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis7.setInverted(true);
        boolean boolean10 = numberAxis7.isAxisLineVisible();
        boolean boolean11 = numberAxis7.getAutoRangeStickyZero();
        java.awt.Stroke stroke12 = numberAxis7.getAxisLineStroke();
        categoryPlot5.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis7);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset14 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range15 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset14);
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer18 = null;
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot(xYDataset16, valueAxis17, polarItemRenderer18);
        defaultCategoryDataset14.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot19);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo22 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo22);
        java.awt.geom.Point2D point2D24 = null;
        polarPlot19.zoomDomainAxes((double) '#', plotRenderingInfo23, point2D24);
        org.jfree.chart.block.BlockContainer blockContainer26 = new org.jfree.chart.block.BlockContainer();
        blockContainer26.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer32 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder37 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer32.setFrame((org.jfree.chart.block.BlockFrame) blockBorder37);
        blockContainer26.add((org.jfree.chart.block.Block) blockContainer32);
        java.awt.Graphics2D graphics2D40 = null;
        org.jfree.chart.util.Size2D size2D41 = blockContainer32.arrange(graphics2D40);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D45 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D41, (double) '#', (double) 1.0f, rectangleAnchor44);
        plotRenderingInfo23.setPlotArea(rectangle2D45);
        try {
            statisticalLineAndShapeRenderer0.drawOutline(graphics2D4, categoryPlot5, rectangle2D45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNotNull(size2D41);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
        org.junit.Assert.assertNotNull(rectangle2D45);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        boolean boolean2 = textLine0.equals((java.lang.Object) "({0}, {1}) = {3} - {4}");
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        textLine0.draw(graphics2D3, 0.0f, (float) (-2208927600000L), textAnchor6, (float) 15, (float) 1L, 0.4d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.Range range3 = numberAxis2.getDefaultAutoRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint(range3, (double) (-1L));
        org.jfree.data.Range range6 = org.jfree.data.Range.combine(range0, range3);
        double double7 = range6.getLowerBound();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(1.0d, (double) (short) -1);
        boolean boolean3 = stackedBarRenderer3D2.isDrawBarOutline();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = stackedBarRenderer3D2.getBaseURLGenerator();
        double double5 = stackedBarRenderer3D2.getYOffset();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        double double0 = org.jfree.chart.axis.DateAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE_IN_MILLISECONDS;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.0d + "'", double0 == 2.0d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        polarPlot3.setAngleLabelsVisible(true);
        try {
            double double6 = polarPlot3.getMaxRadius();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        java.text.AttributedString attributedString0 = null;
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D5 = new org.jfree.chart.plot.PiePlot3D(pieDataset4);
        piePlot3D5.setDepthFactor((double) (byte) 1);
        piePlot3D5.setDepthFactor(0.0d);
        piePlot3D5.setInteriorGap((double) 0.0f);
        java.awt.Shape shape12 = piePlot3D5.getLegendItemShape();
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Color color16 = java.awt.Color.getColor("hi!", color15);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer17 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean18 = statisticalLineAndShapeRenderer17.getDrawOutlines();
        statisticalLineAndShapeRenderer17.setAutoPopulateSeriesFillPaint(false);
        java.awt.Stroke stroke22 = statisticalLineAndShapeRenderer17.lookupSeriesStroke(28);
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        int int24 = color23.getTransparency();
        java.awt.Color color25 = color23.darker();
        try {
            org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem(attributedString0, "({0}, {1}) = {3} - {4}", "RectangleConstraintType.RANGE", "EXPAND", shape12, (java.awt.Paint) color16, stroke22, (java.awt.Paint) color23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(color25);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.Marker marker1 = null;
        org.jfree.chart.util.Layer layer2 = org.jfree.chart.util.Layer.FOREGROUND;
        try {
            categoryPlot0.addRangeMarker(marker1, layer2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(layer2);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font4 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer5 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer5.setDrawOutlines(true);
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer5.setBasePaint((java.awt.Paint) color8, false);
        org.jfree.chart.text.TextMeasurer textMeasurer12 = null;
        org.jfree.chart.text.TextBlock textBlock13 = org.jfree.chart.text.TextUtilities.createTextBlock("", font4, (java.awt.Paint) color8, (float) (byte) -1, textMeasurer12);
        numberAxis2.setTickMarkPaint((java.awt.Paint) color8);
        boolean boolean15 = numberAxis2.isInverted();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer16 = null;
        org.jfree.chart.plot.PolarPlot polarPlot17 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, polarItemRenderer16);
        numberAxis2.zoomRange((double) (-1.0f), (double) (short) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = numberAxis2.getLabelInsets();
        double double23 = rectangleInsets21.calculateTopInset(0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(textBlock13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 3.0d + "'", double23 == 3.0d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean1 = statisticalLineAndShapeRenderer0.getDrawOutlines();
        statisticalLineAndShapeRenderer0.setBaseSeriesVisible(true, false);
        java.awt.Paint paint5 = statisticalLineAndShapeRenderer0.getErrorIndicatorPaint();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(paint5);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("");
        taskSeries1.fireSeriesChanged();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        taskSeries1.removeChangeListener(seriesChangeListener3);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.gantt.Task task7 = new org.jfree.data.gantt.Task("", (org.jfree.data.time.TimePeriod) year6);
        taskSeries1.remove(task7);
        int int9 = task7.getSubtaskCount();
        org.jfree.data.gantt.TaskSeries taskSeries11 = new org.jfree.data.gantt.TaskSeries("");
        taskSeries11.fireSeriesChanged();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        taskSeries11.removeChangeListener(seriesChangeListener13);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        org.jfree.data.gantt.Task task17 = new org.jfree.data.gantt.Task("", (org.jfree.data.time.TimePeriod) year16);
        taskSeries11.remove(task17);
        task7.removeSubtask(task17);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(true);
        java.lang.String[] strArray3 = org.jfree.data.time.SerialDate.getMonths(true);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray5 = new double[] {};
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[][] doubleArray9 = new double[][] { doubleArray4, doubleArray5, doubleArray6, doubleArray7, doubleArray8 };
        try {
            org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable[]) strArray1, (java.lang.Comparable[]) strArray3, doubleArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of row keys does not match the number of rows in the data array.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("EXPAND", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis2.setInverted(true);
        boolean boolean5 = numberAxis2.isAxisLineVisible();
        boolean boolean6 = numberAxis2.getAutoRangeStickyZero();
        java.awt.Stroke stroke7 = numberAxis2.getAxisLineStroke();
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis2);
        java.awt.Font font10 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer11 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer11.setDrawOutlines(true);
        java.awt.Color color14 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer11.setBasePaint((java.awt.Paint) color14, false);
        org.jfree.chart.text.TextMeasurer textMeasurer18 = null;
        org.jfree.chart.text.TextBlock textBlock19 = org.jfree.chart.text.TextUtilities.createTextBlock("", font10, (java.awt.Paint) color14, (float) (byte) -1, textMeasurer18);
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor23 = null;
        java.awt.Shape shape27 = textBlock19.calculateBounds(graphics2D20, (float) 1, 100.0f, textBlockAnchor23, (float) 3, (float) (short) -1, (double) 0);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset30 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset30);
        org.jfree.data.Range range32 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset30);
        java.lang.Comparable comparable33 = null;
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity35 = new org.jfree.chart.entity.CategoryItemEntity(shape27, "{0}", "EXPAND", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset30, comparable33, (java.lang.Comparable) 1.0d);
        org.jfree.chart.util.SortOrder sortOrder36 = org.jfree.chart.util.SortOrder.DESCENDING;
        boolean boolean37 = categoryItemEntity35.equals((java.lang.Object) sortOrder36);
        categoryPlot0.setColumnRenderingOrder(sortOrder36);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder39 = null;
        try {
            categoryPlot0.setDatasetRenderingOrder(datasetRenderingOrder39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(textBlock19);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNull(range31);
        org.junit.Assert.assertNull(range32);
        org.junit.Assert.assertNotNull(sortOrder36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        java.lang.Class class0 = null;
        java.lang.ClassLoader classLoader1 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class0);
        org.junit.Assert.assertNotNull(classLoader1);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, polarItemRenderer3);
        float float5 = polarPlot4.getBackgroundAlpha();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = polarPlot4.getRenderer();
        java.awt.Paint paint7 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        polarPlot4.setBackgroundPaint(paint7);
        java.awt.Paint paint9 = polarPlot4.getRadiusGridlinePaint();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D12 = new org.jfree.chart.plot.PiePlot3D(pieDataset11);
        piePlot3D12.setDepthFactor((double) (byte) 1);
        piePlot3D12.setDepthFactor(0.0d);
        java.awt.Stroke stroke17 = piePlot3D12.getLabelLinkStroke();
        double double18 = piePlot3D12.getShadowXOffset();
        java.lang.String str19 = piePlot3D12.getNoDataMessage();
        java.awt.Paint paint20 = piePlot3D12.getBaseSectionOutlinePaint();
        java.awt.Paint paint22 = piePlot3D12.getSectionOutlinePaint((java.lang.Comparable) 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font26 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer27 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer27.setDrawOutlines(true);
        java.awt.Color color30 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer27.setBasePaint((java.awt.Paint) color30, false);
        org.jfree.chart.text.TextMeasurer textMeasurer34 = null;
        org.jfree.chart.text.TextBlock textBlock35 = org.jfree.chart.text.TextUtilities.createTextBlock("", font26, (java.awt.Paint) color30, (float) (byte) -1, textMeasurer34);
        numberAxis24.setTickMarkPaint((java.awt.Paint) color30);
        piePlot3D12.setLabelShadowPaint((java.awt.Paint) color30);
        org.jfree.chart.block.BlockContainer blockContainer38 = new org.jfree.chart.block.BlockContainer();
        blockContainer38.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer44 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder49 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer44.setFrame((org.jfree.chart.block.BlockFrame) blockBorder49);
        blockContainer38.add((org.jfree.chart.block.Block) blockContainer44);
        java.awt.Graphics2D graphics2D52 = null;
        org.jfree.chart.util.Size2D size2D53 = blockContainer44.arrange(graphics2D52);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor56 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D57 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D53, (double) '#', (double) 1.0f, rectangleAnchor56);
        boolean boolean58 = piePlot3D12.equals((java.lang.Object) rectangle2D57);
        try {
            polarPlot4.drawOutline(graphics2D10, rectangle2D57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 1.0f + "'", float5 == 1.0f);
        org.junit.Assert.assertNull(polarItemRenderer6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 4.0d + "'", double18 == 4.0d);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNull(paint22);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(textBlock35);
        org.junit.Assert.assertNotNull(size2D53);
        org.junit.Assert.assertNotNull(rectangleAnchor56);
        org.junit.Assert.assertNotNull(rectangle2D57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDepthFactor((double) (byte) 1);
        piePlot3D1.setDepthFactor(0.0d);
        java.awt.Stroke stroke6 = piePlot3D1.getLabelLinkStroke();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        piePlot3D1.setDataset(pieDataset7);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator9 = null;
        piePlot3D1.setToolTipGenerator(pieToolTipGenerator9);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("{0}");
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis4, polarItemRenderer5);
        java.awt.Font font7 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        polarPlot6.setAngleLabelFont(font7);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer9 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer9.setDrawOutlines(true);
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer9.setBasePaint((java.awt.Paint) color12, false);
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer18 = null;
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot(xYDataset16, valueAxis17, polarItemRenderer18);
        java.lang.Object obj20 = null;
        boolean boolean21 = polarPlot19.equals(obj20);
        int int22 = polarPlot19.getSeriesCount();
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        polarPlot19.setAngleLabelPaint((java.awt.Paint) color23);
        statisticalLineAndShapeRenderer9.setSeriesFillPaint(2, (java.awt.Paint) color23);
        java.awt.Stroke stroke28 = statisticalLineAndShapeRenderer9.getItemStroke(0, 10);
        java.lang.Boolean boolean30 = statisticalLineAndShapeRenderer9.getSeriesCreateEntities((int) (short) -1);
        java.awt.Font font31 = statisticalLineAndShapeRenderer9.getBaseItemLabelFont();
        polarPlot6.setAngleLabelFont(font31);
        labelBlock1.setFont(font31);
        java.lang.Object obj34 = labelBlock1.clone();
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNull(boolean30);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(obj34);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(1.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = stackedBarRenderer3D2.getGradientPaintTransformer();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState5 = null;
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer();
        blockContainer6.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer12 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder17 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer12.setFrame((org.jfree.chart.block.BlockFrame) blockBorder17);
        blockContainer6.add((org.jfree.chart.block.Block) blockContainer12);
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.util.Size2D size2D21 = blockContainer12.arrange(graphics2D20);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D25 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D21, (double) '#', (double) 1.0f, rectangleAnchor24);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D27 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D27.clearCategoryLabelToolTips();
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.RangeType rangeType31 = numberAxis30.getRangeType();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset32 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset32);
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer36 = null;
        org.jfree.chart.plot.PolarPlot polarPlot37 = new org.jfree.chart.plot.PolarPlot(xYDataset34, valueAxis35, polarItemRenderer36);
        defaultCategoryDataset32.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot37);
        int int39 = defaultCategoryDataset32.getColumnCount();
        try {
            stackedBarRenderer3D2.drawItem(graphics2D4, categoryItemRendererState5, rectangle2D25, categoryPlot26, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D27, (org.jfree.chart.axis.ValueAxis) numberAxis30, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset32, 28, (int) (byte) 10, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gradientPaintTransformer3);
        org.junit.Assert.assertNotNull(size2D21);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNotNull(rangeType31);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        try {
            java.lang.Number number3 = defaultBoxAndWhiskerCategoryDataset0.getQ1Value((-1), (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = defaultCategoryDataset0.getGroup();
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, (double) 10L);
        org.junit.Assert.assertNotNull(datasetGroup1);
        org.junit.Assert.assertNull(range3);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(1.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = stackedBarRenderer3D2.getGradientPaintTransformer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = stackedBarRenderer3D2.getBaseItemLabelGenerator();
        stackedBarRenderer3D2.setBaseSeriesVisible(false);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D(pieDataset7);
        piePlot3D8.setDepthFactor((double) (byte) 1);
        piePlot3D8.setCircular(true, true);
        boolean boolean14 = stackedBarRenderer3D2.equals((java.lang.Object) true);
        org.jfree.chart.LegendItem legendItem17 = stackedBarRenderer3D2.getLegendItem((int) '4', (int) (short) 0);
        stackedBarRenderer3D2.setBaseSeriesVisible(true, true);
        org.junit.Assert.assertNotNull(gradientPaintTransformer3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(legendItem17);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset2, valueAxis3, polarItemRenderer4);
        defaultCategoryDataset0.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot5);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo8);
        java.awt.geom.Point2D point2D10 = null;
        polarPlot5.zoomDomainAxes((double) '#', plotRenderingInfo9, point2D10);
        org.jfree.chart.block.BlockContainer blockContainer12 = new org.jfree.chart.block.BlockContainer();
        blockContainer12.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer18 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder23 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer18.setFrame((org.jfree.chart.block.BlockFrame) blockBorder23);
        blockContainer12.add((org.jfree.chart.block.Block) blockContainer18);
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.util.Size2D size2D27 = blockContainer18.arrange(graphics2D26);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor30 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D31 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D27, (double) '#', (double) 1.0f, rectangleAnchor30);
        plotRenderingInfo9.setPlotArea(rectangle2D31);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = org.jfree.chart.util.RectangleEdge.TOP;
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge33);
        double double35 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D31, rectangleEdge34);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNotNull(size2D27);
        org.junit.Assert.assertNotNull(rectangleAnchor30);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertNotNull(rectangleEdge34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 19.0d + "'", double35 == 19.0d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues0.removeValue((java.lang.Comparable) "EXPAND");
        org.jfree.chart.util.SortOrder sortOrder3 = org.jfree.chart.util.SortOrder.DESCENDING;
        defaultKeyedValues0.sortByKeys(sortOrder3);
        org.junit.Assert.assertNotNull(sortOrder3);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, true);
        java.lang.Comparable comparable3 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, comparable3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDepthFactor((double) (byte) 1);
        piePlot3D1.setDepthFactor(0.0d);
        piePlot3D1.setInteriorGap((double) 0.0f);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator8 = piePlot3D1.getURLGenerator();
        piePlot3D1.setOutlineVisible(false);
        org.junit.Assert.assertNull(pieURLGenerator8);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis2.setInverted(true);
        boolean boolean5 = numberAxis2.isAxisLineVisible();
        boolean boolean6 = numberAxis2.getAutoRangeStickyZero();
        java.awt.Stroke stroke7 = numberAxis2.getAxisLineStroke();
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis2);
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot0.getRangeAxisLocation(0);
        categoryPlot0.setRangeGridlinesVisible(false);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer15 = null;
        org.jfree.chart.plot.PolarPlot polarPlot16 = new org.jfree.chart.plot.PolarPlot(xYDataset13, valueAxis14, polarItemRenderer15);
        polarPlot16.removeCornerTextItem("hi!");
        org.jfree.chart.plot.PlotOrientation plotOrientation19 = polarPlot16.getOrientation();
        categoryPlot0.setOrientation(plotOrientation19);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(plotOrientation19);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.util.List list3 = defaultBoxAndWhiskerCategoryDataset0.getOutliers((java.lang.Comparable) (-2208927600000L), (java.lang.Comparable) (byte) 100);
        try {
            org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem6 = defaultBoxAndWhiskerCategoryDataset0.getItem(2958465, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2958465, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(list3);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer1 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean2 = statisticalLineAndShapeRenderer1.getDrawOutlines();
        statisticalLineAndShapeRenderer1.setAutoPopulateSeriesFillPaint(false);
        java.awt.Stroke stroke6 = statisticalLineAndShapeRenderer1.lookupSeriesStroke(28);
        lineAndShapeRenderer0.setBaseStroke(stroke6);
        java.awt.Paint paint9 = lineAndShapeRenderer0.getSeriesFillPaint((int) '#');
        java.awt.Stroke stroke12 = lineAndShapeRenderer0.getItemOutlineStroke(1, 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = lineAndShapeRenderer0.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        boolean boolean15 = lineAndShapeRenderer0.getBaseSeriesVisibleInLegend();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        org.jfree.data.gantt.Task task4 = new org.jfree.data.gantt.Task("", (org.jfree.data.time.TimePeriod) year3);
        java.awt.Font font6 = null;
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.jfree.chart.text.TextMeasurer textMeasurer9 = null;
        org.jfree.chart.text.TextBlock textBlock10 = org.jfree.chart.text.TextUtilities.createTextBlock("", font6, (java.awt.Paint) color7, (float) ' ', textMeasurer9);
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D12 = new org.jfree.chart.plot.PiePlot3D(pieDataset11);
        piePlot3D12.setDepthFactor((double) (byte) 1);
        piePlot3D12.setDepthFactor(0.0d);
        java.awt.Stroke stroke17 = piePlot3D12.getLabelLinkStroke();
        boolean boolean18 = textBlock10.equals((java.lang.Object) stroke17);
        int int19 = year3.compareTo((java.lang.Object) stroke17);
        ringPlot1.setLabelOutlineStroke(stroke17);
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.block.BlockContainer blockContainer22 = new org.jfree.chart.block.BlockContainer();
        blockContainer22.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer28 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder33 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer28.setFrame((org.jfree.chart.block.BlockFrame) blockBorder33);
        blockContainer22.add((org.jfree.chart.block.Block) blockContainer28);
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.chart.util.Size2D size2D37 = blockContainer28.arrange(graphics2D36);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor40 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D41 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D37, (double) '#', (double) 1.0f, rectangleAnchor40);
        org.jfree.data.general.PieDataset pieDataset42 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D43 = new org.jfree.chart.plot.PiePlot3D(pieDataset42);
        piePlot3D43.setDepthFactor((double) (byte) 1);
        piePlot3D43.setDepthFactor(0.0d);
        java.awt.Stroke stroke48 = piePlot3D43.getLabelLinkStroke();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset50 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range51 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset50);
        org.jfree.data.xy.XYDataset xYDataset52 = null;
        org.jfree.chart.axis.ValueAxis valueAxis53 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer54 = null;
        org.jfree.chart.plot.PolarPlot polarPlot55 = new org.jfree.chart.plot.PolarPlot(xYDataset52, valueAxis53, polarItemRenderer54);
        defaultCategoryDataset50.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot55);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo58 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo59 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo58);
        java.awt.geom.Point2D point2D60 = null;
        polarPlot55.zoomDomainAxes((double) '#', plotRenderingInfo59, point2D60);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo62 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo63 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo62);
        plotRenderingInfo59.addSubplotInfo(plotRenderingInfo63);
        try {
            org.jfree.chart.plot.PiePlotState piePlotState65 = ringPlot1.initialise(graphics2D21, rectangle2D41, (org.jfree.chart.plot.PiePlot) piePlot3D43, (java.lang.Integer) 2019, plotRenderingInfo63);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(textBlock10);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(size2D37);
        org.junit.Assert.assertNotNull(rectangleAnchor40);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNull(range51);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.geom.Point2D point2D1 = org.jfree.chart.util.SerialUtilities.readPoint2D(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean1 = statisticalLineAndShapeRenderer0.getDrawOutlines();
        statisticalLineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(false);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment4, verticalAlignment5, (double) 100L, 10.0d);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement13 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment9, verticalAlignment10, (double) 100L, 10.0d);
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalLineAndShapeRenderer0, (org.jfree.chart.block.Arrangement) columnArrangement8, (org.jfree.chart.block.Arrangement) columnArrangement13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset16 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset16);
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer20 = null;
        org.jfree.chart.plot.PolarPlot polarPlot21 = new org.jfree.chart.plot.PolarPlot(xYDataset18, valueAxis19, polarItemRenderer20);
        defaultCategoryDataset16.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot21);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo24 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo24);
        java.awt.geom.Point2D point2D26 = null;
        polarPlot21.zoomDomainAxes((double) '#', plotRenderingInfo25, point2D26);
        org.jfree.chart.block.BlockContainer blockContainer28 = new org.jfree.chart.block.BlockContainer();
        blockContainer28.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer34 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder39 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer34.setFrame((org.jfree.chart.block.BlockFrame) blockBorder39);
        blockContainer28.add((org.jfree.chart.block.Block) blockContainer34);
        java.awt.Graphics2D graphics2D42 = null;
        org.jfree.chart.util.Size2D size2D43 = blockContainer34.arrange(graphics2D42);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor46 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D47 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D43, (double) '#', (double) 1.0f, rectangleAnchor46);
        plotRenderingInfo25.setPlotArea(rectangle2D47);
        java.awt.Stroke stroke49 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        try {
            java.lang.Object obj50 = legendTitle14.draw(graphics2D15, rectangle2D47, (java.lang.Object) stroke49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNotNull(size2D43);
        org.junit.Assert.assertNotNull(rectangleAnchor46);
        org.junit.Assert.assertNotNull(rectangle2D47);
        org.junit.Assert.assertNotNull(stroke49);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        int int0 = org.jfree.data.time.SerialDate.FOLLOWING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.DAY_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 86400000L + "'", long0 == 86400000L);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder11 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer6.setFrame((org.jfree.chart.block.BlockFrame) blockBorder11);
        blockContainer0.add((org.jfree.chart.block.Block) blockContainer6);
        double double14 = blockContainer0.getContentXOffset();
        blockContainer0.setWidth((double) '4');
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(1.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = stackedBarRenderer3D2.getGradientPaintTransformer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = stackedBarRenderer3D2.getBaseItemLabelGenerator();
        stackedBarRenderer3D2.setBaseSeriesVisible(false);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D(pieDataset7);
        piePlot3D8.setDepthFactor((double) (byte) 1);
        piePlot3D8.setCircular(true, true);
        boolean boolean14 = stackedBarRenderer3D2.equals((java.lang.Object) true);
        org.jfree.chart.LegendItem legendItem17 = stackedBarRenderer3D2.getLegendItem((int) '4', (int) (short) 0);
        boolean boolean18 = stackedBarRenderer3D2.getRenderAsPercentages();
        org.junit.Assert.assertNotNull(gradientPaintTransformer3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(legendItem17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.Range range3 = numberAxis2.getDefaultAutoRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint(range3, (double) (-1L));
        org.jfree.data.Range range6 = org.jfree.data.Range.combine(range0, range3);
        org.jfree.data.Range range7 = null;
        org.jfree.data.Range range8 = org.jfree.data.Range.combine(range6, range7);
        double double9 = range6.getLowerBound();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis2.setInverted(true);
        boolean boolean5 = numberAxis2.isAxisLineVisible();
        boolean boolean6 = numberAxis2.getAutoRangeStickyZero();
        java.awt.Stroke stroke7 = numberAxis2.getAxisLineStroke();
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis2);
        numberAxis2.zoomRange((double) 1L, 90.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        int int2 = xYPlot0.indexOf(xYDataset1);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation3 = null;
        try {
            boolean boolean4 = xYPlot0.removeAnnotation(xYAnnotation3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDepthFactor((double) (byte) 1);
        piePlot3D1.setDepthFactor(0.0d);
        java.awt.Stroke stroke6 = piePlot3D1.getLabelLinkStroke();
        double double7 = piePlot3D1.getShadowXOffset();
        java.lang.String str8 = piePlot3D1.getNoDataMessage();
        java.awt.Paint paint9 = piePlot3D1.getBaseSectionOutlinePaint();
        org.jfree.data.general.PieDataset pieDataset10 = null;
        piePlot3D1.setDataset(pieDataset10);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator12 = null;
        piePlot3D1.setLegendLabelURLGenerator(pieURLGenerator12);
        java.awt.Stroke stroke14 = null;
        try {
            piePlot3D1.setBaseSectionOutlineStroke(stroke14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = null;
        try {
            org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("{0}", font1, paint2, (float) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("");
        boolean boolean3 = taskSeries1.equals((java.lang.Object) 1L);
        org.jfree.data.gantt.Task task4 = null;
        taskSeries1.remove(task4);
        java.lang.Object obj6 = taskSeries1.clone();
        try {
            org.jfree.data.gantt.Task task8 = taskSeries1.get(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer1 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean2 = statisticalLineAndShapeRenderer1.getDrawOutlines();
        statisticalLineAndShapeRenderer1.setAutoPopulateSeriesFillPaint(false);
        java.awt.Stroke stroke6 = statisticalLineAndShapeRenderer1.lookupSeriesStroke(28);
        lineAndShapeRenderer0.setBaseStroke(stroke6);
        lineAndShapeRenderer0.setSeriesItemLabelsVisible(28, (java.lang.Boolean) true);
        lineAndShapeRenderer0.setSeriesVisible(0, (java.lang.Boolean) true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = null;
        statisticalLineAndShapeRenderer0.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator2, true);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer5 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean6 = statisticalLineAndShapeRenderer5.getDrawOutlines();
        statisticalLineAndShapeRenderer5.setAutoPopulateSeriesFillPaint(false);
        java.awt.Stroke stroke10 = statisticalLineAndShapeRenderer5.lookupSeriesStroke(28);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = statisticalLineAndShapeRenderer5.getBaseNegativeItemLabelPosition();
        statisticalLineAndShapeRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition11);
        java.awt.Paint paint14 = statisticalLineAndShapeRenderer0.getSeriesPaint(4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
        org.junit.Assert.assertNull(paint14);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long2 = segmentedTimeline0.toMillisecond((long) 'a');
        segmentedTimeline0.setStartTime((-1L));
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2208927599903L) + "'", long2 == (-2208927599903L));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("{0}", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.clear();
        boolean boolean2 = blockContainer0.isEmpty();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean1 = statisticalLineAndShapeRenderer0.getDrawOutlines();
        statisticalLineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(false);
        java.lang.Object obj4 = statisticalLineAndShapeRenderer0.clone();
        java.awt.Stroke stroke5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        statisticalLineAndShapeRenderer0.setBaseStroke(stroke5);
        java.lang.Boolean boolean8 = statisticalLineAndShapeRenderer0.getSeriesShapesVisible((int) (byte) -1);
        statisticalLineAndShapeRenderer0.setAutoPopulateSeriesStroke(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(boolean8);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("");
        taskSeries1.fireSeriesChanged();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        taskSeries1.removeChangeListener(seriesChangeListener3);
        taskSeries1.removeAll();
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDepthFactor((double) (byte) 1);
        piePlot3D1.setDepthFactor(0.0d);
        java.awt.Stroke stroke6 = piePlot3D1.getLabelLinkStroke();
        double double7 = piePlot3D1.getShadowXOffset();
        java.awt.Paint paint8 = piePlot3D1.getLabelLinkPaint();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        org.jfree.chart.ui.Library[] libraryArray1 = projectInfo0.getOptionalLibraries();
        java.util.List list2 = projectInfo0.getContributors();
        java.lang.String str3 = projectInfo0.toString();
        org.junit.Assert.assertNotNull(libraryArray1);
        org.junit.Assert.assertNull(list2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull" + "'", str3.equals("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDepthFactor((double) (byte) 1);
        piePlot3D1.setDepthFactor(0.0d);
        java.awt.Stroke[] strokeArray6 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        boolean boolean7 = piePlot3D1.equals((java.lang.Object) strokeArray6);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator8 = null;
        piePlot3D1.setLegendLabelURLGenerator(pieURLGenerator8);
        java.awt.Paint paint10 = piePlot3D1.getLabelOutlinePaint();
        piePlot3D1.setLabelLinksVisible(false);
        org.junit.Assert.assertNotNull(strokeArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font4 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer5 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer5.setDrawOutlines(true);
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer5.setBasePaint((java.awt.Paint) color8, false);
        org.jfree.chart.text.TextMeasurer textMeasurer12 = null;
        org.jfree.chart.text.TextBlock textBlock13 = org.jfree.chart.text.TextUtilities.createTextBlock("", font4, (java.awt.Paint) color8, (float) (byte) -1, textMeasurer12);
        numberAxis2.setTickMarkPaint((java.awt.Paint) color8);
        boolean boolean15 = numberAxis2.isInverted();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer16 = null;
        org.jfree.chart.plot.PolarPlot polarPlot17 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, polarItemRenderer16);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent18 = null;
        polarPlot17.datasetChanged(datasetChangeEvent18);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(textBlock13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean1 = statisticalLineAndShapeRenderer0.getDrawOutlines();
        statisticalLineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(false);
        java.awt.Stroke stroke5 = statisticalLineAndShapeRenderer0.lookupSeriesStroke(28);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = statisticalLineAndShapeRenderer0.getBaseNegativeItemLabelPosition();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D(pieDataset7);
        piePlot3D8.setDepthFactor((double) (byte) 1);
        piePlot3D8.setDepthFactor(0.0d);
        java.awt.Stroke stroke13 = piePlot3D8.getLabelLinkStroke();
        double double14 = piePlot3D8.getShadowXOffset();
        java.lang.String str15 = piePlot3D8.getNoDataMessage();
        java.awt.Paint paint16 = piePlot3D8.getBaseSectionOutlinePaint();
        org.jfree.data.general.PieDataset pieDataset17 = null;
        piePlot3D8.setDataset(pieDataset17);
        java.awt.Stroke stroke19 = piePlot3D8.getBaseSectionOutlineStroke();
        statisticalLineAndShapeRenderer0.setBaseStroke(stroke19, true);
        java.awt.Shape shape23 = statisticalLineAndShapeRenderer0.getSeriesShape((int) (short) 0);
        java.awt.Paint paint26 = statisticalLineAndShapeRenderer0.getItemFillPaint(2, 2958465);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(shape23);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset2, valueAxis3, polarItemRenderer4);
        defaultCategoryDataset0.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot5);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo8);
        java.awt.geom.Point2D point2D10 = null;
        polarPlot5.zoomDomainAxes((double) '#', plotRenderingInfo9, point2D10);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo12 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo12);
        plotRenderingInfo9.addSubplotInfo(plotRenderingInfo13);
        try {
            org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = plotRenderingInfo9.getSubplotInfo((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range1);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.FIRST_MONDAY_AFTER_1900;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + (-2208960000000L) + "'", long0 == (-2208960000000L));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer1 = new org.jfree.chart.renderer.category.StackedBarRenderer(true);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer1 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer1.setDrawOutlines(true);
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer1.setBasePaint((java.awt.Paint) color4, false);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot(xYDataset8, valueAxis9, polarItemRenderer10);
        java.lang.Object obj12 = null;
        boolean boolean13 = polarPlot11.equals(obj12);
        int int14 = polarPlot11.getSeriesCount();
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        polarPlot11.setAngleLabelPaint((java.awt.Paint) color15);
        statisticalLineAndShapeRenderer1.setSeriesFillPaint(2, (java.awt.Paint) color15);
        java.awt.Stroke stroke20 = statisticalLineAndShapeRenderer1.getItemStroke(0, 10);
        java.lang.Boolean boolean22 = statisticalLineAndShapeRenderer1.getSeriesCreateEntities((int) (short) -1);
        java.awt.Font font23 = statisticalLineAndShapeRenderer1.getBaseItemLabelFont();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D26 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(1.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer27 = stackedBarRenderer3D26.getGradientPaintTransformer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator28 = stackedBarRenderer3D26.getBaseItemLabelGenerator();
        java.awt.Paint paint30 = stackedBarRenderer3D26.lookupSeriesOutlinePaint(1);
        org.jfree.chart.text.TextMeasurer textMeasurer32 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock33 = org.jfree.chart.text.TextUtilities.createTextBlock("({0}, {1}) = {3} - {4}", font23, paint30, (float) 1L, textMeasurer32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNull(boolean22);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(gradientPaintTransformer27);
        org.junit.Assert.assertNull(categoryItemLabelGenerator28);
        org.junit.Assert.assertNotNull(paint30);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long1 = segmentedTimeline0.getStartTime();
        int int2 = segmentedTimeline0.getSegmentsIncluded();
        boolean boolean5 = segmentedTimeline0.containsDomainRange(10L, (long) '#');
        segmentedTimeline0.addException((long) ' ', (-2208927599903L));
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-2208927600000L) + "'", long1 == (-2208927600000L));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28 + "'", int2 == 28);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(1.0d, (double) (short) -1);
        boolean boolean3 = stackedBarRenderer3D2.isDrawBarOutline();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer4 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        stackedBarRenderer3D2.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis9.setInverted(true);
        boolean boolean12 = numberAxis9.isAxisLineVisible();
        boolean boolean13 = numberAxis9.getAutoRangeStickyZero();
        java.awt.Stroke stroke14 = numberAxis9.getAxisLineStroke();
        categoryPlot7.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis9);
        org.jfree.chart.axis.AxisLocation axisLocation17 = categoryPlot7.getRangeAxisLocation(0);
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        try {
            stackedBarRenderer3D2.drawBackground(graphics2D6, categoryPlot7, rectangle2D18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(axisLocation17);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double1 = rectangleInsets0.getLeft();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(4, 0);
        int int3 = month2.getMonth();
        int int4 = month2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month2.next();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = month2.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        java.lang.Object obj4 = null;
        boolean boolean5 = polarPlot3.equals(obj4);
        int int6 = polarPlot3.getSeriesCount();
        boolean boolean7 = polarPlot3.isRangeZoomable();
        java.awt.Font font9 = null;
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.jfree.chart.text.TextMeasurer textMeasurer12 = null;
        org.jfree.chart.text.TextBlock textBlock13 = org.jfree.chart.text.TextUtilities.createTextBlock("", font9, (java.awt.Paint) color10, (float) ' ', textMeasurer12);
        polarPlot3.setNoDataMessagePaint((java.awt.Paint) color10);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(textBlock13);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(1.0d, (double) (short) -1);
        boolean boolean3 = stackedBarRenderer3D2.isDrawBarOutline();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer4 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        stackedBarRenderer3D2.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer4);
        java.awt.GradientPaint gradientPaint6 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer7 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean8 = statisticalLineAndShapeRenderer7.getDrawOutlines();
        statisticalLineAndShapeRenderer7.setAutoPopulateSeriesFillPaint(false);
        java.lang.Object obj11 = statisticalLineAndShapeRenderer7.clone();
        java.awt.Stroke stroke12 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        statisticalLineAndShapeRenderer7.setBaseStroke(stroke12);
        statisticalLineAndShapeRenderer7.setBaseItemLabelsVisible(false, false);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        statisticalLineAndShapeRenderer7.setBaseFillPaint((java.awt.Paint) color17);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = null;
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font24 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer25 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer25.setDrawOutlines(true);
        java.awt.Color color28 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer25.setBasePaint((java.awt.Paint) color28, false);
        org.jfree.chart.text.TextMeasurer textMeasurer32 = null;
        org.jfree.chart.text.TextBlock textBlock33 = org.jfree.chart.text.TextUtilities.createTextBlock("", font24, (java.awt.Paint) color28, (float) (byte) -1, textMeasurer32);
        numberAxis22.setTickMarkPaint((java.awt.Paint) color28);
        org.jfree.chart.plot.Marker marker35 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset36 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range37 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset36);
        org.jfree.data.xy.XYDataset xYDataset38 = null;
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer40 = null;
        org.jfree.chart.plot.PolarPlot polarPlot41 = new org.jfree.chart.plot.PolarPlot(xYDataset38, valueAxis39, polarItemRenderer40);
        defaultCategoryDataset36.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot41);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo44 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo45 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo44);
        java.awt.geom.Point2D point2D46 = null;
        polarPlot41.zoomDomainAxes((double) '#', plotRenderingInfo45, point2D46);
        org.jfree.chart.block.BlockContainer blockContainer48 = new org.jfree.chart.block.BlockContainer();
        blockContainer48.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer54 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder59 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer54.setFrame((org.jfree.chart.block.BlockFrame) blockBorder59);
        blockContainer48.add((org.jfree.chart.block.Block) blockContainer54);
        java.awt.Graphics2D graphics2D62 = null;
        org.jfree.chart.util.Size2D size2D63 = blockContainer54.arrange(graphics2D62);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor66 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D67 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D63, (double) '#', (double) 1.0f, rectangleAnchor66);
        plotRenderingInfo45.setPlotArea(rectangle2D67);
        statisticalLineAndShapeRenderer7.drawRangeMarker(graphics2D19, categoryPlot20, (org.jfree.chart.axis.ValueAxis) numberAxis22, marker35, rectangle2D67);
        java.awt.Shape shape70 = numberAxis22.getUpArrow();
        try {
            java.awt.GradientPaint gradientPaint71 = standardGradientPaintTransformer4.transform(gradientPaint6, shape70);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(textBlock33);
        org.junit.Assert.assertNull(range37);
        org.junit.Assert.assertNotNull(size2D63);
        org.junit.Assert.assertNotNull(rectangleAnchor66);
        org.junit.Assert.assertNotNull(rectangle2D67);
        org.junit.Assert.assertNotNull(shape70);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor5 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        boolean boolean6 = blockBorder4.equals((java.lang.Object) itemLabelAnchor5);
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.jfree.chart.axis.AxisLocation axisLocation9 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        boolean boolean10 = textAnchor8.equals((java.lang.Object) axisLocation9);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor5, textAnchor7, textAnchor8, (double) 2);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor13 = itemLabelPosition12.getItemLabelAnchor();
        org.junit.Assert.assertNotNull(itemLabelAnchor5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor13);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = null;
        try {
            xYPlot0.setSeriesRenderingOrder(seriesRenderingOrder3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(rectangleEdge2);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDepthFactor((double) (byte) 1);
        piePlot3D1.setDepthFactor(0.0d);
        piePlot3D1.setInteriorGap((double) 0.0f);
        java.awt.Shape shape8 = piePlot3D1.getLegendItemShape();
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape8);
        chartEntity9.setToolTipText("#ffff40");
        chartEntity9.setURLText("UnitType.ABSOLUTE");
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.gantt.Task task2 = new org.jfree.data.gantt.Task("", (org.jfree.data.time.TimePeriod) year1);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year1.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, polarItemRenderer3);
        org.jfree.data.general.DatasetGroup datasetGroup5 = polarPlot4.getDatasetGroup();
        int int6 = polarPlot4.getSeriesCount();
        org.junit.Assert.assertNull(datasetGroup5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("");
        taskSeries1.fireSeriesChanged();
        org.jfree.data.gantt.Task task4 = taskSeries1.get("{0}");
        boolean boolean6 = taskSeries1.equals((java.lang.Object) 100);
        org.junit.Assert.assertNull(task4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor5 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        boolean boolean6 = blockBorder4.equals((java.lang.Object) itemLabelAnchor5);
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) numberAxis9, polarItemRenderer10);
        float float12 = polarPlot11.getBackgroundAlpha();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer13 = polarPlot11.getRenderer();
        java.awt.Paint paint14 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        polarPlot11.setBackgroundPaint(paint14);
        java.awt.Paint paint16 = polarPlot11.getRadiusGridlinePaint();
        boolean boolean17 = itemLabelAnchor5.equals((java.lang.Object) paint16);
        org.junit.Assert.assertNotNull(itemLabelAnchor5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 1.0f + "'", float12 == 1.0f);
        org.junit.Assert.assertNull(polarItemRenderer13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer1 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean2 = statisticalLineAndShapeRenderer1.getDrawOutlines();
        statisticalLineAndShapeRenderer1.setAutoPopulateSeriesFillPaint(false);
        java.awt.Stroke stroke6 = statisticalLineAndShapeRenderer1.lookupSeriesStroke(28);
        lineAndShapeRenderer0.setBaseStroke(stroke6);
        java.awt.Paint paint9 = lineAndShapeRenderer0.getSeriesFillPaint((int) '#');
        java.awt.Stroke stroke12 = lineAndShapeRenderer0.getItemOutlineStroke(1, 10);
        java.awt.Stroke stroke13 = null;
        try {
            lineAndShapeRenderer0.setBaseStroke(stroke13, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        int int2 = xYPlot0.indexOf(xYDataset1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = null;
        try {
            xYPlot0.setRangeAxisLocation((int) (short) 0, axisLocation4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("{0}");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean4 = statisticalLineAndShapeRenderer3.getDrawOutlines();
        statisticalLineAndShapeRenderer3.setAutoPopulateSeriesFillPaint(false);
        java.lang.Object obj7 = statisticalLineAndShapeRenderer3.clone();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        statisticalLineAndShapeRenderer3.setBaseStroke(stroke8);
        statisticalLineAndShapeRenderer3.setBaseItemLabelsVisible(false, false);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        statisticalLineAndShapeRenderer3.setBaseFillPaint((java.awt.Paint) color13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font20 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer21 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer21.setDrawOutlines(true);
        java.awt.Color color24 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer21.setBasePaint((java.awt.Paint) color24, false);
        org.jfree.chart.text.TextMeasurer textMeasurer28 = null;
        org.jfree.chart.text.TextBlock textBlock29 = org.jfree.chart.text.TextUtilities.createTextBlock("", font20, (java.awt.Paint) color24, (float) (byte) -1, textMeasurer28);
        numberAxis18.setTickMarkPaint((java.awt.Paint) color24);
        org.jfree.chart.plot.Marker marker31 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset32 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset32);
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer36 = null;
        org.jfree.chart.plot.PolarPlot polarPlot37 = new org.jfree.chart.plot.PolarPlot(xYDataset34, valueAxis35, polarItemRenderer36);
        defaultCategoryDataset32.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot37);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo40 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo40);
        java.awt.geom.Point2D point2D42 = null;
        polarPlot37.zoomDomainAxes((double) '#', plotRenderingInfo41, point2D42);
        org.jfree.chart.block.BlockContainer blockContainer44 = new org.jfree.chart.block.BlockContainer();
        blockContainer44.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer50 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder55 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer50.setFrame((org.jfree.chart.block.BlockFrame) blockBorder55);
        blockContainer44.add((org.jfree.chart.block.Block) blockContainer50);
        java.awt.Graphics2D graphics2D58 = null;
        org.jfree.chart.util.Size2D size2D59 = blockContainer50.arrange(graphics2D58);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor62 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D63 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D59, (double) '#', (double) 1.0f, rectangleAnchor62);
        plotRenderingInfo41.setPlotArea(rectangle2D63);
        statisticalLineAndShapeRenderer3.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker31, rectangle2D63);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity66 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D63);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer67 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer67.setDrawOutlines(true);
        java.awt.Color color70 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer67.setBasePaint((java.awt.Paint) color70, false);
        statisticalLineAndShapeRenderer67.setUseFillPaint(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent75 = null;
        statisticalLineAndShapeRenderer67.notifyListeners(rendererChangeEvent75);
        org.jfree.data.xy.XYDataset xYDataset77 = null;
        org.jfree.chart.axis.ValueAxis valueAxis78 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer79 = null;
        org.jfree.chart.plot.PolarPlot polarPlot80 = new org.jfree.chart.plot.PolarPlot(xYDataset77, valueAxis78, polarItemRenderer79);
        statisticalLineAndShapeRenderer67.addChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot80);
        try {
            java.lang.Object obj82 = labelBlock1.draw(graphics2D2, rectangle2D63, (java.lang.Object) polarPlot80);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(textBlock29);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertNotNull(size2D59);
        org.junit.Assert.assertNotNull(rectangleAnchor62);
        org.junit.Assert.assertNotNull(rectangle2D63);
        org.junit.Assert.assertNotNull(color70);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        int int0 = org.jfree.data.time.SerialDate.FOURTH_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType0 = org.jfree.chart.renderer.AreaRendererEndType.TRUNCATE;
        org.junit.Assert.assertNotNull(areaRendererEndType0);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        int int1 = color0.getTransparency();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer2.setDrawOutlines(true);
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer2.setBasePaint((java.awt.Paint) color5, false);
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer11 = null;
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot(xYDataset9, valueAxis10, polarItemRenderer11);
        java.lang.Object obj13 = null;
        boolean boolean14 = polarPlot12.equals(obj13);
        int int15 = polarPlot12.getSeriesCount();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        polarPlot12.setAngleLabelPaint((java.awt.Paint) color16);
        statisticalLineAndShapeRenderer2.setSeriesFillPaint(2, (java.awt.Paint) color16);
        float[] floatArray23 = new float[] { (short) 10, 0, 100, '#' };
        float[] floatArray24 = color16.getColorComponents(floatArray23);
        float[] floatArray25 = color0.getComponents(floatArray24);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer2 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(1.0d, (double) (short) -1);
        boolean boolean3 = stackedBarRenderer3D2.isDrawBarOutline();
        double double4 = stackedBarRenderer3D2.getYOffset();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset5 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range7 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset5, true);
        org.jfree.data.Range range8 = stackedBarRenderer3D2.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset5);
        java.lang.Comparable comparable11 = null;
        try {
            defaultCategoryDataset5.addValue((java.lang.Number) 0.35d, (java.lang.Comparable) 36.0d, comparable11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.0d) + "'", double4 == (-1.0d));
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(range8);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        statisticalLineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        java.lang.Boolean boolean8 = statisticalLineAndShapeRenderer0.getSeriesVisibleInLegend(0);
        org.junit.Assert.assertNull(boolean8);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer0.setDrawOutlines(true);
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer0.setBasePaint((java.awt.Paint) color3, false);
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset7, valueAxis8, polarItemRenderer9);
        java.lang.Object obj11 = null;
        boolean boolean12 = polarPlot10.equals(obj11);
        int int13 = polarPlot10.getSeriesCount();
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        polarPlot10.setAngleLabelPaint((java.awt.Paint) color14);
        statisticalLineAndShapeRenderer0.setSeriesFillPaint(2, (java.awt.Paint) color14);
        java.awt.Stroke stroke19 = statisticalLineAndShapeRenderer0.getItemStroke(0, 10);
        java.lang.Boolean boolean21 = statisticalLineAndShapeRenderer0.getSeriesShapesVisible(8);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(boolean21);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.chart.block.Arrangement arrangement0 = null;
        try {
            org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer(arrangement0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font3 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer4 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer4.setDrawOutlines(true);
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer4.setBasePaint((java.awt.Paint) color7, false);
        org.jfree.chart.text.TextMeasurer textMeasurer11 = null;
        org.jfree.chart.text.TextBlock textBlock12 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, (java.awt.Paint) color7, (float) (byte) -1, textMeasurer11);
        numberAxis1.setTickMarkPaint((java.awt.Paint) color7);
        numberAxis1.setAutoRange(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double18 = rectangleInsets16.calculateBottomOutset((double) 'a');
        double double19 = rectangleInsets16.getRight();
        numberAxis1.setTickLabelInsets(rectangleInsets16);
        float float21 = numberAxis1.getTickMarkOutsideLength();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(textBlock12);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 2.0f + "'", float21 == 2.0f);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = null;
        statisticalLineAndShapeRenderer0.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator2, true);
        statisticalLineAndShapeRenderer0.setSeriesVisibleInLegend(0, (java.lang.Boolean) true, true);
        java.lang.Boolean boolean10 = statisticalLineAndShapeRenderer0.getSeriesVisibleInLegend(100);
        java.awt.Shape shape13 = statisticalLineAndShapeRenderer0.getItemShape((int) (short) 100, (int) (byte) -1);
        statisticalLineAndShapeRenderer0.setSeriesShapesVisible(2958465, (java.lang.Boolean) true);
        org.junit.Assert.assertNull(boolean10);
        org.junit.Assert.assertNotNull(shape13);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDepthFactor((double) (byte) 1);
        piePlot3D1.setDepthFactor(0.0d);
        java.awt.Stroke stroke6 = piePlot3D1.getLabelLinkStroke();
        double double7 = piePlot3D1.getShadowXOffset();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        int int9 = color8.getTransparency();
        piePlot3D1.setLabelLinkPaint((java.awt.Paint) color8);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor11 = piePlot3D1.getLabelDistributor();
        org.jfree.chart.plot.Plot plot12 = piePlot3D1.getParent();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor11);
        org.junit.Assert.assertNull(plot12);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis2.setInverted(true);
        boolean boolean5 = numberAxis2.isAxisLineVisible();
        boolean boolean6 = numberAxis2.getAutoRangeStickyZero();
        java.awt.Stroke stroke7 = numberAxis2.getAxisLineStroke();
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis2);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot0.getDomainAxisForDataset((int) ' ');
        org.jfree.chart.LegendItemCollection legendItemCollection11 = categoryPlot0.getFixedLegendItems();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertNull(legendItemCollection11);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, polarItemRenderer3);
        org.jfree.data.general.DatasetGroup datasetGroup5 = polarPlot4.getDatasetGroup();
        boolean boolean6 = polarPlot4.isRadiusGridlinesVisible();
        org.junit.Assert.assertNull(datasetGroup5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(2, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(1.0d, (double) (short) -1);
        boolean boolean3 = stackedBarRenderer3D2.isDrawBarOutline();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = stackedBarRenderer3D2.getBaseURLGenerator();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis8.setInverted(true);
        boolean boolean11 = numberAxis8.isAxisLineVisible();
        boolean boolean12 = numberAxis8.getAutoRangeStickyZero();
        java.awt.Stroke stroke13 = numberAxis8.getAxisLineStroke();
        categoryPlot6.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis8);
        org.jfree.chart.axis.AxisLocation axisLocation16 = categoryPlot6.getRangeAxisLocation(0);
        categoryPlot6.clearDomainAxes();
        org.jfree.data.general.PieDataset pieDataset18 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D19 = new org.jfree.chart.plot.PiePlot3D(pieDataset18);
        piePlot3D19.setDepthFactor((double) (byte) 1);
        piePlot3D19.setDepthFactor(0.0d);
        java.awt.Stroke stroke24 = piePlot3D19.getLabelLinkStroke();
        double double25 = piePlot3D19.getShadowXOffset();
        java.lang.String str26 = piePlot3D19.getNoDataMessage();
        java.awt.Paint paint27 = piePlot3D19.getBaseSectionOutlinePaint();
        java.awt.Paint paint29 = piePlot3D19.getSectionOutlinePaint((java.lang.Comparable) 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font33 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer34 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer34.setDrawOutlines(true);
        java.awt.Color color37 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer34.setBasePaint((java.awt.Paint) color37, false);
        org.jfree.chart.text.TextMeasurer textMeasurer41 = null;
        org.jfree.chart.text.TextBlock textBlock42 = org.jfree.chart.text.TextUtilities.createTextBlock("", font33, (java.awt.Paint) color37, (float) (byte) -1, textMeasurer41);
        numberAxis31.setTickMarkPaint((java.awt.Paint) color37);
        piePlot3D19.setLabelShadowPaint((java.awt.Paint) color37);
        org.jfree.chart.block.BlockContainer blockContainer45 = new org.jfree.chart.block.BlockContainer();
        blockContainer45.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer51 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder56 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer51.setFrame((org.jfree.chart.block.BlockFrame) blockBorder56);
        blockContainer45.add((org.jfree.chart.block.Block) blockContainer51);
        java.awt.Graphics2D graphics2D59 = null;
        org.jfree.chart.util.Size2D size2D60 = blockContainer51.arrange(graphics2D59);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor63 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D64 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D60, (double) '#', (double) 1.0f, rectangleAnchor63);
        boolean boolean65 = piePlot3D19.equals((java.lang.Object) rectangle2D64);
        try {
            stackedBarRenderer3D2.drawBackground(graphics2D5, categoryPlot6, rectangle2D64);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 4.0d + "'", double25 == 4.0d);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNull(paint29);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(textBlock42);
        org.junit.Assert.assertNotNull(size2D60);
        org.junit.Assert.assertNotNull(rectangleAnchor63);
        org.junit.Assert.assertNotNull(rectangle2D64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(1.0d, (double) (short) -1);
        boolean boolean3 = stackedBarRenderer3D2.isDrawBarOutline();
        double double4 = stackedBarRenderer3D2.getYOffset();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset5 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range7 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset5, true);
        org.jfree.data.Range range8 = stackedBarRenderer3D2.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset5);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis13.setInverted(true);
        boolean boolean16 = numberAxis13.isAxisLineVisible();
        boolean boolean17 = numberAxis13.getAutoRangeStickyZero();
        java.awt.Stroke stroke18 = numberAxis13.getAxisLineStroke();
        categoryPlot11.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis13);
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot11.setRangeCrosshairStroke(stroke20);
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font27 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer28 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer28.setDrawOutlines(true);
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer28.setBasePaint((java.awt.Paint) color31, false);
        org.jfree.chart.text.TextMeasurer textMeasurer35 = null;
        org.jfree.chart.text.TextBlock textBlock36 = org.jfree.chart.text.TextUtilities.createTextBlock("", font27, (java.awt.Paint) color31, (float) (byte) -1, textMeasurer35);
        numberAxis25.setTickMarkPaint((java.awt.Paint) color31);
        boolean boolean38 = numberAxis25.isInverted();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer39 = null;
        org.jfree.chart.plot.PolarPlot polarPlot40 = new org.jfree.chart.plot.PolarPlot(xYDataset23, (org.jfree.chart.axis.ValueAxis) numberAxis25, polarItemRenderer39);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo43 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo43);
        java.awt.geom.Point2D point2D45 = null;
        polarPlot40.zoomDomainAxes(1.0E-5d, (double) 10, plotRenderingInfo44, point2D45);
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState47 = stackedBarRenderer3D2.initialise(graphics2D9, rectangle2D10, categoryPlot11, 0, plotRenderingInfo44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.0d) + "'", double4 == (-1.0d));
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(textBlock36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.junit.Assert.assertNotNull(plotOrientation0);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        java.awt.geom.Line2D line2D0 = null;
        java.awt.geom.Line2D line2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(line2D0, line2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.gantt.Task task2 = new org.jfree.data.gantt.Task("", (org.jfree.data.time.TimePeriod) year1);
        java.lang.String str3 = task2.getDescription();
        try {
            org.jfree.data.gantt.Task task5 = task2.getSubtask(28);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 28, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset2, valueAxis3, polarItemRenderer4);
        defaultCategoryDataset0.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot5);
        int int7 = defaultCategoryDataset0.getColumnCount();
        defaultCategoryDataset0.removeValue((java.lang.Comparable) (byte) 10, (java.lang.Comparable) 4);
        try {
            java.lang.Comparable comparable12 = defaultCategoryDataset0.getRowKey(2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2019, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer0.setDrawOutlines(true);
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer0.setBasePaint((java.awt.Paint) color3, false);
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset7, valueAxis8, polarItemRenderer9);
        java.lang.Object obj11 = null;
        boolean boolean12 = polarPlot10.equals(obj11);
        int int13 = polarPlot10.getSeriesCount();
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        polarPlot10.setAngleLabelPaint((java.awt.Paint) color14);
        statisticalLineAndShapeRenderer0.setSeriesFillPaint(2, (java.awt.Paint) color14);
        java.awt.Stroke stroke19 = statisticalLineAndShapeRenderer0.getItemStroke(0, 10);
        java.lang.Boolean boolean21 = statisticalLineAndShapeRenderer0.getSeriesCreateEntities((int) (short) -1);
        java.awt.Paint paint23 = statisticalLineAndShapeRenderer0.getSeriesPaint(1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(boolean21);
        org.junit.Assert.assertNull(paint23);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        int int1 = defaultKeyedValues2D0.getColumnCount();
        try {
            java.lang.Number number4 = defaultKeyedValues2D0.getValue((java.lang.Comparable) (byte) 10, (java.lang.Comparable) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: 100");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer0.setDrawOutlines(true);
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer0.setBasePaint((java.awt.Paint) color3, false);
        statisticalLineAndShapeRenderer0.setUseFillPaint(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = null;
        statisticalLineAndShapeRenderer0.notifyListeners(rendererChangeEvent8);
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer12 = null;
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot(xYDataset10, valueAxis11, polarItemRenderer12);
        statisticalLineAndShapeRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot13);
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D16 = new org.jfree.chart.plot.PiePlot3D(pieDataset15);
        piePlot3D16.setDepthFactor((double) (byte) 1);
        piePlot3D16.setDepthFactor(0.0d);
        java.awt.Stroke stroke21 = piePlot3D16.getLabelLinkStroke();
        double double22 = piePlot3D16.getShadowXOffset();
        java.lang.String str23 = piePlot3D16.getNoDataMessage();
        java.awt.Paint paint24 = piePlot3D16.getBaseSectionOutlinePaint();
        boolean boolean25 = polarPlot13.equals((java.lang.Object) piePlot3D16);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 4.0d + "'", double22 == 4.0d);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.Range range3 = numberAxis2.getDefaultAutoRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint(range3, (double) (-1L));
        org.jfree.data.Range range6 = org.jfree.data.Range.combine(range0, range3);
        boolean boolean9 = range3.intersects((double) (byte) -1, (double) (short) 100);
        java.lang.String str10 = range3.toString();
        java.lang.String str11 = range3.toString();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Range[0.0,1.0]" + "'", str10.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Range[0.0,1.0]" + "'", str11.equals("Range[0.0,1.0]"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues0.removeValue((java.lang.Comparable) "EXPAND");
        java.awt.Font font4 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer5 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer5.setDrawOutlines(true);
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer5.setBasePaint((java.awt.Paint) color8, false);
        org.jfree.chart.text.TextMeasurer textMeasurer12 = null;
        org.jfree.chart.text.TextBlock textBlock13 = org.jfree.chart.text.TextUtilities.createTextBlock("", font4, (java.awt.Paint) color8, (float) (byte) -1, textMeasurer12);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor17 = null;
        java.awt.Shape shape21 = textBlock13.calculateBounds(graphics2D14, (float) 1, 100.0f, textBlockAnchor17, (float) 3, (float) (short) -1, (double) 0);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset24 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range25 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset24);
        org.jfree.data.Range range26 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset24);
        java.lang.Comparable comparable27 = null;
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity29 = new org.jfree.chart.entity.CategoryItemEntity(shape21, "{0}", "EXPAND", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset24, comparable27, (java.lang.Comparable) 1.0d);
        org.jfree.chart.util.SortOrder sortOrder30 = org.jfree.chart.util.SortOrder.DESCENDING;
        boolean boolean31 = categoryItemEntity29.equals((java.lang.Object) sortOrder30);
        defaultKeyedValues0.sortByValues(sortOrder30);
        defaultKeyedValues0.clear();
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
        try {
            defaultKeyedValues0.insertValue((int) (short) -1, (java.lang.Comparable) month35, 1.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 'position' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(textBlock13);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertNull(range26);
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer0.setDrawOutlines(true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = null;
        statisticalLineAndShapeRenderer0.setSeriesItemLabelGenerator(2958465, categoryItemLabelGenerator4);
        boolean boolean6 = statisticalLineAndShapeRenderer0.getDrawOutlines();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        java.awt.Font font1 = null;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis4, polarItemRenderer5);
        float float7 = polarPlot6.getBackgroundAlpha();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer8 = polarPlot6.getRenderer();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font1, (org.jfree.chart.plot.Plot) polarPlot6, false);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent11 = null;
        try {
            jFreeChart10.titleChanged(titleChangeEvent11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertNull(polarItemRenderer8);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.util.List list3 = defaultBoxAndWhiskerCategoryDataset0.getOutliers((java.lang.Comparable) (-2208927600000L), (java.lang.Comparable) (byte) 100);
        try {
            java.lang.Comparable comparable5 = defaultBoxAndWhiskerCategoryDataset0.getRowKey(6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(list3);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("{0}");
        labelBlock1.setToolTipText("poly");
        java.lang.Object obj4 = labelBlock1.clone();
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean3 = statisticalLineAndShapeRenderer2.getDrawOutlines();
        statisticalLineAndShapeRenderer2.setAutoPopulateSeriesFillPaint(false);
        java.lang.Object obj6 = statisticalLineAndShapeRenderer2.clone();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        statisticalLineAndShapeRenderer2.setBaseStroke(stroke7);
        statisticalLineAndShapeRenderer2.setBaseItemLabelsVisible(false, false);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        statisticalLineAndShapeRenderer2.setBaseFillPaint((java.awt.Paint) color12);
        org.jfree.chart.text.TextMeasurer textMeasurer15 = null;
        org.jfree.chart.text.TextBlock textBlock16 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color12, (float) (-2208927599903L), textMeasurer15);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(textBlock16);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        java.awt.Color color0 = java.awt.Color.green;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setInverted(true);
        boolean boolean4 = numberAxis1.isAxisLineVisible();
        boolean boolean5 = numberAxis1.getAutoRangeStickyZero();
        java.text.NumberFormat numberFormat6 = null;
        numberAxis1.setNumberFormatOverride(numberFormat6);
        double double8 = numberAxis1.getFixedDimension();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDepthFactor((double) (byte) 1);
        piePlot3D1.setDepthFactor(0.0d);
        java.awt.Stroke[] strokeArray6 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        boolean boolean7 = piePlot3D1.equals((java.lang.Object) strokeArray6);
        piePlot3D1.setDepthFactor((double) (-1L));
        piePlot3D1.setLabelGap((double) 100);
        org.junit.Assert.assertNotNull(strokeArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(1.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = stackedBarRenderer3D2.getGradientPaintTransformer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = stackedBarRenderer3D2.getBaseItemLabelGenerator();
        stackedBarRenderer3D2.setIncludeBaseInRange(false);
        org.junit.Assert.assertNotNull(gradientPaintTransformer3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean1 = statisticalLineAndShapeRenderer0.getDrawOutlines();
        statisticalLineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(false);
        java.lang.Object obj4 = statisticalLineAndShapeRenderer0.clone();
        boolean boolean7 = statisticalLineAndShapeRenderer0.getItemShapeFilled(255, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        java.awt.Font font1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color2, (float) ' ', textMeasurer4);
        org.jfree.chart.text.TextLine textLine6 = textBlock5.getLastLine();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNull(textLine6);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.25d + "'", double0 == 0.25d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D0.clearCategoryLabelToolTips();
        double double2 = categoryAxis3D0.getCategoryMargin();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((double) 100, (double) 'a');
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder11 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer6.setFrame((org.jfree.chart.block.BlockFrame) blockBorder11);
        blockContainer0.add((org.jfree.chart.block.Block) blockContainer6);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.util.Size2D size2D15 = blockContainer6.arrange(graphics2D14);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit17 = new org.jfree.chart.axis.NumberTickUnit(0.0d);
        boolean boolean18 = blockContainer6.equals((java.lang.Object) 0.0d);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.data.general.PieDataset pieDataset20 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D21 = new org.jfree.chart.plot.PiePlot3D(pieDataset20);
        piePlot3D21.setDepthFactor((double) (byte) 1);
        piePlot3D21.setDepthFactor(0.0d);
        java.awt.Stroke stroke26 = piePlot3D21.getLabelLinkStroke();
        double double27 = piePlot3D21.getShadowXOffset();
        java.lang.String str28 = piePlot3D21.getNoDataMessage();
        java.awt.Paint paint29 = piePlot3D21.getBaseSectionOutlinePaint();
        java.awt.Paint paint31 = piePlot3D21.getSectionOutlinePaint((java.lang.Comparable) 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font35 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer36 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer36.setDrawOutlines(true);
        java.awt.Color color39 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer36.setBasePaint((java.awt.Paint) color39, false);
        org.jfree.chart.text.TextMeasurer textMeasurer43 = null;
        org.jfree.chart.text.TextBlock textBlock44 = org.jfree.chart.text.TextUtilities.createTextBlock("", font35, (java.awt.Paint) color39, (float) (byte) -1, textMeasurer43);
        numberAxis33.setTickMarkPaint((java.awt.Paint) color39);
        piePlot3D21.setLabelShadowPaint((java.awt.Paint) color39);
        org.jfree.chart.block.BlockContainer blockContainer47 = new org.jfree.chart.block.BlockContainer();
        blockContainer47.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer53 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder58 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer53.setFrame((org.jfree.chart.block.BlockFrame) blockBorder58);
        blockContainer47.add((org.jfree.chart.block.Block) blockContainer53);
        java.awt.Graphics2D graphics2D61 = null;
        org.jfree.chart.util.Size2D size2D62 = blockContainer53.arrange(graphics2D61);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor65 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D66 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D62, (double) '#', (double) 1.0f, rectangleAnchor65);
        boolean boolean67 = piePlot3D21.equals((java.lang.Object) rectangle2D66);
        java.lang.Object obj68 = null;
        try {
            java.lang.Object obj69 = blockContainer6.draw(graphics2D19, rectangle2D66, obj68);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(size2D15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 4.0d + "'", double27 == 4.0d);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNull(paint31);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(textBlock44);
        org.junit.Assert.assertNotNull(size2D62);
        org.junit.Assert.assertNotNull(rectangleAnchor65);
        org.junit.Assert.assertNotNull(rectangle2D66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font4 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer5 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer5.setDrawOutlines(true);
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer5.setBasePaint((java.awt.Paint) color8, false);
        org.jfree.chart.text.TextMeasurer textMeasurer12 = null;
        org.jfree.chart.text.TextBlock textBlock13 = org.jfree.chart.text.TextUtilities.createTextBlock("", font4, (java.awt.Paint) color8, (float) (byte) -1, textMeasurer12);
        numberAxis2.setTickMarkPaint((java.awt.Paint) color8);
        boolean boolean15 = numberAxis2.isInverted();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer16 = null;
        org.jfree.chart.plot.PolarPlot polarPlot17 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, polarItemRenderer16);
        numberAxis2.zoomRange((double) (-1.0f), (double) (short) 0);
        java.awt.Paint paint21 = numberAxis2.getTickLabelPaint();
        java.lang.String str22 = numberAxis2.getLabelURL();
        java.awt.Shape shape23 = numberAxis2.getDownArrow();
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(textBlock13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNotNull(shape23);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer0.setDrawOutlines(true);
        statisticalLineAndShapeRenderer0.setBaseItemLabelsVisible(true, true);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("hi!");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        boolean boolean2 = strokeList0.equals((java.lang.Object) paint1);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((double) (byte) 100);
        categoryAxis3D0.setCategoryLabelPositions(categoryLabelPositions2);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.gantt.Task task6 = new org.jfree.data.gantt.Task("", (org.jfree.data.time.TimePeriod) year5);
        java.awt.Font font8 = null;
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.jfree.chart.text.TextMeasurer textMeasurer11 = null;
        org.jfree.chart.text.TextBlock textBlock12 = org.jfree.chart.text.TextUtilities.createTextBlock("", font8, (java.awt.Paint) color9, (float) ' ', textMeasurer11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D14 = new org.jfree.chart.plot.PiePlot3D(pieDataset13);
        piePlot3D14.setDepthFactor((double) (byte) 1);
        piePlot3D14.setDepthFactor(0.0d);
        java.awt.Stroke stroke19 = piePlot3D14.getLabelLinkStroke();
        boolean boolean20 = textBlock12.equals((java.lang.Object) stroke19);
        int int21 = year5.compareTo((java.lang.Object) stroke19);
        boolean boolean22 = categoryLabelPositions2.equals((java.lang.Object) int21);
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(textBlock12);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double1 = range0.getUpperBound();
        double double2 = range0.getLowerBound();
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean1 = statisticalLineAndShapeRenderer0.getDrawOutlines();
        statisticalLineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(false);
        java.lang.Object obj4 = statisticalLineAndShapeRenderer0.clone();
        java.awt.Stroke stroke5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        statisticalLineAndShapeRenderer0.setBaseStroke(stroke5);
        boolean boolean9 = statisticalLineAndShapeRenderer0.getItemShapeVisible((int) '4', (int) (byte) 10);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer10 = new org.jfree.chart.renderer.category.GanttRenderer();
        double double11 = ganttRenderer10.getItemMargin();
        java.awt.Stroke stroke12 = ganttRenderer10.getBaseOutlineStroke();
        statisticalLineAndShapeRenderer0.setBaseOutlineStroke(stroke12);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.2d + "'", double11 == 0.2d);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean1 = statisticalLineAndShapeRenderer0.getDrawOutlines();
        statisticalLineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(false);
        java.lang.Object obj4 = statisticalLineAndShapeRenderer0.clone();
        java.awt.Stroke stroke5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        statisticalLineAndShapeRenderer0.setBaseStroke(stroke5);
        boolean boolean9 = statisticalLineAndShapeRenderer0.getItemShapeVisible((int) '4', (int) (byte) 10);
        java.awt.Font font11 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        statisticalLineAndShapeRenderer0.setSeriesItemLabelFont((int) 'a', font11);
        java.lang.Boolean boolean14 = statisticalLineAndShapeRenderer0.getSeriesLinesVisible(0);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = statisticalLineAndShapeRenderer0.getBaseToolTipGenerator();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNull(boolean14);
        org.junit.Assert.assertNull(categoryToolTipGenerator15);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement0.clear();
        flowArrangement0.clear();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset3 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset3);
        defaultCategoryDataset3.removeColumn((java.lang.Comparable) 100L);
        defaultCategoryDataset3.removeColumn((java.lang.Comparable) 0.2d);
        java.lang.Comparable comparable9 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer10 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement0, (org.jfree.data.general.Dataset) defaultCategoryDataset3, comparable9);
        try {
            java.lang.Number number13 = defaultCategoryDataset3.getValue((-1), (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range4);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDepthFactor((double) (byte) 1);
        piePlot3D1.setDepthFactor(0.0d);
        java.lang.Comparable comparable6 = null;
        java.awt.Color color7 = java.awt.Color.GRAY;
        try {
            piePlot3D1.setSectionOutlinePaint(comparable6, (java.awt.Paint) color7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline1 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long2 = segmentedTimeline1.getStartTime();
        int int3 = segmentedTimeline1.getSegmentsIncluded();
        long long6 = segmentedTimeline1.getExceptionSegmentCount(0L, (-1L));
        long long7 = segmentedTimeline1.getSegmentsGroupSize();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(4, 0);
        java.util.Date date11 = month10.getEnd();
        long long12 = segmentedTimeline1.getTime(date11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date11);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(4, 0);
        java.util.Date date17 = month16.getEnd();
        org.jfree.data.gantt.Task task18 = new org.jfree.data.gantt.Task("", date11, date17);
        try {
            org.jfree.data.gantt.Task task20 = task18.getSubtask(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2208927600000L) + "'", long2 == (-2208927600000L));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 28 + "'", int3 == 28);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 86400000L + "'", long7 == 86400000L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62125372800001L) + "'", long12 == (-62125372800001L));
        org.junit.Assert.assertNotNull(date17);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("#ffff40", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        java.lang.Number[][] numberArray2 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "poly", numberArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.data.DefaultKeyedValue defaultKeyedValue2 = new org.jfree.data.DefaultKeyedValue((java.lang.Comparable) 0.0f, (java.lang.Number) 2958465);
        java.lang.Object obj3 = defaultKeyedValue2.clone();
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("EXPAND", "", "", "EXPAND");
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D6 = new org.jfree.chart.plot.PiePlot3D(pieDataset5);
        java.awt.Font font7 = piePlot3D6.getLabelFont();
        boolean boolean8 = library4.equals((java.lang.Object) piePlot3D6);
        java.lang.Object obj9 = piePlot3D6.clone();
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = statisticalLineAndShapeRenderer0.getBaseItemLabelGenerator();
        statisticalLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D5 = new org.jfree.chart.plot.PiePlot3D(pieDataset4);
        java.awt.Font font6 = piePlot3D5.getLabelFont();
        statisticalLineAndShapeRenderer0.setBaseItemLabelFont(font6);
        double double8 = statisticalLineAndShapeRenderer0.getItemLabelAnchorOffset();
        org.junit.Assert.assertNull(categoryItemLabelGenerator1);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.0d + "'", double8 == 2.0d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis2.setInverted(true);
        boolean boolean5 = numberAxis2.isAxisLineVisible();
        boolean boolean6 = numberAxis2.getAutoRangeStickyZero();
        java.awt.Stroke stroke7 = numberAxis2.getAxisLineStroke();
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis2);
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot0.getRangeAxisLocation(0);
        categoryPlot0.setAnchorValue((double) 1L);
        org.jfree.chart.axis.AxisLocation axisLocation14 = null;
        categoryPlot0.setRangeAxisLocation((int) (short) 10, axisLocation14, false);
        categoryPlot0.setAnchorValue((double) 255);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(axisLocation10);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = numberAxis1.getMarkerBand();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = numberAxis1.getMarkerBand();
        java.lang.String str4 = numberAxis1.getLabel();
        org.jfree.data.Range range5 = numberAxis1.getDefaultAutoRange();
        numberAxis1.setTickMarkInsideLength((float) (-2208927599903L));
        org.junit.Assert.assertNull(markerAxisBand2);
        org.junit.Assert.assertNull(markerAxisBand3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
        org.junit.Assert.assertNotNull(range5);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        boolean boolean5 = categoryAxis3D3.equals((java.lang.Object) textAnchor4);
        categoryAxis3D3.setMaximumCategoryLabelWidthRatio((float) 60000L);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset10 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset10);
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer14 = null;
        org.jfree.chart.plot.PolarPlot polarPlot15 = new org.jfree.chart.plot.PolarPlot(xYDataset12, valueAxis13, polarItemRenderer14);
        defaultCategoryDataset10.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot15);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo18 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo18);
        java.awt.geom.Point2D point2D20 = null;
        polarPlot15.zoomDomainAxes((double) '#', plotRenderingInfo19, point2D20);
        org.jfree.chart.block.BlockContainer blockContainer22 = new org.jfree.chart.block.BlockContainer();
        blockContainer22.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer28 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder33 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer28.setFrame((org.jfree.chart.block.BlockFrame) blockBorder33);
        blockContainer22.add((org.jfree.chart.block.Block) blockContainer28);
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.chart.util.Size2D size2D37 = blockContainer28.arrange(graphics2D36);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor40 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D41 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D37, (double) '#', (double) 1.0f, rectangleAnchor40);
        plotRenderingInfo19.setPlotArea(rectangle2D41);
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis45.setInverted(true);
        boolean boolean48 = numberAxis45.isAxisLineVisible();
        boolean boolean49 = numberAxis45.getAutoRangeStickyZero();
        java.awt.Stroke stroke50 = numberAxis45.getAxisLineStroke();
        categoryPlot43.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis45);
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = categoryPlot43.getDomainAxisEdge();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer53 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean54 = rectangleEdge52.equals((java.lang.Object) statisticalBarRenderer53);
        double double55 = categoryAxis3D3.getCategoryMiddle((-1), 100, rectangle2D41, rectangleEdge52);
        java.awt.geom.Point2D point2D56 = null;
        org.jfree.chart.plot.PlotState plotState57 = new org.jfree.chart.plot.PlotState();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset58 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range59 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset58);
        org.jfree.data.xy.XYDataset xYDataset60 = null;
        org.jfree.chart.axis.ValueAxis valueAxis61 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer62 = null;
        org.jfree.chart.plot.PolarPlot polarPlot63 = new org.jfree.chart.plot.PolarPlot(xYDataset60, valueAxis61, polarItemRenderer62);
        defaultCategoryDataset58.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot63);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo66 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo67 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo66);
        java.awt.geom.Point2D point2D68 = null;
        polarPlot63.zoomDomainAxes((double) '#', plotRenderingInfo67, point2D68);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo70 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo71 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo70);
        plotRenderingInfo67.addSubplotInfo(plotRenderingInfo71);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo74 = plotRenderingInfo67.getSubplotInfo((int) (byte) 0);
        try {
            piePlot3D1.draw(graphics2D2, rectangle2D41, point2D56, plotState57, plotRenderingInfo67);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(size2D37);
        org.junit.Assert.assertNotNull(rectangleAnchor40);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(rectangleEdge52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 35.0d + "'", double55 == 35.0d);
        org.junit.Assert.assertNull(range59);
        org.junit.Assert.assertNotNull(plotRenderingInfo74);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        java.awt.Color color0 = java.awt.Color.pink;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
        java.awt.Font font2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer3.setDrawOutlines(true);
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer3.setBasePaint((java.awt.Paint) color6, false);
        org.jfree.chart.text.TextMeasurer textMeasurer10 = null;
        org.jfree.chart.text.TextBlock textBlock11 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, (java.awt.Paint) color6, (float) (byte) -1, textMeasurer10);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor15 = null;
        java.awt.Shape shape19 = textBlock11.calculateBounds(graphics2D12, (float) 1, 100.0f, textBlockAnchor15, (float) 3, (float) (short) -1, (double) 0);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset22 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range23 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset22);
        org.jfree.data.Range range24 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset22);
        java.lang.Comparable comparable25 = null;
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity27 = new org.jfree.chart.entity.CategoryItemEntity(shape19, "{0}", "EXPAND", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset22, comparable25, (java.lang.Comparable) 1.0d);
        org.jfree.data.Range range28 = stackedBarRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset22);
        java.lang.Number number29 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset22);
        java.util.List list30 = defaultCategoryDataset22.getRowKeys();
        try {
            java.lang.Number number33 = defaultCategoryDataset22.getValue((java.lang.Comparable) 10.0f, (java.lang.Comparable) 100.0f);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: 100.0");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(textBlock11);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNull(range23);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNull(number29);
        org.junit.Assert.assertNotNull(list30);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        int int2 = xYPlot0.indexOf(xYDataset1);
        org.jfree.chart.util.Layer layer4 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection5 = xYPlot0.getRangeMarkers(6, layer4);
        java.awt.Paint paint6 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeCrosshairPaint(paint6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(layer4);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer1 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean2 = statisticalLineAndShapeRenderer1.getDrawOutlines();
        statisticalLineAndShapeRenderer1.setAutoPopulateSeriesFillPaint(false);
        java.awt.Stroke stroke6 = statisticalLineAndShapeRenderer1.lookupSeriesStroke(28);
        lineAndShapeRenderer0.setBaseStroke(stroke6);
        java.awt.Paint paint9 = lineAndShapeRenderer0.getSeriesFillPaint((int) '#');
        java.awt.Stroke stroke12 = lineAndShapeRenderer0.getItemOutlineStroke(1, 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = lineAndShapeRenderer0.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        lineAndShapeRenderer0.setSeriesLinesVisible((int) ' ', (java.lang.Boolean) false);
        lineAndShapeRenderer0.setBaseShapesVisible(true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font3 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer4 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer4.setDrawOutlines(true);
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer4.setBasePaint((java.awt.Paint) color7, false);
        org.jfree.chart.text.TextMeasurer textMeasurer11 = null;
        org.jfree.chart.text.TextBlock textBlock12 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, (java.awt.Paint) color7, (float) (byte) -1, textMeasurer11);
        numberAxis1.setTickMarkPaint((java.awt.Paint) color7);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit15 = new org.jfree.chart.axis.NumberTickUnit(0.0d);
        numberAxis1.setTickUnit(numberTickUnit15);
        java.awt.Paint paint17 = numberAxis1.getTickMarkPaint();
        numberAxis1.setAutoRange(false);
        java.awt.Shape shape20 = numberAxis1.getRightArrow();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(textBlock12);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(shape20);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDepthFactor((double) (byte) 1);
        piePlot3D1.setDepthFactor(0.0d);
        java.awt.Stroke stroke6 = piePlot3D1.getLabelLinkStroke();
        double double7 = piePlot3D1.getShadowXOffset();
        java.lang.String str8 = piePlot3D1.getNoDataMessage();
        java.awt.Paint paint9 = piePlot3D1.getBackgroundPaint();
        try {
            double double10 = piePlot3D1.getMaximumExplodePercent();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list1 = defaultCategoryDataset0.getRowKeys();
        org.jfree.data.KeyToGroupMap keyToGroupMap2 = new org.jfree.data.KeyToGroupMap();
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, keyToGroupMap2);
        keyToGroupMap2.mapKeyToGroup((java.lang.Comparable) "SortOrder.DESCENDING", (java.lang.Comparable) 0.0f);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(range3);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        try {
            keyedObjects2D0.removeColumn((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDepthFactor((double) (byte) 1);
        piePlot3D1.setDepthFactor(0.0d);
        java.awt.Stroke[] strokeArray6 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        boolean boolean7 = piePlot3D1.equals((java.lang.Object) strokeArray6);
        java.awt.Paint paint8 = piePlot3D1.getLabelShadowPaint();
        java.awt.Paint paint9 = piePlot3D1.getLabelBackgroundPaint();
        org.jfree.chart.block.BlockBorder blockBorder10 = new org.jfree.chart.block.BlockBorder(paint9);
        org.junit.Assert.assertNotNull(strokeArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset2, valueAxis3, polarItemRenderer4);
        defaultCategoryDataset0.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot5);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo8);
        java.awt.geom.Point2D point2D10 = null;
        polarPlot5.zoomDomainAxes((double) '#', plotRenderingInfo9, point2D10);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo12 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo12);
        plotRenderingInfo9.addSubplotInfo(plotRenderingInfo13);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = plotRenderingInfo9.getSubplotInfo((int) (byte) 0);
        java.awt.geom.Rectangle2D rectangle2D17 = plotRenderingInfo16.getPlotArea();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNotNull(plotRenderingInfo16);
        org.junit.Assert.assertNull(rectangle2D17);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10L, 0.0d, false);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setInverted(true);
        boolean boolean4 = numberAxis1.isAxisLineVisible();
        java.awt.Shape shape5 = numberAxis1.getDownArrow();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.util.List list3 = defaultBoxAndWhiskerCategoryDataset0.getOutliers((java.lang.Comparable) (-2208927600000L), (java.lang.Comparable) (byte) 100);
        try {
            java.lang.Comparable comparable5 = defaultBoxAndWhiskerCategoryDataset0.getColumnKey(6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(list3);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        java.awt.Font font1 = null;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis4, polarItemRenderer5);
        float float7 = polarPlot6.getBackgroundAlpha();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer8 = polarPlot6.getRenderer();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font1, (org.jfree.chart.plot.Plot) polarPlot6, false);
        org.jfree.chart.title.Title title11 = null;
        try {
            jFreeChart10.addSubtitle(title11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'subtitle' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertNull(polarItemRenderer8);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("", timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        org.jfree.chart.ui.Library[] libraryArray1 = projectInfo0.getOptionalLibraries();
        java.awt.Image image2 = projectInfo0.getLogo();
        org.jfree.chart.ui.Library library3 = null;
        try {
            projectInfo0.addOptionalLibrary(library3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Library must be given.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(libraryArray1);
        org.junit.Assert.assertNull(image2);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset2, valueAxis3, polarItemRenderer4);
        java.lang.Object obj6 = null;
        boolean boolean7 = polarPlot5.equals(obj6);
        int int8 = polarPlot5.getSeriesCount();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        polarPlot5.setAngleLabelPaint((java.awt.Paint) color9);
        org.jfree.chart.text.TextLine textLine11 = new org.jfree.chart.text.TextLine("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font1, (java.awt.Paint) color9);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        java.awt.Paint paint0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        double double1 = ganttRenderer0.getStartPercent();
        org.jfree.data.gantt.TaskSeries taskSeries3 = new org.jfree.data.gantt.TaskSeries("");
        boolean boolean5 = taskSeries3.equals((java.lang.Object) 1L);
        org.jfree.data.gantt.Task task6 = null;
        taskSeries3.remove(task6);
        java.lang.Object obj8 = taskSeries3.clone();
        boolean boolean9 = ganttRenderer0.equals((java.lang.Object) taskSeries3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.35d + "'", double1 == 0.35d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.lang.Number number3 = defaultBoxAndWhiskerCategoryDataset0.getQ3Value((java.lang.Comparable) (byte) 1, (java.lang.Comparable) 100.0f);
        try {
            java.lang.Number number6 = defaultBoxAndWhiskerCategoryDataset0.getMaxOutlier((int) (short) 10, 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(number3);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = null;
        statisticalLineAndShapeRenderer0.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator2, true);
        statisticalLineAndShapeRenderer0.setSeriesVisibleInLegend(0, (java.lang.Boolean) true, true);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(1.0d, (double) (short) -1);
        boolean boolean12 = stackedBarRenderer3D11.isDrawBarOutline();
        java.awt.Paint paint13 = stackedBarRenderer3D11.getWallPaint();
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator15 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("({0}, {1}) = {3} - {4}");
        stackedBarRenderer3D11.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator15);
        statisticalLineAndShapeRenderer0.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator15);
        java.lang.Object obj18 = standardCategorySeriesLabelGenerator15.clone();
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(obj18);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder11 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer6.setFrame((org.jfree.chart.block.BlockFrame) blockBorder11);
        blockContainer0.add((org.jfree.chart.block.Block) blockContainer6);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.util.Size2D size2D15 = blockContainer6.arrange(graphics2D14);
        blockContainer6.setID("");
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = blockContainer6.getMargin();
        org.junit.Assert.assertNotNull(size2D15);
        org.junit.Assert.assertNotNull(rectangleInsets18);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean1 = statisticalLineAndShapeRenderer0.getDrawOutlines();
        statisticalLineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(false);
        java.lang.Object obj4 = statisticalLineAndShapeRenderer0.clone();
        java.awt.Stroke stroke5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        statisticalLineAndShapeRenderer0.setBaseStroke(stroke5);
        boolean boolean9 = statisticalLineAndShapeRenderer0.getItemShapeVisible((int) '4', (int) (byte) 10);
        java.awt.Font font11 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        statisticalLineAndShapeRenderer0.setSeriesItemLabelFont((int) 'a', font11);
        java.lang.Boolean boolean14 = statisticalLineAndShapeRenderer0.getSeriesLinesVisible(0);
        boolean boolean17 = statisticalLineAndShapeRenderer0.getItemShapeVisible((int) (byte) 1, 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = statisticalLineAndShapeRenderer0.getPlot();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNull(boolean14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(categoryPlot18);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, polarItemRenderer3);
        org.jfree.data.general.DatasetGroup datasetGroup5 = polarPlot4.getDatasetGroup();
        java.awt.Paint paint6 = polarPlot4.getAngleGridlinePaint();
        java.lang.Object obj7 = polarPlot4.clone();
        java.awt.Font font8 = polarPlot4.getAngleLabelFont();
        java.lang.String str9 = polarPlot4.getPlotType();
        org.junit.Assert.assertNull(datasetGroup5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Polar Plot" + "'", str9.equals("Polar Plot"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis2.setInverted(true);
        boolean boolean5 = numberAxis2.isAxisLineVisible();
        boolean boolean6 = numberAxis2.getAutoRangeStickyZero();
        java.awt.Stroke stroke7 = numberAxis2.getAxisLineStroke();
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis2);
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot0.getRangeAxisLocation(0);
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.plot.Marker marker12 = null;
        try {
            categoryPlot0.addRangeMarker(marker12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(axisLocation10);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list1 = axisCollection0.getAxesAtTop();
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        int int5 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) 10L);
        java.lang.Number number6 = null;
        java.lang.Comparable comparable8 = null;
        try {
            defaultCategoryDataset0.setValue(number6, (java.lang.Comparable) (-2208927599903L), comparable8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        polarPlot3.removeCornerTextItem("hi!");
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = polarPlot3.getOrientation();
        java.lang.String str7 = plotOrientation6.toString();
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str7.equals("PlotOrientation.HORIZONTAL"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis2.setInverted(true);
        boolean boolean5 = numberAxis2.isAxisLineVisible();
        boolean boolean6 = numberAxis2.getAutoRangeStickyZero();
        java.awt.Stroke stroke7 = numberAxis2.getAxisLineStroke();
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis2);
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot0.setRangeCrosshairStroke(stroke9);
        categoryPlot0.setRangeCrosshairVisible(true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDepthFactor((double) (byte) 1);
        piePlot3D1.setDepthFactor(0.0d);
        java.awt.Stroke[] strokeArray6 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        boolean boolean7 = piePlot3D1.equals((java.lang.Object) strokeArray6);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator8 = null;
        piePlot3D1.setLegendLabelURLGenerator(pieURLGenerator8);
        java.awt.Paint paint10 = piePlot3D1.getLabelOutlinePaint();
        piePlot3D1.setIgnoreNullValues(true);
        org.junit.Assert.assertNotNull(strokeArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        java.awt.Font font1 = null;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis4, polarItemRenderer5);
        float float7 = polarPlot6.getBackgroundAlpha();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer8 = polarPlot6.getRenderer();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font1, (org.jfree.chart.plot.Plot) polarPlot6, false);
        org.jfree.chart.event.ChartChangeListener chartChangeListener11 = null;
        try {
            jFreeChart10.removeChangeListener(chartChangeListener11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertNull(polarItemRenderer8);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
        java.awt.Font font2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer3.setDrawOutlines(true);
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer3.setBasePaint((java.awt.Paint) color6, false);
        org.jfree.chart.text.TextMeasurer textMeasurer10 = null;
        org.jfree.chart.text.TextBlock textBlock11 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, (java.awt.Paint) color6, (float) (byte) -1, textMeasurer10);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor15 = null;
        java.awt.Shape shape19 = textBlock11.calculateBounds(graphics2D12, (float) 1, 100.0f, textBlockAnchor15, (float) 3, (float) (short) -1, (double) 0);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset22 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range23 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset22);
        org.jfree.data.Range range24 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset22);
        java.lang.Comparable comparable25 = null;
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity27 = new org.jfree.chart.entity.CategoryItemEntity(shape19, "{0}", "EXPAND", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset22, comparable25, (java.lang.Comparable) 1.0d);
        org.jfree.data.Range range28 = stackedBarRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset22);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer30 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer31 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean32 = statisticalLineAndShapeRenderer31.getDrawOutlines();
        statisticalLineAndShapeRenderer31.setAutoPopulateSeriesFillPaint(false);
        java.awt.Stroke stroke36 = statisticalLineAndShapeRenderer31.lookupSeriesStroke(28);
        lineAndShapeRenderer30.setBaseStroke(stroke36);
        java.awt.Paint paint39 = lineAndShapeRenderer30.getSeriesFillPaint((int) '#');
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator44 = new org.jfree.chart.urls.StandardCategoryURLGenerator("", "({0}, {1}) = {3} - {4}", "{0}");
        lineAndShapeRenderer30.setSeriesURLGenerator(2, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator44, true);
        stackedBarRenderer0.setSeriesURLGenerator(10, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator44);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(textBlock11);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNull(range23);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNull(paint39);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        int int0 = org.jfree.data.time.SerialDate.FRIDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer1 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean2 = statisticalLineAndShapeRenderer1.getDrawOutlines();
        statisticalLineAndShapeRenderer1.setAutoPopulateSeriesFillPaint(false);
        java.awt.Stroke stroke6 = statisticalLineAndShapeRenderer1.lookupSeriesStroke(28);
        lineAndShapeRenderer0.setBaseStroke(stroke6);
        lineAndShapeRenderer0.setBaseItemLabelsVisible(true, true);
        lineAndShapeRenderer0.setSeriesCreateEntities((int) (short) 100, (java.lang.Boolean) true);
        lineAndShapeRenderer0.setBaseShapesVisible(false);
        lineAndShapeRenderer0.setDrawOutlines(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement0.clear();
        flowArrangement0.clear();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset3 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset3);
        defaultCategoryDataset3.removeColumn((java.lang.Comparable) 100L);
        defaultCategoryDataset3.removeColumn((java.lang.Comparable) 0.2d);
        java.lang.Comparable comparable9 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer10 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement0, (org.jfree.data.general.Dataset) defaultCategoryDataset3, comparable9);
        int int12 = defaultCategoryDataset3.getColumnIndex((java.lang.Comparable) "({0}, {1}) = {3} - {4}");
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("{0}");
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis4, polarItemRenderer5);
        java.awt.Font font7 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        polarPlot6.setAngleLabelFont(font7);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer9 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer9.setDrawOutlines(true);
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer9.setBasePaint((java.awt.Paint) color12, false);
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer18 = null;
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot(xYDataset16, valueAxis17, polarItemRenderer18);
        java.lang.Object obj20 = null;
        boolean boolean21 = polarPlot19.equals(obj20);
        int int22 = polarPlot19.getSeriesCount();
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        polarPlot19.setAngleLabelPaint((java.awt.Paint) color23);
        statisticalLineAndShapeRenderer9.setSeriesFillPaint(2, (java.awt.Paint) color23);
        java.awt.Stroke stroke28 = statisticalLineAndShapeRenderer9.getItemStroke(0, 10);
        java.lang.Boolean boolean30 = statisticalLineAndShapeRenderer9.getSeriesCreateEntities((int) (short) -1);
        java.awt.Font font31 = statisticalLineAndShapeRenderer9.getBaseItemLabelFont();
        polarPlot6.setAngleLabelFont(font31);
        labelBlock1.setFont(font31);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType34 = org.jfree.chart.block.LengthConstraintType.NONE;
        boolean boolean35 = labelBlock1.equals((java.lang.Object) lengthConstraintType34);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNull(boolean30);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(lengthConstraintType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((double) (byte) 10, (double) '4');
        java.awt.Font font4 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer5 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer5.setDrawOutlines(true);
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer5.setBasePaint((java.awt.Paint) color8, false);
        org.jfree.chart.text.TextMeasurer textMeasurer12 = null;
        org.jfree.chart.text.TextBlock textBlock13 = org.jfree.chart.text.TextUtilities.createTextBlock("", font4, (java.awt.Paint) color8, (float) (byte) -1, textMeasurer12);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor17 = null;
        java.awt.Shape shape21 = textBlock13.calculateBounds(graphics2D14, (float) 1, 100.0f, textBlockAnchor17, (float) 3, (float) (short) -1, (double) 0);
        java.awt.Font font24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.text.TextBlock textBlock26 = org.jfree.chart.text.TextUtilities.createTextBlock("{0}", font24, (java.awt.Paint) color25);
        java.awt.Paint paint27 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        textBlock13.addLine("{0}", font24, paint27);
        boolean boolean29 = meanAndStandardDeviation2.equals((java.lang.Object) font24);
        org.jfree.data.general.PieDataset pieDataset30 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D31 = new org.jfree.chart.plot.PiePlot3D(pieDataset30);
        piePlot3D31.setDepthFactor((double) (byte) 1);
        piePlot3D31.setDepthFactor(0.0d);
        java.awt.Stroke stroke36 = piePlot3D31.getLabelLinkStroke();
        org.jfree.data.general.PieDataset pieDataset37 = null;
        piePlot3D31.setDataset(pieDataset37);
        java.lang.Object obj39 = piePlot3D31.clone();
        boolean boolean40 = meanAndStandardDeviation2.equals((java.lang.Object) piePlot3D31);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(textBlock13);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(textBlock26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(3);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = statisticalLineAndShapeRenderer0.getBaseItemLabelGenerator();
        statisticalLineAndShapeRenderer0.setSeriesItemLabelsVisible(15, (java.lang.Boolean) true);
        java.awt.Paint paint6 = statisticalLineAndShapeRenderer0.getSeriesPaint(0);
        statisticalLineAndShapeRenderer0.setAutoPopulateSeriesPaint(true);
        statisticalLineAndShapeRenderer0.setDrawOutlines(true);
        org.junit.Assert.assertNull(categoryItemLabelGenerator1);
        org.junit.Assert.assertNull(paint6);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.awt.Image image1 = projectInfo0.getLogo();
        java.lang.String str2 = projectInfo0.getLicenceText();
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(1.0d, (double) (short) -1);
        boolean boolean3 = stackedBarRenderer3D2.isDrawBarOutline();
        double double4 = stackedBarRenderer3D2.getYOffset();
        stackedBarRenderer3D2.setItemLabelAnchorOffset((double) (byte) 0);
        stackedBarRenderer3D2.setRenderAsPercentages(false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.0d) + "'", double4 == (-1.0d));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDepthFactor((double) (byte) 1);
        piePlot3D1.setDepthFactor(0.0d);
        java.awt.Stroke[] strokeArray6 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        boolean boolean7 = piePlot3D1.equals((java.lang.Object) strokeArray6);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator8 = null;
        piePlot3D1.setLegendLabelURLGenerator(pieURLGenerator8);
        java.awt.Paint paint10 = piePlot3D1.getLabelOutlinePaint();
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D12 = new org.jfree.chart.plot.PiePlot3D(pieDataset11);
        piePlot3D12.setDepthFactor((double) (byte) 1);
        piePlot3D12.setDepthFactor(0.0d);
        java.awt.Stroke[] strokeArray17 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        boolean boolean18 = piePlot3D12.equals((java.lang.Object) strokeArray17);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator19 = null;
        piePlot3D12.setLegendLabelURLGenerator(pieURLGenerator19);
        java.awt.Paint paint21 = piePlot3D12.getLabelOutlinePaint();
        org.jfree.data.general.PieDataset pieDataset22 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D23 = new org.jfree.chart.plot.PiePlot3D(pieDataset22);
        piePlot3D23.setDepthFactor((double) (byte) 1);
        piePlot3D23.setDepthFactor(0.0d);
        piePlot3D23.setInteriorGap((double) 0.0f);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator30 = piePlot3D23.getURLGenerator();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator31 = piePlot3D23.getLabelGenerator();
        piePlot3D12.setLabelGenerator(pieSectionLabelGenerator31);
        piePlot3D1.setLegendLabelGenerator(pieSectionLabelGenerator31);
        org.junit.Assert.assertNotNull(strokeArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(strokeArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNull(pieURLGenerator30);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator31);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        java.awt.Color color0 = java.awt.Color.WHITE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset3 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset3);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset5, valueAxis6, polarItemRenderer7);
        defaultCategoryDataset3.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot8);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo11);
        java.awt.geom.Point2D point2D13 = null;
        polarPlot8.zoomDomainAxes((double) '#', plotRenderingInfo12, point2D13);
        org.jfree.chart.block.BlockContainer blockContainer15 = new org.jfree.chart.block.BlockContainer();
        blockContainer15.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer21 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder26 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer21.setFrame((org.jfree.chart.block.BlockFrame) blockBorder26);
        blockContainer15.add((org.jfree.chart.block.Block) blockContainer21);
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.util.Size2D size2D30 = blockContainer21.arrange(graphics2D29);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D34 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D30, (double) '#', (double) 1.0f, rectangleAnchor33);
        plotRenderingInfo12.setPlotArea(rectangle2D34);
        categoryPlot0.handleClick(0, 0, plotRenderingInfo12);
        org.jfree.chart.util.Layer layer38 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection39 = categoryPlot0.getRangeMarkers(0, layer38);
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis43.setInverted(true);
        boolean boolean46 = numberAxis43.isAxisLineVisible();
        boolean boolean47 = numberAxis43.getAutoRangeStickyZero();
        java.awt.Stroke stroke48 = numberAxis43.getAxisLineStroke();
        categoryPlot41.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis43);
        org.jfree.chart.axis.AxisLocation axisLocation51 = categoryPlot41.getRangeAxisLocation(0);
        categoryPlot0.setDomainAxisLocation((int) (short) 0, axisLocation51);
        org.jfree.chart.plot.Marker marker53 = null;
        try {
            categoryPlot0.addRangeMarker(marker53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNotNull(size2D30);
        org.junit.Assert.assertNotNull(rectangleAnchor33);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNotNull(layer38);
        org.junit.Assert.assertNull(collection39);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(axisLocation51);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        java.lang.Object obj2 = plotRenderingInfo1.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.RangeType rangeType2 = numberAxis1.getRangeType();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = null;
        try {
            numberAxis1.setTickUnit(numberTickUnit3, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rangeType2);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("EXPAND");
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font3 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer4 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer4.setDrawOutlines(true);
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer4.setBasePaint((java.awt.Paint) color7, false);
        org.jfree.chart.text.TextMeasurer textMeasurer11 = null;
        org.jfree.chart.text.TextBlock textBlock12 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, (java.awt.Paint) color7, (float) (byte) -1, textMeasurer11);
        numberAxis1.setTickMarkPaint((java.awt.Paint) color7);
        numberAxis1.configure();
        numberAxis1.setFixedAutoRange((double) (-1L));
        org.jfree.chart.axis.NumberTickUnit numberTickUnit17 = numberAxis1.getTickUnit();
        boolean boolean18 = numberAxis1.isVisible();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(textBlock12);
        org.junit.Assert.assertNotNull(numberTickUnit17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        java.awt.Font font1 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer2.setDrawOutlines(true);
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer2.setBasePaint((java.awt.Paint) color5, false);
        org.jfree.chart.text.TextMeasurer textMeasurer9 = null;
        org.jfree.chart.text.TextBlock textBlock10 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color5, (float) (byte) -1, textMeasurer9);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor14 = null;
        java.awt.Shape shape18 = textBlock10.calculateBounds(graphics2D11, (float) 1, 100.0f, textBlockAnchor14, (float) 3, (float) (short) -1, (double) 0);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset21 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range22 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset21);
        org.jfree.data.Range range23 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset21);
        java.lang.Comparable comparable24 = null;
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity26 = new org.jfree.chart.entity.CategoryItemEntity(shape18, "{0}", "EXPAND", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset21, comparable24, (java.lang.Comparable) 1.0d);
        org.jfree.data.category.CategoryDataset categoryDataset27 = categoryItemEntity26.getDataset();
        java.lang.Number number28 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset27);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(textBlock10);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNull(range22);
        org.junit.Assert.assertNull(range23);
        org.junit.Assert.assertNotNull(categoryDataset27);
        org.junit.Assert.assertNull(number28);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        java.awt.Color color0 = java.awt.Color.lightGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(1.0d, (double) (short) -1);
        boolean boolean3 = stackedBarRenderer3D2.isDrawBarOutline();
        double double4 = stackedBarRenderer3D2.getYOffset();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset5 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range7 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset5, true);
        org.jfree.data.Range range8 = stackedBarRenderer3D2.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset5);
        java.awt.Paint paint11 = stackedBarRenderer3D2.getItemLabelPaint((int) (byte) 1, (int) (byte) 10);
        java.io.ObjectOutputStream objectOutputStream12 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePaint(paint11, objectOutputStream12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.0d) + "'", double4 == (-1.0d));
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis2.setInverted(true);
        boolean boolean5 = numberAxis2.isAxisLineVisible();
        boolean boolean6 = numberAxis2.getAutoRangeStickyZero();
        java.awt.Stroke stroke7 = numberAxis2.getAxisLineStroke();
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis2);
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot0.getRangeAxisLocation(0);
        float float11 = categoryPlot0.getBackgroundAlpha();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset15 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset15);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot(xYDataset17, valueAxis18, polarItemRenderer19);
        defaultCategoryDataset15.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot20);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo23 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo23);
        java.awt.geom.Point2D point2D25 = null;
        polarPlot20.zoomDomainAxes((double) '#', plotRenderingInfo24, point2D25);
        org.jfree.chart.block.BlockContainer blockContainer27 = new org.jfree.chart.block.BlockContainer();
        blockContainer27.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer33 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder38 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer33.setFrame((org.jfree.chart.block.BlockFrame) blockBorder38);
        blockContainer27.add((org.jfree.chart.block.Block) blockContainer33);
        java.awt.Graphics2D graphics2D41 = null;
        org.jfree.chart.util.Size2D size2D42 = blockContainer33.arrange(graphics2D41);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor45 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D46 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D42, (double) '#', (double) 1.0f, rectangleAnchor45);
        plotRenderingInfo24.setPlotArea(rectangle2D46);
        categoryPlot12.handleClick(0, 0, plotRenderingInfo24);
        org.jfree.chart.util.Layer layer50 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection51 = categoryPlot12.getRangeMarkers(0, layer50);
        java.util.Collection collection52 = categoryPlot0.getDomainMarkers(layer50);
        org.jfree.data.gantt.TaskSeries taskSeries54 = new org.jfree.data.gantt.TaskSeries("");
        taskSeries54.fireSeriesChanged();
        org.jfree.data.gantt.Task task57 = taskSeries54.get("{0}");
        org.jfree.data.gantt.Task task59 = taskSeries54.get("({0}, {1}) = {3} - {4}");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener60 = null;
        taskSeries54.removeChangeListener(seriesChangeListener60);
        boolean boolean62 = layer50.equals((java.lang.Object) taskSeries54);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 1.0f + "'", float11 == 1.0f);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(size2D42);
        org.junit.Assert.assertNotNull(rectangleAnchor45);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertNotNull(layer50);
        org.junit.Assert.assertNull(collection51);
        org.junit.Assert.assertNull(collection52);
        org.junit.Assert.assertNull(task57);
        org.junit.Assert.assertNull(task59);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis2.setInverted(true);
        boolean boolean5 = numberAxis2.isAxisLineVisible();
        boolean boolean6 = numberAxis2.getAutoRangeStickyZero();
        java.awt.Stroke stroke7 = numberAxis2.getAxisLineStroke();
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis2);
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot0.setRangeCrosshairStroke(stroke9);
        categoryPlot0.setDomainGridlinesVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation14 = categoryPlot0.getRangeAxisLocation(11);
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        int int18 = xYPlot16.indexOf(xYDataset17);
        org.jfree.chart.util.Layer layer20 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection21 = xYPlot16.getRangeMarkers(6, layer20);
        try {
            categoryPlot0.addDomainMarker(categoryMarker15, layer20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(layer20);
        org.junit.Assert.assertNull(collection21);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDepthFactor((double) (byte) 1);
        piePlot3D1.setDepthFactor(0.0d);
        java.awt.Stroke stroke6 = piePlot3D1.getLabelLinkStroke();
        double double7 = piePlot3D1.getShadowXOffset();
        java.lang.String str8 = piePlot3D1.getNoDataMessage();
        java.awt.Paint paint9 = piePlot3D1.getBaseSectionOutlinePaint();
        java.awt.Paint paint11 = piePlot3D1.getSectionOutlinePaint((java.lang.Comparable) 0.0d);
        org.jfree.chart.LegendItemCollection legendItemCollection12 = piePlot3D1.getLegendItems();
        double double13 = piePlot3D1.getLabelLinkMargin();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.05d + "'", double13 == 0.05d);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        java.awt.geom.Point2D point2D0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePoint2D(point2D0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.String str1 = rectangleInsets0.toString();
        double double3 = rectangleInsets0.calculateBottomInset(0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str1.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("EXPAND", "", "", "EXPAND");
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D6 = new org.jfree.chart.plot.PiePlot3D(pieDataset5);
        java.awt.Font font7 = piePlot3D6.getLabelFont();
        boolean boolean8 = library4.equals((java.lang.Object) piePlot3D6);
        java.lang.String str9 = library4.getLicenceName();
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((double) (byte) 100);
        boolean boolean3 = textLine0.equals((java.lang.Object) (byte) 100);
        org.jfree.chart.text.TextFragment textFragment4 = textLine0.getFirstTextFragment();
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(textFragment4);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) '#', (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.event.TitleChangeListener titleChangeListener1 = null;
        textTitle0.removeChangeListener(titleChangeListener1);
        java.lang.String str3 = textTitle0.getURLText();
        textTitle0.setMargin((double) (byte) 10, 8.0d, (double) 60000L, (double) 100);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean1 = statisticalLineAndShapeRenderer0.getDrawOutlines();
        statisticalLineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(false);
        java.lang.Object obj4 = statisticalLineAndShapeRenderer0.clone();
        java.awt.Stroke stroke5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        statisticalLineAndShapeRenderer0.setBaseStroke(stroke5);
        boolean boolean9 = statisticalLineAndShapeRenderer0.getItemShapeVisible((int) '4', (int) (byte) 10);
        java.awt.Font font11 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        statisticalLineAndShapeRenderer0.setSeriesItemLabelFont((int) 'a', font11);
        java.lang.Boolean boolean14 = statisticalLineAndShapeRenderer0.getSeriesLinesVisible(0);
        java.awt.Shape shape15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.Shape shape19 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape15, rectangleAnchor16, (double) (-2208927600000L), (double) (byte) 0);
        statisticalLineAndShapeRenderer0.setBaseShape(shape15);
        java.awt.Paint paint21 = null;
        try {
            statisticalLineAndShapeRenderer0.setBaseItemLabelPaint(paint21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNull(boolean14);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertNotNull(shape19);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        boolean boolean2 = piePlot3D1.getIgnoreNullValues();
        java.awt.Image image3 = piePlot3D1.getBackgroundImage();
        boolean boolean4 = piePlot3D1.getLabelLinksVisible();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(image3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Color color2 = java.awt.Color.getColor("hi!", color1);
        int int3 = color2.getRGB();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16744320) + "'", int3 == (-16744320));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDepthFactor((double) (byte) 1);
        piePlot3D1.setDepthFactor(0.0d);
        java.awt.Stroke stroke6 = piePlot3D1.getLabelLinkStroke();
        double double7 = piePlot3D1.getShadowXOffset();
        java.lang.String str8 = piePlot3D1.getNoDataMessage();
        java.awt.Paint paint9 = piePlot3D1.getBaseSectionOutlinePaint();
        org.jfree.data.general.PieDataset pieDataset10 = null;
        piePlot3D1.setDataset(pieDataset10);
        org.jfree.chart.plot.Plot plot12 = piePlot3D1.getParent();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer14 = new org.jfree.chart.renderer.category.StackedBarRenderer();
        org.jfree.chart.block.BlockContainer blockContainer15 = new org.jfree.chart.block.BlockContainer();
        blockContainer15.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer21 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder26 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer21.setFrame((org.jfree.chart.block.BlockFrame) blockBorder26);
        blockContainer15.add((org.jfree.chart.block.Block) blockContainer21);
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.util.Size2D size2D30 = blockContainer21.arrange(graphics2D29);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D34 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D30, (double) '#', (double) 1.0f, rectangleAnchor33);
        boolean boolean35 = stackedBarRenderer14.equals((java.lang.Object) rectangle2D34);
        org.jfree.data.general.PieDataset pieDataset36 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D37 = new org.jfree.chart.plot.PiePlot3D(pieDataset36);
        piePlot3D37.setDepthFactor((double) (byte) 1);
        piePlot3D37.setDepthFactor(0.0d);
        java.awt.Stroke stroke42 = piePlot3D37.getLabelLinkStroke();
        double double43 = piePlot3D37.getShadowXOffset();
        java.lang.String str44 = piePlot3D37.getNoDataMessage();
        java.awt.Paint paint45 = piePlot3D37.getBackgroundPaint();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset47 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range48 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset47);
        org.jfree.data.xy.XYDataset xYDataset49 = null;
        org.jfree.chart.axis.ValueAxis valueAxis50 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer51 = null;
        org.jfree.chart.plot.PolarPlot polarPlot52 = new org.jfree.chart.plot.PolarPlot(xYDataset49, valueAxis50, polarItemRenderer51);
        defaultCategoryDataset47.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot52);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo55 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo56 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo55);
        java.awt.geom.Point2D point2D57 = null;
        polarPlot52.zoomDomainAxes((double) '#', plotRenderingInfo56, point2D57);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo59 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo60 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo59);
        plotRenderingInfo56.addSubplotInfo(plotRenderingInfo60);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo63 = plotRenderingInfo56.getSubplotInfo((int) (byte) 0);
        try {
            org.jfree.chart.plot.PiePlotState piePlotState64 = piePlot3D1.initialise(graphics2D13, rectangle2D34, (org.jfree.chart.plot.PiePlot) piePlot3D37, (java.lang.Integer) (-1), plotRenderingInfo63);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(plot12);
        org.junit.Assert.assertNotNull(size2D30);
        org.junit.Assert.assertNotNull(rectangleAnchor33);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 4.0d + "'", double43 == 4.0d);
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNull(range48);
        org.junit.Assert.assertNotNull(plotRenderingInfo63);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDepthFactor((double) (byte) 1);
        piePlot3D1.setDepthFactor(0.0d);
        java.awt.Stroke stroke6 = piePlot3D1.getLabelLinkStroke();
        double double7 = piePlot3D1.getShadowXOffset();
        java.lang.String str8 = piePlot3D1.getNoDataMessage();
        java.awt.Paint paint9 = piePlot3D1.getBaseSectionOutlinePaint();
        java.awt.Paint paint11 = piePlot3D1.getSectionOutlinePaint((java.lang.Comparable) 0.0d);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator12 = piePlot3D1.getLegendLabelToolTipGenerator();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNull(pieSectionLabelGenerator12);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor3 = null;
        try {
            org.jfree.chart.axis.NumberTick numberTick5 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 1.0f, "{0}", textAnchor2, textAnchor3, 2.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rotationAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor2);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, polarItemRenderer3);
        org.jfree.data.Range range5 = null;
        try {
            numberAxis2.setRangeWithMargins(range5, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainCrosshairPaint();
        int int2 = xYPlot0.getSeriesCount();
        java.awt.Paint paint3 = xYPlot0.getRangeZeroBaselinePaint();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        int int5 = xYPlot0.indexOf(xYDataset4);
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset7, valueAxis8, polarItemRenderer9);
        java.lang.Object obj11 = null;
        boolean boolean12 = polarPlot10.equals(obj11);
        int int13 = polarPlot10.getSeriesCount();
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        polarPlot10.setAngleLabelPaint((java.awt.Paint) color14);
        try {
            xYPlot0.setQuadrantPaint((int) '4', (java.awt.Paint) color14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(color14);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.renderer.OutlierListCollection outlierListCollection0 = new org.jfree.chart.renderer.OutlierListCollection();
        outlierListCollection0.setLowFarOut(false);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        double double1 = levelRenderer0.getMaximumItemWidth();
        levelRenderer0.setItemMargin((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        java.util.TimeZone timeZone0 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone0;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone0;
        org.junit.Assert.assertNotNull(timeZone0);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDepthFactor((double) (byte) 1);
        piePlot3D1.setDepthFactor(0.0d);
        java.awt.Stroke[] strokeArray6 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        boolean boolean7 = piePlot3D1.equals((java.lang.Object) strokeArray6);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator8 = null;
        piePlot3D1.setLegendLabelURLGenerator(pieURLGenerator8);
        java.awt.Paint paint10 = piePlot3D1.getLabelOutlinePaint();
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D12 = new org.jfree.chart.plot.PiePlot3D(pieDataset11);
        piePlot3D12.setDepthFactor((double) (byte) 1);
        piePlot3D12.setDepthFactor(0.0d);
        piePlot3D12.setInteriorGap((double) 0.0f);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator19 = piePlot3D12.getURLGenerator();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator20 = piePlot3D12.getLabelGenerator();
        piePlot3D1.setLabelGenerator(pieSectionLabelGenerator20);
        java.awt.Paint paint22 = piePlot3D1.getLabelPaint();
        org.junit.Assert.assertNotNull(strokeArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(pieURLGenerator19);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator20);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDepthFactor((double) (byte) 1);
        piePlot3D1.setDepthFactor(0.0d);
        java.awt.Stroke stroke6 = piePlot3D1.getLabelLinkStroke();
        double double7 = piePlot3D1.getShadowXOffset();
        java.lang.String str8 = piePlot3D1.getNoDataMessage();
        java.awt.Paint paint9 = piePlot3D1.getBaseSectionOutlinePaint();
        org.jfree.data.general.PieDataset pieDataset10 = null;
        piePlot3D1.setDataset(pieDataset10);
        piePlot3D1.setLabelLinkMargin((double) (byte) 1);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D15 = new org.jfree.chart.plot.PiePlot3D(pieDataset14);
        piePlot3D15.setDepthFactor((double) (byte) 1);
        piePlot3D15.setDepthFactor(0.0d);
        java.awt.Stroke stroke20 = piePlot3D15.getLabelLinkStroke();
        double double21 = piePlot3D15.getShadowXOffset();
        java.lang.String str22 = piePlot3D15.getNoDataMessage();
        java.awt.Shape shape23 = piePlot3D15.getLegendItemShape();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer24 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer24.setDrawOutlines(true);
        java.awt.Color color27 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer24.setBasePaint((java.awt.Paint) color27, false);
        org.jfree.data.xy.XYDataset xYDataset31 = null;
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer33 = null;
        org.jfree.chart.plot.PolarPlot polarPlot34 = new org.jfree.chart.plot.PolarPlot(xYDataset31, valueAxis32, polarItemRenderer33);
        java.lang.Object obj35 = null;
        boolean boolean36 = polarPlot34.equals(obj35);
        int int37 = polarPlot34.getSeriesCount();
        java.awt.Color color38 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        polarPlot34.setAngleLabelPaint((java.awt.Paint) color38);
        statisticalLineAndShapeRenderer24.setSeriesFillPaint(2, (java.awt.Paint) color38);
        piePlot3D15.setBaseSectionOutlinePaint((java.awt.Paint) color38);
        piePlot3D1.setLabelShadowPaint((java.awt.Paint) color38);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 4.0d + "'", double21 == 4.0d);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(color38);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        java.awt.Color color3 = java.awt.Color.getHSBColor(0.0f, (float) 100L, (float) 1577865599999L);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("{0}");
        java.lang.String str2 = labelBlock1.getToolTipText();
        java.lang.String str3 = labelBlock1.getURLText();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double6 = rectangleInsets4.calculateBottomOutset(4.0d);
        labelBlock1.setMargin(rectangleInsets4);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor8 = org.jfree.chart.axis.CategoryAnchor.END;
        boolean boolean9 = rectangleInsets4.equals((java.lang.Object) categoryAnchor8);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(categoryAnchor8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(1.0d, (double) (short) -1);
        boolean boolean3 = stackedBarRenderer3D2.isDrawBarOutline();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer4 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        stackedBarRenderer3D2.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer4);
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType6 = standardGradientPaintTransformer4.getType();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(gradientPaintTransformType6);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setInverted(true);
        boolean boolean4 = numberAxis1.isAxisLineVisible();
        boolean boolean5 = numberAxis1.getAutoRangeStickyZero();
        java.awt.Stroke stroke6 = numberAxis1.getAxisLineStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis9.setInverted(true);
        boolean boolean12 = numberAxis9.isAxisLineVisible();
        boolean boolean13 = numberAxis9.getAutoRangeStickyZero();
        java.awt.Stroke stroke14 = numberAxis9.getAxisLineStroke();
        categoryPlot7.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis9);
        org.jfree.chart.axis.AxisLocation axisLocation17 = categoryPlot7.getRangeAxisLocation(0);
        float float18 = categoryPlot7.getBackgroundAlpha();
        numberAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot7);
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis23.setInverted(true);
        boolean boolean26 = numberAxis23.isAxisLineVisible();
        boolean boolean27 = numberAxis23.getAutoRangeStickyZero();
        java.awt.Stroke stroke28 = numberAxis23.getAxisLineStroke();
        categoryPlot21.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis23);
        org.jfree.chart.axis.AxisLocation axisLocation31 = categoryPlot21.getRangeAxisLocation(0);
        categoryPlot21.setAnchorValue((double) 1L);
        org.jfree.chart.axis.AxisLocation axisLocation35 = null;
        categoryPlot21.setRangeAxisLocation((int) (short) 10, axisLocation35, false);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset38 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range39 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset38);
        org.jfree.data.xy.XYDataset xYDataset40 = null;
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer42 = null;
        org.jfree.chart.plot.PolarPlot polarPlot43 = new org.jfree.chart.plot.PolarPlot(xYDataset40, valueAxis41, polarItemRenderer42);
        defaultCategoryDataset38.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot43);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo46 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo47 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo46);
        java.awt.geom.Point2D point2D48 = null;
        polarPlot43.zoomDomainAxes((double) '#', plotRenderingInfo47, point2D48);
        org.jfree.chart.block.BlockContainer blockContainer50 = new org.jfree.chart.block.BlockContainer();
        blockContainer50.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer56 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder61 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer56.setFrame((org.jfree.chart.block.BlockFrame) blockBorder61);
        blockContainer50.add((org.jfree.chart.block.Block) blockContainer56);
        java.awt.Graphics2D graphics2D64 = null;
        org.jfree.chart.util.Size2D size2D65 = blockContainer56.arrange(graphics2D64);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor68 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D69 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D65, (double) '#', (double) 1.0f, rectangleAnchor68);
        plotRenderingInfo47.setPlotArea(rectangle2D69);
        org.jfree.chart.plot.CategoryPlot categoryPlot71 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis73 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis73.setInverted(true);
        boolean boolean76 = numberAxis73.isAxisLineVisible();
        boolean boolean77 = numberAxis73.getAutoRangeStickyZero();
        java.awt.Stroke stroke78 = numberAxis73.getAxisLineStroke();
        categoryPlot71.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis73);
        org.jfree.chart.util.RectangleEdge rectangleEdge80 = categoryPlot71.getRangeAxisEdge();
        org.jfree.chart.axis.AxisSpace axisSpace81 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace82 = numberAxis1.reserveSpace(graphics2D20, (org.jfree.chart.plot.Plot) categoryPlot21, rectangle2D69, rectangleEdge80, axisSpace81);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 1.0f + "'", float18 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNull(range39);
        org.junit.Assert.assertNotNull(size2D65);
        org.junit.Assert.assertNotNull(rectangleAnchor68);
        org.junit.Assert.assertNotNull(rectangle2D69);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertNotNull(stroke78);
        org.junit.Assert.assertNotNull(rectangleEdge80);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(4, 0);
        java.util.Date date3 = month2.getEnd();
        int int4 = month2.getYearValue();
        java.util.Calendar calendar5 = null;
        try {
            month2.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setInverted(true);
        boolean boolean4 = numberAxis1.isAxisLineVisible();
        boolean boolean5 = numberAxis1.getAutoRangeStickyZero();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = numberAxis1.getLabelInsets();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(rectangleInsets6);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.MIDDLE;
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis2.setInverted(true);
        boolean boolean5 = numberAxis2.isAxisLineVisible();
        boolean boolean6 = numberAxis2.getAutoRangeStickyZero();
        java.awt.Stroke stroke7 = numberAxis2.getAxisLineStroke();
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis2);
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot0.getRangeAxisLocation(0);
        categoryPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer13 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean14 = statisticalLineAndShapeRenderer13.getDrawOutlines();
        statisticalLineAndShapeRenderer13.setAutoPopulateSeriesFillPaint(false);
        java.awt.Stroke stroke18 = statisticalLineAndShapeRenderer13.lookupSeriesStroke(28);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = statisticalLineAndShapeRenderer13.getBaseNegativeItemLabelPosition();
        org.jfree.data.general.PieDataset pieDataset20 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D21 = new org.jfree.chart.plot.PiePlot3D(pieDataset20);
        piePlot3D21.setDepthFactor((double) (byte) 1);
        piePlot3D21.setDepthFactor(0.0d);
        java.awt.Stroke stroke26 = piePlot3D21.getLabelLinkStroke();
        double double27 = piePlot3D21.getShadowXOffset();
        java.lang.String str28 = piePlot3D21.getNoDataMessage();
        java.awt.Paint paint29 = piePlot3D21.getBaseSectionOutlinePaint();
        org.jfree.data.general.PieDataset pieDataset30 = null;
        piePlot3D21.setDataset(pieDataset30);
        java.awt.Stroke stroke32 = piePlot3D21.getBaseSectionOutlineStroke();
        statisticalLineAndShapeRenderer13.setBaseStroke(stroke32, true);
        java.awt.Shape shape36 = statisticalLineAndShapeRenderer13.getSeriesShape((int) (short) 0);
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer13, true);
        org.jfree.chart.axis.AxisLocation axisLocation40 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot0.setRangeAxisLocation(0, axisLocation40);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent42 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent42);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 4.0d + "'", double27 == 4.0d);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNull(shape36);
        org.junit.Assert.assertNotNull(axisLocation40);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.CLASS_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ClassContext" + "'", str0.equals("ClassContext"));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(1, 255, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("");
        boolean boolean3 = taskSeries1.equals((java.lang.Object) 1L);
        java.util.List list4 = taskSeries1.getTasks();
        java.lang.Comparable comparable5 = taskSeries1.getKey();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + "" + "'", comparable5.equals(""));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer0.setDrawOutlines(true);
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer0.setBasePaint((java.awt.Paint) color3, false);
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset7, valueAxis8, polarItemRenderer9);
        java.lang.Object obj11 = null;
        boolean boolean12 = polarPlot10.equals(obj11);
        int int13 = polarPlot10.getSeriesCount();
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        polarPlot10.setAngleLabelPaint((java.awt.Paint) color14);
        statisticalLineAndShapeRenderer0.setSeriesFillPaint(2, (java.awt.Paint) color14);
        java.awt.Stroke stroke19 = statisticalLineAndShapeRenderer0.getItemStroke(0, 10);
        java.lang.Boolean boolean21 = statisticalLineAndShapeRenderer0.getSeriesCreateEntities((int) (short) -1);
        java.awt.Font font22 = statisticalLineAndShapeRenderer0.getBaseItemLabelFont();
        org.jfree.data.general.PieDataset pieDataset23 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D24 = new org.jfree.chart.plot.PiePlot3D(pieDataset23);
        piePlot3D24.setDepthFactor((double) (byte) 1);
        piePlot3D24.setDepthFactor(0.0d);
        java.awt.Stroke[] strokeArray29 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        boolean boolean30 = piePlot3D24.equals((java.lang.Object) strokeArray29);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator31 = null;
        piePlot3D24.setLegendLabelURLGenerator(pieURLGenerator31);
        java.awt.Paint paint33 = piePlot3D24.getLabelOutlinePaint();
        boolean boolean34 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) statisticalLineAndShapeRenderer0, (java.lang.Object) paint33);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(boolean21);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(strokeArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        org.jfree.chart.ui.Library[] libraryArray1 = projectInfo0.getOptionalLibraries();
        java.util.List list2 = projectInfo0.getContributors();
        java.util.List list3 = projectInfo0.getContributors();
        org.jfree.chart.ui.Library[] libraryArray4 = projectInfo0.getLibraries();
        org.junit.Assert.assertNotNull(libraryArray1);
        org.junit.Assert.assertNull(list2);
        org.junit.Assert.assertNull(list3);
        org.junit.Assert.assertNotNull(libraryArray4);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDepthFactor((double) (byte) 1);
        piePlot3D1.setDepthFactor(0.0d);
        java.awt.Stroke stroke6 = piePlot3D1.getLabelLinkStroke();
        double double7 = piePlot3D1.getShadowXOffset();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        int int9 = color8.getTransparency();
        piePlot3D1.setLabelLinkPaint((java.awt.Paint) color8);
        java.awt.Paint paint11 = piePlot3D1.getLabelBackgroundPaint();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        java.awt.Paint paint1 = null;
        java.awt.Font font3 = null;
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.jfree.chart.text.TextMeasurer textMeasurer6 = null;
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, (java.awt.Paint) color4, (float) ' ', textMeasurer6);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D9 = new org.jfree.chart.plot.PiePlot3D(pieDataset8);
        piePlot3D9.setDepthFactor((double) (byte) 1);
        piePlot3D9.setDepthFactor(0.0d);
        java.awt.Stroke stroke14 = piePlot3D9.getLabelLinkStroke();
        boolean boolean15 = textBlock7.equals((java.lang.Object) stroke14);
        try {
            org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker((double) 255, paint1, stroke14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.Marker marker1 = null;
        try {
            xYPlot0.addRangeMarker(marker1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDepthFactor((double) (byte) 1);
        piePlot3D1.setDepthFactor(0.0d);
        piePlot3D1.setInteriorGap((double) 0.0f);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator8 = piePlot3D1.getURLGenerator();
        org.jfree.data.general.PieDataset pieDataset9 = piePlot3D1.getDataset();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = piePlot3D1.getLegendLabelToolTipGenerator();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer12 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean13 = statisticalLineAndShapeRenderer12.getDrawOutlines();
        statisticalLineAndShapeRenderer12.setAutoPopulateSeriesFillPaint(false);
        java.lang.Object obj16 = statisticalLineAndShapeRenderer12.clone();
        java.awt.Stroke stroke17 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        statisticalLineAndShapeRenderer12.setBaseStroke(stroke17);
        statisticalLineAndShapeRenderer12.setBaseItemLabelsVisible(false, false);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        statisticalLineAndShapeRenderer12.setBaseFillPaint((java.awt.Paint) color22);
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = null;
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Font font29 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer30 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer30.setDrawOutlines(true);
        java.awt.Color color33 = org.jfree.chart.ChartColor.LIGHT_RED;
        statisticalLineAndShapeRenderer30.setBasePaint((java.awt.Paint) color33, false);
        org.jfree.chart.text.TextMeasurer textMeasurer37 = null;
        org.jfree.chart.text.TextBlock textBlock38 = org.jfree.chart.text.TextUtilities.createTextBlock("", font29, (java.awt.Paint) color33, (float) (byte) -1, textMeasurer37);
        numberAxis27.setTickMarkPaint((java.awt.Paint) color33);
        org.jfree.chart.plot.Marker marker40 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset41 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range42 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset41);
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer45 = null;
        org.jfree.chart.plot.PolarPlot polarPlot46 = new org.jfree.chart.plot.PolarPlot(xYDataset43, valueAxis44, polarItemRenderer45);
        defaultCategoryDataset41.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot46);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo49 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo50 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo49);
        java.awt.geom.Point2D point2D51 = null;
        polarPlot46.zoomDomainAxes((double) '#', plotRenderingInfo50, point2D51);
        org.jfree.chart.block.BlockContainer blockContainer53 = new org.jfree.chart.block.BlockContainer();
        blockContainer53.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer59 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder64 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer59.setFrame((org.jfree.chart.block.BlockFrame) blockBorder64);
        blockContainer53.add((org.jfree.chart.block.Block) blockContainer59);
        java.awt.Graphics2D graphics2D67 = null;
        org.jfree.chart.util.Size2D size2D68 = blockContainer59.arrange(graphics2D67);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor71 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D72 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D68, (double) '#', (double) 1.0f, rectangleAnchor71);
        plotRenderingInfo50.setPlotArea(rectangle2D72);
        statisticalLineAndShapeRenderer12.drawRangeMarker(graphics2D24, categoryPlot25, (org.jfree.chart.axis.ValueAxis) numberAxis27, marker40, rectangle2D72);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity75 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D72);
        java.awt.geom.Point2D point2D76 = null;
        org.jfree.chart.plot.PlotState plotState77 = new org.jfree.chart.plot.PlotState();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset78 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range79 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset78);
        org.jfree.data.xy.XYDataset xYDataset80 = null;
        org.jfree.chart.axis.ValueAxis valueAxis81 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer82 = null;
        org.jfree.chart.plot.PolarPlot polarPlot83 = new org.jfree.chart.plot.PolarPlot(xYDataset80, valueAxis81, polarItemRenderer82);
        defaultCategoryDataset78.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot83);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo86 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo87 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo86);
        java.awt.geom.Point2D point2D88 = null;
        polarPlot83.zoomDomainAxes((double) '#', plotRenderingInfo87, point2D88);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo90 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo91 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo90);
        plotRenderingInfo87.addSubplotInfo(plotRenderingInfo91);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo94 = plotRenderingInfo87.getSubplotInfo((int) (byte) 0);
        try {
            piePlot3D1.draw(graphics2D11, rectangle2D72, point2D76, plotState77, plotRenderingInfo94);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(pieURLGenerator8);
        org.junit.Assert.assertNull(pieDataset9);
        org.junit.Assert.assertNull(pieSectionLabelGenerator10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(textBlock38);
        org.junit.Assert.assertNull(range42);
        org.junit.Assert.assertNotNull(size2D68);
        org.junit.Assert.assertNotNull(rectangleAnchor71);
        org.junit.Assert.assertNotNull(rectangle2D72);
        org.junit.Assert.assertNull(range79);
        org.junit.Assert.assertNotNull(plotRenderingInfo94);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.util.UnitType unitType0 = null;
        try {
            org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 2958465, (double) 1577865599999L, 19.0d, (double) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unitType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        int int5 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) 10L);
        java.lang.Number number6 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.0d + "'", number6.equals(0.0d));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        double double1 = ganttRenderer0.getItemMargin();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        ganttRenderer0.setIncompletePaint((java.awt.Paint) color2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean1 = statisticalLineAndShapeRenderer0.getDrawOutlines();
        statisticalLineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(false);
        statisticalLineAndShapeRenderer0.setBaseSeriesVisible(true, true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        java.awt.Color color0 = java.awt.Color.blue;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        boxAndWhiskerRenderer0.setItemMargin(19.0d);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(1.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = stackedBarRenderer3D2.getGradientPaintTransformer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = stackedBarRenderer3D2.getBaseItemLabelGenerator();
        stackedBarRenderer3D2.setBaseSeriesVisible(false);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D(pieDataset7);
        piePlot3D8.setDepthFactor((double) (byte) 1);
        piePlot3D8.setCircular(true, true);
        boolean boolean14 = stackedBarRenderer3D2.equals((java.lang.Object) true);
        java.awt.Font font16 = null;
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.jfree.chart.text.TextMeasurer textMeasurer19 = null;
        org.jfree.chart.text.TextBlock textBlock20 = org.jfree.chart.text.TextUtilities.createTextBlock("", font16, (java.awt.Paint) color17, (float) ' ', textMeasurer19);
        org.jfree.data.general.PieDataset pieDataset21 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D22 = new org.jfree.chart.plot.PiePlot3D(pieDataset21);
        piePlot3D22.setDepthFactor((double) (byte) 1);
        piePlot3D22.setDepthFactor(0.0d);
        java.awt.Stroke stroke27 = piePlot3D22.getLabelLinkStroke();
        boolean boolean28 = textBlock20.equals((java.lang.Object) stroke27);
        boolean boolean29 = stackedBarRenderer3D2.equals((java.lang.Object) boolean28);
        org.junit.Assert.assertNotNull(gradientPaintTransformer3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(textBlock20);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("EXPAND", "", "", "EXPAND");
        java.lang.String str5 = library4.getInfo();
        java.lang.String str6 = library4.getLicenceName();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "EXPAND" + "'", str5.equals("EXPAND"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("");
        boolean boolean3 = taskSeries1.equals((java.lang.Object) 1L);
        org.jfree.data.gantt.Task task4 = null;
        taskSeries1.remove(task4);
        java.lang.String str6 = taskSeries1.getDescription();
        int int7 = taskSeries1.getItemCount();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0L, (byte) 0 };
        java.lang.Number[][] numberArray7 = new java.lang.Number[][] { numberArray6 };
        org.jfree.data.category.CategoryDataset categoryDataset8 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleConstraintType.RANGE", "RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]", numberArray7);
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "org.jfree.chart.event.ChartProgressEvent[source=false]", numberArray7);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(categoryDataset8);
        org.junit.Assert.assertNotNull(categoryDataset9);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        java.awt.Paint paint0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        intervalBarRenderer0.setDrawBarOutline(false);
        intervalBarRenderer0.setSeriesCreateEntities(0, (java.lang.Boolean) false, false);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.util.Layer layer0 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str1 = layer0.toString();
        org.junit.Assert.assertNotNull(layer0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Layer.FOREGROUND" + "'", str1.equals("Layer.FOREGROUND"));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE12;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1, textAnchor2, (double) 1L);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertNotNull(textAnchor2);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean1 = statisticalLineAndShapeRenderer0.getDrawOutlines();
        statisticalLineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(false);
        java.lang.Object obj4 = statisticalLineAndShapeRenderer0.clone();
        java.awt.Paint paint5 = statisticalLineAndShapeRenderer0.getBaseFillPaint();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) 255);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions1, categoryLabelPosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'right' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.setMargin((double) (byte) -1, (double) (short) 1, (double) 100, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockBorder blockBorder11 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 0L, (double) '#', (double) 0.0f);
        blockContainer6.setFrame((org.jfree.chart.block.BlockFrame) blockBorder11);
        blockContainer0.add((org.jfree.chart.block.Block) blockContainer6);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.util.Size2D size2D15 = blockContainer6.arrange(graphics2D14);
        boolean boolean16 = blockContainer6.isEmpty();
        java.lang.Object obj17 = blockContainer6.clone();
        org.junit.Assert.assertNotNull(size2D15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(obj17);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("Polar Plot", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = numberAxis1.getMarkerBand();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = numberAxis1.getMarkerBand();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = numberAxis1.getLabelInsets();
        double double6 = rectangleInsets4.trimWidth((double) 3);
        org.junit.Assert.assertNull(markerAxisBand2);
        org.junit.Assert.assertNull(markerAxisBand3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-3.0d) + "'", double6 == (-3.0d));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean1 = statisticalLineAndShapeRenderer0.getDrawOutlines();
        statisticalLineAndShapeRenderer0.setBaseSeriesVisible(true, false);
        java.awt.Font font6 = null;
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) numberAxis9, polarItemRenderer10);
        float float12 = polarPlot11.getBackgroundAlpha();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer13 = polarPlot11.getRenderer();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font6, (org.jfree.chart.plot.Plot) polarPlot11, false);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent18 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) false, jFreeChart15, 6, 0);
        org.jfree.chart.event.ChartProgressListener chartProgressListener19 = null;
        jFreeChart15.removeProgressListener(chartProgressListener19);
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        java.awt.geom.Point2D point2D23 = null;
        org.jfree.chart.entity.EntityCollection entityCollection24 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo25 = new org.jfree.chart.ChartRenderingInfo(entityCollection24);
        try {
            jFreeChart15.draw(graphics2D21, rectangle2D22, point2D23, chartRenderingInfo25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 1.0f + "'", float12 == 1.0f);
        org.junit.Assert.assertNull(polarItemRenderer13);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(255);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("");
        boolean boolean3 = taskSeries1.equals((java.lang.Object) 1L);
        org.jfree.data.gantt.Task task4 = null;
        taskSeries1.remove(task4);
        java.lang.Object obj6 = taskSeries1.clone();
        try {
            org.jfree.data.gantt.Task task8 = taskSeries1.get((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(obj6);
    }
}

