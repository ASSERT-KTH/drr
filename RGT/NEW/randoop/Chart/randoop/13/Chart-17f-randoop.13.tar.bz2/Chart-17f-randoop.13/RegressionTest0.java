import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int0 = org.jfree.data.time.SerialDate.MONDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.lang.Class class1 = null;
        java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", class1);
        org.junit.Assert.assertNotNull(inputStream2);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int0 = org.jfree.data.time.SerialDate.FIRST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = month0.getMiddleMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(0, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(100, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.lang.ClassLoader classLoader0 = null;
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_SECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("hi!");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addYears(12, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 100, 0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        int int0 = org.jfree.data.time.SerialDate.NEAREST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        int int0 = org.jfree.data.time.SerialDate.PRECEDING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) '4', (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass1 = month0.getClass();
        boolean boolean3 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month0, (java.lang.Object) 10.0d);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = month0.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        java.lang.ClassLoader classLoader0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
        org.junit.Assert.assertNull(classLoader0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        int int0 = org.jfree.data.time.SerialDate.MINIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1900 + "'", int0 == 1900);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.THREAD_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addYears((int) (short) -1, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.CLASS_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ClassContext" + "'", str0.equals("ClassContext"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("ThreadContext");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass1 = month0.getClass();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = month0.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        int int0 = org.jfree.data.time.SerialDate.TUESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("ThreadContext");
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        int int0 = org.jfree.data.time.SerialDate.FOLLOWING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_UPPER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2958465 + "'", int0 == 2958465);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        int int0 = org.jfree.data.time.SerialDate.FRIDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(9);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 9");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) ' ');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(false);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass1 = month0.getClass();
        boolean boolean3 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month0, (java.lang.Object) 10.0d);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = month0.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(10, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) (short) 100, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        org.junit.Assert.assertNotNull(strArray0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        java.text.DateFormatSymbols dateFormatSymbols0 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        org.junit.Assert.assertNotNull(dateFormatSymbols0);
    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test056");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getMiddleMillisecond(calendar2);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560440360054L + "'", long3 == 1560440360054L);
//    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        int int0 = org.jfree.data.time.SerialDate.WEDNESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) (short) 1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Following" + "'", str1.equals("Following"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(13);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        int int0 = org.jfree.data.time.SerialDate.LAST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addDays((int) (byte) -1, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (short) 1, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        int int0 = org.jfree.data.time.SerialDate.THIRD_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (32) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) '4', serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(8, (int) '4', (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(13, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("hi!");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2958465, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        try {
            java.lang.Object obj1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        int int0 = org.jfree.data.time.SerialDate.SATURDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year1.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
        long long2 = year1.getLastMillisecond();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year1.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2177424000001L) + "'", long2 == (-2177424000001L));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test076");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
//        java.lang.Class<?> wildcardClass2 = fixedMillisecond0.getClass();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getMiddleMillisecond(calendar3);
//        long long5 = fixedMillisecond0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560440361053L + "'", long4 == 1560440361053L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560440361053L + "'", long5 == 1560440361053L);
//    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        try {
            java.lang.Number number8 = timeSeries6.getValue((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass1 = month0.getClass();
        boolean boolean3 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month0, (java.lang.Object) 10.0d);
        long long4 = month0.getLastMillisecond();
        java.util.Calendar calendar5 = null;
        try {
            month0.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
        long long2 = year1.getLastMillisecond();
        java.util.Calendar calendar3 = null;
        try {
            year1.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2177424000001L) + "'", long2 == (-2177424000001L));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        java.lang.Object obj17 = new java.lang.Object();
        boolean boolean18 = timeSeries6.equals(obj17);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        java.lang.Object obj0 = null;
        try {
            java.lang.Object obj1 = org.jfree.chart.util.ObjectUtilities.clone(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'object' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addDays(4, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) ' ');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        int int4 = month2.compareTo((java.lang.Object) 1L);
        long long5 = month2.getLastMillisecond();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month2, (double) 1560440359600L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1561964399999L + "'", long5 == 1561964399999L);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(2);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Monday" + "'", str1.equals("Monday"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        int int19 = month17.compareTo((java.lang.Object) 1L);
        long long20 = month17.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month17.next();
        try {
            timeSeries6.add(regularTimePeriod21, (java.lang.Number) 0.0d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1561964399999L + "'", long20 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year1.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(regularTimePeriod2);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        java.util.List list7 = timeSeries6.getItems();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(1900);
        long long10 = year9.getLastMillisecond();
        try {
            timeSeries6.add((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) (-1L));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-2177424000001L) + "'", long10 == (-2177424000001L));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test091");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
//        java.lang.Class<?> wildcardClass2 = fixedMillisecond0.getClass();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getMiddleMillisecond(calendar3);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) (byte) 10);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560440362150L + "'", long4 == 1560440362150L);
//    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        try {
            org.jfree.data.time.TimeSeries timeSeries19 = timeSeries16.createCopy((int) (byte) 100, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d);
        java.util.Collection collection19 = timeSeries6.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries18.addOrUpdate(regularTimePeriod20, (java.lang.Number) 1560440360054L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(collection19);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        try {
            java.lang.Object obj1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        int int0 = org.jfree.data.time.SerialDate.FOURTH_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(3);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((int) (short) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-457) + "'", int1 == (-457));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        java.util.List list7 = timeSeries6.getItems();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeries6.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(list7);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        long long3 = year1.getSerialIndex();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year1.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1900L + "'", long3 == 1900L);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Monday");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int2 = month0.compareTo((java.lang.Object) 1L);
        long long3 = month0.getLastMillisecond();
        int int5 = month0.compareTo((java.lang.Object) 'a');
        java.lang.String str6 = month0.toString();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1561964399999L + "'", long3 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d);
        java.util.Collection collection19 = timeSeries6.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = null;
        try {
            java.lang.Number number21 = timeSeries18.getValue(regularTimePeriod20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(collection19);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (java.lang.Number) 10.0f);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year1.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass21 = month20.getClass();
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
        timeSeries23.setDomainDescription("");
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries16.addAndOrUpdate(timeSeries23);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = timeSeries23.getTimePeriod((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertNotNull(timeSeries26);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(1900);
        try {
            org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(0, year2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass21 = month20.getClass();
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
        java.util.List list24 = timeSeries23.getItems();
        boolean boolean25 = timeSeries16.equals((java.lang.Object) list24);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries16.getDataItem((-457));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertNotNull(list24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Monday");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(2);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Second" + "'", str1.equals("Second"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
        int int3 = year1.compareTo((java.lang.Object) 0);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year1.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries6.addPropertyChangeListener(propertyChangeListener7);
        try {
            java.lang.Number number10 = timeSeries6.getValue((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass21 = month20.getClass();
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
        java.util.List list24 = timeSeries23.getItems();
        boolean boolean25 = timeSeries16.equals((java.lang.Object) list24);
        boolean boolean27 = timeSeries16.equals((java.lang.Object) false);
        try {
            org.jfree.data.time.TimeSeries timeSeries30 = timeSeries16.createCopy(4, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertNotNull(list24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(31);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test119");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getLastMillisecond(calendar10);
//        try {
//            timeSeries6.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (java.lang.Number) 2, true);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560440365813L + "'", long11 == 1560440365813L);
//    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
        java.lang.Class<?> wildcardClass2 = fixedMillisecond0.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) 1561964399999L);
        java.lang.Number number5 = timeSeriesDataItem4.getValue();
        int int7 = timeSeriesDataItem4.compareTo((java.lang.Object) 100.0d);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.561964399999E12d + "'", number5.equals(1.561964399999E12d));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(2);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass21 = month20.getClass();
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
        timeSeries23.setDomainDescription("");
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries16.addAndOrUpdate(timeSeries23);
        java.lang.String str27 = timeSeries16.getDescription();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNull(str27);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        timeSeries6.fireSeriesChanged();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeries6.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) (short) 1, true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Jan" + "'", str2.equals("Jan"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(1900);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(12, 12, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(10);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "October" + "'", str1.equals("October"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (byte) 1, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(0, serialDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int2 = month0.compareTo((java.lang.Object) 1L);
        int int3 = month0.getMonth();
        java.util.Calendar calendar4 = null;
        try {
            month0.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass21 = month20.getClass();
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
        java.util.List list24 = timeSeries23.getItems();
        boolean boolean25 = timeSeries16.equals((java.lang.Object) list24);
        boolean boolean27 = timeSeries16.equals((java.lang.Object) false);
        try {
            java.lang.Number number29 = timeSeries16.getValue(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertNotNull(list24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(2, 9, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Jan");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.clear();
        try {
            timeSeries6.delete(0, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
    }

//    @Test
//    public void test135() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test135");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.SerialDate serialDate2 = null;
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        int int4 = day3.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate7 = serialDate5.getFollowingDayOfWeek(2);
//        java.lang.String str8 = serialDate7.toString();
//        try {
//            boolean boolean10 = spreadsheetDate1.isInRange(serialDate2, serialDate7, (int) (short) 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "17-June-2019" + "'", str8.equals("17-June-2019"));
//    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_FIRST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test137");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = day0.equals(obj1);
//        java.lang.String str3 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = day0.getLastMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//    }

//    @Test
//    public void test138() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test138");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = day0.equals(obj1);
//        java.lang.String str3 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        long long5 = day0.getLastMillisecond();
//        int int7 = day0.compareTo((java.lang.Object) 100L);
//        java.util.Calendar calendar8 = null;
//        try {
//            day0.peg(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560495599999L + "'", long5 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_LOWER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate2 = null;
        try {
            boolean boolean3 = spreadsheetDate1.isBefore(serialDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        int int0 = org.jfree.data.time.SerialDate.MAXIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean4 = spreadsheetDate2.equals((java.lang.Object) 31);
        try {
            org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (short) 10, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int2 = month0.compareTo((java.lang.Object) 1L);
        int int3 = month0.getMonth();
        boolean boolean5 = month0.equals((java.lang.Object) 1.561964399999E12d);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "", "17-June-2019", class5);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries6.removeChangeListener(seriesChangeListener7);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = timeSeries6.getTimePeriod((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(12, false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "December" + "'", str2.equals("December"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        long long3 = year1.getSerialIndex();
        java.util.Date date4 = year1.getStart();
        java.util.TimeZone timeZone5 = null;
        try {
            org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date4, timeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1900L + "'", long3 == 1900L);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        try {
            int int3 = spreadsheetDate1.compareTo((java.lang.Object) 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Float cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass21 = month20.getClass();
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
        java.util.List list24 = timeSeries23.getItems();
        boolean boolean25 = timeSeries16.equals((java.lang.Object) list24);
        timeSeries16.removeAgedItems(false);
        try {
            timeSeries16.delete((int) (short) 100, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertNotNull(list24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        long long3 = year1.getSerialIndex();
        java.util.Date date4 = year1.getStart();
        java.util.TimeZone timeZone5 = null;
        try {
            org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date4, timeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1900L + "'", long3 == 1900L);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        try {
            org.jfree.data.time.SerialDate serialDate3 = spreadsheetDate1.getFollowingDayOfWeek((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        java.lang.Object obj0 = null;
        boolean boolean2 = org.jfree.chart.util.ObjectUtilities.equal(obj0, (java.lang.Object) 1560440370684L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test155");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.setDomainDescription("");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass13 = month12.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond19.next();
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond19.getLastMillisecond(calendar21);
//        long long23 = fixedMillisecond19.getSerialIndex();
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass26 = month25.getClass();
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass26);
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass29 = month28.getClass();
//        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
//        java.lang.Object obj31 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class27, class30);
//        boolean boolean32 = fixedMillisecond19.equals((java.lang.Object) class30);
//        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) year18, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
//        java.util.Calendar calendar34 = null;
//        try {
//            long long35 = year18.getLastMillisecond(calendar34);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560440371177L + "'", long22 == 1560440371177L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560440371177L + "'", long23 == 1560440371177L);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertNull(obj31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(timeSeries33);
//    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        long long2 = month0.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1559372400000L + "'", long2 == 1559372400000L);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass6 = month5.getClass();
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass9 = month8.getClass();
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        java.lang.Object obj11 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class7, class10);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        java.lang.Object obj15 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ThreadContext", class7, (java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440363591L, class7);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass18 = month17.getClass();
        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass18);
        java.lang.Object obj20 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Following", class7, class19);
        java.net.URL uRL21 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("Jan", class7);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNull(obj15);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(class19);
        org.junit.Assert.assertNull(obj20);
        org.junit.Assert.assertNull(uRL21);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass7 = month6.getClass();
        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
        java.lang.Object obj9 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class5, class8);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass11 = month10.getClass();
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        java.lang.Object obj13 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ThreadContext", class5, (java.lang.Class) wildcardClass11);
        java.net.URL uRL14 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("Thu Jun 13 08:39:19 PDT 2019", class5);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(class8);
        org.junit.Assert.assertNull(obj9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertNull(obj13);
        org.junit.Assert.assertNull(uRL14);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = null;
        try {
            int int3 = timeSeries1.getIndex(regularTimePeriod2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.clear();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass12 = month11.getClass();
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class13);
        timeSeries14.setDomainDescription("");
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass21 = month20.getClass();
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries14.addAndOrUpdate(timeSeries23);
        java.lang.String str25 = timeSeries23.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries6.addAndOrUpdate(timeSeries23);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener27 = null;
        timeSeries6.removeChangeListener(seriesChangeListener27);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = timeSeries6.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "ThreadContext" + "'", str25.equals("ThreadContext"));
        org.junit.Assert.assertNotNull(timeSeries26);
    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test161");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
//        long long2 = fixedMillisecond0.getFirstMillisecond();
//        java.lang.Object obj3 = null;
//        int int4 = fixedMillisecond0.compareTo(obj3);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440371446L + "'", long2 == 1560440371446L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d);
        java.util.Collection collection19 = timeSeries6.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass21 = month20.getClass();
        boolean boolean23 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month20, (java.lang.Object) 10.0d);
        long long24 = month20.getLastMillisecond();
        org.jfree.data.time.Year year25 = month20.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month20.next();
        try {
            timeSeries18.add(regularTimePeriod26, (double) 1560440365499L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1561964399999L + "'", long24 == 1561964399999L);
        org.junit.Assert.assertNotNull(year25);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) -1, (-1), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        try {
            timeSeries6.update((int) (byte) 100, (java.lang.Number) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
    }

//    @Test
//    public void test165() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test165");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
//        java.lang.Class<?> wildcardClass2 = fixedMillisecond0.getClass();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) 1561964399999L);
//        java.util.Date date5 = fixedMillisecond0.getStart();
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond0.getFirstMillisecond(calendar6);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560440372354L + "'", long7 == 1560440372354L);
//    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int2 = month0.compareTo((java.lang.Object) 1L);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = month0.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(4);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

//    @Test
//    public void test168() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test168");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
//        java.lang.Class<?> wildcardClass2 = fixedMillisecond0.getClass();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) 1561964399999L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond5.next();
//        java.lang.Class<?> wildcardClass7 = fixedMillisecond5.getClass();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond5.getMiddleMillisecond(calendar8);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond5.previous();
//        boolean boolean11 = timeSeriesDataItem4.equals((java.lang.Object) fixedMillisecond5);
//        long long12 = fixedMillisecond5.getLastMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560440372578L + "'", long9 == 1560440372578L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560440372578L + "'", long12 == 1560440372578L);
//    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass1 = month0.getClass();
        boolean boolean3 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month0, (java.lang.Object) 10.0d);
        long long4 = month0.getLastMillisecond();
        try {
            java.lang.Object obj5 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) month0);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
    }

//    @Test
//    public void test170() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test170");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean3 = spreadsheetDate1.equals((java.lang.Object) 31);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int6 = spreadsheetDate5.toSerial();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate9 = day7.getSerialDate();
//        boolean boolean10 = spreadsheetDate5.isOnOrAfter(serialDate9);
//        org.jfree.data.time.SerialDate serialDate11 = null;
//        try {
//            boolean boolean13 = spreadsheetDate1.isInRange(serialDate9, serialDate11, 9999);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 13 + "'", int8 == 13);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = month0.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("December");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 12 + "'", int1 == 12);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

//    @Test
//    public void test174() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test174");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.setDomainDescription("");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass13 = month12.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass21 = month20.getClass();
//        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
//        timeSeries23.setDomainDescription("");
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries16.addAndOrUpdate(timeSeries23);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        java.lang.Object obj28 = null;
//        boolean boolean29 = day27.equals(obj28);
//        java.lang.String str30 = day27.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day27.previous();
//        long long32 = day27.getLastMillisecond();
//        int int34 = day27.compareTo((java.lang.Object) 100L);
//        java.util.Date date35 = day27.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = null;
//        try {
//            org.jfree.data.time.TimeSeries timeSeries37 = timeSeries23.createCopy((org.jfree.data.time.RegularTimePeriod) day27, regularTimePeriod36);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'end' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(class22);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "13-June-2019" + "'", str30.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560495599999L + "'", long32 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertNotNull(date35);
//    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass21 = month20.getClass();
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
        timeSeries23.setDomainDescription("");
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries16.addAndOrUpdate(timeSeries23);
        java.beans.PropertyChangeListener propertyChangeListener27 = null;
        timeSeries23.removePropertyChangeListener(propertyChangeListener27);
        java.lang.Object obj29 = null;
        boolean boolean30 = timeSeries23.equals(obj29);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

//    @Test
//    public void test176() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test176");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.setDomainDescription("");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass13 = month12.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond19.next();
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond19.getLastMillisecond(calendar21);
//        long long23 = fixedMillisecond19.getSerialIndex();
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass26 = month25.getClass();
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass26);
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass29 = month28.getClass();
//        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
//        java.lang.Object obj31 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class27, class30);
//        boolean boolean32 = fixedMillisecond19.equals((java.lang.Object) class30);
//        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) year18, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
//        java.lang.String str34 = timeSeries33.getDomainDescription();
//        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass39 = month38.getClass();
//        java.lang.Class class40 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass39);
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class40);
//        timeSeries41.setDomainDescription("");
//        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass48 = month47.getClass();
//        java.lang.Class class49 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass48);
//        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class49);
//        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries41.addAndOrUpdate(timeSeries50);
//        java.lang.String str52 = timeSeries51.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries33.addAndOrUpdate(timeSeries51);
//        boolean boolean55 = timeSeries53.equals((java.lang.Object) 1560440368245L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar57 = null;
//        long long58 = fixedMillisecond56.getLastMillisecond(calendar57);
//        try {
//            timeSeries53.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond56, (double) '#', true);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560440374061L + "'", long22 == 1560440374061L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560440374061L + "'", long23 == 1560440374061L);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertNull(obj31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(timeSeries33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
//        org.junit.Assert.assertNotNull(wildcardClass39);
//        org.junit.Assert.assertNotNull(class40);
//        org.junit.Assert.assertNotNull(wildcardClass48);
//        org.junit.Assert.assertNotNull(class49);
//        org.junit.Assert.assertNotNull(timeSeries51);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "Time" + "'", str52.equals("Time"));
//        org.junit.Assert.assertNotNull(timeSeries53);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1560440374074L + "'", long58 == 1560440374074L);
//    }

//    @Test
//    public void test177() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test177");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        int int3 = day0.getMonth();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = day0.getLastMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(serialDate4);
//    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (java.lang.Number) 10.0f);
        java.util.Calendar calendar4 = null;
        try {
            year1.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        timeSeries6.fireSeriesChanged();
        int int18 = timeSeries6.getItemCount();
        try {
            timeSeries6.delete((int) (short) 100, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((-1));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 1, 2, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test182");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.setDomainDescription("");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass13 = month12.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        java.lang.Object obj18 = null;
//        boolean boolean19 = day17.equals(obj18);
//        int int20 = day17.getMonth();
//        java.lang.Number number21 = null;
//        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) day17, number21, true);
//        long long24 = day17.getSerialIndex();
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 43629L + "'", long24 == 43629L);
//    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        java.lang.String str7 = timeSeries6.getDescription();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = timeSeries6.getTimePeriod((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.time.TimePeriodFormatException: ");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(8);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((-457));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test188() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test188");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = day0.equals(obj1);
//        java.lang.String str3 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        long long5 = day0.getLastMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond6.getLastMillisecond(calendar7);
//        boolean boolean10 = fixedMillisecond6.equals((java.lang.Object) 1561964399999L);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 1561964399999L);
//        int int12 = day0.compareTo((java.lang.Object) 1561964399999L);
//        long long13 = day0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560495599999L + "'", long5 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560440375447L + "'", long8 == 1560440375447L);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560495599999L + "'", long13 == 1560495599999L);
//    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass3 = month2.getClass();
        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass6 = month5.getClass();
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
        java.lang.Object obj8 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class4, class7);
        java.net.URL uRL9 = org.jfree.chart.util.ObjectUtilities.getResource("ClassContext", class4);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(class4);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertNull(uRL9);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
        int int3 = year1.compareTo((java.lang.Object) 0);
        long long4 = year1.getLastMillisecond();
        long long5 = year1.getFirstMillisecond();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year1.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-2177424000001L) + "'", long4 == (-2177424000001L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-2208960000000L) + "'", long5 == (-2208960000000L));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass21 = month20.getClass();
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
        timeSeries23.setDomainDescription("");
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries16.addAndOrUpdate(timeSeries23);
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = fixedMillisecond27.next();
        java.lang.Class<?> wildcardClass29 = fixedMillisecond27.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, (double) 1561964399999L);
        try {
            timeSeries26.add(timeSeriesDataItem31);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(wildcardClass29);
    }

//    @Test
//    public void test193() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test193");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
//        java.lang.Class<?> wildcardClass2 = fixedMillisecond0.getClass();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getMiddleMillisecond(calendar3);
//        boolean boolean6 = fixedMillisecond0.equals((java.lang.Object) 1560440372506L);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560440377163L + "'", long4 == 1560440377163L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = fixedMillisecond17.next();
        java.lang.Class<?> wildcardClass19 = fixedMillisecond17.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, (double) 1561964399999L);
        try {
            timeSeries15.add(timeSeriesDataItem21);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

//    @Test
//    public void test195() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test195");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate4 = serialDate2.getFollowingDayOfWeek(2);
//        serialDate2.setDescription("1-January-1900");
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertNotNull(serialDate4);
//    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean3 = spreadsheetDate1.equals((java.lang.Object) 31);
        java.util.Date date4 = spreadsheetDate1.toDate();
        java.util.TimeZone timeZone5 = null;
        try {
            org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4, timeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("Time");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(1900);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

//    @Test
//    public void test200() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test200");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getLastMillisecond(calendar2);
//        long long4 = fixedMillisecond0.getSerialIndex();
//        long long5 = fixedMillisecond0.getSerialIndex();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560440377938L + "'", long3 == 1560440377938L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560440377938L + "'", long4 == 1560440377938L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560440377938L + "'", long5 == 1560440377938L);
//    }

//    @Test
//    public void test201() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test201");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = day0.equals(obj1);
//        java.lang.String str3 = day0.toString();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getLastMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.lang.Object obj1 = null;
        boolean boolean2 = day0.equals(obj1);
        int int3 = day0.getYear();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
    }

//    @Test
//    public void test203() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test203");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.setDomainDescription("");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass13 = month12.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond19.next();
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond19.getLastMillisecond(calendar21);
//        long long23 = fixedMillisecond19.getSerialIndex();
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass26 = month25.getClass();
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass26);
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass29 = month28.getClass();
//        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
//        java.lang.Object obj31 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class27, class30);
//        boolean boolean32 = fixedMillisecond19.equals((java.lang.Object) class30);
//        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) year18, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
//        java.lang.String str34 = timeSeries33.getDomainDescription();
//        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass39 = month38.getClass();
//        java.lang.Class class40 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass39);
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class40);
//        timeSeries41.setDomainDescription("");
//        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass48 = month47.getClass();
//        java.lang.Class class49 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass48);
//        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class49);
//        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries41.addAndOrUpdate(timeSeries50);
//        java.lang.String str52 = timeSeries51.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries33.addAndOrUpdate(timeSeries51);
//        java.lang.String str54 = timeSeries53.getDescription();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem55 = null;
//        try {
//            timeSeries53.add(timeSeriesDataItem55, false);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560440378610L + "'", long22 == 1560440378610L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560440378610L + "'", long23 == 1560440378610L);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertNull(obj31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(timeSeries33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
//        org.junit.Assert.assertNotNull(wildcardClass39);
//        org.junit.Assert.assertNotNull(class40);
//        org.junit.Assert.assertNotNull(wildcardClass48);
//        org.junit.Assert.assertNotNull(class49);
//        org.junit.Assert.assertNotNull(timeSeries51);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "Time" + "'", str52.equals("Time"));
//        org.junit.Assert.assertNotNull(timeSeries53);
//        org.junit.Assert.assertNull(str54);
//    }

//    @Test
//    public void test204() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test204");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = day0.equals(obj1);
//        java.lang.String str3 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        long long5 = day0.getLastMillisecond();
//        int int7 = day0.compareTo((java.lang.Object) 100L);
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass12 = month11.getClass();
//        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class13);
//        timeSeries14.setDomainDescription("");
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass21 = month20.getClass();
//        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries14.addAndOrUpdate(timeSeries23);
//        java.lang.String str25 = timeSeries24.getDomainDescription();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
//        timeSeries24.addChangeListener(seriesChangeListener26);
//        boolean boolean28 = day0.equals((java.lang.Object) seriesChangeListener26);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560495599999L + "'", long5 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNotNull(class13);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(class22);
//        org.junit.Assert.assertNotNull(timeSeries24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Time" + "'", str25.equals("Time"));
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(9999);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

//    @Test
//    public void test206() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test206");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
//        java.lang.Class<?> wildcardClass2 = fixedMillisecond0.getClass();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) 1561964399999L);
//        java.util.Calendar calendar5 = null;
//        fixedMillisecond0.peg(calendar5);
//        long long7 = fixedMillisecond0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560440379023L + "'", long7 == 1560440379023L);
//    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int2 = month0.compareTo((java.lang.Object) 1L);
        long long3 = month0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month0.next();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = month0.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1561964399999L + "'", long3 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

//    @Test
//    public void test208() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test208");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "", "17-June-2019", class5);
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
//        long long10 = year8.getSerialIndex();
//        java.util.Date date11 = year8.getStart();
//        long long12 = year8.getFirstMillisecond();
//        int int13 = year8.getYear();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.lang.Object obj15 = null;
//        boolean boolean16 = day14.equals(obj15);
//        java.lang.String str17 = day14.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day14.previous();
//        int int19 = year8.compareTo((java.lang.Object) day14);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day14.previous();
//        try {
//            timeSeries6.update(regularTimePeriod20, (java.lang.Number) 1560440377163L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1900L + "'", long10 == 1900L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-2208960000000L) + "'", long12 == (-2208960000000L));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1900 + "'", int13 == 1900);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "13-June-2019" + "'", str17.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//    }

//    @Test
//    public void test209() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test209");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        java.util.Calendar calendar2 = null;
//        try {
//            long long3 = day0.getFirstMillisecond(calendar2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test211() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test211");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = day0.equals(obj1);
//        java.lang.String str3 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        long long5 = day0.getLastMillisecond();
//        int int7 = day0.compareTo((java.lang.Object) 100L);
//        java.util.Date date8 = day0.getEnd();
//        java.util.TimeZone timeZone9 = null;
//        try {
//            org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date8, timeZone9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560495599999L + "'", long5 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertNotNull(date8);
//    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test212");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int2 = month0.compareTo((java.lang.Object) 1L);
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        int int5 = month3.compareTo((java.lang.Object) 1L);
//        long long6 = month3.getLastMillisecond();
//        int int7 = month0.compareTo((java.lang.Object) long6);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond8.getLastMillisecond(calendar9);
//        boolean boolean12 = fixedMillisecond8.equals((java.lang.Object) 1561964399999L);
//        long long13 = fixedMillisecond8.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (double) 13);
//        boolean boolean17 = timeSeriesDataItem15.equals((java.lang.Object) "org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d));
//        boolean boolean20 = timeSeriesDataItem15.equals((java.lang.Object) (-1.0d));
//        int int21 = month0.compareTo((java.lang.Object) timeSeriesDataItem15);
//        java.util.Calendar calendar22 = null;
//        try {
//            long long23 = month0.getFirstMillisecond(calendar22);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1561964399999L + "'", long6 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560440380094L + "'", long10 == 1560440380094L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560440380094L + "'", long13 == 1560440380094L);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.previous();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = month0.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
        java.lang.Class<?> wildcardClass2 = fixedMillisecond0.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) 1561964399999L);
        java.util.Date date5 = fixedMillisecond0.getStart();
        java.util.TimeZone timeZone6 = null;
        try {
            org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date5, timeZone6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(date5);
    }

//    @Test
//    public void test215() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test215");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.setDomainDescription("");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass13 = month12.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond19.next();
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond19.getLastMillisecond(calendar21);
//        long long23 = fixedMillisecond19.getSerialIndex();
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass26 = month25.getClass();
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass26);
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass29 = month28.getClass();
//        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
//        java.lang.Object obj31 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class27, class30);
//        boolean boolean32 = fixedMillisecond19.equals((java.lang.Object) class30);
//        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) year18, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
//        java.lang.String str34 = timeSeries33.getDomainDescription();
//        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass39 = month38.getClass();
//        java.lang.Class class40 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass39);
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class40);
//        timeSeries41.setDomainDescription("");
//        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass48 = month47.getClass();
//        java.lang.Class class49 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass48);
//        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class49);
//        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries41.addAndOrUpdate(timeSeries50);
//        java.lang.String str52 = timeSeries51.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries33.addAndOrUpdate(timeSeries51);
//        java.lang.String str54 = timeSeries53.getDescription();
//        java.beans.PropertyChangeListener propertyChangeListener55 = null;
//        timeSeries53.addPropertyChangeListener(propertyChangeListener55);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560440380176L + "'", long22 == 1560440380176L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560440380176L + "'", long23 == 1560440380176L);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertNull(obj31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(timeSeries33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
//        org.junit.Assert.assertNotNull(wildcardClass39);
//        org.junit.Assert.assertNotNull(class40);
//        org.junit.Assert.assertNotNull(wildcardClass48);
//        org.junit.Assert.assertNotNull(class49);
//        org.junit.Assert.assertNotNull(timeSeries51);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "Time" + "'", str52.equals("Time"));
//        org.junit.Assert.assertNotNull(timeSeries53);
//        org.junit.Assert.assertNull(str54);
//    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("13-June-2019");
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass21 = month20.getClass();
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
        timeSeries23.setDomainDescription("");
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries16.addAndOrUpdate(timeSeries23);
        java.beans.PropertyChangeListener propertyChangeListener27 = null;
        timeSeries23.removePropertyChangeListener(propertyChangeListener27);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month29.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month29.previous();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(1900);
        long long34 = year33.getLastMillisecond();
        boolean boolean35 = month29.equals((java.lang.Object) year33);
        try {
            timeSeries23.add((org.jfree.data.time.RegularTimePeriod) month29, (java.lang.Number) 1560440367722L, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-2177424000001L) + "'", long34 == (-2177424000001L));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(2, (int) '#', 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        try {
            java.lang.Object obj1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) (-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
    }

//    @Test
//    public void test220() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test220");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.setDomainDescription("");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass13 = month12.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond19.next();
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond19.getLastMillisecond(calendar21);
//        long long23 = fixedMillisecond19.getSerialIndex();
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass26 = month25.getClass();
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass26);
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass29 = month28.getClass();
//        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
//        java.lang.Object obj31 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class27, class30);
//        boolean boolean32 = fixedMillisecond19.equals((java.lang.Object) class30);
//        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) year18, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
//        java.lang.String str34 = timeSeries33.getDomainDescription();
//        timeSeries33.removeAgedItems(1560440369753L, false);
//        boolean boolean39 = timeSeries33.equals((java.lang.Object) 100);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560440381532L + "'", long22 == 1560440381532L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560440381532L + "'", long23 == 1560440381532L);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertNull(obj31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(timeSeries33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//    }

//    @Test
//    public void test221() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test221");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean4 = spreadsheetDate2.equals((java.lang.Object) 31);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        int int6 = day5.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate9 = serialDate7.getFollowingDayOfWeek(2);
//        java.lang.String str10 = serialDate9.toString();
//        boolean boolean11 = spreadsheetDate2.isOnOrBefore(serialDate9);
//        try {
//            org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (short) 10, serialDate9);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 13 + "'", int6 == 13);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "17-June-2019" + "'", str10.equals("17-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) '#');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test223() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test223");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.setDomainDescription("");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass13 = month12.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond19.next();
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond19.getLastMillisecond(calendar21);
//        long long23 = fixedMillisecond19.getSerialIndex();
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass26 = month25.getClass();
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass26);
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass29 = month28.getClass();
//        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
//        java.lang.Object obj31 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class27, class30);
//        boolean boolean32 = fixedMillisecond19.equals((java.lang.Object) class30);
//        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) year18, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
//        long long34 = year18.getSerialIndex();
//        java.util.Calendar calendar35 = null;
//        try {
//            long long36 = year18.getLastMillisecond(calendar35);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560440381888L + "'", long22 == 1560440381888L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560440381888L + "'", long23 == 1560440381888L);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertNull(obj31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(timeSeries33);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1900L + "'", long34 == 1900L);
//    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        timeSeries6.fireSeriesChanged();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        int int20 = month18.compareTo((java.lang.Object) 1L);
        long long21 = month18.getLastMillisecond();
        int int23 = month18.compareTo((java.lang.Object) 'a');
        int int24 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month18);
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timeSeries6.removePropertyChangeListener(propertyChangeListener25);
        java.beans.PropertyChangeListener propertyChangeListener27 = null;
        timeSeries6.addPropertyChangeListener(propertyChangeListener27);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1561964399999L + "'", long21 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
    }

//    @Test
//    public void test225() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test225");
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        int int2 = day1.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate3 = day1.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate5 = serialDate3.getFollowingDayOfWeek(2);
//        java.lang.String str6 = serialDate5.toString();
//        org.jfree.data.time.SerialDate serialDate8 = serialDate5.getNearestDayOfWeek((int) (byte) 1);
//        try {
//            org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) '#', serialDate5);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "17-June-2019" + "'", str6.equals("17-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate8);
//    }

//    @Test
//    public void test226() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test226");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        java.util.List list7 = timeSeries6.getItems();
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar11 = null;
//        long long12 = fixedMillisecond10.getLastMillisecond(calendar11);
//        boolean boolean14 = fixedMillisecond10.equals((java.lang.Object) 1561964399999L);
//        long long15 = fixedMillisecond10.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (double) 13);
//        java.lang.Object obj18 = timeSeriesDataItem17.clone();
//        int int19 = year9.compareTo((java.lang.Object) timeSeriesDataItem17);
//        java.lang.Object obj20 = timeSeriesDataItem17.clone();
//        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass25 = month24.getClass();
//        java.lang.Class class26 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass25);
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class26);
//        timeSeries27.setDomainDescription("");
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass34 = month33.getClass();
//        java.lang.Class class35 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass34);
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class35);
//        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries27.addAndOrUpdate(timeSeries36);
//        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = fixedMillisecond40.next();
//        java.util.Calendar calendar42 = null;
//        long long43 = fixedMillisecond40.getLastMillisecond(calendar42);
//        long long44 = fixedMillisecond40.getSerialIndex();
//        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass47 = month46.getClass();
//        java.lang.Class class48 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass47);
//        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass50 = month49.getClass();
//        java.lang.Class class51 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass50);
//        java.lang.Object obj52 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class48, class51);
//        boolean boolean53 = fixedMillisecond40.equals((java.lang.Object) class51);
//        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries36.createCopy((org.jfree.data.time.RegularTimePeriod) year39, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond40);
//        java.lang.String str55 = timeSeries54.getDomainDescription();
//        org.jfree.data.time.Month month59 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass60 = month59.getClass();
//        java.lang.Class class61 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass60);
//        org.jfree.data.time.TimeSeries timeSeries62 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class61);
//        timeSeries62.setDomainDescription("");
//        org.jfree.data.time.Month month68 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass69 = month68.getClass();
//        java.lang.Class class70 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass69);
//        org.jfree.data.time.TimeSeries timeSeries71 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class70);
//        org.jfree.data.time.TimeSeries timeSeries72 = timeSeries62.addAndOrUpdate(timeSeries71);
//        java.lang.String str73 = timeSeries72.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries74 = timeSeries54.addAndOrUpdate(timeSeries72);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond75 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = fixedMillisecond75.next();
//        long long77 = regularTimePeriod76.getMiddleMillisecond();
//        boolean boolean78 = timeSeries54.equals((java.lang.Object) regularTimePeriod76);
//        boolean boolean79 = timeSeriesDataItem17.equals((java.lang.Object) timeSeries54);
//        try {
//            timeSeries6.add(timeSeriesDataItem17);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(list7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560440382016L + "'", long12 == 1560440382016L);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560440382016L + "'", long15 == 1560440382016L);
//        org.junit.Assert.assertNotNull(obj18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertNotNull(obj20);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertNotNull(class26);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNotNull(class35);
//        org.junit.Assert.assertNotNull(timeSeries37);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560440382020L + "'", long43 == 1560440382020L);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560440382020L + "'", long44 == 1560440382020L);
//        org.junit.Assert.assertNotNull(wildcardClass47);
//        org.junit.Assert.assertNotNull(class48);
//        org.junit.Assert.assertNotNull(wildcardClass50);
//        org.junit.Assert.assertNotNull(class51);
//        org.junit.Assert.assertNull(obj52);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(timeSeries54);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "hi!" + "'", str55.equals("hi!"));
//        org.junit.Assert.assertNotNull(wildcardClass60);
//        org.junit.Assert.assertNotNull(class61);
//        org.junit.Assert.assertNotNull(wildcardClass69);
//        org.junit.Assert.assertNotNull(class70);
//        org.junit.Assert.assertNotNull(timeSeries72);
//        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "Time" + "'", str73.equals("Time"));
//        org.junit.Assert.assertNotNull(timeSeries74);
//        org.junit.Assert.assertNotNull(regularTimePeriod76);
//        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 1560440382035L + "'", long77 == 1560440382035L);
//        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
//        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
//    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (byte) 10, 2958465);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

//    @Test
//    public void test228() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test228");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getLastMillisecond(calendar2);
//        long long4 = fixedMillisecond0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond0.previous();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560440382622L + "'", long3 == 1560440382622L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560440382622L + "'", long4 == 1560440382622L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(3, true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mar" + "'", str2.equals("Mar"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        long long3 = year1.getSerialIndex();
        java.util.Date date4 = year1.getStart();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        java.lang.Object obj6 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) date4);
        org.junit.Assert.assertNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1900L + "'", long3 == 1900L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        timeSeries6.fireSeriesChanged();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        int int20 = month18.compareTo((java.lang.Object) 1L);
        long long21 = month18.getLastMillisecond();
        int int23 = month18.compareTo((java.lang.Object) 'a');
        int int24 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = null;
        try {
            java.lang.Number number26 = timeSeries6.getValue(regularTimePeriod25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1561964399999L + "'", long21 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.clear();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass12 = month11.getClass();
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class13);
        timeSeries14.setDomainDescription("");
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass21 = month20.getClass();
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries14.addAndOrUpdate(timeSeries23);
        java.lang.String str25 = timeSeries23.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries6.addAndOrUpdate(timeSeries23);
        java.lang.String str27 = timeSeries23.getDescription();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "ThreadContext" + "'", str25.equals("ThreadContext"));
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNull(str27);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((int) (short) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-460) + "'", int1 == (-460));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(11);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 11");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass21 = month20.getClass();
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
        java.util.List list24 = timeSeries23.getItems();
        boolean boolean25 = timeSeries16.equals((java.lang.Object) list24);
        boolean boolean27 = timeSeries16.equals((java.lang.Object) false);
        java.lang.String str28 = timeSeries16.getDescription();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = null;
        try {
            timeSeries16.add(timeSeriesDataItem29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertNotNull(list24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(str28);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean3 = spreadsheetDate1.equals((java.lang.Object) 31);
        java.util.Date date4 = spreadsheetDate1.toDate();
        boolean boolean6 = spreadsheetDate1.equals((java.lang.Object) 1560440366809L);
        java.lang.String str7 = spreadsheetDate1.getDescription();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(str7);
    }

//    @Test
//    public void test238() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test238");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        fixedMillisecond0.peg(calendar1);
//        long long3 = fixedMillisecond0.getSerialIndex();
//        long long4 = fixedMillisecond0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560440383751L + "'", long3 == 1560440383751L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560440383751L + "'", long4 == 1560440383751L);
//    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) -1);
        java.lang.String str2 = seriesChangeEvent1.toString();
        java.lang.Object obj3 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=-1]"));
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + (byte) -1 + "'", obj3.equals((byte) -1));
    }

//    @Test
//    public void test240() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test240");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.setDomainDescription("");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass13 = month12.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass21 = month20.getClass();
//        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
//        java.util.List list24 = timeSeries23.getItems();
//        boolean boolean25 = timeSeries16.equals((java.lang.Object) list24);
//        timeSeries16.removeAgedItems(false);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        int int29 = day28.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day28.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries16.getDataItem(regularTimePeriod30);
//        try {
//            timeSeries16.delete(0, 31);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(class22);
//        org.junit.Assert.assertNotNull(list24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 13 + "'", int29 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNull(timeSeriesDataItem31);
//    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        long long3 = year1.getSerialIndex();
        java.util.Date date4 = year1.getStart();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        java.util.TimeZone timeZone6 = null;
        try {
            org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date4, timeZone6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1900L + "'", long3 == 1900L);
        org.junit.Assert.assertNotNull(date4);
    }

//    @Test
//    public void test242() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test242");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int2 = spreadsheetDate1.toSerial();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        int int4 = day3.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
//        boolean boolean6 = spreadsheetDate1.isOnOrAfter(serialDate5);
//        org.jfree.data.time.SerialDate serialDate7 = null;
//        try {
//            org.jfree.data.time.SerialDate serialDate8 = spreadsheetDate1.getEndOfCurrentMonth(serialDate7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
        java.lang.String str2 = year1.toString();
        java.util.Calendar calendar3 = null;
        try {
            year1.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1900" + "'", str2.equals("1900"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        java.lang.String str17 = timeSeries15.getRangeDescription();
        int int18 = timeSeries15.getMaximumItemCount();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = null;
        try {
            timeSeries15.add(regularTimePeriod19, (java.lang.Number) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ThreadContext" + "'", str17.equals("ThreadContext"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2147483647 + "'", int18 == 2147483647);
    }

//    @Test
//    public void test245() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test245");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.setDomainDescription("");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass13 = month12.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond19.next();
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond19.getLastMillisecond(calendar21);
//        long long23 = fixedMillisecond19.getSerialIndex();
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass26 = month25.getClass();
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass26);
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass29 = month28.getClass();
//        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
//        java.lang.Object obj31 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class27, class30);
//        boolean boolean32 = fixedMillisecond19.equals((java.lang.Object) class30);
//        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) year18, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
//        java.lang.String str34 = timeSeries33.getDomainDescription();
//        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass39 = month38.getClass();
//        java.lang.Class class40 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass39);
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class40);
//        timeSeries41.setDomainDescription("");
//        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass48 = month47.getClass();
//        java.lang.Class class49 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass48);
//        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class49);
//        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries41.addAndOrUpdate(timeSeries50);
//        java.lang.String str52 = timeSeries51.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries33.addAndOrUpdate(timeSeries51);
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = timeSeries51.getNextTimePeriod();
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560440384370L + "'", long22 == 1560440384370L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560440384370L + "'", long23 == 1560440384370L);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertNull(obj31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(timeSeries33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
//        org.junit.Assert.assertNotNull(wildcardClass39);
//        org.junit.Assert.assertNotNull(class40);
//        org.junit.Assert.assertNotNull(wildcardClass48);
//        org.junit.Assert.assertNotNull(class49);
//        org.junit.Assert.assertNotNull(timeSeries51);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "Time" + "'", str52.equals("Time"));
//        org.junit.Assert.assertNotNull(timeSeries53);
//    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 1);
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1);
        long long3 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (java.lang.Number) 10.0f);
        java.lang.String str4 = year1.toString();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year1.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1900" + "'", str4.equals("1900"));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("October");
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int2 = month0.compareTo((java.lang.Object) 1L);
        long long3 = month0.getLastMillisecond();
        long long4 = month0.getLastMillisecond();
        long long5 = month0.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1561964399999L + "'", long3 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 24234L + "'", long5 == 24234L);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        int int0 = org.jfree.data.time.SerialDate.SECOND_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

//    @Test
//    public void test252() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test252");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean2 = fixedMillisecond0.equals((java.lang.Object) 0.0d);
//        java.util.Calendar calendar3 = null;
//        fixedMillisecond0.peg(calendar3);
//        java.lang.String str5 = fixedMillisecond0.toString();
//        java.util.Date date6 = fixedMillisecond0.getStart();
//        java.util.TimeZone timeZone7 = null;
//        try {
//            org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date6, timeZone7);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Thu Jun 13 08:39:44 PDT 2019" + "'", str5.equals("Thu Jun 13 08:39:44 PDT 2019"));
//        org.junit.Assert.assertNotNull(date6);
//    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass1 = month0.getClass();
        int int2 = month0.getMonth();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = month0.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) '4', (int) (byte) 100, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("Second");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        int int0 = org.jfree.data.time.SerialDate.SUNDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

//    @Test
//    public void test259() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test259");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getLastMillisecond(calendar1);
//        boolean boolean4 = fixedMillisecond0.equals((java.lang.Object) 1561964399999L);
//        long long5 = fixedMillisecond0.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) 13);
//        boolean boolean9 = timeSeriesDataItem7.equals((java.lang.Object) "org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d));
//        boolean boolean12 = timeSeriesDataItem7.equals((java.lang.Object) (-1.0d));
//        java.lang.Object obj13 = timeSeriesDataItem7.clone();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440386255L + "'", long2 == 1560440386255L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560440386255L + "'", long5 == 1560440386255L);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(obj13);
//    }

//    @Test
//    public void test260() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test260");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getLastMillisecond(calendar2);
//        long long4 = fixedMillisecond0.getSerialIndex();
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass7 = month6.getClass();
//        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass10 = month9.getClass();
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
//        java.lang.Object obj12 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class8, class11);
//        boolean boolean13 = fixedMillisecond0.equals((java.lang.Object) class11);
//        long long14 = fixedMillisecond0.getFirstMillisecond();
//        long long15 = fixedMillisecond0.getSerialIndex();
//        java.lang.String str16 = fixedMillisecond0.toString();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560440386279L + "'", long3 == 1560440386279L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560440386279L + "'", long4 == 1560440386279L);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(class8);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertNull(obj12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560440386279L + "'", long14 == 1560440386279L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560440386279L + "'", long15 == 1560440386279L);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Thu Jun 13 08:39:46 PDT 2019" + "'", str16.equals("Thu Jun 13 08:39:46 PDT 2019"));
//    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addYears(13, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Value");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
        long long2 = year1.getLastMillisecond();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year1.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2177424000001L) + "'", long2 == (-2177424000001L));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("Thu Jun 13 08:39:19 PDT 2019");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException4);
        org.jfree.data.general.SeriesException seriesException7 = new org.jfree.data.general.SeriesException("");
        seriesException4.addSuppressed((java.lang.Throwable) seriesException7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Thu Jun 13 08:39:39 PDT 2019");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

//    @Test
//    public void test267() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test267");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getLastMillisecond(calendar2);
//        long long4 = fixedMillisecond0.getSerialIndex();
//        java.lang.Object obj5 = null;
//        int int6 = fixedMillisecond0.compareTo(obj5);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560440388087L + "'", long3 == 1560440388087L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560440388087L + "'", long4 == 1560440388087L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test268");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d);
//        timeSeries1.setMaximumItemCount((int) (short) 100);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond4.next();
//        java.lang.Class<?> wildcardClass6 = fixedMillisecond4.getClass();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (double) 1561964399999L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond9.next();
//        java.lang.Class<?> wildcardClass11 = fixedMillisecond9.getClass();
//        java.util.Calendar calendar12 = null;
//        long long13 = fixedMillisecond9.getMiddleMillisecond(calendar12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = fixedMillisecond9.previous();
//        boolean boolean15 = timeSeriesDataItem8.equals((java.lang.Object) fixedMillisecond9);
//        try {
//            timeSeries1.add(timeSeriesDataItem8, false);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560440388220L + "'", long13 == 1560440388220L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) str2);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

//    @Test
//    public void test270() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test270");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.setDomainDescription("");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass13 = month12.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond19.next();
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond19.getLastMillisecond(calendar21);
//        long long23 = fixedMillisecond19.getSerialIndex();
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass26 = month25.getClass();
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass26);
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass29 = month28.getClass();
//        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
//        java.lang.Object obj31 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class27, class30);
//        boolean boolean32 = fixedMillisecond19.equals((java.lang.Object) class30);
//        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) year18, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
//        java.lang.String str34 = timeSeries33.getDomainDescription();
//        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass39 = month38.getClass();
//        java.lang.Class class40 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass39);
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class40);
//        timeSeries41.setDomainDescription("");
//        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass48 = month47.getClass();
//        java.lang.Class class49 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass48);
//        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class49);
//        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries41.addAndOrUpdate(timeSeries50);
//        java.lang.String str52 = timeSeries51.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries33.addAndOrUpdate(timeSeries51);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = fixedMillisecond54.next();
//        long long56 = regularTimePeriod55.getMiddleMillisecond();
//        boolean boolean57 = timeSeries33.equals((java.lang.Object) regularTimePeriod55);
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = timeSeries33.getDataItem((int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560440388291L + "'", long22 == 1560440388291L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560440388291L + "'", long23 == 1560440388291L);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertNull(obj31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(timeSeries33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
//        org.junit.Assert.assertNotNull(wildcardClass39);
//        org.junit.Assert.assertNotNull(class40);
//        org.junit.Assert.assertNotNull(wildcardClass48);
//        org.junit.Assert.assertNotNull(class49);
//        org.junit.Assert.assertNotNull(timeSeries51);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "Time" + "'", str52.equals("Time"));
//        org.junit.Assert.assertNotNull(timeSeries53);
//        org.junit.Assert.assertNotNull(regularTimePeriod55);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1560440388303L + "'", long56 == 1560440388303L);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Thu Jun 13 08:39:42 PDT 2019");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean3 = spreadsheetDate1.equals((java.lang.Object) 31);
        java.util.Date date4 = spreadsheetDate1.toDate();
        boolean boolean6 = spreadsheetDate1.equals((java.lang.Object) 1560440366809L);
        spreadsheetDate1.setDescription("Thu Jun 13 08:39:26 PDT 2019");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = timeSeries1.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test274() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test274");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.setDomainDescription("");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass13 = month12.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass21 = month20.getClass();
//        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
//        timeSeries23.setDomainDescription("");
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries16.addAndOrUpdate(timeSeries23);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener27 = null;
//        timeSeries16.removeChangeListener(seriesChangeListener27);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = fixedMillisecond29.next();
//        java.lang.Class<?> wildcardClass31 = fixedMillisecond29.getClass();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, (double) 1561964399999L);
//        java.lang.Number number34 = timeSeries16.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
//        long long35 = fixedMillisecond29.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(class22);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertNull(number34);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560440388867L + "'", long35 == 1560440388867L);
//    }

//    @Test
//    public void test275() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test275");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        int int3 = day0.getMonth();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        long long5 = day0.getSerialIndex();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = day0.getLastMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43629L + "'", long5 == 43629L);
//    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(0, 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass21 = month20.getClass();
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
        timeSeries23.setDomainDescription("");
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries16.addAndOrUpdate(timeSeries23);
        java.lang.String str27 = timeSeries26.getDescription();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = timeSeries26.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNull(str27);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = null;
        try {
            java.lang.Number number3 = timeSeries1.getValue(regularTimePeriod2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((-1), false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        boolean boolean2 = fixedMillisecond0.equals((java.lang.Object) 0.0d);
        java.util.Calendar calendar3 = null;
        fixedMillisecond0.peg(calendar3);
        java.util.Date date5 = fixedMillisecond0.getTime();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(9);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.time.TimePeriodFormatException: ");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
        java.lang.Class<?> wildcardClass2 = fixedMillisecond0.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) 1561964399999L);
        java.util.Date date5 = fixedMillisecond0.getStart();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass11 = month10.getClass();
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class12);
        timeSeries13.clear();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass19);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class20);
        timeSeries21.setDomainDescription("");
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass28 = month27.getClass();
        java.lang.Class class29 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass28);
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class29);
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries21.addAndOrUpdate(timeSeries30);
        java.lang.String str32 = timeSeries30.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries13.addAndOrUpdate(timeSeries30);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener34 = null;
        timeSeries13.removeChangeListener(seriesChangeListener34);
        int int36 = day6.compareTo((java.lang.Object) timeSeries13);
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass41 = month40.getClass();
        java.lang.Class class42 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass41);
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class42);
        timeSeries43.setDomainDescription("");
        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass50 = month49.getClass();
        java.lang.Class class51 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass50);
        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class51);
        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries43.addAndOrUpdate(timeSeries52);
        org.jfree.data.time.Month month57 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass58 = month57.getClass();
        java.lang.Class class59 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass58);
        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class59);
        java.util.List list61 = timeSeries60.getItems();
        boolean boolean62 = timeSeries53.equals((java.lang.Object) list61);
        boolean boolean64 = timeSeries53.equals((java.lang.Object) false);
        java.beans.PropertyChangeListener propertyChangeListener65 = null;
        timeSeries53.removePropertyChangeListener(propertyChangeListener65);
        int int67 = day6.compareTo((java.lang.Object) propertyChangeListener65);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(class20);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNotNull(class29);
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "ThreadContext" + "'", str32.equals("ThreadContext"));
        org.junit.Assert.assertNotNull(timeSeries33);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertNotNull(class42);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertNotNull(class51);
        org.junit.Assert.assertNotNull(timeSeries53);
        org.junit.Assert.assertNotNull(wildcardClass58);
        org.junit.Assert.assertNotNull(class59);
        org.junit.Assert.assertNotNull(list61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
    }

//    @Test
//    public void test285() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test285");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        int int3 = day0.getDayOfMonth();
//        long long4 = day0.getLastMillisecond();
//        java.util.Calendar calendar5 = null;
//        try {
//            day0.peg(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560495599999L + "'", long4 == 1560495599999L);
//    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((-43619));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        int int0 = org.jfree.data.time.SerialDate.THURSDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        java.lang.Class<?> wildcardClass3 = fixedMillisecond1.getClass();
        java.net.URL uRL4 = org.jfree.chart.util.ObjectUtilities.getResource("October", (java.lang.Class) wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNull(uRL4);
    }

//    @Test
//    public void test290() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test290");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int2 = month0.compareTo((java.lang.Object) 1L);
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        int int5 = month3.compareTo((java.lang.Object) 1L);
//        long long6 = month3.getLastMillisecond();
//        int int7 = month0.compareTo((java.lang.Object) long6);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond8.getLastMillisecond(calendar9);
//        boolean boolean12 = fixedMillisecond8.equals((java.lang.Object) 1561964399999L);
//        long long13 = fixedMillisecond8.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (double) 13);
//        boolean boolean17 = timeSeriesDataItem15.equals((java.lang.Object) "org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d));
//        boolean boolean20 = timeSeriesDataItem15.equals((java.lang.Object) (-1.0d));
//        int int21 = month0.compareTo((java.lang.Object) timeSeriesDataItem15);
//        java.lang.Object obj22 = null;
//        int int23 = timeSeriesDataItem15.compareTo(obj22);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1561964399999L + "'", long6 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560440391210L + "'", long10 == 1560440391210L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560440391210L + "'", long13 == 1560440391210L);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//    }

//    @Test
//    public void test291() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test291");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = day0.equals(obj1);
//        java.lang.String str3 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        long long5 = day0.getLastMillisecond();
//        int int7 = day0.compareTo((java.lang.Object) 100L);
//        java.util.Date date8 = day0.getEnd();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day0);
//        java.lang.String str10 = seriesChangeEvent9.toString();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560495599999L + "'", long5 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=13-June-2019]" + "'", str10.equals("org.jfree.data.general.SeriesChangeEvent[source=13-June-2019]"));
//    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.clear();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass12 = month11.getClass();
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class13);
        timeSeries14.setDomainDescription("");
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass21 = month20.getClass();
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries14.addAndOrUpdate(timeSeries23);
        java.lang.String str25 = timeSeries23.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries6.addAndOrUpdate(timeSeries23);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener27 = null;
        timeSeries6.removeChangeListener(seriesChangeListener27);
        boolean boolean29 = timeSeries6.getNotify();
        try {
            timeSeries6.setMaximumItemCount((-43623));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'maximum' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "ThreadContext" + "'", str25.equals("ThreadContext"));
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (8) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d));
        int int2 = timeSeries1.getMaximumItemCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getYearValue();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
    }

//    @Test
//    public void test296() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test296");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        java.lang.String str2 = day0.toString();
//        int int3 = day0.getYear();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
        java.lang.Class<?> wildcardClass2 = fixedMillisecond0.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) 1561964399999L);
        java.util.Calendar calendar5 = null;
        fixedMillisecond0.peg(calendar5);
        java.util.Calendar calendar7 = null;
        fixedMillisecond0.peg(calendar7);
        int int10 = fixedMillisecond0.compareTo((java.lang.Object) "June 2019");
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

//    @Test
//    public void test298() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test298");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond7.next();
//        java.lang.Class<?> wildcardClass9 = fixedMillisecond7.getClass();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond7.getMiddleMillisecond(calendar10);
//        timeSeries6.setKey((java.lang.Comparable) long11);
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
//        int int15 = month13.compareTo((java.lang.Object) 1L);
//        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
//        int int18 = month16.compareTo((java.lang.Object) 1L);
//        long long19 = month16.getLastMillisecond();
//        int int20 = month13.compareTo((java.lang.Object) long19);
//        try {
//            timeSeries6.update((org.jfree.data.time.RegularTimePeriod) month13, (java.lang.Number) 1560440386647L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560440391607L + "'", long11 == 1560440391607L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1561964399999L + "'", long19 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        java.util.Collection collection0 = null;
        try {
            java.util.Collection collection1 = org.jfree.chart.util.ObjectUtilities.deepClone(collection0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'collection' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
        int int3 = year1.compareTo((java.lang.Object) 0);
        long long4 = year1.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year1.previous();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
        java.io.InputStream inputStream10 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass8);
        try {
            org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod5, (java.lang.Class) wildcardClass8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-2177424000001L) + "'", long4 == (-2177424000001L));
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertNotNull(inputStream10);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d);
        timeSeries1.clear();
        try {
            timeSeries1.delete(31, 1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 31, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test302() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test302");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getLastMillisecond(calendar2);
//        long long4 = fixedMillisecond0.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) 1560440384350L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond0.next();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond0.getFirstMillisecond(calendar8);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560440391666L + "'", long3 == 1560440391666L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560440391666L + "'", long4 == 1560440391666L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560440391666L + "'", long9 == 1560440391666L);
//    }

//    @Test
//    public void test303() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test303");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = day0.equals(obj1);
//        java.lang.String str3 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        long long5 = day0.getLastMillisecond();
//        int int7 = day0.compareTo((java.lang.Object) 100L);
//        java.util.Date date8 = day0.getEnd();
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
//        long long12 = year10.getSerialIndex();
//        java.util.Date date13 = year10.getStart();
//        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date13, timeZone14);
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date8, timeZone14);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560495599999L + "'", long5 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1900L + "'", long12 == 1900L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(timeZone14);
//    }

//    @Test
//    public void test304() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test304");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.clear();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass12 = month11.getClass();
//        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class13);
//        timeSeries14.setDomainDescription("");
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass21 = month20.getClass();
//        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries14.addAndOrUpdate(timeSeries23);
//        java.lang.String str25 = timeSeries23.getRangeDescription();
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries6.addAndOrUpdate(timeSeries23);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener27 = null;
//        timeSeries6.removeChangeListener(seriesChangeListener27);
//        boolean boolean29 = timeSeries6.getNotify();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = fixedMillisecond30.next();
//        java.lang.Class<?> wildcardClass32 = fixedMillisecond30.getClass();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (double) 1561964399999L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = fixedMillisecond35.next();
//        java.lang.Class<?> wildcardClass37 = fixedMillisecond35.getClass();
//        java.util.Calendar calendar38 = null;
//        long long39 = fixedMillisecond35.getMiddleMillisecond(calendar38);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = fixedMillisecond35.previous();
//        boolean boolean41 = timeSeriesDataItem34.equals((java.lang.Object) fixedMillisecond35);
//        java.lang.Number number42 = timeSeriesDataItem34.getValue();
//        try {
//            timeSeries6.add(timeSeriesDataItem34);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNotNull(class13);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(class22);
//        org.junit.Assert.assertNotNull(timeSeries24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "ThreadContext" + "'", str25.equals("ThreadContext"));
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(wildcardClass32);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(wildcardClass37);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560440392372L + "'", long39 == 1560440392372L);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + number42 + "' != '" + 1.561964399999E12d + "'", number42.equals(1.561964399999E12d));
//    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        timeSeries6.fireSeriesChanged();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        int int20 = month18.compareTo((java.lang.Object) 1L);
        long long21 = month18.getLastMillisecond();
        int int23 = month18.compareTo((java.lang.Object) 'a');
        int int24 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = null;
        try {
            timeSeries6.add(regularTimePeriod25, (double) 1560440372983L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1561964399999L + "'", long21 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "", "17-June-2019", class5);
        timeSeries6.setDescription("Thu Jun 13 08:39:43 PDT 2019");
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int11 = month9.compareTo((java.lang.Object) 1L);
        int int12 = month9.getMonth();
        try {
            timeSeries6.add((org.jfree.data.time.RegularTimePeriod) month9, (double) 1560440381532L, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d);
        java.util.Collection collection19 = timeSeries6.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries6.getDataItem((-457));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(collection19);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((-460));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (java.lang.Number) 10.0f);
        long long4 = year1.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-2193192000001L) + "'", long4 == (-2193192000001L));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        java.util.List list17 = timeSeries6.getItems();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeries6.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(list17);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int2 = month0.compareTo((java.lang.Object) 1L);
        long long3 = month0.getLastMillisecond();
        int int5 = month0.compareTo((java.lang.Object) 'a');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month0.previous();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1561964399999L + "'", long3 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d);
        timeSeries1.removeAgedItems(false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("December");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int2 = spreadsheetDate1.toSerial();
        int int3 = spreadsheetDate1.getMonth();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        java.lang.Class class2 = null;
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.lang.Object obj6 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class2, (java.lang.Class) wildcardClass4);
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.io.InputStream inputStream8 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNotNull(inputStream8);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass1 = month0.getClass();
        int int2 = month0.getMonth();
        long long3 = month0.getFirstMillisecond();
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1559372400000L + "'", long3 == 1559372400000L);
    }

//    @Test
//    public void test317() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test317");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean2 = fixedMillisecond0.equals((java.lang.Object) 0.0d);
//        java.util.Calendar calendar3 = null;
//        fixedMillisecond0.peg(calendar3);
//        java.lang.String str5 = fixedMillisecond0.toString();
//        java.util.Date date6 = fixedMillisecond0.getStart();
//        java.util.Calendar calendar7 = null;
//        fixedMillisecond0.peg(calendar7);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Thu Jun 13 08:39:53 PDT 2019" + "'", str5.equals("Thu Jun 13 08:39:53 PDT 2019"));
//        org.junit.Assert.assertNotNull(date6);
//    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2958465, (int) (short) -1, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass21 = month20.getClass();
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
        java.util.List list24 = timeSeries23.getItems();
        boolean boolean25 = timeSeries16.equals((java.lang.Object) list24);
        boolean boolean27 = timeSeries16.equals((java.lang.Object) false);
        java.lang.Object obj28 = timeSeries16.clone();
        boolean boolean30 = timeSeries16.equals((java.lang.Object) 1560440375447L);
        try {
            org.jfree.data.time.TimeSeries timeSeries33 = timeSeries16.createCopy((-43619), (-43623));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertNotNull(list24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

//    @Test
//    public void test320() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test320");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.clear();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass12 = month11.getClass();
//        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class13);
//        timeSeries14.setDomainDescription("");
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass21 = month20.getClass();
//        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries14.addAndOrUpdate(timeSeries23);
//        java.lang.String str25 = timeSeries23.getRangeDescription();
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries6.addAndOrUpdate(timeSeries23);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener27 = null;
//        timeSeries6.removeChangeListener(seriesChangeListener27);
//        timeSeries6.setDescription("Time");
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        int int32 = day31.getDayOfMonth();
//        java.lang.String str33 = day31.toString();
//        long long34 = day31.getLastMillisecond();
//        try {
//            timeSeries6.update((org.jfree.data.time.RegularTimePeriod) day31, (java.lang.Number) 1560440385051L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNotNull(class13);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(class22);
//        org.junit.Assert.assertNotNull(timeSeries24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "ThreadContext" + "'", str25.equals("ThreadContext"));
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 13 + "'", int32 == 13);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "13-June-2019" + "'", str33.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560495599999L + "'", long34 == 1560495599999L);
//    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        long long3 = year1.getSerialIndex();
        java.util.Date date4 = year1.getStart();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date4);
        long long7 = month6.getLastMillisecond();
        org.junit.Assert.assertNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1900L + "'", long3 == 1900L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2206281600001L) + "'", long7 == (-2206281600001L));
    }

//    @Test
//    public void test322() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test322");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.setDomainDescription("");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass13 = month12.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year18.previous();
//        long long20 = year18.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries16.getDataItem((org.jfree.data.time.RegularTimePeriod) year18);
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year23.previous();
//        long long25 = year23.getSerialIndex();
//        java.util.Date date26 = year23.getStart();
//        long long27 = year23.getFirstMillisecond();
//        java.lang.Number number28 = timeSeries16.getValue((org.jfree.data.time.RegularTimePeriod) year23);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean31 = fixedMillisecond29.equals((java.lang.Object) 0.0d);
//        java.util.Calendar calendar32 = null;
//        fixedMillisecond29.peg(calendar32);
//        long long34 = fixedMillisecond29.getSerialIndex();
//        java.lang.Number number35 = null;
//        try {
//            timeSeries16.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, number35, false);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1900L + "'", long20 == 1900L);
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1900L + "'", long25 == 1900L);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-2208960000000L) + "'", long27 == (-2208960000000L));
//        org.junit.Assert.assertNull(number28);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560440393816L + "'", long34 == 1560440393816L);
//    }

//    @Test
//    public void test323() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test323");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
//        java.lang.Class<?> wildcardClass2 = fixedMillisecond0.getClass();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) 1561964399999L);
//        java.util.Calendar calendar5 = null;
//        fixedMillisecond0.peg(calendar5);
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond0.getFirstMillisecond(calendar7);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560440393837L + "'", long8 == 1560440393837L);
//    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(3, false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "March" + "'", str2.equals("March"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass21 = month20.getClass();
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
        java.util.List list24 = timeSeries23.getItems();
        boolean boolean25 = timeSeries16.equals((java.lang.Object) list24);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = null;
        try {
            timeSeries16.add(timeSeriesDataItem26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertNotNull(list24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-435) + "'", int1 == (-435));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

//    @Test
//    public void test328() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test328");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        fixedMillisecond0.peg(calendar1);
//        long long3 = fixedMillisecond0.getSerialIndex();
//        long long4 = fixedMillisecond0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560440393938L + "'", long3 == 1560440393938L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560440393938L + "'", long4 == 1560440393938L);
//    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int2 = month0.compareTo((java.lang.Object) 1L);
        long long3 = month0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month0.next();
        int int6 = month0.compareTo((java.lang.Object) 1560440380567L);
        int int7 = month0.getMonth();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1561964399999L + "'", long3 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
    }

//    @Test
//    public void test330() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test330");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getLastMillisecond(calendar3);
//        boolean boolean6 = fixedMillisecond2.equals((java.lang.Object) 1561964399999L);
//        long long7 = fixedMillisecond2.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (double) 13);
//        java.lang.Object obj10 = timeSeriesDataItem9.clone();
//        int int11 = year1.compareTo((java.lang.Object) timeSeriesDataItem9);
//        java.lang.Object obj12 = timeSeriesDataItem9.clone();
//        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass17 = month16.getClass();
//        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass17);
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class18);
//        timeSeries19.setDomainDescription("");
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass26 = month25.getClass();
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass26);
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class27);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries19.addAndOrUpdate(timeSeries28);
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = fixedMillisecond32.next();
//        java.util.Calendar calendar34 = null;
//        long long35 = fixedMillisecond32.getLastMillisecond(calendar34);
//        long long36 = fixedMillisecond32.getSerialIndex();
//        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass39 = month38.getClass();
//        java.lang.Class class40 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass39);
//        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass42 = month41.getClass();
//        java.lang.Class class43 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass42);
//        java.lang.Object obj44 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class40, class43);
//        boolean boolean45 = fixedMillisecond32.equals((java.lang.Object) class43);
//        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries28.createCopy((org.jfree.data.time.RegularTimePeriod) year31, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond32);
//        java.lang.String str47 = timeSeries46.getDomainDescription();
//        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass52 = month51.getClass();
//        java.lang.Class class53 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass52);
//        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class53);
//        timeSeries54.setDomainDescription("");
//        org.jfree.data.time.Month month60 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass61 = month60.getClass();
//        java.lang.Class class62 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass61);
//        org.jfree.data.time.TimeSeries timeSeries63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class62);
//        org.jfree.data.time.TimeSeries timeSeries64 = timeSeries54.addAndOrUpdate(timeSeries63);
//        java.lang.String str65 = timeSeries64.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries66 = timeSeries46.addAndOrUpdate(timeSeries64);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond67 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = fixedMillisecond67.next();
//        long long69 = regularTimePeriod68.getMiddleMillisecond();
//        boolean boolean70 = timeSeries46.equals((java.lang.Object) regularTimePeriod68);
//        boolean boolean71 = timeSeriesDataItem9.equals((java.lang.Object) timeSeries46);
//        long long72 = timeSeries46.getMaximumItemAge();
//        java.beans.PropertyChangeListener propertyChangeListener73 = null;
//        timeSeries46.removePropertyChangeListener(propertyChangeListener73);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560440393980L + "'", long4 == 1560440393980L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560440393980L + "'", long7 == 1560440393980L);
//        org.junit.Assert.assertNotNull(obj10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(obj12);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(class18);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560440393984L + "'", long35 == 1560440393984L);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560440393984L + "'", long36 == 1560440393984L);
//        org.junit.Assert.assertNotNull(wildcardClass39);
//        org.junit.Assert.assertNotNull(class40);
//        org.junit.Assert.assertNotNull(wildcardClass42);
//        org.junit.Assert.assertNotNull(class43);
//        org.junit.Assert.assertNull(obj44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertNotNull(timeSeries46);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "hi!" + "'", str47.equals("hi!"));
//        org.junit.Assert.assertNotNull(wildcardClass52);
//        org.junit.Assert.assertNotNull(class53);
//        org.junit.Assert.assertNotNull(wildcardClass61);
//        org.junit.Assert.assertNotNull(class62);
//        org.junit.Assert.assertNotNull(timeSeries64);
//        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "Time" + "'", str65.equals("Time"));
//        org.junit.Assert.assertNotNull(timeSeries66);
//        org.junit.Assert.assertNotNull(regularTimePeriod68);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 1560440393993L + "'", long69 == 1560440393993L);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 9223372036854775807L + "'", long72 == 9223372036854775807L);
//    }

//    @Test
//    public void test331() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test331");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getLastMillisecond(calendar2);
//        long long4 = fixedMillisecond0.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass5 = fixedMillisecond0.getClass();
//        long long6 = fixedMillisecond0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560440394529L + "'", long3 == 1560440394529L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560440394529L + "'", long4 == 1560440394529L);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560440394529L + "'", long6 == 1560440394529L);
//    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(1, (-460), (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test334() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test334");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        int int3 = day0.getDayOfMonth();
//        long long4 = day0.getLastMillisecond();
//        int int5 = day0.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560495599999L + "'", long4 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d);
        timeSeries1.setMaximumItemCount((int) (short) 100);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class9);
        timeSeries10.setDomainDescription("");
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass17 = month16.getClass();
        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass17);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class18);
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries10.addAndOrUpdate(timeSeries19);
        timeSeries10.fireSeriesChanged();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        int int24 = month22.compareTo((java.lang.Object) 1L);
        long long25 = month22.getLastMillisecond();
        int int27 = month22.compareTo((java.lang.Object) 'a');
        int int28 = timeSeries10.getIndex((org.jfree.data.time.RegularTimePeriod) month22);
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month22, (java.lang.Number) 1560440382417L, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(class18);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1561964399999L + "'", long25 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        long long3 = year1.getSerialIndex();
        java.util.Date date4 = year1.getStart();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
        long long6 = month5.getSerialIndex();
        org.junit.Assert.assertNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1900L + "'", long3 == 1900L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 22801L + "'", long6 == 22801L);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
        long long2 = year1.getLastMillisecond();
        boolean boolean4 = year1.equals((java.lang.Object) 1.561964399999E12d);
        java.lang.String str5 = year1.toString();
        java.lang.String str6 = year1.toString();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2177424000001L) + "'", long2 == (-2177424000001L));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1900" + "'", str5.equals("1900"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1900" + "'", str6.equals("1900"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int2 = month0.compareTo((java.lang.Object) 1L);
        long long3 = month0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month0.next();
        int int6 = month0.compareTo((java.lang.Object) 1560440380567L);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = month0.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1561964399999L + "'", long3 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        long long3 = year1.getSerialIndex();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year1.getMiddleMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1900L + "'", long3 == 1900L);
    }

//    @Test
//    public void test340() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test340");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate4 = serialDate2.getFollowingDayOfWeek(2);
//        java.lang.String str5 = serialDate4.toString();
//        org.jfree.data.time.SerialDate serialDate7 = serialDate4.getNearestDayOfWeek((int) (byte) 1);
//        serialDate4.setDescription("October");
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "17-June-2019" + "'", str5.equals("17-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate7);
//    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        timeSeries6.fireSeriesChanged();
        timeSeries6.setNotify(true);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 1560440386255L);
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + 1560440386255L + "'", obj2.equals(1560440386255L));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("org.jfree.data.general.SeriesChangeEvent[source=-1]");
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean3 = spreadsheetDate1.equals((java.lang.Object) 31);
        int int4 = spreadsheetDate1.getDayOfWeek();
        int int5 = spreadsheetDate1.toSerial();
        int int6 = spreadsheetDate1.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 9 + "'", int6 == 9);
    }

//    @Test
//    public void test345() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test345");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean4 = spreadsheetDate2.equals((java.lang.Object) 31);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        int int6 = day5.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate9 = serialDate7.getFollowingDayOfWeek(2);
//        java.lang.String str10 = serialDate9.toString();
//        boolean boolean11 = spreadsheetDate2.isOnOrBefore(serialDate9);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean15 = spreadsheetDate13.equals((java.lang.Object) 31);
//        int int16 = spreadsheetDate13.getDayOfWeek();
//        int int17 = spreadsheetDate13.getMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate19);
//        boolean boolean21 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate13, (org.jfree.data.time.SerialDate) spreadsheetDate19);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean25 = spreadsheetDate23.equals((java.lang.Object) 31);
//        int int26 = spreadsheetDate23.getYYYY();
//        java.util.Date date27 = spreadsheetDate23.toDate();
//        int int28 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate23);
//        try {
//            org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(13, (org.jfree.data.time.SerialDate) spreadsheetDate13);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 13 + "'", int6 == 13);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "17-June-2019" + "'", str10.equals("17-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 3 + "'", int16 == 3);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1900 + "'", int26 == 1900);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str4 = timePeriodFormatException3.toString();
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(7, 6, (-460));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test348() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test348");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
//        java.lang.Class<?> wildcardClass2 = fixedMillisecond0.getClass();
//        java.lang.String str3 = fixedMillisecond0.toString();
//        java.util.Calendar calendar4 = null;
//        long long5 = fixedMillisecond0.getMiddleMillisecond(calendar4);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond0.getLastMillisecond(calendar6);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Thu Jun 13 08:39:55 PDT 2019" + "'", str3.equals("Thu Jun 13 08:39:55 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560440395990L + "'", long5 == 1560440395990L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560440395990L + "'", long7 == 1560440395990L);
//    }

//    @Test
//    public void test349() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test349");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getLastMillisecond(calendar1);
//        boolean boolean4 = fixedMillisecond0.equals((java.lang.Object) 1561964399999L);
//        long long5 = fixedMillisecond0.getSerialIndex();
//        java.lang.Class<?> wildcardClass6 = fixedMillisecond0.getClass();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) 1560440367677L);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.Object obj10 = null;
//        boolean boolean11 = day9.equals(obj10);
//        java.lang.String str12 = day9.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day9.previous();
//        long long14 = day9.getLastMillisecond();
//        long long15 = day9.getLastMillisecond();
//        boolean boolean16 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 1560440367677L, (java.lang.Object) long15);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440396271L + "'", long2 == 1560440396271L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560440396271L + "'", long5 == 1560440396271L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "13-June-2019" + "'", str12.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560495599999L + "'", long14 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560495599999L + "'", long15 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean3 = spreadsheetDate1.equals((java.lang.Object) 31);
        java.util.Date date4 = spreadsheetDate1.toDate();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        java.lang.String str17 = timeSeries15.getRangeDescription();
        int int18 = timeSeries15.getMaximumItemCount();
        long long19 = timeSeries15.getMaximumItemAge();
        try {
            timeSeries15.update((int) (byte) -1, (java.lang.Number) 1560440372578L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ThreadContext" + "'", str17.equals("ThreadContext"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2147483647 + "'", int18 == 2147483647);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 9223372036854775807L + "'", long19 == 9223372036854775807L);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(1900);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year18.previous();
        long long20 = year18.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries16.getDataItem((org.jfree.data.time.RegularTimePeriod) year18);
        timeSeries16.clear();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1900L + "'", long20 == 1900L);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) 'a', 31, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("Jan");
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(1900);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year18.previous();
        long long20 = year18.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries16.getDataItem((org.jfree.data.time.RegularTimePeriod) year18);
        java.lang.String str22 = year18.toString();
        java.util.Calendar calendar23 = null;
        try {
            long long24 = year18.getLastMillisecond(calendar23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1900L + "'", long20 == 1900L);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1900" + "'", str22.equals("1900"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        java.lang.Class<?> wildcardClass3 = fixedMillisecond1.getClass();
        java.lang.Object obj4 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("June 2019", (java.lang.Class) wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNull(obj4);
    }

//    @Test
//    public void test359() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test359");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        java.lang.String str2 = day0.toString();
//        long long3 = day0.getLastMillisecond();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getLastMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//    }

//    @Test
//    public void test360() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test360");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getLastMillisecond(calendar1);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getLastMillisecond(calendar3);
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond0.getMiddleMillisecond(calendar5);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440397036L + "'", long2 == 1560440397036L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560440397036L + "'", long4 == 1560440397036L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560440397036L + "'", long6 == 1560440397036L);
//    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.clear();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass12 = month11.getClass();
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class13);
        timeSeries14.setDomainDescription("");
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass21 = month20.getClass();
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries14.addAndOrUpdate(timeSeries23);
        java.lang.String str25 = timeSeries23.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries6.addAndOrUpdate(timeSeries23);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener27 = null;
        timeSeries6.removeChangeListener(seriesChangeListener27);
        try {
            java.lang.Number number30 = timeSeries6.getValue(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "ThreadContext" + "'", str25.equals("ThreadContext"));
        org.junit.Assert.assertNotNull(timeSeries26);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass1 = month0.getClass();
        boolean boolean3 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month0, (java.lang.Object) 10.0d);
        long long4 = month0.getLastMillisecond();
        org.jfree.data.time.Year year5 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month0.next();
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

//    @Test
//    public void test363() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test363");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getLastMillisecond(calendar1);
//        boolean boolean4 = fixedMillisecond0.equals((java.lang.Object) 1561964399999L);
//        long long5 = fixedMillisecond0.getSerialIndex();
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond0.getMiddleMillisecond(calendar6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440397103L + "'", long2 == 1560440397103L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560440397103L + "'", long5 == 1560440397103L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560440397103L + "'", long7 == 1560440397103L);
//    }

//    @Test
//    public void test364() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test364");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = day0.equals(obj1);
//        java.lang.String str3 = day0.toString();
//        java.lang.Object obj4 = null;
//        int int5 = day0.compareTo(obj4);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (java.lang.Number) 10.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = timeSeriesDataItem3.getPeriod();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(1900);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        long long8 = year6.getSerialIndex();
        java.util.Date date9 = year6.getStart();
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date9, timeZone10);
        int int12 = timeSeriesDataItem3.compareTo((java.lang.Object) day11);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1900L + "'", long8 == 1900L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test367() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test367");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getLastMillisecond(calendar3);
//        boolean boolean6 = fixedMillisecond2.equals((java.lang.Object) 1561964399999L);
//        long long7 = fixedMillisecond2.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (double) 13);
//        java.lang.Object obj10 = timeSeriesDataItem9.clone();
//        int int11 = year1.compareTo((java.lang.Object) timeSeriesDataItem9);
//        java.lang.Object obj12 = timeSeriesDataItem9.clone();
//        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass17 = month16.getClass();
//        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass17);
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class18);
//        timeSeries19.setDomainDescription("");
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass26 = month25.getClass();
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass26);
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class27);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries19.addAndOrUpdate(timeSeries28);
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = fixedMillisecond32.next();
//        java.util.Calendar calendar34 = null;
//        long long35 = fixedMillisecond32.getLastMillisecond(calendar34);
//        long long36 = fixedMillisecond32.getSerialIndex();
//        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass39 = month38.getClass();
//        java.lang.Class class40 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass39);
//        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass42 = month41.getClass();
//        java.lang.Class class43 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass42);
//        java.lang.Object obj44 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class40, class43);
//        boolean boolean45 = fixedMillisecond32.equals((java.lang.Object) class43);
//        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries28.createCopy((org.jfree.data.time.RegularTimePeriod) year31, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond32);
//        java.lang.String str47 = timeSeries46.getDomainDescription();
//        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass52 = month51.getClass();
//        java.lang.Class class53 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass52);
//        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class53);
//        timeSeries54.setDomainDescription("");
//        org.jfree.data.time.Month month60 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass61 = month60.getClass();
//        java.lang.Class class62 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass61);
//        org.jfree.data.time.TimeSeries timeSeries63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class62);
//        org.jfree.data.time.TimeSeries timeSeries64 = timeSeries54.addAndOrUpdate(timeSeries63);
//        java.lang.String str65 = timeSeries64.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries66 = timeSeries46.addAndOrUpdate(timeSeries64);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond67 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = fixedMillisecond67.next();
//        long long69 = regularTimePeriod68.getMiddleMillisecond();
//        boolean boolean70 = timeSeries46.equals((java.lang.Object) regularTimePeriod68);
//        boolean boolean71 = timeSeriesDataItem9.equals((java.lang.Object) timeSeries46);
//        timeSeries46.clear();
//        long long73 = timeSeries46.getMaximumItemAge();
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560440397660L + "'", long4 == 1560440397660L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560440397660L + "'", long7 == 1560440397660L);
//        org.junit.Assert.assertNotNull(obj10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(obj12);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(class18);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560440397664L + "'", long35 == 1560440397664L);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560440397664L + "'", long36 == 1560440397664L);
//        org.junit.Assert.assertNotNull(wildcardClass39);
//        org.junit.Assert.assertNotNull(class40);
//        org.junit.Assert.assertNotNull(wildcardClass42);
//        org.junit.Assert.assertNotNull(class43);
//        org.junit.Assert.assertNull(obj44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertNotNull(timeSeries46);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "hi!" + "'", str47.equals("hi!"));
//        org.junit.Assert.assertNotNull(wildcardClass52);
//        org.junit.Assert.assertNotNull(class53);
//        org.junit.Assert.assertNotNull(wildcardClass61);
//        org.junit.Assert.assertNotNull(class62);
//        org.junit.Assert.assertNotNull(timeSeries64);
//        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "Time" + "'", str65.equals("Time"));
//        org.junit.Assert.assertNotNull(timeSeries66);
//        org.junit.Assert.assertNotNull(regularTimePeriod68);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 1560440397687L + "'", long69 == 1560440397687L);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
//        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 9223372036854775807L + "'", long73 == 9223372036854775807L);
//    }

//    @Test
//    public void test368() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test368");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.setDomainDescription("");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass13 = month12.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass21 = month20.getClass();
//        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
//        java.util.List list24 = timeSeries23.getItems();
//        boolean boolean25 = timeSeries16.equals((java.lang.Object) list24);
//        timeSeries16.removeAgedItems(false);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        int int29 = day28.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day28.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries16.getDataItem(regularTimePeriod30);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar33 = null;
//        long long34 = fixedMillisecond32.getLastMillisecond(calendar33);
//        boolean boolean36 = fixedMillisecond32.equals((java.lang.Object) 1561964399999L);
//        long long37 = fixedMillisecond32.getSerialIndex();
//        java.lang.Class<?> wildcardClass38 = fixedMillisecond32.getClass();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (java.lang.Number) 1560440367677L);
//        try {
//            timeSeries16.add(timeSeriesDataItem40, true);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(class22);
//        org.junit.Assert.assertNotNull(list24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 13 + "'", int29 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNull(timeSeriesDataItem31);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560440398063L + "'", long34 == 1560440398063L);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560440398063L + "'", long37 == 1560440398063L);
//        org.junit.Assert.assertNotNull(wildcardClass38);
//    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean4 = spreadsheetDate2.equals((java.lang.Object) 31);
        int int5 = spreadsheetDate2.getDayOfWeek();
        try {
            org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addYears((-435), (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("June 2019");
    }

//    @Test
//    public void test371() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test371");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        int int3 = day0.getDayOfMonth();
//        long long4 = day0.getLastMillisecond();
//        long long5 = day0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560495599999L + "'", long4 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43629L + "'", long5 == 43629L);
//    }

//    @Test
//    public void test372() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test372");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getLastMillisecond(calendar1);
//        boolean boolean4 = fixedMillisecond0.equals((java.lang.Object) 1561964399999L);
//        java.util.Date date5 = fixedMillisecond0.getTime();
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date5);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440398422L + "'", long2 == 1560440398422L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(serialDate6);
//    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test374() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test374");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = day0.equals(obj1);
//        java.lang.String str3 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        long long5 = day0.getLastMillisecond();
//        long long6 = day0.getLastMillisecond();
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = day0.getFirstMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560495599999L + "'", long5 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560495599999L + "'", long6 == 1560495599999L);
//    }

//    @Test
//    public void test375() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test375");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int2 = spreadsheetDate1.toSerial();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        int int4 = day3.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
//        boolean boolean6 = spreadsheetDate1.isOnOrAfter(serialDate5);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int9 = day8.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate10 = day8.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate12 = serialDate10.getFollowingDayOfWeek(2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean16 = spreadsheetDate14.equals((java.lang.Object) 31);
//        java.util.Date date17 = spreadsheetDate14.toDate();
//        boolean boolean19 = spreadsheetDate14.equals((java.lang.Object) 1560440366809L);
//        int int20 = spreadsheetDate14.getYYYY();
//        org.jfree.data.time.SerialDate serialDate21 = serialDate10.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate14);
//        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addYears((-1), serialDate10);
//        int int23 = spreadsheetDate1.compare(serialDate10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond25);
//        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass31 = month30.getClass();
//        java.lang.Class class32 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass31);
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class32);
//        timeSeries33.setDomainDescription("");
//        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass40 = month39.getClass();
//        java.lang.Class class41 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass40);
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class41);
//        org.jfree.data.time.TimeSeries timeSeries43 = timeSeries33.addAndOrUpdate(timeSeries42);
//        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = fixedMillisecond46.next();
//        java.util.Calendar calendar48 = null;
//        long long49 = fixedMillisecond46.getLastMillisecond(calendar48);
//        long long50 = fixedMillisecond46.getSerialIndex();
//        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass53 = month52.getClass();
//        java.lang.Class class54 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass53);
//        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass56 = month55.getClass();
//        java.lang.Class class57 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass56);
//        java.lang.Object obj58 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class54, class57);
//        boolean boolean59 = fixedMillisecond46.equals((java.lang.Object) class57);
//        org.jfree.data.time.TimeSeries timeSeries60 = timeSeries42.createCopy((org.jfree.data.time.RegularTimePeriod) year45, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond46);
//        java.lang.String str61 = timeSeries60.getDomainDescription();
//        org.jfree.data.time.Month month65 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass66 = month65.getClass();
//        java.lang.Class class67 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass66);
//        org.jfree.data.time.TimeSeries timeSeries68 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class67);
//        timeSeries68.setDomainDescription("");
//        org.jfree.data.time.Month month74 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass75 = month74.getClass();
//        java.lang.Class class76 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass75);
//        org.jfree.data.time.TimeSeries timeSeries77 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class76);
//        org.jfree.data.time.TimeSeries timeSeries78 = timeSeries68.addAndOrUpdate(timeSeries77);
//        java.lang.String str79 = timeSeries78.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries80 = timeSeries60.addAndOrUpdate(timeSeries78);
//        org.jfree.data.time.TimeSeries timeSeries81 = timeSeries26.addAndOrUpdate(timeSeries60);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond82 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = fixedMillisecond82.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem85 = timeSeries81.addOrUpdate(regularTimePeriod83, (double) 1560440360327L);
//        boolean boolean86 = spreadsheetDate1.equals((java.lang.Object) regularTimePeriod83);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 13 + "'", int9 == 13);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1900 + "'", int20 == 1900);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-43619) + "'", int23 == (-43619));
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertNotNull(class32);
//        org.junit.Assert.assertNotNull(wildcardClass40);
//        org.junit.Assert.assertNotNull(class41);
//        org.junit.Assert.assertNotNull(timeSeries43);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1560440399964L + "'", long49 == 1560440399964L);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560440399964L + "'", long50 == 1560440399964L);
//        org.junit.Assert.assertNotNull(wildcardClass53);
//        org.junit.Assert.assertNotNull(class54);
//        org.junit.Assert.assertNotNull(wildcardClass56);
//        org.junit.Assert.assertNotNull(class57);
//        org.junit.Assert.assertNull(obj58);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertNotNull(timeSeries60);
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "hi!" + "'", str61.equals("hi!"));
//        org.junit.Assert.assertNotNull(wildcardClass66);
//        org.junit.Assert.assertNotNull(class67);
//        org.junit.Assert.assertNotNull(wildcardClass75);
//        org.junit.Assert.assertNotNull(class76);
//        org.junit.Assert.assertNotNull(timeSeries78);
//        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "Time" + "'", str79.equals("Time"));
//        org.junit.Assert.assertNotNull(timeSeries80);
//        org.junit.Assert.assertNotNull(timeSeries81);
//        org.junit.Assert.assertNotNull(regularTimePeriod83);
//        org.junit.Assert.assertNull(timeSeriesDataItem85);
//        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
//    }

//    @Test
//    public void test376() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test376");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int2 = spreadsheetDate1.toSerial();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        int int4 = day3.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
//        boolean boolean6 = spreadsheetDate1.isOnOrAfter(serialDate5);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int9 = day8.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate10 = day8.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate12 = serialDate10.getFollowingDayOfWeek(2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean16 = spreadsheetDate14.equals((java.lang.Object) 31);
//        java.util.Date date17 = spreadsheetDate14.toDate();
//        boolean boolean19 = spreadsheetDate14.equals((java.lang.Object) 1560440366809L);
//        int int20 = spreadsheetDate14.getYYYY();
//        org.jfree.data.time.SerialDate serialDate21 = serialDate10.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate14);
//        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addYears((-1), serialDate10);
//        int int23 = spreadsheetDate1.compare(serialDate10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate25);
//        boolean boolean27 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate25);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate25);
//        java.util.Calendar calendar29 = null;
//        try {
//            long long30 = day28.getFirstMillisecond(calendar29);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 13 + "'", int9 == 13);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1900 + "'", int20 == 1900);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-43619) + "'", int23 == (-43619));
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//    }

//    @Test
//    public void test377() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test377");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond1.getLastMillisecond(calendar3);
//        long long5 = fixedMillisecond1.getSerialIndex();
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass8 = month7.getClass();
//        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass11 = month10.getClass();
//        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
//        java.lang.Object obj13 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class9, class12);
//        boolean boolean14 = fixedMillisecond1.equals((java.lang.Object) class12);
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass19 = month18.getClass();
//        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass19);
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class20);
//        timeSeries21.setDomainDescription("");
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass28 = month27.getClass();
//        java.lang.Class class29 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass28);
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class29);
//        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries21.addAndOrUpdate(timeSeries30);
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass36 = month35.getClass();
//        java.lang.Class class37 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass36);
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class37);
//        java.util.List list39 = timeSeries38.getItems();
//        boolean boolean40 = timeSeries31.equals((java.lang.Object) list39);
//        java.lang.Class class41 = timeSeries31.getTimePeriodClass();
//        java.lang.Object obj42 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class12, class41);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560440401094L + "'", long4 == 1560440401094L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560440401094L + "'", long5 == 1560440401094L);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(class9);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertNull(obj13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertNotNull(class20);
//        org.junit.Assert.assertNotNull(wildcardClass28);
//        org.junit.Assert.assertNotNull(class29);
//        org.junit.Assert.assertNotNull(timeSeries31);
//        org.junit.Assert.assertNotNull(wildcardClass36);
//        org.junit.Assert.assertNotNull(class37);
//        org.junit.Assert.assertNotNull(list39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(class41);
//        org.junit.Assert.assertNull(obj42);
//    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        java.lang.String str17 = timeSeries16.getDomainDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries16.addChangeListener(seriesChangeListener18);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = timeSeries16.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Time" + "'", str17.equals("Time"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        long long3 = year1.getSerialIndex();
        java.util.Date date4 = year1.getStart();
        long long5 = year1.getFirstMillisecond();
        java.lang.String str6 = year1.toString();
        org.junit.Assert.assertNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1900L + "'", long3 == 1900L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-2208960000000L) + "'", long5 == (-2208960000000L));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1900" + "'", str6.equals("1900"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        try {
            java.lang.Object obj1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) 1560440362150L);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
    }

//    @Test
//    public void test381() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test381");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
//        java.lang.Class<?> wildcardClass2 = fixedMillisecond0.getClass();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getFirstMillisecond(calendar3);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560440401310L + "'", long4 == 1560440401310L);
//    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("Thu Jun 13 08:39:19 PDT 2019");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.Throwable[] throwableArray6 = seriesException4.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray6);
    }

//    @Test
//    public void test383() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test383");
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        int int2 = day1.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate3 = day1.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate5 = serialDate3.getFollowingDayOfWeek(2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean9 = spreadsheetDate7.equals((java.lang.Object) 31);
//        java.util.Date date10 = spreadsheetDate7.toDate();
//        boolean boolean12 = spreadsheetDate7.equals((java.lang.Object) 1560440366809L);
//        int int13 = spreadsheetDate7.getYYYY();
//        org.jfree.data.time.SerialDate serialDate14 = serialDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate7);
//        try {
//            org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addYears((-460), serialDate3);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1900 + "'", int13 == 1900);
//        org.junit.Assert.assertNotNull(serialDate14);
//    }

//    @Test
//    public void test384() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test384");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean2 = fixedMillisecond0.equals((java.lang.Object) 0.0d);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getMiddleMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond0.next();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560440401458L + "'", long4 == 1560440401458L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(11, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30 + "'", int2 == 30);
    }

//    @Test
//    public void test386() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test386");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
//        boolean boolean3 = fixedMillisecond0.equals((java.lang.Object) "org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        java.util.Calendar calendar4 = null;
//        long long5 = fixedMillisecond0.getMiddleMillisecond(calendar4);
//        java.util.Calendar calendar6 = null;
//        fixedMillisecond0.peg(calendar6);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560440402105L + "'", long5 == 1560440402105L);
//    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d));
        timeSeries1.setMaximumItemAge(0L);
        java.util.Collection collection4 = timeSeries1.getTimePeriods();
        org.junit.Assert.assertNotNull(collection4);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass11 = month10.getClass();
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class12);
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener14);
        java.lang.String str16 = timeSeries13.getDescription();
        java.util.Collection collection17 = timeSeries6.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(1900);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) 10.0f);
        timeSeriesDataItem21.setValue((java.lang.Number) 10);
        try {
            timeSeries6.add(timeSeriesDataItem21);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(collection17);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(10, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

//    @Test
//    public void test390() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test390");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getLastMillisecond(calendar10);
//        boolean boolean13 = fixedMillisecond9.equals((java.lang.Object) 1561964399999L);
//        long long14 = fixedMillisecond9.getSerialIndex();
//        java.util.Calendar calendar15 = null;
//        fixedMillisecond9.peg(calendar15);
//        java.util.Date date17 = fixedMillisecond9.getTime();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent18 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) fixedMillisecond9);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, 10.0d);
//        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass25 = month24.getClass();
//        java.lang.Class class26 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass25);
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class26);
//        timeSeries27.setDomainDescription("");
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass34 = month33.getClass();
//        java.lang.Class class35 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass34);
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class35);
//        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries27.addAndOrUpdate(timeSeries36);
//        timeSeries27.fireSeriesChanged();
//        int int39 = timeSeries27.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries6.addAndOrUpdate(timeSeries27);
//        java.util.List list41 = timeSeries6.getItems();
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560440402999L + "'", long11 == 1560440402999L);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560440402999L + "'", long14 == 1560440402999L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNull(timeSeriesDataItem20);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertNotNull(class26);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNotNull(class35);
//        org.junit.Assert.assertNotNull(timeSeries37);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
//        org.junit.Assert.assertNotNull(timeSeries40);
//        org.junit.Assert.assertNotNull(list41);
//    }

//    @Test
//    public void test391() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test391");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = day0.equals(obj1);
//        java.lang.String str3 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        long long5 = day0.getLastMillisecond();
//        int int7 = day0.compareTo((java.lang.Object) 100L);
//        java.util.Date date8 = day0.getEnd();
//        org.jfree.data.time.SerialDate serialDate9 = day0.getSerialDate();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560495599999L + "'", long5 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(serialDate9);
//    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        long long3 = year1.getSerialIndex();
        java.util.Date date4 = year1.getStart();
        long long5 = year1.getFirstMillisecond();
        int int6 = year1.getYear();
        long long7 = year1.getMiddleMillisecond();
        long long8 = year1.getSerialIndex();
        org.junit.Assert.assertNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1900L + "'", long3 == 1900L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-2208960000000L) + "'", long5 == (-2208960000000L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1900 + "'", int6 == 1900);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2193192000001L) + "'", long7 == (-2193192000001L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1900L + "'", long8 == 1900L);
    }

//    @Test
//    public void test393() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test393");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        int int3 = day0.getMonth();
//        long long4 = day0.getFirstMillisecond();
//        boolean boolean6 = day0.equals((java.lang.Object) (-1));
//        int int7 = day0.getMonth();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        long long3 = year1.getSerialIndex();
        java.util.Date date4 = year1.getStart();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date4);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(1900);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        long long10 = year8.getSerialIndex();
        java.util.Date date11 = year8.getStart();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date11, timeZone12);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date4, timeZone12);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date4);
        org.junit.Assert.assertNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1900L + "'", long3 == 1900L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1900L + "'", long10 == 1900L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
        java.lang.Class<?> wildcardClass2 = fixedMillisecond0.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) 1561964399999L);
        java.util.Calendar calendar5 = null;
        fixedMillisecond0.peg(calendar5);
        java.util.Date date7 = fixedMillisecond0.getTime();
        java.util.TimeZone timeZone8 = null;
        try {
            org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date7, timeZone8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass21 = month20.getClass();
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
        java.util.List list24 = timeSeries23.getItems();
        boolean boolean25 = timeSeries16.equals((java.lang.Object) list24);
        boolean boolean27 = timeSeries16.equals((java.lang.Object) false);
        java.lang.String str28 = timeSeries16.getDescription();
        timeSeries16.removeAgedItems(true);
        java.lang.String str31 = timeSeries16.getRangeDescription();
        timeSeries16.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertNotNull(list24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Value" + "'", str31.equals("Value"));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass21 = month20.getClass();
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
        timeSeries23.setDomainDescription("");
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries16.addAndOrUpdate(timeSeries23);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener27 = null;
        timeSeries16.removeChangeListener(seriesChangeListener27);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = timeSeries16.getTimePeriod(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertNotNull(timeSeries26);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass1 = month0.getClass();
        boolean boolean3 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month0, (java.lang.Object) 10.0d);
        long long4 = month0.getLastMillisecond();
        org.jfree.data.time.Year year5 = month0.getYear();
        java.util.Calendar calendar6 = null;
        try {
            year5.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
        org.junit.Assert.assertNotNull(year5);
    }

//    @Test
//    public void test399() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test399");
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass5 = month4.getClass();
//        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class6);
//        timeSeries7.setDomainDescription("");
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass14 = month13.getClass();
//        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass14);
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class15);
//        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries7.addAndOrUpdate(timeSeries16);
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass22 = month21.getClass();
//        java.lang.Class class23 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass22);
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class23);
//        timeSeries24.setDomainDescription("");
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries17.addAndOrUpdate(timeSeries24);
//        java.lang.String str28 = timeSeries27.getDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean31 = fixedMillisecond29.equals((java.lang.Object) 0.0d);
//        java.util.Calendar calendar32 = null;
//        fixedMillisecond29.peg(calendar32);
//        java.lang.String str34 = fixedMillisecond29.toString();
//        long long35 = fixedMillisecond29.getMiddleMillisecond();
//        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass37 = month36.getClass();
//        boolean boolean39 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month36, (java.lang.Object) 10.0d);
//        long long40 = month36.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries27.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, (org.jfree.data.time.RegularTimePeriod) month36);
//        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass46 = month45.getClass();
//        java.lang.Class class47 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass46);
//        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class47);
//        timeSeries48.setDomainDescription("");
//        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass55 = month54.getClass();
//        java.lang.Class class56 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass55);
//        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class56);
//        org.jfree.data.time.TimeSeries timeSeries58 = timeSeries48.addAndOrUpdate(timeSeries57);
//        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d);
//        java.util.Collection collection61 = timeSeries48.getTimePeriodsUniqueToOtherSeries(timeSeries60);
//        java.lang.Class class62 = timeSeries60.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month36, class62);
//        java.net.URL uRL64 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("Thu Jun 13 08:39:19 PDT 2019", class62);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(class6);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertNotNull(class15);
//        org.junit.Assert.assertNotNull(timeSeries17);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertNotNull(class23);
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertNull(str28);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Thu Jun 13 08:40:04 PDT 2019" + "'", str34.equals("Thu Jun 13 08:40:04 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560440404058L + "'", long35 == 1560440404058L);
//        org.junit.Assert.assertNotNull(wildcardClass37);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1561964399999L + "'", long40 == 1561964399999L);
//        org.junit.Assert.assertNotNull(timeSeries41);
//        org.junit.Assert.assertNotNull(wildcardClass46);
//        org.junit.Assert.assertNotNull(class47);
//        org.junit.Assert.assertNotNull(wildcardClass55);
//        org.junit.Assert.assertNotNull(class56);
//        org.junit.Assert.assertNotNull(timeSeries58);
//        org.junit.Assert.assertNotNull(collection61);
//        org.junit.Assert.assertNotNull(class62);
//        org.junit.Assert.assertNull(uRL64);
//    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean3 = spreadsheetDate1.equals((java.lang.Object) 31);
        java.util.Date date4 = spreadsheetDate1.toDate();
        boolean boolean6 = spreadsheetDate1.equals((java.lang.Object) 1560440366809L);
        org.jfree.data.time.SerialDate serialDate8 = spreadsheetDate1.getNearestDayOfWeek((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(serialDate8);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean3 = spreadsheetDate1.equals((java.lang.Object) 31);
        int int4 = spreadsheetDate1.getYYYY();
        java.util.Date date5 = spreadsheetDate1.toDate();
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addYears(0, serialDate8);
        serialDate8.setDescription("ClassContext");
        boolean boolean12 = spreadsheetDate1.isBefore(serialDate8);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1900 + "'", int4 == 1900);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        java.lang.Class class2 = null;
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.lang.Object obj6 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class2, (java.lang.Class) wildcardClass4);
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.net.URL uRL8 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass4);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(1900);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
        long long12 = year10.getSerialIndex();
        java.util.Date date13 = year10.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(date13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date13);
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date13, timeZone16);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNotNull(uRL8);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1900L + "'", long12 == 1900L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(2019, 0, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test404() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test404");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
//        java.lang.Class<?> wildcardClass2 = fixedMillisecond0.getClass();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) 1561964399999L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond5.next();
//        java.lang.Class<?> wildcardClass7 = fixedMillisecond5.getClass();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond5.getMiddleMillisecond(calendar8);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond5.previous();
//        boolean boolean11 = timeSeriesDataItem4.equals((java.lang.Object) fixedMillisecond5);
//        java.lang.Number number12 = timeSeriesDataItem4.getValue();
//        java.lang.Number number13 = timeSeriesDataItem4.getValue();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560440404663L + "'", long9 == 1560440404663L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 1.561964399999E12d + "'", number12.equals(1.561964399999E12d));
//        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 1.561964399999E12d + "'", number13.equals(1.561964399999E12d));
//    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Time");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

//    @Test
//    public void test406() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test406");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1);
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass7 = month6.getClass();
//        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class8);
//        timeSeries9.setDomainDescription("");
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass16 = month15.getClass();
//        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass16);
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class17);
//        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries9.addAndOrUpdate(timeSeries18);
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond22.next();
//        java.util.Calendar calendar24 = null;
//        long long25 = fixedMillisecond22.getLastMillisecond(calendar24);
//        long long26 = fixedMillisecond22.getSerialIndex();
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass29 = month28.getClass();
//        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
//        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass32 = month31.getClass();
//        java.lang.Class class33 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass32);
//        java.lang.Object obj34 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class30, class33);
//        boolean boolean35 = fixedMillisecond22.equals((java.lang.Object) class33);
//        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries18.createCopy((org.jfree.data.time.RegularTimePeriod) year21, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
//        java.lang.String str37 = timeSeries36.getDomainDescription();
//        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass42 = month41.getClass();
//        java.lang.Class class43 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass42);
//        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class43);
//        timeSeries44.setDomainDescription("");
//        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass51 = month50.getClass();
//        java.lang.Class class52 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass51);
//        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class52);
//        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries44.addAndOrUpdate(timeSeries53);
//        java.lang.String str55 = timeSeries54.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries56 = timeSeries36.addAndOrUpdate(timeSeries54);
//        org.jfree.data.time.TimeSeries timeSeries57 = timeSeries2.addAndOrUpdate(timeSeries36);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener58 = null;
//        timeSeries57.addChangeListener(seriesChangeListener58);
//        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = year61.previous();
//        long long63 = year61.getSerialIndex();
//        java.util.Date date64 = year61.getStart();
//        org.jfree.data.time.Month month65 = new org.jfree.data.time.Month(date64);
//        long long66 = month65.getLastMillisecond();
//        int int67 = month65.getYearValue();
//        try {
//            timeSeries57.update((org.jfree.data.time.RegularTimePeriod) month65, (java.lang.Number) 1560440380176L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(class8);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNotNull(class17);
//        org.junit.Assert.assertNotNull(timeSeries19);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560440404761L + "'", long25 == 1560440404761L);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560440404761L + "'", long26 == 1560440404761L);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertNotNull(wildcardClass32);
//        org.junit.Assert.assertNotNull(class33);
//        org.junit.Assert.assertNull(obj34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(timeSeries36);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "hi!" + "'", str37.equals("hi!"));
//        org.junit.Assert.assertNotNull(wildcardClass42);
//        org.junit.Assert.assertNotNull(class43);
//        org.junit.Assert.assertNotNull(wildcardClass51);
//        org.junit.Assert.assertNotNull(class52);
//        org.junit.Assert.assertNotNull(timeSeries54);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "Time" + "'", str55.equals("Time"));
//        org.junit.Assert.assertNotNull(timeSeries56);
//        org.junit.Assert.assertNotNull(timeSeries57);
//        org.junit.Assert.assertNull(regularTimePeriod62);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 1900L + "'", long63 == 1900L);
//        org.junit.Assert.assertNotNull(date64);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + (-2206281600001L) + "'", long66 == (-2206281600001L));
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1900 + "'", int67 == 1900);
//    }

//    @Test
//    public void test407() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test407");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int2 = month0.compareTo((java.lang.Object) 1L);
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        int int5 = month3.compareTo((java.lang.Object) 1L);
//        long long6 = month3.getLastMillisecond();
//        int int7 = month0.compareTo((java.lang.Object) long6);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond8.getLastMillisecond(calendar9);
//        boolean boolean12 = fixedMillisecond8.equals((java.lang.Object) 1561964399999L);
//        long long13 = fixedMillisecond8.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (double) 13);
//        boolean boolean17 = timeSeriesDataItem15.equals((java.lang.Object) "org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d));
//        boolean boolean20 = timeSeriesDataItem15.equals((java.lang.Object) (-1.0d));
//        int int21 = month0.compareTo((java.lang.Object) timeSeriesDataItem15);
//        long long22 = month0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month0.previous();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1561964399999L + "'", long6 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560440404811L + "'", long10 == 1560440404811L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560440404811L + "'", long13 == 1560440404811L);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 24234L + "'", long22 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(7);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d);
        java.util.Collection collection19 = timeSeries6.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        try {
            timeSeries6.delete(2, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(collection19);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Thu Jun 13 08:39:55 PDT 2019");
    }

//    @Test
//    public void test411() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test411");
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        int int3 = day2.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate4 = day2.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate6 = serialDate4.getFollowingDayOfWeek(2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean10 = spreadsheetDate8.equals((java.lang.Object) 31);
//        java.util.Date date11 = spreadsheetDate8.toDate();
//        boolean boolean13 = spreadsheetDate8.equals((java.lang.Object) 1560440366809L);
//        int int14 = spreadsheetDate8.getYYYY();
//        org.jfree.data.time.SerialDate serialDate15 = serialDate4.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate8);
//        org.jfree.data.time.SerialDate serialDate17 = serialDate4.getFollowingDayOfWeek(4);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int20 = spreadsheetDate19.toSerial();
//        int int21 = spreadsheetDate19.getDayOfWeek();
//        org.jfree.data.time.SerialDate serialDate22 = serialDate4.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate19);
//        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addDays((int) (short) 1, (org.jfree.data.time.SerialDate) spreadsheetDate19);
//        try {
//            org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(12, serialDate23);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1900 + "'", int14 == 1900);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 10 + "'", int20 == 10);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 3 + "'", int21 == 3);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertNotNull(serialDate23);
//    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        long long3 = year1.getSerialIndex();
        java.util.Date date4 = year1.getStart();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year1.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1900L + "'", long3 == 1900L);
        org.junit.Assert.assertNotNull(date4);
    }

//    @Test
//    public void test413() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test413");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean3 = spreadsheetDate1.equals((java.lang.Object) 31);
//        int int4 = spreadsheetDate1.getDayOfWeek();
//        java.lang.String str5 = spreadsheetDate1.getDescription();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int7 = day6.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day6.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate10 = serialDate8.getFollowingDayOfWeek(2);
//        java.lang.String str11 = serialDate10.toString();
//        org.jfree.data.time.SerialDate serialDate13 = serialDate10.getNearestDayOfWeek((int) (byte) 1);
//        boolean boolean14 = spreadsheetDate1.isOnOrAfter(serialDate10);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
//        org.junit.Assert.assertNull(str5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 13 + "'", int7 == 13);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "17-June-2019" + "'", str11.equals("17-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//    }

//    @Test
//    public void test414() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test414");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.String str9 = timeSeries6.getDescription();
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(1900);
//        java.lang.String str12 = year11.toString();
//        java.lang.Number number13 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year11, number13);
//        timeSeries6.delete((org.jfree.data.time.RegularTimePeriod) year11);
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year17.previous();
//        long long19 = year17.getSerialIndex();
//        java.util.Date date20 = year17.getStart();
//        long long21 = year17.getFirstMillisecond();
//        int int22 = year17.getYear();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        java.lang.Object obj24 = null;
//        boolean boolean25 = day23.equals(obj24);
//        java.lang.String str26 = day23.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day23.previous();
//        int int28 = year17.compareTo((java.lang.Object) day23);
//        long long29 = year17.getSerialIndex();
//        int int31 = year17.compareTo((java.lang.Object) 1560440373017L);
//        try {
//            timeSeries6.add((org.jfree.data.time.RegularTimePeriod) year17, (java.lang.Number) 1560440365729L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNull(str9);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1900" + "'", str12.equals("1900"));
//        org.junit.Assert.assertNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1900L + "'", long19 == 1900L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-2208960000000L) + "'", long21 == (-2208960000000L));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1900 + "'", int22 == 1900);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "13-June-2019" + "'", str26.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1900L + "'", long29 == 1900L);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
//    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass21 = month20.getClass();
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
        timeSeries23.setDomainDescription("");
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries16.addAndOrUpdate(timeSeries23);
        try {
            timeSeries23.update((int) (byte) 1, (java.lang.Number) 1561964399999L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertNotNull(timeSeries26);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("Thu Jun 13 08:39:42 PDT 2019", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("Overwritten values from: 1560440358934");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) (short) -1, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test419() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test419");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean3 = spreadsheetDate1.equals((java.lang.Object) 31);
//        int int4 = spreadsheetDate1.getDayOfWeek();
//        boolean boolean6 = spreadsheetDate1.equals((java.lang.Object) "");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int9 = spreadsheetDate8.toSerial();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        int int11 = day10.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate12 = day10.getSerialDate();
//        boolean boolean13 = spreadsheetDate8.isOnOrAfter(serialDate12);
//        boolean boolean14 = spreadsheetDate1.isBefore(serialDate12);
//        try {
//            org.jfree.data.time.SerialDate serialDate16 = serialDate12.getFollowingDayOfWeek((int) '4');
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 13 + "'", int11 == 13);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        java.lang.String str7 = timeSeries6.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate9);
        timeSeries6.delete((org.jfree.data.time.RegularTimePeriod) day10);
        java.util.Calendar calendar12 = null;
        try {
            day10.peg(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNull(str7);
    }

//    @Test
//    public void test421() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test421");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1);
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass7 = month6.getClass();
//        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class8);
//        timeSeries9.setDomainDescription("");
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass16 = month15.getClass();
//        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass16);
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class17);
//        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries9.addAndOrUpdate(timeSeries18);
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond22.next();
//        java.util.Calendar calendar24 = null;
//        long long25 = fixedMillisecond22.getLastMillisecond(calendar24);
//        long long26 = fixedMillisecond22.getSerialIndex();
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass29 = month28.getClass();
//        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
//        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass32 = month31.getClass();
//        java.lang.Class class33 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass32);
//        java.lang.Object obj34 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class30, class33);
//        boolean boolean35 = fixedMillisecond22.equals((java.lang.Object) class33);
//        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries18.createCopy((org.jfree.data.time.RegularTimePeriod) year21, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
//        java.lang.String str37 = timeSeries36.getDomainDescription();
//        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass42 = month41.getClass();
//        java.lang.Class class43 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass42);
//        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class43);
//        timeSeries44.setDomainDescription("");
//        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass51 = month50.getClass();
//        java.lang.Class class52 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass51);
//        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class52);
//        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries44.addAndOrUpdate(timeSeries53);
//        java.lang.String str55 = timeSeries54.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries56 = timeSeries36.addAndOrUpdate(timeSeries54);
//        org.jfree.data.time.TimeSeries timeSeries57 = timeSeries2.addAndOrUpdate(timeSeries36);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener58 = null;
//        timeSeries57.addChangeListener(seriesChangeListener58);
//        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day();
//        java.lang.Object obj61 = null;
//        boolean boolean62 = day60.equals(obj61);
//        java.lang.String str63 = day60.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = day60.previous();
//        org.jfree.data.time.Month month65 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = month65.next();
//        boolean boolean67 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) regularTimePeriod64, (java.lang.Object) regularTimePeriod66);
//        int int68 = timeSeries57.getIndex(regularTimePeriod64);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(class8);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNotNull(class17);
//        org.junit.Assert.assertNotNull(timeSeries19);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560440405597L + "'", long25 == 1560440405597L);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560440405597L + "'", long26 == 1560440405597L);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertNotNull(wildcardClass32);
//        org.junit.Assert.assertNotNull(class33);
//        org.junit.Assert.assertNull(obj34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(timeSeries36);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "hi!" + "'", str37.equals("hi!"));
//        org.junit.Assert.assertNotNull(wildcardClass42);
//        org.junit.Assert.assertNotNull(class43);
//        org.junit.Assert.assertNotNull(wildcardClass51);
//        org.junit.Assert.assertNotNull(class52);
//        org.junit.Assert.assertNotNull(timeSeries54);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "Time" + "'", str55.equals("Time"));
//        org.junit.Assert.assertNotNull(timeSeries56);
//        org.junit.Assert.assertNotNull(timeSeries57);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "13-June-2019" + "'", str63.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod64);
//        org.junit.Assert.assertNotNull(regularTimePeriod66);
//        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + (-1) + "'", int68 == (-1));
//    }

//    @Test
//    public void test422() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test422");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.setDomainDescription("");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass13 = month12.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass21 = month20.getClass();
//        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
//        java.util.List list24 = timeSeries23.getItems();
//        boolean boolean25 = timeSeries16.equals((java.lang.Object) list24);
//        timeSeries16.removeAgedItems(false);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        int int29 = day28.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day28.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries16.getDataItem(regularTimePeriod30);
//        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = year33.previous();
//        long long35 = year33.getSerialIndex();
//        java.util.Date date36 = year33.getStart();
//        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month(date36);
//        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month(date36);
//        timeSeries16.setKey((java.lang.Comparable) date36);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(class22);
//        org.junit.Assert.assertNotNull(list24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 13 + "'", int29 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNull(timeSeriesDataItem31);
//        org.junit.Assert.assertNull(regularTimePeriod34);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1900L + "'", long35 == 1900L);
//        org.junit.Assert.assertNotNull(date36);
//    }

//    @Test
//    public void test423() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test423");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.clear();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass12 = month11.getClass();
//        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class13);
//        timeSeries14.setDomainDescription("");
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass21 = month20.getClass();
//        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries14.addAndOrUpdate(timeSeries23);
//        java.lang.String str25 = timeSeries23.getRangeDescription();
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries6.addAndOrUpdate(timeSeries23);
//        java.util.Collection collection27 = timeSeries26.getTimePeriods();
//        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass32 = month31.getClass();
//        java.lang.Class class33 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass32);
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class33);
//        timeSeries34.setDomainDescription("");
//        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass41 = month40.getClass();
//        java.lang.Class class42 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass41);
//        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class42);
//        org.jfree.data.time.TimeSeries timeSeries44 = timeSeries34.addAndOrUpdate(timeSeries43);
//        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = fixedMillisecond47.next();
//        java.util.Calendar calendar49 = null;
//        long long50 = fixedMillisecond47.getLastMillisecond(calendar49);
//        long long51 = fixedMillisecond47.getSerialIndex();
//        org.jfree.data.time.Month month53 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass54 = month53.getClass();
//        java.lang.Class class55 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass54);
//        org.jfree.data.time.Month month56 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass57 = month56.getClass();
//        java.lang.Class class58 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass57);
//        java.lang.Object obj59 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class55, class58);
//        boolean boolean60 = fixedMillisecond47.equals((java.lang.Object) class58);
//        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries43.createCopy((org.jfree.data.time.RegularTimePeriod) year46, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond47);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond62 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar63 = null;
//        long long64 = fixedMillisecond62.getLastMillisecond(calendar63);
//        boolean boolean66 = fixedMillisecond62.equals((java.lang.Object) 1561964399999L);
//        long long67 = fixedMillisecond62.getSerialIndex();
//        int int68 = timeSeries43.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond62);
//        org.jfree.data.time.TimeSeries timeSeries69 = timeSeries26.addAndOrUpdate(timeSeries43);
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = timeSeries43.getTimePeriod((int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNotNull(class13);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(class22);
//        org.junit.Assert.assertNotNull(timeSeries24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "ThreadContext" + "'", str25.equals("ThreadContext"));
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertNotNull(collection27);
//        org.junit.Assert.assertNotNull(wildcardClass32);
//        org.junit.Assert.assertNotNull(class33);
//        org.junit.Assert.assertNotNull(wildcardClass41);
//        org.junit.Assert.assertNotNull(class42);
//        org.junit.Assert.assertNotNull(timeSeries44);
//        org.junit.Assert.assertNotNull(regularTimePeriod48);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560440406558L + "'", long50 == 1560440406558L);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1560440406558L + "'", long51 == 1560440406558L);
//        org.junit.Assert.assertNotNull(wildcardClass54);
//        org.junit.Assert.assertNotNull(class55);
//        org.junit.Assert.assertNotNull(wildcardClass57);
//        org.junit.Assert.assertNotNull(class58);
//        org.junit.Assert.assertNull(obj59);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertNotNull(timeSeries61);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 1560440406561L + "'", long64 == 1560440406561L);
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 1560440406561L + "'", long67 == 1560440406561L);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + (-1) + "'", int68 == (-1));
//        org.junit.Assert.assertNotNull(timeSeries69);
//    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass5 = month4.getClass();
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
        java.lang.Object obj10 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class6, class9);
        java.net.URL uRL11 = org.jfree.chart.util.ObjectUtilities.getResource("1900", class6);
        java.net.URL uRL12 = org.jfree.chart.util.ObjectUtilities.getResource("Thu Jun 13 08:39:23 PDT 2019", class6);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass16 = month15.getClass();
        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass16);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass19);
        java.lang.Object obj21 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class17, class20);
        java.net.URL uRL22 = org.jfree.chart.util.ObjectUtilities.getResource("1900", class17);
        java.lang.Object obj23 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("December", class6, class17);
        java.lang.Class class24 = org.jfree.data.time.RegularTimePeriod.downsize(class17);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertNull(obj10);
        org.junit.Assert.assertNull(uRL11);
        org.junit.Assert.assertNull(uRL12);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(class17);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(class20);
        org.junit.Assert.assertNull(obj21);
        org.junit.Assert.assertNull(uRL22);
        org.junit.Assert.assertNull(obj23);
        org.junit.Assert.assertNotNull(class24);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
        java.lang.String str2 = year1.toString();
        java.lang.Number number3 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, number3);
        java.util.Calendar calendar5 = null;
        try {
            year1.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1900" + "'", str2.equals("1900"));
    }

//    @Test
//    public void test426() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test426");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = day0.equals(obj1);
//        java.lang.String str3 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        long long5 = day0.getLastMillisecond();
//        boolean boolean7 = day0.equals((java.lang.Object) 1560440394647L);
//        int int8 = day0.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560495599999L + "'", long5 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 13 + "'", int8 == 13);
//    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass21 = month20.getClass();
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
        java.util.List list24 = timeSeries23.getItems();
        boolean boolean25 = timeSeries16.equals((java.lang.Object) list24);
        java.lang.Class class26 = timeSeries16.getTimePeriodClass();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries16.getDataItem((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertNotNull(list24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(class26);
    }

//    @Test
//    public void test428() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test428");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
//        java.lang.Class<?> wildcardClass2 = fixedMillisecond0.getClass();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) 1561964399999L);
//        java.util.Calendar calendar5 = null;
//        fixedMillisecond0.peg(calendar5);
//        java.util.Date date7 = fixedMillisecond0.getTime();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond0.getFirstMillisecond(calendar8);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560440407729L + "'", long9 == 1560440407729L);
//    }

//    @Test
//    public void test429() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test429");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getLastMillisecond(calendar1);
//        boolean boolean4 = fixedMillisecond0.equals((java.lang.Object) 1561964399999L);
//        long long5 = fixedMillisecond0.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) 13);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond0.getMiddleMillisecond(calendar8);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond0.previous();
//        java.util.Calendar calendar11 = null;
//        long long12 = fixedMillisecond0.getFirstMillisecond(calendar11);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440407793L + "'", long2 == 1560440407793L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560440407793L + "'", long5 == 1560440407793L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560440407793L + "'", long9 == 1560440407793L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560440407793L + "'", long12 == 1560440407793L);
//    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass6 = month5.getClass();
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass9 = month8.getClass();
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        java.lang.Object obj11 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class7, class10);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        java.lang.Object obj15 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ThreadContext", class7, (java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440363591L, class7);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass18 = month17.getClass();
        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass18);
        java.lang.Object obj20 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Following", class7, class19);
        java.lang.Class class21 = org.jfree.data.time.RegularTimePeriod.downsize(class7);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440392542L, class7);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNull(obj15);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(class19);
        org.junit.Assert.assertNull(obj20);
        org.junit.Assert.assertNotNull(class21);
    }

//    @Test
//    public void test431() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test431");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int2 = spreadsheetDate1.toSerial();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        int int4 = day3.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
//        boolean boolean6 = spreadsheetDate1.isOnOrAfter(serialDate5);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int9 = day8.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate10 = day8.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate12 = serialDate10.getFollowingDayOfWeek(2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean16 = spreadsheetDate14.equals((java.lang.Object) 31);
//        java.util.Date date17 = spreadsheetDate14.toDate();
//        boolean boolean19 = spreadsheetDate14.equals((java.lang.Object) 1560440366809L);
//        int int20 = spreadsheetDate14.getYYYY();
//        org.jfree.data.time.SerialDate serialDate21 = serialDate10.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate14);
//        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addYears((-1), serialDate10);
//        int int23 = spreadsheetDate1.compare(serialDate10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate25);
//        boolean boolean27 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate25);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        int int29 = day28.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate30 = day28.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate32 = serialDate30.getFollowingDayOfWeek(2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean36 = spreadsheetDate34.equals((java.lang.Object) 31);
//        java.util.Date date37 = spreadsheetDate34.toDate();
//        boolean boolean39 = spreadsheetDate34.equals((java.lang.Object) 1560440366809L);
//        int int40 = spreadsheetDate34.getYYYY();
//        org.jfree.data.time.SerialDate serialDate41 = serialDate30.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate34);
//        org.jfree.data.time.SerialDate serialDate43 = serialDate30.getFollowingDayOfWeek(4);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int46 = spreadsheetDate45.toSerial();
//        int int47 = spreadsheetDate45.getDayOfWeek();
//        org.jfree.data.time.SerialDate serialDate48 = serialDate30.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate45);
//        boolean boolean49 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate45);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int53 = spreadsheetDate52.toSerial();
//        int int54 = spreadsheetDate52.getYYYY();
//        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.addDays(7, (org.jfree.data.time.SerialDate) spreadsheetDate52);
//        try {
//            int int56 = spreadsheetDate1.compareTo((java.lang.Object) 7);
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Integer cannot be cast to org.jfree.data.time.SerialDate");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 13 + "'", int9 == 13);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1900 + "'", int20 == 1900);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-43619) + "'", int23 == (-43619));
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 13 + "'", int29 == 13);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1900 + "'", int40 == 1900);
//        org.junit.Assert.assertNotNull(serialDate41);
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 10 + "'", int46 == 10);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 3 + "'", int47 == 3);
//        org.junit.Assert.assertNotNull(serialDate48);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 10 + "'", int53 == 10);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1900 + "'", int54 == 1900);
//        org.junit.Assert.assertNotNull(serialDate55);
//    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
        int int3 = year1.compareTo((java.lang.Object) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year1.previous();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNull(regularTimePeriod4);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        timeSeries6.setDomainDescription("17-June-2019");
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
    }

//    @Test
//    public void test435() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test435");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d));
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getLastMillisecond(calendar3);
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond2.getLastMillisecond(calendar5);
//        try {
//            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (java.lang.Number) 1560440407473L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560440408030L + "'", long4 == 1560440408030L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560440408030L + "'", long6 == 1560440408030L);
//    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Thu Jun 13 08:39:54 PDT 2019", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
        java.lang.Class<?> wildcardClass2 = fixedMillisecond0.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) 1561964399999L);
        java.util.Date date5 = fixedMillisecond0.getStart();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass11 = month10.getClass();
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class12);
        timeSeries13.clear();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass19);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class20);
        timeSeries21.setDomainDescription("");
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass28 = month27.getClass();
        java.lang.Class class29 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass28);
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class29);
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries21.addAndOrUpdate(timeSeries30);
        java.lang.String str32 = timeSeries30.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries13.addAndOrUpdate(timeSeries30);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener34 = null;
        timeSeries13.removeChangeListener(seriesChangeListener34);
        int int36 = day6.compareTo((java.lang.Object) timeSeries13);
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass38 = month37.getClass();
        boolean boolean40 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month37, (java.lang.Object) 10.0d);
        long long41 = month37.getLastMillisecond();
        org.jfree.data.time.Year year42 = month37.getYear();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int46 = spreadsheetDate45.toSerial();
        int int47 = spreadsheetDate45.getYYYY();
        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.addDays(7, (org.jfree.data.time.SerialDate) spreadsheetDate45);
        int int49 = month37.compareTo((java.lang.Object) serialDate48);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = month37.next();
        try {
            timeSeries13.add(regularTimePeriod50, (double) 1560452399999L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(class20);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNotNull(class29);
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "ThreadContext" + "'", str32.equals("ThreadContext"));
        org.junit.Assert.assertNotNull(timeSeries33);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1561964399999L + "'", long41 == 1561964399999L);
        org.junit.Assert.assertNotNull(year42);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 10 + "'", int46 == 10);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1900 + "'", int47 == 1900);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Time");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test439() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test439");
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass5 = month4.getClass();
//        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class6);
//        timeSeries7.setDomainDescription("");
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass14 = month13.getClass();
//        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass14);
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class15);
//        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries7.addAndOrUpdate(timeSeries16);
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = fixedMillisecond20.next();
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond20.getLastMillisecond(calendar22);
//        long long24 = fixedMillisecond20.getSerialIndex();
//        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass27 = month26.getClass();
//        java.lang.Class class28 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass27);
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass30 = month29.getClass();
//        java.lang.Class class31 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass30);
//        java.lang.Object obj32 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class28, class31);
//        boolean boolean33 = fixedMillisecond20.equals((java.lang.Object) class31);
//        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries16.createCopy((org.jfree.data.time.RegularTimePeriod) year19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond20);
//        java.lang.String str35 = timeSeries34.getDomainDescription();
//        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass40 = month39.getClass();
//        java.lang.Class class41 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass40);
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class41);
//        timeSeries42.setDomainDescription("");
//        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass49 = month48.getClass();
//        java.lang.Class class50 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass49);
//        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class50);
//        org.jfree.data.time.TimeSeries timeSeries52 = timeSeries42.addAndOrUpdate(timeSeries51);
//        java.lang.String str53 = timeSeries52.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries34.addAndOrUpdate(timeSeries52);
//        boolean boolean56 = timeSeries54.equals((java.lang.Object) 1560440368245L);
//        java.lang.Class class57 = timeSeries54.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), class57);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(class6);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertNotNull(class15);
//        org.junit.Assert.assertNotNull(timeSeries17);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560440408357L + "'", long23 == 1560440408357L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560440408357L + "'", long24 == 1560440408357L);
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertNotNull(class28);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertNotNull(class31);
//        org.junit.Assert.assertNull(obj32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(timeSeries34);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "hi!" + "'", str35.equals("hi!"));
//        org.junit.Assert.assertNotNull(wildcardClass40);
//        org.junit.Assert.assertNotNull(class41);
//        org.junit.Assert.assertNotNull(wildcardClass49);
//        org.junit.Assert.assertNotNull(class50);
//        org.junit.Assert.assertNotNull(timeSeries52);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "Time" + "'", str53.equals("Time"));
//        org.junit.Assert.assertNotNull(timeSeries54);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertNotNull(class57);
//    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Thu Jun 13 08:39:46 PDT 2019");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        java.lang.String str17 = timeSeries15.getRangeDescription();
        int int18 = timeSeries15.getMaximumItemCount();
        try {
            timeSeries15.update(6, (java.lang.Number) 391L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ThreadContext" + "'", str17.equals("ThreadContext"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2147483647 + "'", int18 == 2147483647);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 1);
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1);
        timeSeries2.setNotify(true);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(1900);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        long long8 = year6.getSerialIndex();
        try {
            timeSeries2.add((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) 1560440371482L, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1900L + "'", long8 == 1900L);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean3 = spreadsheetDate1.equals((java.lang.Object) 31);
        int int4 = spreadsheetDate1.getDayOfWeek();
        int int5 = spreadsheetDate1.getMonth();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((-460));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test445() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test445");
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        int int2 = day1.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate3 = day1.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate5 = serialDate3.getFollowingDayOfWeek(2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean9 = spreadsheetDate7.equals((java.lang.Object) 31);
//        java.util.Date date10 = spreadsheetDate7.toDate();
//        boolean boolean12 = spreadsheetDate7.equals((java.lang.Object) 1560440366809L);
//        int int13 = spreadsheetDate7.getYYYY();
//        org.jfree.data.time.SerialDate serialDate14 = serialDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate7);
//        org.jfree.data.time.SerialDate serialDate16 = serialDate3.getFollowingDayOfWeek(4);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int19 = spreadsheetDate18.toSerial();
//        int int20 = spreadsheetDate18.getDayOfWeek();
//        org.jfree.data.time.SerialDate serialDate21 = serialDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate18);
//        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addDays((int) (short) 1, (org.jfree.data.time.SerialDate) spreadsheetDate18);
//        int int23 = spreadsheetDate18.getDayOfWeek();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1900 + "'", int13 == 1900);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 3 + "'", int20 == 3);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 3 + "'", int23 == 3);
//    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.previous();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass10 = month9.getClass();
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        java.lang.Object obj15 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class11, class14);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass17 = month16.getClass();
        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass17);
        java.lang.Object obj19 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ThreadContext", class11, (java.lang.Class) wildcardClass17);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440363591L, class11);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass22 = month21.getClass();
        java.lang.Class class23 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass22);
        java.lang.Object obj24 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Following", class11, class23);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod2, "", "org.jfree.data.general.SeriesChangeEvent[source=-1]", class11);
        timeSeries25.setDomainDescription("ClassContext");
        timeSeries25.setMaximumItemAge(1560440394529L);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNull(obj15);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(class18);
        org.junit.Assert.assertNull(obj19);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(class23);
        org.junit.Assert.assertNull(obj24);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.clear();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass12 = month11.getClass();
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class13);
        timeSeries14.setDomainDescription("");
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass21 = month20.getClass();
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries14.addAndOrUpdate(timeSeries23);
        java.lang.String str25 = timeSeries23.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries6.addAndOrUpdate(timeSeries23);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener27 = null;
        timeSeries6.removeChangeListener(seriesChangeListener27);
        timeSeries6.setDescription("Time");
        timeSeries6.setNotify(true);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "ThreadContext" + "'", str25.equals("ThreadContext"));
        org.junit.Assert.assertNotNull(timeSeries26);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass1 = month0.getClass();
        boolean boolean3 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month0, (java.lang.Object) 10.0d);
        long long4 = month0.getLastMillisecond();
        org.jfree.data.time.Year year5 = month0.getYear();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int9 = spreadsheetDate8.toSerial();
        int int10 = spreadsheetDate8.getYYYY();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addDays(7, (org.jfree.data.time.SerialDate) spreadsheetDate8);
        int int12 = month0.compareTo((java.lang.Object) serialDate11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1900 + "'", int10 == 1900);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test450() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test450");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getLastMillisecond(calendar1);
//        boolean boolean4 = fixedMillisecond0.equals((java.lang.Object) 1561964399999L);
//        long long5 = fixedMillisecond0.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        boolean boolean11 = fixedMillisecond7.equals((java.lang.Object) 1561964399999L);
//        long long12 = fixedMillisecond7.getSerialIndex();
//        java.lang.Class<?> wildcardClass13 = fixedMillisecond7.getClass();
//        java.lang.Number number14 = timeSeries6.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
//        timeSeries6.addChangeListener(seriesChangeListener15);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440409747L + "'", long2 == 1560440409747L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560440409747L + "'", long5 == 1560440409747L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560440409748L + "'", long9 == 1560440409748L);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560440409748L + "'", long12 == 1560440409748L);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNull(number14);
//    }

//    @Test
//    public void test451() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test451");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        long long3 = day0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//    }

//    @Test
//    public void test452() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test452");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int2 = spreadsheetDate1.toSerial();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        int int4 = day3.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
//        boolean boolean6 = spreadsheetDate1.isOnOrAfter(serialDate5);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int9 = day8.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate10 = day8.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate12 = serialDate10.getFollowingDayOfWeek(2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean16 = spreadsheetDate14.equals((java.lang.Object) 31);
//        java.util.Date date17 = spreadsheetDate14.toDate();
//        boolean boolean19 = spreadsheetDate14.equals((java.lang.Object) 1560440366809L);
//        int int20 = spreadsheetDate14.getYYYY();
//        org.jfree.data.time.SerialDate serialDate21 = serialDate10.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate14);
//        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addYears((-1), serialDate10);
//        int int23 = spreadsheetDate1.compare(serialDate10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate25);
//        boolean boolean27 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate25);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate25);
//        int int29 = spreadsheetDate25.toSerial();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 13 + "'", int9 == 13);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1900 + "'", int20 == 1900);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-43619) + "'", int23 == (-43619));
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
//    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) (short) 0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Thu Jun 13 08:39:55 PDT 2019");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass11 = month10.getClass();
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class12);
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener14);
        java.lang.String str16 = timeSeries13.getDescription();
        java.util.Collection collection17 = timeSeries6.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = null;
        try {
            timeSeries13.add(timeSeriesDataItem18, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(collection17);
    }

//    @Test
//    public void test456() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test456");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        int int4 = fixedMillisecond0.compareTo((java.lang.Object) 8);
//        long long5 = fixedMillisecond0.getLastMillisecond();
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond0.getFirstMillisecond(calendar6);
//        long long8 = fixedMillisecond0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440410258L + "'", long2 == 1560440410258L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560440410258L + "'", long5 == 1560440410258L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560440410258L + "'", long7 == 1560440410258L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560440410258L + "'", long8 == 1560440410258L);
//    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440383789L, "org.jfree.data.general.SeriesChangeEvent[source=-1]", "", class3);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        long long3 = year1.getSerialIndex();
        java.util.Date date4 = year1.getStart();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4, timeZone5);
        java.util.Calendar calendar7 = null;
        try {
            day6.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1900L + "'", long3 == 1900L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone5);
    }

//    @Test
//    public void test459() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test459");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.setDomainDescription("");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass13 = month12.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass21 = month20.getClass();
//        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
//        java.util.List list24 = timeSeries23.getItems();
//        boolean boolean25 = timeSeries16.equals((java.lang.Object) list24);
//        boolean boolean27 = timeSeries16.equals((java.lang.Object) false);
//        java.lang.Object obj28 = timeSeries16.clone();
//        int int29 = timeSeries16.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond30.getLastMillisecond(calendar31);
//        boolean boolean34 = fixedMillisecond30.equals((java.lang.Object) 1561964399999L);
//        long long35 = fixedMillisecond30.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (double) 13);
//        try {
//            timeSeries16.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (double) 100L, false);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(class22);
//        org.junit.Assert.assertNotNull(list24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(obj28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560440410324L + "'", long32 == 1560440410324L);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560440410324L + "'", long35 == 1560440410324L);
//    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("October");
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        timeSeries6.fireSeriesChanged();
        int int18 = timeSeries6.getItemCount();
        timeSeries6.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: ");
        timeSeries6.setRangeDescription("Thu Jun 13 08:39:42 PDT 2019");
        long long23 = timeSeries6.getMaximumItemAge();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 9223372036854775807L + "'", long23 == 9223372036854775807L);
    }

//    @Test
//    public void test462() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test462");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.setDomainDescription("");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass13 = month12.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass21 = month20.getClass();
//        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
//        java.util.List list24 = timeSeries23.getItems();
//        boolean boolean25 = timeSeries16.equals((java.lang.Object) list24);
//        timeSeries16.removeAgedItems(false);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        int int29 = day28.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day28.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries16.getDataItem(regularTimePeriod30);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = fixedMillisecond32.next();
//        java.util.Calendar calendar34 = null;
//        long long35 = fixedMillisecond32.getLastMillisecond(calendar34);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (double) (short) -1);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar39 = null;
//        long long40 = fixedMillisecond38.getLastMillisecond(calendar39);
//        boolean boolean42 = fixedMillisecond38.equals((java.lang.Object) 1561964399999L);
//        long long43 = fixedMillisecond38.getSerialIndex();
//        java.util.Calendar calendar44 = null;
//        fixedMillisecond38.peg(calendar44);
//        java.util.Date date46 = fixedMillisecond38.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond(date46);
//        java.util.Calendar calendar48 = null;
//        long long49 = fixedMillisecond47.getMiddleMillisecond(calendar48);
//        timeSeries16.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(class22);
//        org.junit.Assert.assertNotNull(list24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 13 + "'", int29 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNull(timeSeriesDataItem31);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560440410420L + "'", long35 == 1560440410420L);
//        org.junit.Assert.assertNull(timeSeriesDataItem37);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560440410421L + "'", long40 == 1560440410421L);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560440410421L + "'", long43 == 1560440410421L);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1560440410421L + "'", long49 == 1560440410421L);
//    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int7 = spreadsheetDate6.toSerial();
        int int8 = spreadsheetDate6.getYYYY();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addDays(7, (org.jfree.data.time.SerialDate) spreadsheetDate6);
        boolean boolean10 = spreadsheetDate2.isBefore(serialDate9);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addMonths(2, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1900 + "'", int8 == 1900);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(serialDate11);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        java.lang.Object obj18 = null;
        boolean boolean19 = day17.equals(obj18);
        int int20 = day17.getMonth();
        java.lang.Number number21 = null;
        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) day17, number21, true);
        int int24 = day17.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day17.previous();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
    }

//    @Test
//    public void test465() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test465");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
//        java.lang.Class<?> wildcardClass2 = fixedMillisecond0.getClass();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) 1561964399999L);
//        java.util.Date date5 = fixedMillisecond0.getStart();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass11 = month10.getClass();
//        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class12);
//        timeSeries13.clear();
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass19 = month18.getClass();
//        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass19);
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class20);
//        timeSeries21.setDomainDescription("");
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass28 = month27.getClass();
//        java.lang.Class class29 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass28);
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class29);
//        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries21.addAndOrUpdate(timeSeries30);
//        java.lang.String str32 = timeSeries30.getRangeDescription();
//        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries13.addAndOrUpdate(timeSeries30);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener34 = null;
//        timeSeries13.removeChangeListener(seriesChangeListener34);
//        int int36 = day6.compareTo((java.lang.Object) timeSeries13);
//        long long37 = day6.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertNotNull(class20);
//        org.junit.Assert.assertNotNull(wildcardClass28);
//        org.junit.Assert.assertNotNull(class29);
//        org.junit.Assert.assertNotNull(timeSeries31);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "ThreadContext" + "'", str32.equals("ThreadContext"));
//        org.junit.Assert.assertNotNull(timeSeries33);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560409200000L + "'", long37 == 1560409200000L);
//    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        long long3 = year1.getSerialIndex();
        java.util.Date date4 = year1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date4);
        long long7 = year6.getSerialIndex();
        org.junit.Assert.assertNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1900L + "'", long3 == 1900L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1900L + "'", long7 == 1900L);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.clear();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(1900);
        java.lang.String str10 = year9.toString();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year9, number11);
        try {
            timeSeries6.add(timeSeriesDataItem12);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1900" + "'", str10.equals("1900"));
    }

//    @Test
//    public void test468() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test468");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.setDomainDescription("");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass13 = month12.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond19.next();
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond19.getLastMillisecond(calendar21);
//        long long23 = fixedMillisecond19.getSerialIndex();
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass26 = month25.getClass();
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass26);
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass29 = month28.getClass();
//        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
//        java.lang.Object obj31 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class27, class30);
//        boolean boolean32 = fixedMillisecond19.equals((java.lang.Object) class30);
//        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) year18, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
//        java.lang.String str34 = timeSeries33.getDomainDescription();
//        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass39 = month38.getClass();
//        java.lang.Class class40 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass39);
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class40);
//        timeSeries41.setDomainDescription("");
//        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass48 = month47.getClass();
//        java.lang.Class class49 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass48);
//        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class49);
//        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries41.addAndOrUpdate(timeSeries50);
//        java.lang.String str52 = timeSeries51.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries33.addAndOrUpdate(timeSeries51);
//        boolean boolean55 = timeSeries53.equals((java.lang.Object) 1560440368245L);
//        timeSeries53.setMaximumItemCount(31);
//        int int58 = timeSeries53.getItemCount();
//        try {
//            timeSeries53.delete((int) (byte) 10, 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560440411031L + "'", long22 == 1560440411031L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560440411031L + "'", long23 == 1560440411031L);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertNull(obj31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(timeSeries33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
//        org.junit.Assert.assertNotNull(wildcardClass39);
//        org.junit.Assert.assertNotNull(class40);
//        org.junit.Assert.assertNotNull(wildcardClass48);
//        org.junit.Assert.assertNotNull(class49);
//        org.junit.Assert.assertNotNull(timeSeries51);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "Time" + "'", str52.equals("Time"));
//        org.junit.Assert.assertNotNull(timeSeries53);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
//    }

//    @Test
//    public void test469() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test469");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.setDomainDescription("");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass13 = month12.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass21 = month20.getClass();
//        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
//        timeSeries23.setDomainDescription("");
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries16.addAndOrUpdate(timeSeries23);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener27 = null;
//        timeSeries16.removeChangeListener(seriesChangeListener27);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = fixedMillisecond29.next();
//        java.lang.Class<?> wildcardClass31 = fixedMillisecond29.getClass();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, (double) 1561964399999L);
//        java.lang.Number number34 = timeSeries16.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        int int36 = day35.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate37 = day35.getSerialDate();
//        int int38 = day35.getMonth();
//        java.lang.String str39 = day35.toString();
//        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) day35, (double) 1560440379023L);
//        long long42 = day35.getLastMillisecond();
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(class22);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertNull(number34);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 13 + "'", int36 == 13);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 6 + "'", int38 == 6);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "13-June-2019" + "'", str39.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560495599999L + "'", long42 == 1560495599999L);
//    }

//    @Test
//    public void test470() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test470");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = day0.getFirstMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "", "17-June-2019", class5);
        int int7 = timeSeries6.getMaximumItemCount();
        try {
            timeSeries6.delete((int) (short) 0, (-43594));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
        java.lang.Class<?> wildcardClass2 = fixedMillisecond0.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) 1561964399999L);
        java.util.Date date5 = fixedMillisecond0.getStart();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.SerialDate serialDate8 = day7.getSerialDate();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(serialDate8);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass1 = month0.getClass();
        boolean boolean3 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month0, (java.lang.Object) 10.0d);
        long long4 = month0.getLastMillisecond();
        org.jfree.data.time.Year year5 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month0.next();
        org.jfree.data.time.Year year7 = month0.getYear();
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(year7);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.general.SeriesChangeEvent[source=-1]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
        java.lang.Class<?> wildcardClass2 = fixedMillisecond0.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) 1561964399999L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = timeSeriesDataItem4.getPeriod();
        try {
            java.lang.Object obj6 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) regularTimePeriod5);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

//    @Test
//    public void test476() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test476");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = day0.equals(obj1);
//        java.lang.String str3 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        long long5 = day0.getLastMillisecond();
//        int int7 = day0.compareTo((java.lang.Object) 100L);
//        java.util.Date date8 = day0.getEnd();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day0);
//        java.lang.Object obj10 = seriesChangeEvent9.getSource();
//        java.lang.Object obj11 = seriesChangeEvent9.getSource();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560495599999L + "'", long5 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(obj10);
//        org.junit.Assert.assertNotNull(obj11);
//    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
        java.lang.String str2 = year1.toString();
        java.lang.Number number3 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, number3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int7 = month5.compareTo((java.lang.Object) 1L);
        long long8 = month5.getLastMillisecond();
        int int9 = year1.compareTo((java.lang.Object) long8);
        int int10 = year1.getYear();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1900" + "'", str2.equals("1900"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1561964399999L + "'", long8 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1900 + "'", int10 == 1900);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass21 = month20.getClass();
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
        java.util.List list24 = timeSeries23.getItems();
        boolean boolean25 = timeSeries16.equals((java.lang.Object) list24);
        boolean boolean26 = timeSeries16.isEmpty();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertNotNull(list24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

//    @Test
//    public void test479() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test479");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.setDomainDescription("");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass13 = month12.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond19.next();
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond19.getLastMillisecond(calendar21);
//        long long23 = fixedMillisecond19.getSerialIndex();
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass26 = month25.getClass();
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass26);
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass29 = month28.getClass();
//        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
//        java.lang.Object obj31 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class27, class30);
//        boolean boolean32 = fixedMillisecond19.equals((java.lang.Object) class30);
//        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) year18, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
//        java.lang.String str34 = timeSeries33.getDomainDescription();
//        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass39 = month38.getClass();
//        java.lang.Class class40 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass39);
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class40);
//        timeSeries41.setDomainDescription("");
//        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass48 = month47.getClass();
//        java.lang.Class class49 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass48);
//        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class49);
//        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries41.addAndOrUpdate(timeSeries50);
//        java.lang.String str52 = timeSeries51.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries33.addAndOrUpdate(timeSeries51);
//        int int54 = timeSeries51.getMaximumItemCount();
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = timeSeries51.getDataItem(2958465);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2958465, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560440412326L + "'", long22 == 1560440412326L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560440412326L + "'", long23 == 1560440412326L);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertNull(obj31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(timeSeries33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
//        org.junit.Assert.assertNotNull(wildcardClass39);
//        org.junit.Assert.assertNotNull(class40);
//        org.junit.Assert.assertNotNull(wildcardClass48);
//        org.junit.Assert.assertNotNull(class49);
//        org.junit.Assert.assertNotNull(timeSeries51);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "Time" + "'", str52.equals("Time"));
//        org.junit.Assert.assertNotNull(timeSeries53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 2147483647 + "'", int54 == 2147483647);
//    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int2 = month0.compareTo((java.lang.Object) 1L);
        long long3 = month0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month0.next();
        int int5 = month0.getMonth();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1561964399999L + "'", long3 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) 'a');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test482() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test482");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean2 = fixedMillisecond0.equals((java.lang.Object) 0.0d);
//        long long3 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, 0.0d);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560440412621L + "'", long3 == 1560440412621L);
//    }

//    @Test
//    public void test483() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test483");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.setDomainDescription("");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass13 = month12.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond19.next();
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond19.getLastMillisecond(calendar21);
//        long long23 = fixedMillisecond19.getSerialIndex();
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass26 = month25.getClass();
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass26);
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass29 = month28.getClass();
//        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
//        java.lang.Object obj31 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class27, class30);
//        boolean boolean32 = fixedMillisecond19.equals((java.lang.Object) class30);
//        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) year18, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
//        java.lang.String str34 = timeSeries33.getDomainDescription();
//        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass39 = month38.getClass();
//        java.lang.Class class40 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass39);
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class40);
//        timeSeries41.setDomainDescription("");
//        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass48 = month47.getClass();
//        java.lang.Class class49 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass48);
//        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class49);
//        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries41.addAndOrUpdate(timeSeries50);
//        java.lang.String str52 = timeSeries51.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries33.addAndOrUpdate(timeSeries51);
//        timeSeries33.setRangeDescription("");
//        long long56 = timeSeries33.getMaximumItemAge();
//        timeSeries33.clear();
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560440412840L + "'", long22 == 1560440412840L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560440412840L + "'", long23 == 1560440412840L);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertNull(obj31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(timeSeries33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
//        org.junit.Assert.assertNotNull(wildcardClass39);
//        org.junit.Assert.assertNotNull(class40);
//        org.junit.Assert.assertNotNull(wildcardClass48);
//        org.junit.Assert.assertNotNull(class49);
//        org.junit.Assert.assertNotNull(timeSeries51);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "Time" + "'", str52.equals("Time"));
//        org.junit.Assert.assertNotNull(timeSeries53);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 9223372036854775807L + "'", long56 == 9223372036854775807L);
//    }

//    @Test
//    public void test484() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test484");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1);
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass7 = month6.getClass();
//        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class8);
//        timeSeries9.setDomainDescription("");
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass16 = month15.getClass();
//        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass16);
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class17);
//        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries9.addAndOrUpdate(timeSeries18);
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond22.next();
//        java.util.Calendar calendar24 = null;
//        long long25 = fixedMillisecond22.getLastMillisecond(calendar24);
//        long long26 = fixedMillisecond22.getSerialIndex();
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass29 = month28.getClass();
//        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
//        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass32 = month31.getClass();
//        java.lang.Class class33 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass32);
//        java.lang.Object obj34 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class30, class33);
//        boolean boolean35 = fixedMillisecond22.equals((java.lang.Object) class33);
//        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries18.createCopy((org.jfree.data.time.RegularTimePeriod) year21, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
//        java.lang.String str37 = timeSeries36.getDomainDescription();
//        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass42 = month41.getClass();
//        java.lang.Class class43 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass42);
//        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class43);
//        timeSeries44.setDomainDescription("");
//        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass51 = month50.getClass();
//        java.lang.Class class52 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass51);
//        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class52);
//        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries44.addAndOrUpdate(timeSeries53);
//        java.lang.String str55 = timeSeries54.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries56 = timeSeries36.addAndOrUpdate(timeSeries54);
//        org.jfree.data.time.TimeSeries timeSeries57 = timeSeries2.addAndOrUpdate(timeSeries36);
//        java.lang.Object obj58 = timeSeries2.clone();
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(class8);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNotNull(class17);
//        org.junit.Assert.assertNotNull(timeSeries19);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560440413700L + "'", long25 == 1560440413700L);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560440413700L + "'", long26 == 1560440413700L);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertNotNull(wildcardClass32);
//        org.junit.Assert.assertNotNull(class33);
//        org.junit.Assert.assertNull(obj34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(timeSeries36);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "hi!" + "'", str37.equals("hi!"));
//        org.junit.Assert.assertNotNull(wildcardClass42);
//        org.junit.Assert.assertNotNull(class43);
//        org.junit.Assert.assertNotNull(wildcardClass51);
//        org.junit.Assert.assertNotNull(class52);
//        org.junit.Assert.assertNotNull(timeSeries54);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "Time" + "'", str55.equals("Time"));
//        org.junit.Assert.assertNotNull(timeSeries56);
//        org.junit.Assert.assertNotNull(timeSeries57);
//        org.junit.Assert.assertNotNull(obj58);
//    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        timeSeries6.fireSeriesChanged();
        int int18 = timeSeries6.getItemCount();
        timeSeries6.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: ");
        timeSeries6.setRangeDescription("Thu Jun 13 08:39:42 PDT 2019");
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = timeSeries6.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        java.lang.String str17 = timeSeries16.getDescription();
        try {
            timeSeries16.update(7, (java.lang.Number) 1560440393984L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNull(str17);
    }

//    @Test
//    public void test487() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test487");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean2 = fixedMillisecond0.equals((java.lang.Object) 0.0d);
//        long long3 = fixedMillisecond0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560440414528L + "'", long3 == 1560440414528L);
//    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(9999, 4, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Mar");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

//    @Test
//    public void test490() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test490");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getLastMillisecond(calendar1);
//        boolean boolean4 = fixedMillisecond0.equals((java.lang.Object) 1561964399999L);
//        long long5 = fixedMillisecond0.getSerialIndex();
//        java.util.Calendar calendar6 = null;
//        fixedMillisecond0.peg(calendar6);
//        java.util.Date date8 = fixedMillisecond0.getTime();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) fixedMillisecond0);
//        java.lang.String str10 = seriesChangeEvent9.toString();
//        java.lang.Object obj11 = seriesChangeEvent9.getSource();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440414564L + "'", long2 == 1560440414564L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560440414564L + "'", long5 == 1560440414564L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=Thu Jun 13 08:40:14 PDT 2019]" + "'", str10.equals("org.jfree.data.general.SeriesChangeEvent[source=Thu Jun 13 08:40:14 PDT 2019]"));
//        org.junit.Assert.assertNotNull(obj11);
//    }

//    @Test
//    public void test491() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test491");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.setDomainDescription("");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass13 = month12.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond19.next();
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond19.getLastMillisecond(calendar21);
//        long long23 = fixedMillisecond19.getSerialIndex();
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass26 = month25.getClass();
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass26);
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass29 = month28.getClass();
//        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
//        java.lang.Object obj31 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class27, class30);
//        boolean boolean32 = fixedMillisecond19.equals((java.lang.Object) class30);
//        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) year18, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
//        timeSeries33.setDomainDescription("Time");
//        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass37 = month36.getClass();
//        boolean boolean39 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month36, (java.lang.Object) 10.0d);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = month36.previous();
//        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass46 = month45.getClass();
//        java.lang.Class class47 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass46);
//        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass49 = month48.getClass();
//        java.lang.Class class50 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass49);
//        java.lang.Object obj51 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class47, class50);
//        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass53 = month52.getClass();
//        java.lang.Class class54 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass53);
//        java.lang.Object obj55 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ThreadContext", class47, (java.lang.Class) wildcardClass53);
//        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440363591L, class47);
//        org.jfree.data.time.Month month57 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass58 = month57.getClass();
//        java.lang.Class class59 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass58);
//        java.lang.Object obj60 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Following", class47, class59);
//        java.lang.Class class61 = org.jfree.data.time.RegularTimePeriod.downsize(class47);
//        boolean boolean62 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month36, (java.lang.Object) class47);
//        try {
//            timeSeries33.add((org.jfree.data.time.RegularTimePeriod) month36, (double) 1560440363637L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560440414585L + "'", long22 == 1560440414585L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560440414585L + "'", long23 == 1560440414585L);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertNull(obj31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(timeSeries33);
//        org.junit.Assert.assertNotNull(wildcardClass37);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertNotNull(wildcardClass46);
//        org.junit.Assert.assertNotNull(class47);
//        org.junit.Assert.assertNotNull(wildcardClass49);
//        org.junit.Assert.assertNotNull(class50);
//        org.junit.Assert.assertNull(obj51);
//        org.junit.Assert.assertNotNull(wildcardClass53);
//        org.junit.Assert.assertNotNull(class54);
//        org.junit.Assert.assertNull(obj55);
//        org.junit.Assert.assertNotNull(wildcardClass58);
//        org.junit.Assert.assertNotNull(class59);
//        org.junit.Assert.assertNull(obj60);
//        org.junit.Assert.assertNotNull(class61);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        long long3 = year1.getSerialIndex();
        java.util.Date date4 = year1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date4);
        java.lang.String str7 = year6.toString();
        org.junit.Assert.assertNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1900L + "'", long3 == 1900L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1900" + "'", str7.equals("1900"));
    }

//    @Test
//    public void test493() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test493");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean2 = fixedMillisecond0.equals((java.lang.Object) 0.0d);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getMiddleMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond0.getStart();
//        long long6 = fixedMillisecond0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560440414646L + "'", long4 == 1560440414646L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560440414646L + "'", long6 == 1560440414646L);
//    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setRangeDescription("1-January-1900");
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
    }

//    @Test
//    public void test495() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test495");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d);
//        timeSeries1.setMaximumItemCount((int) (short) 100);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond4.getLastMillisecond(calendar5);
//        boolean boolean8 = fixedMillisecond4.equals((java.lang.Object) 1561964399999L);
//        long long9 = fixedMillisecond4.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (double) 13);
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass18 = month17.getClass();
//        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass18);
//        java.io.InputStream inputStream20 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass18);
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass22 = month21.getClass();
//        java.lang.Class class23 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass22);
//        java.lang.Object obj24 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Thu Jun 13 08:39:19 PDT 2019", (java.lang.Class) wildcardClass18, class23);
//        java.lang.Object obj25 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", (java.lang.Class) wildcardClass18);
//        java.io.InputStream inputStream26 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Jan", (java.lang.Class) wildcardClass18);
//        java.io.InputStream inputStream27 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Following", (java.lang.Class) wildcardClass18);
//        int int28 = timeSeriesDataItem11.compareTo((java.lang.Object) "Following");
//        try {
//            timeSeries1.add(timeSeriesDataItem11, false);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560440414677L + "'", long6 == 1560440414677L);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560440414677L + "'", long9 == 1560440414677L);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertNotNull(class19);
//        org.junit.Assert.assertNotNull(inputStream20);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertNotNull(class23);
//        org.junit.Assert.assertNull(obj24);
//        org.junit.Assert.assertNull(obj25);
//        org.junit.Assert.assertNull(inputStream26);
//        org.junit.Assert.assertNull(inputStream27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//    }

//    @Test
//    public void test496() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test496");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getLastMillisecond(calendar1);
//        boolean boolean4 = fixedMillisecond0.equals((java.lang.Object) 1561964399999L);
//        long long5 = fixedMillisecond0.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) 13);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond0.getMiddleMillisecond(calendar8);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond0.previous();
//        long long11 = fixedMillisecond0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440414879L + "'", long2 == 1560440414879L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560440414879L + "'", long5 == 1560440414879L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560440414879L + "'", long9 == 1560440414879L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560440414879L + "'", long11 == 1560440414879L);
//    }

//    @Test
//    public void test497() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test497");
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        int int2 = day1.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate3 = day1.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate5 = serialDate3.getFollowingDayOfWeek(2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean9 = spreadsheetDate7.equals((java.lang.Object) 31);
//        java.util.Date date10 = spreadsheetDate7.toDate();
//        boolean boolean12 = spreadsheetDate7.equals((java.lang.Object) 1560440366809L);
//        int int13 = spreadsheetDate7.getYYYY();
//        org.jfree.data.time.SerialDate serialDate14 = serialDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate7);
//        org.jfree.data.time.SerialDate serialDate16 = serialDate3.getFollowingDayOfWeek(4);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int19 = spreadsheetDate18.toSerial();
//        int int20 = spreadsheetDate18.getDayOfWeek();
//        org.jfree.data.time.SerialDate serialDate21 = serialDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate18);
//        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addDays((int) (short) 1, (org.jfree.data.time.SerialDate) spreadsheetDate18);
//        org.jfree.data.time.SerialDate serialDate23 = null;
//        try {
//            boolean boolean24 = spreadsheetDate18.isAfter(serialDate23);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1900 + "'", int13 == 1900);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 3 + "'", int20 == 3);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate22);
//    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass7 = month6.getClass();
        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
        java.io.InputStream inputStream9 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass7);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass11 = month10.getClass();
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        java.lang.Object obj13 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Thu Jun 13 08:39:19 PDT 2019", (java.lang.Class) wildcardClass7, class12);
        java.lang.Object obj14 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", (java.lang.Class) wildcardClass7);
        java.io.InputStream inputStream15 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Jan", (java.lang.Class) wildcardClass7);
        java.net.URL uRL16 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("13-June-2019", (java.lang.Class) wildcardClass7);
        java.io.InputStream inputStream17 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("org.jfree.data.general.SeriesChangeEvent[source=13-June-2019]", (java.lang.Class) wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(class8);
        org.junit.Assert.assertNotNull(inputStream9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertNull(obj13);
        org.junit.Assert.assertNull(obj14);
        org.junit.Assert.assertNull(inputStream15);
        org.junit.Assert.assertNull(uRL16);
        org.junit.Assert.assertNull(inputStream17);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
        java.lang.String str2 = year1.toString();
        java.lang.Number number3 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, number3);
        long long5 = year1.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1900" + "'", str2.equals("1900"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-2177424000001L) + "'", long5 == (-2177424000001L));
    }

//    @Test
//    public void test500() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test500");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        int int4 = fixedMillisecond0.compareTo((java.lang.Object) 8);
//        long long5 = fixedMillisecond0.getLastMillisecond();
//        long long6 = fixedMillisecond0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440415064L + "'", long2 == 1560440415064L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560440415064L + "'", long5 == 1560440415064L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560440415064L + "'", long6 == 1560440415064L);
//    }
//}

