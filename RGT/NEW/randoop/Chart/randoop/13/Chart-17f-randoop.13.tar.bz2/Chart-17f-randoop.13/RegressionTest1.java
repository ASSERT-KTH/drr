import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass21 = month20.getClass();
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
        java.util.List list24 = timeSeries23.getItems();
        boolean boolean25 = timeSeries16.equals((java.lang.Object) list24);
        boolean boolean27 = timeSeries16.equals((java.lang.Object) false);
        java.lang.String str28 = timeSeries16.getDescription();
        timeSeries16.removeAgedItems(true);
        java.lang.String str31 = timeSeries16.getRangeDescription();
        timeSeries16.clear();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertNotNull(list24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Value" + "'", str31.equals("Value"));
    }

//    @Test
//    public void test002() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test002");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean4 = spreadsheetDate2.equals((java.lang.Object) 31);
//        java.util.Date date5 = spreadsheetDate2.toDate();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int7 = day6.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day6.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate10 = serialDate8.getFollowingDayOfWeek(2);
//        java.lang.String str11 = serialDate10.toString();
//        int int12 = spreadsheetDate2.compare(serialDate10);
//        try {
//            org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((-457), (org.jfree.data.time.SerialDate) spreadsheetDate2);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 13 + "'", int7 == 13);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "17-June-2019" + "'", str11.equals("17-June-2019"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-43623) + "'", int12 == (-43623));
//    }

//    @Test
//    public void test003() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test003");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.setDomainDescription("");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass13 = month12.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond19.next();
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond19.getLastMillisecond(calendar21);
//        long long23 = fixedMillisecond19.getSerialIndex();
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass26 = month25.getClass();
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass26);
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass29 = month28.getClass();
//        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
//        java.lang.Object obj31 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class27, class30);
//        boolean boolean32 = fixedMillisecond19.equals((java.lang.Object) class30);
//        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) year18, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
//        java.lang.String str34 = timeSeries33.getDomainDescription();
//        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass39 = month38.getClass();
//        java.lang.Class class40 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass39);
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class40);
//        timeSeries41.setDomainDescription("");
//        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass48 = month47.getClass();
//        java.lang.Class class49 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass48);
//        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class49);
//        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries41.addAndOrUpdate(timeSeries50);
//        java.lang.String str52 = timeSeries51.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries33.addAndOrUpdate(timeSeries51);
//        int int54 = timeSeries51.getMaximumItemCount();
//        timeSeries51.setMaximumItemCount(5);
//        timeSeries51.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener58 = null;
//        timeSeries51.removePropertyChangeListener(propertyChangeListener58);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560440415177L + "'", long22 == 1560440415177L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560440415177L + "'", long23 == 1560440415177L);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertNull(obj31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(timeSeries33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
//        org.junit.Assert.assertNotNull(wildcardClass39);
//        org.junit.Assert.assertNotNull(class40);
//        org.junit.Assert.assertNotNull(wildcardClass48);
//        org.junit.Assert.assertNotNull(class49);
//        org.junit.Assert.assertNotNull(timeSeries51);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "Time" + "'", str52.equals("Time"));
//        org.junit.Assert.assertNotNull(timeSeries53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 2147483647 + "'", int54 == 2147483647);
//    }

//    @Test
//    public void test004() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test004");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.clear();
//        timeSeries6.setMaximumItemAge(1560440386279L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond10.next();
//        java.util.Calendar calendar12 = null;
//        long long13 = fixedMillisecond10.getLastMillisecond(calendar12);
//        long long14 = fixedMillisecond10.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass15 = fixedMillisecond10.getClass();
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond10.getFirstMillisecond(calendar16);
//        java.lang.Number number18 = timeSeries6.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560440415432L + "'", long13 == 1560440415432L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560440415432L + "'", long14 == 1560440415432L);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560440415432L + "'", long17 == 1560440415432L);
//        org.junit.Assert.assertNull(number18);
//    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass7 = month6.getClass();
        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
        java.io.InputStream inputStream9 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass7);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass11 = month10.getClass();
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        java.lang.Object obj13 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Thu Jun 13 08:39:19 PDT 2019", (java.lang.Class) wildcardClass7, class12);
        java.lang.Object obj14 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", (java.lang.Class) wildcardClass7);
        java.io.InputStream inputStream15 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Jan", (java.lang.Class) wildcardClass7);
        java.net.URL uRL16 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("13-June-2019", (java.lang.Class) wildcardClass7);
        java.lang.ClassLoader classLoader17 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass7);
        java.io.InputStream inputStream18 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("December", (java.lang.Class) wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(class8);
        org.junit.Assert.assertNotNull(inputStream9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertNull(obj13);
        org.junit.Assert.assertNull(obj14);
        org.junit.Assert.assertNull(inputStream15);
        org.junit.Assert.assertNull(uRL16);
        org.junit.Assert.assertNotNull(classLoader17);
        org.junit.Assert.assertNull(inputStream18);
    }

//    @Test
//    public void test006() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test006");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond0.previous();
//        java.util.Calendar calendar4 = null;
//        long long5 = fixedMillisecond0.getMiddleMillisecond(calendar4);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440415524L + "'", long2 == 1560440415524L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560440415524L + "'", long5 == 1560440415524L);
//    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 1, (int) (byte) 100, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test008() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test008");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean2 = fixedMillisecond0.equals((java.lang.Object) 0.0d);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getMiddleMillisecond(calendar3);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560440415543L + "'", long4 == 1560440415543L);
//    }

//    @Test
//    public void test009() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test009");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.setDomainDescription("");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass13 = month12.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year18.previous();
//        long long20 = year18.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries16.getDataItem((org.jfree.data.time.RegularTimePeriod) year18);
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year23.previous();
//        long long25 = year23.getSerialIndex();
//        java.util.Date date26 = year23.getStart();
//        long long27 = year23.getFirstMillisecond();
//        java.lang.Number number28 = timeSeries16.getValue((org.jfree.data.time.RegularTimePeriod) year23);
//        timeSeries16.removeAgedItems(1560440376363L, true);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = fixedMillisecond32.next();
//        boolean boolean35 = fixedMillisecond32.equals((java.lang.Object) "org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        java.util.Calendar calendar36 = null;
//        long long37 = fixedMillisecond32.getFirstMillisecond(calendar36);
//        try {
//            timeSeries16.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (java.lang.Number) 1560440392542L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1900L + "'", long20 == 1900L);
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1900L + "'", long25 == 1900L);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-2208960000000L) + "'", long27 == (-2208960000000L));
//        org.junit.Assert.assertNull(number28);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560440415563L + "'", long37 == 1560440415563L);
//    }

//    @Test
//    public void test010() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test010");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int2 = spreadsheetDate1.toSerial();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        int int4 = day3.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
//        boolean boolean6 = spreadsheetDate1.isOnOrAfter(serialDate5);
//        int int7 = spreadsheetDate1.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
//    }

//    @Test
//    public void test011() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test011");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getLastMillisecond(calendar10);
//        boolean boolean13 = fixedMillisecond9.equals((java.lang.Object) 1561964399999L);
//        long long14 = fixedMillisecond9.getSerialIndex();
//        java.util.Calendar calendar15 = null;
//        fixedMillisecond9.peg(calendar15);
//        java.util.Date date17 = fixedMillisecond9.getTime();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent18 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) fixedMillisecond9);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, 10.0d);
//        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass25 = month24.getClass();
//        java.lang.Class class26 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass25);
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class26);
//        timeSeries27.setDomainDescription("");
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass34 = month33.getClass();
//        java.lang.Class class35 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass34);
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class35);
//        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries27.addAndOrUpdate(timeSeries36);
//        timeSeries27.fireSeriesChanged();
//        int int39 = timeSeries27.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries6.addAndOrUpdate(timeSeries27);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = fixedMillisecond41.next();
//        java.lang.Class<?> wildcardClass43 = fixedMillisecond41.getClass();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41, (double) 1561964399999L);
//        java.util.Calendar calendar46 = null;
//        fixedMillisecond41.peg(calendar46);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries40.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41, (java.lang.Number) 1560440412840L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560440415785L + "'", long11 == 1560440415785L);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560440415785L + "'", long14 == 1560440415785L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNull(timeSeriesDataItem20);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertNotNull(class26);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNotNull(class35);
//        org.junit.Assert.assertNotNull(timeSeries37);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
//        org.junit.Assert.assertNotNull(timeSeries40);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertNotNull(wildcardClass43);
//        org.junit.Assert.assertNull(timeSeriesDataItem49);
//    }

//    @Test
//    public void test012() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test012");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.setDomainDescription("");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass13 = month12.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass21 = month20.getClass();
//        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
//        java.util.List list24 = timeSeries23.getItems();
//        boolean boolean25 = timeSeries16.equals((java.lang.Object) list24);
//        boolean boolean27 = timeSeries16.equals((java.lang.Object) false);
//        java.lang.String str28 = timeSeries16.getDescription();
//        timeSeries16.removeAgedItems(true);
//        java.lang.String str31 = timeSeries16.getRangeDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = fixedMillisecond32.next();
//        java.util.Calendar calendar34 = null;
//        long long35 = fixedMillisecond32.getLastMillisecond(calendar34);
//        long long36 = fixedMillisecond32.getMiddleMillisecond();
//        java.util.Calendar calendar37 = null;
//        long long38 = fixedMillisecond32.getMiddleMillisecond(calendar37);
//        long long39 = fixedMillisecond32.getMiddleMillisecond();
//        try {
//            timeSeries16.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (java.lang.Number) (byte) 1);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(class22);
//        org.junit.Assert.assertNotNull(list24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNull(str28);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Value" + "'", str31.equals("Value"));
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560440415994L + "'", long35 == 1560440415994L);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560440415994L + "'", long36 == 1560440415994L);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560440415994L + "'", long38 == 1560440415994L);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560440415994L + "'", long39 == 1560440415994L);
//    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass1 = month0.getClass();
        boolean boolean3 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month0, (java.lang.Object) 10.0d);
        long long4 = month0.getLastMillisecond();
        org.jfree.data.time.Year year5 = month0.getYear();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int9 = spreadsheetDate8.toSerial();
        int int10 = spreadsheetDate8.getYYYY();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addDays(7, (org.jfree.data.time.SerialDate) spreadsheetDate8);
        int int12 = month0.compareTo((java.lang.Object) serialDate11);
        java.util.Calendar calendar13 = null;
        try {
            long long14 = month0.getFirstMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1900 + "'", int10 == 1900);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

//    @Test
//    public void test014() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test014");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond3.next();
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond3.getLastMillisecond(calendar5);
//        long long7 = fixedMillisecond3.getSerialIndex();
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass10 = month9.getClass();
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass13 = month12.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        java.lang.Object obj15 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class11, class14);
//        boolean boolean16 = fixedMillisecond3.equals((java.lang.Object) class14);
//        long long17 = fixedMillisecond3.getFirstMillisecond();
//        long long18 = fixedMillisecond3.getSerialIndex();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean22 = spreadsheetDate20.equals((java.lang.Object) 31);
//        int int23 = spreadsheetDate20.getDayOfWeek();
//        int int24 = spreadsheetDate20.getMonth();
//        int int25 = fixedMillisecond3.compareTo((java.lang.Object) spreadsheetDate20);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (double) 1560440363591L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560440416030L + "'", long6 == 1560440416030L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560440416030L + "'", long7 == 1560440416030L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNull(obj15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560440416030L + "'", long17 == 1560440416030L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560440416030L + "'", long18 == 1560440416030L);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 3 + "'", int23 == 3);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d);
        java.util.Collection collection19 = timeSeries6.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = timeSeries18.getTimePeriod((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(collection19);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass21 = month20.getClass();
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
        java.util.List list24 = timeSeries23.getItems();
        boolean boolean25 = timeSeries16.equals((java.lang.Object) list24);
        timeSeries16.removeAgedItems(false);
        java.lang.Comparable comparable28 = timeSeries16.getKey();
        java.lang.Class class29 = timeSeries16.getTimePeriodClass();
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass31 = month30.getClass();
        boolean boolean33 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month30, (java.lang.Object) 10.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = month30.previous();
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass40 = month39.getClass();
        java.lang.Class class41 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass40);
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass43 = month42.getClass();
        java.lang.Class class44 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass43);
        java.lang.Object obj45 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class41, class44);
        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass47 = month46.getClass();
        java.lang.Class class48 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass47);
        java.lang.Object obj49 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ThreadContext", class41, (java.lang.Class) wildcardClass47);
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440363591L, class41);
        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass52 = month51.getClass();
        java.lang.Class class53 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass52);
        java.lang.Object obj54 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Following", class41, class53);
        java.lang.Class class55 = org.jfree.data.time.RegularTimePeriod.downsize(class41);
        boolean boolean56 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month30, (java.lang.Object) class41);
        try {
            timeSeries16.add((org.jfree.data.time.RegularTimePeriod) month30, (double) 1560440385974L, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertNotNull(list24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + comparable28 + "' != '" + "Overwritten values from: 1560440358934" + "'", comparable28.equals("Overwritten values from: 1560440358934"));
        org.junit.Assert.assertNotNull(class29);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertNotNull(class41);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertNotNull(class44);
        org.junit.Assert.assertNull(obj45);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertNotNull(class48);
        org.junit.Assert.assertNull(obj49);
        org.junit.Assert.assertNotNull(wildcardClass52);
        org.junit.Assert.assertNotNull(class53);
        org.junit.Assert.assertNull(obj54);
        org.junit.Assert.assertNotNull(class55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((-43619), (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass11 = month10.getClass();
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class12);
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener14);
        java.lang.String str16 = timeSeries13.getDescription();
        java.util.Collection collection17 = timeSeries6.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries6.removePropertyChangeListener(propertyChangeListener18);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(collection17);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        long long3 = year1.getSerialIndex();
        java.util.Date date4 = year1.getStart();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date4);
        org.junit.Assert.assertNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1900L + "'", long3 == 1900L);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SerialDate serialDate3 = day2.getSerialDate();
        org.junit.Assert.assertNotNull(serialDate3);
    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test022");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = day0.equals(obj1);
//        java.lang.String str3 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        long long5 = day0.getFirstMillisecond();
//        int int6 = day0.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560409200000L + "'", long5 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 13 + "'", int6 == 13);
//    }

//    @Test
//    public void test023() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test023");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.setDomainDescription("");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass13 = month12.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond19.next();
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond19.getLastMillisecond(calendar21);
//        long long23 = fixedMillisecond19.getSerialIndex();
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass26 = month25.getClass();
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass26);
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass29 = month28.getClass();
//        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
//        java.lang.Object obj31 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class27, class30);
//        boolean boolean32 = fixedMillisecond19.equals((java.lang.Object) class30);
//        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) year18, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
//        java.lang.String str34 = timeSeries33.getDomainDescription();
//        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass39 = month38.getClass();
//        java.lang.Class class40 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass39);
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class40);
//        timeSeries41.setDomainDescription("");
//        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass48 = month47.getClass();
//        java.lang.Class class49 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass48);
//        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class49);
//        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries41.addAndOrUpdate(timeSeries50);
//        java.lang.String str52 = timeSeries51.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries33.addAndOrUpdate(timeSeries51);
//        int int54 = timeSeries51.getMaximumItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = fixedMillisecond55.next();
//        java.lang.Class<?> wildcardClass57 = fixedMillisecond55.getClass();
//        java.util.Calendar calendar58 = null;
//        long long59 = fixedMillisecond55.getMiddleMillisecond(calendar58);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = fixedMillisecond55.previous();
//        try {
//            timeSeries51.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond55, (java.lang.Number) 1560440381155L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560440416936L + "'", long22 == 1560440416936L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560440416936L + "'", long23 == 1560440416936L);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertNull(obj31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(timeSeries33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
//        org.junit.Assert.assertNotNull(wildcardClass39);
//        org.junit.Assert.assertNotNull(class40);
//        org.junit.Assert.assertNotNull(wildcardClass48);
//        org.junit.Assert.assertNotNull(class49);
//        org.junit.Assert.assertNotNull(timeSeries51);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "Time" + "'", str52.equals("Time"));
//        org.junit.Assert.assertNotNull(timeSeries53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 2147483647 + "'", int54 == 2147483647);
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//        org.junit.Assert.assertNotNull(wildcardClass57);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 1560440416944L + "'", long59 == 1560440416944L);
//        org.junit.Assert.assertNotNull(regularTimePeriod60);
//    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        timeSeries6.clear();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d);
        java.util.Collection collection19 = timeSeries6.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        long long20 = timeSeries18.getMaximumItemAge();
        long long21 = timeSeries18.getMaximumItemAge();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 9223372036854775807L + "'", long20 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775807L + "'", long21 == 9223372036854775807L);
    }

//    @Test
//    public void test026() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test026");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
//        long long3 = year1.getSerialIndex();
//        java.util.Date date4 = year1.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date4);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate9 = day7.getSerialDate();
//        int int10 = day7.getMonth();
//        long long11 = day7.getFirstMillisecond();
//        boolean boolean13 = day7.equals((java.lang.Object) (-1));
//        int int14 = year6.compareTo((java.lang.Object) day7);
//        org.junit.Assert.assertNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1900L + "'", long3 == 1900L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 13 + "'", int8 == 13);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//    }

//    @Test
//    public void test027() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test027");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean3 = spreadsheetDate1.equals((java.lang.Object) 31);
//        int int4 = spreadsheetDate1.getDayOfWeek();
//        java.lang.String str5 = spreadsheetDate1.getDescription();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int7 = day6.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day6.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate10 = serialDate8.getFollowingDayOfWeek(2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean14 = spreadsheetDate12.equals((java.lang.Object) 31);
//        java.util.Date date15 = spreadsheetDate12.toDate();
//        boolean boolean17 = spreadsheetDate12.equals((java.lang.Object) 1560440366809L);
//        int int18 = spreadsheetDate12.getYYYY();
//        org.jfree.data.time.SerialDate serialDate19 = serialDate8.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate12);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(serialDate19);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day20.previous();
//        long long22 = day20.getFirstMillisecond();
//        try {
//            int int23 = spreadsheetDate1.compareTo((java.lang.Object) long22);
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Long cannot be cast to org.jfree.data.time.SerialDate");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
//        org.junit.Assert.assertNull(str5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 13 + "'", int7 == 13);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1900 + "'", int18 == 1900);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-2206368000000L) + "'", long22 == (-2206368000000L));
//    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(100, (-457), (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass21 = month20.getClass();
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
        java.util.List list24 = timeSeries23.getItems();
        boolean boolean25 = timeSeries16.equals((java.lang.Object) list24);
        boolean boolean27 = timeSeries16.equals((java.lang.Object) false);
        java.lang.Object obj28 = timeSeries16.clone();
        boolean boolean30 = timeSeries16.equals((java.lang.Object) 1560440375447L);
        java.lang.String str31 = timeSeries16.getRangeDescription();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertNotNull(list24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Value" + "'", str31.equals("Value"));
    }

//    @Test
//    public void test030() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test030");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        int int3 = day2.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate4 = day2.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate6 = serialDate4.getFollowingDayOfWeek(2);
//        java.lang.String str7 = serialDate4.getDescription();
//        int int8 = month0.compareTo((java.lang.Object) str7);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNull(str7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(3, (int) (byte) 1);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (java.lang.Number) 10.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = timeSeriesDataItem3.getPeriod();
        java.lang.Object obj5 = timeSeriesDataItem3.clone();
        java.lang.Number number6 = timeSeriesDataItem3.getValue();
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 10.0f + "'", number6.equals(10.0f));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) -1);
        java.lang.String str2 = seriesChangeEvent1.toString();
        java.lang.String str3 = seriesChangeEvent1.toString();
        java.lang.Object obj4 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=-1]"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1]" + "'", str3.equals("org.jfree.data.general.SeriesChangeEvent[source=-1]"));
        org.junit.Assert.assertTrue("'" + obj4 + "' != '" + (byte) -1 + "'", obj4.equals((byte) -1));
    }

//    @Test
//    public void test034() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test034");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean6 = spreadsheetDate4.equals((java.lang.Object) 31);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate9 = day7.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate11 = serialDate9.getFollowingDayOfWeek(2);
//        java.lang.String str12 = serialDate11.toString();
//        boolean boolean13 = spreadsheetDate4.isOnOrAfter(serialDate11);
//        boolean boolean14 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate4);
//        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addDays(9999, (org.jfree.data.time.SerialDate) spreadsheetDate2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean19 = spreadsheetDate17.equals((java.lang.Object) 31);
//        java.util.Date date20 = spreadsheetDate17.toDate();
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        int int22 = day21.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate23 = day21.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate25 = serialDate23.getFollowingDayOfWeek(2);
//        java.lang.String str26 = serialDate25.toString();
//        int int27 = spreadsheetDate17.compare(serialDate25);
//        org.jfree.data.time.SerialDate serialDate28 = spreadsheetDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate17);
//        java.util.Date date29 = spreadsheetDate2.toDate();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean33 = spreadsheetDate31.equals((java.lang.Object) 31);
//        boolean boolean34 = spreadsheetDate2.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate31);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 13 + "'", int8 == 13);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "17-June-2019" + "'", str12.equals("17-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 13 + "'", int22 == 13);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "17-June-2019" + "'", str26.equals("17-June-2019"));
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-43623) + "'", int27 == (-43623));
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass6 = month5.getClass();
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
        java.io.InputStream inputStream8 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass6);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass10 = month9.getClass();
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        java.lang.Object obj12 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Thu Jun 13 08:39:19 PDT 2019", (java.lang.Class) wildcardClass6, class11);
        java.lang.Object obj13 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", (java.lang.Class) wildcardClass6);
        java.io.InputStream inputStream14 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Jan", (java.lang.Class) wildcardClass6);
        java.net.URL uRL15 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("13-June-2019", (java.lang.Class) wildcardClass6);
        java.lang.ClassLoader classLoader16 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass6);
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader16);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNotNull(inputStream8);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNull(obj12);
        org.junit.Assert.assertNull(obj13);
        org.junit.Assert.assertNull(inputStream14);
        org.junit.Assert.assertNull(uRL15);
        org.junit.Assert.assertNotNull(classLoader16);
    }

//    @Test
//    public void test036() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test036");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getLastMillisecond(calendar10);
//        boolean boolean13 = fixedMillisecond9.equals((java.lang.Object) 1561964399999L);
//        long long14 = fixedMillisecond9.getSerialIndex();
//        java.util.Calendar calendar15 = null;
//        fixedMillisecond9.peg(calendar15);
//        java.util.Date date17 = fixedMillisecond9.getTime();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent18 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) fixedMillisecond9);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, 10.0d);
//        java.lang.String str21 = timeSeries6.getRangeDescription();
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560440417648L + "'", long11 == 1560440417648L);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560440417648L + "'", long14 == 1560440417648L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNull(timeSeriesDataItem20);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "ThreadContext" + "'", str21.equals("ThreadContext"));
//    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(1900);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year18.previous();
        long long20 = year18.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries16.getDataItem((org.jfree.data.time.RegularTimePeriod) year18);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(1900);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year23.previous();
        long long25 = year23.getSerialIndex();
        java.util.Date date26 = year23.getStart();
        long long27 = year23.getFirstMillisecond();
        java.lang.Number number28 = timeSeries16.getValue((org.jfree.data.time.RegularTimePeriod) year23);
        timeSeries16.removeAgedItems(1560440376363L, true);
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass36 = month35.getClass();
        java.lang.Class class37 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass36);
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class37);
        java.beans.PropertyChangeListener propertyChangeListener39 = null;
        timeSeries38.addPropertyChangeListener(propertyChangeListener39);
        java.lang.String str41 = timeSeries38.getDescription();
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(1900);
        java.lang.String str44 = year43.toString();
        java.lang.Number number45 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year43, number45);
        timeSeries38.delete((org.jfree.data.time.RegularTimePeriod) year43);
        java.lang.Number number48 = null;
        try {
            timeSeries16.update((org.jfree.data.time.RegularTimePeriod) year43, number48);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1900L + "'", long20 == 1900L);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1900L + "'", long25 == 1900L);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-2208960000000L) + "'", long27 == (-2208960000000L));
        org.junit.Assert.assertNull(number28);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(class37);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "1900" + "'", str44.equals("1900"));
    }

//    @Test
//    public void test038() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test038");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.setDomainDescription("");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass13 = month12.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass21 = month20.getClass();
//        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
//        java.util.List list24 = timeSeries23.getItems();
//        boolean boolean25 = timeSeries16.equals((java.lang.Object) list24);
//        timeSeries16.removeAgedItems(false);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        int int29 = day28.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day28.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries16.getDataItem(regularTimePeriod30);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod30, (java.lang.Number) 1560440379023L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(class22);
//        org.junit.Assert.assertNotNull(list24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 13 + "'", int29 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNull(timeSeriesDataItem31);
//    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass21 = month20.getClass();
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
        java.util.List list24 = timeSeries23.getItems();
        boolean boolean25 = timeSeries16.equals((java.lang.Object) list24);
        timeSeries16.removeAgedItems(true);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = timeSeries16.getTimePeriod((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertNotNull(list24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass11 = month10.getClass();
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class12);
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener14);
        java.lang.String str16 = timeSeries13.getDescription();
        java.util.Collection collection17 = timeSeries6.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        java.util.Collection collection18 = org.jfree.chart.util.ObjectUtilities.deepClone(collection17);
        java.util.Collection collection19 = org.jfree.chart.util.ObjectUtilities.deepClone(collection17);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertNotNull(collection19);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(4);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean3 = spreadsheetDate1.equals((java.lang.Object) 31);
        int int4 = spreadsheetDate1.getDayOfWeek();
        java.lang.String str5 = spreadsheetDate1.getDescription();
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addYears(0, serialDate8);
        boolean boolean10 = spreadsheetDate1.isAfter(serialDate9);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean10);
        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(class12);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(8);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 8");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test044");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.setDomainDescription("");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass13 = month12.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
//        java.lang.String str17 = timeSeries15.getRangeDescription();
//        int int18 = timeSeries15.getMaximumItemCount();
//        long long19 = timeSeries15.getMaximumItemAge();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond20.getLastMillisecond(calendar21);
//        boolean boolean24 = fixedMillisecond20.equals((java.lang.Object) 1561964399999L);
//        long long25 = fixedMillisecond20.getSerialIndex();
//        java.util.Date date26 = fixedMillisecond20.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = fixedMillisecond27.next();
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
//        try {
//            timeSeries15.update(3, (java.lang.Number) 31);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ThreadContext" + "'", str17.equals("ThreadContext"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2147483647 + "'", int18 == 2147483647);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 9223372036854775807L + "'", long19 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560440418703L + "'", long22 == 1560440418703L);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560440418703L + "'", long25 == 1560440418703L);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(timeSeries29);
//    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month1.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month1.previous();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(1900);
        long long6 = year5.getLastMillisecond();
        boolean boolean7 = month1.equals((java.lang.Object) year5);
        long long8 = year5.getSerialIndex();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(7, year5);
        long long10 = year5.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-2177424000001L) + "'", long6 == (-2177424000001L));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1900L + "'", long8 == 1900L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1900L + "'", long10 == 1900L);
    }

//    @Test
//    public void test046() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test046");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getLastMillisecond(calendar1);
//        boolean boolean4 = fixedMillisecond0.equals((java.lang.Object) 1561964399999L);
//        long long5 = fixedMillisecond0.getSerialIndex();
//        java.util.Date date6 = fixedMillisecond0.getEnd();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass12 = month11.getClass();
//        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class13);
//        timeSeries14.setDomainDescription("");
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass21 = month20.getClass();
//        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries14.addAndOrUpdate(timeSeries23);
//        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = fixedMillisecond27.next();
//        java.util.Calendar calendar29 = null;
//        long long30 = fixedMillisecond27.getLastMillisecond(calendar29);
//        long long31 = fixedMillisecond27.getSerialIndex();
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass34 = month33.getClass();
//        java.lang.Class class35 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass34);
//        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass37 = month36.getClass();
//        java.lang.Class class38 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass37);
//        java.lang.Object obj39 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class35, class38);
//        boolean boolean40 = fixedMillisecond27.equals((java.lang.Object) class38);
//        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries23.createCopy((org.jfree.data.time.RegularTimePeriod) year26, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
//        java.lang.String str42 = timeSeries41.getDomainDescription();
//        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass47 = month46.getClass();
//        java.lang.Class class48 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass47);
//        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class48);
//        timeSeries49.setDomainDescription("");
//        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass56 = month55.getClass();
//        java.lang.Class class57 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass56);
//        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class57);
//        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries49.addAndOrUpdate(timeSeries58);
//        java.lang.String str60 = timeSeries59.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries41.addAndOrUpdate(timeSeries59);
//        boolean boolean63 = timeSeries61.equals((java.lang.Object) 1560440368245L);
//        java.lang.Class class64 = timeSeries61.getTimePeriodClass();
//        java.lang.Object obj65 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("October", class64);
//        java.lang.Class class66 = org.jfree.data.time.RegularTimePeriod.downsize(class64);
//        org.jfree.data.time.TimeSeries timeSeries67 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date6, class66);
//        org.jfree.data.time.SerialDate serialDate68 = org.jfree.data.time.SerialDate.createInstance(date6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440418758L + "'", long2 == 1560440418758L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560440418758L + "'", long5 == 1560440418758L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNotNull(class13);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(class22);
//        org.junit.Assert.assertNotNull(timeSeries24);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560440418763L + "'", long30 == 1560440418763L);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560440418763L + "'", long31 == 1560440418763L);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNotNull(class35);
//        org.junit.Assert.assertNotNull(wildcardClass37);
//        org.junit.Assert.assertNotNull(class38);
//        org.junit.Assert.assertNull(obj39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(timeSeries41);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "hi!" + "'", str42.equals("hi!"));
//        org.junit.Assert.assertNotNull(wildcardClass47);
//        org.junit.Assert.assertNotNull(class48);
//        org.junit.Assert.assertNotNull(wildcardClass56);
//        org.junit.Assert.assertNotNull(class57);
//        org.junit.Assert.assertNotNull(timeSeries59);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "Time" + "'", str60.equals("Time"));
//        org.junit.Assert.assertNotNull(timeSeries61);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertNotNull(class64);
//        org.junit.Assert.assertNull(obj65);
//        org.junit.Assert.assertNotNull(class66);
//        org.junit.Assert.assertNotNull(serialDate68);
//    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test047");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getLastMillisecond(calendar2);
//        long long4 = fixedMillisecond0.getSerialIndex();
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass7 = month6.getClass();
//        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass10 = month9.getClass();
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
//        java.lang.Object obj12 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class8, class11);
//        boolean boolean13 = fixedMillisecond0.equals((java.lang.Object) class11);
//        java.util.Date date14 = fixedMillisecond0.getStart();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560440419434L + "'", long3 == 1560440419434L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560440419434L + "'", long4 == 1560440419434L);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(class8);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertNull(obj12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(date14);
//    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        timeSeries6.removeAgedItems(1560440360014L, false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean3 = spreadsheetDate1.equals((java.lang.Object) 31);
        int int4 = spreadsheetDate1.getDayOfWeek();
        java.lang.String str5 = spreadsheetDate1.getDescription();
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addYears(0, serialDate8);
        boolean boolean10 = spreadsheetDate1.isAfter(serialDate9);
        try {
            org.jfree.data.time.SerialDate serialDate12 = serialDate9.getPreviousDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Value");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        long long3 = year1.getSerialIndex();
        java.util.Date date4 = year1.getStart();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date4);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(1900);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        long long10 = year8.getSerialIndex();
        java.util.Date date11 = year8.getStart();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date11, timeZone12);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date4, timeZone12);
        int int15 = day14.getDayOfMonth();
        int int16 = day14.getYear();
        org.junit.Assert.assertNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1900L + "'", long3 == 1900L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1900L + "'", long10 == 1900L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1900 + "'", int16 == 1900);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (2) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        java.lang.Object obj3 = null;
        boolean boolean4 = day2.equals(obj3);
        int int5 = day2.getMonth();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day2, (java.lang.Number) 11, true);
        try {
            java.lang.Number number10 = timeSeries1.getValue(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        long long3 = year1.getSerialIndex();
        java.util.Date date4 = year1.getStart();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
        long long6 = month5.getLastMillisecond();
        java.lang.String str7 = month5.toString();
        org.junit.Assert.assertNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1900L + "'", long3 == 1900L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-2206281600001L) + "'", long6 == (-2206281600001L));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "January 1900" + "'", str7.equals("January 1900"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month1.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month1.previous();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(1900);
        long long6 = year5.getLastMillisecond();
        boolean boolean7 = month1.equals((java.lang.Object) year5);
        long long8 = year5.getSerialIndex();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(7, year5);
        int int10 = month9.getMonth();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-2177424000001L) + "'", long6 == (-2177424000001L));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1900L + "'", long8 == 1900L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 7 + "'", int10 == 7);
    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test056");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean3 = spreadsheetDate1.equals((java.lang.Object) 31);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        int int5 = day4.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate6 = day4.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate8 = serialDate6.getFollowingDayOfWeek(2);
//        java.lang.String str9 = serialDate8.toString();
//        boolean boolean10 = spreadsheetDate1.isOnOrBefore(serialDate8);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean14 = spreadsheetDate12.equals((java.lang.Object) 31);
//        int int15 = spreadsheetDate12.getDayOfWeek();
//        int int16 = spreadsheetDate12.getMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate18);
//        boolean boolean20 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate12, (org.jfree.data.time.SerialDate) spreadsheetDate18);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean24 = spreadsheetDate22.equals((java.lang.Object) 31);
//        int int25 = spreadsheetDate22.getYYYY();
//        java.util.Date date26 = spreadsheetDate22.toDate();
//        int int27 = spreadsheetDate12.compare((org.jfree.data.time.SerialDate) spreadsheetDate22);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        int int29 = day28.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate30 = day28.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate32 = serialDate30.getFollowingDayOfWeek(2);
//        org.jfree.data.time.SerialDate serialDate33 = null;
//        try {
//            boolean boolean35 = spreadsheetDate22.isInRange(serialDate30, serialDate33, (-435));
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "17-June-2019" + "'", str9.equals("17-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 3 + "'", int15 == 3);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1900 + "'", int25 == 1900);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 13 + "'", int29 == 13);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertNotNull(serialDate32);
//    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.clear();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass12 = month11.getClass();
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class13);
        timeSeries14.setDomainDescription("");
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass21 = month20.getClass();
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries14.addAndOrUpdate(timeSeries23);
        java.lang.String str25 = timeSeries23.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries6.addAndOrUpdate(timeSeries23);
        timeSeries23.setDescription("Time");
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "ThreadContext" + "'", str25.equals("ThreadContext"));
        org.junit.Assert.assertNotNull(timeSeries26);
    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test058");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean5 = spreadsheetDate3.equals((java.lang.Object) 31);
//        int int6 = spreadsheetDate3.getYYYY();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int9 = day8.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate10 = day8.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate12 = serialDate10.getFollowingDayOfWeek(2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean16 = spreadsheetDate14.equals((java.lang.Object) 31);
//        java.util.Date date17 = spreadsheetDate14.toDate();
//        boolean boolean19 = spreadsheetDate14.equals((java.lang.Object) 1560440366809L);
//        int int20 = spreadsheetDate14.getYYYY();
//        org.jfree.data.time.SerialDate serialDate21 = serialDate10.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate14);
//        org.jfree.data.time.SerialDate serialDate23 = serialDate10.getFollowingDayOfWeek(4);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int26 = spreadsheetDate25.toSerial();
//        int int27 = spreadsheetDate25.getDayOfWeek();
//        org.jfree.data.time.SerialDate serialDate28 = serialDate10.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate25);
//        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.addDays((int) (short) 1, (org.jfree.data.time.SerialDate) spreadsheetDate25);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        int int31 = day30.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate32 = day30.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate34 = serialDate32.getFollowingDayOfWeek(2);
//        java.lang.String str35 = serialDate34.toString();
//        org.jfree.data.time.SerialDate serialDate37 = serialDate34.getNearestDayOfWeek((int) (byte) 1);
//        org.jfree.data.time.SerialDate serialDate39 = serialDate34.getNearestDayOfWeek((int) (short) 1);
//        org.jfree.data.time.SerialDate serialDate40 = spreadsheetDate25.getEndOfCurrentMonth(serialDate34);
//        boolean boolean41 = spreadsheetDate3.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate25);
//        boolean boolean42 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate25);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1900 + "'", int6 == 1900);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 13 + "'", int9 == 13);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1900 + "'", int20 == 1900);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 10 + "'", int26 == 10);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 3 + "'", int27 == 3);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 13 + "'", int31 == 13);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "17-June-2019" + "'", str35.equals("17-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertNotNull(serialDate39);
//        org.junit.Assert.assertNotNull(serialDate40);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(1900);
        java.lang.String str3 = year2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year2.next();
        try {
            org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(9999, year2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1900" + "'", str3.equals("1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass1 = month0.getClass();
        boolean boolean3 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month0, (java.lang.Object) 10.0d);
        long long4 = month0.getLastMillisecond();
        org.jfree.data.time.Year year5 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month0.previous();
        int int7 = month0.getMonth();
        java.util.Calendar calendar8 = null;
        try {
            month0.peg(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test061");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.setDomainDescription("");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass13 = month12.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond19.next();
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond19.getLastMillisecond(calendar21);
//        long long23 = fixedMillisecond19.getSerialIndex();
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass26 = month25.getClass();
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass26);
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass29 = month28.getClass();
//        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
//        java.lang.Object obj31 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class27, class30);
//        boolean boolean32 = fixedMillisecond19.equals((java.lang.Object) class30);
//        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) year18, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
//        java.lang.String str34 = timeSeries33.getDomainDescription();
//        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass39 = month38.getClass();
//        java.lang.Class class40 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass39);
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class40);
//        timeSeries41.setDomainDescription("");
//        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass48 = month47.getClass();
//        java.lang.Class class49 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass48);
//        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class49);
//        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries41.addAndOrUpdate(timeSeries50);
//        java.lang.String str52 = timeSeries51.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries33.addAndOrUpdate(timeSeries51);
//        java.lang.String str54 = timeSeries53.getDescription();
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = timeSeries53.getTimePeriod(4);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560440421453L + "'", long22 == 1560440421453L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560440421453L + "'", long23 == 1560440421453L);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertNull(obj31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(timeSeries33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
//        org.junit.Assert.assertNotNull(wildcardClass39);
//        org.junit.Assert.assertNotNull(class40);
//        org.junit.Assert.assertNotNull(wildcardClass48);
//        org.junit.Assert.assertNotNull(class49);
//        org.junit.Assert.assertNotNull(timeSeries51);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "Time" + "'", str52.equals("Time"));
//        org.junit.Assert.assertNotNull(timeSeries53);
//        org.junit.Assert.assertNull(str54);
//    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test062");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.setDomainDescription("");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass13 = month12.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass21 = month20.getClass();
//        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
//        java.util.List list24 = timeSeries23.getItems();
//        boolean boolean25 = timeSeries16.equals((java.lang.Object) list24);
//        boolean boolean27 = timeSeries16.equals((java.lang.Object) false);
//        java.beans.PropertyChangeListener propertyChangeListener28 = null;
//        timeSeries16.removePropertyChangeListener(propertyChangeListener28);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond30.getLastMillisecond(calendar31);
//        boolean boolean34 = fixedMillisecond30.equals((java.lang.Object) 1561964399999L);
//        long long35 = fixedMillisecond30.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (double) 13);
//        java.lang.Object obj38 = timeSeriesDataItem37.clone();
//        boolean boolean39 = timeSeries16.equals(obj38);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = fixedMillisecond40.next();
//        java.lang.Class<?> wildcardClass42 = fixedMillisecond40.getClass();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, (double) 1561964399999L);
//        java.util.Date date45 = fixedMillisecond40.getStart();
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date45);
//        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month(date45);
//        try {
//            timeSeries16.add((org.jfree.data.time.RegularTimePeriod) month47, (double) 1560440375744L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(class22);
//        org.junit.Assert.assertNotNull(list24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560440421489L + "'", long32 == 1560440421489L);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560440421489L + "'", long35 == 1560440421489L);
//        org.junit.Assert.assertNotNull(obj38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertNotNull(wildcardClass42);
//        org.junit.Assert.assertNotNull(date45);
//    }

//    @Test
//    public void test063() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test063");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getLastMillisecond(calendar2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond0.previous();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560440421508L + "'", long3 == 1560440421508L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.clear();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass12 = month11.getClass();
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class13);
        timeSeries14.setDomainDescription("");
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass21 = month20.getClass();
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries14.addAndOrUpdate(timeSeries23);
        java.lang.String str25 = timeSeries23.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries6.addAndOrUpdate(timeSeries23);
        boolean boolean27 = timeSeries23.isEmpty();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "ThreadContext" + "'", str25.equals("ThreadContext"));
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

//    @Test
//    public void test065() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test065");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
//        long long3 = year1.getSerialIndex();
//        java.util.Date date4 = year1.getStart();
//        long long5 = year1.getFirstMillisecond();
//        int int6 = year1.getYear();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        java.lang.Object obj8 = null;
//        boolean boolean9 = day7.equals(obj8);
//        java.lang.String str10 = day7.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day7.previous();
//        int int12 = year1.compareTo((java.lang.Object) day7);
//        long long13 = year1.getSerialIndex();
//        java.util.Calendar calendar14 = null;
//        try {
//            year1.peg(calendar14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1900L + "'", long3 == 1900L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-2208960000000L) + "'", long5 == (-2208960000000L));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1900 + "'", int6 == 1900);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "13-June-2019" + "'", str10.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1900L + "'", long13 == 1900L);
//    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test066");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
//        long long3 = year1.getSerialIndex();
//        java.util.Date date4 = year1.getStart();
//        long long5 = year1.getFirstMillisecond();
//        int int6 = year1.getYear();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        java.lang.Object obj8 = null;
//        boolean boolean9 = day7.equals(obj8);
//        java.lang.String str10 = day7.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day7.previous();
//        int int12 = year1.compareTo((java.lang.Object) day7);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day7.previous();
//        int int14 = day7.getMonth();
//        java.util.Calendar calendar15 = null;
//        try {
//            day7.peg(calendar15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1900L + "'", long3 == 1900L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-2208960000000L) + "'", long5 == (-2208960000000L));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1900 + "'", int6 == 1900);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "13-June-2019" + "'", str10.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test067");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.setDomainDescription("");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass13 = month12.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond19.next();
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond19.getLastMillisecond(calendar21);
//        long long23 = fixedMillisecond19.getSerialIndex();
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass26 = month25.getClass();
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass26);
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass29 = month28.getClass();
//        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
//        java.lang.Object obj31 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class27, class30);
//        boolean boolean32 = fixedMillisecond19.equals((java.lang.Object) class30);
//        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) year18, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
//        java.lang.String str34 = timeSeries33.getDomainDescription();
//        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass39 = month38.getClass();
//        java.lang.Class class40 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass39);
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class40);
//        timeSeries41.setDomainDescription("");
//        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass48 = month47.getClass();
//        java.lang.Class class49 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass48);
//        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class49);
//        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries41.addAndOrUpdate(timeSeries50);
//        java.lang.String str52 = timeSeries51.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries33.addAndOrUpdate(timeSeries51);
//        java.lang.String str54 = timeSeries53.getDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar56 = null;
//        long long57 = fixedMillisecond55.getLastMillisecond(calendar56);
//        boolean boolean59 = fixedMillisecond55.equals((java.lang.Object) 1561964399999L);
//        long long60 = fixedMillisecond55.getLastMillisecond();
//        timeSeries53.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond55);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560440421609L + "'", long22 == 1560440421609L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560440421609L + "'", long23 == 1560440421609L);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertNull(obj31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(timeSeries33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
//        org.junit.Assert.assertNotNull(wildcardClass39);
//        org.junit.Assert.assertNotNull(class40);
//        org.junit.Assert.assertNotNull(wildcardClass48);
//        org.junit.Assert.assertNotNull(class49);
//        org.junit.Assert.assertNotNull(timeSeries51);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "Time" + "'", str52.equals("Time"));
//        org.junit.Assert.assertNotNull(timeSeries53);
//        org.junit.Assert.assertNull(str54);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1560440421615L + "'", long57 == 1560440421615L);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1560440421615L + "'", long60 == 1560440421615L);
//    }

//    @Test
//    public void test068() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test068");
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        int int2 = day1.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate3 = day1.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate5 = serialDate3.getFollowingDayOfWeek(2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean9 = spreadsheetDate7.equals((java.lang.Object) 31);
//        java.util.Date date10 = spreadsheetDate7.toDate();
//        boolean boolean12 = spreadsheetDate7.equals((java.lang.Object) 1560440366809L);
//        int int13 = spreadsheetDate7.getYYYY();
//        org.jfree.data.time.SerialDate serialDate14 = serialDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate7);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate14);
//        try {
//            org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (short) 10, serialDate14);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1900 + "'", int13 == 1900);
//        org.junit.Assert.assertNotNull(serialDate14);
//    }

//    @Test
//    public void test069() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test069");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.setDomainDescription("");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass13 = month12.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond19.next();
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond19.getLastMillisecond(calendar21);
//        long long23 = fixedMillisecond19.getSerialIndex();
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass26 = month25.getClass();
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass26);
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass29 = month28.getClass();
//        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
//        java.lang.Object obj31 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class27, class30);
//        boolean boolean32 = fixedMillisecond19.equals((java.lang.Object) class30);
//        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) year18, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
//        java.lang.String str34 = timeSeries33.getDomainDescription();
//        timeSeries33.removeAgedItems(1560440369753L, false);
//        timeSeries33.setRangeDescription("Thu Jun 13 08:40:04 PDT 2019");
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560440422798L + "'", long22 == 1560440422798L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560440422798L + "'", long23 == 1560440422798L);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertNull(obj31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(timeSeries33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
//    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test070");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.setDomainDescription("");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass13 = month12.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass21 = month20.getClass();
//        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
//        timeSeries23.setDomainDescription("");
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries16.addAndOrUpdate(timeSeries23);
//        java.lang.String str27 = timeSeries26.getDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean30 = fixedMillisecond28.equals((java.lang.Object) 0.0d);
//        java.util.Calendar calendar31 = null;
//        fixedMillisecond28.peg(calendar31);
//        java.lang.String str33 = fixedMillisecond28.toString();
//        long long34 = fixedMillisecond28.getMiddleMillisecond();
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass36 = month35.getClass();
//        boolean boolean38 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month35, (java.lang.Object) 10.0d);
//        long long39 = month35.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries26.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (org.jfree.data.time.RegularTimePeriod) month35);
//        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass45 = month44.getClass();
//        java.lang.Class class46 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass45);
//        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class46);
//        timeSeries47.setDomainDescription("");
//        org.jfree.data.time.Month month53 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass54 = month53.getClass();
//        java.lang.Class class55 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass54);
//        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class55);
//        org.jfree.data.time.TimeSeries timeSeries57 = timeSeries47.addAndOrUpdate(timeSeries56);
//        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day();
//        java.lang.Object obj59 = null;
//        boolean boolean60 = day58.equals(obj59);
//        int int61 = day58.getMonth();
//        java.lang.Number number62 = null;
//        timeSeries47.add((org.jfree.data.time.RegularTimePeriod) day58, number62, true);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond65 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = fixedMillisecond65.next();
//        java.lang.Class<?> wildcardClass67 = fixedMillisecond65.getClass();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem69 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond65, (double) 1561964399999L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem71 = timeSeries47.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond65, 0.0d);
//        long long72 = fixedMillisecond65.getFirstMillisecond();
//        java.lang.Number number73 = timeSeries40.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond65);
//        timeSeries40.removeAgedItems(false);
//        java.beans.PropertyChangeListener propertyChangeListener76 = null;
//        timeSeries40.addPropertyChangeListener(propertyChangeListener76);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(class22);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertNull(str27);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Thu Jun 13 08:40:22 PDT 2019" + "'", str33.equals("Thu Jun 13 08:40:22 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560440422892L + "'", long34 == 1560440422892L);
//        org.junit.Assert.assertNotNull(wildcardClass36);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1561964399999L + "'", long39 == 1561964399999L);
//        org.junit.Assert.assertNotNull(timeSeries40);
//        org.junit.Assert.assertNotNull(wildcardClass45);
//        org.junit.Assert.assertNotNull(class46);
//        org.junit.Assert.assertNotNull(wildcardClass54);
//        org.junit.Assert.assertNotNull(class55);
//        org.junit.Assert.assertNotNull(timeSeries57);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 6 + "'", int61 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod66);
//        org.junit.Assert.assertNotNull(wildcardClass67);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem71);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 1560440422902L + "'", long72 == 1560440422902L);
//        org.junit.Assert.assertNull(number73);
//    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.clear();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass12 = month11.getClass();
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class13);
        timeSeries14.setDomainDescription("");
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass21 = month20.getClass();
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries14.addAndOrUpdate(timeSeries23);
        java.lang.String str25 = timeSeries23.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries6.addAndOrUpdate(timeSeries23);
        java.lang.Object obj27 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) timeSeries26);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "ThreadContext" + "'", str25.equals("ThreadContext"));
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNotNull(obj27);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((-43623));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(7, (int) ' ');
        int int3 = month2.getMonth();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = month2.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 7 + "'", int3 == 7);
    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test074");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int2 = spreadsheetDate1.toSerial();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        int int4 = day3.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
//        boolean boolean6 = spreadsheetDate1.isOnOrAfter(serialDate5);
//        java.lang.String str7 = spreadsheetDate1.getDescription();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int9 = day8.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate10 = day8.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate12 = serialDate10.getFollowingDayOfWeek(2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean16 = spreadsheetDate14.equals((java.lang.Object) 31);
//        int int17 = spreadsheetDate14.getDayOfWeek();
//        int int18 = spreadsheetDate14.getDayOfMonth();
//        boolean boolean19 = spreadsheetDate1.isInRange(serialDate10, (org.jfree.data.time.SerialDate) spreadsheetDate14);
//        spreadsheetDate1.setDescription("Following");
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNull(str7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 13 + "'", int9 == 13);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 3 + "'", int17 == 3);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 9 + "'", int18 == 9);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test075");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
//        java.lang.Class<?> wildcardClass2 = fixedMillisecond0.getClass();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getLastMillisecond(calendar3);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560440423359L + "'", long4 == 1560440423359L);
//    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass1 = month0.getClass();
        boolean boolean3 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month0, (java.lang.Object) 10.0d);
        long long4 = month0.getLastMillisecond();
        org.jfree.data.time.Year year5 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month0.previous();
        int int7 = month0.getMonth();
        java.lang.String str8 = month0.toString();
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test077");
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        int int2 = day1.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate3 = day1.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate5 = serialDate3.getFollowingDayOfWeek(2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean9 = spreadsheetDate7.equals((java.lang.Object) 31);
//        java.util.Date date10 = spreadsheetDate7.toDate();
//        boolean boolean12 = spreadsheetDate7.equals((java.lang.Object) 1560440366809L);
//        int int13 = spreadsheetDate7.getYYYY();
//        org.jfree.data.time.SerialDate serialDate14 = serialDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate7);
//        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addYears((-1), serialDate3);
//        try {
//            org.jfree.data.time.SerialDate serialDate17 = serialDate3.getFollowingDayOfWeek(30);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1900 + "'", int13 == 1900);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNotNull(serialDate15);
//    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test078");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean3 = spreadsheetDate1.equals((java.lang.Object) 31);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        int int5 = day4.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate6 = day4.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate8 = serialDate6.getFollowingDayOfWeek(2);
//        java.lang.String str9 = serialDate8.toString();
//        boolean boolean10 = spreadsheetDate1.isOnOrBefore(serialDate8);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean14 = spreadsheetDate12.equals((java.lang.Object) 31);
//        int int15 = spreadsheetDate12.getDayOfWeek();
//        int int16 = spreadsheetDate12.getMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate18);
//        boolean boolean20 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate12, (org.jfree.data.time.SerialDate) spreadsheetDate18);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean24 = spreadsheetDate22.equals((java.lang.Object) 31);
//        int int25 = spreadsheetDate22.getYYYY();
//        java.util.Date date26 = spreadsheetDate22.toDate();
//        int int27 = spreadsheetDate12.compare((org.jfree.data.time.SerialDate) spreadsheetDate22);
//        int int28 = spreadsheetDate12.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "17-June-2019" + "'", str9.equals("17-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 3 + "'", int15 == 3);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1900 + "'", int25 == 1900);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 9 + "'", int28 == 9);
//    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((-460), false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        long long3 = year1.getSerialIndex();
        java.util.Date date4 = year1.getStart();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
        long long6 = month5.getLastMillisecond();
        int int7 = month5.getYearValue();
        long long8 = month5.getFirstMillisecond();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = month5.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1900L + "'", long3 == 1900L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-2206281600001L) + "'", long6 == (-2206281600001L));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1900 + "'", int7 == 1900);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-2208960000000L) + "'", long8 == (-2208960000000L));
    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test081");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getLastMillisecond(calendar1);
//        boolean boolean4 = fixedMillisecond0.equals((java.lang.Object) 1561964399999L);
//        long long5 = fixedMillisecond0.getSerialIndex();
//        java.util.Calendar calendar6 = null;
//        fixedMillisecond0.peg(calendar6);
//        java.util.Date date8 = fixedMillisecond0.getTime();
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond0.getMiddleMillisecond(calendar9);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440425120L + "'", long2 == 1560440425120L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560440425120L + "'", long5 == 1560440425120L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560440425120L + "'", long10 == 1560440425120L);
//    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test082");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getLastMillisecond(calendar1);
//        boolean boolean4 = fixedMillisecond0.equals((java.lang.Object) 1561964399999L);
//        long long5 = fixedMillisecond0.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        boolean boolean11 = fixedMillisecond7.equals((java.lang.Object) 1561964399999L);
//        long long12 = fixedMillisecond7.getSerialIndex();
//        java.lang.Class<?> wildcardClass13 = fixedMillisecond7.getClass();
//        java.lang.Number number14 = timeSeries6.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
//        java.lang.Class class15 = timeSeries6.getTimePeriodClass();
//        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass20 = month19.getClass();
//        java.lang.Class class21 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass20);
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class21);
//        timeSeries22.setDomainDescription("");
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass29 = month28.getClass();
//        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class30);
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries22.addAndOrUpdate(timeSeries31);
//        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = fixedMillisecond35.next();
//        java.util.Calendar calendar37 = null;
//        long long38 = fixedMillisecond35.getLastMillisecond(calendar37);
//        long long39 = fixedMillisecond35.getSerialIndex();
//        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass42 = month41.getClass();
//        java.lang.Class class43 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass42);
//        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass45 = month44.getClass();
//        java.lang.Class class46 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass45);
//        java.lang.Object obj47 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class43, class46);
//        boolean boolean48 = fixedMillisecond35.equals((java.lang.Object) class46);
//        org.jfree.data.time.TimeSeries timeSeries49 = timeSeries31.createCopy((org.jfree.data.time.RegularTimePeriod) year34, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
//        java.lang.String str50 = timeSeries49.getDomainDescription();
//        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass55 = month54.getClass();
//        java.lang.Class class56 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass55);
//        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class56);
//        timeSeries57.setDomainDescription("");
//        org.jfree.data.time.Month month63 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass64 = month63.getClass();
//        java.lang.Class class65 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass64);
//        org.jfree.data.time.TimeSeries timeSeries66 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class65);
//        org.jfree.data.time.TimeSeries timeSeries67 = timeSeries57.addAndOrUpdate(timeSeries66);
//        java.lang.String str68 = timeSeries67.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries69 = timeSeries49.addAndOrUpdate(timeSeries67);
//        timeSeries49.setRangeDescription("");
//        java.lang.Class<?> wildcardClass72 = timeSeries49.getClass();
//        org.jfree.data.time.TimeSeries timeSeries73 = timeSeries6.addAndOrUpdate(timeSeries49);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440425176L + "'", long2 == 1560440425176L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560440425176L + "'", long5 == 1560440425176L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560440425177L + "'", long9 == 1560440425177L);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560440425177L + "'", long12 == 1560440425177L);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNull(number14);
//        org.junit.Assert.assertNotNull(class15);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertNotNull(class21);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560440425186L + "'", long38 == 1560440425186L);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560440425186L + "'", long39 == 1560440425186L);
//        org.junit.Assert.assertNotNull(wildcardClass42);
//        org.junit.Assert.assertNotNull(class43);
//        org.junit.Assert.assertNotNull(wildcardClass45);
//        org.junit.Assert.assertNotNull(class46);
//        org.junit.Assert.assertNull(obj47);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNotNull(timeSeries49);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "hi!" + "'", str50.equals("hi!"));
//        org.junit.Assert.assertNotNull(wildcardClass55);
//        org.junit.Assert.assertNotNull(class56);
//        org.junit.Assert.assertNotNull(wildcardClass64);
//        org.junit.Assert.assertNotNull(class65);
//        org.junit.Assert.assertNotNull(timeSeries67);
//        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "Time" + "'", str68.equals("Time"));
//        org.junit.Assert.assertNotNull(timeSeries69);
//        org.junit.Assert.assertNotNull(wildcardClass72);
//        org.junit.Assert.assertNotNull(timeSeries73);
//    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test083");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.setDomainDescription("");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass13 = month12.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        java.lang.Object obj18 = null;
//        boolean boolean19 = day17.equals(obj18);
//        int int20 = day17.getMonth();
//        java.lang.Number number21 = null;
//        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) day17, number21, true);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = fixedMillisecond24.next();
//        java.lang.Class<?> wildcardClass26 = fixedMillisecond24.getClass();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (double) 1561964399999L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, 0.0d);
//        long long31 = fixedMillisecond24.getFirstMillisecond();
//        java.util.Calendar calendar32 = null;
//        fixedMillisecond24.peg(calendar32);
//        java.util.Date date34 = fixedMillisecond24.getTime();
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem30);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560440425748L + "'", long31 == 1560440425748L);
//        org.junit.Assert.assertNotNull(date34);
//    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test084");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getLastMillisecond(calendar1);
//        boolean boolean4 = fixedMillisecond0.equals((java.lang.Object) 1561964399999L);
//        long long5 = fixedMillisecond0.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        boolean boolean11 = fixedMillisecond7.equals((java.lang.Object) 1561964399999L);
//        long long12 = fixedMillisecond7.getSerialIndex();
//        java.lang.Class<?> wildcardClass13 = fixedMillisecond7.getClass();
//        java.lang.Number number14 = timeSeries6.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = null;
//        try {
//            timeSeries6.add(timeSeriesDataItem15);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440425888L + "'", long2 == 1560440425888L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560440425888L + "'", long5 == 1560440425888L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560440425889L + "'", long9 == 1560440425889L);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560440425889L + "'", long12 == 1560440425889L);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNull(number14);
//    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test085");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (java.lang.Number) 10.0f);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year1.next();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = day5.equals(obj6);
//        java.lang.String str8 = day5.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day5.previous();
//        long long10 = day5.getLastMillisecond();
//        int int12 = day5.compareTo((java.lang.Object) 100L);
//        java.util.Date date13 = day5.getEnd();
//        long long14 = day5.getMiddleMillisecond();
//        int int15 = year1.compareTo((java.lang.Object) day5);
//        java.lang.String str16 = year1.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year1.next();
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
//        int int20 = month18.compareTo((java.lang.Object) 1L);
//        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass25 = month24.getClass();
//        java.lang.Class class26 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass25);
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class26);
//        java.beans.PropertyChangeListener propertyChangeListener28 = null;
//        timeSeries27.addPropertyChangeListener(propertyChangeListener28);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond30.getLastMillisecond(calendar31);
//        boolean boolean34 = fixedMillisecond30.equals((java.lang.Object) 1561964399999L);
//        long long35 = fixedMillisecond30.getSerialIndex();
//        java.util.Calendar calendar36 = null;
//        fixedMillisecond30.peg(calendar36);
//        java.util.Date date38 = fixedMillisecond30.getTime();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent39 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) fixedMillisecond30);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries27.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, 10.0d);
//        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass46 = month45.getClass();
//        java.lang.Class class47 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass46);
//        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class47);
//        timeSeries48.setDomainDescription("");
//        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass55 = month54.getClass();
//        java.lang.Class class56 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass55);
//        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class56);
//        org.jfree.data.time.TimeSeries timeSeries58 = timeSeries48.addAndOrUpdate(timeSeries57);
//        timeSeries48.fireSeriesChanged();
//        int int60 = timeSeries48.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries27.addAndOrUpdate(timeSeries48);
//        boolean boolean62 = month18.equals((java.lang.Object) timeSeries48);
//        boolean boolean63 = year1.equals((java.lang.Object) timeSeries48);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "13-June-2019" + "'", str8.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560495599999L + "'", long10 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560452399999L + "'", long14 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1900" + "'", str16.equals("1900"));
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertNotNull(class26);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560440425908L + "'", long32 == 1560440425908L);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560440425908L + "'", long35 == 1560440425908L);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNull(timeSeriesDataItem41);
//        org.junit.Assert.assertNotNull(wildcardClass46);
//        org.junit.Assert.assertNotNull(class47);
//        org.junit.Assert.assertNotNull(wildcardClass55);
//        org.junit.Assert.assertNotNull(class56);
//        org.junit.Assert.assertNotNull(timeSeries58);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
//        org.junit.Assert.assertNotNull(timeSeries61);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test086");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass7 = month6.getClass();
//        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
//        java.lang.Object obj9 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class5, class8);
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass11 = month10.getClass();
//        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
//        java.lang.Object obj13 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ThreadContext", class5, (java.lang.Class) wildcardClass11);
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440363591L, class5);
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass19 = month18.getClass();
//        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass19);
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class20);
//        timeSeries21.setDomainDescription("");
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass28 = month27.getClass();
//        java.lang.Class class29 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass28);
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class29);
//        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries21.addAndOrUpdate(timeSeries30);
//        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond34.next();
//        java.util.Calendar calendar36 = null;
//        long long37 = fixedMillisecond34.getLastMillisecond(calendar36);
//        long long38 = fixedMillisecond34.getSerialIndex();
//        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass41 = month40.getClass();
//        java.lang.Class class42 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass41);
//        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass44 = month43.getClass();
//        java.lang.Class class45 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass44);
//        java.lang.Object obj46 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class42, class45);
//        boolean boolean47 = fixedMillisecond34.equals((java.lang.Object) class45);
//        org.jfree.data.time.TimeSeries timeSeries48 = timeSeries30.createCopy((org.jfree.data.time.RegularTimePeriod) year33, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
//        int int49 = year33.getYear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = fixedMillisecond50.next();
//        java.lang.Class<?> wildcardClass52 = fixedMillisecond50.getClass();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond50, (double) 1561964399999L);
//        java.util.Date date55 = fixedMillisecond50.getStart();
//        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = year57.previous();
//        long long59 = year57.getSerialIndex();
//        java.util.Date date60 = year57.getStart();
//        org.jfree.data.time.Month month61 = new org.jfree.data.time.Month(date60);
//        org.jfree.data.time.Month month62 = new org.jfree.data.time.Month(date60);
//        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = year64.previous();
//        long long66 = year64.getSerialIndex();
//        java.util.Date date67 = year64.getStart();
//        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day(date67, timeZone68);
//        org.jfree.data.time.Month month70 = new org.jfree.data.time.Month(date60, timeZone68);
//        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day(date55, timeZone68);
//        int int72 = year33.compareTo((java.lang.Object) timeZone68);
//        int int73 = timeSeries14.getIndex((org.jfree.data.time.RegularTimePeriod) year33);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(class8);
//        org.junit.Assert.assertNull(obj9);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertNull(obj13);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertNotNull(class20);
//        org.junit.Assert.assertNotNull(wildcardClass28);
//        org.junit.Assert.assertNotNull(class29);
//        org.junit.Assert.assertNotNull(timeSeries31);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560440426233L + "'", long37 == 1560440426233L);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560440426233L + "'", long38 == 1560440426233L);
//        org.junit.Assert.assertNotNull(wildcardClass41);
//        org.junit.Assert.assertNotNull(class42);
//        org.junit.Assert.assertNotNull(wildcardClass44);
//        org.junit.Assert.assertNotNull(class45);
//        org.junit.Assert.assertNull(obj46);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertNotNull(timeSeries48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1900 + "'", int49 == 1900);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertNotNull(wildcardClass52);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertNull(regularTimePeriod58);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 1900L + "'", long59 == 1900L);
//        org.junit.Assert.assertNotNull(date60);
//        org.junit.Assert.assertNull(regularTimePeriod65);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 1900L + "'", long66 == 1900L);
//        org.junit.Assert.assertNotNull(date67);
//        org.junit.Assert.assertNotNull(timeZone68);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1 + "'", int72 == 1);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + (-1) + "'", int73 == (-1));
//    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test087");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean3 = spreadsheetDate1.equals((java.lang.Object) 31);
//        int int4 = spreadsheetDate1.getDayOfWeek();
//        int int5 = spreadsheetDate1.toSerial();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate9 = day7.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate11 = serialDate9.getFollowingDayOfWeek(2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean15 = spreadsheetDate13.equals((java.lang.Object) 31);
//        java.util.Date date16 = spreadsheetDate13.toDate();
//        boolean boolean18 = spreadsheetDate13.equals((java.lang.Object) 1560440366809L);
//        int int19 = spreadsheetDate13.getYYYY();
//        org.jfree.data.time.SerialDate serialDate20 = serialDate9.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate13);
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addDays((-1), serialDate9);
//        int int22 = spreadsheetDate1.compare(serialDate9);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 13 + "'", int8 == 13);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1900 + "'", int19 == 1900);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-43619) + "'", int22 == (-43619));
//    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("ClassContext");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test089");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.setDomainDescription("");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass13 = month12.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond19.next();
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond19.getLastMillisecond(calendar21);
//        long long23 = fixedMillisecond19.getSerialIndex();
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass26 = month25.getClass();
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass26);
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass29 = month28.getClass();
//        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
//        java.lang.Object obj31 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class27, class30);
//        boolean boolean32 = fixedMillisecond19.equals((java.lang.Object) class30);
//        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) year18, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar35 = null;
//        long long36 = fixedMillisecond34.getLastMillisecond(calendar35);
//        boolean boolean38 = fixedMillisecond34.equals((java.lang.Object) 1561964399999L);
//        long long39 = fixedMillisecond34.getSerialIndex();
//        int int40 = timeSeries15.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = timeSeries15.getTimePeriod(13);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 13, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560440427184L + "'", long22 == 1560440427184L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560440427184L + "'", long23 == 1560440427184L);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertNull(obj31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(timeSeries33);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560440427187L + "'", long36 == 1560440427187L);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560440427187L + "'", long39 == 1560440427187L);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
//    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("Thu Jun 13 08:39:23 PDT 2019");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test091");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
//        long long3 = year1.getSerialIndex();
//        java.util.Date date4 = year1.getStart();
//        long long5 = year1.getFirstMillisecond();
//        int int6 = year1.getYear();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        java.lang.Object obj8 = null;
//        boolean boolean9 = day7.equals(obj8);
//        java.lang.String str10 = day7.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day7.previous();
//        int int12 = year1.compareTo((java.lang.Object) day7);
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.previous();
//        long long16 = year14.getSerialIndex();
//        java.util.Date date17 = year14.getStart();
//        long long18 = year14.getFirstMillisecond();
//        int int19 = year14.getYear();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.lang.Object obj21 = null;
//        boolean boolean22 = day20.equals(obj21);
//        java.lang.String str23 = day20.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day20.previous();
//        int int25 = year14.compareTo((java.lang.Object) day20);
//        int int26 = year14.getYear();
//        java.lang.String str27 = year14.toString();
//        boolean boolean28 = year1.equals((java.lang.Object) str27);
//        long long29 = year1.getSerialIndex();
//        java.lang.Class class31 = null;
//        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass33 = month32.getClass();
//        java.lang.Class class34 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass33);
//        java.lang.Object obj35 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class31, (java.lang.Class) wildcardClass33);
//        java.lang.Class class36 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass33);
//        boolean boolean37 = year1.equals((java.lang.Object) wildcardClass33);
//        int int38 = year1.getYear();
//        org.junit.Assert.assertNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1900L + "'", long3 == 1900L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-2208960000000L) + "'", long5 == (-2208960000000L));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1900 + "'", int6 == 1900);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "13-June-2019" + "'", str10.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1900L + "'", long16 == 1900L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-2208960000000L) + "'", long18 == (-2208960000000L));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1900 + "'", int19 == 1900);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "13-June-2019" + "'", str23.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1900 + "'", int26 == 1900);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "1900" + "'", str27.equals("1900"));
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1900L + "'", long29 == 1900L);
//        org.junit.Assert.assertNotNull(wildcardClass33);
//        org.junit.Assert.assertNotNull(class34);
//        org.junit.Assert.assertNull(obj35);
//        org.junit.Assert.assertNotNull(class36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1900 + "'", int38 == 1900);
//    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = null;
        try {
            timeSeries6.add(regularTimePeriod17, (double) 1560440395625L, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test093");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = day0.equals(obj1);
//        java.lang.String str3 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        long long5 = day0.getSerialIndex();
//        java.util.Calendar calendar6 = null;
//        try {
//            day0.peg(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43629L + "'", long5 == 43629L);
//    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2958465");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass6 = month5.getClass();
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "", "17-June-2019", class7);
        java.io.InputStream inputStream9 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Thu Jun 13 08:39:46 PDT 2019", class7);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass15 = month14.getClass();
        java.lang.Class class16 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass15);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class16);
        timeSeries17.setDomainDescription("");
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass24 = month23.getClass();
        java.lang.Class class25 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass24);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class25);
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries17.addAndOrUpdate(timeSeries26);
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass32 = month31.getClass();
        java.lang.Class class33 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass32);
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class33);
        java.util.List list35 = timeSeries34.getItems();
        boolean boolean36 = timeSeries27.equals((java.lang.Object) list35);
        java.lang.Class class37 = timeSeries27.getTimePeriodClass();
        java.io.InputStream inputStream38 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Thu Jun 13 08:39:23 PDT 2019", class37);
        java.lang.Object obj39 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Second", class7, class37);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNull(inputStream9);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(class16);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(class25);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(class33);
        org.junit.Assert.assertNotNull(list35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(class37);
        org.junit.Assert.assertNull(inputStream38);
        org.junit.Assert.assertNull(obj39);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        java.lang.String str17 = timeSeries16.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries16.addPropertyChangeListener(propertyChangeListener18);
        java.lang.Object obj20 = timeSeries16.clone();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Time" + "'", str17.equals("Time"));
        org.junit.Assert.assertNotNull(obj20);
    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test097");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.setDomainDescription("");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass13 = month12.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass21 = month20.getClass();
//        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
//        timeSeries23.setDomainDescription("");
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries16.addAndOrUpdate(timeSeries23);
//        java.lang.String str27 = timeSeries26.getDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean30 = fixedMillisecond28.equals((java.lang.Object) 0.0d);
//        java.util.Calendar calendar31 = null;
//        fixedMillisecond28.peg(calendar31);
//        java.lang.String str33 = fixedMillisecond28.toString();
//        long long34 = fixedMillisecond28.getMiddleMillisecond();
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass36 = month35.getClass();
//        boolean boolean38 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month35, (java.lang.Object) 10.0d);
//        long long39 = month35.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries26.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (org.jfree.data.time.RegularTimePeriod) month35);
//        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass45 = month44.getClass();
//        java.lang.Class class46 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass45);
//        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class46);
//        timeSeries47.setDomainDescription("");
//        org.jfree.data.time.Month month53 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass54 = month53.getClass();
//        java.lang.Class class55 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass54);
//        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class55);
//        org.jfree.data.time.TimeSeries timeSeries57 = timeSeries47.addAndOrUpdate(timeSeries56);
//        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = year59.previous();
//        long long61 = year59.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem62 = timeSeries57.getDataItem((org.jfree.data.time.RegularTimePeriod) year59);
//        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = year64.previous();
//        long long66 = year64.getSerialIndex();
//        java.util.Date date67 = year64.getStart();
//        long long68 = year64.getFirstMillisecond();
//        java.lang.Number number69 = timeSeries57.getValue((org.jfree.data.time.RegularTimePeriod) year64);
//        int int71 = year64.compareTo((java.lang.Object) 2147483647);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond72 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean74 = fixedMillisecond72.equals((java.lang.Object) 0.0d);
//        java.util.Calendar calendar75 = null;
//        fixedMillisecond72.peg(calendar75);
//        java.lang.String str77 = fixedMillisecond72.toString();
//        java.util.Date date78 = fixedMillisecond72.getStart();
//        boolean boolean79 = year64.equals((java.lang.Object) fixedMillisecond72);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = year64.next();
//        try {
//            timeSeries26.add(regularTimePeriod80, (double) 1560440409747L, true);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(class22);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertNull(str27);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Thu Jun 13 08:40:27 PDT 2019" + "'", str33.equals("Thu Jun 13 08:40:27 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560440427637L + "'", long34 == 1560440427637L);
//        org.junit.Assert.assertNotNull(wildcardClass36);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1561964399999L + "'", long39 == 1561964399999L);
//        org.junit.Assert.assertNotNull(timeSeries40);
//        org.junit.Assert.assertNotNull(wildcardClass45);
//        org.junit.Assert.assertNotNull(class46);
//        org.junit.Assert.assertNotNull(wildcardClass54);
//        org.junit.Assert.assertNotNull(class55);
//        org.junit.Assert.assertNotNull(timeSeries57);
//        org.junit.Assert.assertNull(regularTimePeriod60);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1900L + "'", long61 == 1900L);
//        org.junit.Assert.assertNull(timeSeriesDataItem62);
//        org.junit.Assert.assertNull(regularTimePeriod65);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 1900L + "'", long66 == 1900L);
//        org.junit.Assert.assertNotNull(date67);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + (-2208960000000L) + "'", long68 == (-2208960000000L));
//        org.junit.Assert.assertNull(number69);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1 + "'", int71 == 1);
//        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
//        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "Thu Jun 13 08:40:27 PDT 2019" + "'", str77.equals("Thu Jun 13 08:40:27 PDT 2019"));
//        org.junit.Assert.assertNotNull(date78);
//        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod80);
//    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("Thu Jun 13 08:39:39 PDT 2019");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Mar");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException3);
        java.lang.Throwable[] throwableArray5 = seriesException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray5);
    }

//    @Test
//    public void test100() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test100");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond7.next();
//        java.lang.Class<?> wildcardClass9 = fixedMillisecond7.getClass();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond7.getMiddleMillisecond(calendar10);
//        timeSeries6.setKey((java.lang.Comparable) long11);
//        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass17 = month16.getClass();
//        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass17);
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class18);
//        timeSeries19.setDomainDescription("");
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass26 = month25.getClass();
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass26);
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class27);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries19.addAndOrUpdate(timeSeries28);
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = fixedMillisecond32.next();
//        java.util.Calendar calendar34 = null;
//        long long35 = fixedMillisecond32.getLastMillisecond(calendar34);
//        long long36 = fixedMillisecond32.getSerialIndex();
//        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass39 = month38.getClass();
//        java.lang.Class class40 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass39);
//        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass42 = month41.getClass();
//        java.lang.Class class43 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass42);
//        java.lang.Object obj44 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class40, class43);
//        boolean boolean45 = fixedMillisecond32.equals((java.lang.Object) class43);
//        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries28.createCopy((org.jfree.data.time.RegularTimePeriod) year31, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond32);
//        java.util.Date date47 = fixedMillisecond32.getTime();
//        try {
//            timeSeries6.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (java.lang.Number) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560440427799L + "'", long11 == 1560440427799L);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(class18);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560440427801L + "'", long35 == 1560440427801L);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560440427801L + "'", long36 == 1560440427801L);
//        org.junit.Assert.assertNotNull(wildcardClass39);
//        org.junit.Assert.assertNotNull(class40);
//        org.junit.Assert.assertNotNull(wildcardClass42);
//        org.junit.Assert.assertNotNull(class43);
//        org.junit.Assert.assertNull(obj44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertNotNull(timeSeries46);
//        org.junit.Assert.assertNotNull(date47);
//    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test101");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.setDomainDescription("");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass13 = month12.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond19.next();
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond19.getLastMillisecond(calendar21);
//        long long23 = fixedMillisecond19.getSerialIndex();
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass26 = month25.getClass();
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass26);
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass29 = month28.getClass();
//        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
//        java.lang.Object obj31 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class27, class30);
//        boolean boolean32 = fixedMillisecond19.equals((java.lang.Object) class30);
//        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) year18, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
//        java.lang.String str34 = timeSeries33.getDomainDescription();
//        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass39 = month38.getClass();
//        java.lang.Class class40 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass39);
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class40);
//        timeSeries41.setDomainDescription("");
//        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass48 = month47.getClass();
//        java.lang.Class class49 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass48);
//        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class49);
//        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries41.addAndOrUpdate(timeSeries50);
//        java.lang.String str52 = timeSeries51.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries33.addAndOrUpdate(timeSeries51);
//        org.jfree.data.time.Month month57 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass58 = month57.getClass();
//        java.lang.Class class59 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass58);
//        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "", "17-June-2019", class59);
//        int int61 = timeSeries60.getMaximumItemCount();
//        java.util.Collection collection62 = timeSeries51.getTimePeriodsUniqueToOtherSeries(timeSeries60);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560440427829L + "'", long22 == 1560440427829L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560440427829L + "'", long23 == 1560440427829L);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertNull(obj31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(timeSeries33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
//        org.junit.Assert.assertNotNull(wildcardClass39);
//        org.junit.Assert.assertNotNull(class40);
//        org.junit.Assert.assertNotNull(wildcardClass48);
//        org.junit.Assert.assertNotNull(class49);
//        org.junit.Assert.assertNotNull(timeSeries51);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "Time" + "'", str52.equals("Time"));
//        org.junit.Assert.assertNotNull(timeSeries53);
//        org.junit.Assert.assertNotNull(wildcardClass58);
//        org.junit.Assert.assertNotNull(class59);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 2147483647 + "'", int61 == 2147483647);
//        org.junit.Assert.assertNotNull(collection62);
//    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass1 = month0.getClass();
        boolean boolean3 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month0, (java.lang.Object) 10.0d);
        long long4 = month0.getLastMillisecond();
        org.jfree.data.time.Year year5 = month0.getYear();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int9 = spreadsheetDate8.toSerial();
        int int10 = spreadsheetDate8.getYYYY();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addDays(7, (org.jfree.data.time.SerialDate) spreadsheetDate8);
        int int12 = month0.compareTo((java.lang.Object) serialDate11);
        org.jfree.data.time.Year year13 = month0.getYear();
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1900 + "'", int10 == 1900);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(year13);
    }

//    @Test
//    public void test103() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test103");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        long long3 = fixedMillisecond0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440428302L + "'", long2 == 1560440428302L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560440428302L + "'", long3 == 1560440428302L);
//    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((-435));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.previous();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(1900);
        long long5 = year4.getLastMillisecond();
        boolean boolean6 = month0.equals((java.lang.Object) year4);
        long long7 = year4.getSerialIndex();
        boolean boolean9 = year4.equals((java.lang.Object) 1.561964399999E12d);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass14 = month13.getClass();
        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass14);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class15);
        java.lang.String str17 = timeSeries16.getDescription();
        java.lang.Object obj18 = timeSeries16.clone();
        int int19 = year4.compareTo((java.lang.Object) timeSeries16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year4.next();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-2177424000001L) + "'", long5 == (-2177424000001L));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1900L + "'", long7 == 1900L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(class15);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test106");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (java.lang.Number) 10.0f);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year1.next();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = day5.equals(obj6);
//        java.lang.String str8 = day5.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day5.previous();
//        long long10 = day5.getLastMillisecond();
//        int int12 = day5.compareTo((java.lang.Object) 100L);
//        java.util.Date date13 = day5.getEnd();
//        long long14 = day5.getMiddleMillisecond();
//        int int15 = year1.compareTo((java.lang.Object) day5);
//        java.lang.String str16 = year1.toString();
//        java.lang.String str17 = year1.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year1.next();
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "13-June-2019" + "'", str8.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560495599999L + "'", long10 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560452399999L + "'", long14 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1900" + "'", str16.equals("1900"));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1900" + "'", str17.equals("1900"));
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test107");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = day0.equals(obj1);
//        java.lang.String str3 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        long long5 = day0.getLastMillisecond();
//        int int7 = day0.compareTo((java.lang.Object) 100L);
//        java.util.Date date8 = day0.getEnd();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day0);
//        int int10 = day0.getDayOfMonth();
//        java.util.Calendar calendar11 = null;
//        try {
//            long long12 = day0.getLastMillisecond(calendar11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560495599999L + "'", long5 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 13 + "'", int10 == 13);
//    }

//    @Test
//    public void test108() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test108");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
//        long long3 = year1.getSerialIndex();
//        java.util.Date date4 = year1.getStart();
//        long long5 = year1.getFirstMillisecond();
//        int int6 = year1.getYear();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        java.lang.Object obj8 = null;
//        boolean boolean9 = day7.equals(obj8);
//        java.lang.String str10 = day7.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day7.previous();
//        int int12 = year1.compareTo((java.lang.Object) day7);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day7.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond14.next();
//        java.lang.Class<?> wildcardClass16 = fixedMillisecond14.getClass();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 1561964399999L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond19.next();
//        java.lang.Class<?> wildcardClass21 = fixedMillisecond19.getClass();
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond19.getMiddleMillisecond(calendar22);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = fixedMillisecond19.previous();
//        boolean boolean25 = timeSeriesDataItem18.equals((java.lang.Object) fixedMillisecond19);
//        java.lang.Number number26 = timeSeriesDataItem18.getValue();
//        boolean boolean28 = timeSeriesDataItem18.equals((java.lang.Object) 1560440375744L);
//        boolean boolean29 = day7.equals((java.lang.Object) 1560440375744L);
//        org.junit.Assert.assertNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1900L + "'", long3 == 1900L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-2208960000000L) + "'", long5 == (-2208960000000L));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1900 + "'", int6 == 1900);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "13-June-2019" + "'", str10.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560440428476L + "'", long23 == 1560440428476L);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 1.561964399999E12d + "'", number26.equals(1.561964399999E12d));
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass1 = month0.getClass();
        boolean boolean3 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month0, (java.lang.Object) 10.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month0.previous();
        long long5 = month0.getFirstMillisecond();
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1559372400000L + "'", long5 == 1559372400000L);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        java.lang.Comparable comparable0 = null;
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        java.io.InputStream inputStream15 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass13);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass17 = month16.getClass();
        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass17);
        java.lang.Object obj19 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Thu Jun 13 08:39:19 PDT 2019", (java.lang.Class) wildcardClass13, class18);
        java.lang.Object obj20 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", (java.lang.Class) wildcardClass13);
        java.io.InputStream inputStream21 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Jan", (java.lang.Class) wildcardClass13);
        java.net.URL uRL22 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("13-June-2019", (java.lang.Class) wildcardClass13);
        java.net.URL uRL23 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("org.jfree.data.general.SeriesChangeEvent[source=-1]", (java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440393131L, "March", "Thu Jun 13 08:39:55 PDT 2019", (java.lang.Class) wildcardClass13);
        try {
            org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries(comparable0, "org.jfree.data.general.SeriesChangeEvent[source=-1]", "Thu Jun 13 08:40:22 PDT 2019", (java.lang.Class) wildcardClass13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(inputStream15);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(class18);
        org.junit.Assert.assertNull(obj19);
        org.junit.Assert.assertNull(obj20);
        org.junit.Assert.assertNull(inputStream21);
        org.junit.Assert.assertNull(uRL22);
        org.junit.Assert.assertNull(uRL23);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test112");
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        int int3 = day2.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate4 = day2.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate6 = serialDate4.getFollowingDayOfWeek(2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean10 = spreadsheetDate8.equals((java.lang.Object) 31);
//        java.util.Date date11 = spreadsheetDate8.toDate();
//        boolean boolean13 = spreadsheetDate8.equals((java.lang.Object) 1560440366809L);
//        int int14 = spreadsheetDate8.getYYYY();
//        org.jfree.data.time.SerialDate serialDate15 = serialDate4.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate8);
//        org.jfree.data.time.SerialDate serialDate17 = serialDate4.getFollowingDayOfWeek(4);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int20 = spreadsheetDate19.toSerial();
//        int int21 = spreadsheetDate19.getDayOfWeek();
//        org.jfree.data.time.SerialDate serialDate22 = serialDate4.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate19);
//        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addDays((int) (short) 1, (org.jfree.data.time.SerialDate) spreadsheetDate19);
//        try {
//            org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((-435), (org.jfree.data.time.SerialDate) spreadsheetDate19);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1900 + "'", int14 == 1900);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 10 + "'", int20 == 10);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 3 + "'", int21 == 3);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertNotNull(serialDate23);
//    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test113");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.setDomainDescription("");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass13 = month12.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d);
//        java.util.Collection collection19 = timeSeries6.getTimePeriodsUniqueToOtherSeries(timeSeries18);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        int int21 = day20.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate22 = day20.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate24 = serialDate22.getFollowingDayOfWeek(2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean28 = spreadsheetDate26.equals((java.lang.Object) 31);
//        java.util.Date date29 = spreadsheetDate26.toDate();
//        boolean boolean31 = spreadsheetDate26.equals((java.lang.Object) 1560440366809L);
//        int int32 = spreadsheetDate26.getYYYY();
//        org.jfree.data.time.SerialDate serialDate33 = serialDate22.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate26);
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(serialDate33);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = day34.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day34, (java.lang.Number) 1560440383163L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertNotNull(collection19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 13 + "'", int21 == 13);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1900 + "'", int32 == 1900);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertNull(timeSeriesDataItem37);
//    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("org.jfree.data.general.SeriesChangeEvent[source=13-June-2019]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test115() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test115");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int2 = month0.compareTo((java.lang.Object) 1L);
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass7 = month6.getClass();
//        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class8);
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timeSeries9.addPropertyChangeListener(propertyChangeListener10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar13 = null;
//        long long14 = fixedMillisecond12.getLastMillisecond(calendar13);
//        boolean boolean16 = fixedMillisecond12.equals((java.lang.Object) 1561964399999L);
//        long long17 = fixedMillisecond12.getSerialIndex();
//        java.util.Calendar calendar18 = null;
//        fixedMillisecond12.peg(calendar18);
//        java.util.Date date20 = fixedMillisecond12.getTime();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent21 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) fixedMillisecond12);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, 10.0d);
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass28 = month27.getClass();
//        java.lang.Class class29 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass28);
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class29);
//        timeSeries30.setDomainDescription("");
//        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass37 = month36.getClass();
//        java.lang.Class class38 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass37);
//        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class38);
//        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries30.addAndOrUpdate(timeSeries39);
//        timeSeries30.fireSeriesChanged();
//        int int42 = timeSeries30.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries43 = timeSeries9.addAndOrUpdate(timeSeries30);
//        boolean boolean44 = month0.equals((java.lang.Object) timeSeries30);
//        java.lang.String str45 = month0.toString();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(class8);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560440429134L + "'", long14 == 1560440429134L);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560440429134L + "'", long17 == 1560440429134L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNull(timeSeriesDataItem23);
//        org.junit.Assert.assertNotNull(wildcardClass28);
//        org.junit.Assert.assertNotNull(class29);
//        org.junit.Assert.assertNotNull(wildcardClass37);
//        org.junit.Assert.assertNotNull(class38);
//        org.junit.Assert.assertNotNull(timeSeries40);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertNotNull(timeSeries43);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "June 2019" + "'", str45.equals("June 2019"));
//    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test116");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.setDomainDescription("");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass13 = month12.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
//        java.lang.String str17 = timeSeries16.getDomainDescription();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
//        timeSeries16.addChangeListener(seriesChangeListener18);
//        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass24 = month23.getClass();
//        java.lang.Class class25 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass24);
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class25);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = fixedMillisecond27.next();
//        java.lang.Class<?> wildcardClass29 = fixedMillisecond27.getClass();
//        java.util.Calendar calendar30 = null;
//        long long31 = fixedMillisecond27.getMiddleMillisecond(calendar30);
//        timeSeries26.setKey((java.lang.Comparable) long31);
//        boolean boolean33 = timeSeries16.equals((java.lang.Object) timeSeries26);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Time" + "'", str17.equals("Time"));
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertNotNull(class25);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560440429274L + "'", long31 == 1560440429274L);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test117");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.setDomainDescription("");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass13 = month12.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond19.next();
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond19.getLastMillisecond(calendar21);
//        long long23 = fixedMillisecond19.getSerialIndex();
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass26 = month25.getClass();
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass26);
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass29 = month28.getClass();
//        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
//        java.lang.Object obj31 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class27, class30);
//        boolean boolean32 = fixedMillisecond19.equals((java.lang.Object) class30);
//        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) year18, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = fixedMillisecond19.previous();
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560440429397L + "'", long22 == 1560440429397L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560440429397L + "'", long23 == 1560440429397L);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertNull(obj31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(timeSeries33);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass21 = month20.getClass();
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
        timeSeries23.setDomainDescription("");
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries16.addAndOrUpdate(timeSeries23);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener27 = null;
        timeSeries16.removeChangeListener(seriesChangeListener27);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timeSeries16.addPropertyChangeListener(propertyChangeListener29);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertNotNull(timeSeries26);
    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test119");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getLastMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440429616L + "'", long2 == 1560440429616L);
//        org.junit.Assert.assertNotNull(date3);
//    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test120");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate4 = serialDate2.getFollowingDayOfWeek(2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean8 = spreadsheetDate6.equals((java.lang.Object) 31);
//        java.util.Date date9 = spreadsheetDate6.toDate();
//        boolean boolean11 = spreadsheetDate6.equals((java.lang.Object) 1560440366809L);
//        int int12 = spreadsheetDate6.getYYYY();
//        org.jfree.data.time.SerialDate serialDate13 = serialDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate6);
//        org.jfree.data.time.SerialDate serialDate15 = serialDate2.getFollowingDayOfWeek(4);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int18 = spreadsheetDate17.toSerial();
//        int int19 = spreadsheetDate17.getDayOfWeek();
//        org.jfree.data.time.SerialDate serialDate20 = serialDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate17);
//        java.util.Date date21 = spreadsheetDate17.toDate();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1900 + "'", int12 == 1900);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 3 + "'", int19 == 3);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(date21);
//    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test121");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(5, (org.jfree.data.time.SerialDate) spreadsheetDate2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int6 = spreadsheetDate5.toSerial();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate9 = day7.getSerialDate();
//        boolean boolean10 = spreadsheetDate5.isOnOrAfter(serialDate9);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        int int13 = day12.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate14 = day12.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate16 = serialDate14.getFollowingDayOfWeek(2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean20 = spreadsheetDate18.equals((java.lang.Object) 31);
//        java.util.Date date21 = spreadsheetDate18.toDate();
//        boolean boolean23 = spreadsheetDate18.equals((java.lang.Object) 1560440366809L);
//        int int24 = spreadsheetDate18.getYYYY();
//        org.jfree.data.time.SerialDate serialDate25 = serialDate14.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate18);
//        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addYears((-1), serialDate14);
//        int int27 = spreadsheetDate5.compare(serialDate14);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        int int30 = day29.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate31 = day29.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate33 = serialDate31.getFollowingDayOfWeek(2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean37 = spreadsheetDate35.equals((java.lang.Object) 31);
//        java.util.Date date38 = spreadsheetDate35.toDate();
//        boolean boolean40 = spreadsheetDate35.equals((java.lang.Object) 1560440366809L);
//        int int41 = spreadsheetDate35.getYYYY();
//        org.jfree.data.time.SerialDate serialDate42 = serialDate31.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate35);
//        org.jfree.data.time.SerialDate serialDate44 = serialDate31.getFollowingDayOfWeek(4);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int47 = spreadsheetDate46.toSerial();
//        int int48 = spreadsheetDate46.getDayOfWeek();
//        org.jfree.data.time.SerialDate serialDate49 = serialDate31.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate46);
//        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.addDays((int) (short) 1, (org.jfree.data.time.SerialDate) spreadsheetDate46);
//        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day();
//        int int52 = day51.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate53 = day51.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate55 = serialDate53.getFollowingDayOfWeek(2);
//        java.lang.String str56 = serialDate55.toString();
//        org.jfree.data.time.SerialDate serialDate58 = serialDate55.getNearestDayOfWeek((int) (byte) 1);
//        org.jfree.data.time.SerialDate serialDate60 = serialDate55.getNearestDayOfWeek((int) (short) 1);
//        org.jfree.data.time.SerialDate serialDate61 = spreadsheetDate46.getEndOfCurrentMonth(serialDate55);
//        boolean boolean62 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate5, (org.jfree.data.time.SerialDate) spreadsheetDate46);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 13 + "'", int8 == 13);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 13 + "'", int13 == 13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1900 + "'", int24 == 1900);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-43619) + "'", int27 == (-43619));
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 13 + "'", int30 == 13);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1900 + "'", int41 == 1900);
//        org.junit.Assert.assertNotNull(serialDate42);
//        org.junit.Assert.assertNotNull(serialDate44);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 10 + "'", int47 == 10);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 3 + "'", int48 == 3);
//        org.junit.Assert.assertNotNull(serialDate49);
//        org.junit.Assert.assertNotNull(serialDate50);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 13 + "'", int52 == 13);
//        org.junit.Assert.assertNotNull(serialDate53);
//        org.junit.Assert.assertNotNull(serialDate55);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "17-June-2019" + "'", str56.equals("17-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate58);
//        org.junit.Assert.assertNotNull(serialDate60);
//        org.junit.Assert.assertNotNull(serialDate61);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
//    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test122");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = day0.equals(obj1);
//        java.lang.String str3 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        long long5 = day0.getLastMillisecond();
//        long long6 = day0.getLastMillisecond();
//        java.lang.String str7 = day0.toString();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560495599999L + "'", long5 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560495599999L + "'", long6 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "13-June-2019" + "'", str7.equals("13-June-2019"));
//    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test123");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = day0.equals(obj1);
//        java.lang.String str3 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        java.lang.String str5 = day0.toString();
//        long long6 = day0.getSerialIndex();
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = day0.getFirstMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43629L + "'", long6 == 43629L);
//    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test124");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean7 = spreadsheetDate5.equals((java.lang.Object) 31);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int9 = day8.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate10 = day8.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate12 = serialDate10.getFollowingDayOfWeek(2);
//        java.lang.String str13 = serialDate12.toString();
//        boolean boolean14 = spreadsheetDate5.isOnOrAfter(serialDate12);
//        boolean boolean15 = spreadsheetDate3.isOn((org.jfree.data.time.SerialDate) spreadsheetDate5);
//        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addDays(9999, (org.jfree.data.time.SerialDate) spreadsheetDate3);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean20 = spreadsheetDate18.equals((java.lang.Object) 31);
//        java.util.Date date21 = spreadsheetDate18.toDate();
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        int int23 = day22.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate24 = day22.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate26 = serialDate24.getFollowingDayOfWeek(2);
//        java.lang.String str27 = serialDate26.toString();
//        int int28 = spreadsheetDate18.compare(serialDate26);
//        org.jfree.data.time.SerialDate serialDate29 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate18);
//        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addMonths((int) (short) 100, serialDate29);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 13 + "'", int9 == 13);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "17-June-2019" + "'", str13.equals("17-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 13 + "'", int23 == 13);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "17-June-2019" + "'", str27.equals("17-June-2019"));
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-43623) + "'", int28 == (-43623));
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertNotNull(serialDate30);
//    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test125");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean5 = spreadsheetDate3.equals((java.lang.Object) 31);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int7 = day6.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day6.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate10 = serialDate8.getFollowingDayOfWeek(2);
//        java.lang.String str11 = serialDate10.toString();
//        boolean boolean12 = spreadsheetDate3.isOnOrAfter(serialDate10);
//        boolean boolean13 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean20 = spreadsheetDate18.equals((java.lang.Object) 31);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        int int22 = day21.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate23 = day21.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate25 = serialDate23.getFollowingDayOfWeek(2);
//        java.lang.String str26 = serialDate25.toString();
//        boolean boolean27 = spreadsheetDate18.isOnOrAfter(serialDate25);
//        boolean boolean28 = spreadsheetDate16.isOn((org.jfree.data.time.SerialDate) spreadsheetDate18);
//        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.addDays(9999, (org.jfree.data.time.SerialDate) spreadsheetDate16);
//        boolean boolean30 = spreadsheetDate3.isBefore(serialDate29);
//        try {
//            org.jfree.data.time.SerialDate serialDate32 = spreadsheetDate3.getPreviousDayOfWeek(2147483647);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 13 + "'", int7 == 13);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "17-June-2019" + "'", str11.equals("17-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 13 + "'", int22 == 13);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "17-June-2019" + "'", str26.equals("17-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d);
        java.util.Collection collection19 = timeSeries6.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        java.lang.Class class20 = timeSeries18.getTimePeriodClass();
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass25 = month24.getClass();
        java.lang.Class class26 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass25);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class26);
        timeSeries27.setDomainDescription("");
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass34 = month33.getClass();
        java.lang.Class class35 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass34);
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class35);
        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries27.addAndOrUpdate(timeSeries36);
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(1900);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = year39.previous();
        long long41 = year39.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries37.getDataItem((org.jfree.data.time.RegularTimePeriod) year39);
        java.util.Collection collection43 = timeSeries18.getTimePeriodsUniqueToOtherSeries(timeSeries37);
        timeSeries18.removeAgedItems(true);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(class20);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(class26);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(class35);
        org.junit.Assert.assertNotNull(timeSeries37);
        org.junit.Assert.assertNull(regularTimePeriod40);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1900L + "'", long41 == 1900L);
        org.junit.Assert.assertNull(timeSeriesDataItem42);
        org.junit.Assert.assertNotNull(collection43);
    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test127");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int2 = month0.compareTo((java.lang.Object) 1L);
//        long long3 = month0.getLastMillisecond();
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass9 = month8.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class10);
//        timeSeries11.setDomainDescription("");
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass18 = month17.getClass();
//        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass18);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class19);
//        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries11.addAndOrUpdate(timeSeries20);
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass26 = month25.getClass();
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass26);
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class27);
//        timeSeries28.setDomainDescription("");
//        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries21.addAndOrUpdate(timeSeries28);
//        java.lang.String str32 = timeSeries31.getDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean35 = fixedMillisecond33.equals((java.lang.Object) 0.0d);
//        java.util.Calendar calendar36 = null;
//        fixedMillisecond33.peg(calendar36);
//        java.lang.String str38 = fixedMillisecond33.toString();
//        long long39 = fixedMillisecond33.getMiddleMillisecond();
//        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass41 = month40.getClass();
//        boolean boolean43 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month40, (java.lang.Object) 10.0d);
//        long long44 = month40.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries31.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33, (org.jfree.data.time.RegularTimePeriod) month40);
//        int int46 = month0.compareTo((java.lang.Object) fixedMillisecond33);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1561964399999L + "'", long3 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertNotNull(class19);
//        org.junit.Assert.assertNotNull(timeSeries21);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertNotNull(timeSeries31);
//        org.junit.Assert.assertNull(str32);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Thu Jun 13 08:40:30 PDT 2019" + "'", str38.equals("Thu Jun 13 08:40:30 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560440430804L + "'", long39 == 1560440430804L);
//        org.junit.Assert.assertNotNull(wildcardClass41);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1561964399999L + "'", long44 == 1561964399999L);
//        org.junit.Assert.assertNotNull(timeSeries45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
//    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test128");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.setDomainDescription("");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass13 = month12.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
//        java.lang.String str17 = timeSeries15.getRangeDescription();
//        int int18 = timeSeries15.getMaximumItemCount();
//        long long19 = timeSeries15.getMaximumItemAge();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond20.getLastMillisecond(calendar21);
//        boolean boolean24 = fixedMillisecond20.equals((java.lang.Object) 1561964399999L);
//        long long25 = fixedMillisecond20.getSerialIndex();
//        java.util.Date date26 = fixedMillisecond20.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = fixedMillisecond27.next();
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
//        java.beans.PropertyChangeListener propertyChangeListener30 = null;
//        timeSeries15.removePropertyChangeListener(propertyChangeListener30);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ThreadContext" + "'", str17.equals("ThreadContext"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2147483647 + "'", int18 == 2147483647);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 9223372036854775807L + "'", long19 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560440430940L + "'", long22 == 1560440430940L);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560440430940L + "'", long25 == 1560440430940L);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(timeSeries29);
//    }

//    @Test
//    public void test129() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test129");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.setDomainDescription("");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass13 = month12.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass21 = month20.getClass();
//        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
//        java.util.List list24 = timeSeries23.getItems();
//        boolean boolean25 = timeSeries16.equals((java.lang.Object) list24);
//        timeSeries16.removeAgedItems(false);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        int int29 = day28.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day28.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries16.getDataItem(regularTimePeriod30);
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = timeSeries16.getTimePeriod(2147483647);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2147483647, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(class22);
//        org.junit.Assert.assertNotNull(list24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 13 + "'", int29 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNull(timeSeriesDataItem31);
//    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test130");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.setDomainDescription("");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass13 = month12.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond19.next();
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond19.getLastMillisecond(calendar21);
//        long long23 = fixedMillisecond19.getSerialIndex();
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass26 = month25.getClass();
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass26);
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass29 = month28.getClass();
//        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
//        java.lang.Object obj31 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class27, class30);
//        boolean boolean32 = fixedMillisecond19.equals((java.lang.Object) class30);
//        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) year18, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
//        java.lang.String str34 = timeSeries33.getDomainDescription();
//        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass39 = month38.getClass();
//        java.lang.Class class40 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass39);
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class40);
//        timeSeries41.setDomainDescription("");
//        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass48 = month47.getClass();
//        java.lang.Class class49 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass48);
//        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class49);
//        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries41.addAndOrUpdate(timeSeries50);
//        java.lang.String str52 = timeSeries51.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries33.addAndOrUpdate(timeSeries51);
//        boolean boolean54 = timeSeries33.isEmpty();
//        timeSeries33.fireSeriesChanged();
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560440431042L + "'", long22 == 1560440431042L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560440431042L + "'", long23 == 1560440431042L);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertNull(obj31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(timeSeries33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
//        org.junit.Assert.assertNotNull(wildcardClass39);
//        org.junit.Assert.assertNotNull(class40);
//        org.junit.Assert.assertNotNull(wildcardClass48);
//        org.junit.Assert.assertNotNull(class49);
//        org.junit.Assert.assertNotNull(timeSeries51);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "Time" + "'", str52.equals("Time"));
//        org.junit.Assert.assertNotNull(timeSeries53);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
//    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass1 = month0.getClass();
        boolean boolean3 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month0, (java.lang.Object) 10.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month0.previous();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass10 = month9.getClass();
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        java.lang.Object obj15 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class11, class14);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass17 = month16.getClass();
        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass17);
        java.lang.Object obj19 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ThreadContext", class11, (java.lang.Class) wildcardClass17);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440363591L, class11);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass22 = month21.getClass();
        java.lang.Class class23 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass22);
        java.lang.Object obj24 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Following", class11, class23);
        java.lang.Class class25 = org.jfree.data.time.RegularTimePeriod.downsize(class11);
        boolean boolean26 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month0, (java.lang.Object) class11);
        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize(class11);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNull(obj15);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(class18);
        org.junit.Assert.assertNull(obj19);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(class23);
        org.junit.Assert.assertNull(obj24);
        org.junit.Assert.assertNotNull(class25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(class27);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Following");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test133");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = day0.equals(obj1);
//        java.lang.String str3 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        java.lang.String str5 = day0.toString();
//        long long6 = day0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560495599999L + "'", long6 == 1560495599999L);
//    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        java.lang.Object obj18 = null;
        boolean boolean19 = day17.equals(obj18);
        int int20 = day17.getMonth();
        java.lang.Number number21 = null;
        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) day17, number21, true);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = fixedMillisecond24.next();
        java.lang.Class<?> wildcardClass26 = fixedMillisecond24.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (double) 1561964399999L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, 0.0d);
        java.lang.Object obj31 = null;
        boolean boolean32 = timeSeriesDataItem30.equals(obj31);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(timeSeriesDataItem30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((-457));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test136() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test136");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.setDomainDescription("");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass13 = month12.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year18.previous();
//        long long20 = year18.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries16.getDataItem((org.jfree.data.time.RegularTimePeriod) year18);
//        java.lang.Object obj22 = timeSeries16.clone();
//        timeSeries16.fireSeriesChanged();
//        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
//        int int26 = month24.compareTo((java.lang.Object) 1L);
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
//        int int29 = month27.compareTo((java.lang.Object) 1L);
//        long long30 = month27.getLastMillisecond();
//        int int31 = month24.compareTo((java.lang.Object) long30);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar33 = null;
//        long long34 = fixedMillisecond32.getLastMillisecond(calendar33);
//        boolean boolean36 = fixedMillisecond32.equals((java.lang.Object) 1561964399999L);
//        long long37 = fixedMillisecond32.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (double) 13);
//        boolean boolean41 = timeSeriesDataItem39.equals((java.lang.Object) "org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d));
//        boolean boolean44 = timeSeriesDataItem39.equals((java.lang.Object) (-1.0d));
//        int int45 = month24.compareTo((java.lang.Object) timeSeriesDataItem39);
//        timeSeries16.delete((org.jfree.data.time.RegularTimePeriod) month24);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1900L + "'", long20 == 1900L);
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertNotNull(obj22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1561964399999L + "'", long30 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560440431477L + "'", long34 == 1560440431477L);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560440431477L + "'", long37 == 1560440431477L);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        long long3 = year1.getSerialIndex();
        java.util.Date date4 = year1.getStart();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date4);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(1900);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        long long10 = year8.getSerialIndex();
        java.util.Date date11 = year8.getStart();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date11, timeZone12);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date4, timeZone12);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.junit.Assert.assertNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1900L + "'", long3 == 1900L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1900L + "'", long10 == 1900L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(serialDate15);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.clear();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass12 = month11.getClass();
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class13);
        timeSeries14.setDomainDescription("");
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass21 = month20.getClass();
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries14.addAndOrUpdate(timeSeries23);
        java.lang.String str25 = timeSeries23.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries6.addAndOrUpdate(timeSeries23);
        timeSeries23.setDescription("Following");
        java.lang.String str29 = timeSeries23.getRangeDescription();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "ThreadContext" + "'", str25.equals("ThreadContext"));
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "ThreadContext" + "'", str29.equals("ThreadContext"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((-435), (-435), 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'month' argument must be in the range 1 to 12.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test140");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = day0.equals(obj1);
//        long long3 = day0.getLastMillisecond();
//        int int4 = day0.getYear();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560440383163L);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        java.util.List list17 = timeSeries6.getItems();
        try {
            java.util.Collection collection18 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list17);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(list17);
    }

//    @Test
//    public void test143() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test143");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getLastMillisecond(calendar3);
//        boolean boolean6 = fixedMillisecond2.equals((java.lang.Object) 1561964399999L);
//        long long7 = fixedMillisecond2.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (double) 13);
//        java.lang.Object obj10 = timeSeriesDataItem9.clone();
//        int int11 = year1.compareTo((java.lang.Object) timeSeriesDataItem9);
//        java.lang.Object obj12 = timeSeriesDataItem9.clone();
//        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass17 = month16.getClass();
//        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass17);
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class18);
//        timeSeries19.setDomainDescription("");
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass26 = month25.getClass();
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass26);
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class27);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries19.addAndOrUpdate(timeSeries28);
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d);
//        java.util.Collection collection32 = timeSeries19.getTimePeriodsUniqueToOtherSeries(timeSeries31);
//        long long33 = timeSeries31.getMaximumItemAge();
//        int int34 = timeSeriesDataItem9.compareTo((java.lang.Object) long33);
//        java.lang.Object obj35 = null;
//        boolean boolean36 = timeSeriesDataItem9.equals(obj35);
//        java.lang.Object obj37 = null;
//        boolean boolean38 = timeSeriesDataItem9.equals(obj37);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560440431844L + "'", long4 == 1560440431844L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560440431844L + "'", long7 == 1560440431844L);
//        org.junit.Assert.assertNotNull(obj10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(obj12);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(class18);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertNotNull(collection32);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 9223372036854775807L + "'", long33 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(1900);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year18.previous();
        long long20 = year18.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries16.getDataItem((org.jfree.data.time.RegularTimePeriod) year18);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(1900);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year23.previous();
        long long25 = year23.getSerialIndex();
        java.util.Date date26 = year23.getStart();
        long long27 = year23.getFirstMillisecond();
        java.lang.Number number28 = timeSeries16.getValue((org.jfree.data.time.RegularTimePeriod) year23);
        int int30 = year23.compareTo((java.lang.Object) 2147483647);
        long long31 = year23.getFirstMillisecond();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1900L + "'", long20 == 1900L);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1900L + "'", long25 == 1900L);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-2208960000000L) + "'", long27 == (-2208960000000L));
        org.junit.Assert.assertNull(number28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-2208960000000L) + "'", long31 == (-2208960000000L));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        java.util.List list17 = timeSeries6.getItems();
        java.lang.Object obj18 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) timeSeries6);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNotNull(obj18);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("org.jfree.data.time.TimePeriodFormatException: ");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test147");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getLastMillisecond(calendar1);
//        boolean boolean4 = fixedMillisecond0.equals((java.lang.Object) 1561964399999L);
//        long long5 = fixedMillisecond0.getSerialIndex();
//        java.util.Date date6 = fixedMillisecond0.getEnd();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass12 = month11.getClass();
//        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class13);
//        timeSeries14.setDomainDescription("");
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass21 = month20.getClass();
//        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries14.addAndOrUpdate(timeSeries23);
//        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = fixedMillisecond27.next();
//        java.util.Calendar calendar29 = null;
//        long long30 = fixedMillisecond27.getLastMillisecond(calendar29);
//        long long31 = fixedMillisecond27.getSerialIndex();
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass34 = month33.getClass();
//        java.lang.Class class35 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass34);
//        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass37 = month36.getClass();
//        java.lang.Class class38 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass37);
//        java.lang.Object obj39 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class35, class38);
//        boolean boolean40 = fixedMillisecond27.equals((java.lang.Object) class38);
//        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries23.createCopy((org.jfree.data.time.RegularTimePeriod) year26, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
//        java.lang.String str42 = timeSeries41.getDomainDescription();
//        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass47 = month46.getClass();
//        java.lang.Class class48 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass47);
//        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class48);
//        timeSeries49.setDomainDescription("");
//        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass56 = month55.getClass();
//        java.lang.Class class57 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass56);
//        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class57);
//        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries49.addAndOrUpdate(timeSeries58);
//        java.lang.String str60 = timeSeries59.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries41.addAndOrUpdate(timeSeries59);
//        boolean boolean63 = timeSeries61.equals((java.lang.Object) 1560440368245L);
//        java.lang.Class class64 = timeSeries61.getTimePeriodClass();
//        java.lang.Object obj65 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("October", class64);
//        java.lang.Class class66 = org.jfree.data.time.RegularTimePeriod.downsize(class64);
//        org.jfree.data.time.TimeSeries timeSeries67 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date6, class66);
//        org.jfree.data.time.Year year69 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = year69.previous();
//        long long71 = year69.getSerialIndex();
//        java.util.Date date72 = year69.getStart();
//        org.jfree.data.time.Month month73 = new org.jfree.data.time.Month(date72);
//        org.jfree.data.time.Month month74 = new org.jfree.data.time.Month(date72);
//        org.jfree.data.time.Month month80 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass81 = month80.getClass();
//        java.lang.Class class82 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass81);
//        java.io.InputStream inputStream83 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass81);
//        org.jfree.data.time.Month month84 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass85 = month84.getClass();
//        java.lang.Class class86 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass85);
//        java.lang.Object obj87 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Thu Jun 13 08:39:19 PDT 2019", (java.lang.Class) wildcardClass81, class86);
//        java.lang.Object obj88 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", (java.lang.Class) wildcardClass81);
//        java.io.InputStream inputStream89 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Jan", (java.lang.Class) wildcardClass81);
//        java.net.URL uRL90 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("Thu Jun 13 08:39:42 PDT 2019", (java.lang.Class) wildcardClass81);
//        java.util.Date date91 = null;
//        java.util.TimeZone timeZone92 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod93 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass81, date91, timeZone92);
//        org.jfree.data.time.Month month94 = new org.jfree.data.time.Month(date72, timeZone92);
//        org.jfree.data.time.Day day95 = new org.jfree.data.time.Day(date6, timeZone92);
//        java.lang.String str96 = day95.toString();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440432103L + "'", long2 == 1560440432103L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560440432103L + "'", long5 == 1560440432103L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNotNull(class13);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(class22);
//        org.junit.Assert.assertNotNull(timeSeries24);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560440432113L + "'", long30 == 1560440432113L);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560440432113L + "'", long31 == 1560440432113L);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNotNull(class35);
//        org.junit.Assert.assertNotNull(wildcardClass37);
//        org.junit.Assert.assertNotNull(class38);
//        org.junit.Assert.assertNull(obj39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(timeSeries41);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "hi!" + "'", str42.equals("hi!"));
//        org.junit.Assert.assertNotNull(wildcardClass47);
//        org.junit.Assert.assertNotNull(class48);
//        org.junit.Assert.assertNotNull(wildcardClass56);
//        org.junit.Assert.assertNotNull(class57);
//        org.junit.Assert.assertNotNull(timeSeries59);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "Time" + "'", str60.equals("Time"));
//        org.junit.Assert.assertNotNull(timeSeries61);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertNotNull(class64);
//        org.junit.Assert.assertNull(obj65);
//        org.junit.Assert.assertNotNull(class66);
//        org.junit.Assert.assertNull(regularTimePeriod70);
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 1900L + "'", long71 == 1900L);
//        org.junit.Assert.assertNotNull(date72);
//        org.junit.Assert.assertNotNull(wildcardClass81);
//        org.junit.Assert.assertNotNull(class82);
//        org.junit.Assert.assertNotNull(inputStream83);
//        org.junit.Assert.assertNotNull(wildcardClass85);
//        org.junit.Assert.assertNotNull(class86);
//        org.junit.Assert.assertNull(obj87);
//        org.junit.Assert.assertNull(obj88);
//        org.junit.Assert.assertNull(inputStream89);
//        org.junit.Assert.assertNull(uRL90);
//        org.junit.Assert.assertNotNull(timeZone92);
//        org.junit.Assert.assertNull(regularTimePeriod93);
//        org.junit.Assert.assertTrue("'" + str96 + "' != '" + "13-June-2019" + "'", str96.equals("13-June-2019"));
//    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test148");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
//        long long3 = year1.getSerialIndex();
//        java.util.Date date4 = year1.getStart();
//        long long5 = year1.getFirstMillisecond();
//        int int6 = year1.getYear();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        java.lang.Object obj8 = null;
//        boolean boolean9 = day7.equals(obj8);
//        java.lang.String str10 = day7.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day7.previous();
//        int int12 = year1.compareTo((java.lang.Object) day7);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        int int14 = day13.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate15 = day13.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate17 = serialDate15.getFollowingDayOfWeek(2);
//        java.lang.String str18 = serialDate17.toString();
//        org.jfree.data.time.SerialDate serialDate20 = serialDate17.getNearestDayOfWeek((int) (byte) 1);
//        boolean boolean21 = year1.equals((java.lang.Object) serialDate20);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean26 = spreadsheetDate24.equals((java.lang.Object) 31);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        int int28 = day27.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate29 = day27.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate31 = serialDate29.getFollowingDayOfWeek(2);
//        java.lang.String str32 = serialDate31.toString();
//        boolean boolean33 = spreadsheetDate24.isOnOrBefore(serialDate31);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean37 = spreadsheetDate35.equals((java.lang.Object) 31);
//        int int38 = spreadsheetDate35.getDayOfWeek();
//        int int39 = spreadsheetDate35.getMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate41);
//        boolean boolean43 = spreadsheetDate24.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate35, (org.jfree.data.time.SerialDate) spreadsheetDate41);
//        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, (org.jfree.data.time.SerialDate) spreadsheetDate24);
//        org.jfree.data.time.SerialDate serialDate45 = serialDate20.getEndOfCurrentMonth(serialDate44);
//        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate20);
//        org.junit.Assert.assertNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1900L + "'", long3 == 1900L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-2208960000000L) + "'", long5 == (-2208960000000L));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1900 + "'", int6 == 1900);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "13-June-2019" + "'", str10.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 13 + "'", int14 == 13);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "17-June-2019" + "'", str18.equals("17-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 13 + "'", int28 == 13);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "17-June-2019" + "'", str32.equals("17-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 3 + "'", int38 == 3);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
//        org.junit.Assert.assertNotNull(serialDate44);
//        org.junit.Assert.assertNotNull(serialDate45);
//    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass10 = month9.getClass();
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        java.io.InputStream inputStream12 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass10);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass14 = month13.getClass();
        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass14);
        java.lang.Object obj16 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Thu Jun 13 08:39:19 PDT 2019", (java.lang.Class) wildcardClass10, class15);
        java.lang.Object obj17 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", (java.lang.Class) wildcardClass10);
        java.io.InputStream inputStream18 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Jan", (java.lang.Class) wildcardClass10);
        java.net.URL uRL19 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("13-June-2019", (java.lang.Class) wildcardClass10);
        java.net.URL uRL20 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("org.jfree.data.general.SeriesChangeEvent[source=-1]", (java.lang.Class) wildcardClass10);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440393131L, "March", "Thu Jun 13 08:39:55 PDT 2019", (java.lang.Class) wildcardClass10);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
        timeSeries21.removeChangeListener(seriesChangeListener22);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNotNull(inputStream12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(class15);
        org.junit.Assert.assertNull(obj16);
        org.junit.Assert.assertNull(obj17);
        org.junit.Assert.assertNull(inputStream18);
        org.junit.Assert.assertNull(uRL19);
        org.junit.Assert.assertNull(uRL20);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d);
        timeSeries1.setMaximumItemCount((int) (short) 100);
        boolean boolean4 = timeSeries1.getNotify();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass21 = month20.getClass();
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
        java.util.List list24 = timeSeries23.getItems();
        boolean boolean25 = timeSeries16.equals((java.lang.Object) list24);
        timeSeries16.removeAgedItems(false);
        java.lang.Comparable comparable28 = timeSeries16.getKey();
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timeSeries16.removePropertyChangeListener(propertyChangeListener29);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertNotNull(list24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + comparable28 + "' != '" + "Overwritten values from: 1560440358934" + "'", comparable28.equals("Overwritten values from: 1560440358934"));
    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test152");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean3 = spreadsheetDate1.equals((java.lang.Object) 31);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int6 = spreadsheetDate5.toSerial();
//        org.jfree.data.time.SerialDate serialDate7 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate5);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int9 = day8.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate10 = day8.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate12 = serialDate10.getFollowingDayOfWeek(2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean16 = spreadsheetDate14.equals((java.lang.Object) 31);
//        java.util.Date date17 = spreadsheetDate14.toDate();
//        boolean boolean19 = spreadsheetDate14.equals((java.lang.Object) 1560440366809L);
//        int int20 = spreadsheetDate14.getYYYY();
//        org.jfree.data.time.SerialDate serialDate21 = serialDate10.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate14);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(serialDate21);
//        int int23 = spreadsheetDate1.compare(serialDate21);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 13 + "'", int9 == 13);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1900 + "'", int20 == 1900);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-22) + "'", int23 == (-22));
//    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass21 = month20.getClass();
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
        java.util.List list24 = timeSeries23.getItems();
        boolean boolean25 = timeSeries16.equals((java.lang.Object) list24);
        timeSeries16.removeAgedItems(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener28 = null;
        timeSeries16.addChangeListener(seriesChangeListener28);
        timeSeries16.fireSeriesChanged();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertNotNull(list24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test154");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1);
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass7 = month6.getClass();
//        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class8);
//        timeSeries9.setDomainDescription("");
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass16 = month15.getClass();
//        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass16);
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class17);
//        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries9.addAndOrUpdate(timeSeries18);
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond22.next();
//        java.util.Calendar calendar24 = null;
//        long long25 = fixedMillisecond22.getLastMillisecond(calendar24);
//        long long26 = fixedMillisecond22.getSerialIndex();
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass29 = month28.getClass();
//        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
//        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass32 = month31.getClass();
//        java.lang.Class class33 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass32);
//        java.lang.Object obj34 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class30, class33);
//        boolean boolean35 = fixedMillisecond22.equals((java.lang.Object) class33);
//        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries18.createCopy((org.jfree.data.time.RegularTimePeriod) year21, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
//        java.lang.String str37 = timeSeries36.getDomainDescription();
//        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass42 = month41.getClass();
//        java.lang.Class class43 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass42);
//        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class43);
//        timeSeries44.setDomainDescription("");
//        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass51 = month50.getClass();
//        java.lang.Class class52 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass51);
//        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class52);
//        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries44.addAndOrUpdate(timeSeries53);
//        java.lang.String str55 = timeSeries54.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries56 = timeSeries36.addAndOrUpdate(timeSeries54);
//        org.jfree.data.time.TimeSeries timeSeries57 = timeSeries2.addAndOrUpdate(timeSeries36);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond58 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = fixedMillisecond58.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem61 = timeSeries57.addOrUpdate(regularTimePeriod59, (double) 1560440360327L);
//        try {
//            timeSeries57.update((-460), (java.lang.Number) 1560440384350L);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(class8);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNotNull(class17);
//        org.junit.Assert.assertNotNull(timeSeries19);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560440434189L + "'", long25 == 1560440434189L);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560440434189L + "'", long26 == 1560440434189L);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertNotNull(wildcardClass32);
//        org.junit.Assert.assertNotNull(class33);
//        org.junit.Assert.assertNull(obj34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(timeSeries36);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "hi!" + "'", str37.equals("hi!"));
//        org.junit.Assert.assertNotNull(wildcardClass42);
//        org.junit.Assert.assertNotNull(class43);
//        org.junit.Assert.assertNotNull(wildcardClass51);
//        org.junit.Assert.assertNotNull(class52);
//        org.junit.Assert.assertNotNull(timeSeries54);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "Time" + "'", str55.equals("Time"));
//        org.junit.Assert.assertNotNull(timeSeries56);
//        org.junit.Assert.assertNotNull(timeSeries57);
//        org.junit.Assert.assertNotNull(regularTimePeriod59);
//        org.junit.Assert.assertNull(timeSeriesDataItem61);
//    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test155");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        int int3 = day0.getMonth();
//        java.lang.String str4 = day0.toString();
//        org.jfree.data.time.SerialDate serialDate5 = day0.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(serialDate6);
//    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test156");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate4 = serialDate2.getFollowingDayOfWeek(2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean8 = spreadsheetDate6.equals((java.lang.Object) 31);
//        java.util.Date date9 = spreadsheetDate6.toDate();
//        boolean boolean11 = spreadsheetDate6.equals((java.lang.Object) 1560440366809L);
//        int int12 = spreadsheetDate6.getYYYY();
//        org.jfree.data.time.SerialDate serialDate13 = serialDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate6);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(serialDate13);
//        serialDate13.setDescription("January 1900");
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1900 + "'", int12 == 1900);
//        org.junit.Assert.assertNotNull(serialDate13);
//    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.time.TimePeriodFormatException: ");
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries6.addPropertyChangeListener(propertyChangeListener7);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = timeSeries6.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        long long3 = year1.getSerialIndex();
        java.util.Date date4 = year1.getStart();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
        long long6 = month5.getLastMillisecond();
        int int7 = month5.getYearValue();
        long long8 = month5.getFirstMillisecond();
        java.lang.String str9 = month5.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month5.next();
        org.junit.Assert.assertNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1900L + "'", long3 == 1900L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-2206281600001L) + "'", long6 == (-2206281600001L));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1900 + "'", int7 == 1900);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-2208960000000L) + "'", long8 == (-2208960000000L));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "January 1900" + "'", str9.equals("January 1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test161");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.setDomainDescription("");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass13 = month12.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond19.next();
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond19.getLastMillisecond(calendar21);
//        long long23 = fixedMillisecond19.getSerialIndex();
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass26 = month25.getClass();
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass26);
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass29 = month28.getClass();
//        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
//        java.lang.Object obj31 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class27, class30);
//        boolean boolean32 = fixedMillisecond19.equals((java.lang.Object) class30);
//        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) year18, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
//        java.util.Date date34 = fixedMillisecond19.getTime();
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date34);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560440434438L + "'", long22 == 1560440434438L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560440434438L + "'", long23 == 1560440434438L);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertNull(obj31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(timeSeries33);
//        org.junit.Assert.assertNotNull(date34);
//    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 100, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test163");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = day0.equals(obj1);
//        java.lang.String str3 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
//        boolean boolean7 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) regularTimePeriod4, (java.lang.Object) regularTimePeriod6);
//        long long8 = regularTimePeriod4.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560365999999L + "'", long8 == 1560365999999L);
//    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass1 = month0.getClass();
        boolean boolean3 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month0, (java.lang.Object) 10.0d);
        long long4 = month0.getLastMillisecond();
        java.lang.String str5 = month0.toString();
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "June 2019" + "'", str5.equals("June 2019"));
    }

//    @Test
//    public void test165() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test165");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
//        long long3 = year1.getSerialIndex();
//        java.util.Date date4 = year1.getStart();
//        long long5 = year1.getFirstMillisecond();
//        int int6 = year1.getYear();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        java.lang.Object obj8 = null;
//        boolean boolean9 = day7.equals(obj8);
//        java.lang.String str10 = day7.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day7.previous();
//        int int12 = year1.compareTo((java.lang.Object) day7);
//        long long13 = year1.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (java.lang.Number) 1560440372428L);
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar19 = null;
//        long long20 = fixedMillisecond18.getLastMillisecond(calendar19);
//        boolean boolean22 = fixedMillisecond18.equals((java.lang.Object) 1561964399999L);
//        long long23 = fixedMillisecond18.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) 13);
//        java.lang.Object obj26 = timeSeriesDataItem25.clone();
//        int int27 = year17.compareTo((java.lang.Object) timeSeriesDataItem25);
//        java.lang.Object obj28 = timeSeriesDataItem25.clone();
//        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass33 = month32.getClass();
//        java.lang.Class class34 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass33);
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class34);
//        timeSeries35.setDomainDescription("");
//        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass42 = month41.getClass();
//        java.lang.Class class43 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass42);
//        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class43);
//        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries35.addAndOrUpdate(timeSeries44);
//        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = fixedMillisecond48.next();
//        java.util.Calendar calendar50 = null;
//        long long51 = fixedMillisecond48.getLastMillisecond(calendar50);
//        long long52 = fixedMillisecond48.getSerialIndex();
//        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass55 = month54.getClass();
//        java.lang.Class class56 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass55);
//        org.jfree.data.time.Month month57 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass58 = month57.getClass();
//        java.lang.Class class59 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass58);
//        java.lang.Object obj60 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class56, class59);
//        boolean boolean61 = fixedMillisecond48.equals((java.lang.Object) class59);
//        org.jfree.data.time.TimeSeries timeSeries62 = timeSeries44.createCopy((org.jfree.data.time.RegularTimePeriod) year47, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond48);
//        java.lang.String str63 = timeSeries62.getDomainDescription();
//        org.jfree.data.time.Month month67 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass68 = month67.getClass();
//        java.lang.Class class69 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass68);
//        org.jfree.data.time.TimeSeries timeSeries70 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class69);
//        timeSeries70.setDomainDescription("");
//        org.jfree.data.time.Month month76 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass77 = month76.getClass();
//        java.lang.Class class78 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass77);
//        org.jfree.data.time.TimeSeries timeSeries79 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class78);
//        org.jfree.data.time.TimeSeries timeSeries80 = timeSeries70.addAndOrUpdate(timeSeries79);
//        java.lang.String str81 = timeSeries80.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries82 = timeSeries62.addAndOrUpdate(timeSeries80);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond83 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = fixedMillisecond83.next();
//        long long85 = regularTimePeriod84.getMiddleMillisecond();
//        boolean boolean86 = timeSeries62.equals((java.lang.Object) regularTimePeriod84);
//        boolean boolean87 = timeSeriesDataItem25.equals((java.lang.Object) timeSeries62);
//        boolean boolean88 = year1.equals((java.lang.Object) boolean87);
//        org.junit.Assert.assertNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1900L + "'", long3 == 1900L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-2208960000000L) + "'", long5 == (-2208960000000L));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1900 + "'", int6 == 1900);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "13-June-2019" + "'", str10.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1900L + "'", long13 == 1900L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560440434717L + "'", long20 == 1560440434717L);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560440434717L + "'", long23 == 1560440434717L);
//        org.junit.Assert.assertNotNull(obj26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertNotNull(obj28);
//        org.junit.Assert.assertNotNull(wildcardClass33);
//        org.junit.Assert.assertNotNull(class34);
//        org.junit.Assert.assertNotNull(wildcardClass42);
//        org.junit.Assert.assertNotNull(class43);
//        org.junit.Assert.assertNotNull(timeSeries45);
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1560440434721L + "'", long51 == 1560440434721L);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1560440434721L + "'", long52 == 1560440434721L);
//        org.junit.Assert.assertNotNull(wildcardClass55);
//        org.junit.Assert.assertNotNull(class56);
//        org.junit.Assert.assertNotNull(wildcardClass58);
//        org.junit.Assert.assertNotNull(class59);
//        org.junit.Assert.assertNull(obj60);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//        org.junit.Assert.assertNotNull(timeSeries62);
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "hi!" + "'", str63.equals("hi!"));
//        org.junit.Assert.assertNotNull(wildcardClass68);
//        org.junit.Assert.assertNotNull(class69);
//        org.junit.Assert.assertNotNull(wildcardClass77);
//        org.junit.Assert.assertNotNull(class78);
//        org.junit.Assert.assertNotNull(timeSeries80);
//        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "Time" + "'", str81.equals("Time"));
//        org.junit.Assert.assertNotNull(timeSeries82);
//        org.junit.Assert.assertNotNull(regularTimePeriod84);
//        org.junit.Assert.assertTrue("'" + long85 + "' != '" + 1560440434727L + "'", long85 == 1560440434727L);
//        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
//        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
//        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
//    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean3 = spreadsheetDate1.equals((java.lang.Object) 31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int6 = spreadsheetDate5.toSerial();
        org.jfree.data.time.SerialDate serialDate7 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate5);
        serialDate7.setDescription("17-June-2019");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertNotNull(serialDate7);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Value");
    }

//    @Test
//    public void test169() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test169");
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass7 = month6.getClass();
//        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class8);
//        timeSeries9.setDomainDescription("");
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass16 = month15.getClass();
//        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass16);
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class17);
//        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries9.addAndOrUpdate(timeSeries18);
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond22.next();
//        java.util.Calendar calendar24 = null;
//        long long25 = fixedMillisecond22.getLastMillisecond(calendar24);
//        long long26 = fixedMillisecond22.getSerialIndex();
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass29 = month28.getClass();
//        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
//        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass32 = month31.getClass();
//        java.lang.Class class33 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass32);
//        java.lang.Object obj34 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class30, class33);
//        boolean boolean35 = fixedMillisecond22.equals((java.lang.Object) class33);
//        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries18.createCopy((org.jfree.data.time.RegularTimePeriod) year21, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
//        java.lang.String str37 = timeSeries36.getDomainDescription();
//        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass42 = month41.getClass();
//        java.lang.Class class43 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass42);
//        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class43);
//        timeSeries44.setDomainDescription("");
//        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass51 = month50.getClass();
//        java.lang.Class class52 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass51);
//        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class52);
//        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries44.addAndOrUpdate(timeSeries53);
//        java.lang.String str55 = timeSeries54.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries56 = timeSeries36.addAndOrUpdate(timeSeries54);
//        boolean boolean58 = timeSeries56.equals((java.lang.Object) 1560440368245L);
//        java.lang.Class class59 = timeSeries56.getTimePeriodClass();
//        java.lang.Object obj60 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("October", class59);
//        java.lang.Class class61 = org.jfree.data.time.RegularTimePeriod.downsize(class59);
//        java.net.URL uRL62 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("1-January-1900", class59);
//        org.jfree.data.time.TimeSeries timeSeries63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440377938L, class59);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(class8);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNotNull(class17);
//        org.junit.Assert.assertNotNull(timeSeries19);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560440435470L + "'", long25 == 1560440435470L);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560440435470L + "'", long26 == 1560440435470L);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertNotNull(wildcardClass32);
//        org.junit.Assert.assertNotNull(class33);
//        org.junit.Assert.assertNull(obj34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(timeSeries36);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "hi!" + "'", str37.equals("hi!"));
//        org.junit.Assert.assertNotNull(wildcardClass42);
//        org.junit.Assert.assertNotNull(class43);
//        org.junit.Assert.assertNotNull(wildcardClass51);
//        org.junit.Assert.assertNotNull(class52);
//        org.junit.Assert.assertNotNull(timeSeries54);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "Time" + "'", str55.equals("Time"));
//        org.junit.Assert.assertNotNull(timeSeries56);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertNotNull(class59);
//        org.junit.Assert.assertNull(obj60);
//        org.junit.Assert.assertNotNull(class61);
//        org.junit.Assert.assertNull(uRL62);
//    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
        java.lang.Class<?> wildcardClass2 = fixedMillisecond0.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) 1561964399999L);
        java.util.Date date5 = fixedMillisecond0.getStart();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date5);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month7);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean3 = spreadsheetDate1.equals((java.lang.Object) 31);
        int int4 = spreadsheetDate1.getYYYY();
        int int5 = spreadsheetDate1.getMonth();
        java.util.Date date6 = spreadsheetDate1.toDate();
        int int7 = spreadsheetDate1.getYYYY();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1900 + "'", int4 == 1900);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1900 + "'", int7 == 1900);
    }

//    @Test
//    public void test172() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test172");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.setDomainDescription("");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass13 = month12.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond19.next();
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond19.getLastMillisecond(calendar21);
//        long long23 = fixedMillisecond19.getSerialIndex();
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass26 = month25.getClass();
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass26);
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass29 = month28.getClass();
//        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
//        java.lang.Object obj31 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class27, class30);
//        boolean boolean32 = fixedMillisecond19.equals((java.lang.Object) class30);
//        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) year18, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
//        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year35.previous();
//        long long37 = year35.getSerialIndex();
//        java.util.Date date38 = year35.getStart();
//        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date38, timeZone39);
//        java.lang.Number number41 = timeSeries33.getValue((org.jfree.data.time.RegularTimePeriod) day40);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560440435925L + "'", long22 == 1560440435925L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560440435925L + "'", long23 == 1560440435925L);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertNull(obj31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(timeSeries33);
//        org.junit.Assert.assertNull(regularTimePeriod36);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1900L + "'", long37 == 1900L);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(timeZone39);
//        org.junit.Assert.assertNull(number41);
//    }

//    @Test
//    public void test173() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test173");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = day0.equals(obj1);
//        java.lang.String str3 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        long long5 = day0.getFirstMillisecond();
//        long long6 = day0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560409200000L + "'", long5 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560495599999L + "'", long6 == 1560495599999L);
//    }

//    @Test
//    public void test174() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test174");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        java.util.List list7 = timeSeries6.getItems();
//        java.lang.Object obj8 = timeSeries6.clone();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.Object obj10 = null;
//        boolean boolean11 = day9.equals(obj10);
//        java.lang.String str12 = day9.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day9.previous();
//        long long14 = day9.getLastMillisecond();
//        int int16 = day9.compareTo((java.lang.Object) 100L);
//        java.util.Date date17 = day9.getEnd();
//        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) day9, (java.lang.Number) 1560440431621L, true);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(list7);
//        org.junit.Assert.assertNotNull(obj8);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "13-June-2019" + "'", str12.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560495599999L + "'", long14 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(date17);
//    }

//    @Test
//    public void test175() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test175");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getLastMillisecond(calendar1);
//        boolean boolean4 = fixedMillisecond0.equals((java.lang.Object) 1561964399999L);
//        long long5 = fixedMillisecond0.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        boolean boolean11 = fixedMillisecond7.equals((java.lang.Object) 1561964399999L);
//        long long12 = fixedMillisecond7.getSerialIndex();
//        java.lang.Class<?> wildcardClass13 = fixedMillisecond7.getClass();
//        java.lang.Number number14 = timeSeries6.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries6.getDataItem(3);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440436195L + "'", long2 == 1560440436195L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560440436195L + "'", long5 == 1560440436195L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560440436196L + "'", long9 == 1560440436196L);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560440436196L + "'", long12 == 1560440436196L);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNull(number14);
//    }

//    @Test
//    public void test176() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test176");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getLastMillisecond(calendar2);
//        long long4 = fixedMillisecond0.getSerialIndex();
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass7 = month6.getClass();
//        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass10 = month9.getClass();
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
//        java.lang.Object obj12 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class8, class11);
//        boolean boolean13 = fixedMillisecond0.equals((java.lang.Object) class11);
//        long long14 = fixedMillisecond0.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560440436209L + "'", long3 == 1560440436209L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560440436209L + "'", long4 == 1560440436209L);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(class8);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertNull(obj12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560440436209L + "'", long14 == 1560440436209L);
//    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass6 = month5.getClass();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-2208960000000L), "Thu Jun 13 08:39:39 PDT 2019", "1-January-1900", (java.lang.Class) wildcardClass6);
        java.net.URL uRL8 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("org.jfree.data.general.SeriesChangeEvent[source=-1]", (java.lang.Class) wildcardClass6);
        java.net.URL uRL9 = org.jfree.chart.util.ObjectUtilities.getResource("", (java.lang.Class) wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNull(uRL8);
        org.junit.Assert.assertNotNull(uRL9);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (100) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9);
    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test180");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.setDomainDescription("");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass13 = month12.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond19.next();
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond19.getLastMillisecond(calendar21);
//        long long23 = fixedMillisecond19.getSerialIndex();
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass26 = month25.getClass();
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass26);
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass29 = month28.getClass();
//        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
//        java.lang.Object obj31 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class27, class30);
//        boolean boolean32 = fixedMillisecond19.equals((java.lang.Object) class30);
//        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) year18, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
//        java.lang.String str34 = timeSeries33.getDomainDescription();
//        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass39 = month38.getClass();
//        java.lang.Class class40 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass39);
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class40);
//        timeSeries41.setDomainDescription("");
//        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass48 = month47.getClass();
//        java.lang.Class class49 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass48);
//        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class49);
//        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries41.addAndOrUpdate(timeSeries50);
//        java.lang.String str52 = timeSeries51.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries33.addAndOrUpdate(timeSeries51);
//        timeSeries51.removeAgedItems(1560440369753L, true);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener57 = null;
//        timeSeries51.removeChangeListener(seriesChangeListener57);
//        java.lang.String str59 = timeSeries51.getRangeDescription();
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560440436342L + "'", long22 == 1560440436342L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560440436342L + "'", long23 == 1560440436342L);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertNull(obj31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(timeSeries33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
//        org.junit.Assert.assertNotNull(wildcardClass39);
//        org.junit.Assert.assertNotNull(class40);
//        org.junit.Assert.assertNotNull(wildcardClass48);
//        org.junit.Assert.assertNotNull(class49);
//        org.junit.Assert.assertNotNull(timeSeries51);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "Time" + "'", str52.equals("Time"));
//        org.junit.Assert.assertNotNull(timeSeries53);
//        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "Value" + "'", str59.equals("Value"));
//    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.previous();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(1900);
        long long5 = year4.getLastMillisecond();
        boolean boolean6 = month0.equals((java.lang.Object) year4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month0.next();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-2177424000001L) + "'", long5 == (-2177424000001L));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass21 = month20.getClass();
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
        java.util.List list24 = timeSeries23.getItems();
        boolean boolean25 = timeSeries16.equals((java.lang.Object) list24);
        timeSeries16.removeAgedItems(false);
        java.lang.Comparable comparable28 = timeSeries16.getKey();
        try {
            timeSeries16.delete((-43619), 13);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -43619");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertNotNull(list24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + comparable28 + "' != '" + "Overwritten values from: 1560440358934" + "'", comparable28.equals("Overwritten values from: 1560440358934"));
    }

//    @Test
//    public void test183() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test183");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.setDomainDescription("");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass13 = month12.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass21 = month20.getClass();
//        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
//        timeSeries23.setDomainDescription("");
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries16.addAndOrUpdate(timeSeries23);
//        java.lang.String str27 = timeSeries26.getDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean30 = fixedMillisecond28.equals((java.lang.Object) 0.0d);
//        java.util.Calendar calendar31 = null;
//        fixedMillisecond28.peg(calendar31);
//        java.lang.String str33 = fixedMillisecond28.toString();
//        long long34 = fixedMillisecond28.getMiddleMillisecond();
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass36 = month35.getClass();
//        boolean boolean38 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month35, (java.lang.Object) 10.0d);
//        long long39 = month35.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries26.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (org.jfree.data.time.RegularTimePeriod) month35);
//        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass45 = month44.getClass();
//        java.lang.Class class46 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass45);
//        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class46);
//        timeSeries47.setDomainDescription("");
//        org.jfree.data.time.Month month53 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass54 = month53.getClass();
//        java.lang.Class class55 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass54);
//        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class55);
//        org.jfree.data.time.TimeSeries timeSeries57 = timeSeries47.addAndOrUpdate(timeSeries56);
//        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day();
//        java.lang.Object obj59 = null;
//        boolean boolean60 = day58.equals(obj59);
//        int int61 = day58.getMonth();
//        java.lang.Number number62 = null;
//        timeSeries47.add((org.jfree.data.time.RegularTimePeriod) day58, number62, true);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond65 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = fixedMillisecond65.next();
//        java.lang.Class<?> wildcardClass67 = fixedMillisecond65.getClass();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem69 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond65, (double) 1561964399999L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem71 = timeSeries47.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond65, 0.0d);
//        long long72 = fixedMillisecond65.getFirstMillisecond();
//        java.lang.Number number73 = timeSeries40.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond65);
//        timeSeries40.removeAgedItems(false);
//        java.lang.Comparable comparable76 = timeSeries40.getKey();
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(class22);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertNull(str27);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Thu Jun 13 08:40:36 PDT 2019" + "'", str33.equals("Thu Jun 13 08:40:36 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560440436747L + "'", long34 == 1560440436747L);
//        org.junit.Assert.assertNotNull(wildcardClass36);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1561964399999L + "'", long39 == 1561964399999L);
//        org.junit.Assert.assertNotNull(timeSeries40);
//        org.junit.Assert.assertNotNull(wildcardClass45);
//        org.junit.Assert.assertNotNull(class46);
//        org.junit.Assert.assertNotNull(wildcardClass54);
//        org.junit.Assert.assertNotNull(class55);
//        org.junit.Assert.assertNotNull(timeSeries57);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 6 + "'", int61 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod66);
//        org.junit.Assert.assertNotNull(wildcardClass67);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem71);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 1560440436751L + "'", long72 == 1560440436751L);
//        org.junit.Assert.assertNull(number73);
//        org.junit.Assert.assertTrue("'" + comparable76 + "' != '" + "Overwritten values from: Overwritten values from: 1560440358934" + "'", comparable76.equals("Overwritten values from: Overwritten values from: 1560440358934"));
//    }

//    @Test
//    public void test184() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test184");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean3 = spreadsheetDate1.equals((java.lang.Object) 31);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        int int5 = day4.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate6 = day4.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate8 = serialDate6.getFollowingDayOfWeek(2);
//        java.lang.String str9 = serialDate8.toString();
//        boolean boolean10 = spreadsheetDate1.isOnOrBefore(serialDate8);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean14 = spreadsheetDate12.equals((java.lang.Object) 31);
//        int int15 = spreadsheetDate12.getDayOfWeek();
//        int int16 = spreadsheetDate12.getMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate18);
//        boolean boolean20 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate12, (org.jfree.data.time.SerialDate) spreadsheetDate18);
//        java.lang.String str21 = spreadsheetDate12.getDescription();
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "17-June-2019" + "'", str9.equals("17-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 3 + "'", int15 == 3);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNull(str21);
//    }

//    @Test
//    public void test185() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test185");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getLastMillisecond(calendar3);
//        boolean boolean6 = fixedMillisecond2.equals((java.lang.Object) 1561964399999L);
//        long long7 = fixedMillisecond2.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (double) 13);
//        java.lang.Object obj10 = timeSeriesDataItem9.clone();
//        int int11 = year1.compareTo((java.lang.Object) timeSeriesDataItem9);
//        java.lang.Object obj12 = timeSeriesDataItem9.clone();
//        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass17 = month16.getClass();
//        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass17);
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class18);
//        timeSeries19.setDomainDescription("");
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass26 = month25.getClass();
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass26);
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class27);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries19.addAndOrUpdate(timeSeries28);
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = fixedMillisecond32.next();
//        java.util.Calendar calendar34 = null;
//        long long35 = fixedMillisecond32.getLastMillisecond(calendar34);
//        long long36 = fixedMillisecond32.getSerialIndex();
//        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass39 = month38.getClass();
//        java.lang.Class class40 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass39);
//        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass42 = month41.getClass();
//        java.lang.Class class43 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass42);
//        java.lang.Object obj44 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class40, class43);
//        boolean boolean45 = fixedMillisecond32.equals((java.lang.Object) class43);
//        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries28.createCopy((org.jfree.data.time.RegularTimePeriod) year31, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond32);
//        java.lang.String str47 = timeSeries46.getDomainDescription();
//        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass52 = month51.getClass();
//        java.lang.Class class53 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass52);
//        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class53);
//        timeSeries54.setDomainDescription("");
//        org.jfree.data.time.Month month60 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass61 = month60.getClass();
//        java.lang.Class class62 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass61);
//        org.jfree.data.time.TimeSeries timeSeries63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class62);
//        org.jfree.data.time.TimeSeries timeSeries64 = timeSeries54.addAndOrUpdate(timeSeries63);
//        java.lang.String str65 = timeSeries64.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries66 = timeSeries46.addAndOrUpdate(timeSeries64);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond67 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = fixedMillisecond67.next();
//        long long69 = regularTimePeriod68.getMiddleMillisecond();
//        boolean boolean70 = timeSeries46.equals((java.lang.Object) regularTimePeriod68);
//        boolean boolean71 = timeSeriesDataItem9.equals((java.lang.Object) timeSeries46);
//        timeSeries46.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond73 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = fixedMillisecond73.next();
//        java.lang.Class<?> wildcardClass75 = fixedMillisecond73.getClass();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem77 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond73, (double) 1561964399999L);
//        java.util.Date date78 = fixedMillisecond73.getStart();
//        org.jfree.data.time.Year year80 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = year80.previous();
//        long long82 = year80.getSerialIndex();
//        java.util.Date date83 = year80.getStart();
//        org.jfree.data.time.Month month84 = new org.jfree.data.time.Month(date83);
//        org.jfree.data.time.Month month85 = new org.jfree.data.time.Month(date83);
//        org.jfree.data.time.Year year87 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = year87.previous();
//        long long89 = year87.getSerialIndex();
//        java.util.Date date90 = year87.getStart();
//        java.util.TimeZone timeZone91 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day92 = new org.jfree.data.time.Day(date90, timeZone91);
//        org.jfree.data.time.Month month93 = new org.jfree.data.time.Month(date83, timeZone91);
//        org.jfree.data.time.Day day94 = new org.jfree.data.time.Day(date78, timeZone91);
//        long long95 = day94.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem96 = timeSeries46.getDataItem((org.jfree.data.time.RegularTimePeriod) day94);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560440437392L + "'", long4 == 1560440437392L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560440437392L + "'", long7 == 1560440437392L);
//        org.junit.Assert.assertNotNull(obj10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(obj12);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(class18);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560440437395L + "'", long35 == 1560440437395L);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560440437395L + "'", long36 == 1560440437395L);
//        org.junit.Assert.assertNotNull(wildcardClass39);
//        org.junit.Assert.assertNotNull(class40);
//        org.junit.Assert.assertNotNull(wildcardClass42);
//        org.junit.Assert.assertNotNull(class43);
//        org.junit.Assert.assertNull(obj44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertNotNull(timeSeries46);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "hi!" + "'", str47.equals("hi!"));
//        org.junit.Assert.assertNotNull(wildcardClass52);
//        org.junit.Assert.assertNotNull(class53);
//        org.junit.Assert.assertNotNull(wildcardClass61);
//        org.junit.Assert.assertNotNull(class62);
//        org.junit.Assert.assertNotNull(timeSeries64);
//        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "Time" + "'", str65.equals("Time"));
//        org.junit.Assert.assertNotNull(timeSeries66);
//        org.junit.Assert.assertNotNull(regularTimePeriod68);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 1560440437411L + "'", long69 == 1560440437411L);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod74);
//        org.junit.Assert.assertNotNull(wildcardClass75);
//        org.junit.Assert.assertNotNull(date78);
//        org.junit.Assert.assertNull(regularTimePeriod81);
//        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 1900L + "'", long82 == 1900L);
//        org.junit.Assert.assertNotNull(date83);
//        org.junit.Assert.assertNull(regularTimePeriod88);
//        org.junit.Assert.assertTrue("'" + long89 + "' != '" + 1900L + "'", long89 == 1900L);
//        org.junit.Assert.assertNotNull(date90);
//        org.junit.Assert.assertNotNull(timeZone91);
//        org.junit.Assert.assertTrue("'" + long95 + "' != '" + 43629L + "'", long95 == 43629L);
//        org.junit.Assert.assertNull(timeSeriesDataItem96);
//    }

//    @Test
//    public void test186() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test186");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getLastMillisecond(calendar2);
//        long long4 = fixedMillisecond0.getSerialIndex();
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass7 = month6.getClass();
//        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass10 = month9.getClass();
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
//        java.lang.Object obj12 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class8, class11);
//        boolean boolean13 = fixedMillisecond0.equals((java.lang.Object) class11);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = fixedMillisecond0.previous();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560440439228L + "'", long3 == 1560440439228L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560440439228L + "'", long4 == 1560440439228L);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(class8);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertNull(obj12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440401673L);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("org.jfree.data.general.SeriesChangeEvent[source=13-June-2019]");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test189");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.setDomainDescription("");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass13 = month12.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
//        timeSeries6.fireSeriesChanged();
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
//        int int20 = month18.compareTo((java.lang.Object) 1L);
//        long long21 = month18.getLastMillisecond();
//        int int23 = month18.compareTo((java.lang.Object) 'a');
//        int int24 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month18);
//        timeSeries6.setMaximumItemCount(2);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        java.lang.Object obj28 = null;
//        boolean boolean29 = day27.equals(obj28);
//        java.lang.String str30 = day27.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day27.previous();
//        java.lang.String str32 = day27.toString();
//        long long33 = day27.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day27.next();
//        try {
//            timeSeries6.update(regularTimePeriod34, (java.lang.Number) 1560668399999L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1561964399999L + "'", long21 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "13-June-2019" + "'", str30.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "13-June-2019" + "'", str32.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 43629L + "'", long33 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//    }

//    @Test
//    public void test190() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test190");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
//        long long3 = year1.getSerialIndex();
//        java.util.Date date4 = year1.getStart();
//        long long5 = year1.getFirstMillisecond();
//        int int6 = year1.getYear();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        java.lang.Object obj8 = null;
//        boolean boolean9 = day7.equals(obj8);
//        java.lang.String str10 = day7.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day7.previous();
//        int int12 = year1.compareTo((java.lang.Object) day7);
//        int int13 = year1.getYear();
//        boolean boolean15 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year1, (java.lang.Object) "13-June-2019");
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) "13-June-2019");
//        org.junit.Assert.assertNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1900L + "'", long3 == 1900L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-2208960000000L) + "'", long5 == (-2208960000000L));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1900 + "'", int6 == 1900);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "13-June-2019" + "'", str10.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1900 + "'", int13 == 1900);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test191");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
//        java.lang.Class<?> wildcardClass2 = fixedMillisecond0.getClass();
//        java.lang.String str3 = fixedMillisecond0.toString();
//        java.util.Calendar calendar4 = null;
//        long long5 = fixedMillisecond0.getMiddleMillisecond(calendar4);
//        java.util.Calendar calendar6 = null;
//        fixedMillisecond0.peg(calendar6);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Thu Jun 13 08:40:39 PDT 2019" + "'", str3.equals("Thu Jun 13 08:40:39 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560440439443L + "'", long5 == 1560440439443L);
//    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test192");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.clear();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass12 = month11.getClass();
//        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class13);
//        timeSeries14.setDomainDescription("");
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass21 = month20.getClass();
//        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries14.addAndOrUpdate(timeSeries23);
//        java.lang.String str25 = timeSeries23.getRangeDescription();
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries6.addAndOrUpdate(timeSeries23);
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year28.previous();
//        long long30 = year28.getSerialIndex();
//        java.util.Date date31 = year28.getStart();
//        long long32 = year28.getFirstMillisecond();
//        int int33 = year28.getYear();
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        java.lang.Object obj35 = null;
//        boolean boolean36 = day34.equals(obj35);
//        java.lang.String str37 = day34.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = day34.previous();
//        int int39 = year28.compareTo((java.lang.Object) day34);
//        long long40 = year28.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year28, (java.lang.Number) 1560440372428L);
//        java.util.Date date43 = year28.getEnd();
//        try {
//            timeSeries23.add((org.jfree.data.time.RegularTimePeriod) year28, (java.lang.Number) 1560440439228L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNotNull(class13);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(class22);
//        org.junit.Assert.assertNotNull(timeSeries24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "ThreadContext" + "'", str25.equals("ThreadContext"));
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertNull(regularTimePeriod29);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1900L + "'", long30 == 1900L);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-2208960000000L) + "'", long32 == (-2208960000000L));
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1900 + "'", int33 == 1900);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "13-June-2019" + "'", str37.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1900L + "'", long40 == 1900L);
//        org.junit.Assert.assertNotNull(date43);
//    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(11);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

//    @Test
//    public void test194() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test194");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = day0.equals(obj1);
//        java.lang.String str3 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        java.lang.String str5 = day0.toString();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = day0.getLastMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//    }

//    @Test
//    public void test195() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test195");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
//        java.lang.Class<?> wildcardClass2 = fixedMillisecond0.getClass();
//        java.lang.String str3 = fixedMillisecond0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond0.previous();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Thu Jun 13 08:40:39 PDT 2019" + "'", str3.equals("Thu Jun 13 08:40:39 PDT 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.previous();
        int int5 = month0.compareTo((java.lang.Object) month2);
        int int6 = month0.getMonth();
        int int7 = month0.getMonth();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
    }

//    @Test
//    public void test197() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test197");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.setDomainDescription("");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass13 = month12.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass21 = month20.getClass();
//        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
//        java.util.List list24 = timeSeries23.getItems();
//        boolean boolean25 = timeSeries16.equals((java.lang.Object) list24);
//        timeSeries16.removeAgedItems(true);
//        timeSeries16.setDescription("");
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass34 = month33.getClass();
//        java.lang.Class class35 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass34);
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class35);
//        timeSeries36.setDomainDescription("");
//        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass43 = month42.getClass();
//        java.lang.Class class44 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass43);
//        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class44);
//        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries36.addAndOrUpdate(timeSeries45);
//        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass51 = month50.getClass();
//        java.lang.Class class52 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass51);
//        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class52);
//        timeSeries53.setDomainDescription("");
//        org.jfree.data.time.TimeSeries timeSeries56 = timeSeries46.addAndOrUpdate(timeSeries53);
//        java.lang.String str57 = timeSeries56.getDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond58 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean60 = fixedMillisecond58.equals((java.lang.Object) 0.0d);
//        java.util.Calendar calendar61 = null;
//        fixedMillisecond58.peg(calendar61);
//        java.lang.String str63 = fixedMillisecond58.toString();
//        long long64 = fixedMillisecond58.getMiddleMillisecond();
//        org.jfree.data.time.Month month65 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass66 = month65.getClass();
//        boolean boolean68 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month65, (java.lang.Object) 10.0d);
//        long long69 = month65.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries70 = timeSeries56.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond58, (org.jfree.data.time.RegularTimePeriod) month65);
//        try {
//            timeSeries16.add((org.jfree.data.time.RegularTimePeriod) month65, 0.0d, true);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(class22);
//        org.junit.Assert.assertNotNull(list24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNotNull(class35);
//        org.junit.Assert.assertNotNull(wildcardClass43);
//        org.junit.Assert.assertNotNull(class44);
//        org.junit.Assert.assertNotNull(timeSeries46);
//        org.junit.Assert.assertNotNull(wildcardClass51);
//        org.junit.Assert.assertNotNull(class52);
//        org.junit.Assert.assertNotNull(timeSeries56);
//        org.junit.Assert.assertNull(str57);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "Thu Jun 13 08:40:39 PDT 2019" + "'", str63.equals("Thu Jun 13 08:40:39 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 1560440439564L + "'", long64 == 1560440439564L);
//        org.junit.Assert.assertNotNull(wildcardClass66);
//        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 1561964399999L + "'", long69 == 1561964399999L);
//        org.junit.Assert.assertNotNull(timeSeries70);
//    }

//    @Test
//    public void test198() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test198");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getLastMillisecond(calendar10);
//        boolean boolean13 = fixedMillisecond9.equals((java.lang.Object) 1561964399999L);
//        long long14 = fixedMillisecond9.getSerialIndex();
//        java.util.Calendar calendar15 = null;
//        fixedMillisecond9.peg(calendar15);
//        java.util.Date date17 = fixedMillisecond9.getTime();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent18 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) fixedMillisecond9);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, 10.0d);
//        java.lang.Object obj21 = timeSeries6.clone();
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560440439589L + "'", long11 == 1560440439589L);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560440439589L + "'", long14 == 1560440439589L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNull(timeSeriesDataItem20);
//        org.junit.Assert.assertNotNull(obj21);
//    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test199");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getLastMillisecond(calendar1);
//        boolean boolean4 = fixedMillisecond0.equals((java.lang.Object) 1561964399999L);
//        long long5 = fixedMillisecond0.getSerialIndex();
//        java.util.Date date6 = fixedMillisecond0.getEnd();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass12 = month11.getClass();
//        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class13);
//        timeSeries14.setDomainDescription("");
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass21 = month20.getClass();
//        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries14.addAndOrUpdate(timeSeries23);
//        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = fixedMillisecond27.next();
//        java.util.Calendar calendar29 = null;
//        long long30 = fixedMillisecond27.getLastMillisecond(calendar29);
//        long long31 = fixedMillisecond27.getSerialIndex();
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass34 = month33.getClass();
//        java.lang.Class class35 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass34);
//        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass37 = month36.getClass();
//        java.lang.Class class38 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass37);
//        java.lang.Object obj39 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class35, class38);
//        boolean boolean40 = fixedMillisecond27.equals((java.lang.Object) class38);
//        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries23.createCopy((org.jfree.data.time.RegularTimePeriod) year26, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
//        java.lang.String str42 = timeSeries41.getDomainDescription();
//        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass47 = month46.getClass();
//        java.lang.Class class48 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass47);
//        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class48);
//        timeSeries49.setDomainDescription("");
//        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass56 = month55.getClass();
//        java.lang.Class class57 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass56);
//        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class57);
//        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries49.addAndOrUpdate(timeSeries58);
//        java.lang.String str60 = timeSeries59.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries41.addAndOrUpdate(timeSeries59);
//        boolean boolean63 = timeSeries61.equals((java.lang.Object) 1560440368245L);
//        java.lang.Class class64 = timeSeries61.getTimePeriodClass();
//        java.lang.Object obj65 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("October", class64);
//        java.lang.Class class66 = org.jfree.data.time.RegularTimePeriod.downsize(class64);
//        org.jfree.data.time.TimeSeries timeSeries67 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date6, class66);
//        org.jfree.data.time.Year year68 = new org.jfree.data.time.Year(date6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440439639L + "'", long2 == 1560440439639L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560440439639L + "'", long5 == 1560440439639L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNotNull(class13);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(class22);
//        org.junit.Assert.assertNotNull(timeSeries24);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560440439651L + "'", long30 == 1560440439651L);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560440439651L + "'", long31 == 1560440439651L);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNotNull(class35);
//        org.junit.Assert.assertNotNull(wildcardClass37);
//        org.junit.Assert.assertNotNull(class38);
//        org.junit.Assert.assertNull(obj39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(timeSeries41);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "hi!" + "'", str42.equals("hi!"));
//        org.junit.Assert.assertNotNull(wildcardClass47);
//        org.junit.Assert.assertNotNull(class48);
//        org.junit.Assert.assertNotNull(wildcardClass56);
//        org.junit.Assert.assertNotNull(class57);
//        org.junit.Assert.assertNotNull(timeSeries59);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "Time" + "'", str60.equals("Time"));
//        org.junit.Assert.assertNotNull(timeSeries61);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertNotNull(class64);
//        org.junit.Assert.assertNull(obj65);
//        org.junit.Assert.assertNotNull(class66);
//    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean3 = spreadsheetDate1.equals((java.lang.Object) 31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int6 = spreadsheetDate5.toSerial();
        org.jfree.data.time.SerialDate serialDate7 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate5);
        int int8 = spreadsheetDate5.toSerial();
        int int9 = spreadsheetDate5.getMonth();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass6 = month5.getClass();
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
        java.io.InputStream inputStream8 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass6);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass10 = month9.getClass();
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        java.lang.Object obj12 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Thu Jun 13 08:39:19 PDT 2019", (java.lang.Class) wildcardClass6, class11);
        java.lang.Object obj13 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", (java.lang.Class) wildcardClass6);
        java.io.InputStream inputStream14 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Jan", (java.lang.Class) wildcardClass6);
        java.net.URL uRL15 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("Thu Jun 13 08:39:42 PDT 2019", (java.lang.Class) wildcardClass6);
        java.util.Date date16 = null;
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date16, timeZone17);
        java.lang.ClassLoader classLoader19 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNotNull(inputStream8);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNull(obj12);
        org.junit.Assert.assertNull(obj13);
        org.junit.Assert.assertNull(inputStream14);
        org.junit.Assert.assertNull(uRL15);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(classLoader19);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.clear();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass12 = month11.getClass();
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class13);
        timeSeries14.setDomainDescription("");
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass21 = month20.getClass();
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries14.addAndOrUpdate(timeSeries23);
        java.lang.String str25 = timeSeries23.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries6.addAndOrUpdate(timeSeries23);
        timeSeries26.setMaximumItemAge((long) 2019);
        timeSeries26.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=Thu Jun 13 08:40:14 PDT 2019]");
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "ThreadContext" + "'", str25.equals("ThreadContext"));
        org.junit.Assert.assertNotNull(timeSeries26);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (java.lang.Number) 10.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = timeSeriesDataItem3.getPeriod();
        java.lang.Object obj5 = timeSeriesDataItem3.clone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = timeSeriesDataItem3.getPeriod();
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass6 = month5.getClass();
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
        java.io.InputStream inputStream8 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass6);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass10 = month9.getClass();
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        java.lang.Object obj12 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Thu Jun 13 08:39:19 PDT 2019", (java.lang.Class) wildcardClass6, class11);
        java.lang.Object obj13 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", (java.lang.Class) wildcardClass6);
        java.io.InputStream inputStream14 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Jan", (java.lang.Class) wildcardClass6);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass20 = month19.getClass();
        java.lang.Class class21 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass20);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class21);
        timeSeries22.setDomainDescription("");
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass29 = month28.getClass();
        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class30);
        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries22.addAndOrUpdate(timeSeries31);
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass37 = month36.getClass();
        java.lang.Class class38 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass37);
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class38);
        java.util.List list40 = timeSeries39.getItems();
        boolean boolean41 = timeSeries32.equals((java.lang.Object) list40);
        java.lang.Class class42 = timeSeries32.getTimePeriodClass();
        java.io.InputStream inputStream43 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Thu Jun 13 08:39:23 PDT 2019", class42);
        java.lang.Object obj44 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("13-June-2019", (java.lang.Class) wildcardClass6, class42);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNotNull(inputStream8);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNull(obj12);
        org.junit.Assert.assertNull(obj13);
        org.junit.Assert.assertNull(inputStream14);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(class21);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertNotNull(class30);
        org.junit.Assert.assertNotNull(timeSeries32);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertNotNull(class38);
        org.junit.Assert.assertNotNull(list40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(class42);
        org.junit.Assert.assertNull(inputStream43);
        org.junit.Assert.assertNull(obj44);
    }

//    @Test
//    public void test206() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test206");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.setDomainDescription("");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass13 = month12.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond19.next();
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond19.getLastMillisecond(calendar21);
//        long long23 = fixedMillisecond19.getSerialIndex();
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass26 = month25.getClass();
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass26);
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass29 = month28.getClass();
//        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
//        java.lang.Object obj31 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class27, class30);
//        boolean boolean32 = fixedMillisecond19.equals((java.lang.Object) class30);
//        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) year18, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
//        java.lang.String str34 = timeSeries33.getDomainDescription();
//        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass39 = month38.getClass();
//        java.lang.Class class40 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass39);
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class40);
//        timeSeries41.setDomainDescription("");
//        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass48 = month47.getClass();
//        java.lang.Class class49 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass48);
//        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class49);
//        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries41.addAndOrUpdate(timeSeries50);
//        java.lang.String str52 = timeSeries51.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries33.addAndOrUpdate(timeSeries51);
//        boolean boolean55 = timeSeries53.equals((java.lang.Object) 1560440368245L);
//        java.lang.Class class56 = timeSeries53.getTimePeriodClass();
//        timeSeries53.removeAgedItems(1560440360381L, true);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = null;
//        try {
//            timeSeries53.update(regularTimePeriod60, (java.lang.Number) 1.561964399999E12d);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560440440546L + "'", long22 == 1560440440546L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560440440546L + "'", long23 == 1560440440546L);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertNull(obj31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(timeSeries33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
//        org.junit.Assert.assertNotNull(wildcardClass39);
//        org.junit.Assert.assertNotNull(class40);
//        org.junit.Assert.assertNotNull(wildcardClass48);
//        org.junit.Assert.assertNotNull(class49);
//        org.junit.Assert.assertNotNull(timeSeries51);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "Time" + "'", str52.equals("Time"));
//        org.junit.Assert.assertNotNull(timeSeries53);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertNotNull(class56);
//    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass7 = month6.getClass();
        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
        java.io.InputStream inputStream9 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass7);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass11 = month10.getClass();
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        java.lang.Object obj13 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Thu Jun 13 08:39:19 PDT 2019", (java.lang.Class) wildcardClass7, class12);
        java.lang.Object obj14 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", (java.lang.Class) wildcardClass7);
        java.io.InputStream inputStream15 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Jan", (java.lang.Class) wildcardClass7);
        java.net.URL uRL16 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("Value", (java.lang.Class) wildcardClass7);
        java.io.InputStream inputStream17 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("17-June-2019", (java.lang.Class) wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(class8);
        org.junit.Assert.assertNotNull(inputStream9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertNull(obj13);
        org.junit.Assert.assertNull(obj14);
        org.junit.Assert.assertNull(inputStream15);
        org.junit.Assert.assertNull(uRL16);
        org.junit.Assert.assertNull(inputStream17);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        long long3 = year1.getSerialIndex();
        java.util.Date date4 = year1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (double) 1560440407793L);
        org.junit.Assert.assertNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1900L + "'", long3 == 1900L);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) (byte) 100, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test210() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test210");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int2 = spreadsheetDate1.toSerial();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        int int4 = day3.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
//        boolean boolean6 = spreadsheetDate1.isOnOrAfter(serialDate5);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int9 = day8.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate10 = day8.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate12 = serialDate10.getFollowingDayOfWeek(2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean16 = spreadsheetDate14.equals((java.lang.Object) 31);
//        java.util.Date date17 = spreadsheetDate14.toDate();
//        boolean boolean19 = spreadsheetDate14.equals((java.lang.Object) 1560440366809L);
//        int int20 = spreadsheetDate14.getYYYY();
//        org.jfree.data.time.SerialDate serialDate21 = serialDate10.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate14);
//        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addYears((-1), serialDate10);
//        int int23 = spreadsheetDate1.compare(serialDate10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate25);
//        boolean boolean27 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate25);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate25);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean35 = spreadsheetDate33.equals((java.lang.Object) 31);
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        int int37 = day36.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate38 = day36.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate40 = serialDate38.getFollowingDayOfWeek(2);
//        java.lang.String str41 = serialDate40.toString();
//        boolean boolean42 = spreadsheetDate33.isOnOrAfter(serialDate40);
//        boolean boolean43 = spreadsheetDate31.isOn((org.jfree.data.time.SerialDate) spreadsheetDate33);
//        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.addDays(9999, (org.jfree.data.time.SerialDate) spreadsheetDate31);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean48 = spreadsheetDate46.equals((java.lang.Object) 31);
//        java.util.Date date49 = spreadsheetDate46.toDate();
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
//        int int51 = day50.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate52 = day50.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate54 = serialDate52.getFollowingDayOfWeek(2);
//        java.lang.String str55 = serialDate54.toString();
//        int int56 = spreadsheetDate46.compare(serialDate54);
//        org.jfree.data.time.SerialDate serialDate57 = spreadsheetDate31.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate46);
//        boolean boolean58 = spreadsheetDate25.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate31);
//        java.util.Date date59 = spreadsheetDate31.toDate();
//        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate31);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 13 + "'", int9 == 13);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1900 + "'", int20 == 1900);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-43619) + "'", int23 == (-43619));
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 13 + "'", int37 == 13);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertNotNull(serialDate40);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "17-June-2019" + "'", str41.equals("17-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
//        org.junit.Assert.assertNotNull(serialDate44);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 13 + "'", int51 == 13);
//        org.junit.Assert.assertNotNull(serialDate52);
//        org.junit.Assert.assertNotNull(serialDate54);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "17-June-2019" + "'", str55.equals("17-June-2019"));
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + (-43623) + "'", int56 == (-43623));
//        org.junit.Assert.assertNotNull(serialDate57);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertNotNull(date59);
//    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(9);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass21 = month20.getClass();
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
        java.util.List list24 = timeSeries23.getItems();
        boolean boolean25 = timeSeries16.equals((java.lang.Object) list24);
        boolean boolean27 = timeSeries16.equals((java.lang.Object) false);
        java.lang.String str28 = timeSeries16.getDescription();
        timeSeries16.removeAgedItems(true);
        java.lang.String str31 = timeSeries16.getRangeDescription();
        long long32 = timeSeries16.getMaximumItemAge();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertNotNull(list24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Value" + "'", str31.equals("Value"));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 9223372036854775807L + "'", long32 == 9223372036854775807L);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        long long3 = year1.getSerialIndex();
        java.util.Date date4 = year1.getStart();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date4);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(1900);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        long long10 = year8.getSerialIndex();
        java.util.Date date11 = year8.getStart();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date11, timeZone12);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date4, timeZone12);
        java.util.Calendar calendar15 = null;
        try {
            long long16 = day14.getLastMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1900L + "'", long3 == 1900L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1900L + "'", long10 == 1900L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test214");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int2 = month0.compareTo((java.lang.Object) 1L);
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass7 = month6.getClass();
//        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class8);
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timeSeries9.addPropertyChangeListener(propertyChangeListener10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar13 = null;
//        long long14 = fixedMillisecond12.getLastMillisecond(calendar13);
//        boolean boolean16 = fixedMillisecond12.equals((java.lang.Object) 1561964399999L);
//        long long17 = fixedMillisecond12.getSerialIndex();
//        java.util.Calendar calendar18 = null;
//        fixedMillisecond12.peg(calendar18);
//        java.util.Date date20 = fixedMillisecond12.getTime();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent21 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) fixedMillisecond12);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, 10.0d);
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass28 = month27.getClass();
//        java.lang.Class class29 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass28);
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class29);
//        timeSeries30.setDomainDescription("");
//        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass37 = month36.getClass();
//        java.lang.Class class38 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass37);
//        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class38);
//        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries30.addAndOrUpdate(timeSeries39);
//        timeSeries30.fireSeriesChanged();
//        int int42 = timeSeries30.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries43 = timeSeries9.addAndOrUpdate(timeSeries30);
//        boolean boolean44 = month0.equals((java.lang.Object) timeSeries30);
//        java.beans.PropertyChangeListener propertyChangeListener45 = null;
//        timeSeries30.addPropertyChangeListener(propertyChangeListener45);
//        java.lang.Object obj47 = timeSeries30.clone();
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        java.lang.Object obj49 = null;
//        boolean boolean50 = day48.equals(obj49);
//        java.lang.String str51 = day48.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = day48.previous();
//        boolean boolean53 = timeSeries30.equals((java.lang.Object) day48);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(class8);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560440441393L + "'", long14 == 1560440441393L);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560440441393L + "'", long17 == 1560440441393L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNull(timeSeriesDataItem23);
//        org.junit.Assert.assertNotNull(wildcardClass28);
//        org.junit.Assert.assertNotNull(class29);
//        org.junit.Assert.assertNotNull(wildcardClass37);
//        org.junit.Assert.assertNotNull(class38);
//        org.junit.Assert.assertNotNull(timeSeries40);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertNotNull(timeSeries43);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertNotNull(obj47);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "13-June-2019" + "'", str51.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//    }

//    @Test
//    public void test215() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test215");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.setDomainDescription("");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass13 = month12.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass21 = month20.getClass();
//        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
//        timeSeries23.setDomainDescription("");
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries16.addAndOrUpdate(timeSeries23);
//        java.lang.String str27 = timeSeries26.getDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean30 = fixedMillisecond28.equals((java.lang.Object) 0.0d);
//        java.util.Calendar calendar31 = null;
//        fixedMillisecond28.peg(calendar31);
//        java.lang.String str33 = fixedMillisecond28.toString();
//        long long34 = fixedMillisecond28.getMiddleMillisecond();
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass36 = month35.getClass();
//        boolean boolean38 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month35, (java.lang.Object) 10.0d);
//        long long39 = month35.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries26.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (org.jfree.data.time.RegularTimePeriod) month35);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = month35.previous();
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(class22);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertNull(str27);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Thu Jun 13 08:40:41 PDT 2019" + "'", str33.equals("Thu Jun 13 08:40:41 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560440441579L + "'", long34 == 1560440441579L);
//        org.junit.Assert.assertNotNull(wildcardClass36);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1561964399999L + "'", long39 == 1561964399999L);
//        org.junit.Assert.assertNotNull(timeSeries40);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (java.lang.Number) 10.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year1.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year1.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNull(regularTimePeriod5);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(1900);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year18.previous();
        long long20 = year18.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries16.getDataItem((org.jfree.data.time.RegularTimePeriod) year18);
        java.lang.Object obj22 = timeSeries16.clone();
        timeSeries16.removeAgedItems(false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1900L + "'", long20 == 1900L);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertNotNull(obj22);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("Thu Jun 13 08:39:53 PDT 2019");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

//    @Test
//    public void test219() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test219");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getLastMillisecond(calendar1);
//        boolean boolean4 = fixedMillisecond0.equals((java.lang.Object) 1561964399999L);
//        long long5 = fixedMillisecond0.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) 13);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond0.getMiddleMillisecond(calendar8);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond0.previous();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass15 = month14.getClass();
//        java.lang.Class class16 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass15);
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass18 = month17.getClass();
//        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass18);
//        java.lang.Object obj20 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class16, class19);
//        java.net.URL uRL21 = org.jfree.chart.util.ObjectUtilities.getResource("1900", class16);
//        java.net.URL uRL22 = org.jfree.chart.util.ObjectUtilities.getResource("Thu Jun 13 08:39:23 PDT 2019", class16);
//        int int23 = fixedMillisecond0.compareTo((java.lang.Object) "Thu Jun 13 08:39:23 PDT 2019");
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440441868L + "'", long2 == 1560440441868L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560440441868L + "'", long5 == 1560440441868L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560440441868L + "'", long9 == 1560440441868L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertNotNull(class16);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertNotNull(class19);
//        org.junit.Assert.assertNull(obj20);
//        org.junit.Assert.assertNull(uRL21);
//        org.junit.Assert.assertNull(uRL22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.previous();
        int int3 = month0.getMonth();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
    }

//    @Test
//    public void test221() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test221");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        int int3 = day0.getMonth();
//        long long4 = day0.getFirstMillisecond();
//        boolean boolean6 = day0.equals((java.lang.Object) (-1));
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass12 = month11.getClass();
//        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass15 = month14.getClass();
//        java.lang.Class class16 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass15);
//        java.lang.Object obj17 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class13, class16);
//        java.net.URL uRL18 = org.jfree.chart.util.ObjectUtilities.getResource("1900", class13);
//        java.net.URL uRL19 = org.jfree.chart.util.ObjectUtilities.getResource("Thu Jun 13 08:39:23 PDT 2019", class13);
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass23 = month22.getClass();
//        java.lang.Class class24 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass23);
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass26 = month25.getClass();
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass26);
//        java.lang.Object obj28 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class24, class27);
//        java.net.URL uRL29 = org.jfree.chart.util.ObjectUtilities.getResource("1900", class24);
//        java.lang.Object obj30 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("December", class13, class24);
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class24);
//        java.lang.Comparable comparable32 = timeSeries31.getKey();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNotNull(class13);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertNotNull(class16);
//        org.junit.Assert.assertNull(obj17);
//        org.junit.Assert.assertNull(uRL18);
//        org.junit.Assert.assertNull(uRL19);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertNotNull(class24);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertNull(obj28);
//        org.junit.Assert.assertNull(uRL29);
//        org.junit.Assert.assertNull(obj30);
//        org.junit.Assert.assertNotNull(comparable32);
//    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month1.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month1.previous();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(1900);
        long long6 = year5.getLastMillisecond();
        boolean boolean7 = month1.equals((java.lang.Object) year5);
        long long8 = year5.getSerialIndex();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(7, year5);
        long long10 = year5.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-2177424000001L) + "'", long6 == (-2177424000001L));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1900L + "'", long8 == 1900L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-2177424000001L) + "'", long10 == (-2177424000001L));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("March");
    }

//    @Test
//    public void test224() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test224");
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass5 = month4.getClass();
//        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class6);
//        timeSeries7.setDomainDescription("");
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass14 = month13.getClass();
//        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass14);
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class15);
//        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries7.addAndOrUpdate(timeSeries16);
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year19.previous();
//        long long21 = year19.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries17.getDataItem((org.jfree.data.time.RegularTimePeriod) year19);
//        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year24.previous();
//        long long26 = year24.getSerialIndex();
//        java.util.Date date27 = year24.getStart();
//        long long28 = year24.getFirstMillisecond();
//        java.lang.Number number29 = timeSeries17.getValue((org.jfree.data.time.RegularTimePeriod) year24);
//        int int31 = year24.compareTo((java.lang.Object) 2147483647);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean34 = fixedMillisecond32.equals((java.lang.Object) 0.0d);
//        java.util.Calendar calendar35 = null;
//        fixedMillisecond32.peg(calendar35);
//        java.lang.String str37 = fixedMillisecond32.toString();
//        java.util.Date date38 = fixedMillisecond32.getStart();
//        boolean boolean39 = year24.equals((java.lang.Object) fixedMillisecond32);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = year24.next();
//        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month(6, year24);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(class6);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertNotNull(class15);
//        org.junit.Assert.assertNotNull(timeSeries17);
//        org.junit.Assert.assertNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1900L + "'", long21 == 1900L);
//        org.junit.Assert.assertNull(timeSeriesDataItem22);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1900L + "'", long26 == 1900L);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-2208960000000L) + "'", long28 == (-2208960000000L));
//        org.junit.Assert.assertNull(number29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Thu Jun 13 08:40:42 PDT 2019" + "'", str37.equals("Thu Jun 13 08:40:42 PDT 2019"));
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test226() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test226");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.setDomainDescription("");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass13 = month12.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass21 = month20.getClass();
//        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
//        java.util.List list24 = timeSeries23.getItems();
//        boolean boolean25 = timeSeries16.equals((java.lang.Object) list24);
//        boolean boolean27 = timeSeries16.equals((java.lang.Object) false);
//        java.lang.String str28 = timeSeries16.getDescription();
//        timeSeries16.removeAgedItems(true);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        java.lang.Object obj32 = null;
//        boolean boolean33 = day31.equals(obj32);
//        java.lang.String str34 = day31.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = day31.previous();
//        long long36 = day31.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries16.getDataItem((org.jfree.data.time.RegularTimePeriod) day31);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = day31.previous();
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(class22);
//        org.junit.Assert.assertNotNull(list24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNull(str28);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "13-June-2019" + "'", str34.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 43629L + "'", long36 == 43629L);
//        org.junit.Assert.assertNull(timeSeriesDataItem37);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(12, (int) (byte) -1, (-22));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test228() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test228");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond3.next();
//        java.lang.Class<?> wildcardClass5 = fixedMillisecond3.getClass();
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getMiddleMillisecond(calendar6);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond3.getFirstMillisecond(calendar8);
//        int int10 = year1.compareTo((java.lang.Object) fixedMillisecond3);
//        org.junit.Assert.assertNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560440442309L + "'", long7 == 1560440442309L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560440442309L + "'", long9 == 1560440442309L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//    }

//    @Test
//    public void test229() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test229");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.setDomainDescription("");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass13 = month12.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        java.lang.Object obj18 = null;
//        boolean boolean19 = day17.equals(obj18);
//        int int20 = day17.getMonth();
//        java.lang.Number number21 = null;
//        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) day17, number21, true);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = fixedMillisecond24.next();
//        java.lang.Class<?> wildcardClass26 = fixedMillisecond24.getClass();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (double) 1561964399999L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, 0.0d);
//        long long31 = fixedMillisecond24.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem30);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560440442343L + "'", long31 == 1560440442343L);
//    }

//    @Test
//    public void test230() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test230");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getLastMillisecond(calendar2);
//        long long4 = fixedMillisecond0.getSerialIndex();
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass7 = month6.getClass();
//        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass10 = month9.getClass();
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
//        java.lang.Object obj12 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class8, class11);
//        boolean boolean13 = fixedMillisecond0.equals((java.lang.Object) class11);
//        long long14 = fixedMillisecond0.getFirstMillisecond();
//        long long15 = fixedMillisecond0.getSerialIndex();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean19 = spreadsheetDate17.equals((java.lang.Object) 31);
//        int int20 = spreadsheetDate17.getDayOfWeek();
//        int int21 = spreadsheetDate17.getMonth();
//        int int22 = fixedMillisecond0.compareTo((java.lang.Object) spreadsheetDate17);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean26 = spreadsheetDate24.equals((java.lang.Object) 31);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int29 = spreadsheetDate28.toSerial();
//        org.jfree.data.time.SerialDate serialDate30 = spreadsheetDate24.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate28);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean34 = spreadsheetDate32.equals((java.lang.Object) 31);
//        boolean boolean36 = spreadsheetDate17.isInRange(serialDate30, (org.jfree.data.time.SerialDate) spreadsheetDate32, 2147483647);
//        org.jfree.data.time.SerialDate serialDate38 = serialDate30.getNearestDayOfWeek(1);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560440442432L + "'", long3 == 1560440442432L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560440442432L + "'", long4 == 1560440442432L);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(class8);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertNull(obj12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560440442432L + "'", long14 == 1560440442432L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560440442432L + "'", long15 == 1560440442432L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 3 + "'", int20 == 3);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(serialDate38);
//    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass1 = month0.getClass();
        int int2 = month0.getYearValue();
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
    }

//    @Test
//    public void test232() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test232");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean3 = spreadsheetDate1.equals((java.lang.Object) 31);
//        java.util.Date date4 = spreadsheetDate1.toDate();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        int int6 = day5.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate9 = serialDate7.getFollowingDayOfWeek(2);
//        java.lang.String str10 = serialDate9.toString();
//        int int11 = spreadsheetDate1.compare(serialDate9);
//        try {
//            org.jfree.data.time.SerialDate serialDate13 = serialDate9.getFollowingDayOfWeek((-435));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 13 + "'", int6 == 13);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "17-June-2019" + "'", str10.equals("17-June-2019"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-43623) + "'", int11 == (-43623));
//    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass6 = month5.getClass();
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass9 = month8.getClass();
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        java.lang.Object obj11 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class7, class10);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        java.lang.Object obj15 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ThreadContext", class7, (java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440363591L, class7);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass18 = month17.getClass();
        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass18);
        java.lang.Object obj20 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Following", class7, class19);
        java.lang.Class class21 = org.jfree.data.time.RegularTimePeriod.downsize(class7);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440372331L, class7);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNull(obj15);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(class19);
        org.junit.Assert.assertNull(obj20);
        org.junit.Assert.assertNotNull(class21);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Following" + "'", str1.equals("Following"));
    }

//    @Test
//    public void test235() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test235");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.setDomainDescription("");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass13 = month12.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass21 = month20.getClass();
//        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
//        timeSeries23.setDomainDescription("");
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries16.addAndOrUpdate(timeSeries23);
//        java.lang.String str27 = timeSeries26.getDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean30 = fixedMillisecond28.equals((java.lang.Object) 0.0d);
//        java.util.Calendar calendar31 = null;
//        fixedMillisecond28.peg(calendar31);
//        java.lang.String str33 = fixedMillisecond28.toString();
//        long long34 = fixedMillisecond28.getMiddleMillisecond();
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass36 = month35.getClass();
//        boolean boolean38 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month35, (java.lang.Object) 10.0d);
//        long long39 = month35.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries26.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (org.jfree.data.time.RegularTimePeriod) month35);
//        long long41 = fixedMillisecond28.getSerialIndex();
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(class22);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertNull(str27);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Thu Jun 13 08:40:42 PDT 2019" + "'", str33.equals("Thu Jun 13 08:40:42 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560440442957L + "'", long34 == 1560440442957L);
//        org.junit.Assert.assertNotNull(wildcardClass36);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1561964399999L + "'", long39 == 1561964399999L);
//        org.junit.Assert.assertNotNull(timeSeries40);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560440442957L + "'", long41 == 1560440442957L);
//    }

//    @Test
//    public void test236() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test236");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getLastMillisecond(calendar3);
//        boolean boolean6 = fixedMillisecond2.equals((java.lang.Object) 1561964399999L);
//        long long7 = fixedMillisecond2.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (double) 13);
//        java.lang.Object obj10 = timeSeriesDataItem9.clone();
//        int int11 = year1.compareTo((java.lang.Object) timeSeriesDataItem9);
//        java.lang.Object obj12 = timeSeriesDataItem9.clone();
//        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass17 = month16.getClass();
//        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass17);
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class18);
//        timeSeries19.setDomainDescription("");
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass26 = month25.getClass();
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass26);
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class27);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries19.addAndOrUpdate(timeSeries28);
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = fixedMillisecond32.next();
//        java.util.Calendar calendar34 = null;
//        long long35 = fixedMillisecond32.getLastMillisecond(calendar34);
//        long long36 = fixedMillisecond32.getSerialIndex();
//        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass39 = month38.getClass();
//        java.lang.Class class40 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass39);
//        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass42 = month41.getClass();
//        java.lang.Class class43 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass42);
//        java.lang.Object obj44 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class40, class43);
//        boolean boolean45 = fixedMillisecond32.equals((java.lang.Object) class43);
//        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries28.createCopy((org.jfree.data.time.RegularTimePeriod) year31, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond32);
//        java.lang.String str47 = timeSeries46.getDomainDescription();
//        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass52 = month51.getClass();
//        java.lang.Class class53 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass52);
//        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class53);
//        timeSeries54.setDomainDescription("");
//        org.jfree.data.time.Month month60 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass61 = month60.getClass();
//        java.lang.Class class62 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass61);
//        org.jfree.data.time.TimeSeries timeSeries63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class62);
//        org.jfree.data.time.TimeSeries timeSeries64 = timeSeries54.addAndOrUpdate(timeSeries63);
//        java.lang.String str65 = timeSeries64.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries66 = timeSeries46.addAndOrUpdate(timeSeries64);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond67 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = fixedMillisecond67.next();
//        long long69 = regularTimePeriod68.getMiddleMillisecond();
//        boolean boolean70 = timeSeries46.equals((java.lang.Object) regularTimePeriod68);
//        boolean boolean71 = timeSeriesDataItem9.equals((java.lang.Object) timeSeries46);
//        timeSeries46.clear();
//        try {
//            java.lang.Number number74 = timeSeries46.getValue((-457));
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560440443049L + "'", long4 == 1560440443049L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560440443049L + "'", long7 == 1560440443049L);
//        org.junit.Assert.assertNotNull(obj10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(obj12);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(class18);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560440443059L + "'", long35 == 1560440443059L);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560440443059L + "'", long36 == 1560440443059L);
//        org.junit.Assert.assertNotNull(wildcardClass39);
//        org.junit.Assert.assertNotNull(class40);
//        org.junit.Assert.assertNotNull(wildcardClass42);
//        org.junit.Assert.assertNotNull(class43);
//        org.junit.Assert.assertNull(obj44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertNotNull(timeSeries46);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "hi!" + "'", str47.equals("hi!"));
//        org.junit.Assert.assertNotNull(wildcardClass52);
//        org.junit.Assert.assertNotNull(class53);
//        org.junit.Assert.assertNotNull(wildcardClass61);
//        org.junit.Assert.assertNotNull(class62);
//        org.junit.Assert.assertNotNull(timeSeries64);
//        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "Time" + "'", str65.equals("Time"));
//        org.junit.Assert.assertNotNull(timeSeries66);
//        org.junit.Assert.assertNotNull(regularTimePeriod68);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 1560440443065L + "'", long69 == 1560440443065L);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
//    }

//    @Test
//    public void test237() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test237");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean3 = spreadsheetDate1.equals((java.lang.Object) 31);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        int int5 = day4.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate6 = day4.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate8 = serialDate6.getFollowingDayOfWeek(2);
//        java.lang.String str9 = serialDate8.toString();
//        boolean boolean10 = spreadsheetDate1.isOnOrAfter(serialDate8);
//        int int11 = spreadsheetDate1.getYYYY();
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "17-June-2019" + "'", str9.equals("17-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1900 + "'", int11 == 1900);
//    }

//    @Test
//    public void test238() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test238");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
//        int int2 = spreadsheetDate1.getDayOfMonth();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        int int6 = day5.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate9 = serialDate7.getFollowingDayOfWeek(2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean13 = spreadsheetDate11.equals((java.lang.Object) 31);
//        java.util.Date date14 = spreadsheetDate11.toDate();
//        boolean boolean16 = spreadsheetDate11.equals((java.lang.Object) 1560440366809L);
//        int int17 = spreadsheetDate11.getYYYY();
//        org.jfree.data.time.SerialDate serialDate18 = serialDate7.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate11);
//        org.jfree.data.time.SerialDate serialDate20 = serialDate7.getFollowingDayOfWeek(4);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int23 = spreadsheetDate22.toSerial();
//        int int24 = spreadsheetDate22.getDayOfWeek();
//        org.jfree.data.time.SerialDate serialDate25 = serialDate7.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate22);
//        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addDays((int) (short) 1, (org.jfree.data.time.SerialDate) spreadsheetDate22);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        int int28 = day27.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate29 = day27.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate31 = serialDate29.getFollowingDayOfWeek(2);
//        java.lang.String str32 = serialDate31.toString();
//        org.jfree.data.time.SerialDate serialDate34 = serialDate31.getNearestDayOfWeek((int) (byte) 1);
//        org.jfree.data.time.SerialDate serialDate36 = serialDate31.getNearestDayOfWeek((int) (short) 1);
//        org.jfree.data.time.SerialDate serialDate37 = spreadsheetDate22.getEndOfCurrentMonth(serialDate31);
//        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.addMonths(13, serialDate37);
//        int int39 = spreadsheetDate1.compare(serialDate38);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 13 + "'", int6 == 13);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1900 + "'", int17 == 1900);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 10 + "'", int23 == 10);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 3 + "'", int24 == 3);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 13 + "'", int28 == 13);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "17-June-2019" + "'", str32.equals("17-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-44007) + "'", int39 == (-44007));
//    }

//    @Test
//    public void test239() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test239");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1);
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
//        long long6 = year4.getSerialIndex();
//        java.util.Date date7 = year4.getStart();
//        long long8 = year4.getFirstMillisecond();
//        int int9 = year4.getYear();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        java.lang.Object obj11 = null;
//        boolean boolean12 = day10.equals(obj11);
//        java.lang.String str13 = day10.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day10.previous();
//        int int15 = year4.compareTo((java.lang.Object) day10);
//        int int16 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) day10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = fixedMillisecond17.next();
//        java.util.Calendar calendar19 = null;
//        long long20 = fixedMillisecond17.getLastMillisecond(calendar19);
//        long long21 = fixedMillisecond17.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass22 = fixedMillisecond17.getClass();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, 0.0d);
//        org.junit.Assert.assertNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1900L + "'", long6 == 1900L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-2208960000000L) + "'", long8 == (-2208960000000L));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1900 + "'", int9 == 1900);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "13-June-2019" + "'", str13.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560440443353L + "'", long20 == 1560440443353L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560440443353L + "'", long21 == 1560440443353L);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertNull(timeSeriesDataItem24);
//    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass21 = month20.getClass();
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
        timeSeries23.setDomainDescription("");
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries16.addAndOrUpdate(timeSeries23);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener27 = null;
        timeSeries16.removeChangeListener(seriesChangeListener27);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = fixedMillisecond29.next();
        java.lang.Class<?> wildcardClass31 = fixedMillisecond29.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, (double) 1561964399999L);
        java.lang.Number number34 = timeSeries16.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass39 = month38.getClass();
        java.lang.Class class40 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass39);
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class40);
        timeSeries41.setDomainDescription("");
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass48 = month47.getClass();
        java.lang.Class class49 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass48);
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class49);
        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries41.addAndOrUpdate(timeSeries50);
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day();
        java.lang.Object obj53 = null;
        boolean boolean54 = day52.equals(obj53);
        int int55 = day52.getMonth();
        java.lang.Number number56 = null;
        timeSeries41.add((org.jfree.data.time.RegularTimePeriod) day52, number56, true);
        org.jfree.data.time.FixedMillisecond fixedMillisecond59 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = fixedMillisecond59.next();
        java.lang.Class<?> wildcardClass61 = fixedMillisecond59.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond59, (double) 1561964399999L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem65 = timeSeries41.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond59, 0.0d);
        java.lang.Object obj66 = timeSeriesDataItem65.clone();
        timeSeries16.add(timeSeriesDataItem65);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertNull(number34);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertNotNull(class40);
        org.junit.Assert.assertNotNull(wildcardClass48);
        org.junit.Assert.assertNotNull(class49);
        org.junit.Assert.assertNotNull(timeSeries51);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 6 + "'", int55 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod60);
        org.junit.Assert.assertNotNull(wildcardClass61);
        org.junit.Assert.assertNotNull(timeSeriesDataItem65);
        org.junit.Assert.assertNotNull(obj66);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(12, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

//    @Test
//    public void test242() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test242");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.clear();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass12 = month11.getClass();
//        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class13);
//        timeSeries14.setDomainDescription("");
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass21 = month20.getClass();
//        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries14.addAndOrUpdate(timeSeries23);
//        java.lang.String str25 = timeSeries23.getRangeDescription();
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries6.addAndOrUpdate(timeSeries23);
//        timeSeries23.setDescription("Following");
//        java.util.List list29 = timeSeries23.getItems();
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        int int31 = day30.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate32 = day30.getSerialDate();
//        int int33 = day30.getMonth();
//        long long34 = day30.getFirstMillisecond();
//        boolean boolean36 = day30.equals((java.lang.Object) (-1));
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) day30, (double) 10, true);
//        org.jfree.data.time.SerialDate serialDate40 = day30.getSerialDate();
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNotNull(class13);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(class22);
//        org.junit.Assert.assertNotNull(timeSeries24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "ThreadContext" + "'", str25.equals("ThreadContext"));
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertNotNull(list29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 13 + "'", int31 == 13);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 6 + "'", int33 == 6);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560409200000L + "'", long34 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(serialDate40);
//    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(3, 100, (-43619));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test244() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test244");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        int int3 = day0.getMonth();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        java.util.Calendar calendar5 = null;
//        try {
//            day0.peg(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(serialDate4);
//    }

//    @Test
//    public void test245() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test245");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.setDomainDescription("");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass13 = month12.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass21 = month20.getClass();
//        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
//        java.util.List list24 = timeSeries23.getItems();
//        boolean boolean25 = timeSeries16.equals((java.lang.Object) list24);
//        timeSeries16.removeAgedItems(false);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        int int29 = day28.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day28.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries16.getDataItem(regularTimePeriod30);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = fixedMillisecond32.next();
//        java.util.Calendar calendar34 = null;
//        long long35 = fixedMillisecond32.getLastMillisecond(calendar34);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (double) (short) -1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = fixedMillisecond32.next();
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(class22);
//        org.junit.Assert.assertNotNull(list24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 13 + "'", int29 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNull(timeSeriesDataItem31);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560440444924L + "'", long35 == 1560440444924L);
//        org.junit.Assert.assertNull(timeSeriesDataItem37);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 1);
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1);
        int int3 = timeSeries2.getMaximumItemCount();
        java.lang.String str4 = timeSeries2.getRangeDescription();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass9 = month8.getClass();
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class10);
        timeSeries11.setDomainDescription("");
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass18 = month17.getClass();
        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass18);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class19);
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries11.addAndOrUpdate(timeSeries20);
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries2.addAndOrUpdate(timeSeries20);
        java.lang.Class<?> wildcardClass23 = timeSeries2.getClass();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Value" + "'", str4.equals("Value"));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(class19);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertNotNull(timeSeries22);
        org.junit.Assert.assertNotNull(wildcardClass23);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((-435));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-565) + "'", int1 == (-565));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
        java.lang.String str2 = year1.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year1.next();
        long long4 = year1.getSerialIndex();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1900" + "'", str2.equals("1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1900L + "'", long4 == 1900L);
    }

//    @Test
//    public void test249() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test249");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        java.util.List list7 = timeSeries6.getItems();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean10 = fixedMillisecond8.equals((java.lang.Object) 0.0d);
//        java.util.Calendar calendar11 = null;
//        fixedMillisecond8.peg(calendar11);
//        java.lang.String str13 = fixedMillisecond8.toString();
//        long long14 = fixedMillisecond8.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (double) 31);
//        timeSeries6.setMaximumItemAge(0L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(list7);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Thu Jun 13 08:40:45 PDT 2019" + "'", str13.equals("Thu Jun 13 08:40:45 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560440445207L + "'", long14 == 1560440445207L);
//        org.junit.Assert.assertNull(timeSeriesDataItem16);
//    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.lang.Object obj1 = null;
        boolean boolean2 = day0.equals(obj1);
        int int3 = day0.getMonth();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = day0.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(10);
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) ' ', serialDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(1900);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(100);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        long long3 = year1.getSerialIndex();
        java.util.Date date4 = year1.getStart();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4, timeZone5);
        java.util.TimeZone timeZone7 = null;
        try {
            org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date4, timeZone7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1900L + "'", long3 == 1900L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone5);
    }

//    @Test
//    public void test255() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test255");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.setDomainDescription("");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass13 = month12.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond19.next();
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond19.getLastMillisecond(calendar21);
//        long long23 = fixedMillisecond19.getSerialIndex();
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass26 = month25.getClass();
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass26);
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass29 = month28.getClass();
//        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
//        java.lang.Object obj31 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class27, class30);
//        boolean boolean32 = fixedMillisecond19.equals((java.lang.Object) class30);
//        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) year18, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
//        java.lang.String str34 = timeSeries33.getDomainDescription();
//        timeSeries33.removeAgedItems(1560440369753L, false);
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries33.getDataItem((int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560440445293L + "'", long22 == 1560440445293L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560440445293L + "'", long23 == 1560440445293L);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertNull(obj31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(timeSeries33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
//    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
    }

//    @Test
//    public void test257() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test257");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
//        long long3 = year1.getSerialIndex();
//        java.util.Date date4 = year1.getStart();
//        long long5 = year1.getFirstMillisecond();
//        int int6 = year1.getYear();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        java.lang.Object obj8 = null;
//        boolean boolean9 = day7.equals(obj8);
//        java.lang.String str10 = day7.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day7.previous();
//        int int12 = year1.compareTo((java.lang.Object) day7);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        int int14 = day13.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate15 = day13.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate17 = serialDate15.getFollowingDayOfWeek(2);
//        java.lang.String str18 = serialDate17.toString();
//        org.jfree.data.time.SerialDate serialDate20 = serialDate17.getNearestDayOfWeek((int) (byte) 1);
//        boolean boolean21 = year1.equals((java.lang.Object) serialDate20);
//        try {
//            org.jfree.data.time.SerialDate serialDate23 = serialDate20.getPreviousDayOfWeek((int) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1900L + "'", long3 == 1900L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-2208960000000L) + "'", long5 == (-2208960000000L));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1900 + "'", int6 == 1900);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "13-June-2019" + "'", str10.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 13 + "'", int14 == 13);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "17-June-2019" + "'", str18.equals("17-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//    }

//    @Test
//    public void test258() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test258");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getLastMillisecond(calendar3);
//        boolean boolean6 = fixedMillisecond2.equals((java.lang.Object) 1561964399999L);
//        long long7 = fixedMillisecond2.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (double) 13);
//        java.lang.Object obj10 = timeSeriesDataItem9.clone();
//        int int11 = year1.compareTo((java.lang.Object) timeSeriesDataItem9);
//        java.lang.Object obj12 = timeSeriesDataItem9.clone();
//        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass17 = month16.getClass();
//        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass17);
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class18);
//        timeSeries19.setDomainDescription("");
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass26 = month25.getClass();
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass26);
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class27);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries19.addAndOrUpdate(timeSeries28);
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = fixedMillisecond32.next();
//        java.util.Calendar calendar34 = null;
//        long long35 = fixedMillisecond32.getLastMillisecond(calendar34);
//        long long36 = fixedMillisecond32.getSerialIndex();
//        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass39 = month38.getClass();
//        java.lang.Class class40 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass39);
//        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass42 = month41.getClass();
//        java.lang.Class class43 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass42);
//        java.lang.Object obj44 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class40, class43);
//        boolean boolean45 = fixedMillisecond32.equals((java.lang.Object) class43);
//        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries28.createCopy((org.jfree.data.time.RegularTimePeriod) year31, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond32);
//        java.lang.String str47 = timeSeries46.getDomainDescription();
//        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass52 = month51.getClass();
//        java.lang.Class class53 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass52);
//        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class53);
//        timeSeries54.setDomainDescription("");
//        org.jfree.data.time.Month month60 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass61 = month60.getClass();
//        java.lang.Class class62 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass61);
//        org.jfree.data.time.TimeSeries timeSeries63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class62);
//        org.jfree.data.time.TimeSeries timeSeries64 = timeSeries54.addAndOrUpdate(timeSeries63);
//        java.lang.String str65 = timeSeries64.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries66 = timeSeries46.addAndOrUpdate(timeSeries64);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond67 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = fixedMillisecond67.next();
//        long long69 = regularTimePeriod68.getMiddleMillisecond();
//        boolean boolean70 = timeSeries46.equals((java.lang.Object) regularTimePeriod68);
//        boolean boolean71 = timeSeriesDataItem9.equals((java.lang.Object) timeSeries46);
//        long long72 = timeSeries46.getMaximumItemAge();
//        boolean boolean73 = timeSeries46.getNotify();
//        java.lang.String str74 = timeSeries46.getDescription();
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560440445350L + "'", long4 == 1560440445350L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560440445350L + "'", long7 == 1560440445350L);
//        org.junit.Assert.assertNotNull(obj10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(obj12);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(class18);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560440445361L + "'", long35 == 1560440445361L);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560440445361L + "'", long36 == 1560440445361L);
//        org.junit.Assert.assertNotNull(wildcardClass39);
//        org.junit.Assert.assertNotNull(class40);
//        org.junit.Assert.assertNotNull(wildcardClass42);
//        org.junit.Assert.assertNotNull(class43);
//        org.junit.Assert.assertNull(obj44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertNotNull(timeSeries46);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "hi!" + "'", str47.equals("hi!"));
//        org.junit.Assert.assertNotNull(wildcardClass52);
//        org.junit.Assert.assertNotNull(class53);
//        org.junit.Assert.assertNotNull(wildcardClass61);
//        org.junit.Assert.assertNotNull(class62);
//        org.junit.Assert.assertNotNull(timeSeries64);
//        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "Time" + "'", str65.equals("Time"));
//        org.junit.Assert.assertNotNull(timeSeries66);
//        org.junit.Assert.assertNotNull(regularTimePeriod68);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 1560440445367L + "'", long69 == 1560440445367L);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 9223372036854775807L + "'", long72 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
//        org.junit.Assert.assertNull(str74);
//    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (java.lang.Number) 10.0f);
        boolean boolean5 = year1.equals((java.lang.Object) 1560440409748L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year1.previous();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(regularTimePeriod6);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass11 = month10.getClass();
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class12);
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener14);
        java.lang.String str16 = timeSeries13.getDescription();
        java.util.Collection collection17 = timeSeries6.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        java.util.Collection collection18 = org.jfree.chart.util.ObjectUtilities.deepClone(collection17);
        java.util.Collection collection19 = org.jfree.chart.util.ObjectUtilities.deepClone(collection18);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertNotNull(collection19);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(2019);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d));
        timeSeries1.setMaximumItemAge(0L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.addChangeListener(seriesChangeListener4);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass21 = month20.getClass();
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
        java.util.List list24 = timeSeries23.getItems();
        boolean boolean25 = timeSeries16.equals((java.lang.Object) list24);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond26.next();
        java.lang.Class<?> wildcardClass28 = fixedMillisecond26.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, (double) 1561964399999L);
        java.util.Date date31 = fixedMillisecond26.getStart();
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date31);
        timeSeries16.delete((org.jfree.data.time.RegularTimePeriod) day32);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertNotNull(list24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNotNull(date31);
    }

//    @Test
//    public void test264() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test264");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1);
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass7 = month6.getClass();
//        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class8);
//        timeSeries9.setDomainDescription("");
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass16 = month15.getClass();
//        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass16);
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class17);
//        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries9.addAndOrUpdate(timeSeries18);
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond22.next();
//        java.util.Calendar calendar24 = null;
//        long long25 = fixedMillisecond22.getLastMillisecond(calendar24);
//        long long26 = fixedMillisecond22.getSerialIndex();
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass29 = month28.getClass();
//        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
//        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass32 = month31.getClass();
//        java.lang.Class class33 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass32);
//        java.lang.Object obj34 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class30, class33);
//        boolean boolean35 = fixedMillisecond22.equals((java.lang.Object) class33);
//        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries18.createCopy((org.jfree.data.time.RegularTimePeriod) year21, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
//        java.lang.String str37 = timeSeries36.getDomainDescription();
//        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass42 = month41.getClass();
//        java.lang.Class class43 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass42);
//        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class43);
//        timeSeries44.setDomainDescription("");
//        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass51 = month50.getClass();
//        java.lang.Class class52 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass51);
//        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class52);
//        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries44.addAndOrUpdate(timeSeries53);
//        java.lang.String str55 = timeSeries54.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries56 = timeSeries36.addAndOrUpdate(timeSeries54);
//        org.jfree.data.time.TimeSeries timeSeries57 = timeSeries2.addAndOrUpdate(timeSeries36);
//        java.lang.Number number59 = null;
//        try {
//            timeSeries36.update(3, number59);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(class8);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNotNull(class17);
//        org.junit.Assert.assertNotNull(timeSeries19);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560440446026L + "'", long25 == 1560440446026L);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560440446026L + "'", long26 == 1560440446026L);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertNotNull(wildcardClass32);
//        org.junit.Assert.assertNotNull(class33);
//        org.junit.Assert.assertNull(obj34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(timeSeries36);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "hi!" + "'", str37.equals("hi!"));
//        org.junit.Assert.assertNotNull(wildcardClass42);
//        org.junit.Assert.assertNotNull(class43);
//        org.junit.Assert.assertNotNull(wildcardClass51);
//        org.junit.Assert.assertNotNull(class52);
//        org.junit.Assert.assertNotNull(timeSeries54);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "Time" + "'", str55.equals("Time"));
//        org.junit.Assert.assertNotNull(timeSeries56);
//        org.junit.Assert.assertNotNull(timeSeries57);
//    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        long long3 = year1.getSerialIndex();
        java.util.Date date4 = year1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.junit.Assert.assertNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1900L + "'", long3 == 1900L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate7);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass21 = month20.getClass();
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
        java.util.List list24 = timeSeries23.getItems();
        boolean boolean25 = timeSeries16.equals((java.lang.Object) list24);
        boolean boolean27 = timeSeries16.equals((java.lang.Object) false);
        boolean boolean28 = timeSeries16.getNotify();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertNotNull(list24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d);
        java.util.Collection collection19 = timeSeries6.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        java.util.Collection collection20 = org.jfree.chart.util.ObjectUtilities.deepClone(collection19);
        java.util.Collection collection21 = org.jfree.chart.util.ObjectUtilities.deepClone(collection20);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertNotNull(collection21);
    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test268");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        int int4 = day3.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate7 = serialDate5.getFollowingDayOfWeek(2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean11 = spreadsheetDate9.equals((java.lang.Object) 31);
//        java.util.Date date12 = spreadsheetDate9.toDate();
//        boolean boolean14 = spreadsheetDate9.equals((java.lang.Object) 1560440366809L);
//        int int15 = spreadsheetDate9.getYYYY();
//        org.jfree.data.time.SerialDate serialDate16 = serialDate5.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate9);
//        org.jfree.data.time.SerialDate serialDate18 = serialDate5.getFollowingDayOfWeek(4);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int21 = spreadsheetDate20.toSerial();
//        int int22 = spreadsheetDate20.getDayOfWeek();
//        org.jfree.data.time.SerialDate serialDate23 = serialDate5.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate20);
//        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addDays((int) (short) 1, (org.jfree.data.time.SerialDate) spreadsheetDate20);
//        boolean boolean25 = spreadsheetDate1.isOn(serialDate24);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        int int28 = day27.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate29 = day27.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate31 = serialDate29.getFollowingDayOfWeek(2);
//        java.lang.String str32 = serialDate31.toString();
//        org.jfree.data.time.SerialDate serialDate34 = serialDate31.getNearestDayOfWeek((int) (byte) 1);
//        org.jfree.data.time.SerialDate serialDate36 = serialDate31.getNearestDayOfWeek((int) (short) 1);
//        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.addYears(7, serialDate36);
//        boolean boolean38 = spreadsheetDate1.isAfter(serialDate37);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1900 + "'", int15 == 1900);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 3 + "'", int22 == 3);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 13 + "'", int28 == 13);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "17-June-2019" + "'", str32.equals("17-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//    }

//    @Test
//    public void test269() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test269");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        fixedMillisecond0.peg(calendar1);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getMiddleMillisecond(calendar3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560440446442L + "'", long4 == 1560440446442L);
//    }

//    @Test
//    public void test270() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test270");
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        int int2 = day1.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate3 = day1.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate5 = serialDate3.getFollowingDayOfWeek(2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean9 = spreadsheetDate7.equals((java.lang.Object) 31);
//        java.util.Date date10 = spreadsheetDate7.toDate();
//        boolean boolean12 = spreadsheetDate7.equals((java.lang.Object) 1560440366809L);
//        int int13 = spreadsheetDate7.getYYYY();
//        org.jfree.data.time.SerialDate serialDate14 = serialDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate7);
//        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addYears((-1), serialDate3);
//        java.lang.String str16 = serialDate3.getDescription();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1900 + "'", int13 == 1900);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNull(str16);
//    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560440430804L);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        timeSeries6.fireSeriesChanged();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        int int20 = month18.compareTo((java.lang.Object) 1L);
        long long21 = month18.getLastMillisecond();
        int int23 = month18.compareTo((java.lang.Object) 'a');
        int int24 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month18);
        timeSeries6.setDomainDescription("March");
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month27, (java.lang.Number) 1560440365729L);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1561964399999L + "'", long21 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem29);
    }

//    @Test
//    public void test273() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test273");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.setDomainDescription("");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass13 = month12.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass21 = month20.getClass();
//        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
//        timeSeries23.setDomainDescription("");
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries16.addAndOrUpdate(timeSeries23);
//        java.lang.String str27 = timeSeries26.getDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean30 = fixedMillisecond28.equals((java.lang.Object) 0.0d);
//        java.util.Calendar calendar31 = null;
//        fixedMillisecond28.peg(calendar31);
//        java.lang.String str33 = fixedMillisecond28.toString();
//        long long34 = fixedMillisecond28.getMiddleMillisecond();
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass36 = month35.getClass();
//        boolean boolean38 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month35, (java.lang.Object) 10.0d);
//        long long39 = month35.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries26.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (org.jfree.data.time.RegularTimePeriod) month35);
//        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass45 = month44.getClass();
//        java.lang.Class class46 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass45);
//        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class46);
//        timeSeries47.setDomainDescription("");
//        org.jfree.data.time.Month month53 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass54 = month53.getClass();
//        java.lang.Class class55 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass54);
//        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class55);
//        org.jfree.data.time.TimeSeries timeSeries57 = timeSeries47.addAndOrUpdate(timeSeries56);
//        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day();
//        java.lang.Object obj59 = null;
//        boolean boolean60 = day58.equals(obj59);
//        int int61 = day58.getMonth();
//        java.lang.Number number62 = null;
//        timeSeries47.add((org.jfree.data.time.RegularTimePeriod) day58, number62, true);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond65 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = fixedMillisecond65.next();
//        java.lang.Class<?> wildcardClass67 = fixedMillisecond65.getClass();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem69 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond65, (double) 1561964399999L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem71 = timeSeries47.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond65, 0.0d);
//        long long72 = fixedMillisecond65.getFirstMillisecond();
//        java.lang.Number number73 = timeSeries40.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond65);
//        timeSeries40.removeAgedItems(false);
//        timeSeries40.removeAgedItems(0L, false);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(class22);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertNull(str27);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Thu Jun 13 08:40:46 PDT 2019" + "'", str33.equals("Thu Jun 13 08:40:46 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560440446592L + "'", long34 == 1560440446592L);
//        org.junit.Assert.assertNotNull(wildcardClass36);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1561964399999L + "'", long39 == 1561964399999L);
//        org.junit.Assert.assertNotNull(timeSeries40);
//        org.junit.Assert.assertNotNull(wildcardClass45);
//        org.junit.Assert.assertNotNull(class46);
//        org.junit.Assert.assertNotNull(wildcardClass54);
//        org.junit.Assert.assertNotNull(class55);
//        org.junit.Assert.assertNotNull(timeSeries57);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 6 + "'", int61 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod66);
//        org.junit.Assert.assertNotNull(wildcardClass67);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem71);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 1560440446601L + "'", long72 == 1560440446601L);
//        org.junit.Assert.assertNull(number73);
//    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.previous();
        int int5 = month0.compareTo((java.lang.Object) month2);
        java.lang.Class<?> wildcardClass6 = month0.getClass();
        int int7 = month0.getMonth();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
    }

//    @Test
//    public void test275() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test275");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.clear();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries6.removeChangeListener(seriesChangeListener8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond10.next();
//        java.util.Calendar calendar12 = null;
//        long long13 = fixedMillisecond10.getLastMillisecond(calendar12);
//        long long14 = fixedMillisecond10.getSerialIndex();
//        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass17 = month16.getClass();
//        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass17);
//        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass20 = month19.getClass();
//        java.lang.Class class21 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass20);
//        java.lang.Object obj22 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class18, class21);
//        boolean boolean23 = fixedMillisecond10.equals((java.lang.Object) class21);
//        long long24 = fixedMillisecond10.getSerialIndex();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar26 = null;
//        long long27 = fixedMillisecond25.getLastMillisecond(calendar26);
//        boolean boolean29 = fixedMillisecond25.equals((java.lang.Object) 1561964399999L);
//        long long30 = fixedMillisecond25.getSerialIndex();
//        long long31 = fixedMillisecond25.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560440446909L + "'", long13 == 1560440446909L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560440446909L + "'", long14 == 1560440446909L);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(class18);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertNotNull(class21);
//        org.junit.Assert.assertNull(obj22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560440446909L + "'", long24 == 1560440446909L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560440446912L + "'", long27 == 1560440446912L);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560440446912L + "'", long30 == 1560440446912L);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560440446912L + "'", long31 == 1560440446912L);
//        org.junit.Assert.assertNotNull(timeSeries32);
//    }

//    @Test
//    public void test276() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test276");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.setDomainDescription("");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass13 = month12.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond19.next();
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond19.getLastMillisecond(calendar21);
//        long long23 = fixedMillisecond19.getSerialIndex();
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass26 = month25.getClass();
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass26);
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass29 = month28.getClass();
//        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
//        java.lang.Object obj31 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class27, class30);
//        boolean boolean32 = fixedMillisecond19.equals((java.lang.Object) class30);
//        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) year18, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
//        java.lang.String str34 = timeSeries33.getDomainDescription();
//        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass39 = month38.getClass();
//        java.lang.Class class40 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass39);
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class40);
//        timeSeries41.setDomainDescription("");
//        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass48 = month47.getClass();
//        java.lang.Class class49 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass48);
//        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class49);
//        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries41.addAndOrUpdate(timeSeries50);
//        java.lang.String str52 = timeSeries51.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries33.addAndOrUpdate(timeSeries51);
//        int int54 = timeSeries51.getMaximumItemCount();
//        int int55 = timeSeries51.getItemCount();
//        timeSeries51.fireSeriesChanged();
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560440446995L + "'", long22 == 1560440446995L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560440446995L + "'", long23 == 1560440446995L);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertNull(obj31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(timeSeries33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
//        org.junit.Assert.assertNotNull(wildcardClass39);
//        org.junit.Assert.assertNotNull(class40);
//        org.junit.Assert.assertNotNull(wildcardClass48);
//        org.junit.Assert.assertNotNull(class49);
//        org.junit.Assert.assertNotNull(timeSeries51);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "Time" + "'", str52.equals("Time"));
//        org.junit.Assert.assertNotNull(timeSeries53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 2147483647 + "'", int54 == 2147483647);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
//    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass5 = month4.getClass();
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
        java.lang.Object obj10 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class6, class9);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass12 = month11.getClass();
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
        java.lang.Object obj14 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ThreadContext", class6, (java.lang.Class) wildcardClass12);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440363591L, class6);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass17 = month16.getClass();
        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass17);
        java.lang.Object obj19 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Following", class6, class18);
        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize(class6);
        java.lang.ClassLoader classLoader21 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class20);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertNull(obj10);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNull(obj14);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(class18);
        org.junit.Assert.assertNull(obj19);
        org.junit.Assert.assertNotNull(class20);
        org.junit.Assert.assertNotNull(classLoader21);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean3 = spreadsheetDate1.equals((java.lang.Object) 31);
        int int4 = spreadsheetDate1.getDayOfWeek();
        java.util.Date date5 = spreadsheetDate1.toDate();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date5);
        java.util.Calendar calendar7 = null;
        fixedMillisecond6.peg(calendar7);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass21 = month20.getClass();
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
        timeSeries23.setDomainDescription("");
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries16.addAndOrUpdate(timeSeries23);
        int int27 = timeSeries23.getItemCount();
        try {
            timeSeries23.update((int) (short) -1, (java.lang.Number) 1560440378244L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        long long3 = year1.getSerialIndex();
        java.util.Date date4 = year1.getStart();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        java.lang.String str6 = day5.toString();
        java.util.Calendar calendar7 = null;
        try {
            day5.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1900L + "'", long3 == 1900L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1-January-1900" + "'", str6.equals("1-January-1900"));
    }

//    @Test
//    public void test281() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test281");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1);
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass7 = month6.getClass();
//        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class8);
//        timeSeries9.setDomainDescription("");
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass16 = month15.getClass();
//        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass16);
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class17);
//        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries9.addAndOrUpdate(timeSeries18);
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond22.next();
//        java.util.Calendar calendar24 = null;
//        long long25 = fixedMillisecond22.getLastMillisecond(calendar24);
//        long long26 = fixedMillisecond22.getSerialIndex();
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass29 = month28.getClass();
//        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
//        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass32 = month31.getClass();
//        java.lang.Class class33 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass32);
//        java.lang.Object obj34 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class30, class33);
//        boolean boolean35 = fixedMillisecond22.equals((java.lang.Object) class33);
//        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries18.createCopy((org.jfree.data.time.RegularTimePeriod) year21, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
//        java.lang.String str37 = timeSeries36.getDomainDescription();
//        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass42 = month41.getClass();
//        java.lang.Class class43 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass42);
//        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class43);
//        timeSeries44.setDomainDescription("");
//        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass51 = month50.getClass();
//        java.lang.Class class52 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass51);
//        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class52);
//        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries44.addAndOrUpdate(timeSeries53);
//        java.lang.String str55 = timeSeries54.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries56 = timeSeries36.addAndOrUpdate(timeSeries54);
//        org.jfree.data.time.TimeSeries timeSeries57 = timeSeries2.addAndOrUpdate(timeSeries36);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond58 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = fixedMillisecond58.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem61 = timeSeries57.addOrUpdate(regularTimePeriod59, (double) 1560440360327L);
//        timeSeries57.setDomainDescription("hi!");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = timeSeries57.getTimePeriod((int) (byte) 0);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(class8);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNotNull(class17);
//        org.junit.Assert.assertNotNull(timeSeries19);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560440447685L + "'", long25 == 1560440447685L);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560440447685L + "'", long26 == 1560440447685L);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertNotNull(wildcardClass32);
//        org.junit.Assert.assertNotNull(class33);
//        org.junit.Assert.assertNull(obj34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(timeSeries36);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "hi!" + "'", str37.equals("hi!"));
//        org.junit.Assert.assertNotNull(wildcardClass42);
//        org.junit.Assert.assertNotNull(class43);
//        org.junit.Assert.assertNotNull(wildcardClass51);
//        org.junit.Assert.assertNotNull(class52);
//        org.junit.Assert.assertNotNull(timeSeries54);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "Time" + "'", str55.equals("Time"));
//        org.junit.Assert.assertNotNull(timeSeries56);
//        org.junit.Assert.assertNotNull(timeSeries57);
//        org.junit.Assert.assertNotNull(regularTimePeriod59);
//        org.junit.Assert.assertNull(timeSeriesDataItem61);
//        org.junit.Assert.assertNotNull(regularTimePeriod65);
//    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        int int2 = spreadsheetDate1.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(4);
        boolean boolean5 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

//    @Test
//    public void test283() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test283");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getLastMillisecond(calendar1);
//        boolean boolean4 = fixedMillisecond0.equals((java.lang.Object) 1561964399999L);
//        long long5 = fixedMillisecond0.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) 13);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond0.getMiddleMillisecond(calendar8);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond0.previous();
//        java.util.Date date11 = fixedMillisecond0.getTime();
//        long long12 = fixedMillisecond0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440448142L + "'", long2 == 1560440448142L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560440448142L + "'", long5 == 1560440448142L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560440448142L + "'", long9 == 1560440448142L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560440448142L + "'", long12 == 1560440448142L);
//    }

//    @Test
//    public void test284() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test284");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.setDomainDescription("");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass13 = month12.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond19.next();
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond19.getLastMillisecond(calendar21);
//        long long23 = fixedMillisecond19.getSerialIndex();
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass26 = month25.getClass();
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass26);
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass29 = month28.getClass();
//        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
//        java.lang.Object obj31 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class27, class30);
//        boolean boolean32 = fixedMillisecond19.equals((java.lang.Object) class30);
//        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) year18, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
//        java.lang.String str34 = timeSeries33.getDomainDescription();
//        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass39 = month38.getClass();
//        java.lang.Class class40 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass39);
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class40);
//        timeSeries41.setDomainDescription("");
//        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass48 = month47.getClass();
//        java.lang.Class class49 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass48);
//        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class49);
//        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries41.addAndOrUpdate(timeSeries50);
//        java.lang.String str52 = timeSeries51.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries33.addAndOrUpdate(timeSeries51);
//        int int54 = timeSeries51.getMaximumItemCount();
//        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = year56.previous();
//        long long58 = year56.getSerialIndex();
//        java.util.Date date59 = year56.getStart();
//        org.jfree.data.time.Month month60 = new org.jfree.data.time.Month(date59);
//        org.jfree.data.time.Month month61 = new org.jfree.data.time.Month(date59);
//        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = year63.previous();
//        long long65 = year63.getSerialIndex();
//        java.util.Date date66 = year63.getStart();
//        java.util.TimeZone timeZone67 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day68 = new org.jfree.data.time.Day(date66, timeZone67);
//        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day(date59, timeZone67);
//        int int70 = day69.getDayOfMonth();
//        timeSeries51.setKey((java.lang.Comparable) day69);
//        long long72 = timeSeries51.getMaximumItemAge();
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560440448234L + "'", long22 == 1560440448234L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560440448234L + "'", long23 == 1560440448234L);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertNull(obj31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(timeSeries33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
//        org.junit.Assert.assertNotNull(wildcardClass39);
//        org.junit.Assert.assertNotNull(class40);
//        org.junit.Assert.assertNotNull(wildcardClass48);
//        org.junit.Assert.assertNotNull(class49);
//        org.junit.Assert.assertNotNull(timeSeries51);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "Time" + "'", str52.equals("Time"));
//        org.junit.Assert.assertNotNull(timeSeries53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 2147483647 + "'", int54 == 2147483647);
//        org.junit.Assert.assertNull(regularTimePeriod57);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1900L + "'", long58 == 1900L);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertNull(regularTimePeriod64);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1900L + "'", long65 == 1900L);
//        org.junit.Assert.assertNotNull(date66);
//        org.junit.Assert.assertNotNull(timeZone67);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 1 + "'", int70 == 1);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 9223372036854775807L + "'", long72 == 9223372036854775807L);
//    }

//    @Test
//    public void test285() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test285");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.setDomainDescription("");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass13 = month12.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass21 = month20.getClass();
//        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
//        timeSeries23.setDomainDescription("");
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries16.addAndOrUpdate(timeSeries23);
//        java.lang.String str27 = timeSeries26.getDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean30 = fixedMillisecond28.equals((java.lang.Object) 0.0d);
//        java.util.Calendar calendar31 = null;
//        fixedMillisecond28.peg(calendar31);
//        java.lang.String str33 = fixedMillisecond28.toString();
//        long long34 = fixedMillisecond28.getMiddleMillisecond();
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass36 = month35.getClass();
//        boolean boolean38 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month35, (java.lang.Object) 10.0d);
//        long long39 = month35.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries26.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (org.jfree.data.time.RegularTimePeriod) month35);
//        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year43, (java.lang.Number) 10.0f);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = year43.next();
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        java.lang.Object obj48 = null;
//        boolean boolean49 = day47.equals(obj48);
//        java.lang.String str50 = day47.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = day47.previous();
//        long long52 = day47.getLastMillisecond();
//        int int54 = day47.compareTo((java.lang.Object) 100L);
//        java.util.Date date55 = day47.getEnd();
//        long long56 = day47.getMiddleMillisecond();
//        int int57 = year43.compareTo((java.lang.Object) day47);
//        org.jfree.data.time.Month month58 = new org.jfree.data.time.Month(8, year43);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem60 = timeSeries26.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month58, (double) 1560440374960L);
//        org.jfree.data.time.Month month61 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = month61.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = month61.previous();
//        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year(1900);
//        long long66 = year65.getLastMillisecond();
//        boolean boolean67 = month61.equals((java.lang.Object) year65);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = year65.previous();
//        java.lang.Number number69 = timeSeries26.getValue((org.jfree.data.time.RegularTimePeriod) year65);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(class22);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertNull(str27);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Thu Jun 13 08:40:48 PDT 2019" + "'", str33.equals("Thu Jun 13 08:40:48 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560440448703L + "'", long34 == 1560440448703L);
//        org.junit.Assert.assertNotNull(wildcardClass36);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1561964399999L + "'", long39 == 1561964399999L);
//        org.junit.Assert.assertNotNull(timeSeries40);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "13-June-2019" + "'", str50.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1560495599999L + "'", long52 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1560452399999L + "'", long56 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
//        org.junit.Assert.assertNull(timeSeriesDataItem60);
//        org.junit.Assert.assertNotNull(regularTimePeriod62);
//        org.junit.Assert.assertNotNull(regularTimePeriod63);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + (-2177424000001L) + "'", long66 == (-2177424000001L));
//        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
//        org.junit.Assert.assertNull(regularTimePeriod68);
//        org.junit.Assert.assertTrue("'" + number69 + "' != '" + 1.56044037496E12d + "'", number69.equals(1.56044037496E12d));
//    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((-43594));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -43594");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test287() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test287");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        int int3 = day0.getMonth();
//        java.lang.String str4 = day0.toString();
//        org.jfree.data.time.SerialDate serialDate5 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.previous();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//    }

//    @Test
//    public void test288() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test288");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass7 = month6.getClass();
//        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class8);
//        timeSeries9.setDomainDescription("");
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass16 = month15.getClass();
//        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass16);
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class17);
//        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries9.addAndOrUpdate(timeSeries18);
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d);
//        java.util.Collection collection22 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries21);
//        java.lang.Class class23 = timeSeries21.getTimePeriodClass();
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass28 = month27.getClass();
//        java.lang.Class class29 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass28);
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class29);
//        timeSeries30.setDomainDescription("");
//        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass37 = month36.getClass();
//        java.lang.Class class38 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass37);
//        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class38);
//        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries30.addAndOrUpdate(timeSeries39);
//        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = year42.previous();
//        long long44 = year42.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries40.getDataItem((org.jfree.data.time.RegularTimePeriod) year42);
//        java.util.Collection collection46 = timeSeries21.getTimePeriodsUniqueToOtherSeries(timeSeries40);
//        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(1900);
//        int int50 = year48.compareTo((java.lang.Object) 0);
//        long long51 = year48.getLastMillisecond();
//        long long52 = year48.getFirstMillisecond();
//        timeSeries21.delete((org.jfree.data.time.RegularTimePeriod) year48);
//        boolean boolean54 = fixedMillisecond0.equals((java.lang.Object) year48);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440449397L + "'", long2 == 1560440449397L);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(class8);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNotNull(class17);
//        org.junit.Assert.assertNotNull(timeSeries19);
//        org.junit.Assert.assertNotNull(collection22);
//        org.junit.Assert.assertNotNull(class23);
//        org.junit.Assert.assertNotNull(wildcardClass28);
//        org.junit.Assert.assertNotNull(class29);
//        org.junit.Assert.assertNotNull(wildcardClass37);
//        org.junit.Assert.assertNotNull(class38);
//        org.junit.Assert.assertNotNull(timeSeries40);
//        org.junit.Assert.assertNull(regularTimePeriod43);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1900L + "'", long44 == 1900L);
//        org.junit.Assert.assertNull(timeSeriesDataItem45);
//        org.junit.Assert.assertNotNull(collection46);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-2177424000001L) + "'", long51 == (-2177424000001L));
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + (-2208960000000L) + "'", long52 == (-2208960000000L));
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean3 = spreadsheetDate1.equals((java.lang.Object) 31);
        int int4 = spreadsheetDate1.getDayOfWeek();
        int int5 = spreadsheetDate1.toSerial();
        try {
            org.jfree.data.time.SerialDate serialDate7 = spreadsheetDate1.getNearestDayOfWeek((-460));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
    }

//    @Test
//    public void test290() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test290");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        java.util.List list7 = timeSeries6.getItems();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean10 = fixedMillisecond8.equals((java.lang.Object) 0.0d);
//        java.util.Calendar calendar11 = null;
//        fixedMillisecond8.peg(calendar11);
//        java.lang.String str13 = fixedMillisecond8.toString();
//        long long14 = fixedMillisecond8.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (double) 31);
//        java.beans.PropertyChangeListener propertyChangeListener17 = null;
//        timeSeries6.removePropertyChangeListener(propertyChangeListener17);
//        java.lang.String str19 = timeSeries6.getRangeDescription();
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(list7);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Thu Jun 13 08:40:49 PDT 2019" + "'", str13.equals("Thu Jun 13 08:40:49 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560440449673L + "'", long14 == 1560440449673L);
//        org.junit.Assert.assertNull(timeSeriesDataItem16);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "ThreadContext" + "'", str19.equals("ThreadContext"));
//    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "", "17-June-2019", class5);
        int int7 = timeSeries6.getMaximumItemCount();
        timeSeries6.setMaximumItemCount(9);
        timeSeries6.setDescription("Thu Jun 13 08:39:46 PDT 2019");
        java.lang.Object obj12 = timeSeries6.clone();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(4);
        int int2 = spreadsheetDate1.getMonth();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

//    @Test
//    public void test293() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test293");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getLastMillisecond(calendar1);
//        boolean boolean4 = fixedMillisecond0.equals((java.lang.Object) 1561964399999L);
//        long long5 = fixedMillisecond0.getSerialIndex();
//        java.util.Date date6 = fixedMillisecond0.getEnd();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass12 = month11.getClass();
//        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class13);
//        timeSeries14.setDomainDescription("");
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass21 = month20.getClass();
//        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries14.addAndOrUpdate(timeSeries23);
//        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = fixedMillisecond27.next();
//        java.util.Calendar calendar29 = null;
//        long long30 = fixedMillisecond27.getLastMillisecond(calendar29);
//        long long31 = fixedMillisecond27.getSerialIndex();
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass34 = month33.getClass();
//        java.lang.Class class35 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass34);
//        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass37 = month36.getClass();
//        java.lang.Class class38 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass37);
//        java.lang.Object obj39 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class35, class38);
//        boolean boolean40 = fixedMillisecond27.equals((java.lang.Object) class38);
//        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries23.createCopy((org.jfree.data.time.RegularTimePeriod) year26, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
//        java.lang.String str42 = timeSeries41.getDomainDescription();
//        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass47 = month46.getClass();
//        java.lang.Class class48 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass47);
//        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class48);
//        timeSeries49.setDomainDescription("");
//        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass56 = month55.getClass();
//        java.lang.Class class57 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass56);
//        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class57);
//        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries49.addAndOrUpdate(timeSeries58);
//        java.lang.String str60 = timeSeries59.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries41.addAndOrUpdate(timeSeries59);
//        boolean boolean63 = timeSeries61.equals((java.lang.Object) 1560440368245L);
//        java.lang.Class class64 = timeSeries61.getTimePeriodClass();
//        java.lang.Object obj65 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("October", class64);
//        java.lang.Class class66 = org.jfree.data.time.RegularTimePeriod.downsize(class64);
//        org.jfree.data.time.TimeSeries timeSeries67 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date6, class66);
//        org.jfree.data.time.Year year69 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = year69.previous();
//        long long71 = year69.getSerialIndex();
//        java.util.Date date72 = year69.getStart();
//        org.jfree.data.time.Month month73 = new org.jfree.data.time.Month(date72);
//        org.jfree.data.time.Month month74 = new org.jfree.data.time.Month(date72);
//        org.jfree.data.time.Month month80 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass81 = month80.getClass();
//        java.lang.Class class82 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass81);
//        java.io.InputStream inputStream83 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass81);
//        org.jfree.data.time.Month month84 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass85 = month84.getClass();
//        java.lang.Class class86 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass85);
//        java.lang.Object obj87 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Thu Jun 13 08:39:19 PDT 2019", (java.lang.Class) wildcardClass81, class86);
//        java.lang.Object obj88 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", (java.lang.Class) wildcardClass81);
//        java.io.InputStream inputStream89 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Jan", (java.lang.Class) wildcardClass81);
//        java.net.URL uRL90 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("Thu Jun 13 08:39:42 PDT 2019", (java.lang.Class) wildcardClass81);
//        java.util.Date date91 = null;
//        java.util.TimeZone timeZone92 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod93 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass81, date91, timeZone92);
//        org.jfree.data.time.Month month94 = new org.jfree.data.time.Month(date72, timeZone92);
//        org.jfree.data.time.Day day95 = new org.jfree.data.time.Day(date6, timeZone92);
//        long long96 = day95.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440449738L + "'", long2 == 1560440449738L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560440449738L + "'", long5 == 1560440449738L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNotNull(class13);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(class22);
//        org.junit.Assert.assertNotNull(timeSeries24);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560440449749L + "'", long30 == 1560440449749L);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560440449749L + "'", long31 == 1560440449749L);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNotNull(class35);
//        org.junit.Assert.assertNotNull(wildcardClass37);
//        org.junit.Assert.assertNotNull(class38);
//        org.junit.Assert.assertNull(obj39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(timeSeries41);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "hi!" + "'", str42.equals("hi!"));
//        org.junit.Assert.assertNotNull(wildcardClass47);
//        org.junit.Assert.assertNotNull(class48);
//        org.junit.Assert.assertNotNull(wildcardClass56);
//        org.junit.Assert.assertNotNull(class57);
//        org.junit.Assert.assertNotNull(timeSeries59);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "Time" + "'", str60.equals("Time"));
//        org.junit.Assert.assertNotNull(timeSeries61);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertNotNull(class64);
//        org.junit.Assert.assertNull(obj65);
//        org.junit.Assert.assertNotNull(class66);
//        org.junit.Assert.assertNull(regularTimePeriod70);
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 1900L + "'", long71 == 1900L);
//        org.junit.Assert.assertNotNull(date72);
//        org.junit.Assert.assertNotNull(wildcardClass81);
//        org.junit.Assert.assertNotNull(class82);
//        org.junit.Assert.assertNotNull(inputStream83);
//        org.junit.Assert.assertNotNull(wildcardClass85);
//        org.junit.Assert.assertNotNull(class86);
//        org.junit.Assert.assertNull(obj87);
//        org.junit.Assert.assertNull(obj88);
//        org.junit.Assert.assertNull(inputStream89);
//        org.junit.Assert.assertNull(uRL90);
//        org.junit.Assert.assertNotNull(timeZone92);
//        org.junit.Assert.assertNull(regularTimePeriod93);
//        org.junit.Assert.assertTrue("'" + long96 + "' != '" + 43629L + "'", long96 == 43629L);
//    }

//    @Test
//    public void test294() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test294");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
//        long long3 = year1.getSerialIndex();
//        java.util.Date date4 = year1.getStart();
//        long long5 = year1.getFirstMillisecond();
//        int int6 = year1.getYear();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        java.lang.Object obj8 = null;
//        boolean boolean9 = day7.equals(obj8);
//        java.lang.String str10 = day7.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day7.previous();
//        int int12 = year1.compareTo((java.lang.Object) day7);
//        int int13 = year1.getYear();
//        java.lang.String str14 = year1.toString();
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass19 = month18.getClass();
//        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass19);
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class20);
//        timeSeries21.setDomainDescription("");
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass28 = month27.getClass();
//        java.lang.Class class29 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass28);
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class29);
//        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries21.addAndOrUpdate(timeSeries30);
//        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = year33.previous();
//        long long35 = year33.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries31.getDataItem((org.jfree.data.time.RegularTimePeriod) year33);
//        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year38.previous();
//        long long40 = year38.getSerialIndex();
//        java.util.Date date41 = year38.getStart();
//        long long42 = year38.getFirstMillisecond();
//        java.lang.Number number43 = timeSeries31.getValue((org.jfree.data.time.RegularTimePeriod) year38);
//        int int45 = year38.compareTo((java.lang.Object) 2147483647);
//        boolean boolean46 = year1.equals((java.lang.Object) year38);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = year38.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = year38.previous();
//        org.junit.Assert.assertNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1900L + "'", long3 == 1900L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-2208960000000L) + "'", long5 == (-2208960000000L));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1900 + "'", int6 == 1900);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "13-June-2019" + "'", str10.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1900 + "'", int13 == 1900);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1900" + "'", str14.equals("1900"));
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertNotNull(class20);
//        org.junit.Assert.assertNotNull(wildcardClass28);
//        org.junit.Assert.assertNotNull(class29);
//        org.junit.Assert.assertNotNull(timeSeries31);
//        org.junit.Assert.assertNull(regularTimePeriod34);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1900L + "'", long35 == 1900L);
//        org.junit.Assert.assertNull(timeSeriesDataItem36);
//        org.junit.Assert.assertNull(regularTimePeriod39);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1900L + "'", long40 == 1900L);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-2208960000000L) + "'", long42 == (-2208960000000L));
//        org.junit.Assert.assertNull(number43);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
//        org.junit.Assert.assertNull(regularTimePeriod47);
//        org.junit.Assert.assertNull(regularTimePeriod48);
//    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440378211L);
    }

//    @Test
//    public void test296() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test296");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean2 = fixedMillisecond0.equals((java.lang.Object) 0.0d);
//        java.util.Calendar calendar3 = null;
//        fixedMillisecond0.peg(calendar3);
//        java.lang.String str5 = fixedMillisecond0.toString();
//        java.util.Date date6 = fixedMillisecond0.getStart();
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass11 = month10.getClass();
//        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
//        java.io.InputStream inputStream13 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Thu Jun 13 08:40:39 PDT 2019", (java.lang.Class) wildcardClass11);
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, "", "Thu Jun 13 08:39:19 PDT 2019", (java.lang.Class) wildcardClass11);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Thu Jun 13 08:40:50 PDT 2019" + "'", str5.equals("Thu Jun 13 08:40:50 PDT 2019"));
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertNull(inputStream13);
//    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(30, 1900, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test298() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test298");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getLastMillisecond(calendar1);
//        boolean boolean4 = fixedMillisecond0.equals((java.lang.Object) 1561964399999L);
//        long long5 = fixedMillisecond0.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) 13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeriesDataItem7.getPeriod();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440450567L + "'", long2 == 1560440450567L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560440450567L + "'", long5 == 1560440450567L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//    }

//    @Test
//    public void test299() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test299");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getLastMillisecond(calendar10);
//        boolean boolean13 = fixedMillisecond9.equals((java.lang.Object) 1561964399999L);
//        long long14 = fixedMillisecond9.getSerialIndex();
//        java.util.Calendar calendar15 = null;
//        fixedMillisecond9.peg(calendar15);
//        java.util.Date date17 = fixedMillisecond9.getTime();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent18 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) fixedMillisecond9);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, 10.0d);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = fixedMillisecond9.previous();
//        long long22 = fixedMillisecond9.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560440450582L + "'", long11 == 1560440450582L);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560440450582L + "'", long14 == 1560440450582L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNull(timeSeriesDataItem20);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560440450582L + "'", long22 == 1560440450582L);
//    }

//    @Test
//    public void test300() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test300");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.setDomainDescription("");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass13 = month12.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        java.lang.Object obj18 = null;
//        boolean boolean19 = day17.equals(obj18);
//        java.lang.String str20 = day17.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day17.previous();
//        long long22 = day17.getLastMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar24 = null;
//        long long25 = fixedMillisecond23.getLastMillisecond(calendar24);
//        boolean boolean27 = fixedMillisecond23.equals((java.lang.Object) 1561964399999L);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent28 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 1561964399999L);
//        int int29 = day17.compareTo((java.lang.Object) 1561964399999L);
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass34 = month33.getClass();
//        java.lang.Class class35 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass34);
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class35);
//        timeSeries36.setDomainDescription("");
//        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass43 = month42.getClass();
//        java.lang.Class class44 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass43);
//        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class44);
//        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries36.addAndOrUpdate(timeSeries45);
//        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = fixedMillisecond49.next();
//        java.util.Calendar calendar51 = null;
//        long long52 = fixedMillisecond49.getLastMillisecond(calendar51);
//        long long53 = fixedMillisecond49.getSerialIndex();
//        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass56 = month55.getClass();
//        java.lang.Class class57 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass56);
//        org.jfree.data.time.Month month58 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass59 = month58.getClass();
//        java.lang.Class class60 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass59);
//        java.lang.Object obj61 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class57, class60);
//        boolean boolean62 = fixedMillisecond49.equals((java.lang.Object) class60);
//        org.jfree.data.time.TimeSeries timeSeries63 = timeSeries45.createCopy((org.jfree.data.time.RegularTimePeriod) year48, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond49);
//        java.lang.String str64 = timeSeries63.getDomainDescription();
//        org.jfree.data.time.Month month68 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass69 = month68.getClass();
//        java.lang.Class class70 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass69);
//        org.jfree.data.time.TimeSeries timeSeries71 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class70);
//        timeSeries71.setDomainDescription("");
//        org.jfree.data.time.Month month77 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass78 = month77.getClass();
//        java.lang.Class class79 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass78);
//        org.jfree.data.time.TimeSeries timeSeries80 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class79);
//        org.jfree.data.time.TimeSeries timeSeries81 = timeSeries71.addAndOrUpdate(timeSeries80);
//        java.lang.String str82 = timeSeries81.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries83 = timeSeries63.addAndOrUpdate(timeSeries81);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond84 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar85 = null;
//        long long86 = fixedMillisecond84.getMiddleMillisecond(calendar85);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = fixedMillisecond84.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem89 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod87, (double) 5);
//        int int90 = timeSeries63.getIndex(regularTimePeriod87);
//        org.jfree.data.time.TimeSeries timeSeries91 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) day17, regularTimePeriod87);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "13-June-2019" + "'", str20.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560495599999L + "'", long22 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560440450627L + "'", long25 == 1560440450627L);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNotNull(class35);
//        org.junit.Assert.assertNotNull(wildcardClass43);
//        org.junit.Assert.assertNotNull(class44);
//        org.junit.Assert.assertNotNull(timeSeries46);
//        org.junit.Assert.assertNotNull(regularTimePeriod50);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1560440450630L + "'", long52 == 1560440450630L);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1560440450630L + "'", long53 == 1560440450630L);
//        org.junit.Assert.assertNotNull(wildcardClass56);
//        org.junit.Assert.assertNotNull(class57);
//        org.junit.Assert.assertNotNull(wildcardClass59);
//        org.junit.Assert.assertNotNull(class60);
//        org.junit.Assert.assertNull(obj61);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertNotNull(timeSeries63);
//        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "hi!" + "'", str64.equals("hi!"));
//        org.junit.Assert.assertNotNull(wildcardClass69);
//        org.junit.Assert.assertNotNull(class70);
//        org.junit.Assert.assertNotNull(wildcardClass78);
//        org.junit.Assert.assertNotNull(class79);
//        org.junit.Assert.assertNotNull(timeSeries81);
//        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "Time" + "'", str82.equals("Time"));
//        org.junit.Assert.assertNotNull(timeSeries83);
//        org.junit.Assert.assertTrue("'" + long86 + "' != '" + 1560440450641L + "'", long86 == 1560440450641L);
//        org.junit.Assert.assertNotNull(regularTimePeriod87);
//        org.junit.Assert.assertTrue("'" + int90 + "' != '" + (-1) + "'", int90 == (-1));
//        org.junit.Assert.assertNotNull(timeSeries91);
//    }

//    @Test
//    public void test301() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test301");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int4 = spreadsheetDate3.toSerial();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        int int6 = day5.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
//        boolean boolean8 = spreadsheetDate3.isOnOrAfter(serialDate7);
//        int int9 = spreadsheetDate1.compare(serialDate7);
//        try {
//            org.jfree.data.time.SerialDate serialDate11 = spreadsheetDate1.getNearestDayOfWeek((int) '#');
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 13 + "'", int6 == 13);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-43594) + "'", int9 == (-43594));
//    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        long long3 = year1.getSerialIndex();
        java.util.Date date4 = year1.getStart();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date4);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(1900);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        long long10 = year8.getSerialIndex();
        java.util.Date date11 = year8.getStart();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date11, timeZone12);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date4, timeZone12);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date4);
        int int16 = month15.getYearValue();
        org.junit.Assert.assertNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1900L + "'", long3 == 1900L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1900L + "'", long10 == 1900L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1900 + "'", int16 == 1900);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.clear();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass12 = month11.getClass();
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class13);
        timeSeries14.setDomainDescription("");
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass21 = month20.getClass();
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries14.addAndOrUpdate(timeSeries23);
        java.lang.String str25 = timeSeries23.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries6.addAndOrUpdate(timeSeries23);
        java.lang.Class class27 = timeSeries23.getTimePeriodClass();
        java.lang.ClassLoader classLoader28 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class27);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "ThreadContext" + "'", str25.equals("ThreadContext"));
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNotNull(class27);
        org.junit.Assert.assertNotNull(classLoader28);
    }

//    @Test
//    public void test304() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test304");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.setDomainDescription("");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass13 = month12.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond19.next();
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond19.getLastMillisecond(calendar21);
//        long long23 = fixedMillisecond19.getSerialIndex();
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass26 = month25.getClass();
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass26);
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass29 = month28.getClass();
//        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
//        java.lang.Object obj31 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class27, class30);
//        boolean boolean32 = fixedMillisecond19.equals((java.lang.Object) class30);
//        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) year18, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
//        java.lang.String str34 = timeSeries33.getDomainDescription();
//        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass39 = month38.getClass();
//        java.lang.Class class40 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass39);
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class40);
//        timeSeries41.setDomainDescription("");
//        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass48 = month47.getClass();
//        java.lang.Class class49 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass48);
//        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class49);
//        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries41.addAndOrUpdate(timeSeries50);
//        java.lang.String str52 = timeSeries51.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries33.addAndOrUpdate(timeSeries51);
//        boolean boolean55 = timeSeries53.equals((java.lang.Object) 1560440368245L);
//        timeSeries53.setMaximumItemCount(31);
//        int int58 = timeSeries53.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond59 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = fixedMillisecond59.next();
//        boolean boolean62 = fixedMillisecond59.equals((java.lang.Object) "org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        java.util.Calendar calendar63 = null;
//        long long64 = fixedMillisecond59.getFirstMillisecond(calendar63);
//        int int65 = timeSeries53.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond59);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560440451908L + "'", long22 == 1560440451908L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560440451908L + "'", long23 == 1560440451908L);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertNull(obj31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(timeSeries33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
//        org.junit.Assert.assertNotNull(wildcardClass39);
//        org.junit.Assert.assertNotNull(class40);
//        org.junit.Assert.assertNotNull(wildcardClass48);
//        org.junit.Assert.assertNotNull(class49);
//        org.junit.Assert.assertNotNull(timeSeries51);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "Time" + "'", str52.equals("Time"));
//        org.junit.Assert.assertNotNull(timeSeries53);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod60);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 1560440451914L + "'", long64 == 1560440451914L);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
//    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(7, (int) ' ');
        int int3 = month2.getMonth();
        long long4 = month2.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month2.next();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 7 + "'", int3 == 7);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 391L + "'", long4 == 391L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass21 = month20.getClass();
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
        java.util.List list24 = timeSeries23.getItems();
        boolean boolean25 = timeSeries16.equals((java.lang.Object) list24);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass30 = month29.getClass();
        java.lang.Class class31 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass30);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class31);
        timeSeries32.setDomainDescription("");
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass39 = month38.getClass();
        java.lang.Class class40 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass39);
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class40);
        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries32.addAndOrUpdate(timeSeries41);
        timeSeries32.fireSeriesChanged();
        int int44 = timeSeries32.getItemCount();
        java.lang.Comparable comparable45 = timeSeries32.getKey();
        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries16.addAndOrUpdate(timeSeries32);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertNotNull(list24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertNotNull(class31);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertNotNull(class40);
        org.junit.Assert.assertNotNull(timeSeries42);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + comparable45 + "' != '" + 1560440358934L + "'", comparable45.equals(1560440358934L));
        org.junit.Assert.assertNotNull(timeSeries46);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
        java.lang.Class<?> wildcardClass2 = fixedMillisecond0.getClass();
        int int4 = fixedMillisecond0.compareTo((java.lang.Object) 1560440412840L);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Thu Jun 13 08:40:07 PDT 2019");
    }

//    @Test
//    public void test309() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test309");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
//        long long3 = year1.getSerialIndex();
//        java.util.Date date4 = year1.getStart();
//        long long5 = year1.getFirstMillisecond();
//        int int6 = year1.getYear();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        java.lang.Object obj8 = null;
//        boolean boolean9 = day7.equals(obj8);
//        java.lang.String str10 = day7.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day7.previous();
//        int int12 = year1.compareTo((java.lang.Object) day7);
//        int int13 = day7.getYear();
//        java.util.Calendar calendar14 = null;
//        try {
//            day7.peg(calendar14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1900L + "'", long3 == 1900L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-2208960000000L) + "'", long5 == (-2208960000000L));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1900 + "'", int6 == 1900);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "13-June-2019" + "'", str10.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass11 = month10.getClass();
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class12);
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener14);
        java.lang.String str16 = timeSeries13.getDescription();
        java.util.Collection collection17 = timeSeries6.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(1900);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year19.previous();
        long long21 = year19.getSerialIndex();
        java.util.Date date22 = year19.getStart();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date22, timeZone23);
        java.lang.Number number25 = timeSeries6.getValue((org.jfree.data.time.RegularTimePeriod) day24);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond26.next();
        java.lang.Class<?> wildcardClass28 = fixedMillisecond26.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, (double) 1561964399999L);
        java.util.Date date31 = fixedMillisecond26.getStart();
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date31);
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass37 = month36.getClass();
        java.lang.Class class38 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass37);
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class38);
        timeSeries39.clear();
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass45 = month44.getClass();
        java.lang.Class class46 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass45);
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class46);
        timeSeries47.setDomainDescription("");
        org.jfree.data.time.Month month53 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass54 = month53.getClass();
        java.lang.Class class55 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass54);
        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class55);
        org.jfree.data.time.TimeSeries timeSeries57 = timeSeries47.addAndOrUpdate(timeSeries56);
        java.lang.String str58 = timeSeries56.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries39.addAndOrUpdate(timeSeries56);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener60 = null;
        timeSeries39.removeChangeListener(seriesChangeListener60);
        int int62 = day32.compareTo((java.lang.Object) timeSeries39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = day32.next();
        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) day32, (double) 1560440388073L);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1900L + "'", long21 == 1900L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(number25);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertNotNull(class38);
        org.junit.Assert.assertNotNull(wildcardClass45);
        org.junit.Assert.assertNotNull(class46);
        org.junit.Assert.assertNotNull(wildcardClass54);
        org.junit.Assert.assertNotNull(class55);
        org.junit.Assert.assertNotNull(timeSeries57);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "ThreadContext" + "'", str58.equals("ThreadContext"));
        org.junit.Assert.assertNotNull(timeSeries59);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
    }

//    @Test
//    public void test311() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test311");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.setDomainDescription("");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass13 = month12.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond19.next();
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond19.getLastMillisecond(calendar21);
//        long long23 = fixedMillisecond19.getSerialIndex();
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass26 = month25.getClass();
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass26);
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass29 = month28.getClass();
//        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
//        java.lang.Object obj31 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class27, class30);
//        boolean boolean32 = fixedMillisecond19.equals((java.lang.Object) class30);
//        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) year18, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
//        java.lang.String str34 = timeSeries33.getDomainDescription();
//        timeSeries33.removeAgedItems(1560440369753L, false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = null;
//        java.lang.Number number39 = null;
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries33.addOrUpdate(regularTimePeriod38, number39);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560440453052L + "'", long22 == 1560440453052L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560440453052L + "'", long23 == 1560440453052L);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertNull(obj31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(timeSeries33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
//    }

//    @Test
//    public void test312() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test312");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
//        long long3 = year1.getSerialIndex();
//        java.util.Date date4 = year1.getStart();
//        long long5 = year1.getFirstMillisecond();
//        int int6 = year1.getYear();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        java.lang.Object obj8 = null;
//        boolean boolean9 = day7.equals(obj8);
//        java.lang.String str10 = day7.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day7.previous();
//        int int12 = year1.compareTo((java.lang.Object) day7);
//        int int13 = day7.getYear();
//        java.util.Calendar calendar14 = null;
//        try {
//            long long15 = day7.getLastMillisecond(calendar14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1900L + "'", long3 == 1900L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-2208960000000L) + "'", long5 == (-2208960000000L));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1900 + "'", int6 == 1900);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "13-June-2019" + "'", str10.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int5 = spreadsheetDate4.toSerial();
        int int6 = spreadsheetDate4.getYYYY();
        int int7 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1900 + "'", int6 == 1900);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 25 + "'", int7 == 25);
    }

//    @Test
//    public void test314() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test314");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.clear();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass12 = month11.getClass();
//        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class13);
//        timeSeries14.setDomainDescription("");
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass21 = month20.getClass();
//        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries14.addAndOrUpdate(timeSeries23);
//        java.lang.String str25 = timeSeries23.getRangeDescription();
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries6.addAndOrUpdate(timeSeries23);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener27 = null;
//        timeSeries6.removeChangeListener(seriesChangeListener27);
//        boolean boolean29 = timeSeries6.getNotify();
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass34 = month33.getClass();
//        java.lang.Class class35 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass34);
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class35);
//        timeSeries36.setDomainDescription("");
//        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass43 = month42.getClass();
//        java.lang.Class class44 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass43);
//        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class44);
//        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries36.addAndOrUpdate(timeSeries45);
//        java.lang.String str47 = timeSeries45.getRangeDescription();
//        int int48 = timeSeries45.getMaximumItemCount();
//        long long49 = timeSeries45.getMaximumItemAge();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar51 = null;
//        long long52 = fixedMillisecond50.getLastMillisecond(calendar51);
//        boolean boolean54 = fixedMillisecond50.equals((java.lang.Object) 1561964399999L);
//        long long55 = fixedMillisecond50.getSerialIndex();
//        java.util.Date date56 = fixedMillisecond50.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = fixedMillisecond57.next();
//        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries45.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond50, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond57);
//        try {
//            timeSeries6.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond50, (double) 1560440410258L, true);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNotNull(class13);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(class22);
//        org.junit.Assert.assertNotNull(timeSeries24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "ThreadContext" + "'", str25.equals("ThreadContext"));
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNotNull(class35);
//        org.junit.Assert.assertNotNull(wildcardClass43);
//        org.junit.Assert.assertNotNull(class44);
//        org.junit.Assert.assertNotNull(timeSeries46);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "ThreadContext" + "'", str47.equals("ThreadContext"));
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 2147483647 + "'", int48 == 2147483647);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 9223372036854775807L + "'", long49 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1560440453119L + "'", long52 == 1560440453119L);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1560440453119L + "'", long55 == 1560440453119L);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//        org.junit.Assert.assertNotNull(timeSeries59);
//    }

//    @Test
//    public void test315() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test315");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.setDomainDescription("");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass13 = month12.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass21 = month20.getClass();
//        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class22);
//        timeSeries23.setDomainDescription("");
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries16.addAndOrUpdate(timeSeries23);
//        java.lang.String str27 = timeSeries26.getDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean30 = fixedMillisecond28.equals((java.lang.Object) 0.0d);
//        java.util.Calendar calendar31 = null;
//        fixedMillisecond28.peg(calendar31);
//        java.lang.String str33 = fixedMillisecond28.toString();
//        long long34 = fixedMillisecond28.getMiddleMillisecond();
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass36 = month35.getClass();
//        boolean boolean38 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month35, (java.lang.Object) 10.0d);
//        long long39 = month35.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries26.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (org.jfree.data.time.RegularTimePeriod) month35);
//        try {
//            timeSeries26.delete(5, (-1));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(class22);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertNull(str27);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Thu Jun 13 08:40:53 PDT 2019" + "'", str33.equals("Thu Jun 13 08:40:53 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560440453140L + "'", long34 == 1560440453140L);
//        org.junit.Assert.assertNotNull(wildcardClass36);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1561964399999L + "'", long39 == 1561964399999L);
//        org.junit.Assert.assertNotNull(timeSeries40);
//    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-457) + "'", int1 == (-457));
    }

//    @Test
//    public void test317() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test317");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean5 = spreadsheetDate3.equals((java.lang.Object) 31);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int7 = day6.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day6.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate10 = serialDate8.getFollowingDayOfWeek(2);
//        java.lang.String str11 = serialDate10.toString();
//        boolean boolean12 = spreadsheetDate3.isOnOrBefore(serialDate10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean16 = spreadsheetDate14.equals((java.lang.Object) 31);
//        int int17 = spreadsheetDate14.getDayOfWeek();
//        int int18 = spreadsheetDate14.getMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate20);
//        boolean boolean22 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate14, (org.jfree.data.time.SerialDate) spreadsheetDate20);
//        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, (org.jfree.data.time.SerialDate) spreadsheetDate3);
//        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addYears(9, (org.jfree.data.time.SerialDate) spreadsheetDate3);
//        try {
//            org.jfree.data.time.SerialDate serialDate26 = spreadsheetDate3.getNearestDayOfWeek(9);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 13 + "'", int7 == 13);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "17-June-2019" + "'", str11.equals("17-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 3 + "'", int17 == 3);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(serialDate24);
//    }

//    @Test
//    public void test318() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test318");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getLastMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        java.util.Calendar calendar4 = null;
//        long long5 = fixedMillisecond0.getMiddleMillisecond(calendar4);
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year8, (java.lang.Number) 10.0f);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year8.next();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        java.lang.Object obj13 = null;
//        boolean boolean14 = day12.equals(obj13);
//        java.lang.String str15 = day12.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day12.previous();
//        long long17 = day12.getLastMillisecond();
//        int int19 = day12.compareTo((java.lang.Object) 100L);
//        java.util.Date date20 = day12.getEnd();
//        long long21 = day12.getMiddleMillisecond();
//        int int22 = year8.compareTo((java.lang.Object) day12);
//        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(8, year8);
//        int int24 = fixedMillisecond0.compareTo((java.lang.Object) month23);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440453229L + "'", long2 == 1560440453229L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560440453229L + "'", long5 == 1560440453229L);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "13-June-2019" + "'", str15.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560495599999L + "'", long17 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560452399999L + "'", long21 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Monday");
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 1);
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1);
        int int3 = timeSeries2.getMaximumItemCount();
        java.lang.String str4 = timeSeries2.getRangeDescription();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass9 = month8.getClass();
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class10);
        timeSeries11.setDomainDescription("");
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass18 = month17.getClass();
        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass18);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class19);
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries11.addAndOrUpdate(timeSeries20);
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries2.addAndOrUpdate(timeSeries20);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries20.getDataItem((-435));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Value" + "'", str4.equals("Value"));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(class19);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertNotNull(timeSeries22);
    }

//    @Test
//    public void test321() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test321");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        int int4 = fixedMillisecond0.compareTo((java.lang.Object) 8);
//        long long5 = fixedMillisecond0.getLastMillisecond();
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond0.getFirstMillisecond(calendar6);
//        java.util.Calendar calendar8 = null;
//        fixedMillisecond0.peg(calendar8);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440453313L + "'", long2 == 1560440453313L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560440453313L + "'", long5 == 1560440453313L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560440453313L + "'", long7 == 1560440453313L);
//    }

//    @Test
//    public void test322() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test322");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
//        long long3 = year1.getSerialIndex();
//        java.util.Date date4 = year1.getStart();
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date4);
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
//        long long10 = year8.getSerialIndex();
//        java.util.Date date11 = year8.getStart();
//        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date11, timeZone12);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date4, timeZone12);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(date4);
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass21 = month20.getClass();
//        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
//        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass24 = month23.getClass();
//        java.lang.Class class25 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass24);
//        java.lang.Object obj26 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class22, class25);
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass28 = month27.getClass();
//        java.lang.Class class29 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass28);
//        java.lang.Object obj30 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ThreadContext", class22, (java.lang.Class) wildcardClass28);
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440363591L, class22);
//        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass33 = month32.getClass();
//        java.lang.Class class34 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass33);
//        java.lang.Object obj35 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Following", class22, class34);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean38 = fixedMillisecond36.equals((java.lang.Object) 0.0d);
//        java.util.Calendar calendar39 = null;
//        fixedMillisecond36.peg(calendar39);
//        java.lang.String str41 = fixedMillisecond36.toString();
//        java.util.Date date42 = fixedMillisecond36.getStart();
//        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = year44.previous();
//        long long46 = year44.getSerialIndex();
//        java.util.Date date47 = year44.getStart();
//        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month(date47);
//        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month(date47);
//        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass56 = month55.getClass();
//        java.lang.Class class57 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass56);
//        java.io.InputStream inputStream58 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass56);
//        org.jfree.data.time.Month month59 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass60 = month59.getClass();
//        java.lang.Class class61 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass60);
//        java.lang.Object obj62 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Thu Jun 13 08:39:19 PDT 2019", (java.lang.Class) wildcardClass56, class61);
//        java.lang.Object obj63 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", (java.lang.Class) wildcardClass56);
//        java.io.InputStream inputStream64 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Jan", (java.lang.Class) wildcardClass56);
//        java.net.URL uRL65 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("Thu Jun 13 08:39:42 PDT 2019", (java.lang.Class) wildcardClass56);
//        java.util.Date date66 = null;
//        java.util.TimeZone timeZone67 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass56, date66, timeZone67);
//        org.jfree.data.time.Month month69 = new org.jfree.data.time.Month(date47, timeZone67);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date42, timeZone67);
//        org.jfree.data.time.Month month71 = new org.jfree.data.time.Month(date4, timeZone67);
//        org.junit.Assert.assertNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1900L + "'", long3 == 1900L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1900L + "'", long10 == 1900L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(timeZone12);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(class22);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertNotNull(class25);
//        org.junit.Assert.assertNull(obj26);
//        org.junit.Assert.assertNotNull(wildcardClass28);
//        org.junit.Assert.assertNotNull(class29);
//        org.junit.Assert.assertNull(obj30);
//        org.junit.Assert.assertNotNull(wildcardClass33);
//        org.junit.Assert.assertNotNull(class34);
//        org.junit.Assert.assertNull(obj35);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Thu Jun 13 08:40:53 PDT 2019" + "'", str41.equals("Thu Jun 13 08:40:53 PDT 2019"));
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNull(regularTimePeriod45);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1900L + "'", long46 == 1900L);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertNotNull(wildcardClass56);
//        org.junit.Assert.assertNotNull(class57);
//        org.junit.Assert.assertNotNull(inputStream58);
//        org.junit.Assert.assertNotNull(wildcardClass60);
//        org.junit.Assert.assertNotNull(class61);
//        org.junit.Assert.assertNull(obj62);
//        org.junit.Assert.assertNull(obj63);
//        org.junit.Assert.assertNull(inputStream64);
//        org.junit.Assert.assertNull(uRL65);
//        org.junit.Assert.assertNotNull(timeZone67);
//        org.junit.Assert.assertNull(regularTimePeriod68);
//        org.junit.Assert.assertNotNull(regularTimePeriod70);
//    }

//    @Test
//    public void test323() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test323");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
//        long long3 = year1.getSerialIndex();
//        java.util.Date date4 = year1.getStart();
//        long long5 = year1.getFirstMillisecond();
//        int int6 = year1.getYear();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        java.lang.Object obj8 = null;
//        boolean boolean9 = day7.equals(obj8);
//        java.lang.String str10 = day7.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day7.previous();
//        int int12 = year1.compareTo((java.lang.Object) day7);
//        long long13 = year1.getSerialIndex();
//        int int15 = year1.compareTo((java.lang.Object) 1560440373017L);
//        java.util.Date date16 = year1.getEnd();
//        org.junit.Assert.assertNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1900L + "'", long3 == 1900L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-2208960000000L) + "'", long5 == (-2208960000000L));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1900 + "'", int6 == 1900);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "13-June-2019" + "'", str10.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1900L + "'", long13 == 1900L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertNotNull(date16);
//    }

//    @Test
//    public void test324() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test324");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean6 = spreadsheetDate4.equals((java.lang.Object) 31);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate9 = day7.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate11 = serialDate9.getFollowingDayOfWeek(2);
//        java.lang.String str12 = serialDate11.toString();
//        boolean boolean13 = spreadsheetDate4.isOnOrBefore(serialDate11);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean17 = spreadsheetDate15.equals((java.lang.Object) 31);
//        int int18 = spreadsheetDate15.getDayOfWeek();
//        int int19 = spreadsheetDate15.getMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate21);
//        boolean boolean23 = spreadsheetDate4.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate15, (org.jfree.data.time.SerialDate) spreadsheetDate21);
//        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, (org.jfree.data.time.SerialDate) spreadsheetDate4);
//        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addYears(9, (org.jfree.data.time.SerialDate) spreadsheetDate4);
//        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addDays((int) '4', serialDate25);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 13 + "'", int8 == 13);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "17-June-2019" + "'", str12.equals("17-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 3 + "'", int18 == 3);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertNotNull(serialDate26);
//    }

//    @Test
//    public void test325() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test325");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean6 = spreadsheetDate4.equals((java.lang.Object) 31);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate9 = day7.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate11 = serialDate9.getFollowingDayOfWeek(2);
//        java.lang.String str12 = serialDate11.toString();
//        boolean boolean13 = spreadsheetDate4.isOnOrAfter(serialDate11);
//        boolean boolean14 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate4);
//        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addDays(9999, (org.jfree.data.time.SerialDate) spreadsheetDate2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean19 = spreadsheetDate17.equals((java.lang.Object) 31);
//        java.util.Date date20 = spreadsheetDate17.toDate();
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        int int22 = day21.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate23 = day21.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate25 = serialDate23.getFollowingDayOfWeek(2);
//        java.lang.String str26 = serialDate25.toString();
//        int int27 = spreadsheetDate17.compare(serialDate25);
//        org.jfree.data.time.SerialDate serialDate28 = spreadsheetDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate17);
//        org.jfree.data.time.SerialDate serialDate30 = spreadsheetDate2.getPreviousDayOfWeek(7);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 13 + "'", int8 == 13);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "17-June-2019" + "'", str12.equals("17-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 13 + "'", int22 == 13);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "17-June-2019" + "'", str26.equals("17-June-2019"));
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-43623) + "'", int27 == (-43623));
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertNotNull(serialDate30);
//    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        boolean boolean3 = year0.equals((java.lang.Object) 1560440372428L);
        long long4 = year0.getLastMillisecond();
        long long5 = year0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
    }

//    @Test
//    public void test327() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test327");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
//        java.lang.Class<?> wildcardClass2 = fixedMillisecond0.getClass();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getMiddleMillisecond(calendar3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond0.previous();
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond0.getLastMillisecond(calendar6);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560440454660L + "'", long4 == 1560440454660L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560440454660L + "'", long7 == 1560440454660L);
//    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass1 = month0.getClass();
        boolean boolean3 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month0, (java.lang.Object) 10.0d);
        long long4 = month0.getLastMillisecond();
        org.jfree.data.time.Year year5 = month0.getYear();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int9 = spreadsheetDate8.toSerial();
        int int10 = spreadsheetDate8.getYYYY();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addDays(7, (org.jfree.data.time.SerialDate) spreadsheetDate8);
        int int12 = month0.compareTo((java.lang.Object) serialDate11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month0.next();
        long long14 = month0.getFirstMillisecond();
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1900 + "'", int10 == 1900);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1559372400000L + "'", long14 == 1559372400000L);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int2 = month0.compareTo((java.lang.Object) 1L);
        java.util.Date date3 = month0.getEnd();
        long long4 = month0.getMiddleMillisecond();
        boolean boolean6 = month0.equals((java.lang.Object) "Following");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

//    @Test
//    public void test330() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test330");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate4 = serialDate2.getFollowingDayOfWeek(2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean8 = spreadsheetDate6.equals((java.lang.Object) 31);
//        java.util.Date date9 = spreadsheetDate6.toDate();
//        boolean boolean11 = spreadsheetDate6.equals((java.lang.Object) 1560440366809L);
//        int int12 = spreadsheetDate6.getYYYY();
//        org.jfree.data.time.SerialDate serialDate13 = serialDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate6);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(serialDate13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day14.previous();
//        long long16 = day14.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day14.previous();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1900 + "'", int12 == 1900);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2206368000000L) + "'", long16 == (-2206368000000L));
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//    }

//    @Test
//    public void test331() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test331");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getLastMillisecond(calendar1);
//        boolean boolean4 = fixedMillisecond0.equals((java.lang.Object) 1561964399999L);
//        long long5 = fixedMillisecond0.getSerialIndex();
//        java.util.Date date6 = fixedMillisecond0.getEnd();
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass13 = month12.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        java.io.InputStream inputStream15 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass13);
//        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass17 = month16.getClass();
//        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass17);
//        java.lang.Object obj19 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Thu Jun 13 08:39:19 PDT 2019", (java.lang.Class) wildcardClass13, class18);
//        java.lang.Object obj20 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", (java.lang.Class) wildcardClass13);
//        java.io.InputStream inputStream21 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Jan", (java.lang.Class) wildcardClass13);
//        java.net.URL uRL22 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("Thu Jun 13 08:39:42 PDT 2019", (java.lang.Class) wildcardClass13);
//        java.util.Date date23 = null;
//        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date23, timeZone24);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date6, timeZone24);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440454781L + "'", long2 == 1560440454781L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560440454781L + "'", long5 == 1560440454781L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(inputStream15);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(class18);
//        org.junit.Assert.assertNull(obj19);
//        org.junit.Assert.assertNull(obj20);
//        org.junit.Assert.assertNull(inputStream21);
//        org.junit.Assert.assertNull(uRL22);
//        org.junit.Assert.assertNotNull(timeZone24);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//    }

//    @Test
//    public void test332() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test332");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (java.lang.Number) 10.0f);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year1.next();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = day5.equals(obj6);
//        java.lang.String str8 = day5.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day5.previous();
//        long long10 = day5.getLastMillisecond();
//        int int12 = day5.compareTo((java.lang.Object) 100L);
//        java.util.Date date13 = day5.getEnd();
//        long long14 = day5.getMiddleMillisecond();
//        int int15 = year1.compareTo((java.lang.Object) day5);
//        long long16 = day5.getLastMillisecond();
//        java.util.Calendar calendar17 = null;
//        try {
//            long long18 = day5.getFirstMillisecond(calendar17);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "13-June-2019" + "'", str8.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560495599999L + "'", long10 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560452399999L + "'", long14 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560495599999L + "'", long16 == 1560495599999L);
//    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (97) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d);
        java.util.Collection collection19 = timeSeries6.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        long long20 = timeSeries18.getMaximumItemAge();
        java.util.List list21 = timeSeries18.getItems();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = timeSeries18.getTimePeriod(25);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 25, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 9223372036854775807L + "'", long20 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(list21);
    }

//    @Test
//    public void test335() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test335");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int2 = spreadsheetDate1.toSerial();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        int int4 = day3.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
//        boolean boolean6 = spreadsheetDate1.isOnOrAfter(serialDate5);
//        java.lang.String str7 = spreadsheetDate1.getDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond8.getLastMillisecond(calendar9);
//        boolean boolean12 = fixedMillisecond8.equals((java.lang.Object) 1561964399999L);
//        long long13 = fixedMillisecond8.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (double) 13);
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond8.getMiddleMillisecond(calendar16);
//        boolean boolean18 = spreadsheetDate1.equals((java.lang.Object) fixedMillisecond8);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(3);
//        boolean boolean21 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate20);
//        try {
//            org.jfree.data.time.SerialDate serialDate23 = spreadsheetDate20.getPreviousDayOfWeek((-44007));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNull(str7);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560440454920L + "'", long10 == 1560440454920L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560440454920L + "'", long13 == 1560440454920L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560440454920L + "'", long17 == 1560440454920L);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.previous();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(1900);
        long long8 = year7.getLastMillisecond();
        boolean boolean9 = month3.equals((java.lang.Object) year7);
        java.lang.Number number10 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) year7);
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 1.0d + "'", comparable2.equals(1.0d));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-2177424000001L) + "'", long8 == (-2177424000001L));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(number10);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (java.lang.Number) 10.0f);
        java.lang.String str4 = year1.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1900" + "'", str4.equals("1900"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month1.next();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.previous();
        int int6 = month1.compareTo((java.lang.Object) month3);
        java.lang.Class<?> wildcardClass7 = month1.getClass();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass15 = month14.getClass();
        java.lang.Class class16 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass15);
        java.io.InputStream inputStream17 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass15);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass19);
        java.lang.Object obj21 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Thu Jun 13 08:39:19 PDT 2019", (java.lang.Class) wildcardClass15, class20);
        java.lang.Object obj22 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", (java.lang.Class) wildcardClass15);
        java.io.InputStream inputStream23 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Jan", (java.lang.Class) wildcardClass15);
        java.net.URL uRL24 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("13-June-2019", (java.lang.Class) wildcardClass15);
        java.net.URL uRL25 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("org.jfree.data.general.SeriesChangeEvent[source=-1]", (java.lang.Class) wildcardClass15);
        java.lang.Object obj26 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("January 1900", (java.lang.Class) wildcardClass7, (java.lang.Class) wildcardClass15);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(class16);
        org.junit.Assert.assertNotNull(inputStream17);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(class20);
        org.junit.Assert.assertNull(obj21);
        org.junit.Assert.assertNull(obj22);
        org.junit.Assert.assertNull(inputStream23);
        org.junit.Assert.assertNull(uRL24);
        org.junit.Assert.assertNull(uRL25);
        org.junit.Assert.assertNull(obj26);
    }

//    @Test
//    public void test339() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test339");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass4 = month3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
//        timeSeries6.setDomainDescription("");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass13 = month12.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond19.next();
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond19.getLastMillisecond(calendar21);
//        long long23 = fixedMillisecond19.getSerialIndex();
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass26 = month25.getClass();
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass26);
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass29 = month28.getClass();
//        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
//        java.lang.Object obj31 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class27, class30);
//        boolean boolean32 = fixedMillisecond19.equals((java.lang.Object) class30);
//        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) year18, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
//        java.lang.String str34 = timeSeries33.getDomainDescription();
//        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass39 = month38.getClass();
//        java.lang.Class class40 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass39);
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class40);
//        timeSeries41.setDomainDescription("");
//        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass48 = month47.getClass();
//        java.lang.Class class49 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass48);
//        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class49);
//        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries41.addAndOrUpdate(timeSeries50);
//        java.lang.String str52 = timeSeries51.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries33.addAndOrUpdate(timeSeries51);
//        timeSeries33.setRangeDescription("");
//        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day();
//        int int57 = day56.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = day56.previous();
//        java.lang.Number number59 = timeSeries33.getValue((org.jfree.data.time.RegularTimePeriod) day56);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560440455088L + "'", long22 == 1560440455088L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560440455088L + "'", long23 == 1560440455088L);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertNull(obj31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(timeSeries33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
//        org.junit.Assert.assertNotNull(wildcardClass39);
//        org.junit.Assert.assertNotNull(class40);
//        org.junit.Assert.assertNotNull(wildcardClass48);
//        org.junit.Assert.assertNotNull(class49);
//        org.junit.Assert.assertNotNull(timeSeries51);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "Time" + "'", str52.equals("Time"));
//        org.junit.Assert.assertNotNull(timeSeries53);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 13 + "'", int57 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//        org.junit.Assert.assertNull(number59);
//    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Mar");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException3);
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray5);
    }

//    @Test
//    public void test341() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test341");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean2 = fixedMillisecond0.equals((java.lang.Object) 0.0d);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getMiddleMillisecond(calendar3);
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond0.getMiddleMillisecond(calendar5);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560440455453L + "'", long4 == 1560440455453L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560440455453L + "'", long6 == 1560440455453L);
//    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
        java.lang.Class<?> wildcardClass2 = fixedMillisecond0.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) 1561964399999L);
        java.util.Date date5 = fixedMillisecond0.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(1900);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.previous();
        long long9 = year7.getSerialIndex();
        java.util.Date date10 = year7.getStart();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date10);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(1900);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.previous();
        long long16 = year14.getSerialIndex();
        java.util.Date date17 = year14.getStart();
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date17, timeZone18);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(date10, timeZone18);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date5, timeZone18);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1900L + "'", long9 == 1900L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1900L + "'", long16 == 1900L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone18);
    }

//    @Test
//    public void test343() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test343");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getLastMillisecond(calendar1);
//        boolean boolean4 = fixedMillisecond0.equals((java.lang.Object) 1561964399999L);
//        long long5 = fixedMillisecond0.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) 13);
//        boolean boolean9 = timeSeriesDataItem7.equals((java.lang.Object) "org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d));
//        boolean boolean12 = timeSeriesDataItem7.equals((java.lang.Object) (-1.0d));
//        int int14 = timeSeriesDataItem7.compareTo((java.lang.Object) 1560440442343L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440455654L + "'", long2 == 1560440455654L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560440455654L + "'", long5 == 1560440455654L);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//    }

//    @Test
//    public void test344() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test344");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getLastMillisecond(calendar1);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getLastMillisecond(calendar3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond0.previous();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440455683L + "'", long2 == 1560440455683L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560440455683L + "'", long4 == 1560440455683L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((-457), (-460), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
        java.lang.Class<?> wildcardClass2 = fixedMillisecond0.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) 1561964399999L);
        java.util.Date date5 = fixedMillisecond0.getStart();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass11 = month10.getClass();
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class12);
        timeSeries13.clear();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass19);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class20);
        timeSeries21.setDomainDescription("");
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass28 = month27.getClass();
        java.lang.Class class29 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass28);
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class29);
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries21.addAndOrUpdate(timeSeries30);
        java.lang.String str32 = timeSeries30.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries13.addAndOrUpdate(timeSeries30);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener34 = null;
        timeSeries13.removeChangeListener(seriesChangeListener34);
        int int36 = day6.compareTo((java.lang.Object) timeSeries13);
        timeSeries13.setKey((java.lang.Comparable) 6);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(class20);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNotNull(class29);
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "ThreadContext" + "'", str32.equals("ThreadContext"));
        org.junit.Assert.assertNotNull(timeSeries33);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass4 = month3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class5);
        timeSeries6.setDomainDescription("");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(1900);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year18.previous();
        long long20 = year18.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries16.getDataItem((org.jfree.data.time.RegularTimePeriod) year18);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass26 = month25.getClass();
        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass26);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class27);
        timeSeries28.setDomainDescription("");
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass35 = month34.getClass();
        java.lang.Class class36 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass35);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class36);
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries28.addAndOrUpdate(timeSeries37);
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d);
        java.util.Collection collection41 = timeSeries28.getTimePeriodsUniqueToOtherSeries(timeSeries40);
        java.lang.Class class42 = timeSeries40.getTimePeriodClass();
        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass47 = month46.getClass();
        java.lang.Class class48 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass47);
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class48);
        timeSeries49.setDomainDescription("");
        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass56 = month55.getClass();
        java.lang.Class class57 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass56);
        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class57);
        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries49.addAndOrUpdate(timeSeries58);
        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year(1900);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = year61.previous();
        long long63 = year61.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem64 = timeSeries59.getDataItem((org.jfree.data.time.RegularTimePeriod) year61);
        java.util.Collection collection65 = timeSeries40.getTimePeriodsUniqueToOtherSeries(timeSeries59);
        org.jfree.data.time.Year year67 = new org.jfree.data.time.Year(1900);
        int int69 = year67.compareTo((java.lang.Object) 0);
        long long70 = year67.getLastMillisecond();
        long long71 = year67.getFirstMillisecond();
        timeSeries40.delete((org.jfree.data.time.RegularTimePeriod) year67);
        long long73 = year67.getMiddleMillisecond();
        try {
            timeSeries16.add((org.jfree.data.time.RegularTimePeriod) year67, (java.lang.Number) 1560440372428L, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1900L + "'", long20 == 1900L);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(class27);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertNotNull(class36);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertNotNull(collection41);
        org.junit.Assert.assertNotNull(class42);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertNotNull(class48);
        org.junit.Assert.assertNotNull(wildcardClass56);
        org.junit.Assert.assertNotNull(class57);
        org.junit.Assert.assertNotNull(timeSeries59);
        org.junit.Assert.assertNull(regularTimePeriod62);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 1900L + "'", long63 == 1900L);
        org.junit.Assert.assertNull(timeSeriesDataItem64);
        org.junit.Assert.assertNotNull(collection65);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + (-2177424000001L) + "'", long70 == (-2177424000001L));
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + (-2208960000000L) + "'", long71 == (-2208960000000L));
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + (-2193192000001L) + "'", long73 == (-2193192000001L));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        long long3 = year1.getSerialIndex();
        java.util.Date date4 = year1.getStart();
        long long5 = year1.getFirstMillisecond();
        java.lang.Object obj6 = null;
        int int7 = year1.compareTo(obj6);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass12 = month11.getClass();
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class13);
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries14.addPropertyChangeListener(propertyChangeListener15);
        int int17 = year1.compareTo((java.lang.Object) timeSeries14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year1.previous();
        java.lang.String str19 = year1.toString();
        org.junit.Assert.assertNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1900L + "'", long3 == 1900L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-2208960000000L) + "'", long5 == (-2208960000000L));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1900" + "'", str19.equals("1900"));
    }

//    @Test
//    public void test350() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test350");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getLastMillisecond(calendar1);
//        boolean boolean4 = fixedMillisecond0.equals((java.lang.Object) 1561964399999L);
//        long long5 = fixedMillisecond0.getSerialIndex();
//        java.util.Date date6 = fixedMillisecond0.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440456068L + "'", long2 == 1560440456068L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560440456068L + "'", long5 == 1560440456068L);
//        org.junit.Assert.assertNotNull(date6);
//    }

//    @Test
//    public void test351() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test351");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getLastMillisecond(calendar1);
//        boolean boolean4 = fixedMillisecond0.equals((java.lang.Object) 1561964399999L);
//        long long5 = fixedMillisecond0.getSerialIndex();
//        java.lang.Class<?> wildcardClass6 = fixedMillisecond0.getClass();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) 1560440367677L);
//        java.lang.Object obj9 = timeSeriesDataItem8.clone();
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.previous();
//        long long13 = year11.getSerialIndex();
//        java.util.Date date14 = year11.getStart();
//        long long15 = year11.getFirstMillisecond();
//        int int16 = year11.getYear();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        java.lang.Object obj18 = null;
//        boolean boolean19 = day17.equals(obj18);
//        java.lang.String str20 = day17.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day17.previous();
//        int int22 = year11.compareTo((java.lang.Object) day17);
//        int int23 = year11.getYear();
//        java.lang.String str24 = year11.toString();
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass29 = month28.getClass();
//        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class30);
//        timeSeries31.setDomainDescription("");
//        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass38 = month37.getClass();
//        java.lang.Class class39 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass38);
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440358934L, "hi!", "ThreadContext", class39);
//        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries31.addAndOrUpdate(timeSeries40);
//        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = year43.previous();
//        long long45 = year43.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries41.getDataItem((org.jfree.data.time.RegularTimePeriod) year43);
//        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(1900);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = year48.previous();
//        long long50 = year48.getSerialIndex();
//        java.util.Date date51 = year48.getStart();
//        long long52 = year48.getFirstMillisecond();
//        java.lang.Number number53 = timeSeries41.getValue((org.jfree.data.time.RegularTimePeriod) year48);
//        int int55 = year48.compareTo((java.lang.Object) 2147483647);
//        boolean boolean56 = year11.equals((java.lang.Object) year48);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = year48.previous();
//        boolean boolean58 = timeSeriesDataItem8.equals((java.lang.Object) regularTimePeriod57);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440456083L + "'", long2 == 1560440456083L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560440456083L + "'", long5 == 1560440456083L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNotNull(obj9);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1900L + "'", long13 == 1900L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-2208960000000L) + "'", long15 == (-2208960000000L));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1900 + "'", int16 == 1900);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "13-June-2019" + "'", str20.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1900 + "'", int23 == 1900);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1900" + "'", str24.equals("1900"));
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertNotNull(wildcardClass38);
//        org.junit.Assert.assertNotNull(class39);
//        org.junit.Assert.assertNotNull(timeSeries41);
//        org.junit.Assert.assertNull(regularTimePeriod44);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1900L + "'", long45 == 1900L);
//        org.junit.Assert.assertNull(timeSeriesDataItem46);
//        org.junit.Assert.assertNull(regularTimePeriod49);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1900L + "'", long50 == 1900L);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + (-2208960000000L) + "'", long52 == (-2208960000000L));
//        org.junit.Assert.assertNull(number53);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
//        org.junit.Assert.assertNull(regularTimePeriod57);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//    }
//}

