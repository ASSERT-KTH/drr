import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1);
        int int3 = timePeriodValues2.getMaxMiddleIndex();
        timePeriodValues2.setKey((java.lang.Comparable) false);
        timePeriodValues2.setDescription("");
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues2.createCopy((int) '4', (int) (byte) 100);
        timePeriodValues10.setDescription("");
        timePeriodValues10.setRangeDescription("Time");
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues10.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year17.previous();
        timePeriodValues10.setKey((java.lang.Comparable) regularTimePeriod18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year20.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod21);
        int int23 = timePeriodValues22.getMaxMiddleIndex();
        timePeriodValues22.setKey((java.lang.Comparable) false);
        timePeriodValues22.setDescription("");
        java.beans.PropertyChangeListener propertyChangeListener28 = null;
        timePeriodValues22.removePropertyChangeListener(propertyChangeListener28);
        boolean boolean30 = timePeriodValues22.getNotify();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = year31.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues33 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod32);
        int int34 = timePeriodValues33.getMaxMiddleIndex();
        timePeriodValues33.setKey((java.lang.Comparable) false);
        timePeriodValues33.setDescription("");
        int int39 = timePeriodValues33.getItemCount();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod42 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 1, (long) (byte) 1);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod45 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 1, (long) (byte) 1);
        long long46 = simpleTimePeriod45.getEndMillis();
        boolean boolean47 = simpleTimePeriod42.equals((java.lang.Object) simpleTimePeriod45);
        timePeriodValues33.add((org.jfree.data.time.TimePeriod) simpleTimePeriod42, 0.0d);
        timePeriodValues22.add((org.jfree.data.time.TimePeriod) simpleTimePeriod42, (java.lang.Number) 10L);
        boolean boolean52 = timePeriodValues10.equals((java.lang.Object) simpleTimePeriod42);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues10);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1L + "'", long46 == 1L);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1);
        int int3 = timePeriodValues2.getMaxMiddleIndex();
        timePeriodValues2.setKey((java.lang.Comparable) false);
        timePeriodValues2.setDescription("");
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues2.createCopy((int) '4', (int) (byte) 100);
        timePeriodValues10.setDescription("");
        timePeriodValues10.setRangeDescription("Time");
        java.lang.String str15 = timePeriodValues10.getDescription();
        java.lang.String str16 = timePeriodValues10.getDomainDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timePeriodValues10.addChangeListener(seriesChangeListener17);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues10);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        int int3 = day2.getMonth();
        java.lang.Object obj4 = null;
        boolean boolean5 = day2.equals(obj4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day2.previous();
        int int7 = day2.getMonth();
        java.lang.String str8 = day2.toString();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.util.Date date10 = year9.getStart();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.next();
        int int13 = day2.compareTo((java.lang.Object) day11);
        int int14 = day2.getMonth();
        java.lang.Class<?> wildcardClass15 = day2.getClass();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        java.util.Date date17 = year16.getStart();
        boolean boolean19 = year16.equals((java.lang.Object) "2019");
        long long20 = year16.getLastMillisecond();
        long long21 = year16.getSerialIndex();
        java.util.Date date22 = year16.getStart();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        java.util.Date date24 = year23.getStart();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day25.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day25.next();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year28.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod29);
        int int31 = timePeriodValues30.getMaxMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues34 = timePeriodValues30.createCopy(0, (int) (short) 0);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year35, (double) 100.0f);
        java.lang.Object obj38 = timePeriodValue37.clone();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod41 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 1, (long) (byte) 1);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = year42.previous();
        boolean boolean44 = simpleTimePeriod41.equals((java.lang.Object) year42);
        boolean boolean45 = timePeriodValue37.equals((java.lang.Object) year42);
        java.lang.Object obj46 = timePeriodValue37.clone();
        timePeriodValues34.add(timePeriodValue37);
        java.lang.Class<?> wildcardClass48 = timePeriodValue37.getClass();
        boolean boolean49 = day25.equals((java.lang.Object) timePeriodValue37);
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue52 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year50, (double) 100.0f);
        java.lang.String str53 = year50.toString();
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue56 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year54, (double) 100.0f);
        long long57 = year54.getFirstMillisecond();
        java.util.Date date58 = year54.getStart();
        java.lang.Class class59 = null;
        java.util.Date date60 = null;
        java.util.TimeZone timeZone61 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance(class59, date60, timeZone61);
        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day(date58, timeZone61);
        int int64 = year50.compareTo((java.lang.Object) date58);
        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue67 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year65, (double) 100.0f);
        long long68 = year65.getFirstMillisecond();
        java.util.Date date69 = year65.getStart();
        java.lang.Class class70 = null;
        java.util.Date date71 = null;
        java.util.TimeZone timeZone72 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = org.jfree.data.time.RegularTimePeriod.createInstance(class70, date71, timeZone72);
        org.jfree.data.time.Day day74 = new org.jfree.data.time.Day(date69, timeZone72);
        org.jfree.data.time.Year year75 = new org.jfree.data.time.Year(date58, timeZone72);
        boolean boolean76 = day25.equals((java.lang.Object) timeZone72);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date22, timeZone72);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1-January-2019" + "'", str8.equals("1-January-2019"));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1577865599999L + "'", long20 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2019L + "'", long21 == 2019L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues34);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(obj46);
        org.junit.Assert.assertNotNull(wildcardClass48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "2019" + "'", str53.equals("2019"));
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1546329600000L + "'", long57 == 1546329600000L);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertNotNull(timeZone61);
        org.junit.Assert.assertNull(regularTimePeriod62);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 1546329600000L + "'", long68 == 1546329600000L);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertNotNull(timeZone72);
        org.junit.Assert.assertNull(regularTimePeriod73);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod77);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("TimePeriodValue[1-January-2019,8]");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.general.SeriesException: 1-January-2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1);
        int int3 = timePeriodValues2.getMaxMiddleIndex();
        timePeriodValues2.setKey((java.lang.Comparable) false);
        timePeriodValues2.setDescription("");
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues2.createCopy((int) '4', (int) (byte) 100);
        timePeriodValues10.setDescription("");
        timePeriodValues10.setRangeDescription("Time");
        java.lang.String str15 = timePeriodValues10.getDescription();
        java.lang.String str16 = timePeriodValues10.getDomainDescription();
        int int17 = timePeriodValues10.getMaxStartIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues10);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        boolean boolean4 = day2.equals((java.lang.Object) 1.0f);
        org.jfree.data.time.SerialDate serialDate5 = day2.getSerialDate();
        java.lang.String str6 = day2.toString();
        int int7 = day2.getDayOfMonth();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1-January-2019" + "'", str6.equals("1-January-2019"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 1, (long) (byte) 1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year3.previous();
        boolean boolean5 = simpleTimePeriod2.equals((java.lang.Object) year3);
        int int6 = year3.getYear();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.util.Date date8 = year7.getStart();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.util.Date date10 = year9.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(date8, date10);
        boolean boolean12 = year3.equals((java.lang.Object) date10);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date10);
        long long14 = day13.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day13, (double) 1);
        int int17 = day13.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate18 = day13.getSerialDate();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year19.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod20);
        int int22 = timePeriodValues21.getMaxMiddleIndex();
        timePeriodValues21.setKey((java.lang.Comparable) false);
        java.lang.Comparable comparable25 = timePeriodValues21.getKey();
        timePeriodValues21.setRangeDescription("");
        boolean boolean28 = day13.equals((java.lang.Object) timePeriodValues21);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + comparable25 + "' != '" + false + "'", comparable25.equals(false));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1);
        int int3 = timePeriodValues2.getMaxMiddleIndex();
        int int4 = timePeriodValues2.getMinMiddleIndex();
        timePeriodValues2.setDescription("hi!");
        int int7 = timePeriodValues2.getMinEndIndex();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues2.removePropertyChangeListener(propertyChangeListener8);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 100.0f);
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        java.lang.Object obj5 = null;
        boolean boolean6 = year0.equals(obj5);
        long long7 = year0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year0.previous();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = year0.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 100.0f);
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        java.util.Date date5 = year0.getEnd();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year6, (double) 100.0f);
        long long9 = year6.getFirstMillisecond();
        java.util.Date date10 = year6.getStart();
        java.lang.Class class11 = null;
        java.util.Date date12 = null;
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date12, timeZone13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date10, timeZone13);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date5, timeZone13);
        java.lang.Class class17 = null;
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        java.util.Date date19 = year18.getStart();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.util.Date date21 = year20.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(date19, date21);
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date19, timeZone23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date5, timeZone23);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue28 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year26, (double) 100.0f);
        java.lang.String str29 = year26.toString();
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue32 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year30, (double) 100.0f);
        long long33 = year30.getFirstMillisecond();
        java.util.Date date34 = year30.getStart();
        java.lang.Class class35 = null;
        java.util.Date date36 = null;
        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class35, date36, timeZone37);
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date34, timeZone37);
        int int40 = year26.compareTo((java.lang.Object) date34);
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue43 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year41, (double) 100.0f);
        long long44 = year41.getFirstMillisecond();
        java.util.Date date45 = year41.getStart();
        java.lang.Class class46 = null;
        java.util.Date date47 = null;
        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance(class46, date47, timeZone48);
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date45, timeZone48);
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year(date34, timeZone48);
        java.util.Date date52 = year51.getEnd();
        java.lang.Class class53 = null;
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue56 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year54, (double) 100.0f);
        long long57 = year54.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = year54.next();
        java.util.Date date59 = year54.getEnd();
        java.lang.Class class60 = null;
        java.util.Date date61 = null;
        java.util.TimeZone timeZone62 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance(class60, date61, timeZone62);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = org.jfree.data.time.RegularTimePeriod.createInstance(class53, date59, timeZone62);
        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day(date52, timeZone62);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent66 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date52);
        java.lang.Class class67 = null;
        org.jfree.data.time.Year year68 = new org.jfree.data.time.Year();
        java.util.Date date69 = year68.getStart();
        org.jfree.data.time.Year year70 = new org.jfree.data.time.Year();
        java.util.Date date71 = year70.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod72 = new org.jfree.data.time.SimpleTimePeriod(date69, date71);
        java.util.TimeZone timeZone73 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = org.jfree.data.time.RegularTimePeriod.createInstance(class67, date69, timeZone73);
        org.jfree.data.time.Day day75 = new org.jfree.data.time.Day(date52, timeZone73);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod76 = new org.jfree.data.time.SimpleTimePeriod(date5, date52);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "2019" + "'", str29.equals("2019"));
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1546329600000L + "'", long33 == 1546329600000L);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertNull(regularTimePeriod38);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1546329600000L + "'", long44 == 1546329600000L);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(timeZone48);
        org.junit.Assert.assertNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1546329600000L + "'", long57 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNotNull(timeZone62);
        org.junit.Assert.assertNull(regularTimePeriod63);
        org.junit.Assert.assertNull(regularTimePeriod64);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertNotNull(timeZone73);
        org.junit.Assert.assertNull(regularTimePeriod74);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1);
        int int3 = timePeriodValues2.getMaxMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues2.createCopy(0, (int) (short) 0);
        int int7 = timePeriodValues6.getItemCount();
        timePeriodValues6.setDomainDescription("2019");
        boolean boolean10 = timePeriodValues6.getNotify();
        int int11 = timePeriodValues6.getMaxMiddleIndex();
        timePeriodValues6.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=2018]");
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1);
        int int3 = timePeriodValues2.getMaxMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues2.createCopy(0, (int) (short) 0);
        int int7 = timePeriodValues6.getItemCount();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues6.addChangeListener(seriesChangeListener8);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timePeriodValues6.removeChangeListener(seriesChangeListener10);
        int int12 = timePeriodValues6.getItemCount();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = timePeriodValues6.createCopy((int) '4', (int) (short) 100);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 1, (long) (byte) 1);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year19.previous();
        boolean boolean21 = simpleTimePeriod18.equals((java.lang.Object) year19);
        int int22 = year19.getYear();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        java.util.Date date24 = year23.getStart();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        java.util.Date date26 = year25.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod(date24, date26);
        boolean boolean28 = year19.equals((java.lang.Object) date26);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date26);
        timePeriodValues15.add((org.jfree.data.time.TimePeriod) day29, (java.lang.Number) 1577865599999L);
        java.lang.String str32 = timePeriodValues15.getDomainDescription();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(timePeriodValues15);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Time" + "'", str32.equals("Time"));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1);
        int int3 = timePeriodValues2.getMaxMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues2.createCopy(0, (int) (short) 0);
        int int7 = timePeriodValues6.getItemCount();
        timePeriodValues6.setDomainDescription("2019");
        boolean boolean10 = timePeriodValues6.getNotify();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues6.createCopy((int) (short) -1, (int) (byte) 0);
        int int14 = timePeriodValues6.getMinMiddleIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(timePeriodValues13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1);
        int int3 = timePeriodValues2.getMaxMiddleIndex();
        timePeriodValues2.setKey((java.lang.Comparable) false);
        timePeriodValues2.setDescription("");
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues2.createCopy((int) '4', (int) (byte) 100);
        java.lang.Comparable comparable11 = timePeriodValues2.getKey();
        int int12 = timePeriodValues2.getMinEndIndex();
        int int13 = timePeriodValues2.getMinMiddleIndex();
        timePeriodValues2.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: TimePeriodValue[1-January-2019,35.0]");
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues10);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + false + "'", comparable11.equals(false));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1);
        int int3 = timePeriodValues2.getMaxMiddleIndex();
        int int4 = timePeriodValues2.getMinMiddleIndex();
        timePeriodValues2.setDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues2.removeChangeListener(seriesChangeListener7);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 1, (long) (byte) 1);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.previous();
        boolean boolean14 = simpleTimePeriod11.equals((java.lang.Object) year12);
        timePeriodValues2.add((org.jfree.data.time.TimePeriod) simpleTimePeriod11, (java.lang.Number) (byte) -1);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year17.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year17.next();
        long long20 = year17.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year17.previous();
        int int22 = simpleTimePeriod11.compareTo((java.lang.Object) regularTimePeriod21);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2019L + "'", long20 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1);
        int int3 = timePeriodValues2.getMaxMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues2.createCopy(0, (int) (short) 0);
        int int7 = timePeriodValues6.getItemCount();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues6.addChangeListener(seriesChangeListener8);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timePeriodValues6.removeChangeListener(seriesChangeListener10);
        int int12 = timePeriodValues6.getItemCount();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = timePeriodValues6.createCopy((int) '4', (int) (short) 100);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 1, (long) (byte) 1);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year19.previous();
        boolean boolean21 = simpleTimePeriod18.equals((java.lang.Object) year19);
        int int22 = year19.getYear();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        java.util.Date date24 = year23.getStart();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        java.util.Date date26 = year25.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod(date24, date26);
        boolean boolean28 = year19.equals((java.lang.Object) date26);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date26);
        timePeriodValues15.add((org.jfree.data.time.TimePeriod) day29, (java.lang.Number) 1577865599999L);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod34 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 1, (long) (byte) 1);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year35.previous();
        boolean boolean37 = simpleTimePeriod34.equals((java.lang.Object) year35);
        int int38 = year35.getYear();
        timePeriodValues15.setKey((java.lang.Comparable) int38);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year40.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues42 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod41);
        int int43 = timePeriodValues42.getMaxMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues46 = timePeriodValues42.createCopy(0, (int) (short) 0);
        int int47 = timePeriodValues46.getItemCount();
        timePeriodValues46.setDomainDescription("2019");
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue52 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year50, (double) 100.0f);
        long long53 = year50.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = year50.next();
        java.util.Date date55 = year50.getEnd();
        boolean boolean56 = timePeriodValues46.equals((java.lang.Object) year50);
        int int58 = year50.compareTo((java.lang.Object) 100.0f);
        long long59 = year50.getFirstMillisecond();
        timePeriodValues15.add((org.jfree.data.time.TimePeriod) year50, (-1.0d));
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(timePeriodValues15);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2019 + "'", int38 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1546329600000L + "'", long53 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod54);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 1546329600000L + "'", long59 == 1546329600000L);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day2.next();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day2);
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day2, 0.0d);
        java.lang.String str7 = timePeriodValue6.toString();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "TimePeriodValue[1-January-2019,0.0]" + "'", str7.equals("TimePeriodValue[1-January-2019,0.0]"));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1);
        int int3 = timePeriodValues2.getMaxMiddleIndex();
        int int4 = timePeriodValues2.getMinMiddleIndex();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        java.util.Date date6 = year5.getStart();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day7);
        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (double) (byte) 10);
        timePeriodValue11.setValue((java.lang.Number) (byte) 1);
        java.lang.String str14 = timePeriodValue11.toString();
        java.lang.Object obj15 = timePeriodValue11.clone();
        timePeriodValues2.add(timePeriodValue11);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timePeriodValues2.addPropertyChangeListener(propertyChangeListener17);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "TimePeriodValue[1-January-2019,1]" + "'", str14.equals("TimePeriodValue[1-January-2019,1]"));
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1);
        int int3 = timePeriodValues2.getMaxMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues2.createCopy(0, (int) (short) 0);
        int int7 = timePeriodValues6.getItemCount();
        timePeriodValues6.setDomainDescription("2019");
        boolean boolean10 = timePeriodValues6.getNotify();
        int int11 = timePeriodValues6.getMaxMiddleIndex();
        boolean boolean12 = timePeriodValues6.getNotify();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(4, (int) 'a', (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.data.time.TimePeriod timePeriod0 = null;
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue(timePeriod0, (java.lang.Number) 10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        long long5 = day2.getFirstMillisecond();
        org.jfree.data.time.SerialDate serialDate6 = day2.getSerialDate();
        java.util.Calendar calendar7 = null;
        try {
            day2.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertNotNull(serialDate6);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        boolean boolean3 = year0.equals((java.lang.Object) "2019");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod5);
        int int7 = timePeriodValues6.getMaxMiddleIndex();
        int int8 = year0.compareTo((java.lang.Object) timePeriodValues6);
        int int9 = timePeriodValues6.getMinMiddleIndex();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.lang.Class<?> wildcardClass3 = year0.getClass();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod5);
        int int7 = timePeriodValues6.getMaxMiddleIndex();
        java.lang.Object obj8 = null;
        boolean boolean9 = timePeriodValues6.equals(obj8);
        java.lang.String str10 = timePeriodValues6.getDomainDescription();
        int int11 = timePeriodValues6.getMinMiddleIndex();
        timePeriodValues6.fireSeriesChanged();
        boolean boolean13 = year0.equals((java.lang.Object) timePeriodValues6);
        java.util.Date date14 = year0.getStart();
        long long15 = year0.getLastMillisecond();
        java.util.Calendar calendar16 = null;
        try {
            long long17 = year0.getFirstMillisecond(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Time" + "'", str10.equals("Time"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1);
        int int3 = timePeriodValues2.getMaxMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues2.createCopy(0, (int) (short) 0);
        boolean boolean7 = timePeriodValues2.getNotify();
        timePeriodValues2.delete(11, 2);
        int int11 = timePeriodValues2.getMaxEndIndex();
        int int12 = timePeriodValues2.getMinMiddleIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: 1-January-2019");
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) true);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getStart();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day4);
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, (double) (byte) 10);
        timePeriodValue8.setValue((java.lang.Number) (byte) 1);
        java.lang.String str11 = timePeriodValue8.toString();
        timePeriodValues1.add(timePeriodValue8);
        timePeriodValues1.setDomainDescription("hi!");
        try {
            org.jfree.data.time.TimePeriod timePeriod16 = timePeriodValues1.getTimePeriod((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "TimePeriodValue[1-January-2019,1]" + "'", str11.equals("TimePeriodValue[1-January-2019,1]"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = seriesException1.getSuppressed();
        java.lang.Throwable[] throwableArray4 = seriesException1.getSuppressed();
        java.lang.String str5 = seriesException1.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str5.equals("org.jfree.data.general.SeriesException: hi!"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1);
        int int3 = timePeriodValues2.getMaxMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues2.createCopy(0, (int) (short) 0);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) 100.0f);
        java.lang.Object obj10 = timePeriodValue9.clone();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 1, (long) (byte) 1);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.previous();
        boolean boolean16 = simpleTimePeriod13.equals((java.lang.Object) year14);
        boolean boolean17 = timePeriodValue9.equals((java.lang.Object) year14);
        java.lang.Object obj18 = timePeriodValue9.clone();
        timePeriodValues6.add(timePeriodValue9);
        int int20 = timePeriodValues6.getMinMiddleIndex();
        int int21 = timePeriodValues6.getMaxStartIndex();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year22.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues24 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod23);
        int int25 = timePeriodValues24.getMaxMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = timePeriodValues24.createCopy(0, (int) (short) 0);
        int int29 = timePeriodValues28.getItemCount();
        timePeriodValues28.setDomainDescription("2019");
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue34 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year32, (double) 100.0f);
        long long35 = year32.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year32.next();
        java.util.Date date37 = year32.getEnd();
        boolean boolean38 = timePeriodValues28.equals((java.lang.Object) year32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year32.previous();
        timePeriodValues6.setKey((java.lang.Comparable) year32);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1546329600000L + "'", long35 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1);
        int int3 = timePeriodValues2.getMaxMiddleIndex();
        timePeriodValues2.setKey((java.lang.Comparable) false);
        timePeriodValues2.setDescription("");
        int int8 = timePeriodValues2.getItemCount();
        int int9 = timePeriodValues2.getMaxEndIndex();
        java.lang.Object obj10 = timePeriodValues2.clone();
        int int11 = timePeriodValues2.getMaxMiddleIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1);
        int int3 = timePeriodValues2.getMaxMiddleIndex();
        java.lang.Comparable comparable4 = timePeriodValues2.getKey();
        java.lang.Object obj5 = timePeriodValues2.clone();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(comparable4);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 1, (long) (byte) 1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year3.previous();
        boolean boolean5 = simpleTimePeriod2.equals((java.lang.Object) year3);
        int int6 = year3.getYear();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.util.Date date8 = year7.getStart();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.util.Date date10 = year9.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(date8, date10);
        boolean boolean12 = year3.equals((java.lang.Object) date10);
        java.util.Date date13 = year3.getEnd();
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date13);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1);
        int int3 = timePeriodValues2.getMaxMiddleIndex();
        java.lang.Object obj4 = null;
        boolean boolean5 = timePeriodValues2.equals(obj4);
        timePeriodValues2.fireSeriesChanged();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.util.Date date8 = year7.getStart();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day9.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day9.next();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod13);
        int int15 = timePeriodValues14.getMaxMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = timePeriodValues14.createCopy(0, (int) (short) 0);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year19, (double) 100.0f);
        java.lang.Object obj22 = timePeriodValue21.clone();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod25 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 1, (long) (byte) 1);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year26.previous();
        boolean boolean28 = simpleTimePeriod25.equals((java.lang.Object) year26);
        boolean boolean29 = timePeriodValue21.equals((java.lang.Object) year26);
        java.lang.Object obj30 = timePeriodValue21.clone();
        timePeriodValues18.add(timePeriodValue21);
        java.lang.Class<?> wildcardClass32 = timePeriodValue21.getClass();
        boolean boolean33 = day9.equals((java.lang.Object) timePeriodValue21);
        timePeriodValues2.add(timePeriodValue21);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues18);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 100.0f);
        java.lang.String str3 = year0.toString();
        long long4 = year0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) true);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getStart();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day4);
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, (double) (byte) 10);
        timePeriodValue8.setValue((java.lang.Number) (byte) 1);
        java.lang.String str11 = timePeriodValue8.toString();
        timePeriodValues1.add(timePeriodValue8);
        boolean boolean13 = timePeriodValues1.getNotify();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "TimePeriodValue[1-January-2019,1]" + "'", str11.equals("TimePeriodValue[1-January-2019,1]"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1);
        int int3 = timePeriodValues2.getMaxMiddleIndex();
        timePeriodValues2.setKey((java.lang.Comparable) false);
        java.lang.Comparable comparable6 = timePeriodValues2.getKey();
        java.lang.String str7 = timePeriodValues2.getRangeDescription();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getStart();
        boolean boolean11 = year8.equals((java.lang.Object) "2019");
        long long12 = year8.getSerialIndex();
        int int13 = year8.getYear();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year8);
        timePeriodValues2.add((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 0.0d);
        java.util.Calendar calendar17 = null;
        try {
            year8.peg(calendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + false + "'", comparable6.equals(false));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getStart();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
        long long7 = day5.getFirstMillisecond();
        int int8 = year0.compareTo((java.lang.Object) day5);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1);
        int int3 = timePeriodValues2.getMaxMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues2.createCopy(0, (int) (short) 0);
        int int7 = timePeriodValues6.getItemCount();
        timePeriodValues6.setDomainDescription("2019");
        boolean boolean10 = timePeriodValues6.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues6.addChangeListener(seriesChangeListener11);
        int int13 = timePeriodValues6.getMinEndIndex();
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timePeriodValues6.removePropertyChangeListener(propertyChangeListener14);
        timePeriodValues6.setDomainDescription("TimePeriodValue[1-January-2019,35.0]");
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, (int) (short) 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        int int3 = day2.getMonth();
        java.lang.Object obj4 = null;
        boolean boolean5 = day2.equals(obj4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day2.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day2.next();
        int int8 = day2.getMonth();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        boolean boolean3 = year0.equals((java.lang.Object) "2019");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod5);
        int int7 = timePeriodValues6.getMaxMiddleIndex();
        int int8 = year0.compareTo((java.lang.Object) timePeriodValues6);
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 7);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesChangeEvent[source=false]");
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        seriesException5.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        seriesException3.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException3);
        java.lang.Throwable[] throwableArray11 = seriesException3.getSuppressed();
        java.lang.Throwable[] throwableArray12 = seriesException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertNotNull(throwableArray12);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 100.0f);
        java.lang.Number number3 = null;
        timePeriodValue2.setValue(number3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod6);
        int int8 = timePeriodValues7.getMaxMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = timePeriodValues7.createCopy(0, (int) (short) 0);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year12, (double) 100.0f);
        java.lang.Object obj15 = timePeriodValue14.clone();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 1, (long) (byte) 1);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year19.previous();
        boolean boolean21 = simpleTimePeriod18.equals((java.lang.Object) year19);
        boolean boolean22 = timePeriodValue14.equals((java.lang.Object) year19);
        java.lang.Object obj23 = timePeriodValue14.clone();
        timePeriodValues11.add(timePeriodValue14);
        int int25 = timePeriodValues11.getMinStartIndex();
        boolean boolean26 = timePeriodValue2.equals((java.lang.Object) int25);
        timePeriodValue2.setValue((java.lang.Number) 1546329600000L);
        java.lang.Object obj29 = timePeriodValue2.clone();
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues11);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(obj29);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1);
        int int3 = timePeriodValues2.getMaxMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues2.createCopy(0, (int) (short) 0);
        int int7 = timePeriodValues6.getItemCount();
        timePeriodValues6.fireSeriesChanged();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues6.addChangeListener(seriesChangeListener9);
        timePeriodValues6.delete(100, (int) (byte) -1);
        int int14 = timePeriodValues6.getMinMiddleIndex();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue16 = timePeriodValues6.getDataItem(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        boolean boolean3 = year0.equals((java.lang.Object) "2019");
        long long4 = year0.getSerialIndex();
        int int5 = year0.getYear();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod7);
        int int9 = timePeriodValues8.getMaxMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = timePeriodValues8.createCopy(0, (int) (short) 0);
        int int13 = timePeriodValues12.getItemCount();
        timePeriodValues12.setDomainDescription("2019");
        boolean boolean16 = year0.equals((java.lang.Object) "2019");
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        java.util.Date date18 = year17.getStart();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        int int20 = day19.getMonth();
        java.lang.Object obj21 = null;
        boolean boolean22 = day19.equals(obj21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day19.previous();
        int int24 = day19.getMonth();
        long long25 = day19.getFirstMillisecond();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year26.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod27);
        int int29 = timePeriodValues28.getMaxMiddleIndex();
        java.lang.Object obj30 = null;
        boolean boolean31 = timePeriodValues28.equals(obj30);
        java.lang.String str32 = timePeriodValues28.getDomainDescription();
        int int33 = timePeriodValues28.getMinMiddleIndex();
        boolean boolean34 = timePeriodValues28.isEmpty();
        boolean boolean35 = day19.equals((java.lang.Object) boolean34);
        org.jfree.data.time.SerialDate serialDate36 = day19.getSerialDate();
        boolean boolean37 = year0.equals((java.lang.Object) day19);
        java.util.Calendar calendar38 = null;
        try {
            long long39 = day19.getLastMillisecond(calendar38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1546329600000L + "'", long25 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Time" + "'", str32.equals("Time"));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) '4', (int) (short) 10, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 1, (long) (byte) 1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year3.previous();
        boolean boolean5 = simpleTimePeriod2.equals((java.lang.Object) year3);
        java.util.Date date6 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) 100.0f);
        long long10 = year7.getFirstMillisecond();
        java.util.Date date11 = year7.getStart();
        java.lang.Class class12 = null;
        java.util.Date date13 = null;
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date13, timeZone14);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date11, timeZone14);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date6, timeZone14);
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day17, (java.lang.Number) 12L);
        long long20 = day17.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-14400001L) + "'", long20 == (-14400001L));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 100.0f);
        java.lang.Number number3 = null;
        timePeriodValue2.setValue(number3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod6);
        int int8 = timePeriodValues7.getMaxMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = timePeriodValues7.createCopy(0, (int) (short) 0);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year12, (double) 100.0f);
        java.lang.Object obj15 = timePeriodValue14.clone();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 1, (long) (byte) 1);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year19.previous();
        boolean boolean21 = simpleTimePeriod18.equals((java.lang.Object) year19);
        boolean boolean22 = timePeriodValue14.equals((java.lang.Object) year19);
        java.lang.Object obj23 = timePeriodValue14.clone();
        timePeriodValues11.add(timePeriodValue14);
        int int25 = timePeriodValues11.getMinStartIndex();
        boolean boolean26 = timePeriodValue2.equals((java.lang.Object) int25);
        timePeriodValue2.setValue((java.lang.Number) 1546329600000L);
        java.lang.String str29 = timePeriodValue2.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues11);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "TimePeriodValue[2019,1546329600000]" + "'", str29.equals("TimePeriodValue[2019,1546329600000]"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod6);
        int int8 = timePeriodValues7.getMaxMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = timePeriodValues7.createCopy(0, (int) (short) 0);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year12, (double) 100.0f);
        java.lang.Object obj15 = timePeriodValue14.clone();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 1, (long) (byte) 1);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year19.previous();
        boolean boolean21 = simpleTimePeriod18.equals((java.lang.Object) year19);
        boolean boolean22 = timePeriodValue14.equals((java.lang.Object) year19);
        java.lang.Object obj23 = timePeriodValue14.clone();
        timePeriodValues11.add(timePeriodValue14);
        java.lang.Class<?> wildcardClass25 = timePeriodValue14.getClass();
        boolean boolean26 = day2.equals((java.lang.Object) timePeriodValue14);
        java.lang.String str27 = timePeriodValue14.toString();
        java.lang.Number number28 = timePeriodValue14.getValue();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues11);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "TimePeriodValue[2019,100.0]" + "'", str27.equals("TimePeriodValue[2019,100.0]"));
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + 100.0d + "'", number28.equals(100.0d));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 100.0f);
        long long3 = year0.getMiddleMillisecond();
        java.lang.String str4 = year0.toString();
        java.util.Date date5 = year0.getEnd();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 100.0f);
        java.lang.String str3 = year0.toString();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (double) 100.0f);
        long long7 = year4.getFirstMillisecond();
        java.util.Date date8 = year4.getStart();
        java.lang.Class class9 = null;
        java.util.Date date10 = null;
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date10, timeZone11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date8, timeZone11);
        int int14 = year0.compareTo((java.lang.Object) date8);
        java.lang.Class class15 = null;
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        java.util.Date date17 = year16.getStart();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        java.util.Date date19 = year18.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod(date17, date19);
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date17, timeZone21);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date8, timeZone21);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNull(regularTimePeriod22);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getStart();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        int int5 = day4.getMonth();
        java.lang.Object obj6 = null;
        boolean boolean7 = day4.equals(obj6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day4.previous();
        int int9 = day4.getMonth();
        boolean boolean10 = year0.equals((java.lang.Object) day4);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, (java.lang.Number) 8);
        java.util.Calendar calendar13 = null;
        try {
            day4.peg(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod(date1, date3);
        java.util.Date date5 = simpleTimePeriod4.getEnd();
        java.lang.Class<?> wildcardClass6 = simpleTimePeriod4.getClass();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) true);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getStart();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day4);
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, (double) (byte) 10);
        timePeriodValue8.setValue((java.lang.Number) (byte) 1);
        java.lang.String str11 = timePeriodValue8.toString();
        timePeriodValues1.add(timePeriodValue8);
        timePeriodValues1.setDomainDescription("hi!");
        timePeriodValues1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=0]");
        timePeriodValues1.fireSeriesChanged();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "TimePeriodValue[1-January-2019,1]" + "'", str11.equals("TimePeriodValue[1-January-2019,1]"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1);
        int int3 = timePeriodValues2.getMaxMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues2.createCopy(0, (int) (short) 0);
        int int7 = timePeriodValues6.getItemCount();
        timePeriodValues6.setDomainDescription("2019");
        boolean boolean10 = timePeriodValues6.getNotify();
        int int11 = timePeriodValues6.getItemCount();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        java.util.Date date13 = year12.getStart();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day14.next();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day14);
        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day14, 0.0d);
        timePeriodValues6.add((org.jfree.data.time.TimePeriod) day14, (java.lang.Number) 5);
        long long21 = day14.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 43466L + "'", long21 == 43466L);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) (short) 10);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1);
        int int3 = timePeriodValues2.getMaxMiddleIndex();
        timePeriodValues2.setKey((java.lang.Comparable) false);
        java.lang.Comparable comparable6 = timePeriodValues2.getKey();
        java.lang.String str7 = timePeriodValues2.getDomainDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues2.removeChangeListener(seriesChangeListener8);
        java.lang.Comparable comparable10 = timePeriodValues2.getKey();
        timePeriodValues2.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=2018]");
        int int13 = timePeriodValues2.getMaxMiddleIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + false + "'", comparable6.equals(false));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + false + "'", comparable10.equals(false));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        int int5 = day2.getDayOfMonth();
        java.lang.Class<?> wildcardClass6 = day2.getClass();
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize(class7);
        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize(class7);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNotNull(class8);
        org.junit.Assert.assertNotNull(class9);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1);
        int int3 = timePeriodValues2.getMaxMiddleIndex();
        timePeriodValues2.setKey((java.lang.Comparable) false);
        timePeriodValues2.setDescription("");
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues2.createCopy((int) '4', (int) (byte) 100);
        timePeriodValues10.setDescription("");
        timePeriodValues10.setRangeDescription("Time");
        timePeriodValues10.setDomainDescription("TimePeriodValue[2019,1546415999999]");
        java.lang.String str17 = timePeriodValues10.getDescription();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues10);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1);
        int int3 = timePeriodValues2.getMaxMiddleIndex();
        timePeriodValues2.setKey((java.lang.Comparable) false);
        java.lang.Comparable comparable6 = timePeriodValues2.getKey();
        java.lang.String str7 = timePeriodValues2.getRangeDescription();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getStart();
        boolean boolean11 = year8.equals((java.lang.Object) "2019");
        long long12 = year8.getSerialIndex();
        int int13 = year8.getYear();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year8);
        timePeriodValues2.add((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 0.0d);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (double) 100.0f);
        long long20 = year17.getFirstMillisecond();
        java.util.Date date21 = year17.getStart();
        java.lang.Class class22 = null;
        java.util.Date date23 = null;
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date23, timeZone24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date21, timeZone24);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue29 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year27, (double) 100.0f);
        java.lang.Object obj30 = timePeriodValue29.clone();
        int int31 = day26.compareTo(obj30);
        org.jfree.data.time.SerialDate serialDate32 = day26.getSerialDate();
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(serialDate32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day33.previous();
        long long35 = day33.getSerialIndex();
        timePeriodValues2.setKey((java.lang.Comparable) day33);
        java.lang.Comparable comparable37 = timePeriodValues2.getKey();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + false + "'", comparable6.equals(false));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1546329600000L + "'", long20 == 1546329600000L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 43466L + "'", long35 == 43466L);
        org.junit.Assert.assertNotNull(comparable37);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Date date3 = year0.getEnd();
        long long4 = year0.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(7, 7, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 1, (long) (byte) 1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year3.previous();
        boolean boolean5 = simpleTimePeriod2.equals((java.lang.Object) year3);
        java.util.Date date6 = simpleTimePeriod2.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 1, (long) (byte) 1);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
        boolean boolean12 = simpleTimePeriod9.equals((java.lang.Object) year10);
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod9, (double) 10);
        java.util.Date date15 = simpleTimePeriod9.getStart();
        boolean boolean16 = simpleTimePeriod2.equals((java.lang.Object) date15);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1);
        int int3 = timePeriodValues2.getMaxMiddleIndex();
        timePeriodValues2.setKey((java.lang.Comparable) false);
        java.lang.Comparable comparable6 = timePeriodValues2.getKey();
        java.lang.String str7 = timePeriodValues2.getRangeDescription();
        try {
            timePeriodValues2.update(2019, (java.lang.Number) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2019, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + false + "'", comparable6.equals(false));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 100.0f);
        long long3 = year0.getFirstMillisecond();
        java.util.Date date4 = year0.getStart();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date4, timeZone7);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, (double) 100.0f);
        java.lang.Object obj13 = timePeriodValue12.clone();
        int int14 = day9.compareTo(obj13);
        org.jfree.data.time.SerialDate serialDate15 = day9.getSerialDate();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(serialDate15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day16.previous();
        long long18 = day16.getSerialIndex();
        java.lang.Object obj19 = null;
        boolean boolean20 = day16.equals(obj19);
        java.util.Calendar calendar21 = null;
        try {
            long long22 = day16.getMiddleMillisecond(calendar21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 43466L + "'", long18 == 43466L);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1);
        int int3 = timePeriodValues2.getMaxMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues2.createCopy(0, (int) (short) 0);
        int int7 = timePeriodValues6.getItemCount();
        int int8 = timePeriodValues6.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues6.removePropertyChangeListener(propertyChangeListener9);
        try {
            org.jfree.data.time.TimePeriod timePeriod12 = timePeriodValues6.getTimePeriod(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1);
        int int3 = timePeriodValues2.getMaxMiddleIndex();
        int int4 = timePeriodValues2.getMinMiddleIndex();
        timePeriodValues2.setDescription("hi!");
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.util.Date date8 = year7.getStart();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        boolean boolean11 = day9.equals((java.lang.Object) 1.0f);
        long long12 = day9.getFirstMillisecond();
        org.jfree.data.time.SerialDate serialDate13 = day9.getSerialDate();
        timePeriodValues2.add((org.jfree.data.time.TimePeriod) day9, (double) (short) 100);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        java.util.Date date17 = year16.getStart();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date17);
        boolean boolean20 = day18.equals((java.lang.Object) 1.0f);
        long long21 = day18.getFirstMillisecond();
        org.jfree.data.time.SerialDate serialDate22 = day18.getSerialDate();
        timePeriodValues2.add((org.jfree.data.time.TimePeriod) day18, (java.lang.Number) 12);
        timePeriodValues2.setRangeDescription("TimePeriodValue[2019,100.0]");
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1546329600000L + "'", long12 == 1546329600000L);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1546329600000L + "'", long21 == 1546329600000L);
        org.junit.Assert.assertNotNull(serialDate22);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1);
        int int3 = timePeriodValues2.getMaxMiddleIndex();
        timePeriodValues2.setKey((java.lang.Comparable) false);
        java.lang.Comparable comparable6 = timePeriodValues2.getKey();
        java.lang.String str7 = timePeriodValues2.getRangeDescription();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getStart();
        boolean boolean11 = year8.equals((java.lang.Object) "2019");
        long long12 = year8.getSerialIndex();
        int int13 = year8.getYear();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year8);
        timePeriodValues2.add((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 0.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year8.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + false + "'", comparable6.equals(false));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day2.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day2, (double) '#');
        java.lang.Class<?> wildcardClass6 = timePeriodValue5.getClass();
        java.lang.String str7 = timePeriodValue5.toString();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "TimePeriodValue[1-January-2019,35.0]" + "'", str7.equals("TimePeriodValue[1-January-2019,35.0]"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1);
        int int3 = timePeriodValues2.getMaxMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues2.createCopy(0, (int) (short) 0);
        int int7 = timePeriodValues6.getItemCount();
        timePeriodValues6.fireSeriesChanged();
        java.lang.String str9 = timePeriodValues6.getDescription();
        java.lang.String str10 = timePeriodValues6.getRangeDescription();
        java.lang.String str11 = timePeriodValues6.getDescription();
        timePeriodValues6.setNotify(false);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Value" + "'", str10.equals("Value"));
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day2.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day2, (double) '#');
        java.lang.String str6 = timePeriodValue5.toString();
        java.lang.Object obj7 = timePeriodValue5.clone();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "TimePeriodValue[1-January-2019,35.0]" + "'", str6.equals("TimePeriodValue[1-January-2019,35.0]"));
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1);
        int int3 = timePeriodValues2.getMaxMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues2.createCopy(0, (int) (short) 0);
        int int7 = timePeriodValues6.getItemCount();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues6.addChangeListener(seriesChangeListener8);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timePeriodValues6.removeChangeListener(seriesChangeListener10);
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues6.removePropertyChangeListener(propertyChangeListener12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.util.Date date15 = year14.getStart();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
        int int17 = day16.getMonth();
        java.lang.Object obj18 = null;
        boolean boolean19 = day16.equals(obj18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day16.previous();
        int int21 = day16.getYear();
        timePeriodValues6.add((org.jfree.data.time.TimePeriod) day16, (double) 1L);
        org.jfree.data.time.TimePeriodValues timePeriodValues24 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day16);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        long long4 = year3.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 100.0f);
        long long3 = year0.getFirstMillisecond();
        int int4 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.next();
        java.lang.String str6 = year0.toString();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1);
        int int3 = timePeriodValues2.getMaxMiddleIndex();
        timePeriodValues2.setKey((java.lang.Comparable) false);
        java.lang.String str6 = timePeriodValues2.getDomainDescription();
        boolean boolean7 = timePeriodValues2.isEmpty();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Time" + "'", str6.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=1]");
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 100.0f);
        java.lang.String str3 = year0.toString();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (double) 100.0f);
        long long7 = year4.getFirstMillisecond();
        java.util.Date date8 = year4.getStart();
        java.lang.Class class9 = null;
        java.util.Date date10 = null;
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date10, timeZone11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date8, timeZone11);
        int int14 = year0.compareTo((java.lang.Object) date8);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year15, (double) 100.0f);
        long long18 = year15.getFirstMillisecond();
        java.util.Date date19 = year15.getStart();
        java.lang.Class class20 = null;
        java.util.Date date21 = null;
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date21, timeZone22);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date19, timeZone22);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date8, timeZone22);
        java.util.Date date26 = year25.getEnd();
        java.lang.Class class27 = null;
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue30 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year28, (double) 100.0f);
        long long31 = year28.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = year28.next();
        java.util.Date date33 = year28.getEnd();
        java.lang.Class class34 = null;
        java.util.Date date35 = null;
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance(class34, date35, timeZone36);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date33, timeZone36);
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date26, timeZone36);
        long long40 = day39.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1546329600000L + "'", long18 == 1546329600000L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1546329600000L + "'", long31 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertNull(regularTimePeriod38);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1577865599999L + "'", long40 == 1577865599999L);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1);
        int int3 = timePeriodValues2.getMaxMiddleIndex();
        int int4 = timePeriodValues2.getMinMiddleIndex();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year5, (double) 100.0f);
        java.lang.Object obj8 = timePeriodValue7.clone();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 1, (long) (byte) 1);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.previous();
        boolean boolean14 = simpleTimePeriod11.equals((java.lang.Object) year12);
        boolean boolean15 = timePeriodValue7.equals((java.lang.Object) year12);
        java.lang.Number number16 = timePeriodValue7.getValue();
        timePeriodValues2.add(timePeriodValue7);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        java.util.Date date19 = year18.getStart();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day20.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day20.next();
        int int23 = day20.getDayOfMonth();
        java.lang.Class<?> wildcardClass24 = day20.getClass();
        long long25 = day20.getSerialIndex();
        timePeriodValues2.add((org.jfree.data.time.TimePeriod) day20, (java.lang.Number) 2019);
        timePeriodValues2.fireSeriesChanged();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 100.0d + "'", number16.equals(100.0d));
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 43466L + "'", long25 == 43466L);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 100.0f);
        long long3 = year0.getFirstMillisecond();
        java.util.Date date4 = year0.getStart();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date4, timeZone7);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, (double) 100.0f);
        java.lang.Object obj13 = timePeriodValue12.clone();
        int int14 = day9.compareTo(obj13);
        org.jfree.data.time.SerialDate serialDate15 = day9.getSerialDate();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        java.util.Date date17 = year16.getStart();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.next();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent20 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day18);
        java.lang.Object obj21 = seriesChangeEvent20.getSource();
        java.lang.Object obj22 = seriesChangeEvent20.getSource();
        boolean boolean23 = day9.equals((java.lang.Object) seriesChangeEvent20);
        org.jfree.data.time.SerialDate serialDate24 = day9.getSerialDate();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year25.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod26);
        int int28 = timePeriodValues27.getMaxMiddleIndex();
        java.lang.Object obj29 = null;
        boolean boolean30 = timePeriodValues27.equals(obj29);
        java.lang.String str31 = timePeriodValues27.getDomainDescription();
        int int32 = timePeriodValues27.getMinMiddleIndex();
        boolean boolean33 = timePeriodValues27.isEmpty();
        timePeriodValues27.setNotify(false);
        boolean boolean36 = day9.equals((java.lang.Object) false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Time" + "'", str31.equals("Time"));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1);
        int int3 = timePeriodValues2.getMaxMiddleIndex();
        java.lang.Object obj4 = null;
        boolean boolean5 = timePeriodValues2.equals(obj4);
        timePeriodValues2.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues2.addPropertyChangeListener(propertyChangeListener7);
        int int9 = timePeriodValues2.getMinEndIndex();
        boolean boolean10 = timePeriodValues2.isEmpty();
        java.lang.Comparable comparable11 = timePeriodValues2.getKey();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(comparable11);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day2.next();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = day2.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1);
        int int3 = timePeriodValues2.getMaxMiddleIndex();
        timePeriodValues2.setKey((java.lang.Comparable) false);
        timePeriodValues2.setDescription("");
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues2.createCopy((int) '4', (int) (byte) 100);
        timePeriodValues10.setDescription("");
        timePeriodValues10.setRangeDescription("Time");
        java.lang.String str15 = timePeriodValues10.getDescription();
        java.lang.Comparable comparable16 = timePeriodValues10.getKey();
        int int17 = timePeriodValues10.getMinStartIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues10);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + false + "'", comparable16.equals(false));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1);
        int int3 = timePeriodValues2.getMaxMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues2.createCopy(0, (int) (short) 0);
        int int7 = timePeriodValues6.getItemCount();
        timePeriodValues6.setDomainDescription("2019");
        boolean boolean10 = timePeriodValues6.getNotify();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues6.createCopy((int) (short) -1, (int) (byte) 0);
        int int14 = timePeriodValues6.getMinEndIndex();
        int int15 = timePeriodValues6.getMaxStartIndex();
        java.lang.String str16 = timePeriodValues6.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timePeriodValues6.addPropertyChangeListener(propertyChangeListener17);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(timePeriodValues13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2019" + "'", str16.equals("2019"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 1, (long) (byte) 1);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod5 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 1, (long) (byte) 1);
        long long6 = simpleTimePeriod5.getEndMillis();
        boolean boolean7 = simpleTimePeriod2.equals((java.lang.Object) simpleTimePeriod5);
        java.util.Date date8 = simpleTimePeriod2.getEnd();
        java.util.Date date9 = simpleTimePeriod2.getEnd();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 1, (long) (byte) 1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year3.previous();
        boolean boolean5 = simpleTimePeriod2.equals((java.lang.Object) year3);
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 10);
        java.lang.Class class8 = null;
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.util.Date date10 = year9.getStart();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date10, timeZone11);
        boolean boolean13 = simpleTimePeriod2.equals((java.lang.Object) class8);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 1, (long) (byte) 1);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year17.previous();
        boolean boolean19 = simpleTimePeriod16.equals((java.lang.Object) year17);
        int int20 = year17.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year17.next();
        boolean boolean22 = simpleTimePeriod2.equals((java.lang.Object) year17);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 1, (long) (byte) 1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year3.previous();
        boolean boolean5 = simpleTimePeriod2.equals((java.lang.Object) year3);
        java.util.Date date6 = simpleTimePeriod2.getStart();
        java.util.Date date7 = simpleTimePeriod2.getEnd();
        java.util.Date date8 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod10);
        int int12 = timePeriodValues11.getMaxMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = timePeriodValues11.createCopy(0, (int) (short) 0);
        boolean boolean16 = timePeriodValues11.getNotify();
        timePeriodValues11.delete(11, 2);
        int int20 = timePeriodValues11.getMaxEndIndex();
        java.lang.String str21 = timePeriodValues11.getDescription();
        boolean boolean22 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValues11);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 1, (long) (byte) 1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year3.previous();
        boolean boolean5 = simpleTimePeriod2.equals((java.lang.Object) year3);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod7);
        int int9 = timePeriodValues8.getMaxMiddleIndex();
        java.lang.String str10 = timePeriodValues8.getDescription();
        java.lang.Object obj11 = timePeriodValues8.clone();
        java.lang.String str12 = timePeriodValues8.getDomainDescription();
        try {
            int int13 = simpleTimePeriod2.compareTo((java.lang.Object) timePeriodValues8);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimePeriodValues cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1);
        int int3 = timePeriodValues2.getMaxMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues2.createCopy(0, (int) (short) 0);
        int int7 = timePeriodValues6.getItemCount();
        timePeriodValues6.setDomainDescription("2019");
        boolean boolean10 = timePeriodValues6.getNotify();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues6.createCopy((int) (short) -1, (int) (byte) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = timePeriodValues6.createCopy((int) 'a', 1);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(timePeriodValues13);
        org.junit.Assert.assertNotNull(timePeriodValues16);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.lang.Class<?> wildcardClass3 = year0.getClass();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod5);
        int int7 = timePeriodValues6.getMaxMiddleIndex();
        java.lang.Object obj8 = null;
        boolean boolean9 = timePeriodValues6.equals(obj8);
        java.lang.String str10 = timePeriodValues6.getDomainDescription();
        int int11 = timePeriodValues6.getMinMiddleIndex();
        timePeriodValues6.fireSeriesChanged();
        boolean boolean13 = year0.equals((java.lang.Object) timePeriodValues6);
        java.util.Calendar calendar14 = null;
        try {
            long long15 = year0.getMiddleMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Time" + "'", str10.equals("Time"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day2.next();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day2);
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day2, (double) (byte) 10);
        java.lang.Number number7 = timePeriodValue6.getValue();
        java.lang.Object obj8 = timePeriodValue6.clone();
        java.lang.Number number9 = timePeriodValue6.getValue();
        java.lang.String str10 = timePeriodValue6.toString();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 10.0d + "'", number7.equals(10.0d));
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 10.0d + "'", number9.equals(10.0d));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "TimePeriodValue[1-January-2019,10.0]" + "'", str10.equals("TimePeriodValue[1-January-2019,10.0]"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod6);
        int int8 = timePeriodValues7.getMaxMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = timePeriodValues7.createCopy(0, (int) (short) 0);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year12, (double) 100.0f);
        java.lang.Object obj15 = timePeriodValue14.clone();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 1, (long) (byte) 1);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year19.previous();
        boolean boolean21 = simpleTimePeriod18.equals((java.lang.Object) year19);
        boolean boolean22 = timePeriodValue14.equals((java.lang.Object) year19);
        java.lang.Object obj23 = timePeriodValue14.clone();
        timePeriodValues11.add(timePeriodValue14);
        java.lang.Class<?> wildcardClass25 = timePeriodValue14.getClass();
        boolean boolean26 = day2.equals((java.lang.Object) timePeriodValue14);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue29 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year27, (double) 100.0f);
        java.lang.String str30 = year27.toString();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue33 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year31, (double) 100.0f);
        long long34 = year31.getFirstMillisecond();
        java.util.Date date35 = year31.getStart();
        java.lang.Class class36 = null;
        java.util.Date date37 = null;
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance(class36, date37, timeZone38);
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date35, timeZone38);
        int int41 = year27.compareTo((java.lang.Object) date35);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue44 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year42, (double) 100.0f);
        long long45 = year42.getFirstMillisecond();
        java.util.Date date46 = year42.getStart();
        java.lang.Class class47 = null;
        java.util.Date date48 = null;
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance(class47, date48, timeZone49);
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date46, timeZone49);
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(date35, timeZone49);
        boolean boolean53 = day2.equals((java.lang.Object) timeZone49);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = day2.next();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues11);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2019" + "'", str30.equals("2019"));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1546329600000L + "'", long34 == 1546329600000L);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1546329600000L + "'", long45 == 1546329600000L);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNull(regularTimePeriod50);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod54);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 1, (long) (byte) 1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year3.previous();
        boolean boolean5 = simpleTimePeriod2.equals((java.lang.Object) year3);
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 10);
        java.util.Date date8 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.util.Date date10 = year9.getStart();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.next();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent13 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day11);
        long long14 = day11.getSerialIndex();
        int int15 = simpleTimePeriod2.compareTo((java.lang.Object) day11);
        java.util.Calendar calendar16 = null;
        try {
            long long17 = day11.getMiddleMillisecond(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 43466L + "'", long14 == 43466L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        java.lang.Class class0 = null;
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.util.Date date2 = year1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        java.util.Date date5 = year4.getStart();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date5, timeZone6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone6);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date2);
        java.lang.String str10 = year9.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.next();
        long long12 = year9.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1562097599999L + "'", long12 == 1562097599999L);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        java.lang.Class class0 = null;
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.util.Date date2 = year1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        java.util.Date date5 = year4.getStart();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date5, timeZone6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone6);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.util.Date date10 = year9.getStart();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        java.util.Date date12 = year11.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(date10, date12);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date2, date10);
        java.util.Date date15 = simpleTimePeriod14.getStart();
        long long16 = simpleTimePeriod14.getStartMillis();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1546329600000L + "'", long16 == 1546329600000L);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 100.0f);
        int int3 = year0.getYear();
        long long4 = year0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.SerialDate serialDate5 = day4.getSerialDate();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate5);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1);
        int int3 = timePeriodValues2.getMaxMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues2.createCopy(0, (int) (short) 0);
        int int7 = timePeriodValues6.getItemCount();
        timePeriodValues6.fireSeriesChanged();
        java.lang.String str9 = timePeriodValues6.getDescription();
        int int10 = timePeriodValues6.getMaxEndIndex();
        int int11 = timePeriodValues6.getMinEndIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1);
        int int3 = timePeriodValues2.getMaxMiddleIndex();
        int int4 = timePeriodValues2.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues2.addChangeListener(seriesChangeListener5);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues2.removeChangeListener(seriesChangeListener7);
        int int9 = timePeriodValues2.getMaxStartIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 1, (long) (byte) 1);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod5 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 1, (long) (byte) 1);
        long long6 = simpleTimePeriod5.getEndMillis();
        boolean boolean7 = simpleTimePeriod2.equals((java.lang.Object) simpleTimePeriod5);
        java.util.Date date8 = simpleTimePeriod2.getEnd();
        boolean boolean10 = simpleTimePeriod2.equals((java.lang.Object) "org.jfree.data.general.SeriesException: 1-January-2019");
        long long11 = simpleTimePeriod2.getEndMillis();
        long long12 = simpleTimePeriod2.getStartMillis();
        long long13 = simpleTimePeriod2.getEndMillis();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        int int3 = day2.getMonth();
        java.lang.Object obj4 = null;
        boolean boolean5 = day2.equals(obj4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day2.previous();
        int int7 = day2.getMonth();
        java.util.Date date8 = day2.getEnd();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1);
        int int3 = timePeriodValues2.getMaxMiddleIndex();
        int int4 = timePeriodValues2.getMinMiddleIndex();
        timePeriodValues2.setDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues2.removeChangeListener(seriesChangeListener7);
        int int9 = timePeriodValues2.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues2.removePropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year12, (double) 100.0f);
        java.lang.String str15 = year12.toString();
        long long16 = year12.getSerialIndex();
        timePeriodValues2.add((org.jfree.data.time.TimePeriod) year12, (double) (-1L));
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year19, (double) 100.0f);
        long long22 = year19.getFirstMillisecond();
        long long23 = year19.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue25 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year19, (double) 1546329600000L);
        java.lang.String str26 = timePeriodValue25.toString();
        timePeriodValues2.add(timePeriodValue25);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1546329600000L + "'", long22 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 2019L + "'", long23 == 2019L);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "TimePeriodValue[2019,1.5463296E12]" + "'", str26.equals("TimePeriodValue[2019,1.5463296E12]"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 100.0f);
        long long3 = year0.getFirstMillisecond();
        int int4 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.next();
        long long6 = year0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 100.0f);
        long long3 = year0.getFirstMillisecond();
        java.util.Date date4 = year0.getStart();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date4, timeZone7);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, (double) 100.0f);
        java.lang.Object obj13 = timePeriodValue12.clone();
        int int14 = day9.compareTo(obj13);
        org.jfree.data.time.SerialDate serialDate15 = day9.getSerialDate();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(serialDate15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day16.previous();
        long long18 = day16.getSerialIndex();
        int int19 = day16.getYear();
        int int20 = day16.getYear();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 43466L + "'", long18 == 43466L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        boolean boolean4 = day2.equals((java.lang.Object) 1.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day2.previous();
        org.jfree.data.time.SerialDate serialDate6 = day2.getSerialDate();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(serialDate6);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 7, (long) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class<?> wildcardClass2 = year0.getClass();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1);
        int int3 = timePeriodValues2.getMaxMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues2.createCopy(0, (int) (short) 0);
        int int7 = timePeriodValues6.getItemCount();
        timePeriodValues6.setDomainDescription("2019");
        boolean boolean10 = timePeriodValues6.getNotify();
        int int11 = timePeriodValues6.getItemCount();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        java.util.Date date13 = year12.getStart();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day14.next();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day14);
        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day14, 0.0d);
        timePeriodValues6.add((org.jfree.data.time.TimePeriod) day14, (java.lang.Number) 5);
        java.lang.String str21 = day14.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1-January-2019" + "'", str21.equals("1-January-2019"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1);
        int int3 = timePeriodValues2.getMaxMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues2.createCopy(0, (int) (short) 0);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) 100.0f);
        java.lang.Object obj10 = timePeriodValue9.clone();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 1, (long) (byte) 1);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.previous();
        boolean boolean16 = simpleTimePeriod13.equals((java.lang.Object) year14);
        boolean boolean17 = timePeriodValue9.equals((java.lang.Object) year14);
        java.lang.Object obj18 = timePeriodValue9.clone();
        timePeriodValues6.add(timePeriodValue9);
        int int20 = timePeriodValues6.getMinStartIndex();
        timePeriodValues6.setDomainDescription("");
        try {
            org.jfree.data.time.TimePeriod timePeriod24 = timePeriodValues6.getTimePeriod(2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2019, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1);
        int int3 = timePeriodValues2.getMaxMiddleIndex();
        timePeriodValues2.setKey((java.lang.Comparable) false);
        java.lang.Comparable comparable6 = timePeriodValues2.getKey();
        java.lang.String str7 = timePeriodValues2.getRangeDescription();
        boolean boolean8 = timePeriodValues2.isEmpty();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + false + "'", comparable6.equals(false));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        boolean boolean4 = day2.equals((java.lang.Object) 1.0f);
        org.jfree.data.time.SerialDate serialDate5 = day2.getSerialDate();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate5);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getStart();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date9);
        int int11 = day10.getMonth();
        java.lang.Object obj12 = null;
        boolean boolean13 = day10.equals(obj12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day10.previous();
        int int15 = day10.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day10.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day10.previous();
        boolean boolean18 = day7.equals((java.lang.Object) day10);
        java.util.Calendar calendar19 = null;
        try {
            long long20 = day7.getMiddleMillisecond(calendar19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1);
        int int3 = timePeriodValues2.getMaxMiddleIndex();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (double) 100.0f);
        java.lang.Number number7 = null;
        timePeriodValue6.setValue(number7);
        java.lang.Number number9 = timePeriodValue6.getValue();
        java.lang.Object obj10 = null;
        boolean boolean11 = timePeriodValue6.equals(obj10);
        java.lang.Number number12 = timePeriodValue6.getValue();
        timePeriodValues2.add(timePeriodValue6);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 1, (long) (byte) 1);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 1, (long) (byte) 1);
        long long20 = simpleTimePeriod19.getEndMillis();
        boolean boolean21 = simpleTimePeriod16.equals((java.lang.Object) simpleTimePeriod19);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        java.util.Date date23 = year22.getStart();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        java.util.Date date25 = year24.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod(date23, date25);
        boolean boolean27 = simpleTimePeriod16.equals((java.lang.Object) date25);
        timePeriodValues2.setKey((java.lang.Comparable) simpleTimePeriod16);
        org.jfree.data.time.TimePeriodValue timePeriodValue30 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod16, (double) 0L);
        long long31 = simpleTimePeriod16.getEndMillis();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1L + "'", long20 == 1L);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1L + "'", long31 == 1L);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1);
        int int3 = timePeriodValues2.getMaxMiddleIndex();
        timePeriodValues2.setKey((java.lang.Comparable) false);
        int int6 = timePeriodValues2.getItemCount();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.util.Date date8 = year7.getStart();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day9.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day9.next();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod13);
        int int15 = timePeriodValues14.getMaxMiddleIndex();
        timePeriodValues14.setKey((java.lang.Comparable) false);
        java.lang.Comparable comparable18 = timePeriodValues14.getKey();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) comparable18);
        int int20 = day9.compareTo((java.lang.Object) seriesChangeEvent19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day9.previous();
        org.jfree.data.time.SerialDate serialDate22 = day9.getSerialDate();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(serialDate22);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(serialDate22);
        boolean boolean25 = timePeriodValues2.equals((java.lang.Object) serialDate22);
        timePeriodValues2.fireSeriesChanged();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + comparable18 + "' != '" + false + "'", comparable18.equals(false));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 1, (long) (byte) 1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year3.previous();
        boolean boolean5 = simpleTimePeriod2.equals((java.lang.Object) year3);
        int int6 = year3.getYear();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.util.Date date8 = year7.getStart();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.util.Date date10 = year9.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(date8, date10);
        boolean boolean12 = year3.equals((java.lang.Object) date10);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date10);
        long long14 = day13.getFirstMillisecond();
        java.util.Calendar calendar15 = null;
        try {
            day13.peg(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        boolean boolean4 = day2.equals((java.lang.Object) 1.0f);
        org.jfree.data.time.SerialDate serialDate5 = day2.getSerialDate();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate5);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getStart();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date9);
        int int11 = day10.getMonth();
        java.lang.Object obj12 = null;
        boolean boolean13 = day10.equals(obj12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day10.previous();
        int int15 = day10.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day10.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day10.previous();
        boolean boolean18 = day7.equals((java.lang.Object) day10);
        long long19 = day10.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate20 = day10.getSerialDate();
        java.util.Calendar calendar21 = null;
        try {
            long long22 = day10.getFirstMillisecond(calendar21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1546415999999L + "'", long19 == 1546415999999L);
        org.junit.Assert.assertNotNull(serialDate20);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        boolean boolean3 = year0.equals((java.lang.Object) "2019");
        long long4 = year0.getLastMillisecond();
        long long5 = year0.getSerialIndex();
        int int6 = year0.getYear();
        java.util.Calendar calendar7 = null;
        try {
            year0.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 100.0f);
        long long3 = year0.getFirstMillisecond();
        int int4 = year0.getYear();
        long long5 = year0.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1562097599999L + "'", long5 == 1562097599999L);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod3);
        int int5 = timePeriodValues4.getMaxMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues4.createCopy(0, (int) (short) 0);
        int int9 = timePeriodValues8.getItemCount();
        timePeriodValues8.setDomainDescription("2019");
        boolean boolean12 = timePeriodValues8.getNotify();
        int int13 = timePeriodValues8.getItemCount();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.util.Date date15 = year14.getStart();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day16.next();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent18 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day16);
        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day16, 0.0d);
        timePeriodValues8.add((org.jfree.data.time.TimePeriod) day16, (java.lang.Number) 5);
        boolean boolean23 = year0.equals((java.lang.Object) timePeriodValues8);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 100.0f);
        long long3 = year0.getFirstMillisecond();
        java.util.Date date4 = year0.getStart();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date4, timeZone7);
        long long10 = day9.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day9.previous();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year12, (double) 100.0f);
        int int15 = year12.getYear();
        int int16 = day9.compareTo((java.lang.Object) year12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year12.next();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 43466L + "'", long10 == 43466L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod6);
        int int8 = timePeriodValues7.getMaxMiddleIndex();
        timePeriodValues7.setKey((java.lang.Comparable) false);
        java.lang.Comparable comparable11 = timePeriodValues7.getKey();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) comparable11);
        int int13 = day2.compareTo((java.lang.Object) seriesChangeEvent12);
        int int14 = day2.getMonth();
        int int15 = day2.getYear();
        int int17 = day2.compareTo((java.lang.Object) 0L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day2.previous();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + false + "'", comparable11.equals(false));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 100.0f);
        java.lang.Number number3 = null;
        timePeriodValue2.setValue(number3);
        java.lang.Number number5 = timePeriodValue2.getValue();
        java.lang.Object obj6 = null;
        boolean boolean7 = timePeriodValue2.equals(obj6);
        java.lang.Number number8 = timePeriodValue2.getValue();
        java.lang.Number number9 = timePeriodValue2.getValue();
        java.lang.Object obj10 = timePeriodValue2.clone();
        timePeriodValue2.setValue((java.lang.Number) 100.0d);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1);
        int int3 = timePeriodValues2.getMaxMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues2.createCopy(0, (int) (short) 0);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) 100.0f);
        java.lang.Object obj10 = timePeriodValue9.clone();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 1, (long) (byte) 1);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.previous();
        boolean boolean16 = simpleTimePeriod13.equals((java.lang.Object) year14);
        boolean boolean17 = timePeriodValue9.equals((java.lang.Object) year14);
        java.lang.Object obj18 = timePeriodValue9.clone();
        timePeriodValues6.add(timePeriodValue9);
        java.lang.Class<?> wildcardClass20 = timePeriodValue9.getClass();
        java.lang.Class class21 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass20);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 1, (long) (byte) 1);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year25.previous();
        boolean boolean27 = simpleTimePeriod24.equals((java.lang.Object) year25);
        java.util.Date date28 = simpleTimePeriod24.getStart();
        java.util.Date date29 = simpleTimePeriod24.getEnd();
        java.lang.Class class30 = null;
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        java.util.Date date32 = year31.getStart();
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date32);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        java.util.Date date35 = year34.getStart();
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date35, timeZone36);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date32, timeZone36);
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        java.util.Date date40 = year39.getStart();
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        java.util.Date date42 = year41.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod(date40, date42);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod44 = new org.jfree.data.time.SimpleTimePeriod(date32, date40);
        java.lang.Class class45 = null;
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue48 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year46, (double) 100.0f);
        long long49 = year46.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = year46.next();
        java.util.Date date51 = year46.getEnd();
        java.lang.Class class52 = null;
        java.util.Date date53 = null;
        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance(class52, date53, timeZone54);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance(class45, date51, timeZone54);
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year(date40, timeZone54);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date29, timeZone54);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(class21);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1546329600000L + "'", long49 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(timeZone54);
        org.junit.Assert.assertNull(regularTimePeriod55);
        org.junit.Assert.assertNull(regularTimePeriod56);
        org.junit.Assert.assertNull(regularTimePeriod58);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        boolean boolean4 = day2.equals((java.lang.Object) 1.0f);
        org.jfree.data.time.SerialDate serialDate5 = day2.getSerialDate();
        java.lang.String str6 = day2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day2.next();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = day2.getMiddleMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1-January-2019" + "'", str6.equals("1-January-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        int int3 = day2.getMonth();
        java.lang.Object obj4 = null;
        boolean boolean5 = day2.equals(obj4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day2.previous();
        int int7 = day2.getMonth();
        long long8 = day2.getFirstMillisecond();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod10);
        int int12 = timePeriodValues11.getMaxMiddleIndex();
        java.lang.Object obj13 = null;
        boolean boolean14 = timePeriodValues11.equals(obj13);
        java.lang.String str15 = timePeriodValues11.getDomainDescription();
        int int16 = timePeriodValues11.getMinMiddleIndex();
        boolean boolean17 = timePeriodValues11.isEmpty();
        boolean boolean18 = day2.equals((java.lang.Object) boolean17);
        org.jfree.data.time.SerialDate serialDate19 = day2.getSerialDate();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.util.Date date21 = year20.getStart();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day22.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue25 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day22, (double) '#');
        java.lang.Class<?> wildcardClass26 = timePeriodValue25.getClass();
        int int27 = day2.compareTo((java.lang.Object) wildcardClass26);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Time" + "'", str15.equals("Time"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        int int3 = day2.getMonth();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod6 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 1, (long) (byte) 1);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 1, (long) (byte) 1);
        long long10 = simpleTimePeriod9.getEndMillis();
        boolean boolean11 = simpleTimePeriod6.equals((java.lang.Object) simpleTimePeriod9);
        long long12 = simpleTimePeriod6.getStartMillis();
        java.util.Date date13 = simpleTimePeriod6.getStart();
        int int14 = day2.compareTo((java.lang.Object) date13);
        long long15 = day2.getFirstMillisecond();
        java.util.Calendar calendar16 = null;
        try {
            day2.peg(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1546329600000L + "'", long15 == 1546329600000L);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1);
        int int3 = timePeriodValues2.getMaxMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues2.createCopy(0, (int) (short) 0);
        int int7 = timePeriodValues6.getItemCount();
        timePeriodValues6.setDomainDescription("2019");
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, (double) 100.0f);
        long long13 = year10.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year10.next();
        java.util.Date date15 = year10.getEnd();
        boolean boolean16 = timePeriodValues6.equals((java.lang.Object) year10);
        int int18 = year10.compareTo((java.lang.Object) 100.0f);
        java.util.Calendar calendar19 = null;
        try {
            year10.peg(calendar19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        boolean boolean4 = day2.equals((java.lang.Object) 1.0f);
        org.jfree.data.time.SerialDate serialDate5 = day2.getSerialDate();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate5);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getStart();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date9);
        int int11 = day10.getMonth();
        java.lang.Object obj12 = null;
        boolean boolean13 = day10.equals(obj12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day10.previous();
        int int15 = day10.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day10.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day10.previous();
        boolean boolean18 = day7.equals((java.lang.Object) day10);
        long long19 = day10.getLastMillisecond();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 1, (long) (byte) 1);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod25 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 1, (long) (byte) 1);
        long long26 = simpleTimePeriod25.getEndMillis();
        boolean boolean27 = simpleTimePeriod22.equals((java.lang.Object) simpleTimePeriod25);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        java.util.Date date29 = year28.getStart();
        boolean boolean31 = year28.equals((java.lang.Object) "2019");
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year32.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues34 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod33);
        int int35 = timePeriodValues34.getMaxMiddleIndex();
        int int36 = year28.compareTo((java.lang.Object) timePeriodValues34);
        boolean boolean37 = simpleTimePeriod22.equals((java.lang.Object) timePeriodValues34);
        java.lang.Object obj38 = timePeriodValues34.clone();
        int int39 = day10.compareTo((java.lang.Object) timePeriodValues34);
        try {
            java.lang.Number number41 = timePeriodValues34.getValue((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1546415999999L + "'", long19 == 1546415999999L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1L + "'", long26 == 1L);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1);
        int int3 = timePeriodValues2.getMaxMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues2.createCopy(0, (int) (short) 0);
        int int7 = timePeriodValues6.getItemCount();
        timePeriodValues6.setDomainDescription("2019");
        boolean boolean10 = timePeriodValues6.getNotify();
        timePeriodValues6.setDescription("org.jfree.data.general.SeriesChangeEvent[source=0]");
        boolean boolean13 = timePeriodValues6.isEmpty();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 100.0f);
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        java.util.Date date5 = year0.getEnd();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year6, (double) 100.0f);
        long long9 = year6.getFirstMillisecond();
        java.util.Date date10 = year6.getStart();
        java.lang.Class class11 = null;
        java.util.Date date12 = null;
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date12, timeZone13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date10, timeZone13);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date5, timeZone13);
        long long17 = day16.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 43830L + "'", long17 == 43830L);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 1, (long) (byte) 1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year3.previous();
        boolean boolean5 = simpleTimePeriod2.equals((java.lang.Object) year3);
        int int6 = year3.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year3.next();
        long long8 = year3.getMiddleMillisecond();
        long long9 = year3.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1562097599999L + "'", long8 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2019L + "'", long9 == 2019L);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 100.0f);
        java.lang.String str3 = year0.toString();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (double) 100.0f);
        long long7 = year4.getFirstMillisecond();
        java.util.Date date8 = year4.getStart();
        java.lang.Class class9 = null;
        java.util.Date date10 = null;
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date10, timeZone11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date8, timeZone11);
        int int14 = year0.compareTo((java.lang.Object) date8);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year15, (double) 100.0f);
        long long18 = year15.getFirstMillisecond();
        java.util.Date date19 = year15.getStart();
        java.lang.Class class20 = null;
        java.util.Date date21 = null;
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date21, timeZone22);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date19, timeZone22);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date8, timeZone22);
        java.lang.String str26 = year25.toString();
        long long27 = year25.getSerialIndex();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1546329600000L + "'", long18 == 1546329600000L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "2019" + "'", str26.equals("2019"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 2019L + "'", long27 == 2019L);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        boolean boolean3 = year0.equals((java.lang.Object) "2019");
        long long4 = year0.getSerialIndex();
        int int5 = year0.getYear();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod7);
        int int9 = timePeriodValues8.getMaxMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = timePeriodValues8.createCopy(0, (int) (short) 0);
        int int13 = timePeriodValues12.getItemCount();
        timePeriodValues12.setDomainDescription("2019");
        boolean boolean16 = year0.equals((java.lang.Object) "2019");
        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (byte) -1);
        java.util.Date date19 = year0.getEnd();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(date19);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        int int3 = year0.compareTo((java.lang.Object) 100.0d);
        long long4 = year0.getFirstMillisecond();
        long long5 = year0.getLastMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        int int3 = day2.getMonth();
        java.lang.Object obj4 = null;
        boolean boolean5 = day2.equals(obj4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day2.previous();
        int int7 = day2.getMonth();
        java.lang.String str8 = day2.toString();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.util.Date date10 = year9.getStart();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.next();
        int int13 = day2.compareTo((java.lang.Object) day11);
        java.lang.Class class14 = null;
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.util.Date date16 = year15.getStart();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date16);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        java.util.Date date19 = year18.getStart();
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date19, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date16, timeZone20);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        java.util.Date date24 = year23.getStart();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        java.util.Date date26 = year25.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod(date24, date26);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod28 = new org.jfree.data.time.SimpleTimePeriod(date16, date24);
        boolean boolean29 = day2.equals((java.lang.Object) date24);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date24);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        java.util.Date date32 = year31.getStart();
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day33.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = day33.next();
        int int36 = day33.getDayOfMonth();
        java.lang.Class<?> wildcardClass37 = day33.getClass();
        java.lang.Class class38 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass37);
        java.lang.Class class39 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass37);
        boolean boolean40 = year30.equals((java.lang.Object) wildcardClass37);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1-January-2019" + "'", str8.equals("1-January-2019"));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertNotNull(class38);
        org.junit.Assert.assertNotNull(class39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1);
        int int3 = timePeriodValues2.getMaxMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues2.createCopy(0, (int) (short) 0);
        int int7 = timePeriodValues6.getItemCount();
        timePeriodValues6.fireSeriesChanged();
        timePeriodValues6.fireSeriesChanged();
        int int10 = timePeriodValues6.getMaxStartIndex();
        int int11 = timePeriodValues6.getMinMiddleIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        int int3 = day2.getMonth();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod6 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 1, (long) (byte) 1);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 1, (long) (byte) 1);
        long long10 = simpleTimePeriod9.getEndMillis();
        boolean boolean11 = simpleTimePeriod6.equals((java.lang.Object) simpleTimePeriod9);
        long long12 = simpleTimePeriod6.getStartMillis();
        java.util.Date date13 = simpleTimePeriod6.getStart();
        int int14 = day2.compareTo((java.lang.Object) date13);
        java.util.Calendar calendar15 = null;
        try {
            long long16 = day2.getFirstMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 100.0f);
        java.lang.String str3 = year0.toString();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (double) 100.0f);
        long long7 = year4.getFirstMillisecond();
        java.util.Date date8 = year4.getStart();
        java.lang.Class class9 = null;
        java.util.Date date10 = null;
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date10, timeZone11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date8, timeZone11);
        int int14 = year0.compareTo((java.lang.Object) date8);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year15, (double) 100.0f);
        long long18 = year15.getFirstMillisecond();
        java.util.Date date19 = year15.getStart();
        java.lang.Class class20 = null;
        java.util.Date date21 = null;
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date21, timeZone22);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date19, timeZone22);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date8, timeZone22);
        java.lang.String str26 = year25.toString();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue29 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year27, (double) 100.0f);
        java.lang.String str30 = year27.toString();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue33 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year31, (double) 100.0f);
        long long34 = year31.getFirstMillisecond();
        java.util.Date date35 = year31.getStart();
        java.lang.Class class36 = null;
        java.util.Date date37 = null;
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance(class36, date37, timeZone38);
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date35, timeZone38);
        int int41 = year27.compareTo((java.lang.Object) date35);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue44 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year42, (double) 100.0f);
        long long45 = year42.getFirstMillisecond();
        java.util.Date date46 = year42.getStart();
        java.lang.Class class47 = null;
        java.util.Date date48 = null;
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance(class47, date48, timeZone49);
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date46, timeZone49);
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(date35, timeZone49);
        java.util.Date date53 = year52.getEnd();
        java.lang.Class class54 = null;
        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue57 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year55, (double) 100.0f);
        long long58 = year55.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = year55.next();
        java.util.Date date60 = year55.getEnd();
        java.lang.Class class61 = null;
        java.util.Date date62 = null;
        java.util.TimeZone timeZone63 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = org.jfree.data.time.RegularTimePeriod.createInstance(class61, date62, timeZone63);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance(class54, date60, timeZone63);
        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day(date53, timeZone63);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent67 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date53);
        int int68 = year25.compareTo((java.lang.Object) seriesChangeEvent67);
        java.lang.Object obj69 = seriesChangeEvent67.getSource();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1546329600000L + "'", long18 == 1546329600000L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "2019" + "'", str26.equals("2019"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2019" + "'", str30.equals("2019"));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1546329600000L + "'", long34 == 1546329600000L);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1546329600000L + "'", long45 == 1546329600000L);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNull(regularTimePeriod50);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1546329600000L + "'", long58 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod59);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNotNull(timeZone63);
        org.junit.Assert.assertNull(regularTimePeriod64);
        org.junit.Assert.assertNull(regularTimePeriod65);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
        org.junit.Assert.assertNotNull(obj69);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        int int3 = year0.compareTo((java.lang.Object) 100.0d);
        java.lang.String str4 = year0.toString();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        java.util.Date date6 = year5.getStart();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day7.next();
        int int10 = day7.getDayOfMonth();
        java.lang.Class<?> wildcardClass11 = day7.getClass();
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        int int14 = year0.compareTo((java.lang.Object) wildcardClass11);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1);
        int int3 = timePeriodValues2.getMaxMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues2.createCopy(0, (int) (short) 0);
        int int7 = timePeriodValues6.getItemCount();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues6.addChangeListener(seriesChangeListener8);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timePeriodValues6.removeChangeListener(seriesChangeListener10);
        int int12 = timePeriodValues6.getItemCount();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = timePeriodValues6.createCopy((int) '4', (int) (short) 100);
        java.lang.Comparable comparable16 = timePeriodValues6.getKey();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(timePeriodValues15);
        org.junit.Assert.assertNotNull(comparable16);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 1, (long) (byte) 1);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod5 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 1, (long) (byte) 1);
        long long6 = simpleTimePeriod5.getEndMillis();
        boolean boolean7 = simpleTimePeriod2.equals((java.lang.Object) simpleTimePeriod5);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getStart();
        boolean boolean11 = year8.equals((java.lang.Object) "2019");
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod13);
        int int15 = timePeriodValues14.getMaxMiddleIndex();
        int int16 = year8.compareTo((java.lang.Object) timePeriodValues14);
        boolean boolean17 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValues14);
        int int18 = timePeriodValues14.getMinStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
        timePeriodValues14.removeChangeListener(seriesChangeListener19);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesChangeEvent[source=0]");
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1);
        int int3 = timePeriodValues2.getMinEndIndex();
        try {
            timePeriodValues2.update((int) (short) -1, (java.lang.Number) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1);
        int int3 = timePeriodValues2.getMaxMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues2.createCopy(0, (int) (short) 0);
        int int7 = timePeriodValues6.getItemCount();
        timePeriodValues6.setDomainDescription("2019");
        boolean boolean10 = timePeriodValues6.getNotify();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues6.createCopy((int) (short) -1, (int) (byte) 0);
        int int14 = timePeriodValues6.getMinEndIndex();
        java.lang.Class class15 = null;
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        java.util.Date date17 = year16.getStart();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        java.util.Date date19 = year18.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod(date17, date19);
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date17, timeZone21);
        timePeriodValues6.setKey((java.lang.Comparable) date17);
        int int24 = timePeriodValues6.getMinEndIndex();
        java.lang.String str25 = timePeriodValues6.getRangeDescription();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(timePeriodValues13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Value" + "'", str25.equals("Value"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        long long5 = day2.getFirstMillisecond();
        org.jfree.data.time.SerialDate serialDate6 = day2.getSerialDate();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate6);
        long long8 = day7.getLastMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546415999999L + "'", long8 == 1546415999999L);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1);
        int int3 = timePeriodValues2.getMaxMiddleIndex();
        timePeriodValues2.setKey((java.lang.Comparable) false);
        timePeriodValues2.setDescription("");
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues2.createCopy((int) '4', (int) (byte) 100);
        timePeriodValues10.setDescription("");
        timePeriodValues10.setRangeDescription("Time");
        int int15 = timePeriodValues10.getMaxMiddleIndex();
        java.lang.String str16 = timePeriodValues10.getDescription();
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timePeriodValues10.addPropertyChangeListener(propertyChangeListener17);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.lang.Class<?> wildcardClass2 = date1.getClass();
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize(class4);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNotNull(class4);
        org.junit.Assert.assertNotNull(class5);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1);
        int int3 = timePeriodValues2.getMaxMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues2.createCopy(0, (int) (short) 0);
        int int7 = timePeriodValues6.getItemCount();
        timePeriodValues6.setDomainDescription("2019");
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, (double) 100.0f);
        long long13 = year10.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year10.next();
        java.util.Date date15 = year10.getEnd();
        boolean boolean16 = timePeriodValues6.equals((java.lang.Object) year10);
        int int17 = timePeriodValues6.getMinMiddleIndex();
        int int18 = timePeriodValues6.getMaxStartIndex();
        timePeriodValues6.setNotify(false);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        boolean boolean3 = year0.equals((java.lang.Object) "2019");
        long long4 = year0.getSerialIndex();
        int int5 = year0.getYear();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod7);
        int int9 = timePeriodValues8.getMaxMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = timePeriodValues8.createCopy(0, (int) (short) 0);
        int int13 = timePeriodValues12.getItemCount();
        timePeriodValues12.setDomainDescription("2019");
        boolean boolean16 = year0.equals((java.lang.Object) "2019");
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        java.util.Date date18 = year17.getStart();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        int int20 = day19.getMonth();
        java.lang.Object obj21 = null;
        boolean boolean22 = day19.equals(obj21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day19.previous();
        int int24 = day19.getMonth();
        long long25 = day19.getFirstMillisecond();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year26.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod27);
        int int29 = timePeriodValues28.getMaxMiddleIndex();
        java.lang.Object obj30 = null;
        boolean boolean31 = timePeriodValues28.equals(obj30);
        java.lang.String str32 = timePeriodValues28.getDomainDescription();
        int int33 = timePeriodValues28.getMinMiddleIndex();
        boolean boolean34 = timePeriodValues28.isEmpty();
        boolean boolean35 = day19.equals((java.lang.Object) boolean34);
        org.jfree.data.time.SerialDate serialDate36 = day19.getSerialDate();
        boolean boolean37 = year0.equals((java.lang.Object) day19);
        java.util.Calendar calendar38 = null;
        try {
            long long39 = year0.getFirstMillisecond(calendar38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1546329600000L + "'", long25 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Time" + "'", str32.equals("Time"));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "2019", "hi!");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        java.util.Date date5 = year4.getStart();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) 1.0f);
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        timePeriodValues3.setKey((java.lang.Comparable) serialDate9);
        java.lang.String str11 = timePeriodValues3.getDescription();
        java.lang.Comparable comparable12 = timePeriodValues3.getKey();
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(comparable12);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 1, (long) (byte) 1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year3.previous();
        boolean boolean5 = simpleTimePeriod2.equals((java.lang.Object) year3);
        int int6 = year3.getYear();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.util.Date date8 = year7.getStart();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.util.Date date10 = year9.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(date8, date10);
        boolean boolean12 = year3.equals((java.lang.Object) date10);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date10);
        long long14 = day13.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day13, (double) 1);
        int int17 = day13.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate18 = day13.getSerialDate();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(serialDate18);
        java.lang.Class<?> wildcardClass20 = serialDate18.getClass();
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        java.lang.String str4 = year3.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day2.next();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day2);
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day2, (double) (byte) 10);
        timePeriodValue6.setValue((java.lang.Number) (byte) 1);
        org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValue6.getPeriod();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(timePeriod9);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day2.next();
        java.lang.String str4 = day2.toString();
        long long5 = day2.getFirstMillisecond();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day2);
        long long7 = day2.getMiddleMillisecond();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = day2.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1-January-2019" + "'", str4.equals("1-January-2019"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546372799999L + "'", long7 == 1546372799999L);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 1, (long) (byte) 1);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 1);
        java.lang.String str4 = seriesChangeEvent3.toString();
        java.lang.String str5 = seriesChangeEvent3.toString();
        java.lang.Object obj6 = seriesChangeEvent3.getSource();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=1]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=1]"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=1]" + "'", str5.equals("org.jfree.data.general.SeriesChangeEvent[source=1]"));
        org.junit.Assert.assertTrue("'" + obj6 + "' != '" + (byte) 1 + "'", obj6.equals((byte) 1));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1);
        int int3 = timePeriodValues2.getMaxMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues2.createCopy(0, (int) (short) 0);
        int int7 = timePeriodValues6.getItemCount();
        timePeriodValues6.setDomainDescription("2019");
        boolean boolean10 = timePeriodValues6.getNotify();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues6.createCopy((int) (short) -1, (int) (byte) 0);
        timePeriodValues6.setDomainDescription("TimePeriodValue[1-January-2019,10.0]");
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(timePeriodValues13);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day2.previous();
        long long4 = day2.getFirstMillisecond();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod7 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 1, (long) (byte) 1);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 1, (long) (byte) 1);
        long long11 = simpleTimePeriod10.getEndMillis();
        boolean boolean12 = simpleTimePeriod7.equals((java.lang.Object) simpleTimePeriod10);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        java.lang.String str14 = year13.toString();
        int int15 = simpleTimePeriod10.compareTo((java.lang.Object) year13);
        java.util.Date date16 = simpleTimePeriod10.getEnd();
        boolean boolean17 = day2.equals((java.lang.Object) date16);
        java.util.Calendar calendar18 = null;
        try {
            day2.peg(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.lang.Class<?> wildcardClass3 = year0.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.previous();
        long long5 = year0.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1);
        int int3 = timePeriodValues2.getMaxMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues2.createCopy(0, (int) (short) 0);
        int int7 = timePeriodValues6.getItemCount();
        timePeriodValues6.fireSeriesChanged();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues6.addChangeListener(seriesChangeListener9);
        timePeriodValues6.delete(100, (int) (byte) -1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timePeriodValues6.removeChangeListener(seriesChangeListener14);
        java.lang.Comparable comparable16 = timePeriodValues6.getKey();
        boolean boolean17 = timePeriodValues6.isEmpty();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(comparable16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        long long3 = year0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        java.util.Date date6 = year5.getStart();
        int int8 = year5.compareTo((java.lang.Object) 100.0d);
        java.lang.String str9 = year5.toString();
        boolean boolean10 = year0.equals((java.lang.Object) str9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year0.next();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day2.next();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day2);
        long long5 = day2.getSerialIndex();
        int int6 = day2.getYear();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43466L + "'", long5 == 43466L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1);
        int int3 = timePeriodValues2.getMaxMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues2.createCopy(0, (int) (short) 0);
        int int7 = timePeriodValues6.getItemCount();
        int int8 = timePeriodValues6.getMinMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = timePeriodValues6.createCopy(11, (int) (byte) 100);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues11);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day2.previous();
        long long4 = day2.getFirstMillisecond();
        long long5 = day2.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1);
        int int3 = timePeriodValues2.getMaxMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues2.createCopy(0, (int) (short) 0);
        int int7 = timePeriodValues6.getItemCount();
        timePeriodValues6.setDomainDescription("2019");
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getStart();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day12.next();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year15.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod16);
        int int18 = timePeriodValues17.getMaxMiddleIndex();
        timePeriodValues17.setKey((java.lang.Comparable) false);
        java.lang.Comparable comparable21 = timePeriodValues17.getKey();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent22 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) comparable21);
        int int23 = day12.compareTo((java.lang.Object) seriesChangeEvent22);
        timePeriodValues6.setKey((java.lang.Comparable) day12);
        timePeriodValues6.setNotify(false);
        int int27 = timePeriodValues6.getMinEndIndex();
        java.lang.String str28 = timePeriodValues6.getDescription();
        boolean boolean29 = timePeriodValues6.getNotify();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + comparable21 + "' != '" + false + "'", comparable21.equals(false));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1);
        int int3 = timePeriodValues2.getMaxMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues2.createCopy(0, (int) (short) 0);
        int int7 = timePeriodValues6.getItemCount();
        timePeriodValues6.fireSeriesChanged();
        timePeriodValues6.fireSeriesChanged();
        int int10 = timePeriodValues6.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues6.addChangeListener(seriesChangeListener11);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 1, (long) (byte) 1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year3.previous();
        boolean boolean5 = simpleTimePeriod2.equals((java.lang.Object) year3);
        java.util.Date date6 = simpleTimePeriod2.getStart();
        java.util.Date date7 = simpleTimePeriod2.getEnd();
        java.util.Date date8 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 1, (long) (byte) 1);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.previous();
        boolean boolean14 = simpleTimePeriod11.equals((java.lang.Object) year12);
        int int15 = year12.getYear();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        java.util.Date date17 = year16.getStart();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        java.util.Date date19 = year18.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod(date17, date19);
        boolean boolean21 = year12.equals((java.lang.Object) date19);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date19);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod23 = new org.jfree.data.time.SimpleTimePeriod(date8, date19);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        java.util.Date date25 = year24.getStart();
        java.lang.Class<?> wildcardClass26 = date25.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod29 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 1, (long) (byte) 1);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year30.previous();
        boolean boolean32 = simpleTimePeriod29.equals((java.lang.Object) year30);
        org.jfree.data.time.TimePeriodValue timePeriodValue34 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod29, (double) 10);
        java.util.Date date35 = simpleTimePeriod29.getStart();
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date35, timeZone36);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod38 = new org.jfree.data.time.SimpleTimePeriod(date8, date35);
        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date8, "TimePeriodValue[1-January-2019,8]", "org.jfree.data.general.SeriesChangeEvent[source=false]");
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue44 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year42, (double) 100.0f);
        long long45 = year42.getFirstMillisecond();
        java.util.Date date46 = year42.getStart();
        java.lang.Class class47 = null;
        java.util.Date date48 = null;
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance(class47, date48, timeZone49);
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date46, timeZone49);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod52 = new org.jfree.data.time.SimpleTimePeriod(date8, date46);
        java.lang.Class class53 = null;
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year();
        java.util.Date date55 = year54.getStart();
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(date55);
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year();
        java.util.Date date58 = year57.getStart();
        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(date58, timeZone59);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance(class53, date55, timeZone59);
        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year();
        java.util.Date date63 = year62.getStart();
        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year();
        java.util.Date date65 = year64.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod66 = new org.jfree.data.time.SimpleTimePeriod(date63, date65);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod67 = new org.jfree.data.time.SimpleTimePeriod(date55, date63);
        java.lang.Class class68 = null;
        org.jfree.data.time.Year year69 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue71 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year69, (double) 100.0f);
        long long72 = year69.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = year69.next();
        java.util.Date date74 = year69.getEnd();
        java.lang.Class class75 = null;
        java.util.Date date76 = null;
        java.util.TimeZone timeZone77 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = org.jfree.data.time.RegularTimePeriod.createInstance(class75, date76, timeZone77);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = org.jfree.data.time.RegularTimePeriod.createInstance(class68, date74, timeZone77);
        org.jfree.data.time.Year year80 = new org.jfree.data.time.Year(date63, timeZone77);
        org.jfree.data.time.Day day81 = new org.jfree.data.time.Day(date46, timeZone77);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1546329600000L + "'", long45 == 1546329600000L);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNull(regularTimePeriod50);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertNotNull(timeZone59);
        org.junit.Assert.assertNull(regularTimePeriod61);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertNotNull(date65);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 1546329600000L + "'", long72 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod73);
        org.junit.Assert.assertNotNull(date74);
        org.junit.Assert.assertNotNull(timeZone77);
        org.junit.Assert.assertNull(regularTimePeriod78);
        org.junit.Assert.assertNull(regularTimePeriod79);
    }
}

