import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = null;
        try {
            categoryPlot0.setRangeGridlineStroke(stroke1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = null;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setStartAngle((double) 10.0f);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        java.awt.Stroke stroke2 = null;
        try {
            categoryPlot0.setDomainGridlineStroke(stroke2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            categoryPlot0.drawBackground(graphics2D3, rectangle2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation2);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            double double1 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        java.lang.String str0 = org.jfree.chart.ui.Licences.LGPL;
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.LEFT;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) 1L, (double) (byte) 100, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        int int3 = java.awt.Color.HSBtoRGB((float) (-1), (float) 10L, (float) (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16056329) + "'", int3 == (-16056329));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        org.junit.Assert.assertNotNull(rotation0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        double double0 = org.jfree.chart.plot.PiePlot.MAX_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.4d + "'", double0 == 0.4d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.data.KeyedValues keyedValues1 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) 10, keyedValues1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowData' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.data.time.DateRange dateRange1 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType2 = null;
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) (-1.0f), (org.jfree.data.Range) dateRange1, lengthConstraintType2, (double) 'a', (org.jfree.data.Range) dateRange4, lengthConstraintType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'widthType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateRange1);
        org.junit.Assert.assertNotNull(dateRange4);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int2 = color1.getAlpha();
        java.lang.String str3 = color1.toString();
        piePlot0.setLabelPaint((java.awt.Paint) color1);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator5 = piePlot0.getLegendLabelToolTipGenerator();
        java.awt.Font font6 = null;
        try {
            piePlot0.setNoDataMessageFont(font6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 255 + "'", int2 == 255);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str3.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNull(pieSectionLabelGenerator5);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(xYDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        categoryPlot0.setForegroundAlpha((float) 1);
        org.jfree.chart.plot.Marker marker5 = null;
        org.jfree.chart.util.Layer layer6 = null;
        try {
            boolean boolean7 = categoryPlot0.removeDomainMarker((int) (short) -1, marker5, layer6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        boolean boolean3 = dateRange0.intersects((double) (byte) 100, (double) (byte) 100);
        org.junit.Assert.assertNotNull(dateRange0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int1 = color0.getAlpha();
        int int2 = color0.getGreen();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 255 + "'", int2 == 255);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        java.lang.ClassLoader classLoader0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
        org.junit.Assert.assertNull(classLoader0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(true);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        boolean boolean3 = color0.equals((java.lang.Object) 100);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = null;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.CLASS_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ClassContext" + "'", str0.equals("ClassContext"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        dateAxis2.setLabelAngle((double) (byte) 1);
        dateAxis2.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int10 = color9.getAlpha();
        dateAxis2.setTickLabelPaint((java.awt.Paint) color9);
        try {
            dateAxis2.setAutoRangeMinimumSize((double) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 255 + "'", int10 == 255);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.plot.Marker marker2 = null;
        org.jfree.chart.util.Layer layer3 = null;
        try {
            boolean boolean4 = categoryPlot0.removeRangeMarker(marker2, layer3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = piePlot0.getSimpleLabelOffset();
        boolean boolean2 = piePlot0.getSectionOutlinesVisible();
        try {
            piePlot0.setInteriorGap((double) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'percent' (10.0) argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot4);
        java.awt.geom.Rectangle2D rectangle2D6 = legendTitle5.getBounds();
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = null;
        try {
            legendTitle5.setVerticalAlignment(verticalAlignment7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'alignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D6);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        java.util.ResourceBundle.clearCache();
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot4);
        org.jfree.chart.block.BlockContainer blockContainer6 = legendTitle5.getItemContainer();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer11 = null;
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot(xYDataset8, (org.jfree.chart.axis.ValueAxis) dateAxis10, polarItemRenderer11);
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot12);
        java.awt.geom.Rectangle2D rectangle2D14 = legendTitle13.getBounds();
        try {
            java.lang.Object obj16 = blockContainer6.draw(graphics2D7, rectangle2D14, (java.lang.Object) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockContainer6);
        org.junit.Assert.assertNotNull(rectangle2D14);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        dateAxis3.setLabelAngle((double) (byte) 1);
        java.awt.Font font8 = dateAxis3.getTickLabelFont();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer12 = null;
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) dateAxis11, polarItemRenderer12);
        int int14 = polarPlot13.getBackgroundImageAlignment();
        boolean boolean15 = polarPlot13.isSubplot();
        java.awt.Color color16 = java.awt.Color.blue;
        polarPlot13.setAngleLabelPaint((java.awt.Paint) color16);
        org.jfree.chart.text.TextMeasurer textMeasurer20 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock21 = org.jfree.chart.text.TextUtilities.createTextBlock("java.awt.Color[r=255,g=255,b=64]", font8, (java.awt.Paint) color16, (float) '#', 0, textMeasurer20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 15 + "'", int14 == 15);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(color16);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setShadowYOffset(0.05d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        dateAxis3.setLabelAngle((double) (byte) 1);
        dateAxis3.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int11 = color10.getAlpha();
        java.lang.String str12 = color10.toString();
        dateAxis3.setTickMarkPaint((java.awt.Paint) color10);
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = piePlot14.getSimpleLabelOffset();
        java.awt.Stroke stroke16 = piePlot14.getLabelOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, (java.awt.Paint) color10, stroke16);
        java.lang.Class class18 = null;
        try {
            java.util.EventListener[] eventListenerArray19 = valueMarker17.getListeners(class18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 255 + "'", int11 == 255);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str12.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_STARTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        boolean boolean2 = categoryPlot0.isDomainGridlinesVisible();
        int int3 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
        try {
            categoryPlot0.setRangeAxisLocation((int) (short) -1, axisLocation5, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        java.awt.Paint paint4 = polarPlot3.getRadiusGridlinePaint();
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis((int) '4', valueAxis3, false);
        categoryPlot0.configureRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer12 = null;
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) dateAxis11, polarItemRenderer12);
        dateAxis11.setLabelAngle((double) (byte) 1);
        dateAxis11.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int19 = color18.getAlpha();
        java.lang.String str20 = color18.toString();
        dateAxis11.setTickMarkPaint((java.awt.Paint) color18);
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = piePlot22.getSimpleLabelOffset();
        java.awt.Stroke stroke24 = piePlot22.getLabelOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, (java.awt.Paint) color18, stroke24);
        org.jfree.chart.util.Layer layer26 = null;
        categoryPlot0.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker25, layer26);
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        float float30 = categoryPlot29.getForegroundAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        categoryPlot29.setRangeAxis((int) '4', valueAxis32, false);
        categoryPlot29.configureRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset38 = null;
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer41 = null;
        org.jfree.chart.plot.PolarPlot polarPlot42 = new org.jfree.chart.plot.PolarPlot(xYDataset38, (org.jfree.chart.axis.ValueAxis) dateAxis40, polarItemRenderer41);
        dateAxis40.setLabelAngle((double) (byte) 1);
        dateAxis40.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color47 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int48 = color47.getAlpha();
        java.lang.String str49 = color47.toString();
        dateAxis40.setTickMarkPaint((java.awt.Paint) color47);
        org.jfree.chart.plot.PiePlot piePlot51 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = piePlot51.getSimpleLabelOffset();
        java.awt.Stroke stroke53 = piePlot51.getLabelOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker54 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, (java.awt.Paint) color47, stroke53);
        org.jfree.chart.util.Layer layer55 = null;
        categoryPlot29.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker54, layer55);
        org.jfree.chart.util.Layer layer57 = null;
        try {
            boolean boolean58 = categoryPlot0.removeRangeMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker54, layer57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 255 + "'", int19 == 255);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str20.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 1.0f + "'", float30 == 1.0f);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 255 + "'", int48 == 255);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str49.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(rectangleInsets52);
        org.junit.Assert.assertNotNull(stroke53);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        int int5 = polarPlot4.getBackgroundImageAlignment();
        boolean boolean6 = polarPlot4.isSubplot();
        boolean boolean7 = polarPlot4.isDomainZoomable();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        polarPlot4.zoomRangeAxes((double) 0.0f, plotRenderingInfo9, point2D10);
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = piePlot12.getSimpleLabelOffset();
        double double15 = rectangleInsets13.extendHeight(0.0d);
        polarPlot4.setInsets(rectangleInsets13);
        double double17 = rectangleInsets13.getBottom();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.18d + "'", double17 == 0.18d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        java.awt.Color color0 = java.awt.Color.pink;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot4);
        org.jfree.chart.block.BlockContainer blockContainer6 = legendTitle5.getItemContainer();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = piePlot8.getSimpleLabelOffset();
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer13 = null;
        org.jfree.chart.plot.PolarPlot polarPlot14 = new org.jfree.chart.plot.PolarPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) dateAxis12, polarItemRenderer13);
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot14);
        java.awt.geom.Rectangle2D rectangle2D16 = legendTitle15.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType17 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = rectangleInsets9.createAdjustedRectangle(rectangle2D16, lengthAdjustmentType17, lengthAdjustmentType18);
        try {
            blockContainer6.draw(graphics2D7, rectangle2D16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockContainer6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(rectangle2D19);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot4);
        org.jfree.chart.block.BlockContainer blockContainer6 = legendTitle5.getItemContainer();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = piePlot8.getSimpleLabelOffset();
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer13 = null;
        org.jfree.chart.plot.PolarPlot polarPlot14 = new org.jfree.chart.plot.PolarPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) dateAxis12, polarItemRenderer13);
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot14);
        java.awt.geom.Rectangle2D rectangle2D16 = legendTitle15.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType17 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = rectangleInsets9.createAdjustedRectangle(rectangle2D16, lengthAdjustmentType17, lengthAdjustmentType18);
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer23 = null;
        org.jfree.chart.plot.PolarPlot polarPlot24 = new org.jfree.chart.plot.PolarPlot(xYDataset20, (org.jfree.chart.axis.ValueAxis) dateAxis22, polarItemRenderer23);
        org.jfree.data.Range range25 = dateAxis22.getRange();
        java.util.Date date26 = dateAxis22.getMinimumDate();
        try {
            java.lang.Object obj27 = blockContainer6.draw(graphics2D7, rectangle2D16, (java.lang.Object) date26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockContainer6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNotNull(date26);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis((int) '4', valueAxis3, false);
        categoryPlot0.configureRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer12 = null;
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) dateAxis11, polarItemRenderer12);
        dateAxis11.setLabelAngle((double) (byte) 1);
        dateAxis11.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int19 = color18.getAlpha();
        java.lang.String str20 = color18.toString();
        dateAxis11.setTickMarkPaint((java.awt.Paint) color18);
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = piePlot22.getSimpleLabelOffset();
        java.awt.Stroke stroke24 = piePlot22.getLabelOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, (java.awt.Paint) color18, stroke24);
        org.jfree.chart.util.Layer layer26 = null;
        categoryPlot0.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker25, layer26);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType28 = null;
        try {
            valueMarker25.setLabelOffsetType(lengthAdjustmentType28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'adj' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 255 + "'", int19 == 255);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str20.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke24);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = piePlot0.getSimpleLabelOffset();
        java.awt.Paint paint3 = piePlot0.getSectionPaint((java.lang.Comparable) 10);
        java.lang.Comparable comparable4 = null;
        try {
            java.awt.Paint paint5 = piePlot0.getSectionPaint(comparable4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNull(paint3);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        org.jfree.data.time.DateRange dateRange5 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double6 = dateRange5.getUpperBound();
        dateAxis2.setRange((org.jfree.data.Range) dateRange5);
        try {
            dateAxis2.setRangeAboutValue((-1.0d), (-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (-0.5) <= upper (-1.5).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateRange5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("");
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        int int1 = ringPlot0.getPieIndex();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot4);
        org.jfree.chart.block.BlockContainer blockContainer6 = legendTitle5.getItemContainer();
        blockContainer6.setMargin(4.0d, (double) 0L, 10.0d, (double) (short) -1);
        org.junit.Assert.assertNotNull(blockContainer6);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        dateAxis2.setLabelAngle((double) (byte) 1);
        dateAxis2.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int10 = color9.getAlpha();
        java.lang.String str11 = color9.toString();
        dateAxis2.setTickMarkPaint((java.awt.Paint) color9);
        org.jfree.data.Range range13 = dateAxis2.getDefaultAutoRange();
        java.util.TimeZone timeZone14 = null;
        try {
            dateAxis2.setTimeZone(timeZone14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 255 + "'", int10 == 255);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str11.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(range13);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        boolean boolean2 = categoryPlot0.isDomainGridlinesVisible();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        boolean boolean7 = categoryPlot0.render(graphics2D3, rectangle2D4, (int) (byte) 10, plotRenderingInfo6);
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot0.getDataset((int) ' ');
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot0.getRowRenderingOrder();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        float float13 = categoryPlot12.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation14 = categoryPlot12.getRangeAxisLocation();
        try {
            categoryPlot0.setRangeAxisLocation((int) (short) -1, axisLocation14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 1.0f + "'", float13 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation14);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot4);
        org.jfree.chart.block.BlockContainer blockContainer6 = legendTitle5.getItemContainer();
        org.jfree.chart.block.Arrangement arrangement7 = blockContainer6.getArrangement();
        org.jfree.chart.block.BlockContainer blockContainer8 = new org.jfree.chart.block.BlockContainer(arrangement7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        float float11 = categoryPlot10.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot10.getRangeAxisLocation();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = categoryPlot10.getRenderer();
        java.lang.String str14 = categoryPlot10.getPlotType();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot(xYDataset16, (org.jfree.chart.axis.ValueAxis) dateAxis18, polarItemRenderer19);
        org.jfree.chart.title.LegendTitle legendTitle21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot20);
        java.awt.geom.Rectangle2D rectangle2D22 = legendTitle21.getBounds();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        boolean boolean25 = categoryPlot10.render(graphics2D15, rectangle2D22, (int) (byte) 1, plotRenderingInfo24);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer29 = null;
        org.jfree.chart.plot.PolarPlot polarPlot30 = new org.jfree.chart.plot.PolarPlot(xYDataset26, (org.jfree.chart.axis.ValueAxis) dateAxis28, polarItemRenderer29);
        dateAxis28.setLabelAngle((double) (byte) 1);
        java.awt.Font font33 = dateAxis28.getTickLabelFont();
        try {
            java.lang.Object obj34 = blockContainer8.draw(graphics2D9, rectangle2D22, (java.lang.Object) font33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockContainer6);
        org.junit.Assert.assertNotNull(arrangement7);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 1.0f + "'", float11 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNull(categoryItemRenderer13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Category Plot" + "'", str14.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(font33);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        piePlotState1.setPieWRadius((double) (byte) 100);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        try {
            java.awt.geom.Point2D point2D2 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        int int5 = polarPlot4.getBackgroundImageAlignment();
        boolean boolean6 = polarPlot4.isRangeZoomable();
        java.lang.String str7 = polarPlot4.getPlotType();
        polarPlot4.setRadiusGridlinesVisible(true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Polar Plot" + "'", str7.equals("Polar Plot"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        int int5 = polarPlot4.getBackgroundImageAlignment();
        boolean boolean6 = polarPlot4.isOutlineVisible();
        java.awt.Paint paint7 = polarPlot4.getRadiusGridlinePaint();
        java.awt.Font font8 = polarPlot4.getAngleLabelFont();
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = polarPlot4.getOrientation();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(plotOrientation9);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        boolean boolean2 = categoryPlot0.isDomainGridlinesVisible();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        boolean boolean7 = categoryPlot0.render(graphics2D3, rectangle2D4, (int) (byte) 10, plotRenderingInfo6);
        categoryPlot0.setOutlineVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource12 = null;
        dateAxis11.setStandardTickUnits(tickUnitSource12);
        java.awt.Stroke stroke14 = dateAxis11.getTickMarkStroke();
        java.awt.Paint paint15 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        dateAxis11.setLabelPaint(paint15);
        int int17 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis11);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        boolean boolean5 = polarPlot3.equals((java.lang.Object) 0.4d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setInnerSeparatorExtension((double) '#');
        org.jfree.chart.util.Rotation rotation3 = ringPlot0.getDirection();
        double double4 = ringPlot0.getShadowXOffset();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor5 = null;
        try {
            ringPlot0.setLabelDistributor(abstractPieLabelDistributor5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'distributor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        boolean boolean2 = categoryPlot0.isDomainGridlinesVisible();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        boolean boolean7 = categoryPlot0.render(graphics2D3, rectangle2D4, (int) (byte) 10, plotRenderingInfo6);
        categoryPlot0.setOutlineVisible(true);
        boolean boolean10 = categoryPlot0.isDomainZoomable();
        try {
            categoryPlot0.zoom(0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = piePlot0.getSimpleLabelOffset();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        piePlot0.markerChanged(markerChangeEvent2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot0.setLabelBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor6 = null;
        try {
            piePlot0.setLabelDistributor(abstractPieLabelDistributor6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'distributor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis((int) '4', valueAxis3, false);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        try {
            categoryPlot0.handleClick((int) 'a', (int) (byte) 10, plotRenderingInfo9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        org.jfree.data.Range range5 = dateAxis2.getRange();
        org.jfree.data.Range range8 = org.jfree.data.Range.expand(range5, (double) 100, (double) (byte) -1);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(range8);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = piePlot5.getSimpleLabelOffset();
        double double7 = rectangleInsets6.getRight();
        dateAxis2.setLabelInsets(rectangleInsets6);
        java.awt.Shape shape9 = dateAxis2.getLeftArrow();
        java.awt.Shape shape10 = dateAxis2.getDownArrow();
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.18d + "'", double7 == 0.18d);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis((int) '4', valueAxis3, false);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot0.getRangeAxisLocation((int) (short) -1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation8);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = piePlot0.getSimpleLabelOffset();
        boolean boolean2 = piePlot0.getSectionOutlinesVisible();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator3 = null;
        piePlot0.setLegendLabelURLGenerator(pieURLGenerator3);
        java.lang.Comparable comparable5 = null;
        try {
            double double6 = piePlot0.getExplodePercent(comparable5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        double double5 = dateAxis2.getLabelAngle();
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = dateAxis2.getTickUnit();
        dateAxis2.setVisible(false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(dateTickUnit6);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        int int5 = polarPlot4.getBackgroundImageAlignment();
        boolean boolean6 = polarPlot4.isSubplot();
        boolean boolean7 = polarPlot4.isDomainZoomable();
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer11 = null;
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot(xYDataset8, (org.jfree.chart.axis.ValueAxis) dateAxis10, polarItemRenderer11);
        dateAxis10.setLabelAngle((double) (byte) 1);
        dateAxis10.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int18 = color17.getAlpha();
        dateAxis10.setTickLabelPaint((java.awt.Paint) color17);
        polarPlot4.setAngleGridlinePaint((java.awt.Paint) color17);
        org.jfree.chart.axis.TickUnit tickUnit21 = null;
        try {
            polarPlot4.setAngleTickUnit(tickUnit21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 255 + "'", int18 == 255);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = piePlot0.getSimpleLabelOffset();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        piePlot0.markerChanged(markerChangeEvent2);
        java.lang.Object obj4 = piePlot0.clone();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator5 = null;
        piePlot0.setToolTipGenerator(pieToolTipGenerator5);
        java.awt.Stroke stroke7 = piePlot0.getLabelLinkStroke();
        java.awt.Shape shape8 = piePlot0.getLegendItemShape();
        org.jfree.chart.util.Size2D size2D11 = new org.jfree.chart.util.Size2D((double) ' ', 0.0d);
        size2D11.height = ' ';
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer17 = null;
        org.jfree.chart.plot.PolarPlot polarPlot18 = new org.jfree.chart.plot.PolarPlot(xYDataset14, (org.jfree.chart.axis.ValueAxis) dateAxis16, polarItemRenderer17);
        org.jfree.data.Range range19 = dateAxis16.getRange();
        java.util.Date date20 = dateAxis16.getMinimumDate();
        boolean boolean21 = size2D11.equals((java.lang.Object) date20);
        java.awt.Paint paint22 = piePlot0.getSectionPaint((java.lang.Comparable) boolean21);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(paint22);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        double double0 = org.jfree.chart.axis.DateAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE_IN_MILLISECONDS;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.0d + "'", double0 == 2.0d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = null;
        org.jfree.chart.text.TextBlock textBlock3 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint2);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = textBlock3.getLineAlignment();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = textBlock3.getLineAlignment();
        org.junit.Assert.assertNotNull(textBlock3);
        org.junit.Assert.assertNotNull(horizontalAlignment4);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        java.lang.Comparable comparable1 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset0, comparable1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis((int) '4', valueAxis3, false);
        categoryPlot0.configureRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer12 = null;
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) dateAxis11, polarItemRenderer12);
        dateAxis11.setLabelAngle((double) (byte) 1);
        dateAxis11.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int19 = color18.getAlpha();
        java.lang.String str20 = color18.toString();
        dateAxis11.setTickMarkPaint((java.awt.Paint) color18);
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = piePlot22.getSimpleLabelOffset();
        java.awt.Stroke stroke24 = piePlot22.getLabelOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, (java.awt.Paint) color18, stroke24);
        org.jfree.chart.util.Layer layer26 = null;
        categoryPlot0.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker25, layer26);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder28 = null;
        try {
            categoryPlot0.setDatasetRenderingOrder(datasetRenderingOrder28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 255 + "'", int19 == 255);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str20.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke24);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("ClassContext");
        java.util.EventListener eventListener2 = null;
        boolean boolean3 = numberAxis3D1.hasListener(eventListener2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        dateAxis2.setLabelAngle((double) (byte) 1);
        dateAxis2.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int10 = color9.getAlpha();
        dateAxis2.setTickLabelPaint((java.awt.Paint) color9);
        dateAxis2.setInverted(false);
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer17 = null;
        org.jfree.chart.plot.PolarPlot polarPlot18 = new org.jfree.chart.plot.PolarPlot(xYDataset14, (org.jfree.chart.axis.ValueAxis) dateAxis16, polarItemRenderer17);
        dateAxis16.setLabelAngle((double) (byte) 1);
        dateAxis16.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color23 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int24 = color23.getAlpha();
        java.lang.String str25 = color23.toString();
        dateAxis16.setTickMarkPaint((java.awt.Paint) color23);
        org.jfree.data.Range range27 = dateAxis16.getDefaultAutoRange();
        dateAxis2.setRange(range27, false, false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 255 + "'", int10 == 255);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 255 + "'", int24 == 255);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str25.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(range27);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        int int5 = polarPlot4.getBackgroundImageAlignment();
        boolean boolean6 = polarPlot4.isSubplot();
        boolean boolean7 = polarPlot4.isDomainZoomable();
        polarPlot4.zoom((double) 15);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis((int) '4', valueAxis3, false);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean9 = categoryPlot8.isDomainGridlinesVisible();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        float float11 = categoryPlot10.getForegroundAlpha();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = categoryPlot10.getRenderer(255);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        categoryPlot10.setDataset(categoryDataset14);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        float float17 = categoryPlot16.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation18 = categoryPlot16.getRangeAxisLocation();
        categoryPlot10.setDomainAxisLocation(axisLocation18, true);
        categoryPlot8.setRangeAxisLocation(axisLocation18, false);
        try {
            categoryPlot0.setRangeAxisLocation((-1), axisLocation18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 1.0f + "'", float11 == 1.0f);
        org.junit.Assert.assertNull(categoryItemRenderer13);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 1.0f + "'", float17 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation18);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("ClassContext", graphics2D1, (double) 0L, (float) (short) 100, (float) (-16056329));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.function.Function2D function2D0 = null;
        java.lang.Comparable comparable4 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, 1.0d, 2.0d, 0, comparable4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setInnerSeparatorExtension((double) '#');
        org.jfree.chart.util.Rotation rotation3 = ringPlot0.getDirection();
        java.awt.Stroke stroke4 = null;
        try {
            ringPlot0.setSeparatorStroke(stroke4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rotation3);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setInnerSeparatorExtension((double) '#');
        org.jfree.chart.util.Rotation rotation3 = ringPlot0.getDirection();
        double double4 = ringPlot0.getShadowXOffset();
        double double5 = ringPlot0.getInnerSeparatorExtension();
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) dateAxis8, polarItemRenderer9);
        dateAxis8.setLabelAngle((double) (byte) 1);
        dateAxis8.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int16 = color15.getAlpha();
        java.lang.String str17 = color15.toString();
        dateAxis8.setTickMarkPaint((java.awt.Paint) color15);
        ringPlot0.setLabelShadowPaint((java.awt.Paint) color15);
        java.awt.color.ColorSpace colorSpace20 = null;
        float[] floatArray21 = null;
        try {
            float[] floatArray22 = color15.getComponents(colorSpace20, floatArray21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 35.0d + "'", double5 == 35.0d);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 255 + "'", int16 == 255);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str17.equals("java.awt.Color[r=255,g=255,b=64]"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        dateAxis3.setLabelAngle((double) (byte) 1);
        dateAxis3.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int11 = color10.getAlpha();
        java.lang.String str12 = color10.toString();
        dateAxis3.setTickMarkPaint((java.awt.Paint) color10);
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = piePlot14.getSimpleLabelOffset();
        java.awt.Stroke stroke16 = piePlot14.getLabelOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, (java.awt.Paint) color10, stroke16);
        java.awt.Paint paint18 = valueMarker17.getOutlinePaint();
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer22 = null;
        org.jfree.chart.plot.PolarPlot polarPlot23 = new org.jfree.chart.plot.PolarPlot(xYDataset19, (org.jfree.chart.axis.ValueAxis) dateAxis21, polarItemRenderer22);
        org.jfree.chart.title.LegendTitle legendTitle24 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot23);
        java.awt.Color color25 = java.awt.Color.green;
        java.awt.Color color26 = color25.darker();
        legendTitle24.setBackgroundPaint((java.awt.Paint) color25);
        java.lang.Class<?> wildcardClass28 = legendTitle24.getClass();
        try {
            java.util.EventListener[] eventListenerArray29 = valueMarker17.getListeners((java.lang.Class) wildcardClass28);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: [Lorg.jfree.chart.title.LegendTitle; cannot be cast to [Ljava.util.EventListener;");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 255 + "'", int11 == 255);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str12.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(wildcardClass28);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.clearDomainMarkers(15);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer27 = null;
        org.jfree.chart.plot.PolarPlot polarPlot28 = new org.jfree.chart.plot.PolarPlot(xYDataset24, (org.jfree.chart.axis.ValueAxis) dateAxis26, polarItemRenderer27);
        dateAxis26.setLabelAngle((double) (byte) 1);
        dateAxis26.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color33 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int34 = color33.getAlpha();
        dateAxis26.setTickLabelPaint((java.awt.Paint) color33);
        dateAxis26.setInverted(false);
        double double38 = dateAxis26.getLowerBound();
        org.jfree.data.Range range39 = xYPlot21.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis26);
        java.awt.Graphics2D graphics2D40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        try {
            xYPlot21.drawBackground(graphics2D40, rectangle2D41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 255 + "'", int34 == 255);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNull(range39);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        java.awt.Paint paint1 = waferMapPlot0.getBackgroundPaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        waferMapPlot0.rendererChanged(rendererChangeEvent2);
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        waferMapPlot0.setDataset(waferMapDataset1);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.image.ColorModel colorModel5 = null;
        java.awt.Rectangle rectangle6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = piePlot7.getSimpleLabelOffset();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer12 = null;
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) dateAxis11, polarItemRenderer12);
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot13);
        java.awt.geom.Rectangle2D rectangle2D15 = legendTitle14.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType16 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = rectangleInsets8.createAdjustedRectangle(rectangle2D15, lengthAdjustmentType16, lengthAdjustmentType17);
        java.awt.geom.AffineTransform affineTransform19 = null;
        java.awt.RenderingHints renderingHints20 = null;
        java.awt.PaintContext paintContext21 = color4.createContext(colorModel5, rectangle6, rectangle2D18, affineTransform19, renderingHints20);
        java.awt.geom.Point2D point2D22 = null;
        org.jfree.chart.plot.PlotState plotState23 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        try {
            waferMapPlot0.draw(graphics2D3, (java.awt.geom.Rectangle2D) rectangle6, point2D22, plotState23, plotRenderingInfo24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(paintContext21);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        java.awt.Stroke stroke22 = xYPlot21.getDomainZeroBaselineStroke();
        java.awt.Paint paint23 = xYPlot21.getRangeGridlinePaint();
        java.awt.Paint paint24 = null;
        try {
            xYPlot21.setRangeZeroBaselinePaint(paint24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        org.jfree.data.Range range5 = dateAxis2.getRange();
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent9 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) range5, jFreeChart6, 255, (int) (short) 10);
        chartProgressEvent9.setType((int) '#');
        java.lang.String str12 = chartProgressEvent9.toString();
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.chart.event.ChartProgressEvent[source=[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]]" + "'", str12.equals("org.jfree.chart.event.ChartProgressEvent[source=[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]]"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = null;
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0, keyToGroupMap1);
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        int int5 = polarPlot4.getBackgroundImageAlignment();
        boolean boolean6 = polarPlot4.isOutlineVisible();
        java.awt.Paint paint7 = polarPlot4.getRadiusGridlinePaint();
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer11 = null;
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot(xYDataset8, (org.jfree.chart.axis.ValueAxis) dateAxis10, polarItemRenderer11);
        int int13 = polarPlot12.getBackgroundImageAlignment();
        boolean boolean14 = polarPlot12.isSubplot();
        java.awt.Color color15 = java.awt.Color.blue;
        polarPlot12.setAngleLabelPaint((java.awt.Paint) color15);
        java.awt.Font font17 = polarPlot12.getAngleLabelFont();
        polarPlot4.setNoDataMessageFont(font17);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(font17);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = piePlot0.getSimpleLabelOffset();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        piePlot0.markerChanged(markerChangeEvent2);
        java.lang.Object obj4 = piePlot0.clone();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator5 = null;
        piePlot0.setToolTipGenerator(pieToolTipGenerator5);
        java.awt.Stroke stroke7 = piePlot0.getLabelLinkStroke();
        double double8 = piePlot0.getShadowXOffset();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        float float10 = categoryPlot9.getForegroundAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        categoryPlot9.setRangeAxis((int) '4', valueAxis12, false);
        categoryPlot9.configureRangeAxes();
        java.awt.Stroke stroke16 = categoryPlot9.getRangeCrosshairStroke();
        piePlot0.setLabelOutlineStroke(stroke16);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 1.0f + "'", float10 == 1.0f);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        dateAxis2.setLabelAngle((double) (byte) 1);
        dateAxis2.setAutoRangeMinimumSize((double) (byte) 10);
        org.jfree.data.Range range9 = null;
        try {
            dateAxis2.setRange(range9, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", "hi!", "PlotOrientation.VERTICAL", "hi!");
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        int int3 = java.awt.Color.HSBtoRGB((float) (byte) 10, (float) (short) 1, 0.0f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_MINIMUM_ARC_ANGLE_TO_DRAW;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-5d + "'", double0 == 1.0E-5d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        xYPlot21.zoomRangeAxes((double) ' ', plotRenderingInfo23, point2D24);
        java.awt.Paint paint26 = xYPlot21.getDomainTickBandPaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent27 = null;
        xYPlot21.rendererChanged(rendererChangeEvent27);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation29 = null;
        try {
            boolean boolean30 = xYPlot21.removeAnnotation(xYAnnotation29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertNull(paint26);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = categoryPlot0.getRenderer();
        java.lang.String str4 = categoryPlot0.getPlotType();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) dateAxis8, polarItemRenderer9);
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot10);
        java.awt.geom.Rectangle2D rectangle2D12 = legendTitle11.getBounds();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        boolean boolean15 = categoryPlot0.render(graphics2D5, rectangle2D12, (int) (byte) 1, plotRenderingInfo14);
        categoryPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis18 = categoryPlot0.getRangeAxis();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNull(categoryItemRenderer3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Category Plot" + "'", str4.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(valueAxis18);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("org.jfree.chart.event.ChartProgressEvent[source=[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]]", graphics2D1, (double) (-16056329), (float) 1, (float) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        float float2 = categoryPlot1.getForegroundAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        categoryPlot1.setRangeAxis((int) '4', valueAxis4, false);
        categoryPlot1.configureRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer13 = null;
        org.jfree.chart.plot.PolarPlot polarPlot14 = new org.jfree.chart.plot.PolarPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) dateAxis12, polarItemRenderer13);
        dateAxis12.setLabelAngle((double) (byte) 1);
        dateAxis12.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int20 = color19.getAlpha();
        java.lang.String str21 = color19.toString();
        dateAxis12.setTickMarkPaint((java.awt.Paint) color19);
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = piePlot23.getSimpleLabelOffset();
        java.awt.Stroke stroke25 = piePlot23.getLabelOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, (java.awt.Paint) color19, stroke25);
        org.jfree.chart.util.Layer layer27 = null;
        categoryPlot1.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker26, layer27);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        java.awt.geom.Point2D point2D31 = null;
        categoryPlot1.zoomRangeAxes(32.0d, plotRenderingInfo30, point2D31, true);
        boolean boolean34 = textAnchor0.equals((java.lang.Object) point2D31);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 255 + "'", int20 == 255);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str21.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.data.time.DateRange dateRange2 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = new org.jfree.chart.block.RectangleConstraint((double) '#', (org.jfree.data.Range) dateRange2);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = new org.jfree.chart.block.RectangleConstraint(10.0d, (org.jfree.data.Range) dateRange2);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = rectangleConstraint4.getHeightConstraintType();
        double double6 = rectangleConstraint4.getHeight();
        org.junit.Assert.assertNotNull(dateRange2);
        org.junit.Assert.assertNotNull(lengthConstraintType5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = piePlot0.getSimpleLabelOffset();
        boolean boolean2 = piePlot0.getSectionOutlinesVisible();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator3 = null;
        piePlot0.setLegendLabelURLGenerator(pieURLGenerator3);
        boolean boolean5 = piePlot0.getSimpleLabels();
        boolean boolean6 = piePlot0.getLabelLinksVisible();
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        try {
            piePlot0.drawBackground(graphics2D7, rectangle2D8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        org.jfree.data.time.DateRange dateRange5 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double6 = dateRange5.getUpperBound();
        dateAxis2.setRange((org.jfree.data.Range) dateRange5);
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        try {
            java.util.Date date9 = dateAxis2.calculateHighestVisibleTickValue(dateTickUnit8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateRange5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        java.awt.Color color0 = java.awt.Color.BLACK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        dateAxis3.setLabelAngle((double) (byte) 1);
        dateAxis3.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int11 = color10.getAlpha();
        dateAxis3.setTickLabelPaint((java.awt.Paint) color10);
        double double13 = dateAxis3.getFixedAutoRange();
        org.jfree.data.Range range14 = dateAxis3.getDefaultAutoRange();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, valueAxis15, xYItemRenderer16);
        boolean boolean18 = dateAxis3.isPositiveArrowVisible();
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 255 + "'", int11 == 255);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        java.awt.Paint paint2 = textTitle1.getPaint();
        java.lang.String str3 = textTitle1.getToolTipText();
        java.lang.Object obj4 = textTitle1.clone();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) ' ', 0.0d);
        double double3 = size2D2.width;
        size2D2.setWidth((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        categoryPlot0.setForegroundAlpha((float) 1);
        boolean boolean4 = categoryPlot0.getDrawSharedDomainAxis();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        try {
            xYPlot21.setDataset((-1), xYDataset23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", "", "Category Plot");
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = piePlot5.getSimpleLabelOffset();
        java.awt.Paint paint8 = piePlot5.getSectionPaint((java.lang.Comparable) 10);
        java.lang.Object obj9 = piePlot5.clone();
        boolean boolean10 = basicProjectInfo4.equals(obj9);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        boolean boolean2 = categoryPlot0.isDomainGridlinesVisible();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        boolean boolean7 = categoryPlot0.render(graphics2D3, rectangle2D4, (int) (byte) 10, plotRenderingInfo6);
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot0.getDataset((int) ' ');
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot0.getRowRenderingOrder();
        java.awt.Paint paint11 = null;
        try {
            categoryPlot0.setRangeCrosshairPaint(paint11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertNotNull(sortOrder10);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation();
        boolean boolean3 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent4 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent4);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        java.awt.Paint paint2 = textTitle1.getPaint();
        java.lang.String str3 = textTitle1.getToolTipText();
        double double4 = textTitle1.getContentXOffset();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Paint paint2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = null;
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) dateAxis8, polarItemRenderer9);
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = piePlot11.getSimpleLabelOffset();
        double double13 = rectangleInsets12.getRight();
        dateAxis8.setLabelInsets(rectangleInsets12);
        try {
            org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle("PlotOrientation.VERTICAL", font1, paint2, rectangleEdge3, horizontalAlignment4, verticalAlignment5, rectangleInsets12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'horizontalAlignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.18d + "'", double13 == 0.18d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot4);
        org.jfree.chart.block.BlockContainer blockContainer6 = legendTitle5.getItemContainer();
        org.jfree.chart.block.Arrangement arrangement7 = blockContainer6.getArrangement();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("hi!");
        java.lang.String str11 = textTitle10.getToolTipText();
        java.awt.geom.Rectangle2D rectangle2D12 = textTitle10.getBounds();
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = piePlot13.getSimpleLabelOffset();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent15 = null;
        piePlot13.markerChanged(markerChangeEvent15);
        try {
            java.lang.Object obj17 = blockContainer6.draw(graphics2D8, rectangle2D12, (java.lang.Object) markerChangeEvent15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockContainer6);
        org.junit.Assert.assertNotNull(arrangement7);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNotNull(rectangleInsets14);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = categoryPlot0.getRenderer();
        boolean boolean4 = categoryPlot0.isRangeZoomable();
        boolean boolean5 = categoryPlot0.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNull(categoryItemRenderer3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        java.awt.Stroke stroke22 = xYPlot21.getDomainZeroBaselineStroke();
        try {
            java.awt.Paint paint24 = xYPlot21.getQuadrantPaint((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (-1) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        org.jfree.data.Range range5 = dateAxis2.getRange();
        java.util.Date date6 = dateAxis2.getMinimumDate();
        dateAxis2.setFixedAutoRange(4.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        float float2 = categoryPlot0.getBackgroundImageAlpha();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        float float4 = categoryPlot3.getForegroundAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        categoryPlot3.setRangeAxis((int) '4', valueAxis6, false);
        categoryPlot3.configureRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer15 = null;
        org.jfree.chart.plot.PolarPlot polarPlot16 = new org.jfree.chart.plot.PolarPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) dateAxis14, polarItemRenderer15);
        dateAxis14.setLabelAngle((double) (byte) 1);
        dateAxis14.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int22 = color21.getAlpha();
        java.lang.String str23 = color21.toString();
        dateAxis14.setTickMarkPaint((java.awt.Paint) color21);
        org.jfree.chart.plot.PiePlot piePlot25 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = piePlot25.getSimpleLabelOffset();
        java.awt.Stroke stroke27 = piePlot25.getLabelOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker28 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, (java.awt.Paint) color21, stroke27);
        org.jfree.chart.util.Layer layer29 = null;
        categoryPlot3.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker28, layer29);
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource33 = null;
        dateAxis32.setStandardTickUnits(tickUnitSource33);
        java.awt.Stroke stroke35 = dateAxis32.getTickMarkStroke();
        valueMarker28.setStroke(stroke35);
        categoryPlot0.setRangeGridlineStroke(stroke35);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder38 = null;
        try {
            categoryPlot0.setDatasetRenderingOrder(datasetRenderingOrder38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.5f + "'", float2 == 0.5f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 255 + "'", int22 == 255);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str23.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(stroke35);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(255, (int) '4', (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Blue");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        boolean boolean0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        try {
            float float4 = textFragment1.calculateBaselineOffset(graphics2D2, textAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor3);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot4);
        polarPlot4.setBackgroundAlpha((float) (byte) 100);
        java.awt.Stroke stroke8 = polarPlot4.getRadiusGridlineStroke();
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        polarPlot4.zoomRangeAxes((double) 100, (double) 1.0f, plotRenderingInfo7, point2D8);
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = piePlot10.getSimpleLabelOffset();
        double double12 = rectangleInsets11.getRight();
        polarPlot4.setInsets(rectangleInsets11, true);
        org.jfree.chart.axis.ValueAxis valueAxis15 = polarPlot4.getAxis();
        java.lang.String str16 = polarPlot4.getPlotType();
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.18d + "'", double12 == 0.18d);
        org.junit.Assert.assertNotNull(valueAxis15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Polar Plot" + "'", str16.equals("Polar Plot"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = piePlot0.getSimpleLabelOffset();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        piePlot0.markerChanged(markerChangeEvent2);
        java.lang.Object obj4 = piePlot0.clone();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator5 = null;
        piePlot0.setToolTipGenerator(pieToolTipGenerator5);
        double double7 = piePlot0.getMaximumExplodePercent();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        dateAxis2.setLabelAngle((double) (byte) 1);
        dateAxis2.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int10 = color9.getAlpha();
        dateAxis2.setTickLabelPaint((java.awt.Paint) color9);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean13 = categoryPlot12.isDomainGridlinesVisible();
        boolean boolean14 = categoryPlot12.isDomainGridlinesVisible();
        int int15 = categoryPlot12.getRangeAxisCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = categoryPlot12.getDomainAxis((int) (byte) 0);
        boolean boolean18 = dateAxis2.hasListener((java.util.EventListener) categoryPlot12);
        double double19 = categoryPlot12.getAnchorValue();
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 255 + "'", int10 == 255);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNull(categoryAxis17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_FINISHED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 100, 0.4d);
        org.jfree.data.time.DateRange dateRange11 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((double) '#', (org.jfree.data.Range) dateRange11);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint9.toRangeHeight((org.jfree.data.Range) dateRange11);
        org.jfree.chart.util.Size2D size2D14 = legendTitle5.arrange(graphics2D6, rectangleConstraint9);
        legendTitle5.setNotify(true);
        org.jfree.chart.block.BlockContainer blockContainer17 = legendTitle5.getItemContainer();
        org.junit.Assert.assertNotNull(dateRange11);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(size2D14);
        org.junit.Assert.assertNotNull(blockContainer17);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        double double5 = dateAxis2.getLabelAngle();
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = dateAxis2.getTickUnit();
        dateAxis2.setLabelAngle(0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(dateTickUnit6);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        double double5 = dateAxis2.getLabelAngle();
        java.awt.Paint paint6 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        dateAxis2.setLabelPaint(paint6);
        org.jfree.chart.plot.Plot plot8 = dateAxis2.getPlot();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(plot8);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        java.awt.Color color2 = java.awt.Color.MAGENTA;
        boolean boolean3 = categoryPlot0.equals((java.lang.Object) color2);
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        try {
            categoryPlot0.addDomainMarker(categoryMarker4, layer5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.clearDomainMarkers(15);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        float float26 = categoryPlot25.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot25.getRangeAxisLocation();
        xYPlot21.setDomainAxisLocation((int) (byte) 0, axisLocation27, true);
        java.awt.Color color30 = java.awt.Color.WHITE;
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        float[] floatArray36 = new float[] { (-1.0f), 10, (short) 0, '#' };
        float[] floatArray37 = color31.getRGBComponents(floatArray36);
        float[] floatArray38 = color30.getColorComponents(floatArray36);
        xYPlot21.setRangeCrosshairPaint((java.awt.Paint) color30);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 1.0f + "'", float26 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(floatArray38);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("ClassContext");
        numberAxis3D1.setLabel("RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]");
        java.awt.Color color5 = java.awt.Color.GRAY;
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) dateAxis9, polarItemRenderer10);
        dateAxis9.setLabelAngle((double) (byte) 1);
        dateAxis9.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int17 = color16.getAlpha();
        java.lang.String str18 = color16.toString();
        dateAxis9.setTickMarkPaint((java.awt.Paint) color16);
        org.jfree.chart.plot.PiePlot piePlot20 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = piePlot20.getSimpleLabelOffset();
        java.awt.Stroke stroke22 = piePlot20.getLabelOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, (java.awt.Paint) color16, stroke22);
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((-1.0d), (java.awt.Paint) color5, stroke22);
        numberAxis3D1.setAxisLineStroke(stroke22);
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        float float30 = categoryPlot29.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation31 = categoryPlot29.getRangeAxisLocation();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = categoryPlot29.getRenderer();
        java.lang.String str33 = categoryPlot29.getPlotType();
        java.awt.Graphics2D graphics2D34 = null;
        org.jfree.data.xy.XYDataset xYDataset35 = null;
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer38 = null;
        org.jfree.chart.plot.PolarPlot polarPlot39 = new org.jfree.chart.plot.PolarPlot(xYDataset35, (org.jfree.chart.axis.ValueAxis) dateAxis37, polarItemRenderer38);
        org.jfree.chart.title.LegendTitle legendTitle40 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot39);
        java.awt.geom.Rectangle2D rectangle2D41 = legendTitle40.getBounds();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = null;
        boolean boolean44 = categoryPlot29.render(graphics2D34, rectangle2D41, (int) (byte) 1, plotRenderingInfo43);
        org.jfree.data.xy.XYDataset xYDataset45 = null;
        org.jfree.data.xy.XYDataset xYDataset46 = null;
        org.jfree.chart.axis.DateAxis dateAxis48 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer49 = null;
        org.jfree.chart.plot.PolarPlot polarPlot50 = new org.jfree.chart.plot.PolarPlot(xYDataset46, (org.jfree.chart.axis.ValueAxis) dateAxis48, polarItemRenderer49);
        org.jfree.chart.plot.PiePlot piePlot51 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = piePlot51.getSimpleLabelOffset();
        double double53 = rectangleInsets52.getRight();
        dateAxis48.setLabelInsets(rectangleInsets52);
        dateAxis48.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis59 = new org.jfree.chart.axis.DateAxis("");
        dateAxis59.setRange((double) 0.0f, (double) 10.0f);
        dateAxis59.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer65 = null;
        org.jfree.chart.plot.XYPlot xYPlot66 = new org.jfree.chart.plot.XYPlot(xYDataset45, (org.jfree.chart.axis.ValueAxis) dateAxis48, (org.jfree.chart.axis.ValueAxis) dateAxis59, xYItemRenderer65);
        xYPlot66.clearDomainMarkers(15);
        org.jfree.data.xy.XYDataset xYDataset69 = null;
        org.jfree.chart.axis.DateAxis dateAxis71 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer72 = null;
        org.jfree.chart.plot.PolarPlot polarPlot73 = new org.jfree.chart.plot.PolarPlot(xYDataset69, (org.jfree.chart.axis.ValueAxis) dateAxis71, polarItemRenderer72);
        dateAxis71.setLabelAngle((double) (byte) 1);
        dateAxis71.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color78 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int79 = color78.getAlpha();
        dateAxis71.setTickLabelPaint((java.awt.Paint) color78);
        dateAxis71.setInverted(false);
        double double83 = dateAxis71.getLowerBound();
        org.jfree.data.Range range84 = xYPlot66.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis71);
        org.jfree.chart.util.RectangleEdge rectangleEdge85 = xYPlot66.getRangeAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo86 = null;
        try {
            org.jfree.chart.axis.AxisState axisState87 = numberAxis3D1.draw(graphics2D26, (double) '4', rectangle2D28, rectangle2D41, rectangleEdge85, plotRenderingInfo86);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 255 + "'", int17 == 255);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str18.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 1.0f + "'", float30 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNull(categoryItemRenderer32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Category Plot" + "'", str33.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(rectangleInsets52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.18d + "'", double53 == 0.18d);
        org.junit.Assert.assertNotNull(color78);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 255 + "'", int79 == 255);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 0.0d + "'", double83 == 0.0d);
        org.junit.Assert.assertNull(range84);
        org.junit.Assert.assertNotNull(rectangleEdge85);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        xYPlot21.zoomRangeAxes((double) ' ', plotRenderingInfo23, point2D24);
        java.awt.Paint paint26 = xYPlot21.getDomainTickBandPaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent27 = null;
        xYPlot21.rendererChanged(rendererChangeEvent27);
        xYPlot21.clearRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.Object obj32 = categoryPlot31.clone();
        org.jfree.chart.axis.AxisLocation axisLocation33 = categoryPlot31.getRangeAxisLocation();
        try {
            xYPlot21.setDomainAxisLocation((-1), axisLocation33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertNull(paint26);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertNotNull(axisLocation33);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        xYPlot21.zoomRangeAxes((double) ' ', plotRenderingInfo23, point2D24);
        java.awt.Paint paint26 = xYPlot21.getDomainTickBandPaint();
        double double27 = xYPlot21.getRangeCrosshairValue();
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean30 = categoryPlot29.isDomainGridlinesVisible();
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot();
        float float32 = categoryPlot31.getForegroundAlpha();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = categoryPlot31.getRenderer(255);
        org.jfree.data.category.CategoryDataset categoryDataset35 = null;
        categoryPlot31.setDataset(categoryDataset35);
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot();
        float float38 = categoryPlot37.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation39 = categoryPlot37.getRangeAxisLocation();
        categoryPlot31.setDomainAxisLocation(axisLocation39, true);
        categoryPlot29.setRangeAxisLocation(axisLocation39, false);
        try {
            xYPlot21.setRangeAxisLocation((-1), axisLocation39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertNull(paint26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + float32 + "' != '" + 1.0f + "'", float32 == 1.0f);
        org.junit.Assert.assertNull(categoryItemRenderer34);
        org.junit.Assert.assertTrue("'" + float38 + "' != '" + 1.0f + "'", float38 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation39);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(0.0d, (double) 0.5f);
        double double3 = size2D2.height;
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.5d + "'", double3 == 0.5d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.clearDomainMarkers(15);
        org.jfree.chart.LegendItemCollection legendItemCollection24 = xYPlot21.getFixedLegendItems();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = xYPlot21.getAxisOffset();
        boolean boolean26 = xYPlot21.isRangeZoomable();
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        float float28 = categoryPlot27.getForegroundAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        categoryPlot27.setRangeAxis((int) '4', valueAxis30, false);
        categoryPlot27.configureRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset36 = null;
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer39 = null;
        org.jfree.chart.plot.PolarPlot polarPlot40 = new org.jfree.chart.plot.PolarPlot(xYDataset36, (org.jfree.chart.axis.ValueAxis) dateAxis38, polarItemRenderer39);
        dateAxis38.setLabelAngle((double) (byte) 1);
        dateAxis38.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color45 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int46 = color45.getAlpha();
        java.lang.String str47 = color45.toString();
        dateAxis38.setTickMarkPaint((java.awt.Paint) color45);
        org.jfree.chart.plot.PiePlot piePlot49 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = piePlot49.getSimpleLabelOffset();
        java.awt.Stroke stroke51 = piePlot49.getLabelOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker52 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, (java.awt.Paint) color45, stroke51);
        org.jfree.chart.util.Layer layer53 = null;
        categoryPlot27.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker52, layer53);
        org.jfree.chart.axis.DateAxis dateAxis56 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource57 = null;
        dateAxis56.setStandardTickUnits(tickUnitSource57);
        java.awt.Stroke stroke59 = dateAxis56.getTickMarkStroke();
        valueMarker52.setStroke(stroke59);
        org.jfree.chart.util.Layer layer61 = null;
        try {
            xYPlot21.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker52, layer61);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertNull(legendItemCollection24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 1.0f + "'", float28 == 1.0f);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 255 + "'", int46 == 255);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str47.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(rectangleInsets50);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(stroke59);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        boolean boolean2 = categoryPlot0.isDomainGridlinesVisible();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        boolean boolean7 = categoryPlot0.render(graphics2D3, rectangle2D4, (int) (byte) 10, plotRenderingInfo6);
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot0.getDataset((int) ' ');
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = null;
        try {
            categoryPlot0.addDomainMarker(categoryMarker10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(categoryDataset9);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = null;
        org.jfree.chart.text.TextBlock textBlock3 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint2);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = textBlock3.getLineAlignment();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.Font font9 = null;
        java.awt.Paint paint10 = null;
        org.jfree.chart.text.TextBlock textBlock11 = org.jfree.chart.text.TextUtilities.createTextBlock("", font9, paint10);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor15 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        java.awt.Shape shape19 = textBlock11.calculateBounds(graphics2D12, 0.0f, (float) (short) 0, textBlockAnchor15, (float) (byte) 10, (float) 15, (double) 0L);
        textBlock3.draw(graphics2D5, 0.0f, (float) (byte) 10, textBlockAnchor15);
        org.jfree.chart.text.TextLine textLine21 = textBlock3.getLastLine();
        java.awt.Font font24 = null;
        java.awt.Paint paint25 = null;
        org.jfree.chart.text.TextBlock textBlock26 = org.jfree.chart.text.TextUtilities.createTextBlock("", font24, paint25);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment27 = textBlock26.getLineAlignment();
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.Font font32 = null;
        java.awt.Paint paint33 = null;
        org.jfree.chart.text.TextBlock textBlock34 = org.jfree.chart.text.TextUtilities.createTextBlock("", font32, paint33);
        java.awt.Graphics2D graphics2D35 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor38 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        java.awt.Shape shape42 = textBlock34.calculateBounds(graphics2D35, 0.0f, (float) (short) 0, textBlockAnchor38, (float) (byte) 10, (float) 15, (double) 0L);
        textBlock26.draw(graphics2D28, 0.0f, (float) (byte) 10, textBlockAnchor38);
        org.jfree.chart.plot.PiePlot piePlot45 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = piePlot45.getSimpleLabelOffset();
        boolean boolean47 = piePlot45.getSectionOutlinesVisible();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator48 = null;
        piePlot45.setLegendLabelURLGenerator(pieURLGenerator48);
        boolean boolean50 = piePlot45.getSimpleLabels();
        org.jfree.chart.plot.RingPlot ringPlot51 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint52 = ringPlot51.getShadowPaint();
        ringPlot51.setInteriorGap((double) (byte) 0);
        java.awt.Font font55 = ringPlot51.getNoDataMessageFont();
        piePlot45.setLabelFont(font55);
        java.awt.Color color57 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        textBlock26.addLine("", font55, (java.awt.Paint) color57);
        org.jfree.data.xy.XYDataset xYDataset59 = null;
        org.jfree.chart.axis.DateAxis dateAxis61 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer62 = null;
        org.jfree.chart.plot.PolarPlot polarPlot63 = new org.jfree.chart.plot.PolarPlot(xYDataset59, (org.jfree.chart.axis.ValueAxis) dateAxis61, polarItemRenderer62);
        dateAxis61.setLabelAngle((double) (byte) 1);
        dateAxis61.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color68 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int69 = color68.getAlpha();
        dateAxis61.setTickLabelPaint((java.awt.Paint) color68);
        textBlock3.addLine("", font55, (java.awt.Paint) color68);
        org.junit.Assert.assertNotNull(textBlock3);
        org.junit.Assert.assertNotNull(horizontalAlignment4);
        org.junit.Assert.assertNotNull(textBlock11);
        org.junit.Assert.assertNotNull(textBlockAnchor15);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNull(textLine21);
        org.junit.Assert.assertNotNull(textBlock26);
        org.junit.Assert.assertNotNull(horizontalAlignment27);
        org.junit.Assert.assertNotNull(textBlock34);
        org.junit.Assert.assertNotNull(textBlockAnchor38);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNotNull(rectangleInsets46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNotNull(font55);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertNotNull(color68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 255 + "'", int69 == 255);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot0.zoomRangeAxes((-1.0d), plotRenderingInfo6, point2D7, false);
        categoryPlot0.setDrawSharedDomainAxis(false);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation2);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 100, 0.4d);
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((double) '#', (org.jfree.data.Range) dateRange4);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = rectangleConstraint2.toRangeHeight((org.jfree.data.Range) dateRange4);
        double double8 = dateRange4.constrain(0.0d);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(rectangleConstraint6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.setDomainGridlinesVisible(true);
        double double24 = xYPlot21.getDomainCrosshairValue();
        boolean boolean25 = xYPlot21.isDomainCrosshairLockedOnData();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation26 = null;
        try {
            xYPlot21.addAnnotation(xYAnnotation26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        ringPlot0.markerChanged(markerChangeEvent1);
        org.jfree.data.general.WaferMapDataset waferMapDataset3 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot4 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset3);
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer5 = null;
        waferMapPlot4.setRenderer(waferMapRenderer5);
        boolean boolean7 = ringPlot0.equals((java.lang.Object) waferMapPlot4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.clearDomainMarkers(15);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        float float26 = categoryPlot25.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot25.getRangeAxisLocation();
        xYPlot21.setDomainAxisLocation((int) (byte) 0, axisLocation27, true);
        xYPlot21.setDomainCrosshairValue((double) 'a');
        org.jfree.chart.axis.AxisLocation axisLocation32 = xYPlot21.getRangeAxisLocation();
        java.awt.Graphics2D graphics2D33 = null;
        org.jfree.chart.title.TextTitle textTitle35 = new org.jfree.chart.title.TextTitle("hi!");
        java.lang.String str36 = textTitle35.getToolTipText();
        java.awt.geom.Rectangle2D rectangle2D37 = textTitle35.getBounds();
        try {
            xYPlot21.drawBackground(graphics2D33, rectangle2D37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 1.0f + "'", float26 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertNotNull(rectangle2D37);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int2 = color1.getAlpha();
        java.lang.String str3 = color1.toString();
        piePlot0.setLabelPaint((java.awt.Paint) color1);
        java.awt.Paint paint5 = piePlot0.getBaseSectionOutlinePaint();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 255 + "'", int2 == 255);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str3.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        org.jfree.data.Range range5 = dateAxis2.getRange();
        boolean boolean7 = range5.equals((java.lang.Object) 255);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.setDomainGridlinesVisible(true);
        double double24 = xYPlot21.getDomainCrosshairValue();
        java.awt.geom.Point2D point2D25 = null;
        try {
            xYPlot21.setQuadrantOrigin(point2D25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'origin' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.clearDomainMarkers(15);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        float float26 = categoryPlot25.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot25.getRangeAxisLocation();
        xYPlot21.setDomainAxisLocation((int) (byte) 0, axisLocation27, true);
        xYPlot21.setDomainCrosshairValue((double) 'a');
        xYPlot21.mapDatasetToRangeAxis(100, 255);
        xYPlot21.setRangeGridlinesVisible(true);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 1.0f + "'", float26 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation27);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        java.awt.Paint paint0 = null;
        java.awt.Stroke stroke1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) dateAxis4, polarItemRenderer5);
        int int7 = polarPlot6.getBackgroundImageAlignment();
        boolean boolean8 = polarPlot6.isSubplot();
        java.awt.Color color9 = java.awt.Color.blue;
        polarPlot6.setAngleLabelPaint((java.awt.Paint) color9);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = polarPlot6.getInsets();
        try {
            org.jfree.chart.block.LineBorder lineBorder12 = new org.jfree.chart.block.LineBorder(paint0, stroke1, rectangleInsets11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(rectangleInsets11);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation();
        java.lang.String str3 = categoryPlot0.getPlotType();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Category Plot" + "'", str3.equals("Category Plot"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.clearDomainMarkers(15);
        org.jfree.chart.LegendItemCollection legendItemCollection24 = xYPlot21.getFixedLegendItems();
        xYPlot21.setRangeZeroBaselineVisible(true);
        xYPlot21.setWeight(1);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertNull(legendItemCollection24);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot4);
        java.lang.Object obj6 = legendTitle5.clone();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) dateAxis9, polarItemRenderer10);
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = piePlot12.getSimpleLabelOffset();
        double double14 = rectangleInsets13.getRight();
        dateAxis9.setLabelInsets(rectangleInsets13);
        legendTitle5.setLegendItemGraphicPadding(rectangleInsets13);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = legendTitle5.getLegendItemGraphicPadding();
        double double19 = rectangleInsets17.calculateTopOutset((double) (short) 0);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.18d + "'", double14 == 0.18d);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockBorder0.getInsets();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        org.jfree.chart.plot.PiePlotState piePlotState4 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo3);
        piePlotState4.setTotal((double) (short) 0);
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) dateAxis9, polarItemRenderer10);
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot11);
        java.awt.geom.Rectangle2D rectangle2D13 = legendTitle12.getBounds();
        piePlotState4.setLinkArea(rectangle2D13);
        try {
            blockBorder0.draw(graphics2D2, rectangle2D13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(rectangle2D13);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("java.awt.Color[r=255,g=255,b=64]", "hi!", "RectangleInsets[t=0.18,l=0.18,b=0.18,r=0.18]", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]");
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot4);
        java.awt.Color color6 = java.awt.Color.green;
        java.awt.Color color7 = color6.darker();
        legendTitle5.setBackgroundPaint((java.awt.Paint) color6);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.data.time.DateRange dateRange12 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint((double) '#', (org.jfree.data.Range) dateRange12);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint(10.0d, (org.jfree.data.Range) dateRange12);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType15 = rectangleConstraint14.getHeightConstraintType();
        org.jfree.chart.util.Size2D size2D16 = legendTitle5.arrange(graphics2D9, rectangleConstraint14);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.util.Size2D size2D18 = legendTitle5.arrange(graphics2D17);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(dateRange12);
        org.junit.Assert.assertNotNull(lengthConstraintType15);
        org.junit.Assert.assertNotNull(size2D16);
        org.junit.Assert.assertNotNull(size2D18);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = piePlot1.getSimpleLabelOffset();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        piePlot1.markerChanged(markerChangeEvent3);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setLabelBackgroundPaint((java.awt.Paint) color5);
        java.awt.Color color7 = java.awt.Color.getColor("PlotOrientation.VERTICAL", color5);
        int int8 = color7.getAlpha();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 255 + "'", int8 == 255);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = piePlot5.getSimpleLabelOffset();
        double double7 = rectangleInsets6.getRight();
        dateAxis2.setLabelInsets(rectangleInsets6);
        dateAxis2.setTickLabelsVisible(true);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.18d + "'", double7 == 0.18d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        java.lang.String str2 = textTitle1.getToolTipText();
        java.awt.Paint paint3 = textTitle1.getBackgroundPaint();
        double double4 = textTitle1.getContentXOffset();
        boolean boolean5 = textTitle1.getNotify();
        textTitle1.setText("Size2D[width=0.0, height=0.0]");
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(0.0d, (double) 0.5f);
        java.lang.Object obj3 = null;
        boolean boolean4 = size2D2.equals(obj3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.RendererState rendererState1 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        boolean boolean2 = categoryPlot0.isDomainGridlinesVisible();
        int int3 = categoryPlot0.getRangeAxisCount();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent4);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        java.lang.ClassLoader classLoader0 = null;
        try {
            java.util.ResourceBundle.clearCache(classLoader0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.clearDomainMarkers(15);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        float float26 = categoryPlot25.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot25.getRangeAxisLocation();
        xYPlot21.setDomainAxisLocation((int) (byte) 0, axisLocation27, true);
        xYPlot21.setDomainCrosshairValue((double) 'a');
        boolean boolean32 = xYPlot21.isDomainZoomable();
        org.jfree.chart.util.Layer layer34 = null;
        java.util.Collection collection35 = xYPlot21.getRangeMarkers((int) (byte) 10, layer34);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 1.0f + "'", float26 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNull(collection35);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        java.awt.Paint paint2 = textTitle1.getPaint();
        java.lang.String str3 = textTitle1.getToolTipText();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        try {
            textTitle1.setPosition(rectangleEdge4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        dateAxis2.setLabelAngle((double) (byte) 1);
        dateAxis2.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int10 = color9.getAlpha();
        dateAxis2.setTickLabelPaint((java.awt.Paint) color9);
        dateAxis2.setInverted(false);
        double double14 = dateAxis2.getLowerBound();
        double double15 = dateAxis2.getFixedAutoRange();
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 255 + "'", int10 == 255);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        java.util.List list2 = categoryPlot0.getAnnotations();
        java.util.Collection collection3 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list2);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(collection3);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.clearDomainMarkers(15);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        float float26 = categoryPlot25.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot25.getRangeAxisLocation();
        xYPlot21.setDomainAxisLocation((int) (byte) 0, axisLocation27, true);
        boolean boolean30 = xYPlot21.isRangeZoomable();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent31 = null;
        xYPlot21.rendererChanged(rendererChangeEvent31);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 1.0f + "'", float26 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        int int5 = polarPlot4.getBackgroundImageAlignment();
        boolean boolean6 = polarPlot4.isSubplot();
        boolean boolean7 = polarPlot4.isDomainZoomable();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        polarPlot4.handleClick((int) (byte) 10, (int) '4', plotRenderingInfo10);
        org.jfree.chart.axis.TickUnit tickUnit12 = polarPlot4.getAngleTickUnit();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(tickUnit12);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        xYPlot21.zoomRangeAxes((double) ' ', plotRenderingInfo23, point2D24);
        org.jfree.chart.util.Layer layer27 = null;
        java.util.Collection collection28 = xYPlot21.getDomainMarkers((int) (byte) 100, layer27);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertNull(collection28);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("PlotOrientation.VERTICAL");
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setInnerSeparatorExtension((double) (byte) 0);
        java.awt.Stroke stroke3 = ringPlot0.getLabelLinkStroke();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = null;
        ringPlot0.markerChanged(markerChangeEvent4);
        ringPlot0.setCircular(true);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = piePlot0.getSimpleLabelOffset();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        piePlot0.markerChanged(markerChangeEvent2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot0.setLabelBackgroundPaint((java.awt.Paint) color4);
        boolean boolean7 = piePlot0.equals((java.lang.Object) (short) 0);
        java.awt.Shape shape8 = piePlot0.getLegendItemShape();
        double double9 = piePlot0.getMaximumLabelWidth();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.14d + "'", double9 == 0.14d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("java.awt.Color[r=255,g=255,b=64]", graphics2D1, 100.0f, (float) (byte) 100, textAnchor4, (double) 'a', textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("java.awt.Color[r=255,g=255,b=64]", "hi!", "", "java.awt.Color[r=255,g=255,b=64]");
        java.lang.String str5 = basicProjectInfo4.getInfo();
        basicProjectInfo4.addOptionalLibrary("java.awt.Color[r=255,g=255,b=64]");
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str5.equals("java.awt.Color[r=255,g=255,b=64]"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("PlotOrientation.VERTICAL", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        polarPlot4.zoomRangeAxes((double) 100, (double) 1.0f, plotRenderingInfo7, point2D8);
        boolean boolean10 = polarPlot4.isRangeZoomable();
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        int int5 = polarPlot4.getBackgroundImageAlignment();
        boolean boolean6 = polarPlot4.isSubplot();
        boolean boolean7 = polarPlot4.isDomainZoomable();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        polarPlot4.zoomRangeAxes((double) 0.0f, plotRenderingInfo9, point2D10);
        org.jfree.chart.plot.Plot plot12 = polarPlot4.getRootPlot();
        org.jfree.chart.block.ColumnArrangement columnArrangement13 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer18 = null;
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) dateAxis17, polarItemRenderer18);
        org.jfree.chart.plot.PiePlot piePlot20 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = piePlot20.getSimpleLabelOffset();
        double double22 = rectangleInsets21.getRight();
        dateAxis17.setLabelInsets(rectangleInsets21);
        dateAxis17.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("");
        dateAxis28.setRange((double) 0.0f, (double) 10.0f);
        dateAxis28.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset14, (org.jfree.chart.axis.ValueAxis) dateAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis28, xYItemRenderer34);
        xYPlot35.clearDomainMarkers(15);
        org.jfree.data.xy.XYDataset xYDataset38 = null;
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer41 = null;
        org.jfree.chart.plot.PolarPlot polarPlot42 = new org.jfree.chart.plot.PolarPlot(xYDataset38, (org.jfree.chart.axis.ValueAxis) dateAxis40, polarItemRenderer41);
        dateAxis40.setLabelAngle((double) (byte) 1);
        dateAxis40.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color47 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int48 = color47.getAlpha();
        dateAxis40.setTickLabelPaint((java.awt.Paint) color47);
        dateAxis40.setInverted(false);
        double double52 = dateAxis40.getLowerBound();
        org.jfree.data.Range range53 = xYPlot35.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis40);
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = xYPlot35.getRangeAxisEdge();
        boolean boolean55 = columnArrangement13.equals((java.lang.Object) rectangleEdge54);
        org.jfree.chart.block.FlowArrangement flowArrangement56 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.LegendTitle legendTitle57 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot4, (org.jfree.chart.block.Arrangement) columnArrangement13, (org.jfree.chart.block.Arrangement) flowArrangement56);
        java.awt.Paint paint58 = polarPlot4.getRadiusGridlinePaint();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(plot12);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.18d + "'", double22 == 0.18d);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 255 + "'", int48 == 255);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNull(range53);
        org.junit.Assert.assertNotNull(rectangleEdge54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(paint58);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = categoryPlot0.getRenderer();
        java.lang.String str4 = categoryPlot0.getPlotType();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) dateAxis8, polarItemRenderer9);
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot10);
        java.awt.geom.Rectangle2D rectangle2D12 = legendTitle11.getBounds();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        boolean boolean15 = categoryPlot0.render(graphics2D5, rectangle2D12, (int) (byte) 1, plotRenderingInfo14);
        java.awt.Stroke stroke16 = categoryPlot0.getRangeGridlineStroke();
        java.lang.String str17 = categoryPlot0.getPlotType();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNull(categoryItemRenderer3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Category Plot" + "'", str4.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Category Plot" + "'", str17.equals("Category Plot"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis((int) '4', valueAxis3, false);
        categoryPlot0.configureRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer12 = null;
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) dateAxis11, polarItemRenderer12);
        dateAxis11.setLabelAngle((double) (byte) 1);
        dateAxis11.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int19 = color18.getAlpha();
        java.lang.String str20 = color18.toString();
        dateAxis11.setTickMarkPaint((java.awt.Paint) color18);
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = piePlot22.getSimpleLabelOffset();
        java.awt.Stroke stroke24 = piePlot22.getLabelOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, (java.awt.Paint) color18, stroke24);
        org.jfree.chart.util.Layer layer26 = null;
        categoryPlot0.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker25, layer26);
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource30 = null;
        dateAxis29.setStandardTickUnits(tickUnitSource30);
        java.awt.Stroke stroke32 = dateAxis29.getTickMarkStroke();
        valueMarker25.setStroke(stroke32);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType34 = null;
        try {
            valueMarker25.setLabelOffsetType(lengthAdjustmentType34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'adj' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 255 + "'", int19 == 255);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str20.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke32);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("ClassContext");
        boolean boolean2 = numberAxis3D1.isVisible();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer8 = null;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) dateAxis7, polarItemRenderer8);
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot9);
        java.awt.geom.Rectangle2D rectangle2D11 = legendTitle10.getBounds();
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = piePlot12.getSimpleLabelOffset();
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer17 = null;
        org.jfree.chart.plot.PolarPlot polarPlot18 = new org.jfree.chart.plot.PolarPlot(xYDataset14, (org.jfree.chart.axis.ValueAxis) dateAxis16, polarItemRenderer17);
        org.jfree.chart.title.LegendTitle legendTitle19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot18);
        java.awt.geom.Rectangle2D rectangle2D20 = legendTitle19.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType21 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = rectangleInsets13.createAdjustedRectangle(rectangle2D20, lengthAdjustmentType21, lengthAdjustmentType22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        float float25 = categoryPlot24.getForegroundAlpha();
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot24.getRangeAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        try {
            org.jfree.chart.axis.AxisState axisState28 = numberAxis3D1.draw(graphics2D3, (double) (byte) 1, rectangle2D11, rectangle2D20, rectangleEdge26, plotRenderingInfo27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 1.0f + "'", float25 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleEdge26);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        categoryPlot0.setForegroundAlpha((float) 1);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        categoryPlot0.drawBackgroundImage(graphics2D4, rectangle2D5);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = categoryPlot0.getRendererForDataset(categoryDataset7);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(categoryItemRenderer8);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("org.jfree.chart.event.ChartProgressEvent[source=[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]]");
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.time.DateRange dateRange2 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = new org.jfree.chart.block.RectangleConstraint((double) '#', (org.jfree.data.Range) dateRange2);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = new org.jfree.chart.block.RectangleConstraint(10.0d, (org.jfree.data.Range) dateRange2);
        boolean boolean6 = dateRange2.contains(100.0d);
        double double7 = dateRange2.getUpperBound();
        org.junit.Assert.assertNotNull(dateRange2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int2 = color1.getAlpha();
        java.lang.String str3 = color1.toString();
        piePlot0.setLabelPaint((java.awt.Paint) color1);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator5 = piePlot0.getLabelGenerator();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent6 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot0);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        plotChangeEvent6.setType(chartChangeEventType7);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 255 + "'", int2 == 255);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str3.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator5);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Size2D[width=0.0, height=0.0]");
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis((int) '4', valueAxis3, false);
        categoryPlot0.configureRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer12 = null;
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) dateAxis11, polarItemRenderer12);
        dateAxis11.setLabelAngle((double) (byte) 1);
        dateAxis11.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int19 = color18.getAlpha();
        java.lang.String str20 = color18.toString();
        dateAxis11.setTickMarkPaint((java.awt.Paint) color18);
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = piePlot22.getSimpleLabelOffset();
        java.awt.Stroke stroke24 = piePlot22.getLabelOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, (java.awt.Paint) color18, stroke24);
        org.jfree.chart.util.Layer layer26 = null;
        categoryPlot0.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker25, layer26);
        org.jfree.chart.axis.AxisSpace axisSpace28 = categoryPlot0.getFixedDomainAxisSpace();
        boolean boolean29 = categoryPlot0.getDrawSharedDomainAxis();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 255 + "'", int19 == 255);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str20.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNull(axisSpace28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(true);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 100, 0.4d);
        org.jfree.data.time.DateRange dateRange11 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((double) '#', (org.jfree.data.Range) dateRange11);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint9.toRangeHeight((org.jfree.data.Range) dateRange11);
        org.jfree.chart.util.Size2D size2D14 = legendTitle5.arrange(graphics2D6, rectangleConstraint9);
        java.lang.String str15 = size2D14.toString();
        size2D14.setHeight((double) (byte) -1);
        org.junit.Assert.assertNotNull(dateRange11);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(size2D14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str15.equals("Size2D[width=0.0, height=0.0]"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        java.awt.Stroke stroke22 = xYPlot21.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("");
        java.util.Date date26 = dateAxis25.getMaximumDate();
        xYPlot21.setRangeAxis((int) (short) 100, (org.jfree.chart.axis.ValueAxis) dateAxis25);
        dateAxis25.setInverted(false);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(date26);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.setDomainGridlinesVisible(true);
        double double24 = xYPlot21.getDomainCrosshairValue();
        xYPlot21.configureDomainAxes();
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis((int) '4', valueAxis3, false);
        categoryPlot0.configureRangeAxes();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.plot.PlotOrientation plotOrientation11 = null;
        try {
            categoryPlot0.setOrientation(plotOrientation11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        java.awt.Paint paint1 = null;
        java.awt.Stroke stroke2 = null;
        try {
            org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker(0.05d, paint1, stroke2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = categoryPlot0.getRenderer();
        java.lang.String str4 = categoryPlot0.getPlotType();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) dateAxis8, polarItemRenderer9);
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot10);
        java.awt.geom.Rectangle2D rectangle2D12 = legendTitle11.getBounds();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        boolean boolean15 = categoryPlot0.render(graphics2D5, rectangle2D12, (int) (byte) 1, plotRenderingInfo14);
        categoryPlot0.setNoDataMessage("hi!");
        categoryPlot0.setAnchorValue((double) 1);
        categoryPlot0.setWeight(10);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource24 = null;
        dateAxis23.setStandardTickUnits(tickUnitSource24);
        java.awt.Stroke stroke26 = dateAxis23.getTickMarkStroke();
        double double27 = dateAxis23.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("Size2D[width=0.0, height=0.0]");
        numberAxis29.setAutoRangeStickyZero(true);
        boolean boolean32 = numberAxis29.getAutoRangeStickyZero();
        boolean boolean33 = numberAxis29.isVisible();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray34 = new org.jfree.chart.axis.ValueAxis[] { dateAxis23, numberAxis29 };
        categoryPlot0.setRangeAxes(valueAxisArray34);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNull(categoryItemRenderer3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Category Plot" + "'", str4.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.05d + "'", double27 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(valueAxisArray34);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = piePlot0.getSimpleLabelOffset();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor2 = null;
        try {
            piePlot0.setLabelDistributor(abstractPieLabelDistributor2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'distributor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) dateAxis5, polarItemRenderer6);
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = piePlot8.getSimpleLabelOffset();
        double double10 = rectangleInsets9.getRight();
        dateAxis5.setLabelInsets(rectangleInsets9);
        dateAxis5.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("");
        dateAxis16.setRange((double) 0.0f, (double) 10.0f);
        dateAxis16.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) dateAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis16, xYItemRenderer22);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        xYPlot23.zoomRangeAxes((double) ' ', plotRenderingInfo25, point2D26);
        java.awt.Paint paint28 = xYPlot23.getDomainTickBandPaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent29 = null;
        xYPlot23.rendererChanged(rendererChangeEvent29);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray31 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot23.setRenderers(xYItemRendererArray31);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder33 = xYPlot23.getDatasetRenderingOrder();
        categoryPlot0.setDatasetRenderingOrder(datasetRenderingOrder33);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation35 = null;
        try {
            boolean boolean36 = categoryPlot0.removeAnnotation(categoryAnnotation35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.18d + "'", double10 == 0.18d);
        org.junit.Assert.assertNull(paint28);
        org.junit.Assert.assertNotNull(xYItemRendererArray31);
        org.junit.Assert.assertNotNull(datasetRenderingOrder33);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        dateAxis2.setLabelAngle((double) (byte) 1);
        dateAxis2.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int10 = color9.getAlpha();
        java.lang.String str11 = color9.toString();
        dateAxis2.setTickMarkPaint((java.awt.Paint) color9);
        java.awt.Stroke stroke13 = null;
        try {
            dateAxis2.setTickMarkStroke(stroke13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 255 + "'", int10 == 255);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str11.equals("java.awt.Color[r=255,g=255,b=64]"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.lang.Object obj1 = standardPieSectionLabelGenerator0.clone();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) dateAxis4, polarItemRenderer5);
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot6);
        polarPlot6.setBackgroundAlpha((float) (byte) 100);
        boolean boolean10 = standardPieSectionLabelGenerator0.equals((java.lang.Object) (byte) 100);
        java.lang.Object obj11 = standardPieSectionLabelGenerator0.clone();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot0.zoomRangeAxes((-1.0d), plotRenderingInfo6, point2D7, false);
        boolean boolean10 = categoryPlot0.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        java.lang.Comparable comparable4 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 255, (-16056329), comparable4, "java.awt.Color[r=255,g=255,b=64]", "ClassContext");
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator8 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator9 = null;
        try {
            java.lang.String str10 = pieSectionEntity7.getImageMapAreaTag(toolTipTagFragmentGenerator8, uRLTagFragmentGenerator9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        int int6 = polarPlot5.getBackgroundImageAlignment();
        boolean boolean7 = polarPlot5.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) polarPlot5);
        int int9 = jFreeChart8.getSubtitleCount();
        try {
            org.jfree.chart.plot.XYPlot xYPlot10 = jFreeChart8.getXYPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PolarPlot cannot be cast to org.jfree.chart.plot.XYPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        java.lang.String str2 = textTitle1.getToolTipText();
        java.awt.Paint paint3 = textTitle1.getBackgroundPaint();
        double double4 = textTitle1.getContentXOffset();
        boolean boolean5 = textTitle1.getNotify();
        textTitle1.setWidth((double) 0.5f);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis((int) '4', valueAxis3, false);
        categoryPlot0.configureRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer12 = null;
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) dateAxis11, polarItemRenderer12);
        dateAxis11.setLabelAngle((double) (byte) 1);
        dateAxis11.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int19 = color18.getAlpha();
        java.lang.String str20 = color18.toString();
        dateAxis11.setTickMarkPaint((java.awt.Paint) color18);
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = piePlot22.getSimpleLabelOffset();
        java.awt.Stroke stroke24 = piePlot22.getLabelOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, (java.awt.Paint) color18, stroke24);
        org.jfree.chart.util.Layer layer26 = null;
        categoryPlot0.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker25, layer26);
        java.awt.Paint paint28 = valueMarker25.getLabelPaint();
        valueMarker25.setLabel("java.awt.Color[r=255,g=255,b=64]");
        float float31 = valueMarker25.getAlpha();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 255 + "'", int19 == 255);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str20.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + 1.0f + "'", float31 == 1.0f);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("ClassContext");
        numberAxis3D1.setLabel("RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]");
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("hi!");
        java.lang.String str8 = textTitle7.getToolTipText();
        java.awt.geom.Rectangle2D rectangle2D9 = textTitle7.getBounds();
        java.awt.geom.Rectangle2D rectangle2D10 = textTitle7.getBounds();
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer14 = null;
        org.jfree.chart.plot.PolarPlot polarPlot15 = new org.jfree.chart.plot.PolarPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) dateAxis13, polarItemRenderer14);
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot15);
        org.jfree.chart.block.BlockContainer blockContainer17 = legendTitle16.getItemContainer();
        org.jfree.chart.plot.PiePlot piePlot18 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = piePlot18.getSimpleLabelOffset();
        boolean boolean20 = piePlot18.getSectionOutlinesVisible();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator21 = null;
        piePlot18.setLegendLabelURLGenerator(pieURLGenerator21);
        boolean boolean23 = piePlot18.getSimpleLabels();
        org.jfree.chart.plot.RingPlot ringPlot24 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint25 = ringPlot24.getShadowPaint();
        ringPlot24.setInteriorGap((double) (byte) 0);
        java.awt.Font font28 = ringPlot24.getNoDataMessageFont();
        piePlot18.setLabelFont(font28);
        legendTitle16.setItemFont(font28);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = legendTitle16.getPosition();
        org.jfree.chart.axis.AxisSpace axisSpace32 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace33 = numberAxis3D1.reserveSpace(graphics2D4, (org.jfree.chart.plot.Plot) ringPlot5, rectangle2D10, rectangleEdge31, axisSpace32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertNotNull(blockContainer17);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(rectangleEdge31);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis((int) '4', valueAxis3, false);
        categoryPlot0.configureRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer12 = null;
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) dateAxis11, polarItemRenderer12);
        dateAxis11.setLabelAngle((double) (byte) 1);
        dateAxis11.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int19 = color18.getAlpha();
        java.lang.String str20 = color18.toString();
        dateAxis11.setTickMarkPaint((java.awt.Paint) color18);
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = piePlot22.getSimpleLabelOffset();
        java.awt.Stroke stroke24 = piePlot22.getLabelOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, (java.awt.Paint) color18, stroke24);
        org.jfree.chart.util.Layer layer26 = null;
        categoryPlot0.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker25, layer26);
        categoryPlot0.setRangeCrosshairValue(0.4d, true);
        java.awt.Paint paint31 = null;
        try {
            categoryPlot0.setDomainGridlinePaint(paint31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 255 + "'", int19 == 255);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str20.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke24);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockBorder0.getInsets();
        double double3 = rectangleInsets1.calculateRightInset((double) (byte) 1);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("");
        float float2 = textFragment1.getBaselineOffset();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setInnerSeparatorExtension((double) (byte) 0);
        java.awt.Stroke stroke3 = ringPlot0.getLabelLinkStroke();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        org.jfree.chart.plot.PiePlotState piePlotState6 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo5);
        piePlotState6.setTotal((double) (short) 0);
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer12 = null;
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) dateAxis11, polarItemRenderer12);
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot13);
        java.awt.geom.Rectangle2D rectangle2D15 = legendTitle14.getBounds();
        piePlotState6.setLinkArea(rectangle2D15);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer20 = null;
        org.jfree.chart.plot.PolarPlot polarPlot21 = new org.jfree.chart.plot.PolarPlot(xYDataset17, (org.jfree.chart.axis.ValueAxis) dateAxis19, polarItemRenderer20);
        int int22 = polarPlot21.getBackgroundImageAlignment();
        boolean boolean23 = polarPlot21.isSubplot();
        java.awt.Color color24 = java.awt.Color.blue;
        polarPlot21.setAngleLabelPaint((java.awt.Paint) color24);
        java.awt.Font font26 = polarPlot21.getAngleLabelFont();
        org.jfree.chart.title.LegendTitle legendTitle27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot21);
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer33 = null;
        org.jfree.chart.plot.PolarPlot polarPlot34 = new org.jfree.chart.plot.PolarPlot(xYDataset30, (org.jfree.chart.axis.ValueAxis) dateAxis32, polarItemRenderer33);
        dateAxis32.setLabelAngle((double) (byte) 1);
        dateAxis32.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color39 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int40 = color39.getAlpha();
        java.lang.String str41 = color39.toString();
        dateAxis32.setTickMarkPaint((java.awt.Paint) color39);
        org.jfree.data.Range range43 = dateAxis32.getDefaultAutoRange();
        boolean boolean44 = dateAxis32.isTickMarksVisible();
        org.jfree.chart.plot.PiePlot piePlot46 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = piePlot46.getSimpleLabelOffset();
        org.jfree.data.xy.XYDataset xYDataset48 = null;
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer51 = null;
        org.jfree.chart.plot.PolarPlot polarPlot52 = new org.jfree.chart.plot.PolarPlot(xYDataset48, (org.jfree.chart.axis.ValueAxis) dateAxis50, polarItemRenderer51);
        org.jfree.chart.title.LegendTitle legendTitle53 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot52);
        java.awt.geom.Rectangle2D rectangle2D54 = legendTitle53.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType55 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType56 = null;
        java.awt.geom.Rectangle2D rectangle2D57 = rectangleInsets47.createAdjustedRectangle(rectangle2D54, lengthAdjustmentType55, lengthAdjustmentType56);
        org.jfree.chart.util.RectangleEdge rectangleEdge58 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean59 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge58);
        double double60 = dateAxis32.java2DToValue((double) 8, rectangle2D57, rectangleEdge58);
        java.awt.Point point61 = polarPlot21.translateValueThetaRadiusToJava2D((double) (-1L), (double) 2, rectangle2D57);
        org.jfree.chart.plot.PlotState plotState62 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo63 = null;
        try {
            ringPlot0.draw(graphics2D4, rectangle2D15, (java.awt.geom.Point2D) point61, plotState62, plotRenderingInfo63);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 15 + "'", int22 == 15);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 255 + "'", int40 == 255);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str41.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertNotNull(rectangle2D54);
        org.junit.Assert.assertNotNull(rectangle2D57);
        org.junit.Assert.assertNotNull(rectangleEdge58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 9.223372036854776E18d + "'", double60 == 9.223372036854776E18d);
        org.junit.Assert.assertNotNull(point61);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = piePlot5.getSimpleLabelOffset();
        double double7 = rectangleInsets6.getRight();
        dateAxis2.setLabelInsets(rectangleInsets6);
        java.awt.Shape shape9 = dateAxis2.getLeftArrow();
        dateAxis2.setAxisLineVisible(false);
        dateAxis2.setLabel("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit14 = dateAxis2.getTickUnit();
        org.jfree.chart.event.AxisChangeListener axisChangeListener15 = null;
        dateAxis2.removeChangeListener(axisChangeListener15);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.18d + "'", double7 == 0.18d);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(dateTickUnit14);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        int int5 = polarPlot4.getBackgroundImageAlignment();
        boolean boolean6 = polarPlot4.isSubplot();
        java.awt.Color color7 = java.awt.Color.blue;
        polarPlot4.setAngleLabelPaint((java.awt.Paint) color7);
        java.awt.Font font9 = polarPlot4.getAngleLabelFont();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot4);
        java.lang.Object obj11 = polarPlot4.clone();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.clearDomainMarkers(15);
        org.jfree.chart.LegendItemCollection legendItemCollection24 = xYPlot21.getFixedLegendItems();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = xYPlot21.getAxisOffset();
        boolean boolean26 = xYPlot21.isRangeZoomable();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation27 = null;
        try {
            boolean boolean28 = xYPlot21.removeAnnotation(xYAnnotation27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertNull(legendItemCollection24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        try {
            java.awt.geom.Point2D point2D2 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        float[] floatArray5 = new float[] { (-1.0f), 10, (short) 0, '#' };
        float[] floatArray6 = color0.getRGBComponents(floatArray5);
        org.jfree.chart.block.BlockBorder blockBorder7 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = blockBorder7.getInsets();
        double double9 = rectangleInsets8.getTop();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot4);
        java.lang.Object obj6 = legendTitle5.clone();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) dateAxis9, polarItemRenderer10);
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = piePlot12.getSimpleLabelOffset();
        double double14 = rectangleInsets13.getRight();
        dateAxis9.setLabelInsets(rectangleInsets13);
        legendTitle5.setLegendItemGraphicPadding(rectangleInsets13);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = legendTitle5.getLegendItemGraphicPadding();
        double double19 = rectangleInsets17.extendWidth((double) 15);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.18d + "'", double14 == 0.18d);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 23.4375d + "'", double19 == 23.4375d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        java.lang.Comparable comparable4 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 255, (-16056329), comparable4, "java.awt.Color[r=255,g=255,b=64]", "ClassContext");
        org.jfree.data.general.PieDataset pieDataset8 = pieSectionEntity7.getDataset();
        try {
            java.lang.String str9 = pieSectionEntity7.toString();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNull(pieDataset8);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) 32.0d, (double) 255);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.clearDomainMarkers(15);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        float float26 = categoryPlot25.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot25.getRangeAxisLocation();
        xYPlot21.setDomainAxisLocation((int) (byte) 0, axisLocation27, true);
        java.awt.Stroke stroke30 = xYPlot21.getRangeGridlineStroke();
        xYPlot21.clearRangeMarkers(0);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 1.0f + "'", float26 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(stroke30);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.clearDomainMarkers(15);
        org.jfree.chart.plot.PlotOrientation plotOrientation24 = xYPlot21.getOrientation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        java.awt.geom.Point2D point2D28 = null;
        try {
            xYPlot21.zoomRangeAxes((double) (byte) 1, (double) 0.5f, plotRenderingInfo27, point2D28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (165.0) <= upper (5.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertNotNull(plotOrientation24);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        int int6 = polarPlot5.getBackgroundImageAlignment();
        boolean boolean7 = polarPlot5.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) polarPlot5);
        int int9 = jFreeChart8.getSubtitleCount();
        java.util.List list10 = jFreeChart8.getSubtitles();
        int int11 = jFreeChart8.getSubtitleCount();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        float float23 = categoryPlot22.getForegroundAlpha();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = categoryPlot22.getRenderer(255);
        java.awt.Stroke stroke26 = categoryPlot22.getDomainGridlineStroke();
        xYPlot21.setRangeZeroBaselineStroke(stroke26);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 1.0f + "'", float23 == 1.0f);
        org.junit.Assert.assertNull(categoryItemRenderer25);
        org.junit.Assert.assertNotNull(stroke26);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = piePlot0.getSimpleLabelOffset();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        piePlot0.markerChanged(markerChangeEvent2);
        java.lang.Object obj4 = piePlot0.clone();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator5 = null;
        piePlot0.setToolTipGenerator(pieToolTipGenerator5);
        java.awt.Stroke stroke7 = piePlot0.getLabelLinkStroke();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator8 = piePlot0.getLegendLabelGenerator();
        double double9 = piePlot0.getLabelGap();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.025d + "'", double9 == 0.025d);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("", "java.awt.Color[r=255,g=255,b=64]", "", "java.awt.Color[r=255,g=255,b=64]", "java.awt.Color[r=255,g=255,b=64]");
        java.lang.String str6 = basicProjectInfo5.getVersion();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str6.equals("java.awt.Color[r=255,g=255,b=64]"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        java.awt.Color color1 = java.awt.Color.GRAY;
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) dateAxis5, polarItemRenderer6);
        dateAxis5.setLabelAngle((double) (byte) 1);
        dateAxis5.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int13 = color12.getAlpha();
        java.lang.String str14 = color12.toString();
        dateAxis5.setTickMarkPaint((java.awt.Paint) color12);
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = piePlot16.getSimpleLabelOffset();
        java.awt.Stroke stroke18 = piePlot16.getLabelOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, (java.awt.Paint) color12, stroke18);
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker((-1.0d), (java.awt.Paint) color1, stroke18);
        valueMarker20.setValue((double) 0L);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 255 + "'", int13 == 255);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str14.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.data.time.DateRange dateRange1 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) '#', (org.jfree.data.Range) dateRange1);
        org.jfree.data.Range range5 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange1, (double) 1.0f, false);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 100, 0.4d);
        org.jfree.data.time.DateRange dateRange10 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = new org.jfree.chart.block.RectangleConstraint((double) '#', (org.jfree.data.Range) dateRange10);
        org.jfree.data.Range range14 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange10, (double) 1.0f, false);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint8.toRangeHeight(range14);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange1, range14);
        org.jfree.data.Range range17 = rectangleConstraint16.getWidthRange();
        java.lang.String str18 = rectangleConstraint16.toString();
        org.junit.Assert.assertNotNull(dateRange1);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(dateRange10);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]" + "'", str18.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.junit.Assert.assertNotNull(plotOrientation0);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("org.jfree.chart.event.ChartProgressEvent[source=[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]]", "java.awt.Color[r=255,g=255,b=64]");
        java.lang.String str3 = contributor2.getName();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.chart.event.ChartProgressEvent[source=[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]]" + "'", str3.equals("org.jfree.chart.event.ChartProgressEvent[source=[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]]"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = categoryPlot0.getRenderer();
        java.lang.String str4 = categoryPlot0.getPlotType();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) dateAxis8, polarItemRenderer9);
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot10);
        java.awt.geom.Rectangle2D rectangle2D12 = legendTitle11.getBounds();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        boolean boolean15 = categoryPlot0.render(graphics2D5, rectangle2D12, (int) (byte) 1, plotRenderingInfo14);
        categoryPlot0.setNoDataMessage("hi!");
        categoryPlot0.setAnchorValue((double) 1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        categoryPlot0.zoomRangeAxes((double) (-1L), (double) (byte) 100, plotRenderingInfo22, point2D23);
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.data.Range range26 = categoryPlot0.getDataRange(valueAxis25);
        categoryPlot0.setWeight((int) (short) 10);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNull(categoryItemRenderer3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Category Plot" + "'", str4.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(range26);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Size2D[width=0.0, height=0.0]");
        numberAxis1.setAutoRangeStickyZero(true);
        boolean boolean4 = numberAxis1.getAutoRangeStickyZero();
        numberAxis1.configure();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = null;
        org.jfree.chart.text.TextBlock textBlock3 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint2);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = textBlock3.getLineAlignment();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.Font font9 = null;
        java.awt.Paint paint10 = null;
        org.jfree.chart.text.TextBlock textBlock11 = org.jfree.chart.text.TextUtilities.createTextBlock("", font9, paint10);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor15 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        java.awt.Shape shape19 = textBlock11.calculateBounds(graphics2D12, 0.0f, (float) (short) 0, textBlockAnchor15, (float) (byte) 10, (float) 15, (double) 0L);
        textBlock3.draw(graphics2D5, 0.0f, (float) (byte) 10, textBlockAnchor15);
        org.jfree.chart.text.TextLine textLine21 = textBlock3.getLastLine();
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer26 = null;
        org.jfree.chart.plot.PolarPlot polarPlot27 = new org.jfree.chart.plot.PolarPlot(xYDataset23, (org.jfree.chart.axis.ValueAxis) dateAxis25, polarItemRenderer26);
        dateAxis25.setLabelAngle((double) (byte) 1);
        java.awt.Font font30 = dateAxis25.getTickLabelFont();
        org.jfree.chart.text.TextLine textLine31 = new org.jfree.chart.text.TextLine("", font30);
        textBlock3.addLine(textLine31);
        org.jfree.data.xy.XYDataset xYDataset33 = null;
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer36 = null;
        org.jfree.chart.plot.PolarPlot polarPlot37 = new org.jfree.chart.plot.PolarPlot(xYDataset33, (org.jfree.chart.axis.ValueAxis) dateAxis35, polarItemRenderer36);
        org.jfree.chart.title.LegendTitle legendTitle38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot37);
        org.jfree.chart.block.BlockContainer blockContainer39 = legendTitle38.getItemContainer();
        org.jfree.chart.plot.PiePlot piePlot40 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = piePlot40.getSimpleLabelOffset();
        boolean boolean42 = piePlot40.getSectionOutlinesVisible();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator43 = null;
        piePlot40.setLegendLabelURLGenerator(pieURLGenerator43);
        boolean boolean45 = piePlot40.getSimpleLabels();
        org.jfree.chart.plot.RingPlot ringPlot46 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint47 = ringPlot46.getShadowPaint();
        ringPlot46.setInteriorGap((double) (byte) 0);
        java.awt.Font font50 = ringPlot46.getNoDataMessageFont();
        piePlot40.setLabelFont(font50);
        legendTitle38.setItemFont(font50);
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = legendTitle38.getPosition();
        boolean boolean54 = textBlock3.equals((java.lang.Object) legendTitle38);
        org.junit.Assert.assertNotNull(textBlock3);
        org.junit.Assert.assertNotNull(horizontalAlignment4);
        org.junit.Assert.assertNotNull(textBlock11);
        org.junit.Assert.assertNotNull(textBlockAnchor15);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNull(textLine21);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNotNull(blockContainer39);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(font50);
        org.junit.Assert.assertNotNull(rectangleEdge53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setInnerSeparatorExtension((double) '#');
        org.jfree.chart.util.Rotation rotation3 = ringPlot0.getDirection();
        double double4 = ringPlot0.getShadowXOffset();
        double double5 = ringPlot0.getInnerSeparatorExtension();
        org.jfree.chart.plot.Plot plot6 = ringPlot0.getRootPlot();
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 35.0d + "'", double5 == 35.0d);
        org.junit.Assert.assertNotNull(plot6);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge0);
        java.lang.String str2 = rectangleEdge0.toString();
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RectangleEdge.LEFT" + "'", str2.equals("RectangleEdge.LEFT"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.clearDomainMarkers(15);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        float float26 = categoryPlot25.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot25.getRangeAxisLocation();
        xYPlot21.setDomainAxisLocation((int) (byte) 0, axisLocation27, true);
        xYPlot21.setDomainCrosshairValue((double) 'a');
        boolean boolean32 = xYPlot21.isDomainZoomable();
        int int33 = xYPlot21.getRangeAxisCount();
        xYPlot21.setDomainCrosshairValue((double) 1L);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 1.0f + "'", float26 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        dateAxis2.setLabelAngle((double) (byte) 1);
        dateAxis2.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int10 = color9.getAlpha();
        java.lang.String str11 = color9.toString();
        dateAxis2.setTickMarkPaint((java.awt.Paint) color9);
        java.lang.String str13 = dateAxis2.getLabelToolTip();
        try {
            dateAxis2.setRangeAboutValue(0.025d, (double) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (0.525) <= upper (-0.475).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 255 + "'", int10 == 255);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str11.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNull(str13);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.clearDomainMarkers(15);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        float float26 = categoryPlot25.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot25.getRangeAxisLocation();
        xYPlot21.setDomainAxisLocation((int) (byte) 0, axisLocation27, true);
        xYPlot21.setDomainCrosshairValue((double) 'a');
        boolean boolean32 = xYPlot21.isRangeZeroBaselineVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        xYPlot21.setRenderer((int) '#', xYItemRenderer34, true);
        java.awt.Paint paint37 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        xYPlot21.setRangeZeroBaselinePaint(paint37);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 1.0f + "'", float26 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(paint37);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        boolean boolean2 = categoryPlot0.isDomainGridlinesVisible();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        boolean boolean7 = categoryPlot0.render(graphics2D3, rectangle2D4, (int) (byte) 10, plotRenderingInfo6);
        categoryPlot0.setOutlineVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot0.getRangeAxis(0);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.axis.AxisSpace axisSpace13 = categoryPlot0.getFixedRangeAxisSpace();
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer17 = null;
        org.jfree.chart.plot.PolarPlot polarPlot18 = new org.jfree.chart.plot.PolarPlot(xYDataset14, (org.jfree.chart.axis.ValueAxis) dateAxis16, polarItemRenderer17);
        dateAxis16.setLabelAngle((double) (byte) 1);
        dateAxis16.setTickMarkOutsideLength((-1.0f));
        dateAxis16.setFixedDimension(0.4d);
        double double25 = dateAxis16.getUpperBound();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("");
        java.util.Date date28 = dateAxis27.getMaximumDate();
        dateAxis16.setMaximumDate(date28);
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis16);
        java.util.TimeZone timeZone31 = null;
        try {
            dateAxis16.setTimeZone(timeZone31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNull(axisSpace13);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertNotNull(date28);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        java.awt.color.ColorSpace colorSpace1 = color0.getColorSpace();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(colorSpace1);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        dateAxis3.setLabelAngle((double) (byte) 1);
        dateAxis3.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int11 = color10.getAlpha();
        java.lang.String str12 = color10.toString();
        dateAxis3.setTickMarkPaint((java.awt.Paint) color10);
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = piePlot14.getSimpleLabelOffset();
        java.awt.Stroke stroke16 = piePlot14.getLabelOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, (java.awt.Paint) color10, stroke16);
        java.awt.Paint paint18 = valueMarker17.getOutlinePaint();
        java.lang.String str19 = valueMarker17.getLabel();
        java.awt.Color color20 = java.awt.Color.PINK;
        valueMarker17.setLabelPaint((java.awt.Paint) color20);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 255 + "'", int11 == 255);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str12.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNotNull(color20);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot4);
        org.jfree.chart.block.BlockContainer blockContainer6 = legendTitle5.getItemContainer();
        org.jfree.chart.block.Arrangement arrangement7 = blockContainer6.getArrangement();
        org.jfree.chart.block.BlockContainer blockContainer8 = new org.jfree.chart.block.BlockContainer(arrangement7);
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("hi!");
        java.lang.String str11 = textTitle10.getToolTipText();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = textTitle10.getHorizontalAlignment();
        blockContainer8.add((org.jfree.chart.block.Block) textTitle10);
        blockContainer8.clear();
        blockContainer8.setMargin(0.0d, (-1.0d), (double) 1L, (double) 100.0f);
        org.junit.Assert.assertNotNull(blockContainer6);
        org.junit.Assert.assertNotNull(arrangement7);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(horizontalAlignment12);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        boolean boolean2 = categoryPlot0.isDomainGridlinesVisible();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        boolean boolean7 = categoryPlot0.render(graphics2D3, rectangle2D4, (int) (byte) 10, plotRenderingInfo6);
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot0.getDataset((int) ' ');
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot0.getRowRenderingOrder();
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        try {
            categoryPlot0.addDomainMarker(categoryMarker11, layer12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertNotNull(sortOrder10);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = null;
        dateAxis1.setStandardTickUnits(tickUnitSource2);
        dateAxis1.setFixedAutoRange((double) 100L);
        java.awt.Font font6 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        dateAxis1.setLabelFont(font6);
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date9 = dateAxis1.calculateHighestVisibleTickValue(dateTickUnit8);
        java.lang.Object obj10 = dateAxis1.clone();
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = categoryPlot0.getRenderer(255);
        java.awt.Stroke stroke4 = categoryPlot0.getDomainGridlineStroke();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor5 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent6);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNull(categoryItemRenderer3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(categoryAnchor5);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        dateAxis3.setLabelAngle((double) (byte) 1);
        dateAxis3.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int11 = color10.getAlpha();
        dateAxis3.setTickLabelPaint((java.awt.Paint) color10);
        double double13 = dateAxis3.getFixedAutoRange();
        org.jfree.data.Range range14 = dateAxis3.getDefaultAutoRange();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, valueAxis15, xYItemRenderer16);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        float float19 = categoryPlot18.getForegroundAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        categoryPlot18.setRangeAxis((int) '4', valueAxis21, false);
        categoryPlot18.configureRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer30 = null;
        org.jfree.chart.plot.PolarPlot polarPlot31 = new org.jfree.chart.plot.PolarPlot(xYDataset27, (org.jfree.chart.axis.ValueAxis) dateAxis29, polarItemRenderer30);
        dateAxis29.setLabelAngle((double) (byte) 1);
        dateAxis29.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color36 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int37 = color36.getAlpha();
        java.lang.String str38 = color36.toString();
        dateAxis29.setTickMarkPaint((java.awt.Paint) color36);
        org.jfree.chart.plot.PiePlot piePlot40 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = piePlot40.getSimpleLabelOffset();
        java.awt.Stroke stroke42 = piePlot40.getLabelOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, (java.awt.Paint) color36, stroke42);
        org.jfree.chart.util.Layer layer44 = null;
        categoryPlot18.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker43, layer44);
        java.awt.Paint paint46 = valueMarker43.getLabelPaint();
        valueMarker43.setLabel("java.awt.Color[r=255,g=255,b=64]");
        org.jfree.chart.util.Layer layer49 = null;
        try {
            xYPlot17.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker43, layer49);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 255 + "'", int11 == 255);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 1.0f + "'", float19 == 1.0f);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 255 + "'", int37 == 255);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str38.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(paint46);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = piePlot0.getSimpleLabelOffset();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        piePlot0.markerChanged(markerChangeEvent2);
        java.lang.Object obj4 = piePlot0.clone();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator5 = null;
        piePlot0.setToolTipGenerator(pieToolTipGenerator5);
        java.awt.Stroke stroke7 = piePlot0.getLabelLinkStroke();
        double double8 = piePlot0.getShadowXOffset();
        org.jfree.data.general.PieDataset pieDataset9 = null;
        piePlot0.setDataset(pieDataset9);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) dateAxis5, polarItemRenderer6);
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = piePlot8.getSimpleLabelOffset();
        double double10 = rectangleInsets9.getRight();
        dateAxis5.setLabelInsets(rectangleInsets9);
        dateAxis5.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("");
        dateAxis16.setRange((double) 0.0f, (double) 10.0f);
        dateAxis16.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) dateAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis16, xYItemRenderer22);
        xYPlot23.clearDomainMarkers(15);
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        float float28 = categoryPlot27.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation29 = categoryPlot27.getRangeAxisLocation();
        xYPlot23.setDomainAxisLocation((int) (byte) 0, axisLocation29, true);
        xYPlot23.setDomainCrosshairValue((double) 'a');
        org.jfree.chart.axis.AxisLocation axisLocation34 = xYPlot23.getRangeAxisLocation();
        categoryPlot0.setRangeAxisLocation(axisLocation34, true);
        org.jfree.chart.LegendItemCollection legendItemCollection37 = categoryPlot0.getFixedLegendItems();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.18d + "'", double10 == 0.18d);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 1.0f + "'", float28 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertNull(legendItemCollection37);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis((int) '4', valueAxis3, false);
        categoryPlot0.configureRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer12 = null;
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) dateAxis11, polarItemRenderer12);
        dateAxis11.setLabelAngle((double) (byte) 1);
        dateAxis11.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int19 = color18.getAlpha();
        java.lang.String str20 = color18.toString();
        dateAxis11.setTickMarkPaint((java.awt.Paint) color18);
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = piePlot22.getSimpleLabelOffset();
        java.awt.Stroke stroke24 = piePlot22.getLabelOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, (java.awt.Paint) color18, stroke24);
        org.jfree.chart.util.Layer layer26 = null;
        categoryPlot0.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker25, layer26);
        java.awt.Paint paint28 = valueMarker25.getLabelPaint();
        org.jfree.chart.text.TextAnchor textAnchor29 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        valueMarker25.setLabelTextAnchor(textAnchor29);
        float float31 = valueMarker25.getAlpha();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 255 + "'", int19 == 255);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str20.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(textAnchor29);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + 1.0f + "'", float31 == 1.0f);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        java.awt.Paint paint0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Size2D[width=0.0, height=0.0]");
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setInverted(true);
        numberAxis1.setLabelAngle(0.0d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "Polar Plot");
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        dateAxis2.setLabelAngle((double) (byte) 1);
        dateAxis2.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int10 = color9.getAlpha();
        dateAxis2.setTickLabelPaint((java.awt.Paint) color9);
        double double12 = dateAxis2.getFixedAutoRange();
        dateAxis2.setAxisLineVisible(true);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 255 + "'", int10 == 255);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot4);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        float float7 = categoryPlot6.getForegroundAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot6.setRangeAxis((int) '4', valueAxis9, false);
        categoryPlot6.configureRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer18 = null;
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) dateAxis17, polarItemRenderer18);
        dateAxis17.setLabelAngle((double) (byte) 1);
        dateAxis17.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color24 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int25 = color24.getAlpha();
        java.lang.String str26 = color24.toString();
        dateAxis17.setTickMarkPaint((java.awt.Paint) color24);
        org.jfree.chart.plot.PiePlot piePlot28 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = piePlot28.getSimpleLabelOffset();
        java.awt.Stroke stroke30 = piePlot28.getLabelOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker31 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, (java.awt.Paint) color24, stroke30);
        org.jfree.chart.util.Layer layer32 = null;
        categoryPlot6.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker31, layer32);
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource36 = null;
        dateAxis35.setStandardTickUnits(tickUnitSource36);
        java.awt.Stroke stroke38 = dateAxis35.getTickMarkStroke();
        valueMarker31.setStroke(stroke38);
        polarPlot4.setRadiusGridlineStroke(stroke38);
        java.awt.Paint paint41 = polarPlot4.getBackgroundPaint();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor42 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        boolean boolean43 = polarPlot4.equals((java.lang.Object) textBlockAnchor42);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 255 + "'", int25 == 255);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str26.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(textBlockAnchor42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.clearDomainMarkers(15);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        float float26 = categoryPlot25.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot25.getRangeAxisLocation();
        xYPlot21.setDomainAxisLocation((int) (byte) 0, axisLocation27, true);
        boolean boolean30 = xYPlot21.isRangeZoomable();
        xYPlot21.mapDatasetToRangeAxis(10, 0);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 1.0f + "'", float26 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = piePlot0.getSimpleLabelOffset();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        piePlot0.markerChanged(markerChangeEvent2);
        java.lang.Object obj4 = piePlot0.clone();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator5 = null;
        piePlot0.setToolTipGenerator(pieToolTipGenerator5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        piePlot0.setBaseSectionPaint((java.awt.Paint) color7);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.clearDomainMarkers(15);
        org.jfree.chart.LegendItemCollection legendItemCollection24 = xYPlot21.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace25 = null;
        xYPlot21.setFixedRangeAxisSpace(axisSpace25);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertNull(legendItemCollection24);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        java.awt.Color color0 = java.awt.Color.green;
        java.awt.Color color1 = color0.darker();
        java.awt.Stroke stroke2 = null;
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) dateAxis5, polarItemRenderer6);
        int int8 = polarPlot7.getBackgroundImageAlignment();
        boolean boolean9 = polarPlot7.isSubplot();
        boolean boolean10 = polarPlot7.isDomainZoomable();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        polarPlot7.zoomRangeAxes((double) 0.0f, plotRenderingInfo12, point2D13);
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = piePlot15.getSimpleLabelOffset();
        double double18 = rectangleInsets16.extendHeight(0.0d);
        polarPlot7.setInsets(rectangleInsets16);
        try {
            org.jfree.chart.block.LineBorder lineBorder20 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke2, rectangleInsets16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 15 + "'", int8 == 15);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.time.DateRange dateRange1 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) '#', (org.jfree.data.Range) dateRange1);
        org.jfree.data.Range range5 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange1, (double) 1.0f, false);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 100, 0.4d);
        org.jfree.data.time.DateRange dateRange10 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = new org.jfree.chart.block.RectangleConstraint((double) '#', (org.jfree.data.Range) dateRange10);
        org.jfree.data.Range range14 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange10, (double) 1.0f, false);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint8.toRangeHeight(range14);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange1, range14);
        double double17 = rectangleConstraint16.getHeight();
        org.junit.Assert.assertNotNull(dateRange1);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(dateRange10);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        java.lang.String str2 = textTitle1.getToolTipText();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = textTitle1.getHorizontalAlignment();
        java.lang.Object obj4 = textTitle1.clone();
        java.lang.String str5 = textTitle1.getToolTipText();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis((int) '4', valueAxis3, false);
        categoryPlot0.configureRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer12 = null;
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) dateAxis11, polarItemRenderer12);
        dateAxis11.setLabelAngle((double) (byte) 1);
        dateAxis11.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int19 = color18.getAlpha();
        java.lang.String str20 = color18.toString();
        dateAxis11.setTickMarkPaint((java.awt.Paint) color18);
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = piePlot22.getSimpleLabelOffset();
        java.awt.Stroke stroke24 = piePlot22.getLabelOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, (java.awt.Paint) color18, stroke24);
        org.jfree.chart.util.Layer layer26 = null;
        categoryPlot0.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker25, layer26);
        java.awt.Paint paint28 = valueMarker25.getLabelPaint();
        org.jfree.chart.text.TextAnchor textAnchor29 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        valueMarker25.setLabelTextAnchor(textAnchor29);
        java.lang.String str31 = valueMarker25.getLabel();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 255 + "'", int19 == 255);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str20.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(textAnchor29);
        org.junit.Assert.assertNull(str31);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("org.jfree.chart.event.ChartProgressEvent[source=[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]]", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setInnerSeparatorExtension((double) '#');
        org.jfree.chart.util.Rotation rotation3 = ringPlot0.getDirection();
        java.awt.Font font5 = null;
        java.awt.Paint paint6 = null;
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("", font5, paint6);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment8 = textBlock7.getLineAlignment();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.Font font13 = null;
        java.awt.Paint paint14 = null;
        org.jfree.chart.text.TextBlock textBlock15 = org.jfree.chart.text.TextUtilities.createTextBlock("", font13, paint14);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor19 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        java.awt.Shape shape23 = textBlock15.calculateBounds(graphics2D16, 0.0f, (float) (short) 0, textBlockAnchor19, (float) (byte) 10, (float) 15, (double) 0L);
        textBlock7.draw(graphics2D9, 0.0f, (float) (byte) 10, textBlockAnchor19);
        org.jfree.chart.plot.PiePlot piePlot26 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = piePlot26.getSimpleLabelOffset();
        boolean boolean28 = piePlot26.getSectionOutlinesVisible();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator29 = null;
        piePlot26.setLegendLabelURLGenerator(pieURLGenerator29);
        boolean boolean31 = piePlot26.getSimpleLabels();
        org.jfree.chart.plot.RingPlot ringPlot32 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint33 = ringPlot32.getShadowPaint();
        ringPlot32.setInteriorGap((double) (byte) 0);
        java.awt.Font font36 = ringPlot32.getNoDataMessageFont();
        piePlot26.setLabelFont(font36);
        java.awt.Color color38 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        textBlock7.addLine("", font36, (java.awt.Paint) color38);
        boolean boolean40 = rotation3.equals((java.lang.Object) color38);
        double double41 = rotation3.getFactor();
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNotNull(horizontalAlignment8);
        org.junit.Assert.assertNotNull(textBlock15);
        org.junit.Assert.assertNotNull(textBlockAnchor19);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + (-1.0d) + "'", double41 == (-1.0d));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        java.awt.Paint paint5 = dateAxis2.getLabelPaint();
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
        java.lang.String str1 = licences0.getLGPL();
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.clearDomainMarkers(15);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer27 = null;
        org.jfree.chart.plot.PolarPlot polarPlot28 = new org.jfree.chart.plot.PolarPlot(xYDataset24, (org.jfree.chart.axis.ValueAxis) dateAxis26, polarItemRenderer27);
        dateAxis26.setLabelAngle((double) (byte) 1);
        dateAxis26.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color33 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int34 = color33.getAlpha();
        dateAxis26.setTickLabelPaint((java.awt.Paint) color33);
        dateAxis26.setInverted(false);
        double double38 = dateAxis26.getLowerBound();
        org.jfree.data.Range range39 = xYPlot21.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis26);
        java.awt.Paint paint40 = null;
        try {
            dateAxis26.setLabelPaint(paint40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 255 + "'", int34 == 255);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNull(range39);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Size2D[width=0.0, height=0.0]");
        numberAxis1.setAutoRangeStickyZero(true);
        boolean boolean4 = numberAxis1.getAutoRangeStickyZero();
        boolean boolean5 = numberAxis1.isVisible();
        java.text.NumberFormat numberFormat6 = numberAxis1.getNumberFormatOverride();
        java.awt.Shape shape7 = null;
        try {
            numberAxis1.setRightArrow(shape7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(numberFormat6);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = null;
        dateAxis1.setStandardTickUnits(tickUnitSource2);
        java.awt.Shape shape4 = dateAxis1.getRightArrow();
        java.awt.Stroke stroke5 = dateAxis1.getAxisLineStroke();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        xYPlot21.zoomRangeAxes((double) ' ', plotRenderingInfo23, point2D24);
        java.awt.Paint paint26 = xYPlot21.getDomainTickBandPaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent27 = null;
        xYPlot21.rendererChanged(rendererChangeEvent27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int30 = color29.getAlpha();
        java.lang.String str31 = color29.toString();
        xYPlot21.setNoDataMessagePaint((java.awt.Paint) color29);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertNull(paint26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 255 + "'", int30 == 255);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str31.equals("java.awt.Color[r=255,g=255,b=64]"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = null;
        org.jfree.chart.text.TextBlock textBlock3 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint2);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = textBlock3.getLineAlignment();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.Font font9 = null;
        java.awt.Paint paint10 = null;
        org.jfree.chart.text.TextBlock textBlock11 = org.jfree.chart.text.TextUtilities.createTextBlock("", font9, paint10);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor15 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        java.awt.Shape shape19 = textBlock11.calculateBounds(graphics2D12, 0.0f, (float) (short) 0, textBlockAnchor15, (float) (byte) 10, (float) 15, (double) 0L);
        textBlock3.draw(graphics2D5, 0.0f, (float) (byte) 10, textBlockAnchor15);
        org.jfree.chart.text.TextLine textLine21 = textBlock3.getLastLine();
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer26 = null;
        org.jfree.chart.plot.PolarPlot polarPlot27 = new org.jfree.chart.plot.PolarPlot(xYDataset23, (org.jfree.chart.axis.ValueAxis) dateAxis25, polarItemRenderer26);
        dateAxis25.setLabelAngle((double) (byte) 1);
        java.awt.Font font30 = dateAxis25.getTickLabelFont();
        org.jfree.chart.text.TextLine textLine31 = new org.jfree.chart.text.TextLine("", font30);
        textBlock3.addLine(textLine31);
        java.awt.Graphics2D graphics2D33 = null;
        try {
            org.jfree.chart.util.Size2D size2D34 = textLine31.calculateDimensions(graphics2D33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textBlock3);
        org.junit.Assert.assertNotNull(horizontalAlignment4);
        org.junit.Assert.assertNotNull(textBlock11);
        org.junit.Assert.assertNotNull(textBlockAnchor15);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNull(textLine21);
        org.junit.Assert.assertNotNull(font30);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        piePlotState1.setTotal((double) (short) 0);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) dateAxis6, polarItemRenderer7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot8);
        java.awt.geom.Rectangle2D rectangle2D10 = legendTitle9.getBounds();
        piePlotState1.setLinkArea(rectangle2D10);
        java.awt.geom.Rectangle2D rectangle2D12 = piePlotState1.getPieArea();
        org.jfree.chart.entity.EntityCollection entityCollection13 = piePlotState1.getEntityCollection();
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertNull(rectangle2D12);
        org.junit.Assert.assertNull(entityCollection13);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        java.awt.Font font1 = null;
        try {
            org.jfree.chart.text.TextFragment textFragment2 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=0.18,l=0.18,b=0.18,r=0.18]", font1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.Object obj1 = categoryPlot0.clone();
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        float float5 = categoryPlot4.getForegroundAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        categoryPlot4.setRangeAxis((int) '4', valueAxis7, false);
        categoryPlot4.configureRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer16 = null;
        org.jfree.chart.plot.PolarPlot polarPlot17 = new org.jfree.chart.plot.PolarPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis15, polarItemRenderer16);
        dateAxis15.setLabelAngle((double) (byte) 1);
        dateAxis15.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int23 = color22.getAlpha();
        java.lang.String str24 = color22.toString();
        dateAxis15.setTickMarkPaint((java.awt.Paint) color22);
        org.jfree.chart.plot.PiePlot piePlot26 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = piePlot26.getSimpleLabelOffset();
        java.awt.Stroke stroke28 = piePlot26.getLabelOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker29 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, (java.awt.Paint) color22, stroke28);
        org.jfree.chart.util.Layer layer30 = null;
        categoryPlot4.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker29, layer30);
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource34 = null;
        dateAxis33.setStandardTickUnits(tickUnitSource34);
        java.awt.Stroke stroke36 = dateAxis33.getTickMarkStroke();
        valueMarker29.setStroke(stroke36);
        valueMarker29.setLabel("");
        org.jfree.chart.util.Layer layer40 = null;
        try {
            boolean boolean41 = categoryPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker29, layer40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 1.0f + "'", float5 == 1.0f);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 255 + "'", int23 == 255);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str24.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(stroke36);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = piePlot5.getSimpleLabelOffset();
        double double7 = rectangleInsets6.getRight();
        dateAxis2.setLabelInsets(rectangleInsets6);
        dateAxis2.setRangeAboutValue((double) (-1L), 0.0d);
        dateAxis2.setAutoTickUnitSelection(true, false);
        try {
            dateAxis2.setRange((double) (byte) -1, (double) (-16777216));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.18d + "'", double7 == 0.18d);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.clearDomainMarkers(15);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer27 = null;
        org.jfree.chart.plot.PolarPlot polarPlot28 = new org.jfree.chart.plot.PolarPlot(xYDataset24, (org.jfree.chart.axis.ValueAxis) dateAxis26, polarItemRenderer27);
        dateAxis26.setLabelAngle((double) (byte) 1);
        dateAxis26.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color33 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int34 = color33.getAlpha();
        dateAxis26.setTickLabelPaint((java.awt.Paint) color33);
        dateAxis26.setInverted(false);
        double double38 = dateAxis26.getLowerBound();
        org.jfree.data.Range range39 = xYPlot21.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis26);
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = xYPlot21.getRangeAxisEdge();
        java.util.List list41 = xYPlot21.getAnnotations();
        org.jfree.chart.plot.PlotOrientation plotOrientation42 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        java.lang.String str43 = plotOrientation42.toString();
        java.lang.String str44 = plotOrientation42.toString();
        xYPlot21.setOrientation(plotOrientation42);
        boolean boolean46 = xYPlot21.isRangeCrosshairVisible();
        org.jfree.data.xy.XYDataset xYDataset47 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer48 = xYPlot21.getRendererForDataset(xYDataset47);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 255 + "'", int34 == 255);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNull(range39);
        org.junit.Assert.assertNotNull(rectangleEdge40);
        org.junit.Assert.assertNotNull(list41);
        org.junit.Assert.assertNotNull(plotOrientation42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "PlotOrientation.VERTICAL" + "'", str43.equals("PlotOrientation.VERTICAL"));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "PlotOrientation.VERTICAL" + "'", str44.equals("PlotOrientation.VERTICAL"));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNull(xYItemRenderer48);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        boolean boolean2 = categoryPlot0.isDomainGridlinesVisible();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        boolean boolean7 = categoryPlot0.render(graphics2D3, rectangle2D4, (int) (byte) 10, plotRenderingInfo6);
        categoryPlot0.setOutlineVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot0.getRangeAxis(0);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.axis.AxisSpace axisSpace13 = categoryPlot0.getFixedRangeAxisSpace();
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer17 = null;
        org.jfree.chart.plot.PolarPlot polarPlot18 = new org.jfree.chart.plot.PolarPlot(xYDataset14, (org.jfree.chart.axis.ValueAxis) dateAxis16, polarItemRenderer17);
        dateAxis16.setLabelAngle((double) (byte) 1);
        dateAxis16.setTickMarkOutsideLength((-1.0f));
        dateAxis16.setFixedDimension(0.4d);
        double double25 = dateAxis16.getUpperBound();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("");
        java.util.Date date28 = dateAxis27.getMaximumDate();
        dateAxis16.setMaximumDate(date28);
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis16);
        org.jfree.chart.util.Layer layer32 = null;
        java.util.Collection collection33 = categoryPlot0.getDomainMarkers((int) 'a', layer32);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNull(axisSpace13);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNull(collection33);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        java.awt.Color color0 = java.awt.Color.RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) dateAxis4, polarItemRenderer5);
        int int7 = polarPlot6.getBackgroundImageAlignment();
        boolean boolean8 = polarPlot6.isSubplot();
        boolean boolean9 = polarPlot6.isDomainZoomable();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        polarPlot6.handleClick((int) (byte) 10, (int) '4', plotRenderingInfo12);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit14 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        polarPlot6.setAngleTickUnit((org.jfree.chart.axis.TickUnit) numberTickUnit14);
        java.lang.String str16 = standardPieSectionLabelGenerator0.generateSectionLabel(pieDataset1, (java.lang.Comparable) numberTickUnit14);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(numberTickUnit14);
        org.junit.Assert.assertNull(str16);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        java.awt.Stroke stroke4 = polarPlot3.getAngleGridlineStroke();
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.Object obj1 = categoryPlot0.clone();
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge();
        java.awt.Stroke stroke4 = categoryPlot0.getRangeGridlineStroke();
        categoryPlot0.clearRangeMarkers();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = ringPlot0.getShadowPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        float float3 = categoryPlot2.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot2.getRangeAxisLocation();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot2.getRenderer();
        java.lang.String str6 = categoryPlot2.getPlotType();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer11 = null;
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot(xYDataset8, (org.jfree.chart.axis.ValueAxis) dateAxis10, polarItemRenderer11);
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot12);
        java.awt.geom.Rectangle2D rectangle2D14 = legendTitle13.getBounds();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        boolean boolean17 = categoryPlot2.render(graphics2D7, rectangle2D14, (int) (byte) 1, plotRenderingInfo16);
        java.awt.Stroke stroke18 = categoryPlot2.getRangeGridlineStroke();
        ringPlot0.setSeparatorStroke(stroke18);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        dateAxis2.setLabelAngle((double) (byte) 1);
        dateAxis2.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int10 = color9.getAlpha();
        dateAxis2.setTickLabelPaint((java.awt.Paint) color9);
        double double12 = dateAxis2.getFixedAutoRange();
        org.jfree.data.Range range13 = dateAxis2.getDefaultAutoRange();
        java.awt.Shape shape14 = dateAxis2.getRightArrow();
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 255 + "'", int10 == 255);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNotNull(shape14);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        piePlotState1.setTotal((double) (short) 0);
        java.awt.geom.Rectangle2D rectangle2D4 = piePlotState1.getExplodedPieArea();
        org.junit.Assert.assertNull(rectangle2D4);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        java.lang.String str3 = standardPieSectionLabelGenerator0.generateSectionLabel(pieDataset1, (java.lang.Comparable) ' ');
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        dateAxis2.setLabelAngle((double) (byte) 1);
        java.awt.Font font7 = dateAxis2.getTickLabelFont();
        dateAxis2.setAutoTickUnitSelection(true);
        dateAxis2.setLabelAngle(0.18d);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = dateAxis2.getLabelInsets();
        dateAxis2.setPositiveArrowVisible(false);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(rectangleInsets12);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 100, 0.4d);
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((double) '#', (org.jfree.data.Range) dateRange4);
        org.jfree.data.Range range8 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange4, (double) 1.0f, false);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = rectangleConstraint2.toRangeHeight(range8);
        double double10 = rectangleConstraint9.getWidth();
        org.jfree.chart.util.Size2D size2D13 = new org.jfree.chart.util.Size2D((double) ' ', 0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.geom.Rectangle2D rectangle2D17 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D13, 0.0d, 10.0d, rectangleAnchor16);
        size2D13.setWidth((double) 8);
        org.jfree.chart.util.Size2D size2D20 = rectangleConstraint9.calculateConstrainedSize(size2D13);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(rectangleConstraint9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 100.0d + "'", double10 == 100.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(size2D20);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = piePlot5.getSimpleLabelOffset();
        double double7 = rectangleInsets6.getRight();
        dateAxis2.setLabelInsets(rectangleInsets6);
        dateAxis2.setRangeAboutValue((double) (-1L), 0.0d);
        dateAxis2.setAutoTickUnitSelection(true, false);
        dateAxis2.setVisible(false);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.18d + "'", double7 == 0.18d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(100.0d, range1);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        xYPlot21.zoomRangeAxes((double) ' ', plotRenderingInfo23, point2D24);
        java.awt.Paint paint26 = xYPlot21.getDomainTickBandPaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent27 = null;
        xYPlot21.rendererChanged(rendererChangeEvent27);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray29 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot21.setRenderers(xYItemRendererArray29);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = xYPlot21.getDomainAxisEdge((-1));
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        try {
            xYPlot21.handleClick(2, 0, plotRenderingInfo35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertNull(paint26);
        org.junit.Assert.assertNotNull(xYItemRendererArray29);
        org.junit.Assert.assertNotNull(rectangleEdge32);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        org.jfree.data.time.DateRange dateRange5 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double6 = dateRange5.getUpperBound();
        dateAxis2.setRange((org.jfree.data.Range) dateRange5);
        org.jfree.data.Range range9 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange5, 0.025d);
        org.junit.Assert.assertNotNull(dateRange5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(range9);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = categoryPlot0.getRenderer();
        java.lang.String str4 = categoryPlot0.getPlotType();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) dateAxis8, polarItemRenderer9);
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot10);
        java.awt.geom.Rectangle2D rectangle2D12 = legendTitle11.getBounds();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        boolean boolean15 = categoryPlot0.render(graphics2D5, rectangle2D12, (int) (byte) 1, plotRenderingInfo14);
        categoryPlot0.setNoDataMessage("hi!");
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer23 = null;
        org.jfree.chart.plot.PolarPlot polarPlot24 = new org.jfree.chart.plot.PolarPlot(xYDataset20, (org.jfree.chart.axis.ValueAxis) dateAxis22, polarItemRenderer23);
        dateAxis22.setLabelAngle((double) (byte) 1);
        dateAxis22.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color29 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int30 = color29.getAlpha();
        java.lang.String str31 = color29.toString();
        dateAxis22.setTickMarkPaint((java.awt.Paint) color29);
        org.jfree.chart.plot.PiePlot piePlot33 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = piePlot33.getSimpleLabelOffset();
        java.awt.Stroke stroke35 = piePlot33.getLabelOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker36 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, (java.awt.Paint) color29, stroke35);
        java.awt.Paint paint37 = valueMarker36.getOutlinePaint();
        org.jfree.chart.util.Layer layer38 = null;
        try {
            boolean boolean39 = categoryPlot0.removeRangeMarker(15, (org.jfree.chart.plot.Marker) valueMarker36, layer38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNull(categoryItemRenderer3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Category Plot" + "'", str4.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 255 + "'", int30 == 255);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str31.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(paint37);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        int int5 = polarPlot4.getBackgroundImageAlignment();
        boolean boolean6 = polarPlot4.isOutlineVisible();
        polarPlot4.setAngleGridlinesVisible(true);
        org.jfree.chart.plot.WaferMapPlot waferMapPlot9 = new org.jfree.chart.plot.WaferMapPlot();
        java.awt.Paint paint10 = waferMapPlot9.getBackgroundPaint();
        polarPlot4.setAngleLabelPaint(paint10);
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer15 = null;
        org.jfree.chart.plot.PolarPlot polarPlot16 = new org.jfree.chart.plot.PolarPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) dateAxis14, polarItemRenderer15);
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot16);
        polarPlot16.setBackgroundAlpha((float) (byte) 100);
        polarPlot4.setParent((org.jfree.chart.plot.Plot) polarPlot16);
        java.awt.Stroke stroke21 = polarPlot4.getRadiusGridlineStroke();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(stroke21);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        java.lang.Comparable comparable1 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, comparable1, (double) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot4);
        java.lang.Object obj6 = legendTitle5.clone();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) dateAxis9, polarItemRenderer10);
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = piePlot12.getSimpleLabelOffset();
        double double14 = rectangleInsets13.getRight();
        dateAxis9.setLabelInsets(rectangleInsets13);
        legendTitle5.setLegendItemGraphicPadding(rectangleInsets13);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = legendTitle5.getLegendItemGraphicPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = legendTitle5.getMargin();
        java.awt.Font font19 = legendTitle5.getItemFont();
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.18d + "'", double14 == 0.18d);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(font19);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("java.awt.Color[r=255,g=255,b=64]", graphics2D1, (float) (short) 10, (float) 10L, textAnchor4, (double) 255, textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        dateAxis3.setLabelAngle((double) (byte) 1);
        dateAxis3.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int11 = color10.getAlpha();
        java.lang.String str12 = color10.toString();
        dateAxis3.setTickMarkPaint((java.awt.Paint) color10);
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = piePlot14.getSimpleLabelOffset();
        java.awt.Stroke stroke16 = piePlot14.getLabelOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, (java.awt.Paint) color10, stroke16);
        java.awt.Paint paint18 = valueMarker17.getOutlinePaint();
        java.lang.String str19 = valueMarker17.getLabel();
        java.lang.Object obj20 = null;
        boolean boolean21 = valueMarker17.equals(obj20);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 255 + "'", int11 == 255);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str12.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        int int6 = polarPlot5.getBackgroundImageAlignment();
        boolean boolean7 = polarPlot5.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) polarPlot5);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        java.awt.image.BufferedImage bufferedImage12 = jFreeChart8.createBufferedImage(100, 255, chartRenderingInfo11);
        int int13 = jFreeChart8.getBackgroundImageAlignment();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        try {
            java.awt.image.BufferedImage bufferedImage18 = jFreeChart8.createBufferedImage((int) (short) 1, 255, (int) '#', chartRenderingInfo17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown image type 35");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(bufferedImage12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.chart.plot.Plot plot0 = null;
        try {
            org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent(plot0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) '#', (double) (short) -1, 0.14d, (double) (-16777216));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 100, 0.4d);
        java.lang.String str3 = rectangleConstraint2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=0.4]" + "'", str3.equals("RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=0.4]"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        java.lang.Comparable comparable4 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 255, (-16056329), comparable4, "java.awt.Color[r=255,g=255,b=64]", "ClassContext");
        org.jfree.data.general.PieDataset pieDataset8 = pieSectionEntity7.getDataset();
        java.lang.String str9 = pieSectionEntity7.getURLText();
        java.lang.String str10 = pieSectionEntity7.getToolTipText();
        try {
            java.lang.String str11 = pieSectionEntity7.toString();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNull(pieDataset8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ClassContext" + "'", str9.equals("ClassContext"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str10.equals("java.awt.Color[r=255,g=255,b=64]"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot4);
        java.lang.Object obj6 = legendTitle5.clone();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) dateAxis9, polarItemRenderer10);
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = piePlot12.getSimpleLabelOffset();
        double double14 = rectangleInsets13.getRight();
        dateAxis9.setLabelInsets(rectangleInsets13);
        legendTitle5.setLegendItemGraphicPadding(rectangleInsets13);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer20 = null;
        org.jfree.chart.plot.PolarPlot polarPlot21 = new org.jfree.chart.plot.PolarPlot(xYDataset17, (org.jfree.chart.axis.ValueAxis) dateAxis19, polarItemRenderer20);
        dateAxis19.setLabelAngle((double) (byte) 1);
        dateAxis19.setAutoRangeMinimumSize((double) (byte) 10);
        double double26 = dateAxis19.getUpperMargin();
        java.awt.Paint paint27 = dateAxis19.getTickLabelPaint();
        org.jfree.chart.block.BlockBorder blockBorder28 = new org.jfree.chart.block.BlockBorder(rectangleInsets13, paint27);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.18d + "'", double14 == 0.18d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.05d + "'", double26 == 0.05d);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = categoryPlot0.getRenderer();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = categoryPlot0.getDomainAxisEdge(0);
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 0.4d, 100.0f, 0L, 0.025d, (byte) 1, 1.0f };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.4d, 100.0f, 0L, 0.025d, (byte) 1, 1.0f };
        java.lang.Number[] numberArray28 = new java.lang.Number[] { 0.4d, 100.0f, 0L, 0.025d, (byte) 1, 1.0f };
        java.lang.Number[] numberArray35 = new java.lang.Number[] { 0.4d, 100.0f, 0L, 0.025d, (byte) 1, 1.0f };
        java.lang.Number[] numberArray42 = new java.lang.Number[] { 0.4d, 100.0f, 0L, 0.025d, (byte) 1, 1.0f };
        java.lang.Number[] numberArray49 = new java.lang.Number[] { 0.4d, 100.0f, 0L, 0.025d, (byte) 1, 1.0f };
        java.lang.Number[][] numberArray50 = new java.lang.Number[][] { numberArray14, numberArray21, numberArray28, numberArray35, numberArray42, numberArray49 };
        org.jfree.data.category.CategoryDataset categoryDataset51 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("PlotOrientation.VERTICAL", "hi!", numberArray50);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer52 = categoryPlot0.getRendererForDataset(categoryDataset51);
        try {
            org.jfree.data.general.PieDataset pieDataset54 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset51, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 6");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNull(categoryItemRenderer3);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(numberArray49);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(categoryDataset51);
        org.junit.Assert.assertNull(categoryItemRenderer52);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        dateAxis1.setRange((double) 0.0f, (double) 10.0f);
        dateAxis1.resizeRange((double) ' ');
        java.lang.String str7 = dateAxis1.getLabelURL();
        dateAxis1.setNegativeArrowVisible(true);
        java.util.TimeZone timeZone10 = null;
        try {
            dateAxis1.setTimeZone(timeZone10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = categoryPlot0.getRenderer();
        java.lang.String str4 = categoryPlot0.getPlotType();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) dateAxis8, polarItemRenderer9);
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot10);
        java.awt.geom.Rectangle2D rectangle2D12 = legendTitle11.getBounds();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        boolean boolean15 = categoryPlot0.render(graphics2D5, rectangle2D12, (int) (byte) 1, plotRenderingInfo14);
        java.awt.Stroke stroke16 = categoryPlot0.getRangeGridlineStroke();
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = categoryPlot0.getDomainMarkers(layer17);
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color19);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNull(categoryItemRenderer3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Category Plot" + "'", str4.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertNotNull(color19);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot4);
        org.jfree.chart.block.BlockContainer blockContainer6 = legendTitle5.getItemContainer();
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = piePlot7.getSimpleLabelOffset();
        boolean boolean9 = piePlot7.getSectionOutlinesVisible();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator10 = null;
        piePlot7.setLegendLabelURLGenerator(pieURLGenerator10);
        boolean boolean12 = piePlot7.getSimpleLabels();
        org.jfree.chart.plot.RingPlot ringPlot13 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint14 = ringPlot13.getShadowPaint();
        ringPlot13.setInteriorGap((double) (byte) 0);
        java.awt.Font font17 = ringPlot13.getNoDataMessageFont();
        piePlot7.setLabelFont(font17);
        legendTitle5.setItemFont(font17);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = legendTitle5.getPosition();
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = legendTitle5.getLegendItemGraphicEdge();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent22 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle5);
        org.jfree.chart.JFreeChart jFreeChart23 = titleChangeEvent22.getChart();
        org.junit.Assert.assertNotNull(blockContainer6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertNull(jFreeChart23);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, (float) (byte) 10, (float) (short) 10, textAnchor4, 0.0d, (float) 10, (float) (byte) 1);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D("ClassContext");
        boolean boolean11 = numberAxis3D10.isVisible();
        org.jfree.data.RangeType rangeType12 = numberAxis3D10.getRangeType();
        boolean boolean13 = textAnchor4.equals((java.lang.Object) rangeType12);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(rangeType12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        boolean boolean2 = piePlot3D1.getDarkerSides();
        double double3 = piePlot3D1.getDepthFactor();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.12d + "'", double3 == 0.12d);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.clearDomainMarkers();
        boolean boolean23 = xYPlot21.isDomainZeroBaselineVisible();
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("org.jfree.chart.event.ChartProgressEvent[source=[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]]", "java.awt.Color[r=255,g=255,b=64]");
        java.lang.String str3 = contributor2.getEmail();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str3.equals("java.awt.Color[r=255,g=255,b=64]"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = textLine0.calculateDimensions(graphics2D1);
        org.junit.Assert.assertNotNull(size2D2);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Size2D[width=0.0, height=0.0]");
        java.text.NumberFormat numberFormat2 = numberAxis1.getNumberFormatOverride();
        org.junit.Assert.assertNull(numberFormat2);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot4);
        org.jfree.chart.block.BlockContainer blockContainer6 = legendTitle5.getItemContainer();
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = piePlot7.getSimpleLabelOffset();
        boolean boolean9 = piePlot7.getSectionOutlinesVisible();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator10 = null;
        piePlot7.setLegendLabelURLGenerator(pieURLGenerator10);
        boolean boolean12 = piePlot7.getSimpleLabels();
        org.jfree.chart.plot.RingPlot ringPlot13 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint14 = ringPlot13.getShadowPaint();
        ringPlot13.setInteriorGap((double) (byte) 0);
        java.awt.Font font17 = ringPlot13.getNoDataMessageFont();
        piePlot7.setLabelFont(font17);
        legendTitle5.setItemFont(font17);
        java.awt.Color color20 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Color color21 = color20.brighter();
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer26 = null;
        org.jfree.chart.plot.PolarPlot polarPlot27 = new org.jfree.chart.plot.PolarPlot(xYDataset23, (org.jfree.chart.axis.ValueAxis) dateAxis25, polarItemRenderer26);
        org.jfree.chart.plot.PiePlot piePlot28 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = piePlot28.getSimpleLabelOffset();
        double double30 = rectangleInsets29.getRight();
        dateAxis25.setLabelInsets(rectangleInsets29);
        dateAxis25.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis("");
        dateAxis36.setRange((double) 0.0f, (double) 10.0f);
        dateAxis36.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = null;
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot(xYDataset22, (org.jfree.chart.axis.ValueAxis) dateAxis25, (org.jfree.chart.axis.ValueAxis) dateAxis36, xYItemRenderer42);
        xYPlot43.clearDomainMarkers(15);
        org.jfree.chart.plot.PlotOrientation plotOrientation46 = xYPlot43.getOrientation();
        org.jfree.data.xy.XYDataset xYDataset47 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer48 = xYPlot43.getRendererForDataset(xYDataset47);
        boolean boolean49 = color21.equals((java.lang.Object) xYPlot43);
        boolean boolean50 = legendTitle5.equals((java.lang.Object) color21);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor51 = legendTitle5.getLegendItemGraphicLocation();
        org.junit.Assert.assertNotNull(blockContainer6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.18d + "'", double30 == 0.18d);
        org.junit.Assert.assertNotNull(plotOrientation46);
        org.junit.Assert.assertNull(xYItemRenderer48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor51);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        int int5 = polarPlot4.getBackgroundImageAlignment();
        boolean boolean6 = polarPlot4.isSubplot();
        polarPlot4.setBackgroundImageAlignment(0);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent9 = null;
        polarPlot4.datasetChanged(datasetChangeEvent9);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        polarPlot4.rendererChanged(rendererChangeEvent11);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        java.lang.Comparable comparable4 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 255, (-16056329), comparable4, "java.awt.Color[r=255,g=255,b=64]", "ClassContext");
        java.lang.Comparable comparable8 = pieSectionEntity7.getSectionKey();
        try {
            java.lang.String str9 = pieSectionEntity7.toString();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNull(comparable8);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = piePlot0.getSimpleLabelOffset();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        piePlot0.markerChanged(markerChangeEvent2);
        java.lang.Object obj4 = piePlot0.clone();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator5 = null;
        piePlot0.setToolTipGenerator(pieToolTipGenerator5);
        java.awt.Stroke stroke7 = piePlot0.getLabelLinkStroke();
        double double8 = piePlot0.getLabelGap();
        piePlot0.setMaximumLabelWidth((double) 2);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.025d + "'", double8 == 0.025d);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) dateAxis4, polarItemRenderer5);
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot6);
        java.awt.Color color8 = java.awt.Color.green;
        java.awt.Color color9 = color8.darker();
        legendTitle7.setBackgroundPaint((java.awt.Paint) color8);
        java.lang.Class<?> wildcardClass11 = legendTitle7.getClass();
        java.net.URL uRL12 = org.jfree.chart.util.ObjectUtilities.getResource("Polar Plot", (java.lang.Class) wildcardClass11);
        java.net.URL uRL13 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("PlotOrientation.VERTICAL", (java.lang.Class) wildcardClass11);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNull(uRL12);
        org.junit.Assert.assertNull(uRL13);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", graphics2D1, (float) (byte) 0, (float) 10, textAnchor4, (double) (short) -1, textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        boolean boolean2 = categoryPlot0.isDomainGridlinesVisible();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        boolean boolean7 = categoryPlot0.render(graphics2D3, rectangle2D4, (int) (byte) 10, plotRenderingInfo6);
        categoryPlot0.setOutlineVisible(true);
        double double10 = categoryPlot0.getAnchorValue();
        int int11 = categoryPlot0.getRangeAxisCount();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = piePlot0.getLabelBackgroundPaint();
        piePlot0.setLabelLinkMargin((double) 'a');
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis((int) '4', valueAxis3, false);
        org.jfree.chart.axis.AxisLocation axisLocation6 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        float float8 = categoryPlot7.getForegroundAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        categoryPlot7.setRangeAxis((int) '4', valueAxis10, false);
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot7.getRangeAxisLocation();
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        java.lang.String str15 = plotOrientation14.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation13, plotOrientation14);
        categoryPlot0.setDomainAxisLocation(axisLocation13);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PlotOrientation.VERTICAL" + "'", str15.equals("PlotOrientation.VERTICAL"));
        org.junit.Assert.assertNotNull(rectangleEdge16);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        dateAxis2.setLabelAngle((double) (byte) 1);
        dateAxis2.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int10 = color9.getAlpha();
        dateAxis2.setTickLabelPaint((java.awt.Paint) color9);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean13 = categoryPlot12.isDomainGridlinesVisible();
        boolean boolean14 = categoryPlot12.isDomainGridlinesVisible();
        int int15 = categoryPlot12.getRangeAxisCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = categoryPlot12.getDomainAxis((int) (byte) 0);
        boolean boolean18 = dateAxis2.hasListener((java.util.EventListener) categoryPlot12);
        java.awt.Image image19 = categoryPlot12.getBackgroundImage();
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        categoryPlot12.setDomainAxis(0, categoryAxis21, true);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 255 + "'", int10 == 255);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNull(categoryAxis17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(image19);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        int int5 = polarPlot4.getBackgroundImageAlignment();
        boolean boolean6 = polarPlot4.isRangeZoomable();
        java.lang.String str7 = polarPlot4.getPlotType();
        java.awt.Paint paint8 = polarPlot4.getAngleLabelPaint();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Polar Plot" + "'", str7.equals("Polar Plot"));
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        java.lang.String str2 = textTitle1.getToolTipText();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = null;
        try {
            textTitle1.setPadding(rectangleInsets3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'padding' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        dateAxis2.setLabelAngle((double) (byte) 1);
        dateAxis2.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int10 = color9.getAlpha();
        java.lang.String str11 = color9.toString();
        dateAxis2.setTickMarkPaint((java.awt.Paint) color9);
        java.lang.String str13 = dateAxis2.getLabelToolTip();
        org.jfree.data.Range range14 = null;
        try {
            dateAxis2.setRange(range14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 255 + "'", int10 == 255);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str11.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNull(str13);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        dateAxis2.setLabelAngle((double) (byte) 1);
        dateAxis2.setAutoRangeMinimumSize((double) (byte) 10);
        double double9 = dateAxis2.getUpperMargin();
        java.awt.Paint paint10 = dateAxis2.getTickLabelPaint();
        try {
            dateAxis2.setRange((double) 1.0f, (double) (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("java.awt.Color[r=255,g=255,b=64]", "hi!", "", "java.awt.Color[r=255,g=255,b=64]");
        org.jfree.chart.ui.ProjectInfo projectInfo5 = org.jfree.chart.JFreeChart.INFO;
        basicProjectInfo4.addLibrary((org.jfree.chart.ui.Library) projectInfo5);
        basicProjectInfo4.setLicenceName("RectangleInsets[t=0.18,l=0.18,b=0.18,r=0.18]");
        java.lang.String str9 = basicProjectInfo4.getCopyright();
        java.lang.String str10 = basicProjectInfo4.getName();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo15 = new org.jfree.chart.ui.BasicProjectInfo("RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", "", "Category Plot");
        basicProjectInfo4.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo15);
        org.junit.Assert.assertNotNull(projectInfo5);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str10.equals("java.awt.Color[r=255,g=255,b=64]"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = null;
        org.jfree.chart.text.TextBlock textBlock3 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint2);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.util.Size2D size2D5 = textBlock3.calculateDimensions(graphics2D4);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = textBlock3.getLineAlignment();
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer11 = null;
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot(xYDataset8, (org.jfree.chart.axis.ValueAxis) dateAxis10, polarItemRenderer11);
        dateAxis10.setLabelAngle((double) (byte) 1);
        java.awt.Font font15 = dateAxis10.getTickLabelFont();
        org.jfree.chart.text.TextLine textLine16 = new org.jfree.chart.text.TextLine("", font15);
        textBlock3.addLine(textLine16);
        org.junit.Assert.assertNotNull(textBlock3);
        org.junit.Assert.assertNotNull(size2D5);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertNotNull(font15);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        dateAxis1.setRange((double) 0.0f, (double) 10.0f);
        try {
            dateAxis1.setRangeWithMargins((double) '#', 10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (35.0) <= upper (10.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke2 = piePlot0.getSectionOutlineStroke((java.lang.Comparable) 2.0d);
        org.junit.Assert.assertNull(stroke2);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        xYPlot21.zoomRangeAxes((double) ' ', plotRenderingInfo23, point2D24);
        double double26 = xYPlot21.getDomainCrosshairValue();
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.data.function.Function2D function2D0 = null;
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) dateAxis6, polarItemRenderer7);
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = piePlot9.getSimpleLabelOffset();
        double double11 = rectangleInsets10.getRight();
        dateAxis6.setLabelInsets(rectangleInsets10);
        java.awt.Shape shape13 = dateAxis6.getLeftArrow();
        dateAxis6.setAxisLineVisible(false);
        dateAxis6.setLabel("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit18 = dateAxis6.getTickUnit();
        try {
            org.jfree.data.xy.XYDataset xYDataset19 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, 1.0E-8d, 0.14d, 0, (java.lang.Comparable) dateTickUnit18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.18d + "'", double11 == 0.18d);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(dateTickUnit18);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 100, 0.4d);
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((double) '#', (org.jfree.data.Range) dateRange4);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = rectangleConstraint2.toRangeHeight((org.jfree.data.Range) dateRange4);
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) dateAxis9, polarItemRenderer10);
        dateAxis9.setLabelAngle((double) (byte) 1);
        dateAxis9.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int17 = color16.getAlpha();
        java.lang.String str18 = color16.toString();
        dateAxis9.setTickMarkPaint((java.awt.Paint) color16);
        org.jfree.data.Range range20 = dateAxis9.getDefaultAutoRange();
        org.jfree.data.time.DateRange dateRange22 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = new org.jfree.chart.block.RectangleConstraint((double) '#', (org.jfree.data.Range) dateRange22);
        org.jfree.data.Range range24 = org.jfree.data.Range.combine(range20, (org.jfree.data.Range) dateRange22);
        org.jfree.data.Range range27 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange22, 10.0d, (double) 0.5f);
        org.jfree.data.Range range28 = org.jfree.data.Range.combine((org.jfree.data.Range) dateRange4, (org.jfree.data.Range) dateRange22);
        double double29 = dateRange4.getUpperBound();
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(rectangleConstraint6);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 255 + "'", int17 == 255);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str18.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertNotNull(dateRange22);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("Polar Plot", "PlotOrientation.VERTICAL");
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        xYPlot21.zoomRangeAxes((double) ' ', plotRenderingInfo23, point2D24);
        java.awt.Paint paint26 = xYPlot21.getDomainTickBandPaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        try {
            xYPlot21.handleClick((int) (short) 0, (int) (short) 0, plotRenderingInfo29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertNull(paint26);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        dateAxis2.setLabelAngle((double) (byte) 1);
        java.awt.Font font7 = dateAxis2.getTickLabelFont();
        dateAxis2.setAutoTickUnitSelection(true);
        dateAxis2.setLabelAngle(0.18d);
        org.jfree.chart.axis.Timeline timeline12 = dateAxis2.getTimeline();
        double double13 = dateAxis2.getUpperMargin();
        dateAxis2.setLabel("RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=0.4]");
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(timeline12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.05d + "'", double13 == 0.05d);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.AttributedString attributedString2 = null;
        standardPieSectionLabelGenerator0.setAttributedLabel((int) (short) 1, attributedString2);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        try {
            java.text.AttributedString attributedString6 = standardPieSectionLabelGenerator0.generateAttributedSectionLabel(pieDataset4, (java.lang.Comparable) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("java.awt.Color[r=255,g=255,b=64]", "hi!", "", "java.awt.Color[r=255,g=255,b=64]");
        java.lang.String str5 = basicProjectInfo4.getInfo();
        basicProjectInfo4.setVersion("PlotOrientation.VERTICAL");
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str5.equals("java.awt.Color[r=255,g=255,b=64]"));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.data.time.DateRange dateRange1 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) '#', (org.jfree.data.Range) dateRange1);
        org.jfree.data.Range range5 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange1, (double) 1.0f, false);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 100, 0.4d);
        org.jfree.data.time.DateRange dateRange10 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = new org.jfree.chart.block.RectangleConstraint((double) '#', (org.jfree.data.Range) dateRange10);
        org.jfree.data.Range range14 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange10, (double) 1.0f, false);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint8.toRangeHeight(range14);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange1, range14);
        double double17 = range14.getCentralValue();
        org.junit.Assert.assertNotNull(dateRange1);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(dateRange10);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.5d + "'", double17 == 1.5d);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 100, 0.4d);
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((double) '#', (org.jfree.data.Range) dateRange4);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = rectangleConstraint2.toRangeHeight((org.jfree.data.Range) dateRange4);
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) dateAxis9, polarItemRenderer10);
        dateAxis9.setLabelAngle((double) (byte) 1);
        dateAxis9.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int17 = color16.getAlpha();
        java.lang.String str18 = color16.toString();
        dateAxis9.setTickMarkPaint((java.awt.Paint) color16);
        org.jfree.data.Range range20 = dateAxis9.getDefaultAutoRange();
        org.jfree.data.time.DateRange dateRange22 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = new org.jfree.chart.block.RectangleConstraint((double) '#', (org.jfree.data.Range) dateRange22);
        org.jfree.data.Range range24 = org.jfree.data.Range.combine(range20, (org.jfree.data.Range) dateRange22);
        org.jfree.data.Range range27 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange22, 10.0d, (double) 0.5f);
        org.jfree.data.Range range28 = org.jfree.data.Range.combine((org.jfree.data.Range) dateRange4, (org.jfree.data.Range) dateRange22);
        double double30 = dateRange4.constrain((double) '4');
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(rectangleConstraint6);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 255 + "'", int17 == 255);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str18.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertNotNull(dateRange22);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 100, 0.4d);
        org.jfree.data.time.DateRange dateRange11 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((double) '#', (org.jfree.data.Range) dateRange11);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint9.toRangeHeight((org.jfree.data.Range) dateRange11);
        org.jfree.chart.util.Size2D size2D14 = legendTitle5.arrange(graphics2D6, rectangleConstraint9);
        java.lang.Object obj15 = null;
        boolean boolean16 = legendTitle5.equals(obj15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = legendTitle5.getLegendItemGraphicPadding();
        double double19 = rectangleInsets17.calculateRightOutset(1.0d);
        org.junit.Assert.assertNotNull(dateRange11);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(size2D14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 2.0d + "'", double19 == 2.0d);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer2 = null;
        waferMapPlot1.setRenderer(waferMapRenderer2);
        float float4 = waferMapPlot1.getForegroundAlpha();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        waferMapPlot1.rendererChanged(rendererChangeEvent5);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot0.zoomRangeAxes((-1.0d), plotRenderingInfo6, point2D7, false);
        categoryPlot0.clearRangeMarkers((int) (byte) 10);
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = null;
        org.jfree.chart.util.Layer layer13 = null;
        try {
            categoryPlot0.addDomainMarker(categoryMarker12, layer13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation2);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.clearDomainMarkers(15);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        float float26 = categoryPlot25.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot25.getRangeAxisLocation();
        xYPlot21.setDomainAxisLocation((int) (byte) 0, axisLocation27, true);
        java.awt.Stroke stroke30 = xYPlot21.getRangeGridlineStroke();
        java.awt.Paint paint31 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot21.setDomainZeroBaselinePaint(paint31);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent33 = null;
        xYPlot21.notifyListeners(plotChangeEvent33);
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis("");
        dateAxis36.setRange((double) 0.0f, (double) 10.0f);
        dateAxis36.resizeRange((double) ' ');
        dateAxis36.setVerticalTickLabels(false);
        org.jfree.data.Range range44 = xYPlot21.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis36);
        org.jfree.data.xy.XYDataset xYDataset45 = null;
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer48 = null;
        org.jfree.chart.plot.PolarPlot polarPlot49 = new org.jfree.chart.plot.PolarPlot(xYDataset45, (org.jfree.chart.axis.ValueAxis) dateAxis47, polarItemRenderer48);
        dateAxis47.setLabelAngle((double) (byte) 1);
        dateAxis47.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color54 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int55 = color54.getAlpha();
        dateAxis47.setTickLabelPaint((java.awt.Paint) color54);
        org.jfree.chart.plot.CategoryPlot categoryPlot57 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean58 = categoryPlot57.isDomainGridlinesVisible();
        boolean boolean59 = categoryPlot57.isDomainGridlinesVisible();
        int int60 = categoryPlot57.getRangeAxisCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis62 = categoryPlot57.getDomainAxis((int) (byte) 0);
        boolean boolean63 = dateAxis47.hasListener((java.util.EventListener) categoryPlot57);
        dateAxis36.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot57);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 1.0f + "'", float26 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNull(range44);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 255 + "'", int55 == 255);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
        org.junit.Assert.assertNull(categoryAxis62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = categoryPlot0.getRenderer();
        java.lang.String str4 = categoryPlot0.getPlotType();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) dateAxis8, polarItemRenderer9);
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot10);
        java.awt.geom.Rectangle2D rectangle2D12 = legendTitle11.getBounds();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        boolean boolean15 = categoryPlot0.render(graphics2D5, rectangle2D12, (int) (byte) 1, plotRenderingInfo14);
        java.lang.Object obj16 = categoryPlot0.clone();
        categoryPlot0.setAnchorValue((double) 1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNull(categoryItemRenderer3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Category Plot" + "'", str4.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = piePlot0.getSimpleLabelOffset();
        double double2 = rectangleInsets1.getTop();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.18d + "'", double2 == 0.18d);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = piePlot0.getSimpleLabelOffset();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        piePlot0.markerChanged(markerChangeEvent2);
        double double4 = piePlot0.getMaximumExplodePercent();
        java.awt.Paint paint5 = piePlot0.getLabelBackgroundPaint();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot0.setSectionOutlineStroke((java.lang.Comparable) 0.0f, stroke7);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot4);
        org.jfree.chart.block.BlockContainer blockContainer6 = legendTitle5.getItemContainer();
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = piePlot7.getSimpleLabelOffset();
        boolean boolean9 = piePlot7.getSectionOutlinesVisible();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator10 = null;
        piePlot7.setLegendLabelURLGenerator(pieURLGenerator10);
        boolean boolean12 = piePlot7.getSimpleLabels();
        org.jfree.chart.plot.RingPlot ringPlot13 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint14 = ringPlot13.getShadowPaint();
        ringPlot13.setInteriorGap((double) (byte) 0);
        java.awt.Font font17 = ringPlot13.getNoDataMessageFont();
        piePlot7.setLabelFont(font17);
        legendTitle5.setItemFont(font17);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = legendTitle5.getPosition();
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = legendTitle5.getLegendItemGraphicEdge();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = legendTitle5.getMargin();
        org.junit.Assert.assertNotNull(blockContainer6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertNotNull(rectangleInsets22);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Color color1 = color0.brighter();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) dateAxis5, polarItemRenderer6);
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = piePlot8.getSimpleLabelOffset();
        double double10 = rectangleInsets9.getRight();
        dateAxis5.setLabelInsets(rectangleInsets9);
        dateAxis5.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("");
        dateAxis16.setRange((double) 0.0f, (double) 10.0f);
        dateAxis16.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) dateAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis16, xYItemRenderer22);
        xYPlot23.clearDomainMarkers(15);
        org.jfree.chart.plot.PlotOrientation plotOrientation26 = xYPlot23.getOrientation();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = xYPlot23.getRendererForDataset(xYDataset27);
        boolean boolean29 = color1.equals((java.lang.Object) xYPlot23);
        java.awt.Color color30 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        xYPlot23.setRangeTickBandPaint((java.awt.Paint) color30);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.18d + "'", double10 == 0.18d);
        org.junit.Assert.assertNotNull(plotOrientation26);
        org.junit.Assert.assertNull(xYItemRenderer28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(color30);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot4);
        org.jfree.chart.block.BlockContainer blockContainer6 = legendTitle5.getItemContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = legendTitle5.getItemLabelPadding();
        boolean boolean8 = legendTitle5.getNotify();
        org.junit.Assert.assertNotNull(blockContainer6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        java.awt.Stroke stroke22 = xYPlot21.getDomainZeroBaselineStroke();
        java.awt.Color color23 = java.awt.Color.BLUE;
        xYPlot21.setDomainGridlinePaint((java.awt.Paint) color23);
        boolean boolean25 = xYPlot21.isDomainGridlinesVisible();
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        org.jfree.chart.plot.PiePlotState piePlotState28 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo27);
        piePlotState28.setTotal((double) (short) 0);
        org.jfree.data.xy.XYDataset xYDataset31 = null;
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer34 = null;
        org.jfree.chart.plot.PolarPlot polarPlot35 = new org.jfree.chart.plot.PolarPlot(xYDataset31, (org.jfree.chart.axis.ValueAxis) dateAxis33, polarItemRenderer34);
        org.jfree.chart.title.LegendTitle legendTitle36 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot35);
        java.awt.geom.Rectangle2D rectangle2D37 = legendTitle36.getBounds();
        piePlotState28.setLinkArea(rectangle2D37);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        xYPlot21.drawAnnotations(graphics2D26, rectangle2D37, plotRenderingInfo39);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(rectangle2D37);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot4);
        legendTitle5.setPadding(0.0d, 0.5d, (double) 1.0f, 32.0d);
        legendTitle5.setID("java.awt.Color[r=255,g=255,b=64]");
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("ClassContext");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("ClassContext");
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("hi!");
        java.lang.String str9 = textTitle8.getToolTipText();
        java.awt.geom.Rectangle2D rectangle2D10 = textTitle8.getBounds();
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer14 = null;
        org.jfree.chart.plot.PolarPlot polarPlot15 = new org.jfree.chart.plot.PolarPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) dateAxis13, polarItemRenderer14);
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot15);
        org.jfree.chart.block.BlockContainer blockContainer17 = legendTitle16.getItemContainer();
        org.jfree.chart.block.Arrangement arrangement18 = blockContainer17.getArrangement();
        org.jfree.chart.block.BlockContainer blockContainer19 = new org.jfree.chart.block.BlockContainer(arrangement18);
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle("hi!");
        java.lang.String str22 = textTitle21.getToolTipText();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment23 = textTitle21.getHorizontalAlignment();
        blockContainer19.add((org.jfree.chart.block.Block) textTitle21);
        java.lang.Object obj25 = textTitle5.draw(graphics2D6, rectangle2D10, (java.lang.Object) textTitle21);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer29 = null;
        org.jfree.chart.plot.PolarPlot polarPlot30 = new org.jfree.chart.plot.PolarPlot(xYDataset26, (org.jfree.chart.axis.ValueAxis) dateAxis28, polarItemRenderer29);
        org.jfree.chart.title.LegendTitle legendTitle31 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot30);
        java.awt.geom.Rectangle2D rectangle2D32 = legendTitle31.getBounds();
        org.jfree.data.xy.XYDataset xYDataset33 = null;
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer37 = null;
        org.jfree.chart.plot.PolarPlot polarPlot38 = new org.jfree.chart.plot.PolarPlot(xYDataset34, (org.jfree.chart.axis.ValueAxis) dateAxis36, polarItemRenderer37);
        org.jfree.chart.plot.PiePlot piePlot39 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = piePlot39.getSimpleLabelOffset();
        double double41 = rectangleInsets40.getRight();
        dateAxis36.setLabelInsets(rectangleInsets40);
        dateAxis36.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis("");
        dateAxis47.setRange((double) 0.0f, (double) 10.0f);
        dateAxis47.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer53 = null;
        org.jfree.chart.plot.XYPlot xYPlot54 = new org.jfree.chart.plot.XYPlot(xYDataset33, (org.jfree.chart.axis.ValueAxis) dateAxis36, (org.jfree.chart.axis.ValueAxis) dateAxis47, xYItemRenderer53);
        xYPlot54.clearDomainMarkers(15);
        org.jfree.chart.plot.CategoryPlot categoryPlot58 = new org.jfree.chart.plot.CategoryPlot();
        float float59 = categoryPlot58.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation60 = categoryPlot58.getRangeAxisLocation();
        xYPlot54.setDomainAxisLocation((int) (byte) 0, axisLocation60, true);
        boolean boolean63 = xYPlot54.isRangeZoomable();
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = xYPlot54.getDomainAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = null;
        try {
            org.jfree.chart.axis.AxisState axisState66 = numberAxis3D1.draw(graphics2D2, (double) (byte) 100, rectangle2D10, rectangle2D32, rectangleEdge64, plotRenderingInfo65);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertNotNull(blockContainer17);
        org.junit.Assert.assertNotNull(arrangement18);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNotNull(horizontalAlignment23);
        org.junit.Assert.assertNull(obj25);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.18d + "'", double41 == 0.18d);
        org.junit.Assert.assertTrue("'" + float59 + "' != '" + 1.0f + "'", float59 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation60);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(rectangleEdge64);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        xYPlot21.zoomRangeAxes((double) ' ', plotRenderingInfo23, point2D24);
        java.awt.Paint paint26 = xYPlot21.getDomainTickBandPaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent27 = null;
        xYPlot21.rendererChanged(rendererChangeEvent27);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray29 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot21.setRenderers(xYItemRendererArray29);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = xYPlot21.getDomainAxisEdge((-1));
        boolean boolean33 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge32);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertNull(paint26);
        org.junit.Assert.assertNotNull(xYItemRendererArray29);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        int int3 = java.awt.Color.HSBtoRGB((float) 1L, (float) 1, 100.0f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-6553600) + "'", int3 == (-6553600));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = null;
        dateAxis1.setStandardTickUnits(tickUnitSource2);
        dateAxis1.setFixedAutoRange((double) 100L);
        org.jfree.chart.axis.Timeline timeline6 = dateAxis1.getTimeline();
        java.util.Date date7 = dateAxis1.getMaximumDate();
        org.junit.Assert.assertNotNull(timeline6);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.ui.ProjectInfo projectInfo3 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str4 = projectInfo3.toString();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo10 = new org.jfree.chart.ui.BasicProjectInfo("", "java.awt.Color[r=255,g=255,b=64]", "", "java.awt.Color[r=255,g=255,b=64]", "java.awt.Color[r=255,g=255,b=64]");
        projectInfo3.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo10);
        java.awt.Image image12 = projectInfo3.getLogo();
        org.jfree.chart.ui.ProjectInfo projectInfo16 = new org.jfree.chart.ui.ProjectInfo("Polar Plot", "ClassContext", "Polar Plot", image12, "java.awt.Color[r=255,g=255,b=64]", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "ClassContext");
        org.junit.Assert.assertNotNull(projectInfo3);
        org.junit.Assert.assertNotNull(image12);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        dateAxis2.setLabelAngle((double) (byte) 1);
        dateAxis2.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int10 = color9.getAlpha();
        java.lang.String str11 = color9.toString();
        dateAxis2.setTickMarkPaint((java.awt.Paint) color9);
        org.jfree.data.Range range13 = dateAxis2.getDefaultAutoRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 100, 0.4d);
        org.jfree.data.time.DateRange dateRange18 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = new org.jfree.chart.block.RectangleConstraint((double) '#', (org.jfree.data.Range) dateRange18);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = rectangleConstraint16.toRangeHeight((org.jfree.data.Range) dateRange18);
        dateAxis2.setRange((org.jfree.data.Range) dateRange18, true, true);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 255 + "'", int10 == 255);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str11.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNotNull(dateRange18);
        org.junit.Assert.assertNotNull(rectangleConstraint20);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) dateAxis5, polarItemRenderer6);
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = piePlot8.getSimpleLabelOffset();
        double double10 = rectangleInsets9.getRight();
        dateAxis5.setLabelInsets(rectangleInsets9);
        dateAxis5.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("");
        dateAxis16.setRange((double) 0.0f, (double) 10.0f);
        dateAxis16.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) dateAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis16, xYItemRenderer22);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        xYPlot23.zoomRangeAxes((double) ' ', plotRenderingInfo25, point2D26);
        java.awt.Paint paint28 = xYPlot23.getDomainTickBandPaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent29 = null;
        xYPlot23.rendererChanged(rendererChangeEvent29);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray31 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot23.setRenderers(xYItemRendererArray31);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder33 = xYPlot23.getDatasetRenderingOrder();
        categoryPlot0.setDatasetRenderingOrder(datasetRenderingOrder33);
        java.awt.Stroke stroke35 = categoryPlot0.getDomainGridlineStroke();
        org.jfree.chart.axis.ValueAxis valueAxis36 = categoryPlot0.getRangeAxis();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.18d + "'", double10 == 0.18d);
        org.junit.Assert.assertNull(paint28);
        org.junit.Assert.assertNotNull(xYItemRendererArray31);
        org.junit.Assert.assertNotNull(datasetRenderingOrder33);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNull(valueAxis36);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        dateAxis2.setLabelAngle((double) (byte) 1);
        dateAxis2.setTickMarkOutsideLength((-1.0f));
        dateAxis2.setFixedDimension(0.4d);
        double double11 = dateAxis2.getUpperBound();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("");
        java.util.Date date14 = dateAxis13.getMaximumDate();
        dateAxis2.setMaximumDate(date14);
        java.lang.Object obj16 = dateAxis2.clone();
        boolean boolean17 = dateAxis2.isInverted();
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis((int) '4', valueAxis3, false);
        org.jfree.chart.axis.AxisLocation axisLocation6 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot0.getRangeAxisEdge((int) (byte) 0);
        java.awt.Stroke stroke9 = categoryPlot0.getDomainGridlineStroke();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        java.lang.String str1 = plotOrientation0.toString();
        java.lang.String str2 = plotOrientation0.toString();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        float float4 = categoryPlot3.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot3.getRangeAxisLocation();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = categoryPlot3.getRenderer();
        java.lang.String str7 = categoryPlot3.getPlotType();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer12 = null;
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) dateAxis11, polarItemRenderer12);
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot13);
        java.awt.geom.Rectangle2D rectangle2D15 = legendTitle14.getBounds();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        boolean boolean18 = categoryPlot3.render(graphics2D8, rectangle2D15, (int) (byte) 1, plotRenderingInfo17);
        java.awt.Stroke stroke19 = categoryPlot3.getRangeGridlineStroke();
        java.awt.Paint paint20 = categoryPlot3.getRangeCrosshairPaint();
        boolean boolean21 = plotOrientation0.equals((java.lang.Object) paint20);
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PlotOrientation.VERTICAL" + "'", str1.equals("PlotOrientation.VERTICAL"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PlotOrientation.VERTICAL" + "'", str2.equals("PlotOrientation.VERTICAL"));
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNull(categoryItemRenderer6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Category Plot" + "'", str7.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        float[] floatArray7 = new float[] { (-1.0f), 10, (short) 0, '#' };
        float[] floatArray8 = color2.getRGBComponents(floatArray7);
        paintMap0.put((java.lang.Comparable) 0.14d, (java.awt.Paint) color2);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "org.jfree.chart.event.ChartProgressEvent[source=[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]]" + "'", str0.equals("org.jfree.chart.event.ChartProgressEvent[source=[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]]"));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        java.awt.Color color0 = java.awt.Color.GRAY;
        int int1 = color0.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 128 + "'", int1 == 128);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        java.awt.Color color0 = java.awt.Color.cyan;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis((int) '4', valueAxis3, false);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.plot.Plot plot7 = categoryPlot0.getParent();
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer12 = null;
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) dateAxis11, polarItemRenderer12);
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = piePlot14.getSimpleLabelOffset();
        double double16 = rectangleInsets15.getRight();
        dateAxis11.setLabelInsets(rectangleInsets15);
        dateAxis11.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("");
        dateAxis22.setRange((double) 0.0f, (double) 10.0f);
        dateAxis22.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset8, (org.jfree.chart.axis.ValueAxis) dateAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis22, xYItemRenderer28);
        xYPlot29.clearDomainMarkers(15);
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer35 = null;
        org.jfree.chart.plot.PolarPlot polarPlot36 = new org.jfree.chart.plot.PolarPlot(xYDataset32, (org.jfree.chart.axis.ValueAxis) dateAxis34, polarItemRenderer35);
        dateAxis34.setLabelAngle((double) (byte) 1);
        dateAxis34.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color41 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int42 = color41.getAlpha();
        dateAxis34.setTickLabelPaint((java.awt.Paint) color41);
        dateAxis34.setInverted(false);
        double double46 = dateAxis34.getLowerBound();
        org.jfree.data.Range range47 = xYPlot29.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis34);
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis34);
        boolean boolean49 = categoryPlot0.getDrawSharedDomainAxis();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.18d + "'", double16 == 0.18d);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 255 + "'", int42 == 255);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNull(range47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        int int5 = polarPlot4.getBackgroundImageAlignment();
        boolean boolean6 = polarPlot4.isSubplot();
        polarPlot4.setBackgroundImageAlignment(0);
        org.jfree.chart.axis.ValueAxis valueAxis9 = polarPlot4.getAxis();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(valueAxis9);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.clearDomainMarkers(15);
        org.jfree.chart.LegendItemCollection legendItemCollection24 = xYPlot21.getFixedLegendItems();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = xYPlot21.getAxisOffset();
        boolean boolean26 = xYPlot21.isRangeZoomable();
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        float float29 = categoryPlot28.getForegroundAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        categoryPlot28.setRangeAxis((int) '4', valueAxis31, false);
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot28.getRangeAxisLocation();
        xYPlot21.setDomainAxisLocation(3, axisLocation34, true);
        xYPlot21.setDomainCrosshairVisible(false);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertNull(legendItemCollection24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 1.0f + "'", float29 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation34);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        org.jfree.data.time.DateRange dateRange5 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double6 = dateRange5.getUpperBound();
        dateAxis2.setRange((org.jfree.data.Range) dateRange5);
        dateAxis2.setRangeAboutValue(0.5d, (double) 10.0f);
        org.junit.Assert.assertNotNull(dateRange5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(false);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
        java.lang.String str1 = licences0.getGPL();
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        java.awt.Font font4 = null;
        java.awt.Paint paint5 = null;
        org.jfree.chart.text.TextBlock textBlock6 = org.jfree.chart.text.TextUtilities.createTextBlock("", font4, paint5);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = textBlock6.getLineAlignment();
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.Font font12 = null;
        java.awt.Paint paint13 = null;
        org.jfree.chart.text.TextBlock textBlock14 = org.jfree.chart.text.TextUtilities.createTextBlock("", font12, paint13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor18 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        java.awt.Shape shape22 = textBlock14.calculateBounds(graphics2D15, 0.0f, (float) (short) 0, textBlockAnchor18, (float) (byte) 10, (float) 15, (double) 0L);
        textBlock6.draw(graphics2D8, 0.0f, (float) (byte) 10, textBlockAnchor18);
        org.jfree.chart.text.TextLine textLine24 = textBlock6.getLastLine();
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer29 = null;
        org.jfree.chart.plot.PolarPlot polarPlot30 = new org.jfree.chart.plot.PolarPlot(xYDataset26, (org.jfree.chart.axis.ValueAxis) dateAxis28, polarItemRenderer29);
        dateAxis28.setLabelAngle((double) (byte) 1);
        java.awt.Font font33 = dateAxis28.getTickLabelFont();
        org.jfree.chart.text.TextLine textLine34 = new org.jfree.chart.text.TextLine("", font33);
        textBlock6.addLine(textLine34);
        org.jfree.chart.text.TextFragment textFragment36 = textLine34.getLastTextFragment();
        java.awt.Color color37 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        float[] floatArray42 = new float[] { (-1.0f), 10, (short) 0, '#' };
        float[] floatArray43 = color37.getRGBComponents(floatArray42);
        boolean boolean44 = textFragment36.equals((java.lang.Object) floatArray42);
        float[] floatArray45 = java.awt.Color.RGBtoHSB((int) (short) 1, (int) '4', (int) (short) 0, floatArray42);
        org.junit.Assert.assertNotNull(textBlock6);
        org.junit.Assert.assertNotNull(horizontalAlignment7);
        org.junit.Assert.assertNotNull(textBlock14);
        org.junit.Assert.assertNotNull(textBlockAnchor18);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNull(textLine24);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertNotNull(textFragment36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(floatArray42);
        org.junit.Assert.assertNotNull(floatArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(floatArray45);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = piePlot1.getSimpleLabelOffset();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        piePlot1.markerChanged(markerChangeEvent3);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setLabelBackgroundPaint((java.awt.Paint) color5);
        java.awt.Color color7 = java.awt.Color.getColor("PlotOrientation.VERTICAL", color5);
        java.awt.color.ColorSpace colorSpace8 = color7.getColorSpace();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(colorSpace8);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getStartAngle();
        int int2 = ringPlot0.getPieIndex();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 90.0d + "'", double1 == 90.0d);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.clearDomainMarkers(15);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer27 = null;
        org.jfree.chart.plot.PolarPlot polarPlot28 = new org.jfree.chart.plot.PolarPlot(xYDataset24, (org.jfree.chart.axis.ValueAxis) dateAxis26, polarItemRenderer27);
        dateAxis26.setLabelAngle((double) (byte) 1);
        dateAxis26.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color33 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int34 = color33.getAlpha();
        dateAxis26.setTickLabelPaint((java.awt.Paint) color33);
        dateAxis26.setInverted(false);
        double double38 = dateAxis26.getLowerBound();
        org.jfree.data.Range range39 = xYPlot21.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis26);
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = xYPlot21.getRangeAxisEdge();
        java.util.List list41 = xYPlot21.getAnnotations();
        org.jfree.chart.plot.PlotOrientation plotOrientation42 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        java.lang.String str43 = plotOrientation42.toString();
        java.lang.String str44 = plotOrientation42.toString();
        xYPlot21.setOrientation(plotOrientation42);
        boolean boolean46 = xYPlot21.isRangeCrosshairVisible();
        xYPlot21.setRangeCrosshairVisible(false);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 255 + "'", int34 == 255);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNull(range39);
        org.junit.Assert.assertNotNull(rectangleEdge40);
        org.junit.Assert.assertNotNull(list41);
        org.junit.Assert.assertNotNull(plotOrientation42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "PlotOrientation.VERTICAL" + "'", str43.equals("PlotOrientation.VERTICAL"));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "PlotOrientation.VERTICAL" + "'", str44.equals("PlotOrientation.VERTICAL"));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setInnerSeparatorExtension((double) '#');
        org.jfree.chart.util.Rotation rotation3 = ringPlot0.getDirection();
        ringPlot0.setIgnoreZeroValues(true);
        java.awt.Paint paint6 = ringPlot0.getSeparatorPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean9 = categoryPlot8.isDomainGridlinesVisible();
        boolean boolean10 = categoryPlot8.isDomainGridlinesVisible();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        boolean boolean15 = categoryPlot8.render(graphics2D11, rectangle2D12, (int) (byte) 10, plotRenderingInfo14);
        org.jfree.data.category.CategoryDataset categoryDataset17 = categoryPlot8.getDataset((int) ' ');
        org.jfree.chart.util.SortOrder sortOrder18 = categoryPlot8.getRowRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("ClassContext", (org.jfree.chart.plot.Plot) categoryPlot8);
        java.awt.Stroke stroke20 = jFreeChart19.getBorderStroke();
        ringPlot0.setSeparatorStroke(stroke20);
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(categoryDataset17);
        org.junit.Assert.assertNotNull(sortOrder18);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = null;
        org.jfree.chart.text.TextBlock textBlock3 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint2);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = textBlock3.getLineAlignment();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.Font font9 = null;
        java.awt.Paint paint10 = null;
        org.jfree.chart.text.TextBlock textBlock11 = org.jfree.chart.text.TextUtilities.createTextBlock("", font9, paint10);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor15 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        java.awt.Shape shape19 = textBlock11.calculateBounds(graphics2D12, 0.0f, (float) (short) 0, textBlockAnchor15, (float) (byte) 10, (float) 15, (double) 0L);
        textBlock3.draw(graphics2D5, 0.0f, (float) (byte) 10, textBlockAnchor15);
        org.jfree.chart.text.TextLine textLine21 = textBlock3.getLastLine();
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer26 = null;
        org.jfree.chart.plot.PolarPlot polarPlot27 = new org.jfree.chart.plot.PolarPlot(xYDataset23, (org.jfree.chart.axis.ValueAxis) dateAxis25, polarItemRenderer26);
        dateAxis25.setLabelAngle((double) (byte) 1);
        java.awt.Font font30 = dateAxis25.getTickLabelFont();
        org.jfree.chart.text.TextLine textLine31 = new org.jfree.chart.text.TextLine("", font30);
        textBlock3.addLine(textLine31);
        org.jfree.chart.text.TextFragment textFragment33 = textLine31.getLastTextFragment();
        java.awt.Color color34 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        float[] floatArray39 = new float[] { (-1.0f), 10, (short) 0, '#' };
        float[] floatArray40 = color34.getRGBComponents(floatArray39);
        boolean boolean41 = textFragment33.equals((java.lang.Object) floatArray39);
        java.awt.Paint paint42 = textFragment33.getPaint();
        org.junit.Assert.assertNotNull(textBlock3);
        org.junit.Assert.assertNotNull(horizontalAlignment4);
        org.junit.Assert.assertNotNull(textBlock11);
        org.junit.Assert.assertNotNull(textBlockAnchor15);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNull(textLine21);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNotNull(textFragment33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(floatArray39);
        org.junit.Assert.assertNotNull(floatArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(paint42);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        int int5 = polarPlot4.getBackgroundImageAlignment();
        boolean boolean6 = polarPlot4.isSubplot();
        boolean boolean7 = polarPlot4.isDomainZoomable();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        polarPlot4.zoomRangeAxes((double) 0.0f, plotRenderingInfo9, point2D10);
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer15 = null;
        org.jfree.chart.plot.PolarPlot polarPlot16 = new org.jfree.chart.plot.PolarPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) dateAxis14, polarItemRenderer15);
        dateAxis14.setLabelAngle((double) (byte) 1);
        dateAxis14.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int22 = color21.getAlpha();
        java.lang.String str23 = color21.toString();
        dateAxis14.setTickMarkPaint((java.awt.Paint) color21);
        polarPlot4.setAngleGridlinePaint((java.awt.Paint) color21);
        java.awt.Font font27 = null;
        java.awt.Paint paint28 = null;
        org.jfree.chart.text.TextBlock textBlock29 = org.jfree.chart.text.TextUtilities.createTextBlock("", font27, paint28);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment30 = textBlock29.getLineAlignment();
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.Font font35 = null;
        java.awt.Paint paint36 = null;
        org.jfree.chart.text.TextBlock textBlock37 = org.jfree.chart.text.TextUtilities.createTextBlock("", font35, paint36);
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor41 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        java.awt.Shape shape45 = textBlock37.calculateBounds(graphics2D38, 0.0f, (float) (short) 0, textBlockAnchor41, (float) (byte) 10, (float) 15, (double) 0L);
        textBlock29.draw(graphics2D31, 0.0f, (float) (byte) 10, textBlockAnchor41);
        org.jfree.chart.text.TextLine textLine47 = textBlock29.getLastLine();
        org.jfree.data.xy.XYDataset xYDataset49 = null;
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer52 = null;
        org.jfree.chart.plot.PolarPlot polarPlot53 = new org.jfree.chart.plot.PolarPlot(xYDataset49, (org.jfree.chart.axis.ValueAxis) dateAxis51, polarItemRenderer52);
        dateAxis51.setLabelAngle((double) (byte) 1);
        java.awt.Font font56 = dateAxis51.getTickLabelFont();
        org.jfree.chart.text.TextLine textLine57 = new org.jfree.chart.text.TextLine("", font56);
        textBlock29.addLine(textLine57);
        org.jfree.chart.text.TextFragment textFragment59 = textLine57.getLastTextFragment();
        java.awt.Color color60 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        float[] floatArray65 = new float[] { (-1.0f), 10, (short) 0, '#' };
        float[] floatArray66 = color60.getRGBComponents(floatArray65);
        boolean boolean67 = textFragment59.equals((java.lang.Object) floatArray65);
        float[] floatArray68 = color21.getRGBComponents(floatArray65);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 255 + "'", int22 == 255);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str23.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(textBlock29);
        org.junit.Assert.assertNotNull(horizontalAlignment30);
        org.junit.Assert.assertNotNull(textBlock37);
        org.junit.Assert.assertNotNull(textBlockAnchor41);
        org.junit.Assert.assertNotNull(shape45);
        org.junit.Assert.assertNull(textLine47);
        org.junit.Assert.assertNotNull(font56);
        org.junit.Assert.assertNotNull(textFragment59);
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertNotNull(floatArray65);
        org.junit.Assert.assertNotNull(floatArray66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(floatArray68);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("java.awt.Color[r=255,g=255,b=64]", "hi!", "", "java.awt.Color[r=255,g=255,b=64]");
        java.lang.String str5 = basicProjectInfo4.getCopyright();
        basicProjectInfo4.setLicenceName("PlotOrientation.VERTICAL");
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = null;
        org.jfree.chart.text.TextBlock textBlock3 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint2);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.util.Size2D size2D5 = textBlock3.calculateDimensions(graphics2D4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor9 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        textBlock3.draw(graphics2D6, (float) 128, (float) ' ', textBlockAnchor9);
        org.junit.Assert.assertNotNull(textBlock3);
        org.junit.Assert.assertNotNull(size2D5);
        org.junit.Assert.assertNotNull(textBlockAnchor9);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        java.awt.Paint paint1 = waferMapPlot0.getBackgroundPaint();
        java.awt.Paint paint2 = waferMapPlot0.getOutlinePaint();
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer3 = null;
        waferMapPlot0.setRenderer(waferMapRenderer3);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        float float0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.5f + "'", float0 == 0.5f);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        java.util.List list2 = categoryPlot0.getAnnotations();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        float float4 = categoryPlot3.getForegroundAlpha();
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) dateAxis8, polarItemRenderer9);
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = piePlot11.getSimpleLabelOffset();
        double double13 = rectangleInsets12.getRight();
        dateAxis8.setLabelInsets(rectangleInsets12);
        dateAxis8.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("");
        dateAxis19.setRange((double) 0.0f, (double) 10.0f);
        dateAxis19.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) dateAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis19, xYItemRenderer25);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Point2D point2D29 = null;
        xYPlot26.zoomRangeAxes((double) ' ', plotRenderingInfo28, point2D29);
        java.awt.Paint paint31 = xYPlot26.getDomainTickBandPaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent32 = null;
        xYPlot26.rendererChanged(rendererChangeEvent32);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray34 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot26.setRenderers(xYItemRendererArray34);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder36 = xYPlot26.getDatasetRenderingOrder();
        categoryPlot3.setDatasetRenderingOrder(datasetRenderingOrder36);
        categoryPlot0.setDatasetRenderingOrder(datasetRenderingOrder36);
        int int39 = categoryPlot0.getDomainAxisCount();
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource42 = null;
        dateAxis41.setStandardTickUnits(tickUnitSource42);
        dateAxis41.setFixedAutoRange((double) 100L);
        java.awt.Font font46 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        dateAxis41.setLabelFont(font46);
        int int48 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis41);
        try {
            dateAxis41.zoomRange((double) 100.0f, (double) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (100.0) <= upper (-1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.18d + "'", double13 == 0.18d);
        org.junit.Assert.assertNull(paint31);
        org.junit.Assert.assertNotNull(xYItemRendererArray34);
        org.junit.Assert.assertNotNull(datasetRenderingOrder36);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertNotNull(font46);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        java.awt.Color color5 = java.awt.Color.GRAY;
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) dateAxis9, polarItemRenderer10);
        dateAxis9.setLabelAngle((double) (byte) 1);
        dateAxis9.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int17 = color16.getAlpha();
        java.lang.String str18 = color16.toString();
        dateAxis9.setTickMarkPaint((java.awt.Paint) color16);
        org.jfree.chart.plot.PiePlot piePlot20 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = piePlot20.getSimpleLabelOffset();
        java.awt.Stroke stroke22 = piePlot20.getLabelOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, (java.awt.Paint) color16, stroke22);
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((-1.0d), (java.awt.Paint) color5, stroke22);
        java.awt.Color color25 = java.awt.Color.WHITE;
        java.awt.Color color26 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        float[] floatArray31 = new float[] { (-1.0f), 10, (short) 0, '#' };
        float[] floatArray32 = color26.getRGBComponents(floatArray31);
        float[] floatArray33 = color25.getColorComponents(floatArray31);
        float[] floatArray34 = color5.getComponents(floatArray33);
        org.jfree.chart.block.BlockBorder blockBorder35 = new org.jfree.chart.block.BlockBorder(1.5d, 0.4d, 0.025d, (double) 128, (java.awt.Paint) color5);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 255 + "'", int17 == 255);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str18.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray34);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.clearDomainMarkers(15);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        float float26 = categoryPlot25.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot25.getRangeAxisLocation();
        xYPlot21.setDomainAxisLocation((int) (byte) 0, axisLocation27, true);
        java.awt.Stroke stroke30 = xYPlot21.getRangeGridlineStroke();
        java.awt.Paint paint31 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot21.setDomainZeroBaselinePaint(paint31);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent33 = null;
        xYPlot21.notifyListeners(plotChangeEvent33);
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis("");
        dateAxis36.setRange((double) 0.0f, (double) 10.0f);
        dateAxis36.resizeRange((double) ' ');
        dateAxis36.setVerticalTickLabels(false);
        org.jfree.data.Range range44 = xYPlot21.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis36);
        java.util.List list45 = xYPlot21.getAnnotations();
        java.awt.Graphics2D graphics2D46 = null;
        org.jfree.chart.plot.PiePlot piePlot47 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = piePlot47.getSimpleLabelOffset();
        org.jfree.data.xy.XYDataset xYDataset49 = null;
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer52 = null;
        org.jfree.chart.plot.PolarPlot polarPlot53 = new org.jfree.chart.plot.PolarPlot(xYDataset49, (org.jfree.chart.axis.ValueAxis) dateAxis51, polarItemRenderer52);
        org.jfree.chart.title.LegendTitle legendTitle54 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot53);
        java.awt.geom.Rectangle2D rectangle2D55 = legendTitle54.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType56 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType57 = null;
        java.awt.geom.Rectangle2D rectangle2D58 = rectangleInsets48.createAdjustedRectangle(rectangle2D55, lengthAdjustmentType56, lengthAdjustmentType57);
        try {
            xYPlot21.drawBackground(graphics2D46, rectangle2D58);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 1.0f + "'", float26 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNull(range44);
        org.junit.Assert.assertNotNull(list45);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertNotNull(rectangle2D55);
        org.junit.Assert.assertNotNull(rectangle2D58);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        int int5 = polarPlot4.getBackgroundImageAlignment();
        boolean boolean6 = polarPlot4.isOutlineVisible();
        polarPlot4.setAngleGridlinesVisible(true);
        org.jfree.chart.plot.WaferMapPlot waferMapPlot9 = new org.jfree.chart.plot.WaferMapPlot();
        java.awt.Paint paint10 = waferMapPlot9.getBackgroundPaint();
        polarPlot4.setAngleLabelPaint(paint10);
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer15 = null;
        org.jfree.chart.plot.PolarPlot polarPlot16 = new org.jfree.chart.plot.PolarPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) dateAxis14, polarItemRenderer15);
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot16);
        polarPlot16.setBackgroundAlpha((float) (byte) 100);
        polarPlot4.setParent((org.jfree.chart.plot.Plot) polarPlot16);
        double double21 = polarPlot4.getMaxRadius();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        dateAxis3.setLabelAngle((double) (byte) 1);
        dateAxis3.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int11 = color10.getAlpha();
        dateAxis3.setTickLabelPaint((java.awt.Paint) color10);
        double double13 = dateAxis3.getFixedAutoRange();
        org.jfree.chart.axis.TickUnitSource tickUnitSource14 = dateAxis3.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("Size2D[width=0.0, height=0.0]");
        numberAxis16.setAutoRangeStickyZero(true);
        boolean boolean19 = numberAxis16.getAutoRangeStickyZero();
        boolean boolean20 = numberAxis16.isVisible();
        java.text.NumberFormat numberFormat21 = numberAxis16.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType22 = numberAxis16.getRangeType();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit23 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis16.setTickUnit(numberTickUnit23, true, false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis16, xYItemRenderer27);
        org.jfree.chart.util.Size2D size2D32 = new org.jfree.chart.util.Size2D((double) ' ', 0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor35 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.geom.Rectangle2D rectangle2D36 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D32, 0.0d, 10.0d, rectangleAnchor35);
        org.jfree.chart.title.TextTitle textTitle38 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = textTitle38.getPosition();
        double double40 = dateAxis3.valueToJava2D(0.0d, rectangle2D36, rectangleEdge39);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 255 + "'", int11 == 255);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNull(numberFormat21);
        org.junit.Assert.assertNotNull(rangeType22);
        org.junit.Assert.assertNotNull(numberTickUnit23);
        org.junit.Assert.assertNotNull(rectangleAnchor35);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertNotNull(rectangleEdge39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + (-16.0d) + "'", double40 == (-16.0d));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        java.lang.Object obj2 = null;
        boolean boolean3 = blockBorder1.equals(obj2);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = null;
        org.jfree.chart.text.TextBlock textBlock3 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint2);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = textBlock3.getLineAlignment();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.Font font9 = null;
        java.awt.Paint paint10 = null;
        org.jfree.chart.text.TextBlock textBlock11 = org.jfree.chart.text.TextUtilities.createTextBlock("", font9, paint10);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor15 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        java.awt.Shape shape19 = textBlock11.calculateBounds(graphics2D12, 0.0f, (float) (short) 0, textBlockAnchor15, (float) (byte) 10, (float) 15, (double) 0L);
        textBlock3.draw(graphics2D5, 0.0f, (float) (byte) 10, textBlockAnchor15);
        org.jfree.chart.text.TextLine textLine21 = textBlock3.getLastLine();
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer26 = null;
        org.jfree.chart.plot.PolarPlot polarPlot27 = new org.jfree.chart.plot.PolarPlot(xYDataset23, (org.jfree.chart.axis.ValueAxis) dateAxis25, polarItemRenderer26);
        dateAxis25.setLabelAngle((double) (byte) 1);
        java.awt.Font font30 = dateAxis25.getTickLabelFont();
        org.jfree.chart.text.TextLine textLine31 = new org.jfree.chart.text.TextLine("", font30);
        textBlock3.addLine(textLine31);
        org.jfree.chart.text.TextFragment textFragment33 = textLine31.getLastTextFragment();
        java.awt.Paint paint34 = textFragment33.getPaint();
        org.junit.Assert.assertNotNull(textBlock3);
        org.junit.Assert.assertNotNull(horizontalAlignment4);
        org.junit.Assert.assertNotNull(textBlock11);
        org.junit.Assert.assertNotNull(textBlockAnchor15);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNull(textLine21);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNotNull(textFragment33);
        org.junit.Assert.assertNotNull(paint34);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation();
        categoryPlot0.setRangeCrosshairValue(32.0d, false);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation2);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str1 = projectInfo0.toString();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo7 = new org.jfree.chart.ui.BasicProjectInfo("", "java.awt.Color[r=255,g=255,b=64]", "", "java.awt.Color[r=255,g=255,b=64]", "java.awt.Color[r=255,g=255,b=64]");
        projectInfo0.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo7);
        java.awt.Image image9 = projectInfo0.getLogo();
        java.awt.Image image10 = projectInfo0.getLogo();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(image9);
        org.junit.Assert.assertNotNull(image10);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("RectangleAnchor.BOTTOM_LEFT", graphics2D1, (float) (short) 1, (-1.0f), textAnchor4, (double) (-16777216), 100.0f, (float) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = categoryPlot0.getRenderer(255);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        categoryPlot0.setDataset(categoryDataset4);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        float float7 = categoryPlot6.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot6.getRangeAxisLocation();
        categoryPlot0.setDomainAxisLocation(axisLocation8, true);
        java.lang.Number[] numberArray20 = new java.lang.Number[] { 0.4d, 100.0f, 0L, 0.025d, (byte) 1, 1.0f };
        java.lang.Number[] numberArray27 = new java.lang.Number[] { 0.4d, 100.0f, 0L, 0.025d, (byte) 1, 1.0f };
        java.lang.Number[] numberArray34 = new java.lang.Number[] { 0.4d, 100.0f, 0L, 0.025d, (byte) 1, 1.0f };
        java.lang.Number[] numberArray41 = new java.lang.Number[] { 0.4d, 100.0f, 0L, 0.025d, (byte) 1, 1.0f };
        java.lang.Number[] numberArray48 = new java.lang.Number[] { 0.4d, 100.0f, 0L, 0.025d, (byte) 1, 1.0f };
        java.lang.Number[] numberArray55 = new java.lang.Number[] { 0.4d, 100.0f, 0L, 0.025d, (byte) 1, 1.0f };
        java.lang.Number[][] numberArray56 = new java.lang.Number[][] { numberArray20, numberArray27, numberArray34, numberArray41, numberArray48, numberArray55 };
        org.jfree.data.category.CategoryDataset categoryDataset57 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("PlotOrientation.VERTICAL", "hi!", numberArray56);
        try {
            categoryPlot0.setDataset((-6553600), categoryDataset57);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNull(categoryItemRenderer3);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray41);
        org.junit.Assert.assertNotNull(numberArray48);
        org.junit.Assert.assertNotNull(numberArray55);
        org.junit.Assert.assertNotNull(numberArray56);
        org.junit.Assert.assertNotNull(categoryDataset57);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) dateAxis5, polarItemRenderer6);
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = piePlot8.getSimpleLabelOffset();
        double double10 = rectangleInsets9.getRight();
        dateAxis5.setLabelInsets(rectangleInsets9);
        dateAxis5.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("");
        dateAxis16.setRange((double) 0.0f, (double) 10.0f);
        dateAxis16.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) dateAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis16, xYItemRenderer22);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        xYPlot23.zoomRangeAxes((double) ' ', plotRenderingInfo25, point2D26);
        java.awt.Paint paint28 = xYPlot23.getDomainTickBandPaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent29 = null;
        xYPlot23.rendererChanged(rendererChangeEvent29);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray31 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot23.setRenderers(xYItemRendererArray31);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder33 = xYPlot23.getDatasetRenderingOrder();
        categoryPlot0.setDatasetRenderingOrder(datasetRenderingOrder33);
        java.awt.Stroke stroke35 = categoryPlot0.getDomainGridlineStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = null;
        try {
            int int37 = categoryPlot0.getDomainAxisIndex(categoryAxis36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.18d + "'", double10 == 0.18d);
        org.junit.Assert.assertNull(paint28);
        org.junit.Assert.assertNotNull(xYItemRendererArray31);
        org.junit.Assert.assertNotNull(datasetRenderingOrder33);
        org.junit.Assert.assertNotNull(stroke35);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        ringPlot1.setInnerSeparatorExtension((double) '#');
        org.jfree.chart.util.Rotation rotation4 = ringPlot1.getDirection();
        double double5 = ringPlot1.getShadowXOffset();
        double double6 = ringPlot1.getInnerSeparatorExtension();
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = piePlot9.getSimpleLabelOffset();
        java.awt.Stroke stroke11 = piePlot9.getLabelOutlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        org.jfree.chart.plot.PiePlotState piePlotState14 = ringPlot1.initialise(graphics2D7, rectangle2D8, piePlot9, (java.lang.Integer) 100, plotRenderingInfo13);
        boolean boolean15 = piePlot9.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("RectangleEdge.LEFT", (org.jfree.chart.plot.Plot) piePlot9);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer21 = null;
        org.jfree.chart.plot.PolarPlot polarPlot22 = new org.jfree.chart.plot.PolarPlot(xYDataset18, (org.jfree.chart.axis.ValueAxis) dateAxis20, polarItemRenderer21);
        org.jfree.chart.title.LegendTitle legendTitle23 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot22);
        java.awt.geom.Rectangle2D rectangle2D24 = legendTitle23.getBounds();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo25 = null;
        try {
            jFreeChart16.draw(graphics2D17, rectangle2D24, chartRenderingInfo25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rotation4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 35.0d + "'", double6 == 35.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(piePlotState14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(rectangle2D24);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("ClassContext");
        numberAxis3D1.setAutoRange(true);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer11 = null;
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot(xYDataset8, (org.jfree.chart.axis.ValueAxis) dateAxis10, polarItemRenderer11);
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot12);
        java.awt.geom.Rectangle2D rectangle2D14 = legendTitle13.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType15 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = rectangleInsets7.createAdjustedRectangle(rectangle2D14, lengthAdjustmentType15, lengthAdjustmentType16);
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("hi!");
        java.lang.String str20 = textTitle19.getToolTipText();
        java.awt.geom.Rectangle2D rectangle2D21 = textTitle19.getBounds();
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        float float23 = categoryPlot22.getForegroundAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        categoryPlot22.setRangeAxis((int) '4', valueAxis25, false);
        org.jfree.chart.axis.AxisLocation axisLocation28 = categoryPlot22.getRangeAxisLocation();
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = categoryPlot22.getRangeAxisEdge((int) (byte) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        try {
            org.jfree.chart.axis.AxisState axisState32 = numberAxis3D1.draw(graphics2D4, (double) 10, rectangle2D17, rectangle2D21, rectangleEdge30, plotRenderingInfo31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 1.0f + "'", float23 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNotNull(rectangleEdge30);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int2 = color1.getAlpha();
        java.lang.String str3 = color1.toString();
        piePlot0.setLabelPaint((java.awt.Paint) color1);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator5 = piePlot0.getLabelGenerator();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent6 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot0);
        piePlot0.setStartAngle(1.0E-8d);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 255 + "'", int2 == 255);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str3.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator5);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        java.lang.Number[] numberArray8 = new java.lang.Number[] { 0.4d, 100.0f, 0L, 0.025d, (byte) 1, 1.0f };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 0.4d, 100.0f, 0L, 0.025d, (byte) 1, 1.0f };
        java.lang.Number[] numberArray22 = new java.lang.Number[] { 0.4d, 100.0f, 0L, 0.025d, (byte) 1, 1.0f };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { 0.4d, 100.0f, 0L, 0.025d, (byte) 1, 1.0f };
        java.lang.Number[] numberArray36 = new java.lang.Number[] { 0.4d, 100.0f, 0L, 0.025d, (byte) 1, 1.0f };
        java.lang.Number[] numberArray43 = new java.lang.Number[] { 0.4d, 100.0f, 0L, 0.025d, (byte) 1, 1.0f };
        java.lang.Number[][] numberArray44 = new java.lang.Number[][] { numberArray8, numberArray15, numberArray22, numberArray29, numberArray36, numberArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("PlotOrientation.VERTICAL", "hi!", numberArray44);
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = null;
        org.jfree.chart.axis.NumberAxis numberAxis48 = new org.jfree.chart.axis.NumberAxis("Size2D[width=0.0, height=0.0]");
        numberAxis48.setAutoRangeStickyZero(true);
        boolean boolean51 = numberAxis48.getAutoRangeStickyZero();
        boolean boolean52 = numberAxis48.isVisible();
        java.text.NumberFormat numberFormat53 = numberAxis48.getNumberFormatOverride();
        numberAxis48.setAutoRangeIncludesZero(true);
        java.lang.String str56 = numberAxis48.getLabelToolTip();
        java.text.NumberFormat numberFormat57 = null;
        numberAxis48.setNumberFormatOverride(numberFormat57);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer59 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot(categoryDataset45, categoryAxis46, (org.jfree.chart.axis.ValueAxis) numberAxis48, categoryItemRenderer59);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent61 = null;
        categoryPlot60.datasetChanged(datasetChangeEvent61);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray36);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNull(numberFormat53);
        org.junit.Assert.assertNull(str56);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = piePlot0.getSimpleLabelOffset();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        piePlot0.markerChanged(markerChangeEvent2);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator4 = null;
        piePlot0.setToolTipGenerator(pieToolTipGenerator4);
        org.junit.Assert.assertNotNull(rectangleInsets1);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        dateAxis3.setLabelAngle((double) (byte) 1);
        dateAxis3.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int11 = color10.getAlpha();
        dateAxis3.setTickLabelPaint((java.awt.Paint) color10);
        double double13 = dateAxis3.getFixedAutoRange();
        org.jfree.data.Range range14 = dateAxis3.getDefaultAutoRange();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, valueAxis15, xYItemRenderer16);
        org.jfree.chart.util.Layer layer19 = null;
        java.util.Collection collection20 = xYPlot17.getRangeMarkers((int) (byte) 0, layer19);
        xYPlot17.configureRangeAxes();
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 255 + "'", int11 == 255);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNull(collection20);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        java.lang.Comparable comparable4 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 255, (-16056329), comparable4, "java.awt.Color[r=255,g=255,b=64]", "ClassContext");
        java.lang.Comparable comparable8 = pieSectionEntity7.getSectionKey();
        java.lang.String str9 = pieSectionEntity7.getShapeCoords();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNull(comparable8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0" + "'", str9.equals("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot4);
        org.jfree.chart.block.BlockContainer blockContainer6 = legendTitle5.getItemContainer();
        org.jfree.chart.block.Arrangement arrangement7 = blockContainer6.getArrangement();
        org.jfree.chart.block.BlockContainer blockContainer8 = new org.jfree.chart.block.BlockContainer(arrangement7);
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("hi!");
        java.lang.String str11 = textTitle10.getToolTipText();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = textTitle10.getHorizontalAlignment();
        blockContainer8.add((org.jfree.chart.block.Block) textTitle10);
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer18 = null;
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) dateAxis17, polarItemRenderer18);
        org.jfree.chart.plot.PiePlot piePlot20 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = piePlot20.getSimpleLabelOffset();
        double double22 = rectangleInsets21.getRight();
        dateAxis17.setLabelInsets(rectangleInsets21);
        dateAxis17.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("");
        dateAxis28.setRange((double) 0.0f, (double) 10.0f);
        dateAxis28.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset14, (org.jfree.chart.axis.ValueAxis) dateAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis28, xYItemRenderer34);
        xYPlot35.clearDomainMarkers(15);
        org.jfree.data.xy.XYDataset xYDataset38 = null;
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer41 = null;
        org.jfree.chart.plot.PolarPlot polarPlot42 = new org.jfree.chart.plot.PolarPlot(xYDataset38, (org.jfree.chart.axis.ValueAxis) dateAxis40, polarItemRenderer41);
        dateAxis40.setLabelAngle((double) (byte) 1);
        dateAxis40.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color47 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int48 = color47.getAlpha();
        dateAxis40.setTickLabelPaint((java.awt.Paint) color47);
        dateAxis40.setInverted(false);
        double double52 = dateAxis40.getLowerBound();
        org.jfree.data.Range range53 = xYPlot35.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis40);
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = xYPlot35.getRangeAxisEdge();
        textTitle10.setPosition(rectangleEdge54);
        java.awt.Color color56 = java.awt.Color.WHITE;
        textTitle10.setPaint((java.awt.Paint) color56);
        org.junit.Assert.assertNotNull(blockContainer6);
        org.junit.Assert.assertNotNull(arrangement7);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(horizontalAlignment12);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.18d + "'", double22 == 0.18d);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 255 + "'", int48 == 255);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNull(range53);
        org.junit.Assert.assertNotNull(rectangleEdge54);
        org.junit.Assert.assertNotNull(color56);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        java.awt.Color color0 = java.awt.Color.red;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("RectangleAnchor.BOTTOM_LEFT", "", "RectangleInsets[t=0.18,l=0.18,b=0.18,r=0.18]", "hi!", "4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0");
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 100, 0.4d);
        org.jfree.data.time.DateRange dateRange11 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((double) '#', (org.jfree.data.Range) dateRange11);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint9.toRangeHeight((org.jfree.data.Range) dateRange11);
        org.jfree.chart.util.Size2D size2D14 = legendTitle5.arrange(graphics2D6, rectangleConstraint9);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer18 = null;
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) dateAxis17, polarItemRenderer18);
        dateAxis17.setLabelAngle((double) (byte) 1);
        java.awt.Font font22 = dateAxis17.getTickLabelFont();
        dateAxis17.setAutoTickUnitSelection(true);
        dateAxis17.setLabelAngle(0.18d);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = dateAxis17.getLabelInsets();
        legendTitle5.setPadding(rectangleInsets27);
        double double29 = rectangleInsets27.getRight();
        org.junit.Assert.assertNotNull(dateRange11);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(size2D14);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 3.0d + "'", double29 == 3.0d);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        try {
            java.lang.String[] strArray2 = jFreeChartResources0.getStringArray("RectangleAnchor.BOTTOM_LEFT");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key RectangleAnchor.BOTTOM_LEFT");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_START_ANGLE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 90.0d + "'", double0 == 90.0d);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.clearDomainMarkers(15);
        org.jfree.chart.LegendItemCollection legendItemCollection24 = xYPlot21.getFixedLegendItems();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = xYPlot21.getAxisOffset();
        org.jfree.chart.util.Layer layer26 = null;
        java.util.Collection collection27 = xYPlot21.getDomainMarkers(layer26);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertNull(legendItemCollection24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNull(collection27);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        java.awt.Stroke stroke22 = xYPlot21.getDomainZeroBaselineStroke();
        int int23 = xYPlot21.getWeight();
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer28 = null;
        org.jfree.chart.plot.PolarPlot polarPlot29 = new org.jfree.chart.plot.PolarPlot(xYDataset25, (org.jfree.chart.axis.ValueAxis) dateAxis27, polarItemRenderer28);
        dateAxis27.setLabelAngle((double) (byte) 1);
        java.awt.Font font32 = dateAxis27.getTickLabelFont();
        dateAxis27.setAutoTickUnitSelection(true);
        org.jfree.data.xy.XYDataset xYDataset35 = null;
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer38 = null;
        org.jfree.chart.plot.PolarPlot polarPlot39 = new org.jfree.chart.plot.PolarPlot(xYDataset35, (org.jfree.chart.axis.ValueAxis) dateAxis37, polarItemRenderer38);
        dateAxis37.setLabelAngle((double) (byte) 1);
        dateAxis37.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color44 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int45 = color44.getAlpha();
        dateAxis37.setTickLabelPaint((java.awt.Paint) color44);
        double double47 = dateAxis37.getFixedAutoRange();
        org.jfree.data.Range range48 = dateAxis37.getDefaultAutoRange();
        org.jfree.data.Range range51 = org.jfree.data.Range.expand(range48, (double) (-1), 0.0d);
        dateAxis27.setRange(range51);
        try {
            xYPlot21.setDomainAxis((-6553600), (org.jfree.chart.axis.ValueAxis) dateAxis27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 255 + "'", int45 == 255);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertNotNull(range51);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot4);
        java.lang.Object obj6 = legendTitle5.clone();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) dateAxis9, polarItemRenderer10);
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = piePlot12.getSimpleLabelOffset();
        double double14 = rectangleInsets13.getRight();
        dateAxis9.setLabelInsets(rectangleInsets13);
        legendTitle5.setLegendItemGraphicPadding(rectangleInsets13);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = legendTitle5.getLegendItemGraphicPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = legendTitle5.getMargin();
        java.awt.Paint paint19 = legendTitle5.getBackgroundPaint();
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.18d + "'", double14 == 0.18d);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNull(paint19);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot5);
        java.awt.Color color7 = java.awt.Color.green;
        java.awt.Color color8 = color7.darker();
        legendTitle6.setBackgroundPaint((java.awt.Paint) color7);
        java.lang.Class<?> wildcardClass10 = legendTitle6.getClass();
        java.io.InputStream inputStream11 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("java.awt.Color[r=255,g=255,b=64]", (java.lang.Class) wildcardClass10);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNull(inputStream11);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis((int) '4', valueAxis3, false);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent6);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        int int6 = polarPlot5.getBackgroundImageAlignment();
        boolean boolean7 = polarPlot5.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) polarPlot5);
        int int9 = jFreeChart8.getSubtitleCount();
        org.jfree.chart.title.LegendTitle legendTitle11 = jFreeChart8.getLegend((-1));
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = null;
        try {
            java.awt.image.BufferedImage bufferedImage15 = jFreeChart8.createBufferedImage((-6553600), 10, chartRenderingInfo14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (-6553600) and height (10) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNull(legendTitle11);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.util.Date date2 = dateAxis1.getMaximumDate();
        java.awt.Shape shape3 = dateAxis1.getRightArrow();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.clearDomainMarkers(15);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        xYPlot21.setDataset(xYDataset24);
        boolean boolean26 = xYPlot21.isDomainZeroBaselineVisible();
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str1 = projectInfo0.toString();
        projectInfo0.setLicenceName("Polar Plot");
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer8 = null;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) dateAxis7, polarItemRenderer8);
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = piePlot10.getSimpleLabelOffset();
        double double12 = rectangleInsets11.getRight();
        dateAxis7.setLabelInsets(rectangleInsets11);
        dateAxis7.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("");
        dateAxis18.setRange((double) 0.0f, (double) 10.0f);
        dateAxis18.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) dateAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis18, xYItemRenderer24);
        xYPlot25.clearDomainMarkers(15);
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer31 = null;
        org.jfree.chart.plot.PolarPlot polarPlot32 = new org.jfree.chart.plot.PolarPlot(xYDataset28, (org.jfree.chart.axis.ValueAxis) dateAxis30, polarItemRenderer31);
        dateAxis30.setLabelAngle((double) (byte) 1);
        dateAxis30.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color37 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int38 = color37.getAlpha();
        dateAxis30.setTickLabelPaint((java.awt.Paint) color37);
        dateAxis30.setInverted(false);
        double double42 = dateAxis30.getLowerBound();
        org.jfree.data.Range range43 = xYPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis30);
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = xYPlot25.getRangeAxisEdge();
        java.util.List list45 = xYPlot25.getAnnotations();
        projectInfo0.setContributors(list45);
        java.util.Collection collection47 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list45);
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.18d + "'", double12 == 0.18d);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 255 + "'", int38 == 255);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNull(range43);
        org.junit.Assert.assertNotNull(rectangleEdge44);
        org.junit.Assert.assertNotNull(list45);
        org.junit.Assert.assertNotNull(collection47);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", "ClassContext", "", "org.jfree.chart.event.ChartProgressEvent[source=[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]]");
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.calculateTopInset(23.4375d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "hi!");
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        dateAxis2.setLabelAngle((double) (byte) 1);
        dateAxis2.setAutoRangeMinimumSize((double) (byte) 10);
        org.jfree.chart.plot.Plot plot9 = dateAxis2.getPlot();
        java.awt.Shape shape10 = dateAxis2.getLeftArrow();
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        dateAxis2.setLabelAngle((double) (byte) 1);
        dateAxis2.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int10 = color9.getAlpha();
        dateAxis2.setTickLabelPaint((java.awt.Paint) color9);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean13 = categoryPlot12.isDomainGridlinesVisible();
        boolean boolean14 = categoryPlot12.isDomainGridlinesVisible();
        int int15 = categoryPlot12.getRangeAxisCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = categoryPlot12.getDomainAxis((int) (byte) 0);
        boolean boolean18 = dateAxis2.hasListener((java.util.EventListener) categoryPlot12);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        int int20 = categoryPlot12.getIndexOf(categoryItemRenderer19);
        org.jfree.chart.axis.AxisSpace axisSpace21 = categoryPlot12.getFixedDomainAxisSpace();
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 255 + "'", int10 == 255);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNull(categoryAxis17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNull(axisSpace21);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis((int) '4', valueAxis3, false);
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot0.setRangeAxisLocation(2, axisLocation7);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        double double0 = org.jfree.chart.plot.PolarPlot.DEFAULT_ANGLE_TICK_UNIT_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 45.0d + "'", double0 == 45.0d);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]");
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }
}

