import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        java.lang.Comparable[] comparableArray0 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray2 = new java.lang.Comparable[] { '#' };
        double[] doubleArray9 = new double[] { 4.0d, 0.5d, 10.0f, 1.0d, (short) -1, 100.0f };
        double[] doubleArray16 = new double[] { 4.0d, 0.5d, 10.0f, 1.0d, (short) -1, 100.0f };
        double[] doubleArray23 = new double[] { 4.0d, 0.5d, 10.0f, 1.0d, (short) -1, 100.0f };
        double[] doubleArray30 = new double[] { 4.0d, 0.5d, 10.0f, 1.0d, (short) -1, 100.0f };
        double[] doubleArray37 = new double[] { 4.0d, 0.5d, 10.0f, 1.0d, (short) -1, 100.0f };
        double[][] doubleArray38 = new double[][] { doubleArray9, doubleArray16, doubleArray23, doubleArray30, doubleArray37 };
        try {
            org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray0, comparableArray2, doubleArray38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of row keys does not match the number of rows in the data array.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray0);
        org.junit.Assert.assertNotNull(comparableArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = piePlot0.getSimpleLabelOffset();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        piePlot0.markerChanged(markerChangeEvent2);
        java.lang.Object obj4 = piePlot0.clone();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator5 = null;
        piePlot0.setToolTipGenerator(pieToolTipGenerator5);
        java.awt.Stroke stroke7 = piePlot0.getLabelLinkStroke();
        java.awt.Paint paint8 = piePlot0.getLabelLinkPaint();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.clearDomainMarkers(15);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer27 = null;
        org.jfree.chart.plot.PolarPlot polarPlot28 = new org.jfree.chart.plot.PolarPlot(xYDataset24, (org.jfree.chart.axis.ValueAxis) dateAxis26, polarItemRenderer27);
        dateAxis26.setLabelAngle((double) (byte) 1);
        dateAxis26.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color33 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int34 = color33.getAlpha();
        dateAxis26.setTickLabelPaint((java.awt.Paint) color33);
        dateAxis26.setInverted(false);
        double double38 = dateAxis26.getLowerBound();
        org.jfree.data.Range range39 = xYPlot21.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis26);
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = xYPlot21.getRangeAxisEdge();
        java.awt.Graphics2D graphics2D41 = null;
        org.jfree.chart.title.TextTitle textTitle43 = new org.jfree.chart.title.TextTitle("hi!");
        java.lang.String str44 = textTitle43.getToolTipText();
        java.awt.geom.Rectangle2D rectangle2D45 = textTitle43.getBounds();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = null;
        xYPlot21.drawAnnotations(graphics2D41, rectangle2D45, plotRenderingInfo46);
        int int48 = xYPlot21.getDomainAxisCount();
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 255 + "'", int34 == 255);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNull(range39);
        org.junit.Assert.assertNotNull(rectangleEdge40);
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        org.jfree.data.Range range5 = dateAxis2.getRange();
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent9 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) range5, jFreeChart6, 255, (int) (short) 10);
        int int10 = chartProgressEvent9.getType();
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 255 + "'", int10 == 255);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        dateAxis2.setLabelAngle((double) (byte) 1);
        dateAxis2.setTickMarkOutsideLength((-1.0f));
        dateAxis2.setFixedDimension(0.4d);
        double double11 = dateAxis2.getUpperBound();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("");
        java.util.Date date14 = dateAxis13.getMaximumDate();
        dateAxis2.setMaximumDate(date14);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = null;
        dateAxis17.setStandardTickUnits(tickUnitSource18);
        java.awt.Stroke stroke20 = dateAxis17.getTickMarkStroke();
        double double21 = dateAxis17.getUpperMargin();
        org.jfree.data.time.DateRange dateRange22 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis17.setRange((org.jfree.data.Range) dateRange22);
        dateAxis2.setRange((org.jfree.data.Range) dateRange22, false, false);
        double double27 = dateRange22.getLength();
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.05d + "'", double21 == 0.05d);
        org.junit.Assert.assertNotNull(dateRange22);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.0d + "'", double27 == 1.0d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.clearDomainMarkers(15);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer27 = null;
        org.jfree.chart.plot.PolarPlot polarPlot28 = new org.jfree.chart.plot.PolarPlot(xYDataset24, (org.jfree.chart.axis.ValueAxis) dateAxis26, polarItemRenderer27);
        dateAxis26.setLabelAngle((double) (byte) 1);
        dateAxis26.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color33 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int34 = color33.getAlpha();
        dateAxis26.setTickLabelPaint((java.awt.Paint) color33);
        dateAxis26.setInverted(false);
        double double38 = dateAxis26.getLowerBound();
        org.jfree.data.Range range39 = xYPlot21.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis26);
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = xYPlot21.getRangeAxisEdge();
        java.util.List list41 = xYPlot21.getAnnotations();
        org.jfree.chart.plot.PlotOrientation plotOrientation42 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        java.lang.String str43 = plotOrientation42.toString();
        java.lang.String str44 = plotOrientation42.toString();
        xYPlot21.setOrientation(plotOrientation42);
        boolean boolean46 = xYPlot21.isRangeCrosshairVisible();
        xYPlot21.setDomainCrosshairValue((double) 15);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 255 + "'", int34 == 255);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNull(range39);
        org.junit.Assert.assertNotNull(rectangleEdge40);
        org.junit.Assert.assertNotNull(list41);
        org.junit.Assert.assertNotNull(plotOrientation42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "PlotOrientation.VERTICAL" + "'", str43.equals("PlotOrientation.VERTICAL"));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "PlotOrientation.VERTICAL" + "'", str44.equals("PlotOrientation.VERTICAL"));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis((int) '4', valueAxis3, false);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.plot.Plot plot7 = categoryPlot0.getParent();
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer12 = null;
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) dateAxis11, polarItemRenderer12);
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = piePlot14.getSimpleLabelOffset();
        double double16 = rectangleInsets15.getRight();
        dateAxis11.setLabelInsets(rectangleInsets15);
        dateAxis11.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("");
        dateAxis22.setRange((double) 0.0f, (double) 10.0f);
        dateAxis22.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset8, (org.jfree.chart.axis.ValueAxis) dateAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis22, xYItemRenderer28);
        xYPlot29.clearDomainMarkers(15);
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer35 = null;
        org.jfree.chart.plot.PolarPlot polarPlot36 = new org.jfree.chart.plot.PolarPlot(xYDataset32, (org.jfree.chart.axis.ValueAxis) dateAxis34, polarItemRenderer35);
        dateAxis34.setLabelAngle((double) (byte) 1);
        dateAxis34.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color41 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int42 = color41.getAlpha();
        dateAxis34.setTickLabelPaint((java.awt.Paint) color41);
        dateAxis34.setInverted(false);
        double double46 = dateAxis34.getLowerBound();
        org.jfree.data.Range range47 = xYPlot29.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis34);
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis34);
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = categoryPlot0.getDomainAxis((-16777216));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.18d + "'", double16 == 0.18d);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 255 + "'", int42 == 255);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNull(range47);
        org.junit.Assert.assertNull(categoryAxis50);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0");
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        categoryPlot0.setForegroundAlpha((float) 1);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        categoryPlot0.drawBackgroundImage(graphics2D4, rectangle2D5);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D("ClassContext");
        numberAxis3D8.setLabel("RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]");
        java.awt.Color color12 = java.awt.Color.GRAY;
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer17 = null;
        org.jfree.chart.plot.PolarPlot polarPlot18 = new org.jfree.chart.plot.PolarPlot(xYDataset14, (org.jfree.chart.axis.ValueAxis) dateAxis16, polarItemRenderer17);
        dateAxis16.setLabelAngle((double) (byte) 1);
        dateAxis16.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color23 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int24 = color23.getAlpha();
        java.lang.String str25 = color23.toString();
        dateAxis16.setTickMarkPaint((java.awt.Paint) color23);
        org.jfree.chart.plot.PiePlot piePlot27 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = piePlot27.getSimpleLabelOffset();
        java.awt.Stroke stroke29 = piePlot27.getLabelOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, (java.awt.Paint) color23, stroke29);
        org.jfree.chart.plot.ValueMarker valueMarker31 = new org.jfree.chart.plot.ValueMarker((-1.0d), (java.awt.Paint) color12, stroke29);
        numberAxis3D8.setAxisLineStroke(stroke29);
        categoryPlot0.setRangeCrosshairStroke(stroke29);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 255 + "'", int24 == 255);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str25.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(stroke29);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        categoryPlot0.configureDomainAxes();
        boolean boolean3 = categoryPlot0.isRangeGridlinesVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.data.time.DateRange dateRange2 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = new org.jfree.chart.block.RectangleConstraint((double) '#', (org.jfree.data.Range) dateRange2);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = new org.jfree.chart.block.RectangleConstraint(10.0d, (org.jfree.data.Range) dateRange2);
        org.jfree.chart.util.Size2D size2D7 = new org.jfree.chart.util.Size2D((double) ' ', 0.0d);
        size2D7.height = ' ';
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer13 = null;
        org.jfree.chart.plot.PolarPlot polarPlot14 = new org.jfree.chart.plot.PolarPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) dateAxis12, polarItemRenderer13);
        org.jfree.data.Range range15 = dateAxis12.getRange();
        java.util.Date date16 = dateAxis12.getMinimumDate();
        boolean boolean17 = size2D7.equals((java.lang.Object) date16);
        org.jfree.chart.util.Size2D size2D18 = rectangleConstraint4.calculateConstrainedSize(size2D7);
        double double19 = size2D18.getWidth();
        org.junit.Assert.assertNotNull(dateRange2);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(size2D18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 10.0d + "'", double19 == 10.0d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.ui.ProjectInfo projectInfo3 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str4 = projectInfo3.toString();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo10 = new org.jfree.chart.ui.BasicProjectInfo("", "java.awt.Color[r=255,g=255,b=64]", "", "java.awt.Color[r=255,g=255,b=64]", "java.awt.Color[r=255,g=255,b=64]");
        projectInfo3.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo10);
        java.awt.Image image12 = projectInfo3.getLogo();
        org.jfree.chart.ui.ProjectInfo projectInfo16 = new org.jfree.chart.ui.ProjectInfo("Polar Plot", "4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0", "", image12, "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "", "RectangleAnchor.BOTTOM_LEFT");
        org.junit.Assert.assertNotNull(projectInfo3);
        org.junit.Assert.assertNotNull(image12);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.lang.Object obj1 = standardPieSectionLabelGenerator0.clone();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) dateAxis5, polarItemRenderer6);
        dateAxis5.setLabelAngle((double) (byte) 1);
        dateAxis5.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int13 = color12.getAlpha();
        dateAxis5.setTickLabelPaint((java.awt.Paint) color12);
        double double15 = dateAxis5.getFixedAutoRange();
        org.jfree.data.Range range16 = dateAxis5.getDefaultAutoRange();
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) dateAxis5, valueAxis17, xYItemRenderer18);
        boolean boolean20 = standardPieSectionLabelGenerator0.equals((java.lang.Object) xYPlot19);
        try {
            java.awt.Paint paint22 = xYPlot19.getQuadrantPaint((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (97) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 255 + "'", int13 == 255);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setInnerSeparatorExtension((double) '#');
        boolean boolean3 = ringPlot0.getSectionOutlinesVisible();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        java.awt.Color color0 = java.awt.Color.gray;
        int int1 = color0.getTransparency();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) dateAxis5, polarItemRenderer6);
        int int8 = polarPlot7.getBackgroundImageAlignment();
        boolean boolean9 = polarPlot7.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) polarPlot7);
        boolean boolean11 = color0.equals((java.lang.Object) "");
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 15 + "'", int8 == 15);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        float float5 = categoryPlot4.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation6 = categoryPlot4.getRangeAxisLocation();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = categoryPlot4.getRenderer();
        java.lang.String str8 = categoryPlot4.getPlotType();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer13 = null;
        org.jfree.chart.plot.PolarPlot polarPlot14 = new org.jfree.chart.plot.PolarPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) dateAxis12, polarItemRenderer13);
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot14);
        java.awt.geom.Rectangle2D rectangle2D16 = legendTitle15.getBounds();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        boolean boolean19 = categoryPlot4.render(graphics2D9, rectangle2D16, (int) (byte) 1, plotRenderingInfo18);
        java.awt.Stroke stroke20 = categoryPlot4.getRangeGridlineStroke();
        java.awt.Paint paint21 = categoryPlot4.getRangeCrosshairPaint();
        org.jfree.chart.block.BlockBorder blockBorder22 = new org.jfree.chart.block.BlockBorder((double) 1L, (double) 2, 0.0d, (double) 10L, paint21);
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer26 = null;
        org.jfree.chart.plot.PolarPlot polarPlot27 = new org.jfree.chart.plot.PolarPlot(xYDataset23, (org.jfree.chart.axis.ValueAxis) dateAxis25, polarItemRenderer26);
        org.jfree.data.time.DateRange dateRange28 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double29 = dateRange28.getUpperBound();
        dateAxis25.setRange((org.jfree.data.Range) dateRange28);
        boolean boolean31 = blockBorder22.equals((java.lang.Object) dateRange28);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 1.0f + "'", float5 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNull(categoryItemRenderer7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(dateRange28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.setDomainGridlinesVisible(true);
        double double24 = xYPlot21.getDomainCrosshairValue();
        boolean boolean25 = xYPlot21.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.ValueAxis valueAxis27 = xYPlot21.getRangeAxis(0);
        try {
            java.awt.Paint paint29 = xYPlot21.getQuadrantPaint((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (100) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(valueAxis27);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot4);
        java.awt.Color color6 = java.awt.Color.green;
        java.awt.Color color7 = color6.darker();
        legendTitle5.setBackgroundPaint((java.awt.Paint) color6);
        java.lang.Class<?> wildcardClass9 = legendTitle5.getClass();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle5.getLegendItemGraphicPadding();
        java.awt.Paint paint11 = null;
        try {
            legendTitle5.setItemPaint(paint11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Size2D[width=0.0, height=0.0]");
        numberAxis1.setAutoRangeStickyZero(true);
        boolean boolean4 = numberAxis1.getAutoRangeStickyZero();
        boolean boolean5 = numberAxis1.isVisible();
        java.text.NumberFormat numberFormat6 = numberAxis1.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType7 = numberAxis1.getRangeType();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer12 = null;
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) dateAxis11, polarItemRenderer12);
        dateAxis11.setLabelAngle((double) (byte) 1);
        dateAxis11.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int19 = color18.getAlpha();
        java.lang.String str20 = color18.toString();
        dateAxis11.setTickMarkPaint((java.awt.Paint) color18);
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = piePlot22.getSimpleLabelOffset();
        java.awt.Stroke stroke24 = piePlot22.getLabelOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, (java.awt.Paint) color18, stroke24);
        numberAxis1.setTickMarkStroke(stroke24);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(numberFormat6);
        org.junit.Assert.assertNotNull(rangeType7);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 255 + "'", int19 == 255);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str20.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke24);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot0.zoomRangeAxes((-1.0d), plotRenderingInfo6, point2D7, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        try {
            int int11 = categoryPlot0.getDomainAxisIndex(categoryAxis10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation2);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        dateAxis3.setLabelAngle((double) (byte) 1);
        dateAxis3.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int11 = color10.getAlpha();
        dateAxis3.setTickLabelPaint((java.awt.Paint) color10);
        double double13 = dateAxis3.getFixedAutoRange();
        org.jfree.chart.axis.TickUnitSource tickUnitSource14 = dateAxis3.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("Size2D[width=0.0, height=0.0]");
        numberAxis16.setAutoRangeStickyZero(true);
        boolean boolean19 = numberAxis16.getAutoRangeStickyZero();
        boolean boolean20 = numberAxis16.isVisible();
        java.text.NumberFormat numberFormat21 = numberAxis16.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType22 = numberAxis16.getRangeType();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit23 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis16.setTickUnit(numberTickUnit23, true, false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis16, xYItemRenderer27);
        xYPlot28.setDomainZeroBaselineVisible(true);
        xYPlot28.setDomainZeroBaselineVisible(true);
        java.awt.Paint paint33 = xYPlot28.getDomainZeroBaselinePaint();
        xYPlot28.mapDatasetToRangeAxis((int) (byte) 100, (-16777216));
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 255 + "'", int11 == 255);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNull(numberFormat21);
        org.junit.Assert.assertNotNull(rangeType22);
        org.junit.Assert.assertNotNull(numberTickUnit23);
        org.junit.Assert.assertNotNull(paint33);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = null;
        org.jfree.chart.text.TextBlock textBlock3 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint2);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = textBlock3.getLineAlignment();
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) dateAxis8, polarItemRenderer9);
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = piePlot11.getSimpleLabelOffset();
        double double13 = rectangleInsets12.getRight();
        dateAxis8.setLabelInsets(rectangleInsets12);
        dateAxis8.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("");
        dateAxis19.setRange((double) 0.0f, (double) 10.0f);
        dateAxis19.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) dateAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis19, xYItemRenderer25);
        java.awt.Stroke stroke27 = xYPlot26.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("");
        java.util.Date date31 = dateAxis30.getMaximumDate();
        xYPlot26.setRangeAxis((int) (short) 100, (org.jfree.chart.axis.ValueAxis) dateAxis30);
        java.util.Date date33 = dateAxis30.getMinimumDate();
        boolean boolean34 = textBlock3.equals((java.lang.Object) date33);
        org.junit.Assert.assertNotNull(textBlock3);
        org.junit.Assert.assertNotNull(horizontalAlignment4);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.18d + "'", double13 == 0.18d);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setInnerSeparatorExtension((double) '#');
        org.jfree.chart.util.Rotation rotation3 = ringPlot0.getDirection();
        ringPlot0.setIgnoreZeroValues(true);
        java.awt.Paint paint6 = ringPlot0.getSeparatorPaint();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot0);
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        int int5 = polarPlot4.getBackgroundImageAlignment();
        boolean boolean6 = polarPlot4.isSubplot();
        polarPlot4.setBackgroundImageAlignment(0);
        boolean boolean9 = polarPlot4.isRangeZoomable();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        java.awt.Stroke stroke22 = xYPlot21.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("");
        java.util.Date date26 = dateAxis25.getMaximumDate();
        xYPlot21.setRangeAxis((int) (short) 100, (org.jfree.chart.axis.ValueAxis) dateAxis25);
        double double28 = dateAxis25.getUpperBound();
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        dateAxis2.setLabelAngle((double) (byte) 1);
        dateAxis2.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int10 = color9.getAlpha();
        dateAxis2.setTickLabelPaint((java.awt.Paint) color9);
        double double12 = dateAxis2.getFixedAutoRange();
        org.jfree.data.Range range13 = dateAxis2.getDefaultAutoRange();
        org.jfree.data.Range range16 = org.jfree.data.Range.expand(range13, (double) (-1), 0.0d);
        double double17 = range16.getLowerBound();
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 255 + "'", int10 == 255);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        polarPlot4.zoomRangeAxes((double) 100, (double) 1.0f, plotRenderingInfo7, point2D8);
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = piePlot10.getSimpleLabelOffset();
        double double12 = rectangleInsets11.getRight();
        polarPlot4.setInsets(rectangleInsets11, true);
        org.jfree.chart.axis.ValueAxis valueAxis15 = polarPlot4.getAxis();
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        try {
            java.awt.Point point19 = polarPlot4.translateValueThetaRadiusToJava2D((double) (byte) -1, (double) (byte) 0, rectangle2D18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.18d + "'", double12 == 0.18d);
        org.junit.Assert.assertNotNull(valueAxis15);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        dateAxis1.setRange((double) 0.0f, (double) 10.0f);
        dateAxis1.resizeRange((double) ' ');
        dateAxis1.setLowerBound((double) (short) 0);
        double double9 = dateAxis1.getLowerMargin();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        int int5 = polarPlot4.getBackgroundImageAlignment();
        boolean boolean6 = polarPlot4.isSubplot();
        boolean boolean7 = polarPlot4.isDomainZoomable();
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer11 = null;
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot(xYDataset8, (org.jfree.chart.axis.ValueAxis) dateAxis10, polarItemRenderer11);
        dateAxis10.setLabelAngle((double) (byte) 1);
        dateAxis10.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int18 = color17.getAlpha();
        dateAxis10.setTickLabelPaint((java.awt.Paint) color17);
        polarPlot4.setAngleGridlinePaint((java.awt.Paint) color17);
        int int21 = color17.getBlue();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 255 + "'", int18 == 255);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 64 + "'", int21 == 64);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        java.lang.Comparable comparable4 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 255, (-16056329), comparable4, "java.awt.Color[r=255,g=255,b=64]", "ClassContext");
        org.jfree.data.general.PieDataset pieDataset8 = pieSectionEntity7.getDataset();
        java.lang.String str9 = pieSectionEntity7.getURLText();
        java.lang.String str10 = pieSectionEntity7.getToolTipText();
        java.lang.Comparable comparable11 = null;
        pieSectionEntity7.setSectionKey(comparable11);
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator13 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator14 = null;
        try {
            java.lang.String str15 = pieSectionEntity7.getImageMapAreaTag(toolTipTagFragmentGenerator13, uRLTagFragmentGenerator14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNull(pieDataset8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ClassContext" + "'", str9.equals("ClassContext"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str10.equals("java.awt.Color[r=255,g=255,b=64]"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.clearDomainMarkers(15);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        float float26 = categoryPlot25.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot25.getRangeAxisLocation();
        xYPlot21.setDomainAxisLocation((int) (byte) 0, axisLocation27, true);
        xYPlot21.setDomainCrosshairValue((double) 'a');
        boolean boolean32 = xYPlot21.isDomainZoomable();
        int int33 = xYPlot21.getRangeAxisCount();
        xYPlot21.clearRangeMarkers();
        org.jfree.data.xy.XYDataset xYDataset36 = null;
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer39 = null;
        org.jfree.chart.plot.PolarPlot polarPlot40 = new org.jfree.chart.plot.PolarPlot(xYDataset36, (org.jfree.chart.axis.ValueAxis) dateAxis38, polarItemRenderer39);
        int int41 = polarPlot40.getBackgroundImageAlignment();
        boolean boolean42 = polarPlot40.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart43 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) polarPlot40);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo46 = null;
        java.awt.image.BufferedImage bufferedImage47 = jFreeChart43.createBufferedImage(100, 255, chartRenderingInfo46);
        xYPlot21.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart43);
        org.jfree.chart.event.ChartChangeListener chartChangeListener49 = null;
        try {
            jFreeChart43.removeChangeListener(chartChangeListener49);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 1.0f + "'", float26 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 15 + "'", int41 == 15);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(bufferedImage47);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        boolean boolean2 = categoryPlot0.isDomainGridlinesVisible();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        boolean boolean7 = categoryPlot0.render(graphics2D3, rectangle2D4, (int) (byte) 10, plotRenderingInfo6);
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot0.getDataset((int) ' ');
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(categoryDataset9);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.clearDomainMarkers(15);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        float float26 = categoryPlot25.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot25.getRangeAxisLocation();
        xYPlot21.setDomainAxisLocation((int) (byte) 0, axisLocation27, true);
        xYPlot21.setDomainCrosshairValue((double) 'a');
        boolean boolean32 = xYPlot21.isRangeZeroBaselineVisible();
        double double33 = xYPlot21.getRangeCrosshairValue();
        java.awt.Paint paint34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        xYPlot21.setDomainZeroBaselinePaint(paint34);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 1.0f + "'", float26 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(paint34);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        java.lang.Object obj1 = null;
        boolean boolean2 = verticalAlignment0.equals(obj1);
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.clearDomainMarkers(15);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        float float26 = categoryPlot25.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot25.getRangeAxisLocation();
        xYPlot21.setDomainAxisLocation((int) (byte) 0, axisLocation27, true);
        xYPlot21.clearRangeAxes();
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 1.0f + "'", float26 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation27);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!");
        java.lang.String str3 = textTitle2.getToolTipText();
        java.awt.Paint paint4 = textTitle2.getBackgroundPaint();
        textTitle2.setToolTipText("java.awt.Color[r=255,g=255,b=64]");
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer11 = null;
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot(xYDataset8, (org.jfree.chart.axis.ValueAxis) dateAxis10, polarItemRenderer11);
        int int13 = polarPlot12.getBackgroundImageAlignment();
        boolean boolean14 = polarPlot12.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) polarPlot12);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo18 = null;
        java.awt.image.BufferedImage bufferedImage19 = jFreeChart15.createBufferedImage(100, 255, chartRenderingInfo18);
        jFreeChart15.removeLegend();
        java.awt.Stroke stroke21 = jFreeChart15.getBorderStroke();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType22 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent23 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) "java.awt.Color[r=255,g=255,b=64]", jFreeChart15, chartChangeEventType22);
        textTitle0.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart15);
        boolean boolean25 = jFreeChart15.getAntiAlias();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(bufferedImage19);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(0.0d, 2.0d, (double) 100.0f, (double) (short) 1);
        double double5 = rectangleInsets4.getBottom();
        java.lang.String str6 = rectangleInsets4.toString();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "RectangleInsets[t=0.0,l=2.0,b=100.0,r=1.0]" + "'", str6.equals("RectangleInsets[t=0.0,l=2.0,b=100.0,r=1.0]"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = piePlot0.getSimpleLabelOffset();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        piePlot0.markerChanged(markerChangeEvent2);
        java.lang.Object obj4 = piePlot0.clone();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator5 = null;
        piePlot0.setToolTipGenerator(pieToolTipGenerator5);
        java.awt.Stroke stroke7 = piePlot0.getLabelLinkStroke();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator8 = piePlot0.getLegendLabelGenerator();
        piePlot0.setCircular(true);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator8);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        java.awt.Paint paint1 = null;
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) dateAxis5, polarItemRenderer6);
        int int8 = polarPlot7.getBackgroundImageAlignment();
        boolean boolean9 = polarPlot7.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) polarPlot7);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo13 = null;
        java.awt.image.BufferedImage bufferedImage14 = jFreeChart10.createBufferedImage(100, 255, chartRenderingInfo13);
        jFreeChart10.removeLegend();
        java.awt.Stroke stroke16 = jFreeChart10.getBorderStroke();
        try {
            org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) '4', paint1, stroke16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 15 + "'", int8 == 15);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(bufferedImage14);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setInnerSeparatorExtension((double) 100L);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator3 = ringPlot0.getLegendLabelURLGenerator();
        ringPlot0.setSectionDepth((double) 1L);
        org.junit.Assert.assertNull(pieURLGenerator3);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.time.DateRange dateRange2 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = new org.jfree.chart.block.RectangleConstraint((double) '#', (org.jfree.data.Range) dateRange2);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = new org.jfree.chart.block.RectangleConstraint(10.0d, (org.jfree.data.Range) dateRange2);
        boolean boolean6 = dateRange2.contains(100.0d);
        boolean boolean8 = dateRange2.contains((double) (short) -1);
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer12 = null;
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) dateAxis11, polarItemRenderer12);
        int int14 = polarPlot13.getBackgroundImageAlignment();
        boolean boolean15 = polarPlot13.isSubplot();
        java.awt.Color color16 = java.awt.Color.blue;
        polarPlot13.setAngleLabelPaint((java.awt.Paint) color16);
        java.awt.Font font18 = polarPlot13.getAngleLabelFont();
        org.jfree.chart.plot.PlotOrientation plotOrientation19 = polarPlot13.getOrientation();
        boolean boolean20 = dateRange2.equals((java.lang.Object) polarPlot13);
        org.junit.Assert.assertNotNull(dateRange2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 15 + "'", int14 == 15);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(plotOrientation19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        dateAxis2.setLabelAngle((double) (byte) 1);
        java.awt.Font font7 = dateAxis2.getTickLabelFont();
        dateAxis2.setAutoTickUnitSelection(true);
        dateAxis2.setUpperBound((double) (-1));
        dateAxis2.setFixedAutoRange(100.0d);
        java.text.DateFormat dateFormat14 = null;
        dateAxis2.setDateFormatOverride(dateFormat14);
        java.awt.Font font16 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        dateAxis2.setLabelFont(font16);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(font16);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot4);
        org.jfree.chart.block.BlockContainer blockContainer6 = legendTitle5.getItemContainer();
        org.jfree.chart.block.Arrangement arrangement7 = blockContainer6.getArrangement();
        org.jfree.chart.block.BlockContainer blockContainer8 = new org.jfree.chart.block.BlockContainer(arrangement7);
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("hi!");
        java.lang.String str11 = textTitle10.getToolTipText();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = textTitle10.getHorizontalAlignment();
        blockContainer8.add((org.jfree.chart.block.Block) textTitle10);
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = piePlot14.getSimpleLabelOffset();
        double double17 = rectangleInsets15.calculateLeftOutset((double) (byte) 0);
        textTitle10.setPadding(rectangleInsets15);
        java.lang.Object obj19 = textTitle10.clone();
        org.junit.Assert.assertNotNull(blockContainer6);
        org.junit.Assert.assertNotNull(arrangement7);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(horizontalAlignment12);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(obj19);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        float[] floatArray1 = null;
        float[] floatArray2 = color0.getComponents(floatArray1);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray2);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        java.util.List list2 = categoryPlot0.getAnnotations();
        categoryPlot0.setWeight((int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        ringPlot2.setInnerSeparatorExtension((double) '#');
        org.jfree.chart.util.Rotation rotation5 = ringPlot2.getDirection();
        double double6 = ringPlot2.getShadowXOffset();
        double double7 = ringPlot2.getInnerSeparatorExtension();
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer11 = null;
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot(xYDataset8, (org.jfree.chart.axis.ValueAxis) dateAxis10, polarItemRenderer11);
        dateAxis10.setLabelAngle((double) (byte) 1);
        dateAxis10.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int18 = color17.getAlpha();
        java.lang.String str19 = color17.toString();
        dateAxis10.setTickMarkPaint((java.awt.Paint) color17);
        ringPlot2.setLabelShadowPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextLine textLine22 = new org.jfree.chart.text.TextLine("ClassContext", font1, (java.awt.Paint) color17);
        org.jfree.chart.text.TextFragment textFragment23 = textLine22.getLastTextFragment();
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer28 = null;
        org.jfree.chart.plot.PolarPlot polarPlot29 = new org.jfree.chart.plot.PolarPlot(xYDataset25, (org.jfree.chart.axis.ValueAxis) dateAxis27, polarItemRenderer28);
        org.jfree.chart.plot.PiePlot piePlot30 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = piePlot30.getSimpleLabelOffset();
        double double32 = rectangleInsets31.getRight();
        dateAxis27.setLabelInsets(rectangleInsets31);
        dateAxis27.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("");
        dateAxis38.setRange((double) 0.0f, (double) 10.0f);
        dateAxis38.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer44 = null;
        org.jfree.chart.plot.XYPlot xYPlot45 = new org.jfree.chart.plot.XYPlot(xYDataset24, (org.jfree.chart.axis.ValueAxis) dateAxis27, (org.jfree.chart.axis.ValueAxis) dateAxis38, xYItemRenderer44);
        xYPlot45.clearDomainMarkers(15);
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot();
        float float50 = categoryPlot49.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation51 = categoryPlot49.getRangeAxisLocation();
        xYPlot45.setDomainAxisLocation((int) (byte) 0, axisLocation51, true);
        java.awt.Stroke stroke54 = xYPlot45.getRangeGridlineStroke();
        boolean boolean55 = textLine22.equals((java.lang.Object) xYPlot45);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rotation5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 35.0d + "'", double7 == 35.0d);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 255 + "'", int18 == 255);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str19.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(textFragment23);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.18d + "'", double32 == 0.18d);
        org.junit.Assert.assertTrue("'" + float50 + "' != '" + 1.0f + "'", float50 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation51);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        org.jfree.data.Range range5 = dateAxis2.getRange();
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent9 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) range5, jFreeChart6, 255, (int) (short) 10);
        chartProgressEvent9.setType(1);
        org.jfree.chart.JFreeChart jFreeChart12 = chartProgressEvent9.getChart();
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(jFreeChart12);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = piePlot0.getSimpleLabelOffset();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        piePlot0.markerChanged(markerChangeEvent2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot0.setLabelBackgroundPaint((java.awt.Paint) color4);
        double double6 = piePlot0.getShadowYOffset();
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder8 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color7);
        piePlot0.setBaseSectionOutlinePaint((java.awt.Paint) color7);
        boolean boolean10 = piePlot0.isCircular();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator11 = null;
        try {
            piePlot0.setLegendLabelGenerator(pieSectionLabelGenerator11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'generator' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis((int) '4', valueAxis3, false);
        categoryPlot0.configureRangeAxes();
        categoryPlot0.clearRangeMarkers();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setInnerSeparatorExtension((double) '#');
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = null;
        ringPlot0.setLegendLabelToolTipGenerator(pieSectionLabelGenerator3);
        ringPlot0.setShadowXOffset(0.5d);
        double double7 = ringPlot0.getMaximumLabelWidth();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.14d + "'", double7 == 0.14d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.util.List list1 = projectInfo0.getContributors();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        dateAxis1.setRange((double) 0.0f, (double) 10.0f);
        dateAxis1.resizeRange((double) ' ');
        java.awt.Font font7 = dateAxis1.getTickLabelFont();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.axis.AxisState axisState9 = null;
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer13 = null;
        org.jfree.chart.plot.PolarPlot polarPlot14 = new org.jfree.chart.plot.PolarPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) dateAxis12, polarItemRenderer13);
        dateAxis12.setLabelAngle((double) (byte) 1);
        dateAxis12.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int20 = color19.getAlpha();
        java.lang.String str21 = color19.toString();
        dateAxis12.setTickMarkPaint((java.awt.Paint) color19);
        org.jfree.data.Range range23 = dateAxis12.getDefaultAutoRange();
        boolean boolean24 = dateAxis12.isTickMarksVisible();
        org.jfree.chart.plot.PiePlot piePlot26 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = piePlot26.getSimpleLabelOffset();
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer31 = null;
        org.jfree.chart.plot.PolarPlot polarPlot32 = new org.jfree.chart.plot.PolarPlot(xYDataset28, (org.jfree.chart.axis.ValueAxis) dateAxis30, polarItemRenderer31);
        org.jfree.chart.title.LegendTitle legendTitle33 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot32);
        java.awt.geom.Rectangle2D rectangle2D34 = legendTitle33.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType35 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType36 = null;
        java.awt.geom.Rectangle2D rectangle2D37 = rectangleInsets27.createAdjustedRectangle(rectangle2D34, lengthAdjustmentType35, lengthAdjustmentType36);
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean39 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge38);
        double double40 = dateAxis12.java2DToValue((double) 8, rectangle2D37, rectangleEdge38);
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = null;
        java.util.List list42 = dateAxis1.refreshTicks(graphics2D8, axisState9, rectangle2D37, rectangleEdge41);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 255 + "'", int20 == 255);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str21.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertNotNull(rectangleEdge38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 9.223372036854776E18d + "'", double40 == 9.223372036854776E18d);
        org.junit.Assert.assertNull(list42);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        dateAxis3.setLabelAngle((double) (byte) 1);
        dateAxis3.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int11 = color10.getAlpha();
        java.lang.String str12 = color10.toString();
        dateAxis3.setTickMarkPaint((java.awt.Paint) color10);
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = piePlot14.getSimpleLabelOffset();
        java.awt.Stroke stroke16 = piePlot14.getLabelOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, (java.awt.Paint) color10, stroke16);
        java.awt.Paint paint18 = valueMarker17.getOutlinePaint();
        java.awt.Font font19 = valueMarker17.getLabelFont();
        java.awt.Paint paint20 = valueMarker17.getOutlinePaint();
        java.awt.Paint paint21 = valueMarker17.getPaint();
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 255 + "'", int11 == 255);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str12.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke1 = null;
        piePlot0.setOutlineStroke(stroke1);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot0.getLabelGenerator();
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("ClassContext");
        numberAxis3D1.setLabel("RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]");
        numberAxis3D1.setAutoTickUnitSelection(false, true);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = piePlot0.getSimpleLabelOffset();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        piePlot0.markerChanged(markerChangeEvent2);
        double double4 = piePlot0.getMaximumExplodePercent();
        java.awt.Paint paint5 = piePlot0.getLabelBackgroundPaint();
        piePlot0.setStartAngle((double) (short) -1);
        java.awt.Image image8 = piePlot0.getBackgroundImage();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(image8);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.clearDomainMarkers(15);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer27 = null;
        org.jfree.chart.plot.PolarPlot polarPlot28 = new org.jfree.chart.plot.PolarPlot(xYDataset24, (org.jfree.chart.axis.ValueAxis) dateAxis26, polarItemRenderer27);
        dateAxis26.setLabelAngle((double) (byte) 1);
        dateAxis26.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color33 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int34 = color33.getAlpha();
        dateAxis26.setTickLabelPaint((java.awt.Paint) color33);
        dateAxis26.setInverted(false);
        double double38 = dateAxis26.getLowerBound();
        org.jfree.data.Range range39 = xYPlot21.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis26);
        java.awt.Paint paint40 = xYPlot21.getDomainGridlinePaint();
        org.jfree.chart.plot.RingPlot ringPlot41 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint42 = ringPlot41.getShadowPaint();
        ringPlot41.setInteriorGap((double) (byte) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.data.xy.XYDataset xYDataset47 = null;
        org.jfree.chart.axis.DateAxis dateAxis49 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer50 = null;
        org.jfree.chart.plot.PolarPlot polarPlot51 = new org.jfree.chart.plot.PolarPlot(xYDataset47, (org.jfree.chart.axis.ValueAxis) dateAxis49, polarItemRenderer50);
        int int52 = polarPlot51.getBackgroundImageAlignment();
        boolean boolean53 = polarPlot51.isSubplot();
        boolean boolean54 = polarPlot51.isDomainZoomable();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo56 = null;
        java.awt.geom.Point2D point2D57 = null;
        polarPlot51.zoomRangeAxes((double) 0.0f, plotRenderingInfo56, point2D57);
        org.jfree.data.xy.XYDataset xYDataset59 = null;
        org.jfree.chart.axis.DateAxis dateAxis61 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer62 = null;
        org.jfree.chart.plot.PolarPlot polarPlot63 = new org.jfree.chart.plot.PolarPlot(xYDataset59, (org.jfree.chart.axis.ValueAxis) dateAxis61, polarItemRenderer62);
        dateAxis61.setLabelAngle((double) (byte) 1);
        dateAxis61.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color68 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int69 = color68.getAlpha();
        java.lang.String str70 = color68.toString();
        dateAxis61.setTickMarkPaint((java.awt.Paint) color68);
        polarPlot51.setAngleGridlinePaint((java.awt.Paint) color68);
        org.jfree.chart.block.BlockBorder blockBorder73 = new org.jfree.chart.block.BlockBorder(rectangleInsets46, (java.awt.Paint) color68);
        java.awt.Color color74 = java.awt.Color.getColor("PlotOrientation.VERTICAL", color68);
        ringPlot41.setSeparatorPaint((java.awt.Paint) color74);
        xYPlot21.setDomainZeroBaselinePaint((java.awt.Paint) color74);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 255 + "'", int34 == 255);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNull(range39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(rectangleInsets46);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 15 + "'", int52 == 15);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(color68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 255 + "'", int69 == 255);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str70.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(color74);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.clearDomainMarkers(15);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        float float26 = categoryPlot25.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot25.getRangeAxisLocation();
        xYPlot21.setDomainAxisLocation((int) (byte) 0, axisLocation27, true);
        xYPlot21.setDomainCrosshairValue((double) 'a');
        boolean boolean32 = xYPlot21.isDomainZoomable();
        int int33 = xYPlot21.getRangeAxisCount();
        xYPlot21.clearRangeMarkers();
        org.jfree.data.xy.XYDataset xYDataset36 = null;
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer39 = null;
        org.jfree.chart.plot.PolarPlot polarPlot40 = new org.jfree.chart.plot.PolarPlot(xYDataset36, (org.jfree.chart.axis.ValueAxis) dateAxis38, polarItemRenderer39);
        int int41 = polarPlot40.getBackgroundImageAlignment();
        boolean boolean42 = polarPlot40.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart43 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) polarPlot40);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo46 = null;
        java.awt.image.BufferedImage bufferedImage47 = jFreeChart43.createBufferedImage(100, 255, chartRenderingInfo46);
        xYPlot21.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart43);
        float float49 = jFreeChart43.getBackgroundImageAlpha();
        org.jfree.chart.event.ChartProgressListener chartProgressListener50 = null;
        jFreeChart43.removeProgressListener(chartProgressListener50);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo54 = null;
        try {
            jFreeChart43.handleClick((-16056329), 64, chartRenderingInfo54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 1.0f + "'", float26 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 15 + "'", int41 == 15);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(bufferedImage47);
        org.junit.Assert.assertTrue("'" + float49 + "' != '" + 0.5f + "'", float49 == 0.5f);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.Object obj1 = categoryPlot0.clone();
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getDomainAxisEdge((int) (short) 1);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot0.getRangeMarkers((int) (short) 0, layer6);
        org.jfree.chart.plot.Marker marker9 = null;
        org.jfree.chart.util.Layer layer10 = null;
        try {
            boolean boolean11 = categoryPlot0.removeDomainMarker((int) (byte) 0, marker9, layer10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNull(collection7);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str1 = projectInfo0.toString();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo7 = new org.jfree.chart.ui.BasicProjectInfo("", "java.awt.Color[r=255,g=255,b=64]", "", "java.awt.Color[r=255,g=255,b=64]", "java.awt.Color[r=255,g=255,b=64]");
        projectInfo0.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo7);
        basicProjectInfo7.setLicenceName("Size2D[width=0.0, height=0.0]");
        org.jfree.chart.ui.Library[] libraryArray11 = basicProjectInfo7.getOptionalLibraries();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(libraryArray11);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.getName();
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("Pie Plot", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.clearDomainMarkers(15);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        float float26 = categoryPlot25.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot25.getRangeAxisLocation();
        xYPlot21.setDomainAxisLocation((int) (byte) 0, axisLocation27, true);
        xYPlot21.setDomainCrosshairValue((double) 'a');
        xYPlot21.mapDatasetToRangeAxis(100, 255);
        org.jfree.data.xy.XYDataset xYDataset35 = null;
        xYPlot21.setDataset(xYDataset35);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 1.0f + "'", float26 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation27);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.Object obj1 = categoryPlot0.clone();
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = categoryPlot0.getRangeMarkers((int) (byte) 0, layer4);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNull(collection5);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        java.lang.Number[] numberArray8 = new java.lang.Number[] { 0.4d, 100.0f, 0L, 0.025d, (byte) 1, 1.0f };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 0.4d, 100.0f, 0L, 0.025d, (byte) 1, 1.0f };
        java.lang.Number[] numberArray22 = new java.lang.Number[] { 0.4d, 100.0f, 0L, 0.025d, (byte) 1, 1.0f };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { 0.4d, 100.0f, 0L, 0.025d, (byte) 1, 1.0f };
        java.lang.Number[] numberArray36 = new java.lang.Number[] { 0.4d, 100.0f, 0L, 0.025d, (byte) 1, 1.0f };
        java.lang.Number[] numberArray43 = new java.lang.Number[] { 0.4d, 100.0f, 0L, 0.025d, (byte) 1, 1.0f };
        java.lang.Number[][] numberArray44 = new java.lang.Number[][] { numberArray8, numberArray15, numberArray22, numberArray29, numberArray36, numberArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("PlotOrientation.VERTICAL", "hi!", numberArray44);
        java.lang.Number number46 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset45);
        try {
            org.jfree.data.general.PieDataset pieDataset48 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset45, (java.lang.Comparable) 1.0E-5d);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray36);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertTrue("'" + number46 + "' != '" + 0.0d + "'", number46.equals(0.0d));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot0.zoomRangeAxes((-1.0d), plotRenderingInfo6, point2D7, false);
        categoryPlot0.clearRangeMarkers((int) (byte) 10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = categoryPlot0.getRangeAxisForDataset((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNull(valueAxis13);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        int int6 = polarPlot5.getBackgroundImageAlignment();
        boolean boolean7 = polarPlot5.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) polarPlot5);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        java.awt.image.BufferedImage bufferedImage12 = jFreeChart8.createBufferedImage(100, 255, chartRenderingInfo11);
        int int13 = jFreeChart8.getBackgroundImageAlignment();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo16 = null;
        try {
            java.awt.image.BufferedImage bufferedImage17 = jFreeChart8.createBufferedImage((-6553600), 1, chartRenderingInfo16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (-6553600) and height (1) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(bufferedImage12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        boolean boolean2 = categoryPlot0.isDomainGridlinesVisible();
        int int3 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean5 = categoryPlot4.isDomainGridlinesVisible();
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) dateAxis9, polarItemRenderer10);
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = piePlot12.getSimpleLabelOffset();
        double double14 = rectangleInsets13.getRight();
        dateAxis9.setLabelInsets(rectangleInsets13);
        dateAxis9.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("");
        dateAxis20.setRange((double) 0.0f, (double) 10.0f);
        dateAxis20.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) dateAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer26);
        xYPlot27.clearDomainMarkers(15);
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot();
        float float32 = categoryPlot31.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation33 = categoryPlot31.getRangeAxisLocation();
        xYPlot27.setDomainAxisLocation((int) (byte) 0, axisLocation33, true);
        xYPlot27.setDomainCrosshairValue((double) 'a');
        org.jfree.chart.axis.AxisLocation axisLocation38 = xYPlot27.getRangeAxisLocation();
        categoryPlot4.setRangeAxisLocation(axisLocation38, true);
        categoryPlot0.setDomainAxisLocation(axisLocation38);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.18d + "'", double14 == 0.18d);
        org.junit.Assert.assertTrue("'" + float32 + "' != '" + 1.0f + "'", float32 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertNotNull(axisLocation38);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setInnerSeparatorExtension((double) 100L);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator3 = ringPlot0.getLegendLabelURLGenerator();
        java.awt.Paint paint4 = ringPlot0.getLabelShadowPaint();
        org.junit.Assert.assertNull(pieURLGenerator3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("", "java.awt.Color[r=255,g=255,b=64]", "", "java.awt.Color[r=255,g=255,b=64]", "java.awt.Color[r=255,g=255,b=64]");
        org.jfree.chart.ui.ProjectInfo projectInfo6 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str7 = projectInfo6.toString();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo13 = new org.jfree.chart.ui.BasicProjectInfo("", "java.awt.Color[r=255,g=255,b=64]", "", "java.awt.Color[r=255,g=255,b=64]", "java.awt.Color[r=255,g=255,b=64]");
        projectInfo6.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo13);
        java.lang.String str15 = basicProjectInfo13.getCopyright();
        basicProjectInfo5.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo13);
        org.junit.Assert.assertNotNull(projectInfo6);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str15.equals("java.awt.Color[r=255,g=255,b=64]"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        java.awt.Color color0 = java.awt.Color.darkGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 100, 0.4d);
        org.jfree.data.time.DateRange dateRange11 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((double) '#', (org.jfree.data.Range) dateRange11);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint9.toRangeHeight((org.jfree.data.Range) dateRange11);
        org.jfree.chart.util.Size2D size2D14 = legendTitle5.arrange(graphics2D6, rectangleConstraint9);
        legendTitle5.setNotify(true);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 100, 0.4d);
        org.jfree.data.time.DateRange dateRange22 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = new org.jfree.chart.block.RectangleConstraint((double) '#', (org.jfree.data.Range) dateRange22);
        org.jfree.data.Range range26 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange22, (double) 1.0f, false);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint27 = rectangleConstraint20.toRangeHeight(range26);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint29 = rectangleConstraint20.toFixedHeight((double) (byte) 100);
        org.jfree.chart.util.Size2D size2D30 = legendTitle5.arrange(graphics2D17, rectangleConstraint20);
        org.junit.Assert.assertNotNull(dateRange11);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(size2D14);
        org.junit.Assert.assertNotNull(dateRange22);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertNotNull(rectangleConstraint27);
        org.junit.Assert.assertNotNull(rectangleConstraint29);
        org.junit.Assert.assertNotNull(size2D30);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = piePlot5.getSimpleLabelOffset();
        double double7 = rectangleInsets6.getRight();
        dateAxis2.setLabelInsets(rectangleInsets6);
        dateAxis2.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition12 = dateAxis2.getTickMarkPosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        float float14 = categoryPlot13.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation15 = categoryPlot13.getRangeAxisLocation();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = categoryPlot13.getRenderer();
        java.lang.String str17 = categoryPlot13.getPlotType();
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer22 = null;
        org.jfree.chart.plot.PolarPlot polarPlot23 = new org.jfree.chart.plot.PolarPlot(xYDataset19, (org.jfree.chart.axis.ValueAxis) dateAxis21, polarItemRenderer22);
        org.jfree.chart.title.LegendTitle legendTitle24 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot23);
        java.awt.geom.Rectangle2D rectangle2D25 = legendTitle24.getBounds();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        boolean boolean28 = categoryPlot13.render(graphics2D18, rectangle2D25, (int) (byte) 1, plotRenderingInfo27);
        java.awt.Stroke stroke29 = categoryPlot13.getRangeGridlineStroke();
        dateAxis2.setAxisLineStroke(stroke29);
        org.jfree.data.xy.XYDataset xYDataset31 = null;
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer34 = null;
        org.jfree.chart.plot.PolarPlot polarPlot35 = new org.jfree.chart.plot.PolarPlot(xYDataset31, (org.jfree.chart.axis.ValueAxis) dateAxis33, polarItemRenderer34);
        dateAxis33.setLabelAngle((double) (byte) 1);
        java.awt.Font font38 = dateAxis33.getTickLabelFont();
        dateAxis33.setAutoTickUnitSelection(true);
        dateAxis33.setLabelAngle(0.18d);
        org.jfree.chart.axis.Timeline timeline43 = dateAxis33.getTimeline();
        dateAxis2.setTimeline(timeline43);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.18d + "'", double7 == 0.18d);
        org.junit.Assert.assertNotNull(dateTickMarkPosition12);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 1.0f + "'", float14 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNull(categoryItemRenderer16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Category Plot" + "'", str17.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(font38);
        org.junit.Assert.assertNotNull(timeline43);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str1 = projectInfo0.toString();
        projectInfo0.setName("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        org.junit.Assert.assertNotNull(projectInfo0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = ringPlot0.getShadowPaint();
        ringPlot0.setInteriorGap((double) (byte) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) dateAxis8, polarItemRenderer9);
        int int11 = polarPlot10.getBackgroundImageAlignment();
        boolean boolean12 = polarPlot10.isSubplot();
        boolean boolean13 = polarPlot10.isDomainZoomable();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        polarPlot10.zoomRangeAxes((double) 0.0f, plotRenderingInfo15, point2D16);
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer21 = null;
        org.jfree.chart.plot.PolarPlot polarPlot22 = new org.jfree.chart.plot.PolarPlot(xYDataset18, (org.jfree.chart.axis.ValueAxis) dateAxis20, polarItemRenderer21);
        dateAxis20.setLabelAngle((double) (byte) 1);
        dateAxis20.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color27 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int28 = color27.getAlpha();
        java.lang.String str29 = color27.toString();
        dateAxis20.setTickMarkPaint((java.awt.Paint) color27);
        polarPlot10.setAngleGridlinePaint((java.awt.Paint) color27);
        org.jfree.chart.block.BlockBorder blockBorder32 = new org.jfree.chart.block.BlockBorder(rectangleInsets5, (java.awt.Paint) color27);
        java.awt.Color color33 = java.awt.Color.getColor("PlotOrientation.VERTICAL", color27);
        ringPlot0.setSeparatorPaint((java.awt.Paint) color33);
        double double35 = ringPlot0.getOuterSeparatorExtension();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 15 + "'", int11 == 15);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 255 + "'", int28 == 255);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str29.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.2d + "'", double35 == 0.2d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.NONE;
        java.lang.String str1 = lengthConstraintType0.toString();
        org.junit.Assert.assertNotNull(lengthConstraintType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "LengthConstraintType.NONE" + "'", str1.equals("LengthConstraintType.NONE"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        org.jfree.chart.entity.EntityCollection entityCollection2 = piePlotState1.getEntityCollection();
        piePlotState1.setPieCenterY(2.0d);
        piePlotState1.setPassesRequired((int) '4');
        org.junit.Assert.assertNull(entityCollection2);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        dateAxis2.setLabelAngle((double) (byte) 1);
        dateAxis2.setAutoRangeMinimumSize((double) (byte) 10);
        double double9 = dateAxis2.getUpperMargin();
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer13 = null;
        org.jfree.chart.plot.PolarPlot polarPlot14 = new org.jfree.chart.plot.PolarPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) dateAxis12, polarItemRenderer13);
        dateAxis12.setLabelAngle((double) (byte) 1);
        dateAxis12.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int20 = color19.getAlpha();
        dateAxis12.setTickLabelPaint((java.awt.Paint) color19);
        double double22 = dateAxis12.getFixedAutoRange();
        org.jfree.chart.axis.TickUnitSource tickUnitSource23 = dateAxis12.getStandardTickUnits();
        dateAxis2.setStandardTickUnits(tickUnitSource23);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 255 + "'", int20 == 255);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource23);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        java.lang.ClassLoader classLoader0 = null;
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = null;
        dateAxis1.setStandardTickUnits(tickUnitSource2);
        dateAxis1.setFixedAutoRange((double) 100L);
        java.awt.Font font6 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        dateAxis1.setLabelFont(font6);
        dateAxis1.setAxisLineVisible(false);
        dateAxis1.setTickMarksVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        float float13 = categoryPlot12.getForegroundAlpha();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = categoryPlot12.getRenderer(255);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        categoryPlot12.setDataset(categoryDataset16);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = categoryPlot12.getDrawingSupplier();
        dateAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot12);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        float float22 = categoryPlot21.getForegroundAlpha();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = categoryPlot21.getRenderer(255);
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        categoryPlot21.setDataset(categoryDataset25);
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        float float28 = categoryPlot27.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation29 = categoryPlot27.getRangeAxisLocation();
        categoryPlot21.setDomainAxisLocation(axisLocation29, true);
        categoryPlot12.setDomainAxisLocation((int) (byte) 100, axisLocation29);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 1.0f + "'", float13 == 1.0f);
        org.junit.Assert.assertNull(categoryItemRenderer15);
        org.junit.Assert.assertNotNull(drawingSupplier18);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 1.0f + "'", float22 == 1.0f);
        org.junit.Assert.assertNull(categoryItemRenderer24);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 1.0f + "'", float28 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation29);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        java.lang.String str2 = textTitle1.getToolTipText();
        java.awt.geom.Rectangle2D rectangle2D3 = textTitle1.getBounds();
        java.awt.geom.Rectangle2D rectangle2D4 = textTitle1.getBounds();
        double double5 = textTitle1.getContentXOffset();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(rectangle2D3);
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.lang.Object obj1 = standardPieSectionLabelGenerator0.clone();
        java.lang.Object obj2 = standardPieSectionLabelGenerator0.clone();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer27 = null;
        org.jfree.chart.plot.PolarPlot polarPlot28 = new org.jfree.chart.plot.PolarPlot(xYDataset24, (org.jfree.chart.axis.ValueAxis) dateAxis26, polarItemRenderer27);
        org.jfree.chart.title.LegendTitle legendTitle29 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot28);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean33 = categoryPlot32.isDomainGridlinesVisible();
        boolean boolean34 = categoryPlot32.isDomainGridlinesVisible();
        java.awt.Graphics2D graphics2D35 = null;
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        boolean boolean39 = categoryPlot32.render(graphics2D35, rectangle2D36, (int) (byte) 10, plotRenderingInfo38);
        categoryPlot32.setOutlineVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis43 = categoryPlot32.getRangeAxis(0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = null;
        org.jfree.data.xy.XYDataset xYDataset47 = null;
        org.jfree.chart.axis.DateAxis dateAxis49 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer50 = null;
        org.jfree.chart.plot.PolarPlot polarPlot51 = new org.jfree.chart.plot.PolarPlot(xYDataset47, (org.jfree.chart.axis.ValueAxis) dateAxis49, polarItemRenderer50);
        int int52 = polarPlot51.getBackgroundImageAlignment();
        boolean boolean53 = polarPlot51.isSubplot();
        java.awt.Color color54 = java.awt.Color.blue;
        polarPlot51.setAngleLabelPaint((java.awt.Paint) color54);
        java.awt.Font font56 = polarPlot51.getAngleLabelFont();
        org.jfree.chart.title.LegendTitle legendTitle57 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot51);
        org.jfree.data.xy.XYDataset xYDataset60 = null;
        org.jfree.chart.axis.DateAxis dateAxis62 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer63 = null;
        org.jfree.chart.plot.PolarPlot polarPlot64 = new org.jfree.chart.plot.PolarPlot(xYDataset60, (org.jfree.chart.axis.ValueAxis) dateAxis62, polarItemRenderer63);
        dateAxis62.setLabelAngle((double) (byte) 1);
        dateAxis62.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color69 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int70 = color69.getAlpha();
        java.lang.String str71 = color69.toString();
        dateAxis62.setTickMarkPaint((java.awt.Paint) color69);
        org.jfree.data.Range range73 = dateAxis62.getDefaultAutoRange();
        boolean boolean74 = dateAxis62.isTickMarksVisible();
        org.jfree.chart.plot.PiePlot piePlot76 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets77 = piePlot76.getSimpleLabelOffset();
        org.jfree.data.xy.XYDataset xYDataset78 = null;
        org.jfree.chart.axis.DateAxis dateAxis80 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer81 = null;
        org.jfree.chart.plot.PolarPlot polarPlot82 = new org.jfree.chart.plot.PolarPlot(xYDataset78, (org.jfree.chart.axis.ValueAxis) dateAxis80, polarItemRenderer81);
        org.jfree.chart.title.LegendTitle legendTitle83 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot82);
        java.awt.geom.Rectangle2D rectangle2D84 = legendTitle83.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType85 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType86 = null;
        java.awt.geom.Rectangle2D rectangle2D87 = rectangleInsets77.createAdjustedRectangle(rectangle2D84, lengthAdjustmentType85, lengthAdjustmentType86);
        org.jfree.chart.util.RectangleEdge rectangleEdge88 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean89 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge88);
        double double90 = dateAxis62.java2DToValue((double) 8, rectangle2D87, rectangleEdge88);
        java.awt.Point point91 = polarPlot51.translateValueThetaRadiusToJava2D((double) (-1L), (double) 2, rectangle2D87);
        categoryPlot32.zoomRangeAxes((double) 10, (double) (-1L), plotRenderingInfo46, (java.awt.geom.Point2D) point91);
        polarPlot28.zoomRangeAxes((double) (-16056329), plotRenderingInfo31, (java.awt.geom.Point2D) point91);
        try {
            xYPlot21.zoomDomainAxes((double) (short) 1, plotRenderingInfo23, (java.awt.geom.Point2D) point91, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNull(valueAxis43);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 15 + "'", int52 == 15);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(font56);
        org.junit.Assert.assertNotNull(color69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 255 + "'", int70 == 255);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str71.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(range73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertNotNull(rectangleInsets77);
        org.junit.Assert.assertNotNull(rectangle2D84);
        org.junit.Assert.assertNotNull(rectangle2D87);
        org.junit.Assert.assertNotNull(rectangleEdge88);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 9.223372036854776E18d + "'", double90 == 9.223372036854776E18d);
        org.junit.Assert.assertNotNull(point91);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double1 = rectangleInsets0.getTop();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        boolean boolean2 = categoryPlot0.isDomainGridlinesVisible();
        int int3 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis((int) (byte) 0);
        org.jfree.chart.LegendItemCollection legendItemCollection6 = categoryPlot0.getFixedLegendItems();
        float float7 = categoryPlot0.getForegroundAlpha();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNull(legendItemCollection6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        int int5 = polarPlot4.getBackgroundImageAlignment();
        boolean boolean6 = polarPlot4.isSubplot();
        boolean boolean7 = polarPlot4.isDomainZoomable();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        polarPlot4.zoomRangeAxes((double) 0.0f, plotRenderingInfo9, point2D10);
        java.lang.Object obj12 = polarPlot4.clone();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.setDomainCrosshairValue((double) (short) 10);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer28 = null;
        org.jfree.chart.plot.PolarPlot polarPlot29 = new org.jfree.chart.plot.PolarPlot(xYDataset25, (org.jfree.chart.axis.ValueAxis) dateAxis27, polarItemRenderer28);
        int int30 = polarPlot29.getBackgroundImageAlignment();
        boolean boolean31 = polarPlot29.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart32 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) polarPlot29);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo35 = null;
        java.awt.image.BufferedImage bufferedImage36 = jFreeChart32.createBufferedImage(100, 255, chartRenderingInfo35);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent39 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) (short) 10, jFreeChart32, (-16056329), (-16777216));
        jFreeChart32.setTextAntiAlias(false);
        java.awt.Image image42 = jFreeChart32.getBackgroundImage();
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 15 + "'", int30 == 15);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(bufferedImage36);
        org.junit.Assert.assertNull(image42);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setInnerSeparatorExtension((double) '#');
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = null;
        ringPlot0.setLegendLabelToolTipGenerator(pieSectionLabelGenerator3);
        float float5 = ringPlot0.getBackgroundImageAlpha();
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.5f + "'", float5 == 0.5f);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = piePlot1.getSimpleLabelOffset();
        boolean boolean3 = piePlot1.getSectionOutlinesVisible();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = null;
        piePlot1.setLegendLabelURLGenerator(pieURLGenerator4);
        boolean boolean6 = piePlot1.getSimpleLabels();
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint8 = ringPlot7.getShadowPaint();
        ringPlot7.setInteriorGap((double) (byte) 0);
        java.awt.Font font11 = ringPlot7.getNoDataMessageFont();
        piePlot1.setLabelFont(font11);
        java.awt.Color color13 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment14 = new org.jfree.chart.text.TextFragment("", font11, (java.awt.Paint) color13);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(color13);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) dateAxis4, polarItemRenderer5);
        dateAxis4.setLabelAngle((double) (byte) 1);
        dateAxis4.setTickMarkOutsideLength((-1.0f));
        dateAxis4.setFixedDimension(0.4d);
        double double13 = dateAxis4.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot15.zoomRangeAxes(0.18d, plotRenderingInfo17, point2D18, false);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = categoryPlot15.getRendererForDataset(categoryDataset21);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        categoryPlot15.setRenderer(0, categoryItemRenderer24, true);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNull(categoryItemRenderer22);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        double double1 = rectangleConstraint0.getWidth();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        java.lang.String str2 = textTitle1.getToolTipText();
        java.awt.geom.Rectangle2D rectangle2D3 = textTitle1.getBounds();
        double double4 = textTitle1.getWidth();
        org.jfree.chart.block.BlockFrame blockFrame5 = textTitle1.getFrame();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(rectangle2D3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(blockFrame5);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.clearDomainMarkers(15);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        float float26 = categoryPlot25.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot25.getRangeAxisLocation();
        xYPlot21.setDomainAxisLocation((int) (byte) 0, axisLocation27, true);
        java.awt.Stroke stroke30 = xYPlot21.getRangeGridlineStroke();
        java.awt.Paint paint31 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot21.setDomainZeroBaselinePaint(paint31);
        java.awt.Paint paint33 = xYPlot21.getDomainTickBandPaint();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent34 = null;
        xYPlot21.markerChanged(markerChangeEvent34);
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = xYPlot21.getDomainAxisEdge();
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot();
        float float38 = categoryPlot37.getForegroundAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        categoryPlot37.setRangeAxis((int) '4', valueAxis40, false);
        categoryPlot37.configureRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset46 = null;
        org.jfree.chart.axis.DateAxis dateAxis48 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer49 = null;
        org.jfree.chart.plot.PolarPlot polarPlot50 = new org.jfree.chart.plot.PolarPlot(xYDataset46, (org.jfree.chart.axis.ValueAxis) dateAxis48, polarItemRenderer49);
        dateAxis48.setLabelAngle((double) (byte) 1);
        dateAxis48.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color55 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int56 = color55.getAlpha();
        java.lang.String str57 = color55.toString();
        dateAxis48.setTickMarkPaint((java.awt.Paint) color55);
        org.jfree.chart.plot.PiePlot piePlot59 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets60 = piePlot59.getSimpleLabelOffset();
        java.awt.Stroke stroke61 = piePlot59.getLabelOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker62 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, (java.awt.Paint) color55, stroke61);
        org.jfree.chart.util.Layer layer63 = null;
        categoryPlot37.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker62, layer63);
        org.jfree.chart.axis.DateAxis dateAxis66 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource67 = null;
        dateAxis66.setStandardTickUnits(tickUnitSource67);
        java.awt.Stroke stroke69 = dateAxis66.getTickMarkStroke();
        valueMarker62.setStroke(stroke69);
        org.jfree.chart.plot.PiePlot piePlot71 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets72 = piePlot71.getSimpleLabelOffset();
        boolean boolean73 = piePlot71.getSectionOutlinesVisible();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator74 = null;
        piePlot71.setLegendLabelURLGenerator(pieURLGenerator74);
        boolean boolean76 = piePlot71.getSimpleLabels();
        org.jfree.chart.plot.RingPlot ringPlot77 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint78 = ringPlot77.getShadowPaint();
        ringPlot77.setInteriorGap((double) (byte) 0);
        java.awt.Font font81 = ringPlot77.getNoDataMessageFont();
        piePlot71.setLabelFont(font81);
        valueMarker62.setLabelFont(font81);
        org.jfree.chart.util.Layer layer84 = null;
        try {
            boolean boolean85 = xYPlot21.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker62, layer84);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 1.0f + "'", float26 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNull(paint33);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertTrue("'" + float38 + "' != '" + 1.0f + "'", float38 == 1.0f);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 255 + "'", int56 == 255);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str57.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(rectangleInsets60);
        org.junit.Assert.assertNotNull(stroke61);
        org.junit.Assert.assertNotNull(stroke69);
        org.junit.Assert.assertNotNull(rectangleInsets72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(paint78);
        org.junit.Assert.assertNotNull(font81);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.Object obj2 = textTitle1.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        dateAxis2.setLabelAngle((double) (byte) 1);
        dateAxis2.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int10 = color9.getAlpha();
        java.lang.String str11 = color9.toString();
        dateAxis2.setTickMarkPaint((java.awt.Paint) color9);
        java.lang.String str13 = dateAxis2.getLabelToolTip();
        boolean boolean14 = dateAxis2.isAutoTickUnitSelection();
        java.util.Date date15 = dateAxis2.getMinimumDate();
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 255 + "'", int10 == 255);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str11.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(date15);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = null;
        dateAxis1.setStandardTickUnits(tickUnitSource2);
        dateAxis1.setFixedAutoRange((double) 100L);
        java.awt.Font font6 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        dateAxis1.setLabelFont(font6);
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date9 = dateAxis1.calculateHighestVisibleTickValue(dateTickUnit8);
        double double10 = dateAxis1.getFixedAutoRange();
        java.awt.Shape shape11 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis1.setUpArrow(shape11);
        dateAxis1.setLabelAngle(0.0d);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 100.0d + "'", double10 == 100.0d);
        org.junit.Assert.assertNotNull(shape11);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.setDomainCrosshairValue((double) (short) 10);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer28 = null;
        org.jfree.chart.plot.PolarPlot polarPlot29 = new org.jfree.chart.plot.PolarPlot(xYDataset25, (org.jfree.chart.axis.ValueAxis) dateAxis27, polarItemRenderer28);
        int int30 = polarPlot29.getBackgroundImageAlignment();
        boolean boolean31 = polarPlot29.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart32 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) polarPlot29);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo35 = null;
        java.awt.image.BufferedImage bufferedImage36 = jFreeChart32.createBufferedImage(100, 255, chartRenderingInfo35);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent39 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) (short) 10, jFreeChart32, (-16056329), (-16777216));
        jFreeChart32.setTextAntiAlias(false);
        java.lang.Object obj42 = jFreeChart32.getTextAntiAlias();
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 15 + "'", int30 == 15);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(bufferedImage36);
        org.junit.Assert.assertNotNull(obj42);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setInnerSeparatorExtension((double) '#');
        org.jfree.chart.util.Rotation rotation3 = ringPlot0.getDirection();
        double double4 = ringPlot0.getShadowXOffset();
        java.awt.Font font6 = null;
        java.awt.Paint paint7 = null;
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("", font6, paint7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor12 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        java.awt.Shape shape16 = textBlock8.calculateBounds(graphics2D9, 0.0f, (float) (short) 0, textBlockAnchor12, (float) (byte) 10, (float) 15, (double) 0L);
        boolean boolean17 = ringPlot0.equals((java.lang.Object) textBlock8);
        double double18 = ringPlot0.getLabelLinkMargin();
        ringPlot0.setLabelLinkMargin(0.0d);
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertNotNull(textBlockAnchor12);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.025d + "'", double18 == 0.025d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.clearDomainMarkers(15);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        float float26 = categoryPlot25.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot25.getRangeAxisLocation();
        xYPlot21.setDomainAxisLocation((int) (byte) 0, axisLocation27, true);
        xYPlot21.setDomainCrosshairValue((double) 'a');
        boolean boolean32 = xYPlot21.isDomainZoomable();
        int int33 = xYPlot21.getRangeAxisCount();
        xYPlot21.clearRangeMarkers();
        org.jfree.data.xy.XYDataset xYDataset36 = null;
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer39 = null;
        org.jfree.chart.plot.PolarPlot polarPlot40 = new org.jfree.chart.plot.PolarPlot(xYDataset36, (org.jfree.chart.axis.ValueAxis) dateAxis38, polarItemRenderer39);
        int int41 = polarPlot40.getBackgroundImageAlignment();
        boolean boolean42 = polarPlot40.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart43 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) polarPlot40);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo46 = null;
        java.awt.image.BufferedImage bufferedImage47 = jFreeChart43.createBufferedImage(100, 255, chartRenderingInfo46);
        xYPlot21.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart43);
        float float49 = jFreeChart43.getBackgroundImageAlpha();
        org.jfree.chart.title.TextTitle textTitle51 = new org.jfree.chart.title.TextTitle("hi!");
        java.awt.Paint paint52 = textTitle51.getPaint();
        jFreeChart43.setBackgroundPaint(paint52);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 1.0f + "'", float26 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 15 + "'", int41 == 15);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(bufferedImage47);
        org.junit.Assert.assertTrue("'" + float49 + "' != '" + 0.5f + "'", float49 == 0.5f);
        org.junit.Assert.assertNotNull(paint52);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Size2D[width=0.0, height=0.0]");
        numberAxis1.setAutoRangeStickyZero(true);
        java.awt.Stroke stroke4 = numberAxis1.getTickMarkStroke();
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = piePlot0.getSimpleLabelOffset();
        boolean boolean2 = piePlot0.isSubplot();
        piePlot0.setStartAngle(0.5d);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        java.lang.String str1 = textAnchor0.toString();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextAnchor.CENTER_LEFT" + "'", str1.equals("TextAnchor.CENTER_LEFT"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setInnerSeparatorExtension((double) '#');
        org.jfree.chart.util.Rotation rotation3 = ringPlot0.getDirection();
        double double4 = ringPlot0.getShadowXOffset();
        double double5 = ringPlot0.getInnerSeparatorExtension();
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = piePlot8.getSimpleLabelOffset();
        java.awt.Stroke stroke10 = piePlot8.getLabelOutlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        org.jfree.chart.plot.PiePlotState piePlotState13 = ringPlot0.initialise(graphics2D6, rectangle2D7, piePlot8, (java.lang.Integer) 100, plotRenderingInfo12);
        java.awt.Paint paint14 = ringPlot0.getLabelOutlinePaint();
        java.awt.Color color15 = java.awt.Color.orange;
        ringPlot0.setShadowPaint((java.awt.Paint) color15);
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 35.0d + "'", double5 == 35.0d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(piePlotState13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(color15);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.clearDomainMarkers(15);
        org.jfree.chart.LegendItemCollection legendItemCollection24 = xYPlot21.getFixedLegendItems();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = xYPlot21.getAxisOffset();
        boolean boolean26 = xYPlot21.isRangeZoomable();
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        float float29 = categoryPlot28.getForegroundAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        categoryPlot28.setRangeAxis((int) '4', valueAxis31, false);
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot28.getRangeAxisLocation();
        xYPlot21.setDomainAxisLocation(3, axisLocation34, true);
        xYPlot21.setDomainCrosshairValue((double) 10L);
        java.awt.Stroke stroke39 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot21.setDomainCrosshairStroke(stroke39);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertNull(legendItemCollection24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 1.0f + "'", float29 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertNotNull(stroke39);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.setDomainCrosshairValue((double) (short) 10);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer28 = null;
        org.jfree.chart.plot.PolarPlot polarPlot29 = new org.jfree.chart.plot.PolarPlot(xYDataset25, (org.jfree.chart.axis.ValueAxis) dateAxis27, polarItemRenderer28);
        int int30 = polarPlot29.getBackgroundImageAlignment();
        boolean boolean31 = polarPlot29.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart32 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) polarPlot29);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo35 = null;
        java.awt.image.BufferedImage bufferedImage36 = jFreeChart32.createBufferedImage(100, 255, chartRenderingInfo35);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent39 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) (short) 10, jFreeChart32, (-16056329), (-16777216));
        try {
            org.jfree.chart.title.Title title41 = jFreeChart32.getSubtitle(64);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 15 + "'", int30 == 15);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(bufferedImage36);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        dateAxis2.setLabelAngle((double) (byte) 1);
        dateAxis2.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int10 = color9.getAlpha();
        dateAxis2.setTickLabelPaint((java.awt.Paint) color9);
        dateAxis2.setTickMarkOutsideLength((float) (-1));
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 255 + "'", int10 == 255);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot4);
        java.lang.Object obj6 = legendTitle5.clone();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) dateAxis9, polarItemRenderer10);
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = piePlot12.getSimpleLabelOffset();
        double double14 = rectangleInsets13.getRight();
        dateAxis9.setLabelInsets(rectangleInsets13);
        legendTitle5.setLegendItemGraphicPadding(rectangleInsets13);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = legendTitle5.getLegendItemGraphicPadding();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = legendTitle5.getLegendItemGraphicLocation();
        java.awt.Paint paint19 = legendTitle5.getBackgroundPaint();
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.18d + "'", double14 == 0.18d);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(rectangleAnchor18);
        org.junit.Assert.assertNull(paint19);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("hi!");
        java.lang.String str4 = textTitle3.getToolTipText();
        java.awt.geom.Rectangle2D rectangle2D5 = textTitle3.getBounds();
        java.awt.geom.Rectangle2D rectangle2D6 = textTitle3.getBounds();
        try {
            blockBorder0.draw(graphics2D1, rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(rectangle2D6);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        int int6 = polarPlot5.getBackgroundImageAlignment();
        boolean boolean7 = polarPlot5.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) polarPlot5);
        java.lang.Object obj9 = polarPlot5.clone();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = piePlot0.getSimpleLabelOffset();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        piePlot0.markerChanged(markerChangeEvent2);
        java.lang.Object obj4 = piePlot0.clone();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator5 = null;
        piePlot0.setToolTipGenerator(pieToolTipGenerator5);
        java.awt.Stroke stroke7 = piePlot0.getLabelLinkStroke();
        java.awt.Shape shape8 = piePlot0.getLegendItemShape();
        org.jfree.chart.block.LineBorder lineBorder9 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = lineBorder9.getInsets();
        piePlot0.setSimpleLabelOffset(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(rectangleInsets10);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.setDomainGridlinesVisible(true);
        double double24 = xYPlot21.getDomainCrosshairValue();
        boolean boolean25 = xYPlot21.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.ValueAxis valueAxis27 = xYPlot21.getRangeAxis(0);
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("Size2D[width=0.0, height=0.0]");
        numberAxis29.setAutoRangeStickyZero(true);
        boolean boolean32 = numberAxis29.getAutoRangeStickyZero();
        boolean boolean33 = numberAxis29.isVisible();
        java.text.NumberFormat numberFormat34 = numberAxis29.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType35 = numberAxis29.getRangeType();
        xYPlot21.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis29);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(valueAxis27);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNull(numberFormat34);
        org.junit.Assert.assertNotNull(rangeType35);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        xYPlot21.zoomRangeAxes((double) ' ', plotRenderingInfo23, point2D24);
        java.awt.Stroke stroke26 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot21.setDomainGridlineStroke(stroke26);
        org.jfree.chart.axis.ValueAxis valueAxis28 = xYPlot21.getDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer33 = null;
        org.jfree.chart.plot.PolarPlot polarPlot34 = new org.jfree.chart.plot.PolarPlot(xYDataset30, (org.jfree.chart.axis.ValueAxis) dateAxis32, polarItemRenderer33);
        int int35 = polarPlot34.getBackgroundImageAlignment();
        boolean boolean36 = polarPlot34.isSubplot();
        boolean boolean37 = polarPlot34.isDomainZoomable();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        java.awt.geom.Point2D point2D40 = null;
        polarPlot34.zoomRangeAxes((double) 0.0f, plotRenderingInfo39, point2D40);
        org.jfree.data.xy.XYDataset xYDataset42 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer45 = null;
        org.jfree.chart.plot.PolarPlot polarPlot46 = new org.jfree.chart.plot.PolarPlot(xYDataset42, (org.jfree.chart.axis.ValueAxis) dateAxis44, polarItemRenderer45);
        dateAxis44.setLabelAngle((double) (byte) 1);
        dateAxis44.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color51 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int52 = color51.getAlpha();
        java.lang.String str53 = color51.toString();
        dateAxis44.setTickMarkPaint((java.awt.Paint) color51);
        polarPlot34.setAngleGridlinePaint((java.awt.Paint) color51);
        org.jfree.chart.block.BlockBorder blockBorder56 = new org.jfree.chart.block.BlockBorder(rectangleInsets29, (java.awt.Paint) color51);
        double double58 = rectangleInsets29.calculateLeftOutset((double) 10L);
        double double60 = rectangleInsets29.calculateRightInset(1.0d);
        double double61 = rectangleInsets29.getRight();
        valueAxis28.setLabelInsets(rectangleInsets29);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(valueAxis28);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 15 + "'", int35 == 15);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 255 + "'", int52 == 255);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str53.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 1.0d + "'", double58 == 1.0d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 1.0d + "'", double60 == 1.0d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 1.0d + "'", double61 == 1.0d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        int int6 = polarPlot5.getBackgroundImageAlignment();
        boolean boolean7 = polarPlot5.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) polarPlot5);
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer13 = null;
        org.jfree.chart.plot.PolarPlot polarPlot14 = new org.jfree.chart.plot.PolarPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) dateAxis12, polarItemRenderer13);
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = piePlot15.getSimpleLabelOffset();
        double double17 = rectangleInsets16.getRight();
        dateAxis12.setLabelInsets(rectangleInsets16);
        dateAxis12.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("");
        dateAxis23.setRange((double) 0.0f, (double) 10.0f);
        dateAxis23.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis23, xYItemRenderer29);
        xYPlot30.clearDomainMarkers(15);
        org.jfree.data.xy.XYDataset xYDataset33 = null;
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer36 = null;
        org.jfree.chart.plot.PolarPlot polarPlot37 = new org.jfree.chart.plot.PolarPlot(xYDataset33, (org.jfree.chart.axis.ValueAxis) dateAxis35, polarItemRenderer36);
        dateAxis35.setLabelAngle((double) (byte) 1);
        dateAxis35.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color42 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int43 = color42.getAlpha();
        dateAxis35.setTickLabelPaint((java.awt.Paint) color42);
        dateAxis35.setInverted(false);
        double double47 = dateAxis35.getLowerBound();
        org.jfree.data.Range range48 = xYPlot30.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis35);
        org.jfree.chart.util.RectangleEdge rectangleEdge49 = xYPlot30.getRangeAxisEdge();
        java.util.List list50 = xYPlot30.getAnnotations();
        jFreeChart8.setSubtitles(list50);
        org.jfree.chart.event.ChartProgressListener chartProgressListener52 = null;
        jFreeChart8.removeProgressListener(chartProgressListener52);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.18d + "'", double17 == 0.18d);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 255 + "'", int43 == 255);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNull(range48);
        org.junit.Assert.assertNotNull(rectangleEdge49);
        org.junit.Assert.assertNotNull(list50);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.time.DateRange dateRange2 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = new org.jfree.chart.block.RectangleConstraint((double) '#', (org.jfree.data.Range) dateRange2);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = new org.jfree.chart.block.RectangleConstraint(10.0d, (org.jfree.data.Range) dateRange2);
        java.lang.String str5 = rectangleConstraint4.toString();
        org.jfree.data.time.DateRange dateRange7 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint((double) '#', (org.jfree.data.Range) dateRange7);
        org.jfree.data.Range range11 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange7, (double) 1.0f, false);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = rectangleConstraint4.toRangeWidth((org.jfree.data.Range) dateRange7);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange7, (double) (-1.0f));
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint14.toUnconstrainedWidth();
        org.junit.Assert.assertNotNull(dateRange2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]" + "'", str5.equals("RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]"));
        org.junit.Assert.assertNotNull(dateRange7);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(rectangleConstraint12);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        int int5 = polarPlot4.getBackgroundImageAlignment();
        boolean boolean6 = polarPlot4.isOutlineVisible();
        java.awt.Paint paint7 = polarPlot4.getRadiusGridlinePaint();
        java.awt.Font font8 = polarPlot4.getAngleLabelFont();
        boolean boolean9 = polarPlot4.isRadiusGridlinesVisible();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = textTitle1.getPosition();
        textTitle1.setMargin((double) 0, (double) (-16777216), 100.0d, 35.0d);
        java.awt.Paint paint8 = textTitle1.getBackgroundPaint();
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNull(paint8);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("ClassContext");
        numberAxis3D1.setLabel("RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]");
        org.jfree.data.Range range4 = numberAxis3D1.getDefaultAutoRange();
        numberAxis3D1.configure();
        org.junit.Assert.assertNotNull(range4);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        java.awt.Stroke stroke2 = piePlot3D1.getLabelOutlineStroke();
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.setDomainGridlinesVisible(true);
        double double24 = xYPlot21.getDomainCrosshairValue();
        boolean boolean25 = xYPlot21.isDomainCrosshairLockedOnData();
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer29 = null;
        org.jfree.chart.plot.PolarPlot polarPlot30 = new org.jfree.chart.plot.PolarPlot(xYDataset26, (org.jfree.chart.axis.ValueAxis) dateAxis28, polarItemRenderer29);
        dateAxis28.setLabelAngle((double) (byte) 1);
        dateAxis28.setTickMarkOutsideLength((-1.0f));
        dateAxis28.setFixedDimension(0.4d);
        java.awt.Paint paint37 = dateAxis28.getTickMarkPaint();
        xYPlot21.setDomainZeroBaselinePaint(paint37);
        org.jfree.data.xy.XYDataset xYDataset40 = null;
        xYPlot21.setDataset((int) (byte) 0, xYDataset40);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(paint37);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeGridlinesVisible(false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = piePlot0.getSimpleLabelOffset();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        piePlot0.markerChanged(markerChangeEvent2);
        double double4 = piePlot0.getMaximumExplodePercent();
        java.awt.Paint paint5 = piePlot0.getLabelBackgroundPaint();
        piePlot0.setMinimumArcAngleToDraw((double) 0);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        boolean boolean2 = paintMap0.containsKey((java.lang.Comparable) (short) 10);
        java.lang.Comparable comparable3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean5 = categoryPlot4.isDomainGridlinesVisible();
        categoryPlot4.setForegroundAlpha((float) 1);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        categoryPlot4.drawBackgroundImage(graphics2D8, rectangle2D9);
        org.jfree.chart.LegendItemCollection legendItemCollection11 = categoryPlot4.getFixedLegendItems();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        categoryPlot4.rendererChanged(rendererChangeEvent12);
        categoryPlot4.mapDatasetToRangeAxis(0, (int) (byte) 0);
        java.awt.Paint paint17 = categoryPlot4.getDomainGridlinePaint();
        try {
            paintMap0.put(comparable3, paint17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(legendItemCollection11);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        categoryPlot0.configureDomainAxes();
        categoryPlot0.setRangeCrosshairValue((double) 0.5f, false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("RectangleEdge.LEFT", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = null;
        dateAxis1.setStandardTickUnits(tickUnitSource2);
        java.awt.Stroke stroke4 = dateAxis1.getTickMarkStroke();
        double double5 = dateAxis1.getUpperMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets(0.0d, 2.0d, (double) 100.0f, (double) (short) 1);
        double double11 = rectangleInsets10.getBottom();
        dateAxis1.setLabelInsets(rectangleInsets10);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 100.0d + "'", double11 == 100.0d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        boolean boolean2 = categoryPlot0.isDomainGridlinesVisible();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        boolean boolean7 = categoryPlot0.render(graphics2D3, rectangle2D4, (int) (byte) 10, plotRenderingInfo6);
        categoryPlot0.setOutlineVisible(true);
        org.jfree.data.category.CategoryDataset categoryDataset11 = categoryPlot0.getDataset(0);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        float float13 = categoryPlot12.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation14 = categoryPlot12.getRangeAxisLocation();
        categoryPlot0.setDomainAxisLocation(axisLocation14);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(categoryDataset11);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 1.0f + "'", float13 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation14);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        boolean boolean2 = piePlot3D1.getDarkerSides();
        piePlot3D1.setDarkerSides(true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        java.awt.Color color4 = java.awt.Color.GRAY;
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) dateAxis8, polarItemRenderer9);
        dateAxis8.setLabelAngle((double) (byte) 1);
        dateAxis8.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int16 = color15.getAlpha();
        java.lang.String str17 = color15.toString();
        dateAxis8.setTickMarkPaint((java.awt.Paint) color15);
        org.jfree.chart.plot.PiePlot piePlot19 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = piePlot19.getSimpleLabelOffset();
        java.awt.Stroke stroke21 = piePlot19.getLabelOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, (java.awt.Paint) color15, stroke21);
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker((-1.0d), (java.awt.Paint) color4, stroke21);
        java.awt.Color color24 = java.awt.Color.WHITE;
        java.awt.Color color25 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        float[] floatArray30 = new float[] { (-1.0f), 10, (short) 0, '#' };
        float[] floatArray31 = color25.getRGBComponents(floatArray30);
        float[] floatArray32 = color24.getColorComponents(floatArray30);
        float[] floatArray33 = color4.getComponents(floatArray32);
        float[] floatArray34 = java.awt.Color.RGBtoHSB(0, (int) (short) 0, (int) (byte) 1, floatArray32);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 255 + "'", int16 == 255);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str17.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray34);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace3);
        categoryPlot0.setAnchorValue((double) (short) 1);
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot0.getDomainAxisLocation();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(axisLocation7);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        int int5 = polarPlot4.getBackgroundImageAlignment();
        boolean boolean6 = polarPlot4.isOutlineVisible();
        polarPlot4.setAngleGridlinesVisible(true);
        org.jfree.chart.plot.WaferMapPlot waferMapPlot9 = new org.jfree.chart.plot.WaferMapPlot();
        java.awt.Paint paint10 = waferMapPlot9.getBackgroundPaint();
        polarPlot4.setAngleLabelPaint(paint10);
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) (byte) 0, (float) 0L, (float) (-16777216));
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) ' ', 0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D6 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D2, (double) 100.0f, (double) (byte) 0, rectangleAnchor5);
        size2D2.setWidth((double) 0.5f);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(rectangle2D6);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke1 = null;
        piePlot0.setOutlineStroke(stroke1);
        java.awt.Color color3 = java.awt.Color.green;
        java.awt.Color color4 = color3.darker();
        piePlot0.setLabelBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator6 = null;
        piePlot0.setURLGenerator(pieURLGenerator6);
        piePlot0.setShadowYOffset((double) (byte) 1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Size2D[width=0.0, height=0.0]");
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setFixedAutoRange((double) 10.0f);
        java.text.NumberFormat numberFormat6 = null;
        numberAxis1.setNumberFormatOverride(numberFormat6);
        numberAxis1.setAutoRangeIncludesZero(true);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        float[] floatArray5 = new float[] { (-1.0f), 10, (short) 0, '#' };
        float[] floatArray6 = color0.getRGBComponents(floatArray5);
        org.jfree.chart.block.BlockBorder blockBorder7 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = blockBorder7.getInsets();
        double double10 = rectangleInsets8.calculateBottomInset(1.5d);
        java.lang.String str11 = rectangleInsets8.toString();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent12 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) str11);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str11.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        int int5 = polarPlot4.getBackgroundImageAlignment();
        boolean boolean6 = polarPlot4.isSubplot();
        java.awt.Color color7 = java.awt.Color.blue;
        polarPlot4.setAngleLabelPaint((java.awt.Paint) color7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = polarPlot4.getInsets();
        java.awt.Stroke stroke10 = polarPlot4.getRadiusGridlineStroke();
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.clearDomainMarkers(15);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        float float26 = categoryPlot25.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot25.getRangeAxisLocation();
        xYPlot21.setDomainAxisLocation((int) (byte) 0, axisLocation27, true);
        xYPlot21.setDomainCrosshairValue((double) 'a');
        boolean boolean32 = xYPlot21.isDomainZoomable();
        int int33 = xYPlot21.getRangeAxisCount();
        xYPlot21.clearRangeMarkers();
        org.jfree.data.xy.XYDataset xYDataset36 = null;
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer39 = null;
        org.jfree.chart.plot.PolarPlot polarPlot40 = new org.jfree.chart.plot.PolarPlot(xYDataset36, (org.jfree.chart.axis.ValueAxis) dateAxis38, polarItemRenderer39);
        int int41 = polarPlot40.getBackgroundImageAlignment();
        boolean boolean42 = polarPlot40.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart43 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) polarPlot40);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo46 = null;
        java.awt.image.BufferedImage bufferedImage47 = jFreeChart43.createBufferedImage(100, 255, chartRenderingInfo46);
        xYPlot21.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart43);
        float float49 = jFreeChart43.getBackgroundImageAlpha();
        jFreeChart43.setTextAntiAlias(false);
        jFreeChart43.setNotify(true);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 1.0f + "'", float26 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 15 + "'", int41 == 15);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(bufferedImage47);
        org.junit.Assert.assertTrue("'" + float49 + "' != '" + 0.5f + "'", float49 == 0.5f);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        int int6 = polarPlot5.getBackgroundImageAlignment();
        boolean boolean7 = polarPlot5.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) polarPlot5);
        jFreeChart8.setAntiAlias(true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = null;
        org.jfree.chart.text.TextBlock textBlock3 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint2);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = textBlock3.getLineAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment4, verticalAlignment5, (double) 100, 0.0d);
        org.jfree.chart.block.Block block9 = null;
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer13 = null;
        org.jfree.chart.plot.PolarPlot polarPlot14 = new org.jfree.chart.plot.PolarPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) dateAxis12, polarItemRenderer13);
        dateAxis12.setLabelAngle((double) (byte) 1);
        dateAxis12.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int20 = color19.getAlpha();
        java.lang.String str21 = color19.toString();
        dateAxis12.setTickMarkPaint((java.awt.Paint) color19);
        org.jfree.data.Range range23 = dateAxis12.getDefaultAutoRange();
        boolean boolean24 = dateAxis12.isTickMarksVisible();
        org.jfree.chart.plot.PiePlot piePlot26 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = piePlot26.getSimpleLabelOffset();
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer31 = null;
        org.jfree.chart.plot.PolarPlot polarPlot32 = new org.jfree.chart.plot.PolarPlot(xYDataset28, (org.jfree.chart.axis.ValueAxis) dateAxis30, polarItemRenderer31);
        org.jfree.chart.title.LegendTitle legendTitle33 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot32);
        java.awt.geom.Rectangle2D rectangle2D34 = legendTitle33.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType35 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType36 = null;
        java.awt.geom.Rectangle2D rectangle2D37 = rectangleInsets27.createAdjustedRectangle(rectangle2D34, lengthAdjustmentType35, lengthAdjustmentType36);
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean39 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge38);
        double double40 = dateAxis12.java2DToValue((double) 8, rectangle2D37, rectangleEdge38);
        columnArrangement8.add(block9, (java.lang.Object) 8);
        org.junit.Assert.assertNotNull(textBlock3);
        org.junit.Assert.assertNotNull(horizontalAlignment4);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 255 + "'", int20 == 255);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str21.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertNotNull(rectangleEdge38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 9.223372036854776E18d + "'", double40 == 9.223372036854776E18d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        piePlotState1.setTotal((double) (short) 0);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) dateAxis6, polarItemRenderer7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot8);
        java.awt.geom.Rectangle2D rectangle2D10 = legendTitle9.getBounds();
        piePlotState1.setLinkArea(rectangle2D10);
        java.awt.geom.Rectangle2D rectangle2D12 = piePlotState1.getPieArea();
        piePlotState1.setPieCenterY((double) 1);
        int int15 = piePlotState1.getPassesRequired();
        piePlotState1.setPieWRadius(35.0d);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertNull(rectangle2D12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        piePlotState1.setTotal((double) (short) 0);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) dateAxis6, polarItemRenderer7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot8);
        java.awt.geom.Rectangle2D rectangle2D10 = legendTitle9.getBounds();
        piePlotState1.setLinkArea(rectangle2D10);
        java.awt.geom.Rectangle2D rectangle2D12 = piePlotState1.getPieArea();
        piePlotState1.setPieCenterY((double) 1);
        double double15 = piePlotState1.getTotal();
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertNull(rectangle2D12);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) 10, 9.223372036854776E18d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        xYPlot21.zoomRangeAxes((double) ' ', plotRenderingInfo23, point2D24);
        java.awt.Paint paint26 = xYPlot21.getDomainTickBandPaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent27 = null;
        xYPlot21.rendererChanged(rendererChangeEvent27);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray29 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot21.setRenderers(xYItemRendererArray29);
        org.jfree.chart.plot.PlotOrientation plotOrientation31 = xYPlot21.getOrientation();
        double double32 = xYPlot21.getDomainCrosshairValue();
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertNull(paint26);
        org.junit.Assert.assertNotNull(xYItemRendererArray29);
        org.junit.Assert.assertNotNull(plotOrientation31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.clearDomainMarkers(15);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        float float26 = categoryPlot25.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot25.getRangeAxisLocation();
        xYPlot21.setDomainAxisLocation((int) (byte) 0, axisLocation27, true);
        java.awt.Stroke stroke30 = xYPlot21.getRangeGridlineStroke();
        java.awt.Paint paint31 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot21.setDomainZeroBaselinePaint(paint31);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent33 = null;
        xYPlot21.notifyListeners(plotChangeEvent33);
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis("");
        dateAxis36.setRange((double) 0.0f, (double) 10.0f);
        dateAxis36.resizeRange((double) ' ');
        dateAxis36.setVerticalTickLabels(false);
        org.jfree.data.Range range44 = xYPlot21.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis36);
        org.jfree.chart.axis.AxisSpace axisSpace45 = null;
        xYPlot21.setFixedRangeAxisSpace(axisSpace45, false);
        xYPlot21.clearAnnotations();
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 1.0f + "'", float26 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNull(range44);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = piePlot0.getSimpleLabelOffset();
        boolean boolean2 = piePlot0.getSectionOutlinesVisible();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator3 = null;
        piePlot0.setLegendLabelURLGenerator(pieURLGenerator3);
        boolean boolean5 = piePlot0.getSimpleLabels();
        org.jfree.chart.text.TextFragment textFragment7 = new org.jfree.chart.text.TextFragment("");
        boolean boolean8 = piePlot0.equals((java.lang.Object) "");
        piePlot0.setShadowXOffset((double) (byte) 0);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) ' ');
        java.lang.Object obj3 = objectList1.get((int) (short) -1);
        java.lang.Object obj4 = objectList1.clone();
        java.lang.Object obj5 = objectList1.clone();
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        java.text.NumberFormat numberFormat1 = null;
        java.text.NumberFormat numberFormat2 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("", numberFormat1, numberFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'numberFormat' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.data.KeyedValues keyedValues1 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) 1.0E-5d, keyedValues1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowData' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis((int) '4', valueAxis3, false);
        categoryPlot0.configureRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer12 = null;
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) dateAxis11, polarItemRenderer12);
        dateAxis11.setLabelAngle((double) (byte) 1);
        dateAxis11.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int19 = color18.getAlpha();
        java.lang.String str20 = color18.toString();
        dateAxis11.setTickMarkPaint((java.awt.Paint) color18);
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = piePlot22.getSimpleLabelOffset();
        java.awt.Stroke stroke24 = piePlot22.getLabelOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, (java.awt.Paint) color18, stroke24);
        org.jfree.chart.util.Layer layer26 = null;
        categoryPlot0.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker25, layer26);
        org.jfree.chart.plot.CategoryMarker categoryMarker28 = null;
        try {
            categoryPlot0.addDomainMarker(categoryMarker28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 255 + "'", int19 == 255);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str20.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke24);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = categoryPlot0.getRenderer();
        java.lang.String str4 = categoryPlot0.getPlotType();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) dateAxis8, polarItemRenderer9);
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot10);
        java.awt.geom.Rectangle2D rectangle2D12 = legendTitle11.getBounds();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        boolean boolean15 = categoryPlot0.render(graphics2D5, rectangle2D12, (int) (byte) 1, plotRenderingInfo14);
        categoryPlot0.setNoDataMessage("hi!");
        categoryPlot0.setAnchorValue((double) 1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        categoryPlot0.zoomRangeAxes((double) (-1L), (double) (byte) 100, plotRenderingInfo22, point2D23);
        int int25 = categoryPlot0.getDomainAxisCount();
        categoryPlot0.setWeight(3);
        org.jfree.chart.axis.AxisLocation axisLocation28 = categoryPlot0.getRangeAxisLocation();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNull(categoryItemRenderer3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Category Plot" + "'", str4.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(axisLocation28);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.Object obj1 = categoryPlot0.clone();
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getDomainAxisEdge((int) (short) 1);
        int int5 = categoryPlot0.getDomainAxisCount();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        java.awt.Font font4 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        ringPlot5.setInnerSeparatorExtension((double) '#');
        org.jfree.chart.util.Rotation rotation8 = ringPlot5.getDirection();
        double double9 = ringPlot5.getShadowXOffset();
        double double10 = ringPlot5.getInnerSeparatorExtension();
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer14 = null;
        org.jfree.chart.plot.PolarPlot polarPlot15 = new org.jfree.chart.plot.PolarPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) dateAxis13, polarItemRenderer14);
        dateAxis13.setLabelAngle((double) (byte) 1);
        dateAxis13.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color20 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int21 = color20.getAlpha();
        java.lang.String str22 = color20.toString();
        dateAxis13.setTickMarkPaint((java.awt.Paint) color20);
        ringPlot5.setLabelShadowPaint((java.awt.Paint) color20);
        org.jfree.chart.text.TextLine textLine25 = new org.jfree.chart.text.TextLine("ClassContext", font4, (java.awt.Paint) color20);
        java.awt.Font font27 = null;
        java.awt.Paint paint28 = null;
        org.jfree.chart.text.TextBlock textBlock29 = org.jfree.chart.text.TextUtilities.createTextBlock("", font27, paint28);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment30 = textBlock29.getLineAlignment();
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.Font font35 = null;
        java.awt.Paint paint36 = null;
        org.jfree.chart.text.TextBlock textBlock37 = org.jfree.chart.text.TextUtilities.createTextBlock("", font35, paint36);
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor41 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        java.awt.Shape shape45 = textBlock37.calculateBounds(graphics2D38, 0.0f, (float) (short) 0, textBlockAnchor41, (float) (byte) 10, (float) 15, (double) 0L);
        textBlock29.draw(graphics2D31, 0.0f, (float) (byte) 10, textBlockAnchor41);
        org.jfree.chart.text.TextLine textLine47 = textBlock29.getLastLine();
        org.jfree.data.xy.XYDataset xYDataset49 = null;
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer52 = null;
        org.jfree.chart.plot.PolarPlot polarPlot53 = new org.jfree.chart.plot.PolarPlot(xYDataset49, (org.jfree.chart.axis.ValueAxis) dateAxis51, polarItemRenderer52);
        dateAxis51.setLabelAngle((double) (byte) 1);
        java.awt.Font font56 = dateAxis51.getTickLabelFont();
        org.jfree.chart.text.TextLine textLine57 = new org.jfree.chart.text.TextLine("", font56);
        textBlock29.addLine(textLine57);
        org.jfree.chart.text.TextFragment textFragment59 = textLine57.getLastTextFragment();
        java.awt.Color color60 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        float[] floatArray65 = new float[] { (-1.0f), 10, (short) 0, '#' };
        float[] floatArray66 = color60.getRGBComponents(floatArray65);
        boolean boolean67 = textFragment59.equals((java.lang.Object) floatArray65);
        float[] floatArray68 = color20.getComponents(floatArray65);
        float[] floatArray69 = java.awt.Color.RGBtoHSB((int) (byte) 10, 2, (int) (byte) 100, floatArray65);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(rotation8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 4.0d + "'", double9 == 4.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 35.0d + "'", double10 == 35.0d);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 255 + "'", int21 == 255);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str22.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(textBlock29);
        org.junit.Assert.assertNotNull(horizontalAlignment30);
        org.junit.Assert.assertNotNull(textBlock37);
        org.junit.Assert.assertNotNull(textBlockAnchor41);
        org.junit.Assert.assertNotNull(shape45);
        org.junit.Assert.assertNull(textLine47);
        org.junit.Assert.assertNotNull(font56);
        org.junit.Assert.assertNotNull(textFragment59);
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertNotNull(floatArray65);
        org.junit.Assert.assertNotNull(floatArray66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(floatArray68);
        org.junit.Assert.assertNotNull(floatArray69);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int2 = color1.getAlpha();
        java.lang.String str3 = color1.toString();
        piePlot0.setLabelPaint((java.awt.Paint) color1);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator5 = piePlot0.getLegendLabelToolTipGenerator();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator6 = piePlot0.getLegendLabelURLGenerator();
        org.jfree.chart.util.Rotation rotation7 = org.jfree.chart.util.Rotation.CLOCKWISE;
        double double8 = rotation7.getFactor();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer12 = null;
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) dateAxis11, polarItemRenderer12);
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot13);
        org.jfree.chart.block.BlockContainer blockContainer15 = legendTitle14.getItemContainer();
        boolean boolean16 = rotation7.equals((java.lang.Object) legendTitle14);
        piePlot0.setDirection(rotation7);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 255 + "'", int2 == 255);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str3.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNull(pieSectionLabelGenerator5);
        org.junit.Assert.assertNull(pieURLGenerator6);
        org.junit.Assert.assertNotNull(rotation7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertNotNull(blockContainer15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test167");
//        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
//        org.jfree.data.general.PieDataset pieDataset1 = null;
//        java.lang.Comparable comparable4 = null;
//        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 255, (-16056329), comparable4, "java.awt.Color[r=255,g=255,b=64]", "ClassContext");
//        org.jfree.data.general.PieDataset pieDataset8 = pieSectionEntity7.getDataset();
//        pieSectionEntity7.setPieIndex((int) (short) 1);
//        java.lang.String str11 = pieSectionEntity7.getURLText();
//        try {
//            java.lang.Object obj12 = pieSectionEntity7.clone();
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(shape0);
//        org.junit.Assert.assertNull(pieDataset8);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ClassContext" + "'", str11.equals("ClassContext"));
//    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = categoryPlot0.getRenderer(255);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        categoryPlot0.setDataset(categoryDataset4);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        float float7 = categoryPlot6.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot6.getRangeAxisLocation();
        categoryPlot0.setDomainAxisLocation(axisLocation8, true);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot0.getRangeAxisEdge((int) (short) 1);
        org.jfree.chart.axis.AxisLocation axisLocation14 = categoryPlot0.getDomainAxisLocation((int) ' ');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNull(categoryItemRenderer3);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNotNull(axisLocation14);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = piePlot0.getSimpleLabelOffset();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        piePlot0.markerChanged(markerChangeEvent2);
        piePlot0.setInteriorGap((double) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean7 = categoryPlot6.isDomainGridlinesVisible();
        boolean boolean8 = categoryPlot6.isDomainGridlinesVisible();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        boolean boolean13 = categoryPlot6.render(graphics2D9, rectangle2D10, (int) (byte) 10, plotRenderingInfo12);
        categoryPlot6.setOutlineVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis17 = categoryPlot6.getRangeAxis(0);
        categoryPlot6.configureRangeAxes();
        org.jfree.chart.axis.AxisSpace axisSpace19 = categoryPlot6.getFixedRangeAxisSpace();
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer23 = null;
        org.jfree.chart.plot.PolarPlot polarPlot24 = new org.jfree.chart.plot.PolarPlot(xYDataset20, (org.jfree.chart.axis.ValueAxis) dateAxis22, polarItemRenderer23);
        dateAxis22.setLabelAngle((double) (byte) 1);
        dateAxis22.setTickMarkOutsideLength((-1.0f));
        dateAxis22.setFixedDimension(0.4d);
        double double31 = dateAxis22.getUpperBound();
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("");
        java.util.Date date34 = dateAxis33.getMaximumDate();
        dateAxis22.setMaximumDate(date34);
        categoryPlot6.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis22);
        java.awt.Paint paint37 = dateAxis22.getTickLabelPaint();
        piePlot0.setBaseSectionPaint(paint37);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(valueAxis17);
        org.junit.Assert.assertNull(axisSpace19);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0d + "'", double31 == 1.0d);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(paint37);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = null;
        org.jfree.chart.text.TextBlock textBlock3 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint2);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = textBlock3.getLineAlignment();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.Font font9 = null;
        java.awt.Paint paint10 = null;
        org.jfree.chart.text.TextBlock textBlock11 = org.jfree.chart.text.TextUtilities.createTextBlock("", font9, paint10);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor15 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        java.awt.Shape shape19 = textBlock11.calculateBounds(graphics2D12, 0.0f, (float) (short) 0, textBlockAnchor15, (float) (byte) 10, (float) 15, (double) 0L);
        textBlock3.draw(graphics2D5, 0.0f, (float) (byte) 10, textBlockAnchor15);
        org.jfree.chart.text.TextLine textLine21 = textBlock3.getLastLine();
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer26 = null;
        org.jfree.chart.plot.PolarPlot polarPlot27 = new org.jfree.chart.plot.PolarPlot(xYDataset23, (org.jfree.chart.axis.ValueAxis) dateAxis25, polarItemRenderer26);
        dateAxis25.setLabelAngle((double) (byte) 1);
        java.awt.Font font30 = dateAxis25.getTickLabelFont();
        org.jfree.chart.text.TextLine textLine31 = new org.jfree.chart.text.TextLine("", font30);
        textBlock3.addLine(textLine31);
        java.lang.Object obj33 = null;
        boolean boolean34 = textBlock3.equals(obj33);
        org.junit.Assert.assertNotNull(textBlock3);
        org.junit.Assert.assertNotNull(horizontalAlignment4);
        org.junit.Assert.assertNotNull(textBlock11);
        org.junit.Assert.assertNotNull(textBlockAnchor15);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNull(textLine21);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = null;
        dateAxis1.setStandardTickUnits(tickUnitSource2);
        dateAxis1.setFixedAutoRange((double) 100L);
        java.awt.Font font6 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        dateAxis1.setLabelFont(font6);
        dateAxis1.setAxisLineVisible(false);
        dateAxis1.setTickMarksVisible(false);
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer15 = null;
        org.jfree.chart.plot.PolarPlot polarPlot16 = new org.jfree.chart.plot.PolarPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) dateAxis14, polarItemRenderer15);
        dateAxis14.setLabelAngle((double) (byte) 1);
        dateAxis14.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int22 = color21.getAlpha();
        dateAxis14.setTickLabelPaint((java.awt.Paint) color21);
        double double24 = dateAxis14.getFixedAutoRange();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = dateAxis14.getTickLabelInsets();
        double double27 = rectangleInsets25.calculateRightOutset((double) (byte) -1);
        dateAxis1.setLabelInsets(rectangleInsets25);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 255 + "'", int22 == 255);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 4.0d + "'", double27 == 4.0d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int2 = color1.getAlpha();
        java.lang.String str3 = color1.toString();
        piePlot0.setLabelPaint((java.awt.Paint) color1);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator5 = piePlot0.getLabelGenerator();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent6 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot0);
        piePlot0.setLabelLinkMargin((-16.0d));
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 255 + "'", int2 == 255);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str3.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator5);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot4);
        java.awt.geom.Rectangle2D rectangle2D6 = legendTitle5.getBounds();
        java.awt.Paint paint7 = legendTitle5.getItemPaint();
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        xYPlot21.zoomRangeAxes((double) ' ', plotRenderingInfo23, point2D24);
        java.awt.Stroke stroke26 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot21.setDomainGridlineStroke(stroke26);
        org.jfree.chart.axis.ValueAxis valueAxis28 = xYPlot21.getDomainAxis();
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer33 = null;
        org.jfree.chart.plot.PolarPlot polarPlot34 = new org.jfree.chart.plot.PolarPlot(xYDataset30, (org.jfree.chart.axis.ValueAxis) dateAxis32, polarItemRenderer33);
        dateAxis32.setLabelAngle((double) (byte) 1);
        dateAxis32.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color39 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int40 = color39.getAlpha();
        java.lang.String str41 = color39.toString();
        dateAxis32.setTickMarkPaint((java.awt.Paint) color39);
        org.jfree.chart.plot.PiePlot piePlot43 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = piePlot43.getSimpleLabelOffset();
        java.awt.Stroke stroke45 = piePlot43.getLabelOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker46 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, (java.awt.Paint) color39, stroke45);
        java.awt.Paint paint47 = valueMarker46.getOutlinePaint();
        java.awt.Font font48 = valueMarker46.getLabelFont();
        try {
            boolean boolean49 = xYPlot21.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(valueAxis28);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 255 + "'", int40 == 255);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str41.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(font48);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.Object obj1 = categoryPlot0.clone();
        org.jfree.chart.util.SortOrder sortOrder2 = categoryPlot0.getRowRenderingOrder();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(sortOrder2);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo7 = new org.jfree.chart.ui.BasicProjectInfo("java.awt.Color[r=255,g=255,b=64]", "hi!", "", "java.awt.Color[r=255,g=255,b=64]");
        org.jfree.chart.ui.ProjectInfo projectInfo8 = org.jfree.chart.JFreeChart.INFO;
        basicProjectInfo7.addLibrary((org.jfree.chart.ui.Library) projectInfo8);
        org.jfree.chart.ui.ProjectInfo projectInfo10 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str11 = projectInfo10.toString();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo17 = new org.jfree.chart.ui.BasicProjectInfo("", "java.awt.Color[r=255,g=255,b=64]", "", "java.awt.Color[r=255,g=255,b=64]", "java.awt.Color[r=255,g=255,b=64]");
        projectInfo10.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo17);
        java.awt.Image image19 = projectInfo10.getLogo();
        projectInfo8.setLogo(image19);
        org.jfree.chart.ui.ProjectInfo projectInfo24 = new org.jfree.chart.ui.ProjectInfo("RectangleInsets[t=0.0,l=2.0,b=100.0,r=1.0]", "ClassContext", "RectangleAnchor.BOTTOM_LEFT", image19, "ClassContext", "RectangleInsets[t=0.0,l=2.0,b=100.0,r=1.0]", "LengthConstraintType.NONE");
        org.junit.Assert.assertNotNull(projectInfo8);
        org.junit.Assert.assertNotNull(projectInfo10);
        org.junit.Assert.assertNotNull(image19);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        java.awt.Stroke stroke22 = xYPlot21.getDomainZeroBaselineStroke();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        xYPlot21.setRenderer((int) (byte) 0, xYItemRenderer24, false);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        xYPlot21.setDomainAxis((int) (byte) 1, valueAxis28);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint1 = lineBorder0.getPaint();
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("PlotOrientation.VERTICAL", "Polar Plot");
        java.lang.String str3 = contributor2.getEmail();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Polar Plot" + "'", str3.equals("Polar Plot"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        java.lang.String str2 = textTitle1.getToolTipText();
        java.awt.Paint paint3 = textTitle1.getBackgroundPaint();
        double double4 = textTitle1.getContentXOffset();
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = blockBorder5.getInsets();
        textTitle1.setFrame((org.jfree.chart.block.BlockFrame) blockBorder5);
        textTitle1.setPadding((double) (byte) 1, (double) 0.5f, (double) (short) 100, (double) (short) 1);
        boolean boolean13 = textTitle1.getExpandToFitSpace();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.clearDomainMarkers(15);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        float float26 = categoryPlot25.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot25.getRangeAxisLocation();
        xYPlot21.setDomainAxisLocation((int) (byte) 0, axisLocation27, true);
        java.awt.Stroke stroke30 = xYPlot21.getRangeGridlineStroke();
        java.awt.Paint paint31 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot21.setDomainZeroBaselinePaint(paint31);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent33 = null;
        xYPlot21.notifyListeners(plotChangeEvent33);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder35 = xYPlot21.getSeriesRenderingOrder();
        org.jfree.data.xy.XYDataset xYDataset37 = null;
        try {
            xYPlot21.setDataset((-16777216), xYDataset37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 1.0f + "'", float26 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(seriesRenderingOrder35);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        float float2 = categoryPlot0.getBackgroundImageAlpha();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        float float4 = categoryPlot3.getForegroundAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        categoryPlot3.setRangeAxis((int) '4', valueAxis6, false);
        categoryPlot3.configureRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer15 = null;
        org.jfree.chart.plot.PolarPlot polarPlot16 = new org.jfree.chart.plot.PolarPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) dateAxis14, polarItemRenderer15);
        dateAxis14.setLabelAngle((double) (byte) 1);
        dateAxis14.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int22 = color21.getAlpha();
        java.lang.String str23 = color21.toString();
        dateAxis14.setTickMarkPaint((java.awt.Paint) color21);
        org.jfree.chart.plot.PiePlot piePlot25 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = piePlot25.getSimpleLabelOffset();
        java.awt.Stroke stroke27 = piePlot25.getLabelOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker28 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, (java.awt.Paint) color21, stroke27);
        org.jfree.chart.util.Layer layer29 = null;
        categoryPlot3.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker28, layer29);
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource33 = null;
        dateAxis32.setStandardTickUnits(tickUnitSource33);
        java.awt.Stroke stroke35 = dateAxis32.getTickMarkStroke();
        valueMarker28.setStroke(stroke35);
        categoryPlot0.setRangeGridlineStroke(stroke35);
        double double38 = categoryPlot0.getAnchorValue();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.5f + "'", float2 == 0.5f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 255 + "'", int22 == 255);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str23.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.clearDomainMarkers(15);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        float float26 = categoryPlot25.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot25.getRangeAxisLocation();
        xYPlot21.setDomainAxisLocation((int) (byte) 0, axisLocation27, true);
        double double30 = xYPlot21.getRangeCrosshairValue();
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 1.0f + "'", float26 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        int int5 = polarPlot4.getBackgroundImageAlignment();
        boolean boolean6 = polarPlot4.isSubplot();
        boolean boolean7 = polarPlot4.isDomainZoomable();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        polarPlot4.zoomRangeAxes((double) 0.0f, plotRenderingInfo9, point2D10);
        java.awt.Font font12 = polarPlot4.getAngleLabelFont();
        boolean boolean13 = polarPlot4.isDomainZoomable();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 100, 0.4d);
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((double) '#', (org.jfree.data.Range) dateRange4);
        org.jfree.data.Range range8 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange4, (double) 1.0f, false);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = rectangleConstraint2.toRangeHeight(range8);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = rectangleConstraint9.toFixedHeight(0.0d);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(rectangleConstraint9);
        org.junit.Assert.assertNotNull(rectangleConstraint11);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.data.time.DateRange dateRange1 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) '#', (org.jfree.data.Range) dateRange1);
        org.jfree.data.Range range5 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange1, (double) 1.0f, false);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 100, 0.4d);
        org.jfree.data.time.DateRange dateRange10 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = new org.jfree.chart.block.RectangleConstraint((double) '#', (org.jfree.data.Range) dateRange10);
        org.jfree.data.Range range14 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange10, (double) 1.0f, false);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint8.toRangeHeight(range14);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange1, range14);
        org.jfree.data.Range range17 = rectangleConstraint16.getWidthRange();
        double double18 = rectangleConstraint16.getHeight();
        org.junit.Assert.assertNotNull(dateRange1);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(dateRange10);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        java.lang.String str2 = textTitle1.getToolTipText();
        java.awt.Paint paint3 = textTitle1.getBackgroundPaint();
        textTitle1.setToolTipText("java.awt.Color[r=255,g=255,b=64]");
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) dateAxis9, polarItemRenderer10);
        int int12 = polarPlot11.getBackgroundImageAlignment();
        boolean boolean13 = polarPlot11.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) polarPlot11);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        java.awt.image.BufferedImage bufferedImage18 = jFreeChart14.createBufferedImage(100, 255, chartRenderingInfo17);
        jFreeChart14.removeLegend();
        java.awt.Stroke stroke20 = jFreeChart14.getBorderStroke();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType21 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent22 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) "java.awt.Color[r=255,g=255,b=64]", jFreeChart14, chartChangeEventType21);
        jFreeChart14.setBackgroundImageAlpha((float) 255);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 15 + "'", int12 == 15);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(bufferedImage18);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        org.jfree.data.Range range5 = dateAxis2.getRange();
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent9 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) range5, jFreeChart6, 255, (int) (short) 10);
        chartProgressEvent9.setPercent((int) (short) -1);
        org.junit.Assert.assertNotNull(range5);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        org.jfree.chart.event.PlotChangeListener plotChangeListener22 = null;
        xYPlot21.removeChangeListener(plotChangeListener22);
        xYPlot21.clearDomainMarkers((int) (byte) 1);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        java.awt.Font font3 = null;
        java.awt.Paint paint4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, paint4);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = textBlock5.getLineAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement10 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment6, verticalAlignment7, (double) 100, 0.0d);
        textTitle1.setHorizontalAlignment(horizontalAlignment6);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = org.jfree.chart.block.RectangleConstraint.NONE;
        try {
            org.jfree.chart.util.Size2D size2D14 = textTitle1.arrange(graphics2D12, rectangleConstraint13);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation();
        boolean boolean3 = categoryPlot0.isDomainGridlinesVisible();
        java.lang.Object obj4 = categoryPlot0.clone();
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = null;
        try {
            categoryPlot0.addDomainMarker(categoryMarker5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.data.time.DateRange dateRange2 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = new org.jfree.chart.block.RectangleConstraint((double) '#', (org.jfree.data.Range) dateRange2);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = new org.jfree.chart.block.RectangleConstraint(10.0d, (org.jfree.data.Range) dateRange2);
        org.jfree.data.Range range5 = rectangleConstraint4.getWidthRange();
        org.junit.Assert.assertNotNull(dateRange2);
        org.junit.Assert.assertNull(range5);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.clearDomainMarkers(15);
        org.jfree.chart.LegendItemCollection legendItemCollection24 = xYPlot21.getFixedLegendItems();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = xYPlot21.getAxisOffset();
        boolean boolean26 = xYPlot21.isDomainGridlinesVisible();
        xYPlot21.setRangeCrosshairValue(10.0d);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertNull(legendItemCollection24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        piePlotState1.setTotal((double) (short) 0);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) dateAxis6, polarItemRenderer7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot8);
        java.awt.geom.Rectangle2D rectangle2D10 = legendTitle9.getBounds();
        piePlotState1.setLinkArea(rectangle2D10);
        double double12 = piePlotState1.getPieHRadius();
        double double13 = piePlotState1.getPieHRadius();
        java.awt.geom.Rectangle2D rectangle2D14 = piePlotState1.getPieArea();
        java.awt.geom.Rectangle2D rectangle2D15 = piePlotState1.getExplodedPieArea();
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNull(rectangle2D14);
        org.junit.Assert.assertNull(rectangle2D15);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        boolean boolean2 = piePlot3D1.getDarkerSides();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.awt.geom.Point2D point2D5 = null;
        org.jfree.chart.plot.PlotState plotState6 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        try {
            piePlot3D1.draw(graphics2D3, rectangle2D4, point2D5, plotState6, plotRenderingInfo7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Size2D[width=0.0, height=0.0]");
        double double2 = numberAxis1.getUpperMargin();
        java.lang.String str3 = numberAxis1.getLabel();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis1.setTickUnit(numberTickUnit4);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str3.equals("Size2D[width=0.0, height=0.0]"));
        org.junit.Assert.assertNotNull(numberTickUnit4);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("RectangleInsets[t=0.0,l=2.0,b=100.0,r=1.0]", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        dateAxis2.setLabelAngle((double) (byte) 1);
        dateAxis2.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int10 = color9.getAlpha();
        dateAxis2.setTickLabelPaint((java.awt.Paint) color9);
        java.util.TimeZone timeZone12 = dateAxis2.getTimeZone();
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 255 + "'", int10 == 255);
        org.junit.Assert.assertNotNull(timeZone12);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis((int) '4', valueAxis3, false);
        categoryPlot0.configureRangeAxes();
        int int7 = categoryPlot0.getDatasetCount();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        java.lang.Comparable comparable4 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 255, (-16056329), comparable4, "java.awt.Color[r=255,g=255,b=64]", "ClassContext");
        org.jfree.data.general.PieDataset pieDataset8 = pieSectionEntity7.getDataset();
        java.lang.String str9 = pieSectionEntity7.getURLText();
        java.lang.String str10 = pieSectionEntity7.getShapeCoords();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNull(pieDataset8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ClassContext" + "'", str9.equals("ClassContext"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0" + "'", str10.equals("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0"));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        java.awt.Paint paint1 = waferMapPlot0.getBackgroundPaint();
        java.awt.Paint paint2 = waferMapPlot0.getOutlinePaint();
        org.jfree.data.general.WaferMapDataset waferMapDataset3 = waferMapPlot0.getDataset();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(waferMapDataset3);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        double double5 = dateAxis2.getLabelAngle();
        dateAxis2.setVerticalTickLabels(false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis((int) '4', valueAxis3, false);
        categoryPlot0.configureRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer12 = null;
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) dateAxis11, polarItemRenderer12);
        dateAxis11.setLabelAngle((double) (byte) 1);
        dateAxis11.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int19 = color18.getAlpha();
        java.lang.String str20 = color18.toString();
        dateAxis11.setTickMarkPaint((java.awt.Paint) color18);
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = piePlot22.getSimpleLabelOffset();
        java.awt.Stroke stroke24 = piePlot22.getLabelOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, (java.awt.Paint) color18, stroke24);
        org.jfree.chart.util.Layer layer26 = null;
        categoryPlot0.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker25, layer26);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        java.awt.geom.Point2D point2D30 = null;
        categoryPlot0.zoomRangeAxes(32.0d, plotRenderingInfo29, point2D30, true);
        categoryPlot0.clearDomainMarkers();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent34 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent34);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 255 + "'", int19 == 255);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str20.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke24);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("ClassContext");
        numberAxis3D1.setLabel("RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]");
        org.jfree.data.Range range4 = numberAxis3D1.getDefaultAutoRange();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = null;
        dateAxis6.setStandardTickUnits(tickUnitSource7);
        java.awt.Shape shape9 = dateAxis6.getRightArrow();
        numberAxis3D1.setDownArrow(shape9);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D12 = new org.jfree.chart.axis.NumberAxis3D("ClassContext");
        boolean boolean13 = numberAxis3D12.isVisible();
        org.jfree.data.RangeType rangeType14 = numberAxis3D12.getRangeType();
        numberAxis3D1.setRangeType(rangeType14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        org.jfree.chart.plot.PiePlotState piePlotState18 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo17);
        piePlotState18.setTotal((double) (short) 0);
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer24 = null;
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot(xYDataset21, (org.jfree.chart.axis.ValueAxis) dateAxis23, polarItemRenderer24);
        org.jfree.chart.title.LegendTitle legendTitle26 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot25);
        java.awt.geom.Rectangle2D rectangle2D27 = legendTitle26.getBounds();
        piePlotState18.setLinkArea(rectangle2D27);
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        float float30 = categoryPlot29.getForegroundAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        categoryPlot29.setRangeAxis((int) '4', valueAxis32, false);
        org.jfree.chart.axis.AxisLocation axisLocation35 = categoryPlot29.getRangeAxisLocation();
        org.jfree.chart.plot.PlotOrientation plotOrientation36 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        java.lang.String str37 = plotOrientation36.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation35, plotOrientation36);
        double double39 = numberAxis3D1.valueToJava2D((double) (-16056329), rectangle2D27, rectangleEdge38);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(rangeType14);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 1.0f + "'", float30 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertNotNull(plotOrientation36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "PlotOrientation.VERTICAL" + "'", str37.equals("PlotOrientation.VERTICAL"));
        org.junit.Assert.assertNotNull(rectangleEdge38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        int int5 = polarPlot4.getBackgroundImageAlignment();
        boolean boolean6 = polarPlot4.isSubplot();
        polarPlot4.setBackgroundImageAlignment(0);
        polarPlot4.removeCornerTextItem("Size2D[width=0.0, height=0.0]");
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        polarPlot4.setDataset(xYDataset11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer16 = null;
        org.jfree.chart.plot.PolarPlot polarPlot17 = new org.jfree.chart.plot.PolarPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis15, polarItemRenderer16);
        int int18 = polarPlot17.getBackgroundImageAlignment();
        boolean boolean19 = polarPlot17.isSubplot();
        java.awt.Color color20 = java.awt.Color.blue;
        polarPlot17.setAngleLabelPaint((java.awt.Paint) color20);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = polarPlot17.getInsets();
        java.awt.Stroke stroke23 = polarPlot17.getRadiusGridlineStroke();
        polarPlot4.setAngleGridlineStroke(stroke23);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor25 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        org.jfree.chart.plot.PiePlot piePlot26 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = piePlot26.getSimpleLabelOffset();
        boolean boolean28 = textBlockAnchor25.equals((java.lang.Object) piePlot26);
        boolean boolean29 = polarPlot4.equals((java.lang.Object) textBlockAnchor25);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 15 + "'", int18 == 15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(textBlockAnchor25);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.lang.Object obj1 = categoryAxis3D0.clone();
        categoryAxis3D0.setLowerMargin((double) (byte) 1);
        categoryAxis3D0.setUpperMargin((-1.0d));
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        java.util.List list2 = categoryPlot0.getAnnotations();
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = null;
        try {
            categoryPlot0.addDomainMarker(categoryMarker3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        java.awt.Stroke stroke22 = xYPlot21.getDomainZeroBaselineStroke();
        java.awt.Color color23 = java.awt.Color.BLUE;
        xYPlot21.setDomainGridlinePaint((java.awt.Paint) color23);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        float float27 = categoryPlot26.getForegroundAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        categoryPlot26.setRangeAxis((int) '4', valueAxis29, false);
        org.jfree.chart.axis.AxisLocation axisLocation32 = categoryPlot26.getRangeAxisLocation();
        org.jfree.chart.plot.PlotOrientation plotOrientation33 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        java.lang.String str34 = plotOrientation33.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation32, plotOrientation33);
        xYPlot21.setDomainAxisLocation(8, axisLocation32, false);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 1.0f + "'", float27 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertNotNull(plotOrientation33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "PlotOrientation.VERTICAL" + "'", str34.equals("PlotOrientation.VERTICAL"));
        org.junit.Assert.assertNotNull(rectangleEdge35);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = categoryPlot0.getRenderer(255);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        categoryPlot0.setDataset(categoryDataset4);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = categoryPlot0.getDrawingSupplier();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) dateAxis9, polarItemRenderer10);
        dateAxis9.setLabelAngle((double) (byte) 1);
        dateAxis9.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int17 = color16.getAlpha();
        java.lang.String str18 = color16.toString();
        dateAxis9.setTickMarkPaint((java.awt.Paint) color16);
        org.jfree.data.Range range20 = dateAxis9.getDefaultAutoRange();
        boolean boolean21 = dateAxis9.isTickMarksVisible();
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = piePlot23.getSimpleLabelOffset();
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer28 = null;
        org.jfree.chart.plot.PolarPlot polarPlot29 = new org.jfree.chart.plot.PolarPlot(xYDataset25, (org.jfree.chart.axis.ValueAxis) dateAxis27, polarItemRenderer28);
        org.jfree.chart.title.LegendTitle legendTitle30 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot29);
        java.awt.geom.Rectangle2D rectangle2D31 = legendTitle30.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType32 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = rectangleInsets24.createAdjustedRectangle(rectangle2D31, lengthAdjustmentType32, lengthAdjustmentType33);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean36 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge35);
        double double37 = dateAxis9.java2DToValue((double) 8, rectangle2D34, rectangleEdge35);
        boolean boolean38 = categoryPlot0.equals((java.lang.Object) 8);
        java.util.List list39 = categoryPlot0.getAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset40 = categoryPlot0.getDataset();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNull(categoryItemRenderer3);
        org.junit.Assert.assertNotNull(drawingSupplier6);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 255 + "'", int17 == 255);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str18.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 9.223372036854776E18d + "'", double37 == 9.223372036854776E18d);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(list39);
        org.junit.Assert.assertNull(categoryDataset40);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) dateAxis4, polarItemRenderer5);
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot6);
        java.awt.Color color8 = java.awt.Color.green;
        java.awt.Color color9 = color8.darker();
        legendTitle7.setBackgroundPaint((java.awt.Paint) color8);
        java.lang.Class<?> wildcardClass11 = legendTitle7.getClass();
        java.lang.Object obj12 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("PlotOrientation.VERTICAL", (java.lang.Class) wildcardClass11);
        java.net.URL uRL13 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("RectangleAnchor.BOTTOM_LEFT", (java.lang.Class) wildcardClass11);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNull(obj12);
        org.junit.Assert.assertNull(uRL13);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        java.lang.Comparable comparable4 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 255, (-16056329), comparable4, "java.awt.Color[r=255,g=255,b=64]", "ClassContext");
        org.jfree.data.general.PieDataset pieDataset8 = pieSectionEntity7.getDataset();
        java.lang.String str9 = pieSectionEntity7.getURLText();
        int int10 = pieSectionEntity7.getPieIndex();
        pieSectionEntity7.setPieIndex(0);
        pieSectionEntity7.setURLText("RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=0.4]");
        java.lang.String str15 = pieSectionEntity7.getShapeType();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNull(pieDataset8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ClassContext" + "'", str9.equals("ClassContext"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 255 + "'", int10 == 255);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "poly" + "'", str15.equals("poly"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double1 = rectangleInsets0.getRight();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            rectangleInsets0.trim(rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        int int5 = polarPlot4.getBackgroundImageAlignment();
        boolean boolean6 = polarPlot4.isSubplot();
        boolean boolean7 = polarPlot4.isDomainZoomable();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        polarPlot4.zoomRangeAxes((double) 0.0f, plotRenderingInfo9, point2D10);
        org.jfree.chart.plot.Plot plot12 = polarPlot4.getRootPlot();
        org.jfree.chart.block.ColumnArrangement columnArrangement13 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer18 = null;
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) dateAxis17, polarItemRenderer18);
        org.jfree.chart.plot.PiePlot piePlot20 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = piePlot20.getSimpleLabelOffset();
        double double22 = rectangleInsets21.getRight();
        dateAxis17.setLabelInsets(rectangleInsets21);
        dateAxis17.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("");
        dateAxis28.setRange((double) 0.0f, (double) 10.0f);
        dateAxis28.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset14, (org.jfree.chart.axis.ValueAxis) dateAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis28, xYItemRenderer34);
        xYPlot35.clearDomainMarkers(15);
        org.jfree.data.xy.XYDataset xYDataset38 = null;
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer41 = null;
        org.jfree.chart.plot.PolarPlot polarPlot42 = new org.jfree.chart.plot.PolarPlot(xYDataset38, (org.jfree.chart.axis.ValueAxis) dateAxis40, polarItemRenderer41);
        dateAxis40.setLabelAngle((double) (byte) 1);
        dateAxis40.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color47 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int48 = color47.getAlpha();
        dateAxis40.setTickLabelPaint((java.awt.Paint) color47);
        dateAxis40.setInverted(false);
        double double52 = dateAxis40.getLowerBound();
        org.jfree.data.Range range53 = xYPlot35.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis40);
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = xYPlot35.getRangeAxisEdge();
        boolean boolean55 = columnArrangement13.equals((java.lang.Object) rectangleEdge54);
        org.jfree.chart.block.FlowArrangement flowArrangement56 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.LegendTitle legendTitle57 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot4, (org.jfree.chart.block.Arrangement) columnArrangement13, (org.jfree.chart.block.Arrangement) flowArrangement56);
        flowArrangement56.clear();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(plot12);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.18d + "'", double22 == 0.18d);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 255 + "'", int48 == 255);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNull(range53);
        org.junit.Assert.assertNotNull(rectangleEdge54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = piePlot0.getSimpleLabelOffset();
        boolean boolean2 = piePlot0.getSectionOutlinesVisible();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator3 = null;
        piePlot0.setLegendLabelURLGenerator(pieURLGenerator3);
        boolean boolean5 = piePlot0.getSimpleLabels();
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint7 = ringPlot6.getShadowPaint();
        ringPlot6.setInteriorGap((double) (byte) 0);
        java.awt.Font font10 = ringPlot6.getNoDataMessageFont();
        piePlot0.setLabelFont(font10);
        piePlot0.setShadowYOffset(100.0d);
        double double14 = piePlot0.getInteriorGap();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.08d + "'", double14 == 0.08d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot4);
        org.jfree.chart.block.BlockContainer blockContainer6 = legendTitle5.getItemContainer();
        org.jfree.chart.block.Arrangement arrangement7 = blockContainer6.getArrangement();
        org.jfree.chart.block.BlockContainer blockContainer8 = new org.jfree.chart.block.BlockContainer(arrangement7);
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("hi!");
        java.lang.String str11 = textTitle10.getToolTipText();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = textTitle10.getHorizontalAlignment();
        blockContainer8.add((org.jfree.chart.block.Block) textTitle10);
        org.jfree.chart.block.Arrangement arrangement14 = blockContainer8.getArrangement();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot(xYDataset16, (org.jfree.chart.axis.ValueAxis) dateAxis18, polarItemRenderer19);
        int int21 = polarPlot20.getBackgroundImageAlignment();
        boolean boolean22 = polarPlot20.isSubplot();
        boolean boolean23 = polarPlot20.isDomainZoomable();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        polarPlot20.zoomRangeAxes((double) 0.0f, plotRenderingInfo25, point2D26);
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer31 = null;
        org.jfree.chart.plot.PolarPlot polarPlot32 = new org.jfree.chart.plot.PolarPlot(xYDataset28, (org.jfree.chart.axis.ValueAxis) dateAxis30, polarItemRenderer31);
        dateAxis30.setLabelAngle((double) (byte) 1);
        dateAxis30.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color37 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int38 = color37.getAlpha();
        java.lang.String str39 = color37.toString();
        dateAxis30.setTickMarkPaint((java.awt.Paint) color37);
        polarPlot20.setAngleGridlinePaint((java.awt.Paint) color37);
        org.jfree.chart.block.BlockBorder blockBorder42 = new org.jfree.chart.block.BlockBorder(rectangleInsets15, (java.awt.Paint) color37);
        blockContainer8.setPadding(rectangleInsets15);
        org.junit.Assert.assertNotNull(blockContainer6);
        org.junit.Assert.assertNotNull(arrangement7);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(horizontalAlignment12);
        org.junit.Assert.assertNotNull(arrangement14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 15 + "'", int21 == 15);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 255 + "'", int38 == 255);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str39.equals("java.awt.Color[r=255,g=255,b=64]"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        dateAxis2.setLabelAngle((double) (byte) 1);
        dateAxis2.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int10 = color9.getAlpha();
        dateAxis2.setTickLabelPaint((java.awt.Paint) color9);
        dateAxis2.setRange(0.4d, (double) 100L);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer18 = null;
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) dateAxis17, polarItemRenderer18);
        org.jfree.chart.plot.PiePlot piePlot20 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = piePlot20.getSimpleLabelOffset();
        double double22 = rectangleInsets21.getRight();
        dateAxis17.setLabelInsets(rectangleInsets21);
        java.awt.Shape shape24 = dateAxis17.getLeftArrow();
        dateAxis17.setAxisLineVisible(false);
        dateAxis17.setLabel("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit29 = dateAxis17.getTickUnit();
        dateAxis2.setTickUnit(dateTickUnit29);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 255 + "'", int10 == 255);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.18d + "'", double22 == 0.18d);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(dateTickUnit29);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int2 = color1.getAlpha();
        java.lang.String str3 = color1.toString();
        piePlot0.setLabelPaint((java.awt.Paint) color1);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator5 = piePlot0.getLegendLabelToolTipGenerator();
        double double6 = piePlot0.getShadowYOffset();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 255 + "'", int2 == 255);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str3.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNull(pieSectionLabelGenerator5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        dateAxis1.setRange((double) 0.0f, (double) 10.0f);
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) dateAxis9, polarItemRenderer10);
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot11);
        org.jfree.chart.block.BlockContainer blockContainer13 = legendTitle12.getItemContainer();
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = piePlot14.getSimpleLabelOffset();
        boolean boolean16 = piePlot14.getSectionOutlinesVisible();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator17 = null;
        piePlot14.setLegendLabelURLGenerator(pieURLGenerator17);
        boolean boolean19 = piePlot14.getSimpleLabels();
        org.jfree.chart.plot.RingPlot ringPlot20 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint21 = ringPlot20.getShadowPaint();
        ringPlot20.setInteriorGap((double) (byte) 0);
        java.awt.Font font24 = ringPlot20.getNoDataMessageFont();
        piePlot14.setLabelFont(font24);
        legendTitle12.setItemFont(font24);
        org.jfree.chart.util.Size2D size2D29 = new org.jfree.chart.util.Size2D((double) ' ', 0.0d);
        size2D29.height = ' ';
        java.awt.Paint paint32 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        boolean boolean33 = size2D29.equals((java.lang.Object) paint32);
        org.jfree.chart.text.TextFragment textFragment35 = new org.jfree.chart.text.TextFragment("RectangleEdge.LEFT", font24, paint32, (float) 'a');
        org.jfree.chart.plot.PiePlot piePlot36 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = piePlot36.getSimpleLabelOffset();
        boolean boolean38 = piePlot36.getSectionOutlinesVisible();
        java.awt.Paint paint39 = piePlot36.getBaseSectionPaint();
        org.jfree.chart.text.TextBlock textBlock40 = org.jfree.chart.text.TextUtilities.createTextBlock("Polar Plot", font24, paint39);
        dateAxis1.setTickLabelFont(font24);
        org.junit.Assert.assertNotNull(blockContainer13);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(textBlock40);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = categoryPlot0.getRenderer(255);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        categoryPlot0.setDataset(categoryDataset4);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = categoryPlot0.getDrawingSupplier();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent7 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent7);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNull(categoryItemRenderer3);
        org.junit.Assert.assertNotNull(drawingSupplier6);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        dateAxis3.setLabelAngle((double) (byte) 1);
        java.awt.Font font8 = dateAxis3.getTickLabelFont();
        org.jfree.chart.text.TextLine textLine9 = new org.jfree.chart.text.TextLine("", font8);
        org.jfree.chart.text.TextFragment textFragment10 = textLine9.getLastTextFragment();
        java.awt.Graphics2D graphics2D11 = null;
        try {
            org.jfree.chart.util.Size2D size2D12 = textFragment10.calculateDimensions(graphics2D11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(textFragment10);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation();
        boolean boolean3 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("Size2D[width=0.0, height=0.0]");
        numberAxis5.setAutoRangeStickyZero(true);
        numberAxis5.setInverted(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        float float11 = categoryPlot10.getForegroundAlpha();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = categoryPlot10.getRenderer(255);
        java.awt.Stroke stroke14 = categoryPlot10.getDomainGridlineStroke();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor15 = categoryPlot10.getDomainGridlinePosition();
        numberAxis5.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot10);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer21 = null;
        org.jfree.chart.plot.PolarPlot polarPlot22 = new org.jfree.chart.plot.PolarPlot(xYDataset18, (org.jfree.chart.axis.ValueAxis) dateAxis20, polarItemRenderer21);
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = piePlot23.getSimpleLabelOffset();
        double double25 = rectangleInsets24.getRight();
        dateAxis20.setLabelInsets(rectangleInsets24);
        dateAxis20.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("");
        dateAxis31.setRange((double) 0.0f, (double) 10.0f);
        dateAxis31.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer37 = null;
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot(xYDataset17, (org.jfree.chart.axis.ValueAxis) dateAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis31, xYItemRenderer37);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = null;
        java.awt.geom.Point2D point2D41 = null;
        xYPlot38.zoomRangeAxes((double) ' ', plotRenderingInfo40, point2D41);
        java.awt.Paint paint43 = xYPlot38.getDomainTickBandPaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent44 = null;
        xYPlot38.rendererChanged(rendererChangeEvent44);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray46 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot38.setRenderers(xYItemRendererArray46);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder48 = xYPlot38.getDatasetRenderingOrder();
        categoryPlot10.setDatasetRenderingOrder(datasetRenderingOrder48);
        categoryPlot0.setDatasetRenderingOrder(datasetRenderingOrder48);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer51 = null;
        categoryPlot0.setRenderer(categoryItemRenderer51, false);
        org.jfree.chart.util.SortOrder sortOrder54 = categoryPlot0.getColumnRenderingOrder();
        org.jfree.chart.axis.AxisSpace axisSpace55 = categoryPlot0.getFixedRangeAxisSpace();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 1.0f + "'", float11 == 1.0f);
        org.junit.Assert.assertNull(categoryItemRenderer13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(categoryAnchor15);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.18d + "'", double25 == 0.18d);
        org.junit.Assert.assertNull(paint43);
        org.junit.Assert.assertNotNull(xYItemRendererArray46);
        org.junit.Assert.assertNotNull(datasetRenderingOrder48);
        org.junit.Assert.assertNotNull(sortOrder54);
        org.junit.Assert.assertNull(axisSpace55);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        java.lang.Comparable comparable4 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 255, (-16056329), comparable4, "java.awt.Color[r=255,g=255,b=64]", "ClassContext");
        org.jfree.data.general.PieDataset pieDataset8 = pieSectionEntity7.getDataset();
        java.lang.String str9 = pieSectionEntity7.getURLText();
        java.lang.String str10 = pieSectionEntity7.getToolTipText();
        java.lang.Comparable comparable11 = null;
        pieSectionEntity7.setSectionKey(comparable11);
        java.lang.Object obj13 = null;
        boolean boolean14 = pieSectionEntity7.equals(obj13);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNull(pieDataset8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ClassContext" + "'", str9.equals("ClassContext"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str10.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        boolean boolean2 = categoryPlot0.isDomainGridlinesVisible();
        int int3 = categoryPlot0.getRangeAxisCount();
        java.awt.Image image4 = categoryPlot0.getBackgroundImage();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNull(image4);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = categoryPlot0.getRenderer();
        java.lang.String str4 = categoryPlot0.getPlotType();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) dateAxis8, polarItemRenderer9);
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot10);
        java.awt.geom.Rectangle2D rectangle2D12 = legendTitle11.getBounds();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        boolean boolean15 = categoryPlot0.render(graphics2D5, rectangle2D12, (int) (byte) 1, plotRenderingInfo14);
        java.awt.Stroke stroke16 = categoryPlot0.getRangeGridlineStroke();
        java.util.List list17 = categoryPlot0.getAnnotations();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNull(categoryItemRenderer3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Category Plot" + "'", str4.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(list17);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = null;
        dateAxis1.setStandardTickUnits(tickUnitSource2);
        dateAxis1.setFixedAutoRange((double) 100L);
        boolean boolean6 = dateAxis1.isAutoTickUnitSelection();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D("ClassContext");
        numberAxis3D8.setLabel("RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]");
        org.jfree.data.Range range11 = numberAxis3D8.getDefaultAutoRange();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource14 = null;
        dateAxis13.setStandardTickUnits(tickUnitSource14);
        java.awt.Shape shape16 = dateAxis13.getRightArrow();
        numberAxis3D8.setDownArrow(shape16);
        boolean boolean18 = dateAxis1.equals((java.lang.Object) numberAxis3D8);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        boolean boolean2 = piePlot3D1.getDarkerSides();
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = piePlot4.getSimpleLabelOffset();
        boolean boolean6 = piePlot4.getSectionOutlinesVisible();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator7 = null;
        piePlot4.setLegendLabelURLGenerator(pieURLGenerator7);
        boolean boolean9 = piePlot4.getSimpleLabels();
        boolean boolean10 = piePlot4.getLabelLinksVisible();
        java.lang.String str11 = piePlot4.getPlotType();
        java.awt.Paint paint12 = piePlot4.getShadowPaint();
        piePlot3D1.setSectionOutlinePaint((java.lang.Comparable) 15, paint12);
        piePlot3D1.setDarkerSides(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Pie Plot" + "'", str11.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D1, (float) (-6553600), (float) 1L, textAnchor4, 1.0E-5d, textAnchor6);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertNull(shape7);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.clearDomainMarkers(15);
        org.jfree.chart.LegendItemCollection legendItemCollection24 = xYPlot21.getFixedLegendItems();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = xYPlot21.getAxisOffset();
        int int26 = xYPlot21.getRangeAxisCount();
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        xYPlot21.setDataset(2, xYDataset28);
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        int int31 = xYPlot21.indexOf(xYDataset30);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertNull(legendItemCollection24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        java.lang.Comparable comparable4 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 255, (-16056329), comparable4, "java.awt.Color[r=255,g=255,b=64]", "ClassContext");
        org.jfree.data.general.PieDataset pieDataset8 = pieSectionEntity7.getDataset();
        java.lang.String str9 = pieSectionEntity7.getURLText();
        java.lang.String str10 = pieSectionEntity7.getToolTipText();
        java.lang.Comparable comparable11 = null;
        pieSectionEntity7.setSectionKey(comparable11);
        java.lang.String str13 = pieSectionEntity7.getURLText();
        pieSectionEntity7.setURLText("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0");
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNull(pieDataset8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ClassContext" + "'", str9.equals("ClassContext"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str10.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ClassContext" + "'", str13.equals("ClassContext"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = categoryPlot0.getDomainAxisEdge(10);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNotNull(rectangleEdge5);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        dateAxis2.setLabelAngle((double) (byte) 1);
        dateAxis2.setTickMarkOutsideLength((-1.0f));
        dateAxis2.setFixedDimension(0.4d);
        double double11 = dateAxis2.getUpperBound();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("");
        java.util.Date date14 = dateAxis13.getMaximumDate();
        dateAxis2.setMaximumDate(date14);
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot(xYDataset16, (org.jfree.chart.axis.ValueAxis) dateAxis18, polarItemRenderer19);
        int int21 = polarPlot20.getBackgroundImageAlignment();
        boolean boolean22 = polarPlot20.isOutlineVisible();
        java.awt.Paint paint23 = polarPlot20.getRadiusGridlinePaint();
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer27 = null;
        org.jfree.chart.plot.PolarPlot polarPlot28 = new org.jfree.chart.plot.PolarPlot(xYDataset24, (org.jfree.chart.axis.ValueAxis) dateAxis26, polarItemRenderer27);
        org.jfree.chart.plot.PiePlot piePlot29 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = piePlot29.getSimpleLabelOffset();
        double double31 = rectangleInsets30.getRight();
        dateAxis26.setLabelInsets(rectangleInsets30);
        java.awt.Shape shape33 = dateAxis26.getLeftArrow();
        dateAxis26.setAxisLineVisible(false);
        dateAxis26.setLabel("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit38 = dateAxis26.getTickUnit();
        polarPlot20.setAngleTickUnit((org.jfree.chart.axis.TickUnit) dateTickUnit38);
        dateAxis2.setTickUnit(dateTickUnit38);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 15 + "'", int21 == 15);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.18d + "'", double31 == 0.18d);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(dateTickUnit38);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot4);
        org.jfree.chart.block.BlockContainer blockContainer6 = legendTitle5.getItemContainer();
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = piePlot7.getSimpleLabelOffset();
        boolean boolean9 = piePlot7.getSectionOutlinesVisible();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator10 = null;
        piePlot7.setLegendLabelURLGenerator(pieURLGenerator10);
        boolean boolean12 = piePlot7.getSimpleLabels();
        org.jfree.chart.plot.RingPlot ringPlot13 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint14 = ringPlot13.getShadowPaint();
        ringPlot13.setInteriorGap((double) (byte) 0);
        java.awt.Font font17 = ringPlot13.getNoDataMessageFont();
        piePlot7.setLabelFont(font17);
        legendTitle5.setItemFont(font17);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = legendTitle5.getPosition();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = null;
        try {
            legendTitle5.setHorizontalAlignment(horizontalAlignment21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'alignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(blockContainer6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(rectangleEdge20);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.clearDomainMarkers(15);
        org.jfree.chart.LegendItemCollection legendItemCollection24 = xYPlot21.getFixedLegendItems();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = xYPlot21.getAxisOffset();
        int int26 = xYPlot21.getRangeAxisCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        try {
            xYPlot21.handleClick(0, (int) (byte) 1, plotRenderingInfo29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertNull(legendItemCollection24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis((int) '4', valueAxis3, false);
        categoryPlot0.configureRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer12 = null;
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) dateAxis11, polarItemRenderer12);
        dateAxis11.setLabelAngle((double) (byte) 1);
        dateAxis11.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int19 = color18.getAlpha();
        java.lang.String str20 = color18.toString();
        dateAxis11.setTickMarkPaint((java.awt.Paint) color18);
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = piePlot22.getSimpleLabelOffset();
        java.awt.Stroke stroke24 = piePlot22.getLabelOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, (java.awt.Paint) color18, stroke24);
        org.jfree.chart.util.Layer layer26 = null;
        categoryPlot0.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker25, layer26);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        java.awt.geom.Point2D point2D30 = null;
        categoryPlot0.zoomRangeAxes(32.0d, plotRenderingInfo29, point2D30, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray33 = null;
        try {
            categoryPlot0.setRenderers(categoryItemRendererArray33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 255 + "'", int19 == 255);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str20.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke24);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("ClassContext");
        numberAxis3D1.setAutoRange(true);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = null;
        try {
            numberAxis3D1.setTickUnit(numberTickUnit4, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean2 = categoryPlot1.isDomainGridlinesVisible();
        boolean boolean3 = categoryPlot1.isDomainGridlinesVisible();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        boolean boolean8 = categoryPlot1.render(graphics2D4, rectangle2D5, (int) (byte) 10, plotRenderingInfo7);
        org.jfree.data.category.CategoryDataset categoryDataset10 = categoryPlot1.getDataset((int) ' ');
        org.jfree.chart.util.SortOrder sortOrder11 = categoryPlot1.getRowRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("ClassContext", (org.jfree.chart.plot.Plot) categoryPlot1);
        int int13 = categoryPlot1.getRangeAxisCount();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(categoryDataset10);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = lineBorder0.getInsets();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = lineBorder0.getInsets();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        int int5 = polarPlot4.getBackgroundImageAlignment();
        double double6 = polarPlot4.getMaxRadius();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.clearDomainMarkers(15);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer27 = null;
        org.jfree.chart.plot.PolarPlot polarPlot28 = new org.jfree.chart.plot.PolarPlot(xYDataset24, (org.jfree.chart.axis.ValueAxis) dateAxis26, polarItemRenderer27);
        dateAxis26.setLabelAngle((double) (byte) 1);
        dateAxis26.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color33 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int34 = color33.getAlpha();
        dateAxis26.setTickLabelPaint((java.awt.Paint) color33);
        dateAxis26.setInverted(false);
        double double38 = dateAxis26.getLowerBound();
        org.jfree.data.Range range39 = xYPlot21.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis26);
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("");
        dateAxis41.setRange((double) 0.0f, (double) 10.0f);
        dateAxis41.resizeRange((double) ' ');
        dateAxis41.setLowerBound((double) (short) 0);
        org.jfree.data.Range range49 = xYPlot21.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis41);
        java.awt.Paint paint50 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        dateAxis41.setLabelPaint(paint50);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 255 + "'", int34 == 255);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNull(range39);
        org.junit.Assert.assertNull(range49);
        org.junit.Assert.assertNotNull(paint50);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = categoryPlot0.getRenderer();
        boolean boolean4 = categoryPlot0.isRangeZoomable();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = categoryPlot0.getOrientation();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = categoryPlot0.getDrawingSupplier();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNull(categoryItemRenderer3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNotNull(drawingSupplier6);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        int int5 = polarPlot4.getBackgroundImageAlignment();
        boolean boolean6 = polarPlot4.isOutlineVisible();
        polarPlot4.setAngleGridlinesVisible(true);
        org.jfree.chart.plot.WaferMapPlot waferMapPlot9 = new org.jfree.chart.plot.WaferMapPlot();
        java.awt.Paint paint10 = waferMapPlot9.getBackgroundPaint();
        polarPlot4.setAngleLabelPaint(paint10);
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("");
        java.awt.Paint paint14 = textTitle13.getPaint();
        polarPlot4.setNoDataMessagePaint(paint14);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        boolean boolean2 = categoryPlot0.isDomainGridlinesVisible();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        boolean boolean7 = categoryPlot0.render(graphics2D3, rectangle2D4, (int) (byte) 10, plotRenderingInfo6);
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot0.getDataset((int) ' ');
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        float float11 = categoryPlot10.getForegroundAlpha();
        float float12 = categoryPlot10.getBackgroundImageAlpha();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        float float14 = categoryPlot13.getForegroundAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        categoryPlot13.setRangeAxis((int) '4', valueAxis16, false);
        categoryPlot13.configureRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer25 = null;
        org.jfree.chart.plot.PolarPlot polarPlot26 = new org.jfree.chart.plot.PolarPlot(xYDataset22, (org.jfree.chart.axis.ValueAxis) dateAxis24, polarItemRenderer25);
        dateAxis24.setLabelAngle((double) (byte) 1);
        dateAxis24.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int32 = color31.getAlpha();
        java.lang.String str33 = color31.toString();
        dateAxis24.setTickMarkPaint((java.awt.Paint) color31);
        org.jfree.chart.plot.PiePlot piePlot35 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = piePlot35.getSimpleLabelOffset();
        java.awt.Stroke stroke37 = piePlot35.getLabelOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, (java.awt.Paint) color31, stroke37);
        org.jfree.chart.util.Layer layer39 = null;
        categoryPlot13.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker38, layer39);
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource43 = null;
        dateAxis42.setStandardTickUnits(tickUnitSource43);
        java.awt.Stroke stroke45 = dateAxis42.getTickMarkStroke();
        valueMarker38.setStroke(stroke45);
        categoryPlot10.setRangeGridlineStroke(stroke45);
        categoryPlot0.setRangeCrosshairStroke(stroke45);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer49 = null;
        categoryPlot0.setRenderer(categoryItemRenderer49);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 1.0f + "'", float11 == 1.0f);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.5f + "'", float12 == 0.5f);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 1.0f + "'", float14 == 1.0f);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 255 + "'", int32 == 255);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str33.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(stroke45);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.Object obj1 = null;
        boolean boolean2 = ringPlot0.equals(obj1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        int int6 = polarPlot5.getBackgroundImageAlignment();
        boolean boolean7 = polarPlot5.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) polarPlot5);
        int int9 = jFreeChart8.getSubtitleCount();
        java.util.List list10 = jFreeChart8.getSubtitles();
        jFreeChart8.setAntiAlias(false);
        jFreeChart8.setBackgroundImageAlignment((int) (byte) -1);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo18 = null;
        try {
            java.awt.image.BufferedImage bufferedImage19 = jFreeChart8.createBufferedImage((int) (short) 0, (int) '#', (-16777216), chartRenderingInfo18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown image type -16777216");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(list10);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean8 = categoryPlot7.isDomainGridlinesVisible();
        boolean boolean9 = categoryPlot7.isDomainGridlinesVisible();
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        boolean boolean14 = categoryPlot7.render(graphics2D10, rectangle2D11, (int) (byte) 10, plotRenderingInfo13);
        categoryPlot7.setOutlineVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis18 = categoryPlot7.getRangeAxis(0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer25 = null;
        org.jfree.chart.plot.PolarPlot polarPlot26 = new org.jfree.chart.plot.PolarPlot(xYDataset22, (org.jfree.chart.axis.ValueAxis) dateAxis24, polarItemRenderer25);
        int int27 = polarPlot26.getBackgroundImageAlignment();
        boolean boolean28 = polarPlot26.isSubplot();
        java.awt.Color color29 = java.awt.Color.blue;
        polarPlot26.setAngleLabelPaint((java.awt.Paint) color29);
        java.awt.Font font31 = polarPlot26.getAngleLabelFont();
        org.jfree.chart.title.LegendTitle legendTitle32 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot26);
        org.jfree.data.xy.XYDataset xYDataset35 = null;
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer38 = null;
        org.jfree.chart.plot.PolarPlot polarPlot39 = new org.jfree.chart.plot.PolarPlot(xYDataset35, (org.jfree.chart.axis.ValueAxis) dateAxis37, polarItemRenderer38);
        dateAxis37.setLabelAngle((double) (byte) 1);
        dateAxis37.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color44 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int45 = color44.getAlpha();
        java.lang.String str46 = color44.toString();
        dateAxis37.setTickMarkPaint((java.awt.Paint) color44);
        org.jfree.data.Range range48 = dateAxis37.getDefaultAutoRange();
        boolean boolean49 = dateAxis37.isTickMarksVisible();
        org.jfree.chart.plot.PiePlot piePlot51 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = piePlot51.getSimpleLabelOffset();
        org.jfree.data.xy.XYDataset xYDataset53 = null;
        org.jfree.chart.axis.DateAxis dateAxis55 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer56 = null;
        org.jfree.chart.plot.PolarPlot polarPlot57 = new org.jfree.chart.plot.PolarPlot(xYDataset53, (org.jfree.chart.axis.ValueAxis) dateAxis55, polarItemRenderer56);
        org.jfree.chart.title.LegendTitle legendTitle58 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot57);
        java.awt.geom.Rectangle2D rectangle2D59 = legendTitle58.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType60 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType61 = null;
        java.awt.geom.Rectangle2D rectangle2D62 = rectangleInsets52.createAdjustedRectangle(rectangle2D59, lengthAdjustmentType60, lengthAdjustmentType61);
        org.jfree.chart.util.RectangleEdge rectangleEdge63 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean64 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge63);
        double double65 = dateAxis37.java2DToValue((double) 8, rectangle2D62, rectangleEdge63);
        java.awt.Point point66 = polarPlot26.translateValueThetaRadiusToJava2D((double) (-1L), (double) 2, rectangle2D62);
        categoryPlot7.zoomRangeAxes((double) 10, (double) (-1L), plotRenderingInfo21, (java.awt.geom.Point2D) point66);
        try {
            polarPlot3.zoomRangeAxes(0.0d, (double) 10L, plotRenderingInfo6, (java.awt.geom.Point2D) point66);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(valueAxis18);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 15 + "'", int27 == 15);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 255 + "'", int45 == 255);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str46.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(rectangleInsets52);
        org.junit.Assert.assertNotNull(rectangle2D59);
        org.junit.Assert.assertNotNull(rectangle2D62);
        org.junit.Assert.assertNotNull(rectangleEdge63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 9.223372036854776E18d + "'", double65 == 9.223372036854776E18d);
        org.junit.Assert.assertNotNull(point66);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.util.RectangleEdge.RIGHT;
        try {
            double double2 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D0, rectangleEdge1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge1);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = null;
        org.jfree.chart.text.TextBlock textBlock3 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint2);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = textBlock3.getLineAlignment();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.Font font9 = null;
        java.awt.Paint paint10 = null;
        org.jfree.chart.text.TextBlock textBlock11 = org.jfree.chart.text.TextUtilities.createTextBlock("", font9, paint10);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor15 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        java.awt.Shape shape19 = textBlock11.calculateBounds(graphics2D12, 0.0f, (float) (short) 0, textBlockAnchor15, (float) (byte) 10, (float) 15, (double) 0L);
        textBlock3.draw(graphics2D5, 0.0f, (float) (byte) 10, textBlockAnchor15);
        org.jfree.chart.text.TextLine textLine21 = textBlock3.getLastLine();
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer26 = null;
        org.jfree.chart.plot.PolarPlot polarPlot27 = new org.jfree.chart.plot.PolarPlot(xYDataset23, (org.jfree.chart.axis.ValueAxis) dateAxis25, polarItemRenderer26);
        dateAxis25.setLabelAngle((double) (byte) 1);
        java.awt.Font font30 = dateAxis25.getTickLabelFont();
        org.jfree.chart.text.TextLine textLine31 = new org.jfree.chart.text.TextLine("", font30);
        textBlock3.addLine(textLine31);
        org.jfree.chart.text.TextFragment textFragment33 = textLine31.getLastTextFragment();
        java.lang.String str34 = textFragment33.getText();
        java.awt.Graphics2D graphics2D35 = null;
        try {
            org.jfree.chart.util.Size2D size2D36 = textFragment33.calculateDimensions(graphics2D35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textBlock3);
        org.junit.Assert.assertNotNull(horizontalAlignment4);
        org.junit.Assert.assertNotNull(textBlock11);
        org.junit.Assert.assertNotNull(textBlockAnchor15);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNull(textLine21);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNotNull(textFragment33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "" + "'", str34.equals(""));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        float float2 = categoryPlot0.getBackgroundImageAlpha();
        boolean boolean3 = categoryPlot0.getDrawSharedDomainAxis();
        categoryPlot0.setRangeCrosshairValue(0.0d, false);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.5f + "'", float2 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) dateAxis5, polarItemRenderer6);
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot7);
        java.awt.geom.Rectangle2D rectangle2D9 = legendTitle8.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.geom.Point2D point2D11 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D9, rectangleAnchor10);
        java.lang.String str12 = rectangleAnchor10.toString();
        try {
            java.awt.geom.Rectangle2D rectangle2D13 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) '#', (double) 255, rectangleAnchor10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
        org.junit.Assert.assertNotNull(point2D11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "RectangleAnchor.BOTTOM_LEFT" + "'", str12.equals("RectangleAnchor.BOTTOM_LEFT"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        int int6 = polarPlot5.getBackgroundImageAlignment();
        boolean boolean7 = polarPlot5.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) polarPlot5);
        org.jfree.chart.event.ChartChangeListener chartChangeListener9 = null;
        try {
            jFreeChart8.addChangeListener(chartChangeListener9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Size2D[width=0.0, height=0.0]");
        numberAxis1.setAutoRangeStickyZero(true);
        boolean boolean4 = numberAxis1.getAutoRangeStickyZero();
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent8 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) boolean4, jFreeChart5, (int) '4', (int) (byte) 100);
        org.jfree.chart.JFreeChart jFreeChart9 = null;
        chartProgressEvent8.setChart(jFreeChart9);
        chartProgressEvent8.setPercent((int) 'a');
        int int13 = chartProgressEvent8.getType();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 52 + "'", int13 == 52);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.clearDomainMarkers(15);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        float float26 = categoryPlot25.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot25.getRangeAxisLocation();
        xYPlot21.setDomainAxisLocation((int) (byte) 0, axisLocation27, true);
        xYPlot21.setDomainCrosshairValue((double) 'a');
        boolean boolean32 = xYPlot21.isRangeZeroBaselineVisible();
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        xYPlot21.setDataset(0, xYDataset34);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 1.0f + "'", float26 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, 0.025d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        int int6 = polarPlot5.getBackgroundImageAlignment();
        boolean boolean7 = polarPlot5.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) polarPlot5);
        int int9 = jFreeChart8.getSubtitleCount();
        java.util.List list10 = jFreeChart8.getSubtitles();
        jFreeChart8.setAntiAlias(false);
        jFreeChart8.setBackgroundImageAlignment((int) (byte) -1);
        org.jfree.chart.title.TextTitle textTitle15 = jFreeChart8.getTitle();
        java.awt.Paint paint16 = textTitle15.getBackgroundPaint();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNotNull(textTitle15);
        org.junit.Assert.assertNull(paint16);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.clearDomainMarkers(15);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        float float26 = categoryPlot25.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot25.getRangeAxisLocation();
        xYPlot21.setDomainAxisLocation((int) (byte) 0, axisLocation27, true);
        boolean boolean30 = xYPlot21.isRangeZoomable();
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = xYPlot21.getDomainAxisEdge();
        java.awt.Paint paint32 = xYPlot21.getRangeTickBandPaint();
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 1.0f + "'", float26 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNull(paint32);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        polarPlot4.zoomRangeAxes(0.05d, plotRenderingInfo6, point2D7);
        java.awt.Paint paint9 = polarPlot4.getRadiusGridlinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis10 = polarPlot4.getAxis();
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(valueAxis10);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot4);
        org.jfree.chart.block.BlockContainer blockContainer6 = legendTitle5.getItemContainer();
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = piePlot7.getSimpleLabelOffset();
        boolean boolean9 = piePlot7.getSectionOutlinesVisible();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator10 = null;
        piePlot7.setLegendLabelURLGenerator(pieURLGenerator10);
        boolean boolean12 = piePlot7.getSimpleLabels();
        org.jfree.chart.plot.RingPlot ringPlot13 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint14 = ringPlot13.getShadowPaint();
        ringPlot13.setInteriorGap((double) (byte) 0);
        java.awt.Font font17 = ringPlot13.getNoDataMessageFont();
        piePlot7.setLabelFont(font17);
        legendTitle5.setItemFont(font17);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = legendTitle5.getPosition();
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = legendTitle5.getLegendItemGraphicEdge();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent22 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle5);
        boolean boolean23 = legendTitle5.getNotify();
        org.junit.Assert.assertNotNull(blockContainer6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer2 = null;
        waferMapPlot1.setRenderer(waferMapRenderer2);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        waferMapPlot1.setDataset(waferMapDataset4);
        try {
            org.jfree.chart.LegendItemCollection legendItemCollection6 = waferMapPlot1.getLegendItems();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        java.awt.Paint paint2 = textTitle1.getPaint();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) dateAxis5, polarItemRenderer6);
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot7);
        org.jfree.chart.block.BlockContainer blockContainer9 = legendTitle8.getItemContainer();
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = piePlot10.getSimpleLabelOffset();
        boolean boolean12 = piePlot10.getSectionOutlinesVisible();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator13 = null;
        piePlot10.setLegendLabelURLGenerator(pieURLGenerator13);
        boolean boolean15 = piePlot10.getSimpleLabels();
        org.jfree.chart.plot.RingPlot ringPlot16 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint17 = ringPlot16.getShadowPaint();
        ringPlot16.setInteriorGap((double) (byte) 0);
        java.awt.Font font20 = ringPlot16.getNoDataMessageFont();
        piePlot10.setLabelFont(font20);
        legendTitle8.setItemFont(font20);
        textTitle1.setFont(font20);
        org.jfree.chart.event.TitleChangeListener titleChangeListener24 = null;
        textTitle1.removeChangeListener(titleChangeListener24);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer29 = null;
        org.jfree.chart.plot.PolarPlot polarPlot30 = new org.jfree.chart.plot.PolarPlot(xYDataset26, (org.jfree.chart.axis.ValueAxis) dateAxis28, polarItemRenderer29);
        dateAxis28.setLabelAngle((double) (byte) 1);
        java.awt.Font font33 = dateAxis28.getTickLabelFont();
        dateAxis28.setAutoTickUnitSelection(true);
        dateAxis28.setLabelAngle(0.18d);
        org.jfree.data.xy.XYDataset xYDataset38 = null;
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer41 = null;
        org.jfree.chart.plot.PolarPlot polarPlot42 = new org.jfree.chart.plot.PolarPlot(xYDataset38, (org.jfree.chart.axis.ValueAxis) dateAxis40, polarItemRenderer41);
        dateAxis40.setLabelAngle((double) (byte) 1);
        dateAxis40.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color47 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int48 = color47.getAlpha();
        java.lang.String str49 = color47.toString();
        dateAxis40.setTickMarkPaint((java.awt.Paint) color47);
        org.jfree.data.Range range51 = dateAxis40.getDefaultAutoRange();
        java.awt.Font font52 = dateAxis40.getTickLabelFont();
        dateAxis28.setLabelFont(font52);
        textTitle1.setFont(font52);
        textTitle1.setToolTipText("RectangleAnchor.BOTTOM_LEFT");
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(blockContainer9);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 255 + "'", int48 == 255);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str49.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(range51);
        org.junit.Assert.assertNotNull(font52);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        java.lang.String str1 = textBlockAnchor0.toString();
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextBlockAnchor.CENTER_RIGHT" + "'", str1.equals("TextBlockAnchor.CENTER_RIGHT"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        int int5 = polarPlot4.getBackgroundImageAlignment();
        boolean boolean6 = polarPlot4.isSubplot();
        boolean boolean7 = polarPlot4.isDomainZoomable();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        polarPlot4.handleClick((int) (byte) 10, (int) '4', plotRenderingInfo10);
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer16 = null;
        org.jfree.chart.plot.PolarPlot polarPlot17 = new org.jfree.chart.plot.PolarPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis15, polarItemRenderer16);
        org.jfree.chart.plot.PiePlot piePlot18 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = piePlot18.getSimpleLabelOffset();
        double double20 = rectangleInsets19.getRight();
        dateAxis15.setLabelInsets(rectangleInsets19);
        dateAxis15.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("");
        dateAxis26.setRange((double) 0.0f, (double) 10.0f);
        dateAxis26.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) dateAxis15, (org.jfree.chart.axis.ValueAxis) dateAxis26, xYItemRenderer32);
        xYPlot33.setDomainGridlinesVisible(true);
        double double36 = xYPlot33.getDomainCrosshairValue();
        boolean boolean37 = xYPlot33.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.ValueAxis valueAxis39 = xYPlot33.getRangeAxis(0);
        xYPlot33.setDomainZeroBaselineVisible(false);
        java.awt.Stroke stroke42 = xYPlot33.getDomainGridlineStroke();
        polarPlot4.setRadiusGridlineStroke(stroke42);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.18d + "'", double20 == 0.18d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(valueAxis39);
        org.junit.Assert.assertNotNull(stroke42);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.setDomainGridlinesVisible(true);
        double double24 = xYPlot21.getDomainCrosshairValue();
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.title.TextTitle textTitle27 = new org.jfree.chart.title.TextTitle("");
        java.awt.Paint paint28 = textTitle27.getPaint();
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        float float31 = categoryPlot30.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation32 = categoryPlot30.getRangeAxisLocation();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = categoryPlot30.getRenderer();
        java.lang.String str34 = categoryPlot30.getPlotType();
        java.awt.Graphics2D graphics2D35 = null;
        org.jfree.data.xy.XYDataset xYDataset36 = null;
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer39 = null;
        org.jfree.chart.plot.PolarPlot polarPlot40 = new org.jfree.chart.plot.PolarPlot(xYDataset36, (org.jfree.chart.axis.ValueAxis) dateAxis38, polarItemRenderer39);
        org.jfree.chart.title.LegendTitle legendTitle41 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot40);
        java.awt.geom.Rectangle2D rectangle2D42 = legendTitle41.getBounds();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = null;
        boolean boolean45 = categoryPlot30.render(graphics2D35, rectangle2D42, (int) (byte) 1, plotRenderingInfo44);
        java.lang.Object obj46 = null;
        java.lang.Object obj47 = textTitle27.draw(graphics2D29, rectangle2D42, obj46);
        try {
            xYPlot21.drawBackground(graphics2D25, rectangle2D42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + 1.0f + "'", float31 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertNull(categoryItemRenderer33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Category Plot" + "'", str34.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangle2D42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNull(obj47);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        dateAxis2.setLabelAngle((double) (byte) 1);
        java.awt.Font font7 = dateAxis2.getTickLabelFont();
        dateAxis2.setAutoTickUnitSelection(true);
        dateAxis2.setLabelAngle(0.18d);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = dateAxis2.getLabelInsets();
        java.awt.Shape shape13 = dateAxis2.getRightArrow();
        java.util.Date date14 = dateAxis2.getMaximumDate();
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(date14);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        double double5 = dateAxis2.getLabelAngle();
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = dateAxis2.getTickUnit();
        dateAxis2.setPositiveArrowVisible(true);
        java.awt.Paint paint9 = dateAxis2.getAxisLinePaint();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(dateTickUnit6);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        xYPlot21.zoomRangeAxes((double) ' ', plotRenderingInfo23, point2D24);
        java.awt.Paint paint26 = xYPlot21.getDomainTickBandPaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent27 = null;
        xYPlot21.rendererChanged(rendererChangeEvent27);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray29 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot21.setRenderers(xYItemRendererArray29);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = xYPlot21.getDomainAxisEdge((-1));
        java.awt.Stroke stroke33 = null;
        try {
            xYPlot21.setDomainCrosshairStroke(stroke33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertNull(paint26);
        org.junit.Assert.assertNotNull(xYItemRendererArray29);
        org.junit.Assert.assertNotNull(rectangleEdge32);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        org.jfree.data.Range range5 = dateAxis2.getRange();
        java.util.Date date6 = dateAxis2.getMinimumDate();
        org.jfree.data.time.DateRange dateRange9 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((double) '#', (org.jfree.data.Range) dateRange9);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = new org.jfree.chart.block.RectangleConstraint(10.0d, (org.jfree.data.Range) dateRange9);
        boolean boolean13 = dateRange9.contains(100.0d);
        boolean boolean15 = dateRange9.contains((double) (short) -1);
        dateAxis2.setRange((org.jfree.data.Range) dateRange9);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(dateRange9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        java.awt.Color color0 = java.awt.Color.PINK;
        java.awt.Color color1 = color0.brighter();
        org.jfree.chart.block.BlockBorder blockBorder2 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color1);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Size2D[width=0.0, height=0.0]");
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setFixedAutoRange((double) 10.0f);
        java.text.NumberFormat numberFormat6 = null;
        numberAxis1.setNumberFormatOverride(numberFormat6);
        numberAxis1.setAutoRangeIncludesZero(false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!");
        java.lang.String str3 = textTitle2.getToolTipText();
        java.awt.Paint paint4 = textTitle2.getBackgroundPaint();
        textTitle2.setToolTipText("java.awt.Color[r=255,g=255,b=64]");
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer11 = null;
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot(xYDataset8, (org.jfree.chart.axis.ValueAxis) dateAxis10, polarItemRenderer11);
        int int13 = polarPlot12.getBackgroundImageAlignment();
        boolean boolean14 = polarPlot12.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) polarPlot12);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo18 = null;
        java.awt.image.BufferedImage bufferedImage19 = jFreeChart15.createBufferedImage(100, 255, chartRenderingInfo18);
        jFreeChart15.removeLegend();
        java.awt.Stroke stroke21 = jFreeChart15.getBorderStroke();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType22 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent23 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) "java.awt.Color[r=255,g=255,b=64]", jFreeChart15, chartChangeEventType22);
        textTitle0.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart15);
        java.lang.String str25 = textTitle0.getID();
        org.jfree.chart.block.BlockFrame blockFrame26 = textTitle0.getFrame();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(bufferedImage19);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNotNull(blockFrame26);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        java.awt.Shape shape0 = null;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        try {
            org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 3, 128, (java.lang.Comparable) 4.0d, "RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=0.4]", "TextAnchor.CENTER_LEFT");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = piePlot0.getSimpleLabelOffset();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        piePlot0.markerChanged(markerChangeEvent2);
        double double4 = piePlot0.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        boolean boolean6 = piePlot0.equals((java.lang.Object) rectangleInsets5);
        piePlot0.setSectionOutlinesVisible(false);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        float[] floatArray14 = new float[] { (-1.0f), 10, (short) 0, '#' };
        float[] floatArray15 = color9.getRGBComponents(floatArray14);
        org.jfree.chart.block.BlockBorder blockBorder16 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color9);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = blockBorder16.getInsets();
        double double19 = rectangleInsets17.calculateBottomInset(1.5d);
        piePlot0.setLabelPadding(rectangleInsets17);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot4);
        org.jfree.chart.block.BlockContainer blockContainer6 = legendTitle5.getItemContainer();
        org.jfree.chart.block.Arrangement arrangement7 = blockContainer6.getArrangement();
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("hi!");
        java.lang.String str10 = textTitle9.getToolTipText();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment11 = textTitle9.getHorizontalAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment12 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement15 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment11, verticalAlignment12, (double) 0, 0.0d);
        blockContainer6.setArrangement((org.jfree.chart.block.Arrangement) flowArrangement15);
        org.junit.Assert.assertNotNull(blockContainer6);
        org.junit.Assert.assertNotNull(arrangement7);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(horizontalAlignment11);
        org.junit.Assert.assertNotNull(verticalAlignment12);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Size2D[width=0.0, height=0.0]");
        numberAxis1.setAutoRangeStickyZero(true);
        boolean boolean4 = numberAxis1.getAutoRangeStickyZero();
        boolean boolean5 = numberAxis1.isVisible();
        numberAxis1.configure();
        java.lang.Object obj7 = numberAxis1.clone();
        double double8 = numberAxis1.getUpperMargin();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.data.time.DateRange dateRange2 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = new org.jfree.chart.block.RectangleConstraint((double) '#', (org.jfree.data.Range) dateRange2);
        org.jfree.data.Range range6 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange2, (double) 1.0f, false);
        double double7 = dateRange2.getCentralValue();
        double double8 = dateRange2.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint(1.0d, (org.jfree.data.Range) dateRange2);
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer13 = null;
        org.jfree.chart.plot.PolarPlot polarPlot14 = new org.jfree.chart.plot.PolarPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) dateAxis12, polarItemRenderer13);
        dateAxis12.setLabelAngle((double) (byte) 1);
        dateAxis12.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int20 = color19.getAlpha();
        java.lang.String str21 = color19.toString();
        dateAxis12.setTickMarkPaint((java.awt.Paint) color19);
        org.jfree.data.Range range23 = dateAxis12.getDefaultAutoRange();
        org.jfree.data.time.DateRange dateRange25 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint((double) '#', (org.jfree.data.Range) dateRange25);
        org.jfree.data.Range range27 = org.jfree.data.Range.combine(range23, (org.jfree.data.Range) dateRange25);
        double double28 = dateRange25.getCentralValue();
        double double29 = dateRange25.getLength();
        double double30 = dateRange25.getUpperBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint31 = rectangleConstraint9.toRangeWidth((org.jfree.data.Range) dateRange25);
        org.junit.Assert.assertNotNull(dateRange2);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.5d + "'", double7 == 0.5d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 255 + "'", int20 == 255);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str21.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNotNull(dateRange25);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.5d + "'", double28 == 0.5d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint31);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = piePlot0.getSimpleLabelOffset();
        java.awt.Stroke stroke2 = piePlot0.getLabelOutlineStroke();
        java.awt.Paint paint3 = piePlot0.getLabelOutlinePaint();
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(paint3);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        int int5 = polarPlot4.getBackgroundImageAlignment();
        boolean boolean6 = polarPlot4.isOutlineVisible();
        java.awt.Paint paint7 = polarPlot4.getRadiusGridlinePaint();
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer11 = null;
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot(xYDataset8, (org.jfree.chart.axis.ValueAxis) dateAxis10, polarItemRenderer11);
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = piePlot13.getSimpleLabelOffset();
        double double15 = rectangleInsets14.getRight();
        dateAxis10.setLabelInsets(rectangleInsets14);
        java.awt.Shape shape17 = dateAxis10.getLeftArrow();
        dateAxis10.setAxisLineVisible(false);
        dateAxis10.setLabel("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit22 = dateAxis10.getTickUnit();
        polarPlot4.setAngleTickUnit((org.jfree.chart.axis.TickUnit) dateTickUnit22);
        java.awt.Color color26 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.image.ColorModel colorModel27 = null;
        java.awt.Rectangle rectangle28 = null;
        org.jfree.chart.plot.PiePlot piePlot29 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = piePlot29.getSimpleLabelOffset();
        org.jfree.data.xy.XYDataset xYDataset31 = null;
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer34 = null;
        org.jfree.chart.plot.PolarPlot polarPlot35 = new org.jfree.chart.plot.PolarPlot(xYDataset31, (org.jfree.chart.axis.ValueAxis) dateAxis33, polarItemRenderer34);
        org.jfree.chart.title.LegendTitle legendTitle36 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot35);
        java.awt.geom.Rectangle2D rectangle2D37 = legendTitle36.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType38 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = rectangleInsets30.createAdjustedRectangle(rectangle2D37, lengthAdjustmentType38, lengthAdjustmentType39);
        java.awt.geom.AffineTransform affineTransform41 = null;
        java.awt.RenderingHints renderingHints42 = null;
        java.awt.PaintContext paintContext43 = color26.createContext(colorModel27, rectangle28, rectangle2D40, affineTransform41, renderingHints42);
        try {
            java.awt.Point point44 = polarPlot4.translateValueThetaRadiusToJava2D((double) (-6553600), 23.4375d, (java.awt.geom.Rectangle2D) rectangle28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.18d + "'", double15 == 0.18d);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(dateTickUnit22);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertNotNull(rectangle2D40);
        org.junit.Assert.assertNotNull(paintContext43);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        xYPlot21.zoomRangeAxes((double) ' ', plotRenderingInfo23, point2D24);
        java.awt.Stroke stroke26 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot21.setDomainGridlineStroke(stroke26);
        org.jfree.chart.axis.ValueAxis valueAxis28 = xYPlot21.getDomainAxis();
        valueAxis28.setFixedAutoRange((double) 0L);
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource33 = null;
        dateAxis32.setStandardTickUnits(tickUnitSource33);
        java.awt.Shape shape35 = dateAxis32.getRightArrow();
        valueAxis28.setLeftArrow(shape35);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(valueAxis28);
        org.junit.Assert.assertNotNull(shape35);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.setDomainCrosshairValue((double) (short) 10);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer28 = null;
        org.jfree.chart.plot.PolarPlot polarPlot29 = new org.jfree.chart.plot.PolarPlot(xYDataset25, (org.jfree.chart.axis.ValueAxis) dateAxis27, polarItemRenderer28);
        int int30 = polarPlot29.getBackgroundImageAlignment();
        boolean boolean31 = polarPlot29.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart32 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) polarPlot29);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo35 = null;
        java.awt.image.BufferedImage bufferedImage36 = jFreeChart32.createBufferedImage(100, 255, chartRenderingInfo35);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent39 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) (short) 10, jFreeChart32, (-16056329), (-16777216));
        boolean boolean40 = jFreeChart32.getAntiAlias();
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 15 + "'", int30 == 15);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(bufferedImage36);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.setDomainCrosshairValue((double) (short) 10);
        boolean boolean24 = xYPlot21.isDomainGridlinesVisible();
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        java.text.NumberFormat numberFormat1 = null;
        java.text.NumberFormat numberFormat2 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("TextAnchor.CENTER_LEFT", numberFormat1, numberFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'numberFormat' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        java.lang.Number[] numberArray8 = new java.lang.Number[] { 0.4d, 100.0f, 0L, 0.025d, (byte) 1, 1.0f };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 0.4d, 100.0f, 0L, 0.025d, (byte) 1, 1.0f };
        java.lang.Number[] numberArray22 = new java.lang.Number[] { 0.4d, 100.0f, 0L, 0.025d, (byte) 1, 1.0f };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { 0.4d, 100.0f, 0L, 0.025d, (byte) 1, 1.0f };
        java.lang.Number[] numberArray36 = new java.lang.Number[] { 0.4d, 100.0f, 0L, 0.025d, (byte) 1, 1.0f };
        java.lang.Number[] numberArray43 = new java.lang.Number[] { 0.4d, 100.0f, 0L, 0.025d, (byte) 1, 1.0f };
        java.lang.Number[][] numberArray44 = new java.lang.Number[][] { numberArray8, numberArray15, numberArray22, numberArray29, numberArray36, numberArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("PlotOrientation.VERTICAL", "hi!", numberArray44);
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = null;
        org.jfree.chart.axis.NumberAxis numberAxis48 = new org.jfree.chart.axis.NumberAxis("Size2D[width=0.0, height=0.0]");
        numberAxis48.setAutoRangeStickyZero(true);
        boolean boolean51 = numberAxis48.getAutoRangeStickyZero();
        boolean boolean52 = numberAxis48.isVisible();
        java.text.NumberFormat numberFormat53 = numberAxis48.getNumberFormatOverride();
        numberAxis48.setAutoRangeIncludesZero(true);
        java.lang.String str56 = numberAxis48.getLabelToolTip();
        java.text.NumberFormat numberFormat57 = null;
        numberAxis48.setNumberFormatOverride(numberFormat57);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer59 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot(categoryDataset45, categoryAxis46, (org.jfree.chart.axis.ValueAxis) numberAxis48, categoryItemRenderer59);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot61 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset45);
        org.jfree.chart.util.TableOrder tableOrder62 = null;
        try {
            multiplePiePlot61.setDataExtractOrder(tableOrder62);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray36);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNull(numberFormat53);
        org.junit.Assert.assertNull(str56);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        dateAxis2.setLabelAngle((double) (byte) 1);
        dateAxis2.setTickMarkOutsideLength((-1.0f));
        dateAxis2.setFixedDimension(0.4d);
        double double11 = dateAxis2.getUpperBound();
        org.jfree.data.time.DateRange dateRange13 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint((double) '#', (org.jfree.data.Range) dateRange13);
        org.jfree.data.Range range16 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange13, 9.223372036854776E18d);
        dateAxis2.setRange(range16);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNotNull(dateRange13);
        org.junit.Assert.assertNotNull(range16);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        java.util.List list2 = categoryPlot0.getAnnotations();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        float float4 = categoryPlot3.getForegroundAlpha();
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) dateAxis8, polarItemRenderer9);
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = piePlot11.getSimpleLabelOffset();
        double double13 = rectangleInsets12.getRight();
        dateAxis8.setLabelInsets(rectangleInsets12);
        dateAxis8.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("");
        dateAxis19.setRange((double) 0.0f, (double) 10.0f);
        dateAxis19.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) dateAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis19, xYItemRenderer25);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Point2D point2D29 = null;
        xYPlot26.zoomRangeAxes((double) ' ', plotRenderingInfo28, point2D29);
        java.awt.Paint paint31 = xYPlot26.getDomainTickBandPaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent32 = null;
        xYPlot26.rendererChanged(rendererChangeEvent32);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray34 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot26.setRenderers(xYItemRendererArray34);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder36 = xYPlot26.getDatasetRenderingOrder();
        categoryPlot3.setDatasetRenderingOrder(datasetRenderingOrder36);
        categoryPlot0.setDatasetRenderingOrder(datasetRenderingOrder36);
        org.jfree.chart.util.SortOrder sortOrder39 = categoryPlot0.getColumnRenderingOrder();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.18d + "'", double13 == 0.18d);
        org.junit.Assert.assertNull(paint31);
        org.junit.Assert.assertNotNull(xYItemRendererArray34);
        org.junit.Assert.assertNotNull(datasetRenderingOrder36);
        org.junit.Assert.assertNotNull(sortOrder39);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        java.lang.Comparable comparable4 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 255, (-16056329), comparable4, "java.awt.Color[r=255,g=255,b=64]", "ClassContext");
        org.jfree.data.general.PieDataset pieDataset8 = pieSectionEntity7.getDataset();
        java.lang.String str9 = pieSectionEntity7.getURLText();
        java.lang.String str10 = pieSectionEntity7.getToolTipText();
        try {
            java.lang.String str11 = pieSectionEntity7.toString();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNull(pieDataset8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ClassContext" + "'", str9.equals("ClassContext"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str10.equals("java.awt.Color[r=255,g=255,b=64]"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) ' ');
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) dateAxis4, polarItemRenderer5);
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 100, 0.4d);
        org.jfree.data.time.DateRange dateRange13 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint((double) '#', (org.jfree.data.Range) dateRange13);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint11.toRangeHeight((org.jfree.data.Range) dateRange13);
        org.jfree.chart.util.Size2D size2D16 = legendTitle7.arrange(graphics2D8, rectangleConstraint11);
        java.lang.String str17 = size2D16.toString();
        java.lang.Object obj18 = size2D16.clone();
        boolean boolean19 = objectList1.equals((java.lang.Object) size2D16);
        double double20 = size2D16.getWidth();
        org.junit.Assert.assertNotNull(dateRange13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(size2D16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str17.equals("Size2D[width=0.0, height=0.0]"));
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Size2D[width=0.0, height=0.0]");
        numberAxis1.setAutoRangeStickyZero(true);
        boolean boolean4 = numberAxis1.getAutoRangeStickyZero();
        boolean boolean5 = numberAxis1.isVisible();
        numberAxis1.configure();
        java.lang.Object obj7 = numberAxis1.clone();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.axis.AxisState axisState9 = null;
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer13 = null;
        org.jfree.chart.plot.PolarPlot polarPlot14 = new org.jfree.chart.plot.PolarPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) dateAxis12, polarItemRenderer13);
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot14);
        java.awt.Color color16 = java.awt.Color.green;
        java.awt.Color color17 = color16.darker();
        legendTitle15.setBackgroundPaint((java.awt.Paint) color16);
        java.lang.Class<?> wildcardClass19 = legendTitle15.getClass();
        java.awt.geom.Rectangle2D rectangle2D20 = legendTitle15.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = null;
        java.util.List list22 = numberAxis1.refreshTicks(graphics2D8, axisState9, rectangle2D20, rectangleEdge21);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(list22);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis((int) '4', valueAxis3, false);
        categoryPlot0.configureRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer12 = null;
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) dateAxis11, polarItemRenderer12);
        dateAxis11.setLabelAngle((double) (byte) 1);
        dateAxis11.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int19 = color18.getAlpha();
        java.lang.String str20 = color18.toString();
        dateAxis11.setTickMarkPaint((java.awt.Paint) color18);
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = piePlot22.getSimpleLabelOffset();
        java.awt.Stroke stroke24 = piePlot22.getLabelOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, (java.awt.Paint) color18, stroke24);
        org.jfree.chart.util.Layer layer26 = null;
        categoryPlot0.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker25, layer26);
        org.jfree.chart.plot.PiePlot piePlot28 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = piePlot28.getSimpleLabelOffset();
        java.awt.Paint paint31 = piePlot28.getSectionPaint((java.lang.Comparable) 10);
        valueMarker25.addChangeListener((org.jfree.chart.event.MarkerChangeListener) piePlot28);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 255 + "'", int19 == 255);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str20.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNull(paint31);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        int int5 = polarPlot4.getBackgroundImageAlignment();
        boolean boolean6 = polarPlot4.isSubplot();
        boolean boolean7 = polarPlot4.isDomainZoomable();
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint9 = ringPlot8.getShadowPaint();
        ringPlot8.setInteriorGap((double) (byte) 0);
        java.awt.Font font12 = ringPlot8.getNoDataMessageFont();
        polarPlot4.setAngleLabelFont(font12);
        polarPlot4.setAngleGridlinesVisible(false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(font12);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        int int6 = polarPlot5.getBackgroundImageAlignment();
        boolean boolean7 = polarPlot5.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) polarPlot5);
        int int9 = jFreeChart8.getSubtitleCount();
        java.util.List list10 = jFreeChart8.getSubtitles();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = null;
        try {
            java.awt.image.BufferedImage bufferedImage15 = jFreeChart8.createBufferedImage((int) (short) 100, (-16056329), 100, chartRenderingInfo14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown image type 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(list10);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        xYPlot21.zoomRangeAxes((double) ' ', plotRenderingInfo23, point2D24);
        java.awt.Paint paint26 = xYPlot21.getDomainTickBandPaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent27 = null;
        xYPlot21.rendererChanged(rendererChangeEvent27);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray29 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot21.setRenderers(xYItemRendererArray29);
        int int31 = xYPlot21.getRangeAxisCount();
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertNull(paint26);
        org.junit.Assert.assertNotNull(xYItemRendererArray29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = piePlot0.getSimpleLabelOffset();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        piePlot0.markerChanged(markerChangeEvent2);
        java.lang.Object obj4 = piePlot0.clone();
        java.awt.Paint paint5 = piePlot0.getLabelLinkPaint();
        double double6 = piePlot0.getLabelGap();
        java.awt.Paint paint7 = piePlot0.getLabelBackgroundPaint();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.025d + "'", double6 == 0.025d);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D0.clearCategoryLabelToolTips();
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.Font font3 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        categoryAxis3D0.setTickLabelFont((java.lang.Comparable) date2, font3);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        int int5 = polarPlot4.getBackgroundImageAlignment();
        boolean boolean6 = polarPlot4.isSubplot();
        java.awt.Color color7 = java.awt.Color.blue;
        polarPlot4.setAngleLabelPaint((java.awt.Paint) color7);
        java.awt.Font font9 = polarPlot4.getAngleLabelFont();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot4);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer16 = null;
        org.jfree.chart.plot.PolarPlot polarPlot17 = new org.jfree.chart.plot.PolarPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis15, polarItemRenderer16);
        dateAxis15.setLabelAngle((double) (byte) 1);
        dateAxis15.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int23 = color22.getAlpha();
        java.lang.String str24 = color22.toString();
        dateAxis15.setTickMarkPaint((java.awt.Paint) color22);
        org.jfree.data.Range range26 = dateAxis15.getDefaultAutoRange();
        boolean boolean27 = dateAxis15.isTickMarksVisible();
        org.jfree.chart.plot.PiePlot piePlot29 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = piePlot29.getSimpleLabelOffset();
        org.jfree.data.xy.XYDataset xYDataset31 = null;
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer34 = null;
        org.jfree.chart.plot.PolarPlot polarPlot35 = new org.jfree.chart.plot.PolarPlot(xYDataset31, (org.jfree.chart.axis.ValueAxis) dateAxis33, polarItemRenderer34);
        org.jfree.chart.title.LegendTitle legendTitle36 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot35);
        java.awt.geom.Rectangle2D rectangle2D37 = legendTitle36.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType38 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = rectangleInsets30.createAdjustedRectangle(rectangle2D37, lengthAdjustmentType38, lengthAdjustmentType39);
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean42 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge41);
        double double43 = dateAxis15.java2DToValue((double) 8, rectangle2D40, rectangleEdge41);
        java.awt.Point point44 = polarPlot4.translateValueThetaRadiusToJava2D((double) (-1L), (double) 2, rectangle2D40);
        org.jfree.chart.axis.NumberAxis numberAxis46 = new org.jfree.chart.axis.NumberAxis("Size2D[width=0.0, height=0.0]");
        numberAxis46.setAutoRangeStickyZero(true);
        boolean boolean49 = numberAxis46.getAutoRangeStickyZero();
        boolean boolean50 = numberAxis46.isVisible();
        org.jfree.data.xy.XYDataset xYDataset51 = null;
        org.jfree.chart.axis.DateAxis dateAxis53 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer54 = null;
        org.jfree.chart.plot.PolarPlot polarPlot55 = new org.jfree.chart.plot.PolarPlot(xYDataset51, (org.jfree.chart.axis.ValueAxis) dateAxis53, polarItemRenderer54);
        int int56 = polarPlot55.getBackgroundImageAlignment();
        boolean boolean57 = polarPlot55.isSubplot();
        boolean boolean58 = polarPlot55.isDomainZoomable();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo61 = null;
        polarPlot55.handleClick((int) (byte) 10, (int) '4', plotRenderingInfo61);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit63 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        polarPlot55.setAngleTickUnit((org.jfree.chart.axis.TickUnit) numberTickUnit63);
        numberAxis46.setTickUnit(numberTickUnit63);
        polarPlot4.setAngleTickUnit((org.jfree.chart.axis.TickUnit) numberTickUnit63);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 255 + "'", int23 == 255);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str24.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertNotNull(rectangle2D40);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 9.223372036854776E18d + "'", double43 == 9.223372036854776E18d);
        org.junit.Assert.assertNotNull(point44);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 15 + "'", int56 == 15);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(numberTickUnit63);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        int int5 = polarPlot4.getBackgroundImageAlignment();
        boolean boolean6 = polarPlot4.isSubplot();
        java.awt.Color color7 = java.awt.Color.blue;
        polarPlot4.setAngleLabelPaint((java.awt.Paint) color7);
        java.awt.Font font9 = polarPlot4.getAngleLabelFont();
        org.jfree.chart.plot.PlotOrientation plotOrientation10 = polarPlot4.getOrientation();
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        polarPlot4.setDataset(xYDataset11);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(plotOrientation10);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot5);
        java.awt.Color color7 = java.awt.Color.green;
        java.awt.Color color8 = color7.darker();
        legendTitle6.setBackgroundPaint((java.awt.Paint) color7);
        java.lang.Class<?> wildcardClass10 = legendTitle6.getClass();
        java.net.URL uRL11 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("RectangleInsets[t=0.0,l=2.0,b=100.0,r=1.0]", (java.lang.Class) wildcardClass10);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNull(uRL11);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.setDomainGridlinesVisible(true);
        double double24 = xYPlot21.getDomainCrosshairValue();
        boolean boolean25 = xYPlot21.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.ValueAxis valueAxis27 = xYPlot21.getRangeAxis(0);
        xYPlot21.setDomainZeroBaselineVisible(false);
        java.awt.Stroke stroke30 = xYPlot21.getDomainGridlineStroke();
        int int31 = xYPlot21.getSeriesCount();
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(valueAxis27);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.clearDomainMarkers(15);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        float float26 = categoryPlot25.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot25.getRangeAxisLocation();
        xYPlot21.setDomainAxisLocation((int) (byte) 0, axisLocation27, true);
        java.awt.Stroke stroke30 = xYPlot21.getRangeGridlineStroke();
        java.awt.Paint paint31 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot21.setDomainZeroBaselinePaint(paint31);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent33 = null;
        xYPlot21.notifyListeners(plotChangeEvent33);
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis("");
        dateAxis36.setRange((double) 0.0f, (double) 10.0f);
        dateAxis36.resizeRange((double) ' ');
        dateAxis36.setVerticalTickLabels(false);
        org.jfree.data.Range range44 = xYPlot21.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis36);
        java.util.Date date45 = dateAxis36.getMinimumDate();
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 1.0f + "'", float26 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNull(range44);
        org.junit.Assert.assertNotNull(date45);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.clearDomainMarkers(15);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        float float26 = categoryPlot25.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot25.getRangeAxisLocation();
        xYPlot21.setDomainAxisLocation((int) (byte) 0, axisLocation27, true);
        boolean boolean30 = xYPlot21.isRangeZoomable();
        xYPlot21.clearDomainMarkers();
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 1.0f + "'", float26 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        int int6 = polarPlot5.getBackgroundImageAlignment();
        boolean boolean7 = polarPlot5.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) polarPlot5);
        java.awt.RenderingHints renderingHints9 = jFreeChart8.getRenderingHints();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(renderingHints9);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D0.clearCategoryLabelToolTips();
        int int2 = categoryAxis3D0.getCategoryLabelPositionOffset();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 100, 0.4d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType3 = rectangleConstraint2.getWidthConstraintType();
        java.lang.String str4 = lengthConstraintType3.toString();
        org.junit.Assert.assertNotNull(lengthConstraintType3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "LengthConstraintType.FIXED" + "'", str4.equals("LengthConstraintType.FIXED"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = categoryPlot0.getRenderer();
        java.lang.String str4 = categoryPlot0.getPlotType();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) dateAxis8, polarItemRenderer9);
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot10);
        java.awt.geom.Rectangle2D rectangle2D12 = legendTitle11.getBounds();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        boolean boolean15 = categoryPlot0.render(graphics2D5, rectangle2D12, (int) (byte) 1, plotRenderingInfo14);
        java.awt.Stroke stroke16 = categoryPlot0.getRangeGridlineStroke();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent17 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent17);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder19 = categoryPlot0.getDatasetRenderingOrder();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNull(categoryItemRenderer3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Category Plot" + "'", str4.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(datasetRenderingOrder19);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        org.jfree.data.Range range5 = dateAxis2.getRange();
        java.util.Date date6 = dateAxis2.getMinimumDate();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) dateAxis9, polarItemRenderer10);
        dateAxis9.setLabelAngle((double) (byte) 1);
        java.awt.Font font14 = dateAxis9.getTickLabelFont();
        dateAxis9.setAutoTickUnitSelection(true);
        dateAxis9.setLabelAngle(0.18d);
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer22 = null;
        org.jfree.chart.plot.PolarPlot polarPlot23 = new org.jfree.chart.plot.PolarPlot(xYDataset19, (org.jfree.chart.axis.ValueAxis) dateAxis21, polarItemRenderer22);
        dateAxis21.setLabelAngle((double) (byte) 1);
        dateAxis21.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color28 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int29 = color28.getAlpha();
        java.lang.String str30 = color28.toString();
        dateAxis21.setTickMarkPaint((java.awt.Paint) color28);
        org.jfree.data.Range range32 = dateAxis21.getDefaultAutoRange();
        java.awt.Font font33 = dateAxis21.getTickLabelFont();
        dateAxis9.setLabelFont(font33);
        dateAxis2.setTickLabelFont(font33);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 255 + "'", int29 == 255);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str30.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertNotNull(font33);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.lang.Object obj1 = categoryAxis3D0.clone();
        categoryAxis3D0.setLowerMargin((double) (byte) 1);
        java.awt.Font font5 = categoryAxis3D0.getTickLabelFont((java.lang.Comparable) 0.0d);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer11 = null;
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot(xYDataset8, (org.jfree.chart.axis.ValueAxis) dateAxis10, polarItemRenderer11);
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot12);
        java.awt.geom.Rectangle2D rectangle2D14 = legendTitle13.getBounds();
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot(xYDataset16, (org.jfree.chart.axis.ValueAxis) dateAxis18, polarItemRenderer19);
        org.jfree.chart.plot.PiePlot piePlot21 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = piePlot21.getSimpleLabelOffset();
        double double23 = rectangleInsets22.getRight();
        dateAxis18.setLabelInsets(rectangleInsets22);
        dateAxis18.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("");
        dateAxis29.setRange((double) 0.0f, (double) 10.0f);
        dateAxis29.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) dateAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis29, xYItemRenderer35);
        xYPlot36.clearDomainMarkers(15);
        org.jfree.data.xy.XYDataset xYDataset39 = null;
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer42 = null;
        org.jfree.chart.plot.PolarPlot polarPlot43 = new org.jfree.chart.plot.PolarPlot(xYDataset39, (org.jfree.chart.axis.ValueAxis) dateAxis41, polarItemRenderer42);
        dateAxis41.setLabelAngle((double) (byte) 1);
        dateAxis41.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color48 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int49 = color48.getAlpha();
        dateAxis41.setTickLabelPaint((java.awt.Paint) color48);
        dateAxis41.setInverted(false);
        double double53 = dateAxis41.getLowerBound();
        org.jfree.data.Range range54 = xYPlot36.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis41);
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = xYPlot36.getRangeAxisEdge();
        double double56 = categoryAxis3D0.getCategoryEnd((int) (byte) 10, 0, rectangle2D14, rectangleEdge55);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.18d + "'", double23 == 0.18d);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 255 + "'", int49 == 255);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNull(range54);
        org.junit.Assert.assertNotNull(rectangleEdge55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = piePlot4.getSimpleLabelOffset();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent6 = null;
        piePlot4.markerChanged(markerChangeEvent6);
        java.awt.Color color8 = java.awt.Color.green;
        piePlot4.setLabelBackgroundPaint((java.awt.Paint) color8);
        org.jfree.chart.block.BlockBorder blockBorder10 = new org.jfree.chart.block.BlockBorder((double) (-16056329), 1.5d, (-1.0d), 0.0d, (java.awt.Paint) color8);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.clearDomainMarkers(15);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer27 = null;
        org.jfree.chart.plot.PolarPlot polarPlot28 = new org.jfree.chart.plot.PolarPlot(xYDataset24, (org.jfree.chart.axis.ValueAxis) dateAxis26, polarItemRenderer27);
        dateAxis26.setLabelAngle((double) (byte) 1);
        dateAxis26.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color33 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int34 = color33.getAlpha();
        dateAxis26.setTickLabelPaint((java.awt.Paint) color33);
        dateAxis26.setInverted(false);
        double double38 = dateAxis26.getLowerBound();
        org.jfree.data.Range range39 = xYPlot21.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis26);
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = xYPlot21.getRangeAxisEdge();
        java.util.List list41 = xYPlot21.getAnnotations();
        org.jfree.chart.util.Layer layer43 = null;
        java.util.Collection collection44 = xYPlot21.getRangeMarkers((int) (byte) -1, layer43);
        org.jfree.data.xy.XYDataset xYDataset45 = null;
        xYPlot21.setDataset(xYDataset45);
        org.jfree.data.xy.XYDataset xYDataset49 = null;
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer52 = null;
        org.jfree.chart.plot.PolarPlot polarPlot53 = new org.jfree.chart.plot.PolarPlot(xYDataset49, (org.jfree.chart.axis.ValueAxis) dateAxis51, polarItemRenderer52);
        dateAxis51.setLabelAngle((double) (byte) 1);
        dateAxis51.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color58 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int59 = color58.getAlpha();
        java.lang.String str60 = color58.toString();
        dateAxis51.setTickMarkPaint((java.awt.Paint) color58);
        org.jfree.chart.plot.PiePlot piePlot62 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets63 = piePlot62.getSimpleLabelOffset();
        java.awt.Stroke stroke64 = piePlot62.getLabelOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker65 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, (java.awt.Paint) color58, stroke64);
        java.awt.Paint paint66 = valueMarker65.getOutlinePaint();
        java.awt.Font font67 = valueMarker65.getLabelFont();
        org.jfree.chart.util.Layer layer68 = null;
        try {
            boolean boolean69 = xYPlot21.removeRangeMarker(4, (org.jfree.chart.plot.Marker) valueMarker65, layer68);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 255 + "'", int34 == 255);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNull(range39);
        org.junit.Assert.assertNotNull(rectangleEdge40);
        org.junit.Assert.assertNotNull(list41);
        org.junit.Assert.assertNull(collection44);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 255 + "'", int59 == 255);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str60.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(rectangleInsets63);
        org.junit.Assert.assertNotNull(stroke64);
        org.junit.Assert.assertNotNull(paint66);
        org.junit.Assert.assertNotNull(font67);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer1 = new org.jfree.chart.text.G2TextMeasurer(graphics2D0);
        try {
            float float5 = g2TextMeasurer1.getStringWidth("RectangleInsets[t=0.18,l=0.18,b=0.18,r=0.18]", 255, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = new org.jfree.chart.LegendItemCollection();
        legendItemCollection1.addAll(legendItemCollection2);
        org.jfree.chart.LegendItem legendItem4 = null;
        legendItemCollection1.add(legendItem4);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) dateAxis9, polarItemRenderer10);
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = piePlot12.getSimpleLabelOffset();
        double double14 = rectangleInsets13.getRight();
        dateAxis9.setLabelInsets(rectangleInsets13);
        dateAxis9.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("");
        dateAxis20.setRange((double) 0.0f, (double) 10.0f);
        dateAxis20.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) dateAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer26);
        xYPlot27.clearDomainMarkers(15);
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot();
        float float32 = categoryPlot31.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation33 = categoryPlot31.getRangeAxisLocation();
        xYPlot27.setDomainAxisLocation((int) (byte) 0, axisLocation33, true);
        java.awt.Stroke stroke36 = xYPlot27.getRangeGridlineStroke();
        java.awt.Paint paint37 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot27.setDomainZeroBaselinePaint(paint37);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent39 = null;
        xYPlot27.notifyListeners(plotChangeEvent39);
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis("");
        dateAxis42.setRange((double) 0.0f, (double) 10.0f);
        dateAxis42.resizeRange((double) ' ');
        dateAxis42.setVerticalTickLabels(false);
        org.jfree.data.Range range50 = xYPlot27.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis42);
        java.util.List list51 = xYPlot27.getAnnotations();
        boolean boolean52 = legendItemCollection1.equals((java.lang.Object) list51);
        legendItemCollection0.addAll(legendItemCollection1);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.18d + "'", double14 == 0.18d);
        org.junit.Assert.assertTrue("'" + float32 + "' != '" + 1.0f + "'", float32 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNull(range50);
        org.junit.Assert.assertNotNull(list51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.clearDomainMarkers(15);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        float float26 = categoryPlot25.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot25.getRangeAxisLocation();
        xYPlot21.setDomainAxisLocation((int) (byte) 0, axisLocation27, true);
        boolean boolean30 = xYPlot21.isRangeZoomable();
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = xYPlot21.getDomainAxisEdge();
        xYPlot21.setWeight((int) (short) 1);
        java.awt.Paint paint34 = xYPlot21.getDomainGridlinePaint();
        xYPlot21.setDomainCrosshairVisible(false);
        java.awt.Stroke stroke37 = null;
        try {
            xYPlot21.setDomainGridlineStroke(stroke37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 1.0f + "'", float26 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNotNull(paint34);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.clearDomainMarkers(15);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        float float26 = categoryPlot25.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot25.getRangeAxisLocation();
        xYPlot21.setDomainAxisLocation((int) (byte) 0, axisLocation27, true);
        xYPlot21.setDomainCrosshairValue((double) 'a');
        xYPlot21.mapDatasetToRangeAxis(100, 255);
        org.jfree.chart.axis.AxisSpace axisSpace35 = null;
        xYPlot21.setFixedRangeAxisSpace(axisSpace35);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer37 = xYPlot21.getRenderer();
        java.awt.Paint paint38 = xYPlot21.getRangeTickBandPaint();
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 1.0f + "'", float26 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNull(xYItemRenderer37);
        org.junit.Assert.assertNull(paint38);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 1L, (double) 128);
        size2D2.height = 0.2d;
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        boolean boolean2 = piePlot3D1.getDarkerSides();
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = piePlot4.getSimpleLabelOffset();
        boolean boolean6 = piePlot4.getSectionOutlinesVisible();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator7 = null;
        piePlot4.setLegendLabelURLGenerator(pieURLGenerator7);
        boolean boolean9 = piePlot4.getSimpleLabels();
        boolean boolean10 = piePlot4.getLabelLinksVisible();
        java.lang.String str11 = piePlot4.getPlotType();
        java.awt.Paint paint12 = piePlot4.getShadowPaint();
        piePlot3D1.setSectionOutlinePaint((java.lang.Comparable) 15, paint12);
        double double14 = piePlot3D1.getDepthFactor();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Pie Plot" + "'", str11.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.12d + "'", double14 == 0.12d);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = piePlot0.getSimpleLabelOffset();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        piePlot0.markerChanged(markerChangeEvent2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot0.setLabelBackgroundPaint((java.awt.Paint) color4);
        double double6 = piePlot0.getShadowYOffset();
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = piePlot7.getSimpleLabelOffset();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = null;
        piePlot7.markerChanged(markerChangeEvent9);
        double double11 = piePlot7.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        boolean boolean13 = piePlot7.equals((java.lang.Object) rectangleInsets12);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator14 = piePlot7.getURLGenerator();
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot(xYDataset16, (org.jfree.chart.axis.ValueAxis) dateAxis18, polarItemRenderer19);
        dateAxis18.setLabelAngle((double) (byte) 1);
        dateAxis18.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color25 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int26 = color25.getAlpha();
        java.lang.String str27 = color25.toString();
        dateAxis18.setTickMarkPaint((java.awt.Paint) color25);
        org.jfree.chart.plot.PiePlot piePlot29 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = piePlot29.getSimpleLabelOffset();
        java.awt.Stroke stroke31 = piePlot29.getLabelOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker32 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, (java.awt.Paint) color25, stroke31);
        java.awt.Paint paint33 = valueMarker32.getOutlinePaint();
        java.awt.Font font34 = valueMarker32.getLabelFont();
        java.awt.Paint paint35 = valueMarker32.getOutlinePaint();
        piePlot7.setLabelLinkPaint(paint35);
        piePlot0.setBaseSectionOutlinePaint(paint35);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(pieURLGenerator14);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 255 + "'", int26 == 255);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str27.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNotNull(paint35);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) dateAxis6, polarItemRenderer7);
        dateAxis6.setLabelAngle((double) (byte) 1);
        dateAxis6.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int14 = color13.getAlpha();
        dateAxis6.setTickLabelPaint((java.awt.Paint) color13);
        int int16 = color13.getRed();
        org.jfree.chart.block.BlockBorder blockBorder17 = new org.jfree.chart.block.BlockBorder((double) ' ', 1.0d, (double) (-16777216), (double) 64, (java.awt.Paint) color13);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 255 + "'", int14 == 255);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 255 + "'", int16 == 255);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        java.lang.Comparable comparable4 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 255, (-16056329), comparable4, "java.awt.Color[r=255,g=255,b=64]", "ClassContext");
        pieSectionEntity7.setPieIndex(128);
        try {
            java.lang.String str10 = pieSectionEntity7.toString();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        boolean boolean2 = jFreeChartResources0.containsKey("java.awt.Color[r=255,g=255,b=64]");
        java.util.Locale locale3 = jFreeChartResources0.getLocale();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(locale3);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        dateAxis2.setLabelAngle((double) (byte) 1);
        dateAxis2.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int10 = color9.getAlpha();
        dateAxis2.setTickLabelPaint((java.awt.Paint) color9);
        dateAxis2.setInverted(false);
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer18 = null;
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) dateAxis17, polarItemRenderer18);
        org.jfree.chart.plot.PiePlot piePlot20 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = piePlot20.getSimpleLabelOffset();
        double double22 = rectangleInsets21.getRight();
        dateAxis17.setLabelInsets(rectangleInsets21);
        dateAxis17.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("");
        dateAxis28.setRange((double) 0.0f, (double) 10.0f);
        dateAxis28.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset14, (org.jfree.chart.axis.ValueAxis) dateAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis28, xYItemRenderer34);
        xYPlot35.clearDomainMarkers(15);
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot();
        float float40 = categoryPlot39.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation41 = categoryPlot39.getRangeAxisLocation();
        xYPlot35.setDomainAxisLocation((int) (byte) 0, axisLocation41, true);
        boolean boolean44 = xYPlot35.isRangeZoomable();
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = xYPlot35.getDomainAxisEdge();
        boolean boolean46 = dateAxis2.hasListener((java.util.EventListener) xYPlot35);
        java.awt.Color color47 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        java.awt.Color color48 = color47.darker();
        dateAxis2.setTickMarkPaint((java.awt.Paint) color47);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 255 + "'", int10 == 255);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.18d + "'", double22 == 0.18d);
        org.junit.Assert.assertTrue("'" + float40 + "' != '" + 1.0f + "'", float40 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(rectangleEdge45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(color48);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.setDomainGridlinesVisible(true);
        double double24 = xYPlot21.getDomainCrosshairValue();
        boolean boolean25 = xYPlot21.isDomainCrosshairLockedOnData();
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer29 = null;
        org.jfree.chart.plot.PolarPlot polarPlot30 = new org.jfree.chart.plot.PolarPlot(xYDataset26, (org.jfree.chart.axis.ValueAxis) dateAxis28, polarItemRenderer29);
        dateAxis28.setLabelAngle((double) (byte) 1);
        dateAxis28.setTickMarkOutsideLength((-1.0f));
        dateAxis28.setFixedDimension(0.4d);
        java.awt.Paint paint37 = dateAxis28.getTickMarkPaint();
        xYPlot21.setDomainZeroBaselinePaint(paint37);
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot();
        float float40 = categoryPlot39.getForegroundAlpha();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = categoryPlot39.getRenderer(255);
        org.jfree.data.category.CategoryDataset categoryDataset43 = null;
        categoryPlot39.setDataset(categoryDataset43);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier45 = categoryPlot39.getDrawingSupplier();
        org.jfree.chart.axis.NumberAxis numberAxis48 = new org.jfree.chart.axis.NumberAxis("Size2D[width=0.0, height=0.0]");
        numberAxis48.setAutoRangeStickyZero(true);
        boolean boolean51 = numberAxis48.getAutoRangeStickyZero();
        boolean boolean52 = numberAxis48.isVisible();
        java.text.NumberFormat numberFormat53 = numberAxis48.getNumberFormatOverride();
        numberAxis48.setAutoRangeIncludesZero(true);
        java.lang.String str56 = numberAxis48.getLabelToolTip();
        java.text.NumberFormat numberFormat57 = null;
        numberAxis48.setNumberFormatOverride(numberFormat57);
        categoryPlot39.setRangeAxis(15, (org.jfree.chart.axis.ValueAxis) numberAxis48, false);
        org.jfree.data.Range range61 = xYPlot21.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis48);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertTrue("'" + float40 + "' != '" + 1.0f + "'", float40 == 1.0f);
        org.junit.Assert.assertNull(categoryItemRenderer42);
        org.junit.Assert.assertNotNull(drawingSupplier45);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNull(numberFormat53);
        org.junit.Assert.assertNull(str56);
        org.junit.Assert.assertNull(range61);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Polar Plot");
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Color color2 = color1.brighter();
        java.awt.Color color3 = color2.brighter();
        ringPlot0.setLabelOutlinePaint((java.awt.Paint) color2);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) dateAxis8, polarItemRenderer9);
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = piePlot11.getSimpleLabelOffset();
        double double13 = rectangleInsets12.getRight();
        dateAxis8.setLabelInsets(rectangleInsets12);
        dateAxis8.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("");
        dateAxis19.setRange((double) 0.0f, (double) 10.0f);
        dateAxis19.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) dateAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis19, xYItemRenderer25);
        java.awt.Stroke stroke27 = xYPlot26.getDomainZeroBaselineStroke();
        java.awt.Paint paint28 = xYPlot26.getRangeGridlinePaint();
        boolean boolean29 = color2.equals((java.lang.Object) paint28);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.18d + "'", double13 == 0.18d);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = null;
        org.jfree.chart.text.TextBlock textBlock3 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint2);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.util.Size2D size2D5 = textBlock3.calculateDimensions(graphics2D4);
        java.lang.String str6 = size2D5.toString();
        org.junit.Assert.assertNotNull(textBlock3);
        org.junit.Assert.assertNotNull(size2D5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str6.equals("Size2D[width=0.0, height=0.0]"));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        java.awt.Font font1 = null;
        java.awt.Color color2 = java.awt.Color.blue;
        try {
            org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("", font1, (java.awt.Paint) color2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.clearDomainMarkers(15);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer27 = null;
        org.jfree.chart.plot.PolarPlot polarPlot28 = new org.jfree.chart.plot.PolarPlot(xYDataset24, (org.jfree.chart.axis.ValueAxis) dateAxis26, polarItemRenderer27);
        dateAxis26.setLabelAngle((double) (byte) 1);
        dateAxis26.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color33 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int34 = color33.getAlpha();
        dateAxis26.setTickLabelPaint((java.awt.Paint) color33);
        dateAxis26.setInverted(false);
        double double38 = dateAxis26.getLowerBound();
        org.jfree.data.Range range39 = xYPlot21.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis26);
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = xYPlot21.getRangeAxisEdge();
        java.util.List list41 = xYPlot21.getAnnotations();
        org.jfree.chart.util.Layer layer43 = null;
        java.util.Collection collection44 = xYPlot21.getRangeMarkers((int) (byte) -1, layer43);
        org.jfree.data.xy.XYDataset xYDataset45 = null;
        xYPlot21.setDataset(xYDataset45);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        int int48 = xYPlot21.getIndexOf(xYItemRenderer47);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 255 + "'", int34 == 255);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNull(range39);
        org.junit.Assert.assertNotNull(rectangleEdge40);
        org.junit.Assert.assertNotNull(list41);
        org.junit.Assert.assertNull(collection44);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        piePlotState1.setTotal((double) (short) 0);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) dateAxis6, polarItemRenderer7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot8);
        java.awt.geom.Rectangle2D rectangle2D10 = legendTitle9.getBounds();
        piePlotState1.setLinkArea(rectangle2D10);
        java.awt.geom.Rectangle2D rectangle2D12 = piePlotState1.getPieArea();
        piePlotState1.setPieCenterY((double) 1);
        double double15 = piePlotState1.getLatestAngle();
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertNull(rectangle2D12);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.clearDomainMarkers(15);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        float float26 = categoryPlot25.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot25.getRangeAxisLocation();
        xYPlot21.setDomainAxisLocation((int) (byte) 0, axisLocation27, true);
        xYPlot21.setDomainCrosshairValue((double) 'a');
        org.jfree.chart.axis.AxisLocation axisLocation32 = xYPlot21.getRangeAxisLocation();
        java.awt.Stroke stroke33 = xYPlot21.getRangeCrosshairStroke();
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 1.0f + "'", float26 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertNotNull(stroke33);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot4);
        org.jfree.chart.block.BlockContainer blockContainer6 = legendTitle5.getItemContainer();
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = piePlot7.getSimpleLabelOffset();
        boolean boolean9 = piePlot7.getSectionOutlinesVisible();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator10 = null;
        piePlot7.setLegendLabelURLGenerator(pieURLGenerator10);
        boolean boolean12 = piePlot7.getSimpleLabels();
        org.jfree.chart.plot.RingPlot ringPlot13 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint14 = ringPlot13.getShadowPaint();
        ringPlot13.setInteriorGap((double) (byte) 0);
        java.awt.Font font17 = ringPlot13.getNoDataMessageFont();
        piePlot7.setLabelFont(font17);
        legendTitle5.setItemFont(font17);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = legendTitle5.getPosition();
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = legendTitle5.getLegendItemGraphicEdge();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent22 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle5);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = legendTitle5.getLegendItemGraphicPadding();
        org.junit.Assert.assertNotNull(blockContainer6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertNotNull(rectangleInsets23);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = null;
        dateAxis1.setStandardTickUnits(tickUnitSource2);
        java.awt.Stroke stroke4 = dateAxis1.getTickMarkStroke();
        double double5 = dateAxis1.getUpperMargin();
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis1.setRange((org.jfree.data.Range) dateRange6);
        dateAxis1.resizeRange((double) (short) 100, (double) (byte) 0);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(dateRange6);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        java.lang.String str2 = textTitle1.getToolTipText();
        java.awt.Paint paint3 = textTitle1.getBackgroundPaint();
        double double4 = textTitle1.getContentXOffset();
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = blockBorder5.getInsets();
        textTitle1.setFrame((org.jfree.chart.block.BlockFrame) blockBorder5);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        float float9 = categoryPlot8.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot8.getRangeAxisLocation();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = categoryPlot8.getRenderer();
        boolean boolean12 = categoryPlot8.isRangeZoomable();
        org.jfree.chart.plot.PlotOrientation plotOrientation13 = categoryPlot8.getOrientation();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource16 = null;
        dateAxis15.setStandardTickUnits(tickUnitSource16);
        java.awt.Stroke stroke18 = dateAxis15.getTickMarkStroke();
        boolean boolean19 = plotOrientation13.equals((java.lang.Object) stroke18);
        boolean boolean20 = blockBorder5.equals((java.lang.Object) boolean19);
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer26 = null;
        org.jfree.chart.plot.PolarPlot polarPlot27 = new org.jfree.chart.plot.PolarPlot(xYDataset23, (org.jfree.chart.axis.ValueAxis) dateAxis25, polarItemRenderer26);
        org.jfree.chart.plot.PiePlot piePlot28 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = piePlot28.getSimpleLabelOffset();
        double double30 = rectangleInsets29.getRight();
        dateAxis25.setLabelInsets(rectangleInsets29);
        dateAxis25.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis("");
        dateAxis36.setRange((double) 0.0f, (double) 10.0f);
        dateAxis36.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = null;
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot(xYDataset22, (org.jfree.chart.axis.ValueAxis) dateAxis25, (org.jfree.chart.axis.ValueAxis) dateAxis36, xYItemRenderer42);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo45 = null;
        java.awt.geom.Point2D point2D46 = null;
        xYPlot43.zoomRangeAxes((double) ' ', plotRenderingInfo45, point2D46);
        java.awt.Paint paint48 = xYPlot43.getDomainTickBandPaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent49 = null;
        xYPlot43.rendererChanged(rendererChangeEvent49);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray51 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot43.setRenderers(xYItemRendererArray51);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder53 = xYPlot43.getDatasetRenderingOrder();
        java.awt.Paint paint54 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        java.lang.Class<?> wildcardClass55 = paint54.getClass();
        xYPlot43.setDomainGridlinePaint(paint54);
        java.awt.Graphics2D graphics2D57 = null;
        org.jfree.chart.util.Size2D size2D60 = new org.jfree.chart.util.Size2D((double) ' ', 0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor63 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.geom.Rectangle2D rectangle2D64 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D60, 0.0d, 10.0d, rectangleAnchor63);
        org.jfree.chart.plot.CategoryPlot categoryPlot65 = new org.jfree.chart.plot.CategoryPlot();
        float float66 = categoryPlot65.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation67 = categoryPlot65.getRangeAxisLocation();
        org.jfree.chart.axis.AxisSpace axisSpace68 = null;
        categoryPlot65.setFixedDomainAxisSpace(axisSpace68);
        org.jfree.chart.axis.CategoryAxis categoryAxis70 = null;
        java.util.List list71 = categoryPlot65.getCategoriesForAxis(categoryAxis70);
        xYPlot43.drawRangeTickBands(graphics2D57, rectangle2D64, list71);
        try {
            blockBorder5.draw(graphics2D21, rectangle2D64);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNull(categoryItemRenderer11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(plotOrientation13);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.18d + "'", double30 == 0.18d);
        org.junit.Assert.assertNull(paint48);
        org.junit.Assert.assertNotNull(xYItemRendererArray51);
        org.junit.Assert.assertNotNull(datasetRenderingOrder53);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertNotNull(rectangleAnchor63);
        org.junit.Assert.assertNotNull(rectangle2D64);
        org.junit.Assert.assertTrue("'" + float66 + "' != '" + 1.0f + "'", float66 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation67);
        org.junit.Assert.assertNotNull(list71);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) ' ');
        java.lang.Object obj3 = objectList1.get((int) (short) -1);
        java.lang.Object obj5 = objectList1.get((-1));
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertNull(obj5);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("ClassContext");
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.util.RectangleEdge.TOP;
        textTitle1.setPosition(rectangleEdge2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = textTitle1.getVerticalAlignment();
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(verticalAlignment4);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        java.text.NumberFormat numberFormat1 = null;
        java.text.NumberFormat numberFormat2 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Polar Plot", numberFormat1, numberFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'numberFormat' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot4);
        legendTitle5.setPadding(0.0d, 0.5d, (double) 1.0f, 32.0d);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer15 = null;
        org.jfree.chart.plot.PolarPlot polarPlot16 = new org.jfree.chart.plot.PolarPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) dateAxis14, polarItemRenderer15);
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot16);
        java.awt.geom.Rectangle2D rectangle2D18 = legendTitle17.getBounds();
        try {
            legendTitle5.draw(graphics2D11, rectangle2D18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D18);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.clearDomainMarkers(15);
        double double24 = xYPlot21.getRangeCrosshairValue();
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        boolean boolean2 = categoryPlot0.isDomainGridlinesVisible();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        boolean boolean7 = categoryPlot0.render(graphics2D3, rectangle2D4, (int) (byte) 10, plotRenderingInfo6);
        categoryPlot0.setNoDataMessage("LengthConstraintType.FIXED");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.getSimpleLabels();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.lang.Object obj1 = categoryAxis3D0.clone();
        categoryAxis3D0.setMaximumCategoryLabelLines((int) (byte) 100);
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        int int6 = polarPlot5.getBackgroundImageAlignment();
        boolean boolean7 = polarPlot5.isSubplot();
        boolean boolean8 = polarPlot5.isDomainZoomable();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        polarPlot5.zoomRangeAxes((double) 0.0f, plotRenderingInfo10, point2D11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer16 = null;
        org.jfree.chart.plot.PolarPlot polarPlot17 = new org.jfree.chart.plot.PolarPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis15, polarItemRenderer16);
        dateAxis15.setLabelAngle((double) (byte) 1);
        dateAxis15.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int23 = color22.getAlpha();
        java.lang.String str24 = color22.toString();
        dateAxis15.setTickMarkPaint((java.awt.Paint) color22);
        polarPlot5.setAngleGridlinePaint((java.awt.Paint) color22);
        org.jfree.chart.block.BlockBorder blockBorder27 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, (java.awt.Paint) color22);
        double double29 = rectangleInsets0.calculateLeftOutset((double) 10L);
        double double31 = rectangleInsets0.calculateRightInset(1.0d);
        double double33 = rectangleInsets0.trimWidth(1.5d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 255 + "'", int23 == 255);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str24.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0d + "'", double31 == 1.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + (-0.5d) + "'", double33 == (-0.5d));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = new org.jfree.chart.LegendItemCollection();
        legendItemCollection0.addAll(legendItemCollection1);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource5 = null;
        dateAxis4.setStandardTickUnits(tickUnitSource5);
        dateAxis4.setFixedAutoRange((double) 100L);
        java.awt.Font font9 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        dateAxis4.setLabelFont(font9);
        dateAxis4.setAxisLineVisible(false);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer17 = null;
        org.jfree.chart.plot.PolarPlot polarPlot18 = new org.jfree.chart.plot.PolarPlot(xYDataset14, (org.jfree.chart.axis.ValueAxis) dateAxis16, polarItemRenderer17);
        org.jfree.chart.plot.PiePlot piePlot19 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = piePlot19.getSimpleLabelOffset();
        double double21 = rectangleInsets20.getRight();
        dateAxis16.setLabelInsets(rectangleInsets20);
        dateAxis16.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("");
        dateAxis27.setRange((double) 0.0f, (double) 10.0f);
        dateAxis27.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis27, xYItemRenderer33);
        java.awt.Stroke stroke35 = xYPlot34.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("");
        java.util.Date date39 = dateAxis38.getMaximumDate();
        xYPlot34.setRangeAxis((int) (short) 100, (org.jfree.chart.axis.ValueAxis) dateAxis38);
        java.util.Date date41 = dateAxis38.getMinimumDate();
        org.jfree.chart.title.TextTitle textTitle43 = new org.jfree.chart.title.TextTitle("hi!");
        java.lang.String str44 = textTitle43.getToolTipText();
        java.awt.geom.Rectangle2D rectangle2D45 = textTitle43.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = null;
        double double47 = dateAxis4.dateToJava2D(date41, rectangle2D45, rectangleEdge46);
        boolean boolean48 = legendItemCollection1.equals((java.lang.Object) double47);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.18d + "'", double21 == 0.18d);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        piePlotState1.setTotal((double) (short) 0);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.image.ColorModel colorModel5 = null;
        java.awt.Rectangle rectangle6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = piePlot7.getSimpleLabelOffset();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer12 = null;
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) dateAxis11, polarItemRenderer12);
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot13);
        java.awt.geom.Rectangle2D rectangle2D15 = legendTitle14.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType16 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = rectangleInsets8.createAdjustedRectangle(rectangle2D15, lengthAdjustmentType16, lengthAdjustmentType17);
        java.awt.geom.AffineTransform affineTransform19 = null;
        java.awt.RenderingHints renderingHints20 = null;
        java.awt.PaintContext paintContext21 = color4.createContext(colorModel5, rectangle6, rectangle2D18, affineTransform19, renderingHints20);
        piePlotState1.setLinkArea((java.awt.geom.Rectangle2D) rectangle6);
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle("hi!");
        java.lang.String str25 = textTitle24.getToolTipText();
        java.awt.geom.Rectangle2D rectangle2D26 = textTitle24.getBounds();
        java.awt.geom.Rectangle2D rectangle2D27 = textTitle24.getBounds();
        piePlotState1.setExplodedPieArea(rectangle2D27);
        org.jfree.chart.util.Size2D size2D31 = new org.jfree.chart.util.Size2D((double) ' ', 0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor34 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D35 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D31, (double) 100.0f, (double) (byte) 0, rectangleAnchor34);
        piePlotState1.setExplodedPieArea(rectangle2D35);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(paintContext21);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(rectangleAnchor34);
        org.junit.Assert.assertNotNull(rectangle2D35);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.chart.block.BlockResult blockResult0 = new org.jfree.chart.block.BlockResult();
        org.jfree.chart.entity.EntityCollection entityCollection1 = blockResult0.getEntityCollection();
        org.jfree.chart.entity.EntityCollection entityCollection2 = null;
        blockResult0.setEntityCollection(entityCollection2);
        org.jfree.chart.entity.EntityCollection entityCollection4 = null;
        blockResult0.setEntityCollection(entityCollection4);
        org.junit.Assert.assertNull(entityCollection1);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setInnerSeparatorExtension((double) '#');
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = null;
        ringPlot0.setLegendLabelToolTipGenerator(pieSectionLabelGenerator3);
        ringPlot0.setShadowXOffset(0.5d);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator7 = null;
        ringPlot0.setLegendLabelURLGenerator(pieURLGenerator7);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.clearDomainMarkers(15);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer27 = null;
        org.jfree.chart.plot.PolarPlot polarPlot28 = new org.jfree.chart.plot.PolarPlot(xYDataset24, (org.jfree.chart.axis.ValueAxis) dateAxis26, polarItemRenderer27);
        dateAxis26.setLabelAngle((double) (byte) 1);
        dateAxis26.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color33 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int34 = color33.getAlpha();
        dateAxis26.setTickLabelPaint((java.awt.Paint) color33);
        dateAxis26.setInverted(false);
        double double38 = dateAxis26.getLowerBound();
        org.jfree.data.Range range39 = xYPlot21.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis26);
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("");
        dateAxis41.setRange((double) 0.0f, (double) 10.0f);
        dateAxis41.resizeRange((double) ' ');
        dateAxis41.setLowerBound((double) (short) 0);
        org.jfree.data.Range range49 = xYPlot21.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis41);
        org.jfree.chart.axis.Timeline timeline50 = dateAxis41.getTimeline();
        dateAxis41.resizeRange(1.0E-8d);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 255 + "'", int34 == 255);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNull(range39);
        org.junit.Assert.assertNull(range49);
        org.junit.Assert.assertNotNull(timeline50);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.clearDomainMarkers(15);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer27 = null;
        org.jfree.chart.plot.PolarPlot polarPlot28 = new org.jfree.chart.plot.PolarPlot(xYDataset24, (org.jfree.chart.axis.ValueAxis) dateAxis26, polarItemRenderer27);
        dateAxis26.setLabelAngle((double) (byte) 1);
        dateAxis26.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color33 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int34 = color33.getAlpha();
        dateAxis26.setTickLabelPaint((java.awt.Paint) color33);
        dateAxis26.setInverted(false);
        double double38 = dateAxis26.getLowerBound();
        org.jfree.data.Range range39 = xYPlot21.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis26);
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("");
        dateAxis41.setRange((double) 0.0f, (double) 10.0f);
        dateAxis41.resizeRange((double) ' ');
        dateAxis41.setLowerBound((double) (short) 0);
        org.jfree.data.Range range49 = xYPlot21.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis41);
        double double50 = dateAxis41.getFixedDimension();
        java.lang.String str51 = dateAxis41.getLabelURL();
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 255 + "'", int34 == 255);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNull(range39);
        org.junit.Assert.assertNull(range49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertNull(str51);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setMaximumCategoryLabelLines(0);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.clearDomainMarkers(15);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer27 = null;
        org.jfree.chart.plot.PolarPlot polarPlot28 = new org.jfree.chart.plot.PolarPlot(xYDataset24, (org.jfree.chart.axis.ValueAxis) dateAxis26, polarItemRenderer27);
        dateAxis26.setLabelAngle((double) (byte) 1);
        dateAxis26.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color33 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int34 = color33.getAlpha();
        dateAxis26.setTickLabelPaint((java.awt.Paint) color33);
        dateAxis26.setInverted(false);
        double double38 = dateAxis26.getLowerBound();
        org.jfree.data.Range range39 = xYPlot21.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis26);
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = xYPlot21.getRangeAxisEdge();
        java.awt.Graphics2D graphics2D41 = null;
        org.jfree.chart.title.TextTitle textTitle43 = new org.jfree.chart.title.TextTitle("hi!");
        java.lang.String str44 = textTitle43.getToolTipText();
        java.awt.geom.Rectangle2D rectangle2D45 = textTitle43.getBounds();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = null;
        xYPlot21.drawAnnotations(graphics2D41, rectangle2D45, plotRenderingInfo46);
        java.lang.String str48 = xYPlot21.getPlotType();
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 255 + "'", int34 == 255);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNull(range39);
        org.junit.Assert.assertNotNull(rectangleEdge40);
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "XY Plot" + "'", str48.equals("XY Plot"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor(0);
        try {
            org.jfree.chart.plot.PieLabelRecord pieLabelRecord3 = pieLabelDistributor1.getPieLabelRecord((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        org.jfree.data.time.DateRange dateRange5 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double6 = dateRange5.getUpperBound();
        dateAxis2.setRange((org.jfree.data.Range) dateRange5);
        try {
            dateAxis2.setAutoRangeMinimumSize(0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateRange5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        boolean boolean2 = categoryPlot0.isDomainGridlinesVisible();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        boolean boolean7 = categoryPlot0.render(graphics2D3, rectangle2D4, (int) (byte) 10, plotRenderingInfo6);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean9 = categoryPlot8.isDomainGridlinesVisible();
        boolean boolean10 = categoryPlot8.isDomainGridlinesVisible();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        boolean boolean15 = categoryPlot8.render(graphics2D11, rectangle2D12, (int) (byte) 10, plotRenderingInfo14);
        org.jfree.data.category.CategoryDataset categoryDataset17 = categoryPlot8.getDataset((int) ' ');
        org.jfree.chart.util.SortOrder sortOrder18 = categoryPlot8.getRowRenderingOrder();
        categoryPlot0.setColumnRenderingOrder(sortOrder18);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(categoryDataset17);
        org.junit.Assert.assertNotNull(sortOrder18);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot4);
        org.jfree.chart.block.BlockContainer blockContainer6 = legendTitle5.getItemContainer();
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = piePlot7.getSimpleLabelOffset();
        boolean boolean9 = piePlot7.getSectionOutlinesVisible();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator10 = null;
        piePlot7.setLegendLabelURLGenerator(pieURLGenerator10);
        boolean boolean12 = piePlot7.getSimpleLabels();
        org.jfree.chart.plot.RingPlot ringPlot13 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint14 = ringPlot13.getShadowPaint();
        ringPlot13.setInteriorGap((double) (byte) 0);
        java.awt.Font font17 = ringPlot13.getNoDataMessageFont();
        piePlot7.setLabelFont(font17);
        legendTitle5.setItemFont(font17);
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer24 = null;
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot(xYDataset21, (org.jfree.chart.axis.ValueAxis) dateAxis23, polarItemRenderer24);
        dateAxis23.setLabelAngle((double) (byte) 1);
        java.awt.Font font28 = dateAxis23.getTickLabelFont();
        org.jfree.chart.text.TextLine textLine29 = new org.jfree.chart.text.TextLine("", font28);
        org.jfree.chart.text.TextFragment textFragment30 = textLine29.getLastTextFragment();
        java.awt.Paint paint31 = textFragment30.getPaint();
        boolean boolean32 = legendTitle5.equals((java.lang.Object) paint31);
        org.junit.Assert.assertNotNull(blockContainer6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(textFragment30);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Size2D[width=0.0, height=0.0]");
        numberAxis1.setAutoRangeStickyZero(true);
        boolean boolean4 = numberAxis1.getAutoRangeStickyZero();
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent8 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) boolean4, jFreeChart5, (int) '4', (int) (byte) 100);
        org.jfree.chart.JFreeChart jFreeChart9 = null;
        chartProgressEvent8.setChart(jFreeChart9);
        chartProgressEvent8.setPercent((int) 'a');
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer17 = null;
        org.jfree.chart.plot.PolarPlot polarPlot18 = new org.jfree.chart.plot.PolarPlot(xYDataset14, (org.jfree.chart.axis.ValueAxis) dateAxis16, polarItemRenderer17);
        int int19 = polarPlot18.getBackgroundImageAlignment();
        boolean boolean20 = polarPlot18.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) polarPlot18);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo24 = null;
        java.awt.image.BufferedImage bufferedImage25 = jFreeChart21.createBufferedImage(100, 255, chartRenderingInfo24);
        chartProgressEvent8.setChart(jFreeChart21);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 15 + "'", int19 == 15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(bufferedImage25);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) ' ', 0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.geom.Rectangle2D rectangle2D6 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D2, 0.0d, 10.0d, rectangleAnchor5);
        double double7 = size2D2.height;
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("java.awt.Color[r=255,g=255,b=64]", "hi!", "", "java.awt.Color[r=255,g=255,b=64]");
        java.lang.String str5 = basicProjectInfo4.getName();
        basicProjectInfo4.setName("TextBlockAnchor.CENTER_RIGHT");
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str5.equals("java.awt.Color[r=255,g=255,b=64]"));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        int int6 = polarPlot5.getBackgroundImageAlignment();
        boolean boolean7 = polarPlot5.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) polarPlot5);
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer13 = null;
        org.jfree.chart.plot.PolarPlot polarPlot14 = new org.jfree.chart.plot.PolarPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) dateAxis12, polarItemRenderer13);
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = piePlot15.getSimpleLabelOffset();
        double double17 = rectangleInsets16.getRight();
        dateAxis12.setLabelInsets(rectangleInsets16);
        dateAxis12.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("");
        dateAxis23.setRange((double) 0.0f, (double) 10.0f);
        dateAxis23.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis23, xYItemRenderer29);
        xYPlot30.clearDomainMarkers(15);
        org.jfree.data.xy.XYDataset xYDataset33 = null;
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer36 = null;
        org.jfree.chart.plot.PolarPlot polarPlot37 = new org.jfree.chart.plot.PolarPlot(xYDataset33, (org.jfree.chart.axis.ValueAxis) dateAxis35, polarItemRenderer36);
        dateAxis35.setLabelAngle((double) (byte) 1);
        dateAxis35.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color42 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int43 = color42.getAlpha();
        dateAxis35.setTickLabelPaint((java.awt.Paint) color42);
        dateAxis35.setInverted(false);
        double double47 = dateAxis35.getLowerBound();
        org.jfree.data.Range range48 = xYPlot30.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis35);
        org.jfree.chart.util.RectangleEdge rectangleEdge49 = xYPlot30.getRangeAxisEdge();
        java.util.List list50 = xYPlot30.getAnnotations();
        jFreeChart8.setSubtitles(list50);
        jFreeChart8.setTitle("RectangleAnchor.BOTTOM_LEFT");
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.18d + "'", double17 == 0.18d);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 255 + "'", int43 == 255);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNull(range48);
        org.junit.Assert.assertNotNull(rectangleEdge49);
        org.junit.Assert.assertNotNull(list50);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("XY Plot");
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        java.awt.Color color0 = java.awt.Color.CYAN;
        int int1 = color0.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.data.time.DateRange dateRange2 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = new org.jfree.chart.block.RectangleConstraint((double) '#', (org.jfree.data.Range) dateRange2);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = new org.jfree.chart.block.RectangleConstraint(10.0d, (org.jfree.data.Range) dateRange2);
        org.jfree.data.Range range7 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange2, 0.14d, true);
        org.junit.Assert.assertNotNull(dateRange2);
        org.junit.Assert.assertNotNull(range7);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        xYPlot21.zoomRangeAxes((double) ' ', plotRenderingInfo23, point2D24);
        java.awt.Stroke stroke26 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot21.setDomainGridlineStroke(stroke26);
        org.jfree.chart.axis.ValueAxis valueAxis28 = xYPlot21.getDomainAxis();
        java.awt.Paint paint29 = xYPlot21.getBackgroundPaint();
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(valueAxis28);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = piePlot0.getSimpleLabelOffset();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        piePlot0.markerChanged(markerChangeEvent2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot0.setLabelBackgroundPaint((java.awt.Paint) color4);
        double double6 = piePlot0.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        piePlot0.setInsets(rectangleInsets7, false);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets7);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = categoryPlot0.getRenderer();
        java.lang.String str4 = categoryPlot0.getPlotType();
        java.awt.Color color6 = java.awt.Color.GRAY;
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer11 = null;
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot(xYDataset8, (org.jfree.chart.axis.ValueAxis) dateAxis10, polarItemRenderer11);
        dateAxis10.setLabelAngle((double) (byte) 1);
        dateAxis10.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int18 = color17.getAlpha();
        java.lang.String str19 = color17.toString();
        dateAxis10.setTickMarkPaint((java.awt.Paint) color17);
        org.jfree.chart.plot.PiePlot piePlot21 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = piePlot21.getSimpleLabelOffset();
        java.awt.Stroke stroke23 = piePlot21.getLabelOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, (java.awt.Paint) color17, stroke23);
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((-1.0d), (java.awt.Paint) color6, stroke23);
        org.jfree.chart.util.Layer layer26 = null;
        boolean boolean27 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker25, layer26);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNull(categoryItemRenderer3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Category Plot" + "'", str4.equals("Category Plot"));
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 255 + "'", int18 == 255);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str19.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        java.lang.String str2 = textTitle1.getToolTipText();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = textTitle1.getHorizontalAlignment();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) dateAxis6, polarItemRenderer7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot8);
        boolean boolean10 = horizontalAlignment3.equals((java.lang.Object) legendTitle9);
        java.awt.Paint paint11 = legendTitle9.getBackgroundPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = null;
        try {
            legendTitle9.setItemLabelPadding(rectangleInsets12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'padding' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(paint11);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.clearDomainMarkers(15);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        float float26 = categoryPlot25.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot25.getRangeAxisLocation();
        xYPlot21.setDomainAxisLocation((int) (byte) 0, axisLocation27, true);
        xYPlot21.setDomainCrosshairValue((double) 'a');
        boolean boolean32 = xYPlot21.isRangeZeroBaselineVisible();
        double double33 = xYPlot21.getRangeCrosshairValue();
        java.lang.String str34 = xYPlot21.getNoDataMessage();
        org.jfree.data.xy.XYDataset xYDataset35 = null;
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer38 = null;
        org.jfree.chart.plot.PolarPlot polarPlot39 = new org.jfree.chart.plot.PolarPlot(xYDataset35, (org.jfree.chart.axis.ValueAxis) dateAxis37, polarItemRenderer38);
        dateAxis37.setLabelAngle((double) (byte) 1);
        dateAxis37.setAutoRangeMinimumSize((double) (byte) 10);
        double double44 = dateAxis37.getUpperMargin();
        java.awt.Paint paint45 = dateAxis37.getTickLabelPaint();
        xYPlot21.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis37);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 1.0f + "'", float26 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.05d + "'", double44 == 0.05d);
        org.junit.Assert.assertNotNull(paint45);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = categoryPlot0.getRenderer();
        java.lang.String str4 = categoryPlot0.getPlotType();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) dateAxis8, polarItemRenderer9);
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot10);
        java.awt.geom.Rectangle2D rectangle2D12 = legendTitle11.getBounds();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        boolean boolean15 = categoryPlot0.render(graphics2D5, rectangle2D12, (int) (byte) 1, plotRenderingInfo14);
        java.awt.Stroke stroke16 = categoryPlot0.getRangeGridlineStroke();
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = categoryPlot0.getDomainMarkers(layer17);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = categoryPlot0.getDomainAxis(128);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNull(categoryItemRenderer3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Category Plot" + "'", str4.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertNull(categoryAxis20);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        org.jfree.chart.event.PlotChangeListener plotChangeListener22 = null;
        xYPlot21.removeChangeListener(plotChangeListener22);
        double double24 = xYPlot21.getDomainCrosshairValue();
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        java.awt.Paint paint2 = textTitle1.getPaint();
        java.lang.String str3 = textTitle1.getToolTipText();
        java.awt.Font font4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        textTitle1.setFont(font4);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        ringPlot2.setInnerSeparatorExtension((double) '#');
        org.jfree.chart.util.Rotation rotation5 = ringPlot2.getDirection();
        double double6 = ringPlot2.getShadowXOffset();
        double double7 = ringPlot2.getInnerSeparatorExtension();
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer11 = null;
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot(xYDataset8, (org.jfree.chart.axis.ValueAxis) dateAxis10, polarItemRenderer11);
        dateAxis10.setLabelAngle((double) (byte) 1);
        dateAxis10.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int18 = color17.getAlpha();
        java.lang.String str19 = color17.toString();
        dateAxis10.setTickMarkPaint((java.awt.Paint) color17);
        ringPlot2.setLabelShadowPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextLine textLine22 = new org.jfree.chart.text.TextLine("ClassContext", font1, (java.awt.Paint) color17);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer27 = null;
        org.jfree.chart.plot.PolarPlot polarPlot28 = new org.jfree.chart.plot.PolarPlot(xYDataset24, (org.jfree.chart.axis.ValueAxis) dateAxis26, polarItemRenderer27);
        dateAxis26.setLabelAngle((double) (byte) 1);
        java.awt.Font font31 = dateAxis26.getTickLabelFont();
        org.jfree.chart.text.TextLine textLine32 = new org.jfree.chart.text.TextLine("", font31);
        org.jfree.chart.text.TextFragment textFragment33 = textLine32.getLastTextFragment();
        textLine22.removeFragment(textFragment33);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rotation5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 35.0d + "'", double7 == 35.0d);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 255 + "'", int18 == 255);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str19.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(textFragment33);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str1 = projectInfo0.toString();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo7 = new org.jfree.chart.ui.BasicProjectInfo("", "java.awt.Color[r=255,g=255,b=64]", "", "java.awt.Color[r=255,g=255,b=64]", "java.awt.Color[r=255,g=255,b=64]");
        projectInfo0.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo7);
        projectInfo0.setVersion("Polar Plot");
        org.junit.Assert.assertNotNull(projectInfo0);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.clearDomainMarkers(15);
        org.jfree.chart.plot.PlotOrientation plotOrientation24 = xYPlot21.getOrientation();
        org.jfree.chart.axis.AxisSpace axisSpace25 = null;
        xYPlot21.setFixedDomainAxisSpace(axisSpace25, false);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertNotNull(plotOrientation24);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = piePlot0.getSimpleLabelOffset();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        piePlot0.markerChanged(markerChangeEvent2);
        java.lang.Object obj4 = piePlot0.clone();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator5 = null;
        piePlot0.setToolTipGenerator(pieToolTipGenerator5);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D("ClassContext");
        numberAxis3D8.setLabel("RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]");
        numberAxis3D8.setUpperBound((double) 0);
        double double13 = numberAxis3D8.getFixedAutoRange();
        java.awt.Paint paint14 = numberAxis3D8.getTickMarkPaint();
        piePlot0.setShadowPaint(paint14);
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle("hi!");
        java.lang.String str18 = textTitle17.getToolTipText();
        java.awt.Paint paint19 = textTitle17.getBackgroundPaint();
        double double20 = textTitle17.getContentXOffset();
        org.jfree.chart.block.BlockBorder blockBorder21 = new org.jfree.chart.block.BlockBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = blockBorder21.getInsets();
        textTitle17.setFrame((org.jfree.chart.block.BlockFrame) blockBorder21);
        java.awt.Color color24 = java.awt.Color.gray;
        textTitle17.setPaint((java.awt.Paint) color24);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = textTitle17.getPadding();
        piePlot0.setLabelPadding(rectangleInsets26);
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle("hi!");
        java.lang.String str30 = textTitle29.getToolTipText();
        java.awt.geom.Rectangle2D rectangle2D31 = textTitle29.getBounds();
        java.awt.geom.Rectangle2D rectangle2D32 = textTitle29.getBounds();
        rectangleInsets26.trim(rectangle2D32);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(rectangle2D32);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 100, 0.4d);
        org.jfree.data.time.DateRange dateRange11 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((double) '#', (org.jfree.data.Range) dateRange11);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint9.toRangeHeight((org.jfree.data.Range) dateRange11);
        org.jfree.chart.util.Size2D size2D14 = legendTitle5.arrange(graphics2D6, rectangleConstraint9);
        legendTitle5.setNotify(true);
        java.awt.Paint paint17 = legendTitle5.getBackgroundPaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = legendTitle5.getLegendItemGraphicLocation();
        org.junit.Assert.assertNotNull(dateRange11);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(size2D14);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertNotNull(rectangleAnchor18);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str1 = projectInfo0.toString();
        projectInfo0.setLicenceName("Polar Plot");
        java.lang.String str4 = projectInfo0.toString();
        org.junit.Assert.assertNotNull(projectInfo0);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = piePlot5.getSimpleLabelOffset();
        double double7 = rectangleInsets6.getRight();
        dateAxis2.setLabelInsets(rectangleInsets6);
        java.awt.Shape shape9 = dateAxis2.getLeftArrow();
        dateAxis2.setAxisLineVisible(false);
        dateAxis2.setLabel("");
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer17 = null;
        org.jfree.chart.plot.PolarPlot polarPlot18 = new org.jfree.chart.plot.PolarPlot(xYDataset14, (org.jfree.chart.axis.ValueAxis) dateAxis16, polarItemRenderer17);
        int int19 = polarPlot18.getBackgroundImageAlignment();
        boolean boolean20 = polarPlot18.isSubplot();
        polarPlot18.setBackgroundImageAlignment(0);
        polarPlot18.removeCornerTextItem("Size2D[width=0.0, height=0.0]");
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        polarPlot18.setDataset(xYDataset25);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer30 = null;
        org.jfree.chart.plot.PolarPlot polarPlot31 = new org.jfree.chart.plot.PolarPlot(xYDataset27, (org.jfree.chart.axis.ValueAxis) dateAxis29, polarItemRenderer30);
        int int32 = polarPlot31.getBackgroundImageAlignment();
        boolean boolean33 = polarPlot31.isSubplot();
        java.awt.Color color34 = java.awt.Color.blue;
        polarPlot31.setAngleLabelPaint((java.awt.Paint) color34);
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = polarPlot31.getInsets();
        java.awt.Stroke stroke37 = polarPlot31.getRadiusGridlineStroke();
        polarPlot18.setAngleGridlineStroke(stroke37);
        dateAxis2.setAxisLineStroke(stroke37);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.18d + "'", double7 == 0.18d);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 15 + "'", int19 == 15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 15 + "'", int32 == 15);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertNotNull(stroke37);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) dateAxis4, polarItemRenderer5);
        dateAxis4.setLabelAngle((double) (byte) 1);
        dateAxis4.setTickMarkOutsideLength((-1.0f));
        dateAxis4.setFixedDimension(0.4d);
        double double13 = dateAxis4.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot15.zoomRangeAxes(0.18d, plotRenderingInfo17, point2D18, false);
        java.lang.String str21 = categoryPlot15.getPlotType();
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Category Plot" + "'", str21.equals("Category Plot"));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource3 = null;
        dateAxis2.setStandardTickUnits(tickUnitSource3);
        dateAxis2.setFixedAutoRange((double) 100L);
        java.awt.Font font7 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        dateAxis2.setLabelFont(font7);
        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date10 = dateAxis2.calculateHighestVisibleTickValue(dateTickUnit9);
        double double11 = dateAxis2.getFixedAutoRange();
        boolean boolean12 = textBlockAnchor0.equals((java.lang.Object) dateAxis2);
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(dateTickUnit9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 100.0d + "'", double11 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str1 = projectInfo0.toString();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo7 = new org.jfree.chart.ui.BasicProjectInfo("", "java.awt.Color[r=255,g=255,b=64]", "", "java.awt.Color[r=255,g=255,b=64]", "java.awt.Color[r=255,g=255,b=64]");
        projectInfo0.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo7);
        java.awt.Image image9 = projectInfo0.getLogo();
        java.lang.String str10 = projectInfo0.getLicenceName();
        java.lang.String str11 = projectInfo0.getLicenceName();
        org.jfree.chart.ui.ProjectInfo projectInfo12 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str13 = projectInfo12.toString();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo19 = new org.jfree.chart.ui.BasicProjectInfo("", "java.awt.Color[r=255,g=255,b=64]", "", "java.awt.Color[r=255,g=255,b=64]", "java.awt.Color[r=255,g=255,b=64]");
        projectInfo12.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo19);
        java.awt.Image image21 = projectInfo12.getLogo();
        projectInfo0.setLogo(image21);
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(image9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Polar Plot" + "'", str10.equals("Polar Plot"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Polar Plot" + "'", str11.equals("Polar Plot"));
        org.junit.Assert.assertNotNull(projectInfo12);
        org.junit.Assert.assertNotNull(image21);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = categoryPlot0.getRenderer(255);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        categoryPlot0.setDataset(categoryDataset4);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = categoryPlot0.getDrawingSupplier();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) dateAxis9, polarItemRenderer10);
        dateAxis9.setLabelAngle((double) (byte) 1);
        dateAxis9.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int17 = color16.getAlpha();
        java.lang.String str18 = color16.toString();
        dateAxis9.setTickMarkPaint((java.awt.Paint) color16);
        org.jfree.data.Range range20 = dateAxis9.getDefaultAutoRange();
        boolean boolean21 = dateAxis9.isTickMarksVisible();
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = piePlot23.getSimpleLabelOffset();
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer28 = null;
        org.jfree.chart.plot.PolarPlot polarPlot29 = new org.jfree.chart.plot.PolarPlot(xYDataset25, (org.jfree.chart.axis.ValueAxis) dateAxis27, polarItemRenderer28);
        org.jfree.chart.title.LegendTitle legendTitle30 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot29);
        java.awt.geom.Rectangle2D rectangle2D31 = legendTitle30.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType32 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = rectangleInsets24.createAdjustedRectangle(rectangle2D31, lengthAdjustmentType32, lengthAdjustmentType33);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean36 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge35);
        double double37 = dateAxis9.java2DToValue((double) 8, rectangle2D34, rectangleEdge35);
        boolean boolean38 = categoryPlot0.equals((java.lang.Object) 8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = null;
        categoryPlot0.setRenderer(2, categoryItemRenderer40, false);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNull(categoryItemRenderer3);
        org.junit.Assert.assertNotNull(drawingSupplier6);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 255 + "'", int17 == 255);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str18.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 9.223372036854776E18d + "'", double37 == 9.223372036854776E18d);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        int int6 = polarPlot5.getBackgroundImageAlignment();
        boolean boolean7 = polarPlot5.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) polarPlot5);
        int int9 = jFreeChart8.getSubtitleCount();
        java.util.List list10 = jFreeChart8.getSubtitles();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean12 = categoryPlot11.isDomainGridlinesVisible();
        boolean boolean13 = categoryPlot11.isDomainGridlinesVisible();
        int int14 = categoryPlot11.getRangeAxisCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = categoryPlot11.getDomainAxis((int) (byte) 0);
        org.jfree.chart.LegendItemCollection legendItemCollection17 = categoryPlot11.getFixedLegendItems();
        java.awt.Stroke stroke18 = categoryPlot11.getDomainGridlineStroke();
        jFreeChart8.setBorderStroke(stroke18);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNull(categoryAxis16);
        org.junit.Assert.assertNull(legendItemCollection17);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer5 = new org.jfree.chart.text.G2TextMeasurer(graphics2D4);
        try {
            org.jfree.chart.text.TextBlock textBlock6 = org.jfree.chart.text.TextUtilities.createTextBlock("Pie Plot", font1, (java.awt.Paint) color2, (float) (-1), (org.jfree.chart.text.TextMeasurer) g2TextMeasurer5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        piePlotState1.setTotal((double) (short) 0);
        piePlotState1.setPassesRequired(1);
        java.awt.geom.Rectangle2D rectangle2D6 = piePlotState1.getLinkArea();
        double double7 = piePlotState1.getPieCenterX();
        org.junit.Assert.assertNull(rectangle2D6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = categoryPlot0.getRenderer(255);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        categoryPlot0.setDataset(categoryDataset4);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        float float7 = categoryPlot6.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot6.getRangeAxisLocation();
        categoryPlot0.setDomainAxisLocation(axisLocation8, true);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot0.getRangeAxisEdge((int) (short) 1);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge12);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNull(categoryItemRenderer3);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNotNull(rectangleEdge13);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        java.awt.Font font3 = null;
        java.awt.Paint paint4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, paint4);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = textBlock5.getLineAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement10 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment6, verticalAlignment7, (double) 100, 0.0d);
        textTitle1.setHorizontalAlignment(horizontalAlignment6);
        boolean boolean12 = textTitle1.getNotify();
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        int int6 = polarPlot5.getBackgroundImageAlignment();
        boolean boolean7 = polarPlot5.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) polarPlot5);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        java.awt.image.BufferedImage bufferedImage12 = jFreeChart8.createBufferedImage(100, 255, chartRenderingInfo11);
        jFreeChart8.removeLegend();
        java.awt.Stroke stroke14 = jFreeChart8.getBorderStroke();
        java.awt.Image image15 = jFreeChart8.getBackgroundImage();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(bufferedImage12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(image15);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        java.awt.Paint paint2 = textTitle1.getPaint();
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("hi!");
        java.lang.String str5 = textTitle4.getToolTipText();
        java.awt.Paint paint6 = textTitle4.getBackgroundPaint();
        textTitle4.setToolTipText("java.awt.Color[r=255,g=255,b=64]");
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer13 = null;
        org.jfree.chart.plot.PolarPlot polarPlot14 = new org.jfree.chart.plot.PolarPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) dateAxis12, polarItemRenderer13);
        int int15 = polarPlot14.getBackgroundImageAlignment();
        boolean boolean16 = polarPlot14.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) polarPlot14);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = null;
        java.awt.image.BufferedImage bufferedImage21 = jFreeChart17.createBufferedImage(100, 255, chartRenderingInfo20);
        jFreeChart17.removeLegend();
        java.awt.Stroke stroke23 = jFreeChart17.getBorderStroke();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType24 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent25 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) "java.awt.Color[r=255,g=255,b=64]", jFreeChart17, chartChangeEventType24);
        jFreeChart17.setTitle("Pie Plot");
        textTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart17);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 15 + "'", int15 == 15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(bufferedImage21);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        int int6 = polarPlot5.getBackgroundImageAlignment();
        boolean boolean7 = polarPlot5.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) polarPlot5);
        int int9 = jFreeChart8.getSubtitleCount();
        java.util.List list10 = jFreeChart8.getSubtitles();
        jFreeChart8.setAntiAlias(false);
        jFreeChart8.setBackgroundImageAlignment((int) (byte) -1);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot(xYDataset16, (org.jfree.chart.axis.ValueAxis) dateAxis18, polarItemRenderer19);
        org.jfree.chart.plot.PiePlot piePlot21 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = piePlot21.getSimpleLabelOffset();
        double double23 = rectangleInsets22.getRight();
        dateAxis18.setLabelInsets(rectangleInsets22);
        dateAxis18.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("");
        dateAxis29.setRange((double) 0.0f, (double) 10.0f);
        dateAxis29.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) dateAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis29, xYItemRenderer35);
        xYPlot36.clearDomainMarkers(15);
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot();
        float float41 = categoryPlot40.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation42 = categoryPlot40.getRangeAxisLocation();
        xYPlot36.setDomainAxisLocation((int) (byte) 0, axisLocation42, true);
        java.awt.Stroke stroke45 = xYPlot36.getRangeGridlineStroke();
        java.awt.Paint paint46 = xYPlot36.getRangeGridlinePaint();
        jFreeChart8.setBackgroundPaint(paint46);
        org.jfree.chart.event.ChartChangeListener chartChangeListener48 = null;
        try {
            jFreeChart8.removeChangeListener(chartChangeListener48);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.18d + "'", double23 == 0.18d);
        org.junit.Assert.assertTrue("'" + float41 + "' != '" + 1.0f + "'", float41 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation42);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(paint46);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = categoryPlot0.getRenderer();
        java.lang.String str4 = categoryPlot0.getPlotType();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) dateAxis8, polarItemRenderer9);
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot10);
        java.awt.geom.Rectangle2D rectangle2D12 = legendTitle11.getBounds();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        boolean boolean15 = categoryPlot0.render(graphics2D5, rectangle2D12, (int) (byte) 1, plotRenderingInfo14);
        categoryPlot0.setNoDataMessage("hi!");
        categoryPlot0.setAnchorValue((double) 1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        categoryPlot0.zoomRangeAxes((double) (-1L), (double) (byte) 100, plotRenderingInfo22, point2D23);
        int int25 = categoryPlot0.getDomainAxisCount();
        categoryPlot0.setWeight(3);
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("");
        dateAxis29.setRange((double) 0.0f, (double) 10.0f);
        dateAxis29.resizeRange((double) ' ');
        dateAxis29.setLabelURL("Category Plot");
        org.jfree.data.Range range37 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis29);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNull(categoryItemRenderer3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Category Plot" + "'", str4.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNull(range37);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = categoryPlot0.getRenderer(255);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        categoryPlot0.setDataset(categoryDataset4);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = categoryPlot0.getDrawingSupplier();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) dateAxis9, polarItemRenderer10);
        dateAxis9.setLabelAngle((double) (byte) 1);
        dateAxis9.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int17 = color16.getAlpha();
        java.lang.String str18 = color16.toString();
        dateAxis9.setTickMarkPaint((java.awt.Paint) color16);
        org.jfree.data.Range range20 = dateAxis9.getDefaultAutoRange();
        boolean boolean21 = dateAxis9.isTickMarksVisible();
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = piePlot23.getSimpleLabelOffset();
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer28 = null;
        org.jfree.chart.plot.PolarPlot polarPlot29 = new org.jfree.chart.plot.PolarPlot(xYDataset25, (org.jfree.chart.axis.ValueAxis) dateAxis27, polarItemRenderer28);
        org.jfree.chart.title.LegendTitle legendTitle30 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot29);
        java.awt.geom.Rectangle2D rectangle2D31 = legendTitle30.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType32 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = rectangleInsets24.createAdjustedRectangle(rectangle2D31, lengthAdjustmentType32, lengthAdjustmentType33);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean36 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge35);
        double double37 = dateAxis9.java2DToValue((double) 8, rectangle2D34, rectangleEdge35);
        boolean boolean38 = categoryPlot0.equals((java.lang.Object) 8);
        java.util.List list39 = categoryPlot0.getAnnotations();
        java.lang.String str40 = categoryPlot0.getPlotType();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNull(categoryItemRenderer3);
        org.junit.Assert.assertNotNull(drawingSupplier6);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 255 + "'", int17 == 255);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str18.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 9.223372036854776E18d + "'", double37 == 9.223372036854776E18d);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(list39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Category Plot" + "'", str40.equals("Category Plot"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.lang.Object obj1 = categoryAxis3D0.clone();
        categoryAxis3D0.setLowerMargin((double) (byte) 1);
        double double4 = categoryAxis3D0.getUpperMargin();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        java.awt.Paint paint0 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.clearDomainMarkers(15);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        float float26 = categoryPlot25.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot25.getRangeAxisLocation();
        xYPlot21.setDomainAxisLocation((int) (byte) 0, axisLocation27, true);
        xYPlot21.clearAnnotations();
        xYPlot21.mapDatasetToRangeAxis(2, 255);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 1.0f + "'", float26 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation27);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, (float) (-6553600), (float) 64, textAnchor4, (double) (-6553600), textAnchor6);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        boolean boolean1 = blockParams0.getGenerateEntities();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        java.awt.Paint paint2 = blockBorder1.getPaint();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        boolean boolean2 = paintMap0.containsKey((java.lang.Comparable) (short) 10);
        boolean boolean4 = paintMap0.containsKey((java.lang.Comparable) 255);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer8 = null;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) dateAxis7, polarItemRenderer8);
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot9);
        java.lang.Object obj11 = legendTitle10.clone();
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer15 = null;
        org.jfree.chart.plot.PolarPlot polarPlot16 = new org.jfree.chart.plot.PolarPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) dateAxis14, polarItemRenderer15);
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = piePlot17.getSimpleLabelOffset();
        double double19 = rectangleInsets18.getRight();
        dateAxis14.setLabelInsets(rectangleInsets18);
        legendTitle10.setLegendItemGraphicPadding(rectangleInsets18);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = legendTitle10.getLegendItemGraphicPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = legendTitle10.getMargin();
        boolean boolean24 = paintMap0.equals((java.lang.Object) legendTitle10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.18d + "'", double19 == 0.18d);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        boolean boolean2 = piePlot3D1.getDarkerSides();
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = piePlot4.getSimpleLabelOffset();
        boolean boolean6 = piePlot4.getSectionOutlinesVisible();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator7 = null;
        piePlot4.setLegendLabelURLGenerator(pieURLGenerator7);
        boolean boolean9 = piePlot4.getSimpleLabels();
        boolean boolean10 = piePlot4.getLabelLinksVisible();
        java.lang.String str11 = piePlot4.getPlotType();
        java.awt.Paint paint12 = piePlot4.getShadowPaint();
        piePlot3D1.setSectionOutlinePaint((java.lang.Comparable) 15, paint12);
        boolean boolean14 = piePlot3D1.getDarkerSides();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Pie Plot" + "'", str11.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = piePlot0.getSimpleLabelOffset();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        piePlot0.markerChanged(markerChangeEvent2);
        java.lang.Object obj4 = piePlot0.clone();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator5 = null;
        piePlot0.setToolTipGenerator(pieToolTipGenerator5);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = piePlot0.getLabelGenerator();
        piePlot0.setShadowXOffset(0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator7);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        java.util.List list3 = categoryPlot0.getCategories();
        java.awt.Paint paint4 = categoryPlot0.getRangeGridlinePaint();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNull(list3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        xYPlot21.zoomRangeAxes((double) ' ', plotRenderingInfo23, point2D24);
        java.awt.Paint paint26 = xYPlot21.getDomainTickBandPaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent27 = null;
        xYPlot21.rendererChanged(rendererChangeEvent27);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray29 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot21.setRenderers(xYItemRendererArray29);
        xYPlot21.clearDomainAxes();
        double double32 = xYPlot21.getRangeCrosshairValue();
        java.awt.Paint paint33 = xYPlot21.getRangeGridlinePaint();
        boolean boolean34 = xYPlot21.isDomainZeroBaselineVisible();
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertNull(paint26);
        org.junit.Assert.assertNotNull(xYItemRendererArray29);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        dateAxis2.setLabelAngle((double) (byte) 1);
        dateAxis2.setTickMarkOutsideLength((-1.0f));
        dateAxis2.setFixedDimension(0.4d);
        org.jfree.data.time.DateRange dateRange12 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint((double) '#', (org.jfree.data.Range) dateRange12);
        boolean boolean15 = dateRange12.equals((java.lang.Object) 15);
        dateAxis2.setRange((org.jfree.data.Range) dateRange12, true, false);
        org.junit.Assert.assertNotNull(dateRange12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot4);
        org.jfree.chart.block.BlockContainer blockContainer6 = legendTitle5.getItemContainer();
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = piePlot7.getSimpleLabelOffset();
        boolean boolean9 = piePlot7.getSectionOutlinesVisible();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator10 = null;
        piePlot7.setLegendLabelURLGenerator(pieURLGenerator10);
        boolean boolean12 = piePlot7.getSimpleLabels();
        org.jfree.chart.plot.RingPlot ringPlot13 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint14 = ringPlot13.getShadowPaint();
        ringPlot13.setInteriorGap((double) (byte) 0);
        java.awt.Font font17 = ringPlot13.getNoDataMessageFont();
        piePlot7.setLabelFont(font17);
        legendTitle5.setItemFont(font17);
        java.awt.Color color20 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Color color21 = color20.brighter();
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer26 = null;
        org.jfree.chart.plot.PolarPlot polarPlot27 = new org.jfree.chart.plot.PolarPlot(xYDataset23, (org.jfree.chart.axis.ValueAxis) dateAxis25, polarItemRenderer26);
        org.jfree.chart.plot.PiePlot piePlot28 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = piePlot28.getSimpleLabelOffset();
        double double30 = rectangleInsets29.getRight();
        dateAxis25.setLabelInsets(rectangleInsets29);
        dateAxis25.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis("");
        dateAxis36.setRange((double) 0.0f, (double) 10.0f);
        dateAxis36.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = null;
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot(xYDataset22, (org.jfree.chart.axis.ValueAxis) dateAxis25, (org.jfree.chart.axis.ValueAxis) dateAxis36, xYItemRenderer42);
        xYPlot43.clearDomainMarkers(15);
        org.jfree.chart.plot.PlotOrientation plotOrientation46 = xYPlot43.getOrientation();
        org.jfree.data.xy.XYDataset xYDataset47 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer48 = xYPlot43.getRendererForDataset(xYDataset47);
        boolean boolean49 = color21.equals((java.lang.Object) xYPlot43);
        boolean boolean50 = legendTitle5.equals((java.lang.Object) color21);
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = legendTitle5.getItemLabelPadding();
        java.awt.geom.Rectangle2D rectangle2D52 = legendTitle5.getBounds();
        org.junit.Assert.assertNotNull(blockContainer6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.18d + "'", double30 == 0.18d);
        org.junit.Assert.assertNotNull(plotOrientation46);
        org.junit.Assert.assertNull(xYItemRenderer48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(rectangleInsets51);
        org.junit.Assert.assertNotNull(rectangle2D52);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double1 = rectangleInsets0.getBottom();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = ringPlot0.getShadowPaint();
        java.awt.Paint paint2 = ringPlot0.getLabelLinkPaint();
        ringPlot0.setSeparatorsVisible(false);
        double double5 = ringPlot0.getOuterSeparatorExtension();
        ringPlot0.setStartAngle(2.0d);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("XY Plot", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) dateAxis4, polarItemRenderer5);
        dateAxis4.setLabelAngle((double) (byte) 1);
        dateAxis4.setTickMarkOutsideLength((-1.0f));
        dateAxis4.setFixedDimension(0.4d);
        double double13 = dateAxis4.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer14);
        boolean boolean16 = categoryPlot15.isDomainZoomable();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer21 = null;
        org.jfree.chart.plot.PolarPlot polarPlot22 = new org.jfree.chart.plot.PolarPlot(xYDataset18, (org.jfree.chart.axis.ValueAxis) dateAxis20, polarItemRenderer21);
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = piePlot23.getSimpleLabelOffset();
        double double25 = rectangleInsets24.getRight();
        dateAxis20.setLabelInsets(rectangleInsets24);
        dateAxis20.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("");
        dateAxis31.setRange((double) 0.0f, (double) 10.0f);
        dateAxis31.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer37 = null;
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot(xYDataset17, (org.jfree.chart.axis.ValueAxis) dateAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis31, xYItemRenderer37);
        xYPlot38.clearDomainMarkers(15);
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot();
        float float43 = categoryPlot42.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation44 = categoryPlot42.getRangeAxisLocation();
        xYPlot38.setDomainAxisLocation((int) (byte) 0, axisLocation44, true);
        xYPlot38.setDomainCrosshairValue((double) 'a');
        org.jfree.chart.axis.AxisLocation axisLocation49 = xYPlot38.getRangeAxisLocation();
        categoryPlot15.setRangeAxisLocation(axisLocation49, false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.18d + "'", double25 == 0.18d);
        org.junit.Assert.assertTrue("'" + float43 + "' != '" + 1.0f + "'", float43 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation44);
        org.junit.Assert.assertNotNull(axisLocation49);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = piePlot0.getSimpleLabelOffset();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        piePlot0.markerChanged(markerChangeEvent2);
        java.lang.Object obj4 = piePlot0.clone();
        java.awt.Paint paint5 = piePlot0.getLabelLinkPaint();
        double double6 = piePlot0.getLabelGap();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = piePlot0.getLegendLabelToolTipGenerator();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.util.Size2D size2D11 = new org.jfree.chart.util.Size2D((double) (-1), (double) '#');
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer17 = null;
        org.jfree.chart.plot.PolarPlot polarPlot18 = new org.jfree.chart.plot.PolarPlot(xYDataset14, (org.jfree.chart.axis.ValueAxis) dateAxis16, polarItemRenderer17);
        org.jfree.chart.title.LegendTitle legendTitle19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot18);
        java.awt.geom.Rectangle2D rectangle2D20 = legendTitle19.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.geom.Point2D point2D22 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D20, rectangleAnchor21);
        java.lang.String str23 = rectangleAnchor21.toString();
        boolean boolean25 = rectangleAnchor21.equals((java.lang.Object) 0.025d);
        java.awt.geom.Rectangle2D rectangle2D26 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D11, (double) (-16777216), 100.0d, rectangleAnchor21);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer30 = null;
        org.jfree.chart.plot.PolarPlot polarPlot31 = new org.jfree.chart.plot.PolarPlot(xYDataset27, (org.jfree.chart.axis.ValueAxis) dateAxis29, polarItemRenderer30);
        org.jfree.chart.title.LegendTitle legendTitle32 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot31);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean36 = categoryPlot35.isDomainGridlinesVisible();
        boolean boolean37 = categoryPlot35.isDomainGridlinesVisible();
        java.awt.Graphics2D graphics2D38 = null;
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = null;
        boolean boolean42 = categoryPlot35.render(graphics2D38, rectangle2D39, (int) (byte) 10, plotRenderingInfo41);
        categoryPlot35.setOutlineVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis46 = categoryPlot35.getRangeAxis(0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = null;
        org.jfree.data.xy.XYDataset xYDataset50 = null;
        org.jfree.chart.axis.DateAxis dateAxis52 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer53 = null;
        org.jfree.chart.plot.PolarPlot polarPlot54 = new org.jfree.chart.plot.PolarPlot(xYDataset50, (org.jfree.chart.axis.ValueAxis) dateAxis52, polarItemRenderer53);
        int int55 = polarPlot54.getBackgroundImageAlignment();
        boolean boolean56 = polarPlot54.isSubplot();
        java.awt.Color color57 = java.awt.Color.blue;
        polarPlot54.setAngleLabelPaint((java.awt.Paint) color57);
        java.awt.Font font59 = polarPlot54.getAngleLabelFont();
        org.jfree.chart.title.LegendTitle legendTitle60 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot54);
        org.jfree.data.xy.XYDataset xYDataset63 = null;
        org.jfree.chart.axis.DateAxis dateAxis65 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer66 = null;
        org.jfree.chart.plot.PolarPlot polarPlot67 = new org.jfree.chart.plot.PolarPlot(xYDataset63, (org.jfree.chart.axis.ValueAxis) dateAxis65, polarItemRenderer66);
        dateAxis65.setLabelAngle((double) (byte) 1);
        dateAxis65.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color72 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int73 = color72.getAlpha();
        java.lang.String str74 = color72.toString();
        dateAxis65.setTickMarkPaint((java.awt.Paint) color72);
        org.jfree.data.Range range76 = dateAxis65.getDefaultAutoRange();
        boolean boolean77 = dateAxis65.isTickMarksVisible();
        org.jfree.chart.plot.PiePlot piePlot79 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets80 = piePlot79.getSimpleLabelOffset();
        org.jfree.data.xy.XYDataset xYDataset81 = null;
        org.jfree.chart.axis.DateAxis dateAxis83 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer84 = null;
        org.jfree.chart.plot.PolarPlot polarPlot85 = new org.jfree.chart.plot.PolarPlot(xYDataset81, (org.jfree.chart.axis.ValueAxis) dateAxis83, polarItemRenderer84);
        org.jfree.chart.title.LegendTitle legendTitle86 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot85);
        java.awt.geom.Rectangle2D rectangle2D87 = legendTitle86.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType88 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType89 = null;
        java.awt.geom.Rectangle2D rectangle2D90 = rectangleInsets80.createAdjustedRectangle(rectangle2D87, lengthAdjustmentType88, lengthAdjustmentType89);
        org.jfree.chart.util.RectangleEdge rectangleEdge91 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean92 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge91);
        double double93 = dateAxis65.java2DToValue((double) 8, rectangle2D90, rectangleEdge91);
        java.awt.Point point94 = polarPlot54.translateValueThetaRadiusToJava2D((double) (-1L), (double) 2, rectangle2D90);
        categoryPlot35.zoomRangeAxes((double) 10, (double) (-1L), plotRenderingInfo49, (java.awt.geom.Point2D) point94);
        polarPlot31.zoomRangeAxes((double) (-16056329), plotRenderingInfo34, (java.awt.geom.Point2D) point94);
        org.jfree.chart.plot.PlotState plotState97 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo98 = null;
        try {
            piePlot0.draw(graphics2D8, rectangle2D26, (java.awt.geom.Point2D) point94, plotState97, plotRenderingInfo98);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.025d + "'", double6 == 0.025d);
        org.junit.Assert.assertNull(pieSectionLabelGenerator7);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertNotNull(point2D22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "RectangleAnchor.BOTTOM_LEFT" + "'", str23.equals("RectangleAnchor.BOTTOM_LEFT"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNull(valueAxis46);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 15 + "'", int55 == 15);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertNotNull(font59);
        org.junit.Assert.assertNotNull(color72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 255 + "'", int73 == 255);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str74.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(range76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertNotNull(rectangleInsets80);
        org.junit.Assert.assertNotNull(rectangle2D87);
        org.junit.Assert.assertNotNull(rectangle2D90);
        org.junit.Assert.assertNotNull(rectangleEdge91);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 9.223372036854776E18d + "'", double93 == 9.223372036854776E18d);
        org.junit.Assert.assertNotNull(point94);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        java.awt.Font font3 = null;
        java.awt.Paint paint4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, paint4);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = textBlock5.getLineAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement10 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment6, verticalAlignment7, (double) 100, 0.0d);
        textTitle1.setHorizontalAlignment(horizontalAlignment6);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer16 = null;
        org.jfree.chart.plot.PolarPlot polarPlot17 = new org.jfree.chart.plot.PolarPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis15, polarItemRenderer16);
        dateAxis15.setLabelAngle((double) (byte) 1);
        java.awt.Font font20 = dateAxis15.getTickLabelFont();
        org.jfree.chart.text.TextLine textLine21 = new org.jfree.chart.text.TextLine("", font20);
        org.jfree.chart.text.TextFragment textFragment22 = textLine21.getLastTextFragment();
        java.awt.Paint paint23 = textFragment22.getPaint();
        textTitle1.setBackgroundPaint(paint23);
        java.awt.Color color25 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Color color26 = color25.brighter();
        textTitle1.setPaint((java.awt.Paint) color25);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(textFragment22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        org.jfree.chart.entity.EntityCollection entityCollection2 = piePlotState1.getEntityCollection();
        double double3 = piePlotState1.getPieWRadius();
        org.junit.Assert.assertNull(entityCollection2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.jfree.data.KeyedValues keyedValues1 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) 10.0d, keyedValues1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowData' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis((int) '4', valueAxis3, false);
        categoryPlot0.configureRangeAxes();
        categoryPlot0.setAnchorValue((double) (-1L), true);
        categoryPlot0.clearRangeAxes();
        categoryPlot0.setRangeCrosshairValue((double) (byte) 1);
        float float13 = categoryPlot0.getBackgroundImageAlpha();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.5f + "'", float13 == 0.5f);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        boolean boolean2 = jFreeChartResources0.containsKey("java.awt.Color[r=255,g=255,b=64]");
        boolean boolean4 = jFreeChartResources0.containsKey("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        java.awt.Stroke stroke22 = xYPlot21.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("");
        java.util.Date date26 = dateAxis25.getMaximumDate();
        xYPlot21.setRangeAxis((int) (short) 100, (org.jfree.chart.axis.ValueAxis) dateAxis25);
        org.jfree.chart.util.Layer layer29 = null;
        java.util.Collection collection30 = xYPlot21.getRangeMarkers((-16056329), layer29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        xYPlot21.setRenderer(0, xYItemRenderer32, false);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNull(collection30);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("");
        java.awt.Paint paint2 = textFragment1.getPaint();
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.clearDomainMarkers(15);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        float float26 = categoryPlot25.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot25.getRangeAxisLocation();
        xYPlot21.setDomainAxisLocation((int) (byte) 0, axisLocation27, true);
        java.awt.Stroke stroke30 = xYPlot21.getRangeGridlineStroke();
        java.awt.Stroke stroke31 = xYPlot21.getDomainGridlineStroke();
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 1.0f + "'", float26 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(stroke31);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Size2D[width=0.0, height=0.0]");
        numberAxis1.setAutoRangeStickyZero(true);
        boolean boolean4 = numberAxis1.getAutoRangeStickyZero();
        boolean boolean5 = numberAxis1.isVisible();
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) dateAxis8, polarItemRenderer9);
        int int11 = polarPlot10.getBackgroundImageAlignment();
        boolean boolean12 = polarPlot10.isSubplot();
        boolean boolean13 = polarPlot10.isDomainZoomable();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        polarPlot10.handleClick((int) (byte) 10, (int) '4', plotRenderingInfo16);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit18 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        polarPlot10.setAngleTickUnit((org.jfree.chart.axis.TickUnit) numberTickUnit18);
        numberAxis1.setTickUnit(numberTickUnit18);
        numberAxis1.setTickMarkOutsideLength((float) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 15 + "'", int11 == 15);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(numberTickUnit18);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.clearDomainMarkers(15);
        org.jfree.chart.LegendItemCollection legendItemCollection24 = xYPlot21.getFixedLegendItems();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = xYPlot21.getAxisOffset();
        xYPlot21.setDomainCrosshairValue(1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertNull(legendItemCollection24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) dateAxis4, polarItemRenderer5);
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot6);
        java.awt.Color color8 = java.awt.Color.green;
        java.awt.Color color9 = color8.darker();
        legendTitle7.setBackgroundPaint((java.awt.Paint) color8);
        java.lang.Class<?> wildcardClass11 = legendTitle7.getClass();
        java.lang.Object obj12 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("PlotOrientation.VERTICAL", (java.lang.Class) wildcardClass11);
        java.net.URL uRL13 = org.jfree.chart.util.ObjectUtilities.getResource("", (java.lang.Class) wildcardClass11);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNull(obj12);
        org.junit.Assert.assertNotNull(uRL13);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        int int6 = polarPlot5.getBackgroundImageAlignment();
        boolean boolean7 = polarPlot5.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) polarPlot5);
        int int9 = jFreeChart8.getSubtitleCount();
        java.util.List list10 = jFreeChart8.getSubtitles();
        jFreeChart8.setAntiAlias(false);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent13 = null;
        try {
            jFreeChart8.titleChanged(titleChangeEvent13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(list10);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        int int6 = polarPlot5.getBackgroundImageAlignment();
        boolean boolean7 = polarPlot5.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) polarPlot5);
        int int9 = jFreeChart8.getSubtitleCount();
        java.util.List list10 = jFreeChart8.getSubtitles();
        jFreeChart8.setAntiAlias(false);
        boolean boolean13 = jFreeChart8.getAntiAlias();
        boolean boolean14 = jFreeChart8.isBorderVisible();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot4);
        org.jfree.chart.block.BlockContainer blockContainer6 = legendTitle5.getItemContainer();
        org.jfree.chart.block.Arrangement arrangement7 = blockContainer6.getArrangement();
        org.jfree.chart.block.BlockContainer blockContainer8 = new org.jfree.chart.block.BlockContainer(arrangement7);
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("hi!");
        java.lang.String str11 = textTitle10.getToolTipText();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = textTitle10.getHorizontalAlignment();
        blockContainer8.add((org.jfree.chart.block.Block) textTitle10);
        java.lang.Object obj14 = blockContainer8.clone();
        org.junit.Assert.assertNotNull(blockContainer6);
        org.junit.Assert.assertNotNull(arrangement7);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(horizontalAlignment12);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = categoryPlot0.getRenderer(255);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        categoryPlot0.setDataset(categoryDataset4);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = categoryPlot0.getDrawingSupplier();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) dateAxis9, polarItemRenderer10);
        dateAxis9.setLabelAngle((double) (byte) 1);
        dateAxis9.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int17 = color16.getAlpha();
        java.lang.String str18 = color16.toString();
        dateAxis9.setTickMarkPaint((java.awt.Paint) color16);
        org.jfree.data.Range range20 = dateAxis9.getDefaultAutoRange();
        boolean boolean21 = dateAxis9.isTickMarksVisible();
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = piePlot23.getSimpleLabelOffset();
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer28 = null;
        org.jfree.chart.plot.PolarPlot polarPlot29 = new org.jfree.chart.plot.PolarPlot(xYDataset25, (org.jfree.chart.axis.ValueAxis) dateAxis27, polarItemRenderer28);
        org.jfree.chart.title.LegendTitle legendTitle30 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot29);
        java.awt.geom.Rectangle2D rectangle2D31 = legendTitle30.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType32 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = rectangleInsets24.createAdjustedRectangle(rectangle2D31, lengthAdjustmentType32, lengthAdjustmentType33);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean36 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge35);
        double double37 = dateAxis9.java2DToValue((double) 8, rectangle2D34, rectangleEdge35);
        boolean boolean38 = categoryPlot0.equals((java.lang.Object) 8);
        java.util.List list39 = categoryPlot0.getAnnotations();
        org.jfree.chart.axis.ValueAxis valueAxis41 = categoryPlot0.getRangeAxis(0);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNull(categoryItemRenderer3);
        org.junit.Assert.assertNotNull(drawingSupplier6);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 255 + "'", int17 == 255);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str18.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 9.223372036854776E18d + "'", double37 == 9.223372036854776E18d);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(list39);
        org.junit.Assert.assertNull(valueAxis41);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("Size2D[width=0.0, height=0.0]");
        numberAxis2.setAutoRangeStickyZero(true);
        boolean boolean5 = numberAxis2.getAutoRangeStickyZero();
        boolean boolean6 = numberAxis2.isVisible();
        java.text.NumberFormat numberFormat7 = numberAxis2.getNumberFormatOverride();
        numberAxis2.setAutoRangeIncludesZero(true);
        double double10 = numberAxis2.getUpperMargin();
        boolean boolean11 = chartChangeEventType0.equals((java.lang.Object) numberAxis2);
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.05d + "'", double10 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.clearDomainMarkers(15);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        float float26 = categoryPlot25.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot25.getRangeAxisLocation();
        xYPlot21.setDomainAxisLocation((int) (byte) 0, axisLocation27, true);
        xYPlot21.setDomainCrosshairValue((double) 'a');
        boolean boolean32 = xYPlot21.isDomainZoomable();
        java.awt.Paint paint33 = xYPlot21.getDomainCrosshairPaint();
        java.util.List list34 = xYPlot21.getAnnotations();
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis("Size2D[width=0.0, height=0.0]");
        double double37 = numberAxis36.getUpperMargin();
        java.awt.Paint paint38 = numberAxis36.getLabelPaint();
        org.jfree.chart.block.LineBorder lineBorder39 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = lineBorder39.getInsets();
        java.awt.Stroke stroke41 = lineBorder39.getStroke();
        numberAxis36.setTickMarkStroke(stroke41);
        xYPlot21.setDomainZeroBaselineStroke(stroke41);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 1.0f + "'", float26 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(list34);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.05d + "'", double37 == 0.05d);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertNotNull(stroke41);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Locale locale1 = jFreeChartResources0.getLocale();
        java.util.Locale locale2 = jFreeChartResources0.getLocale();
        java.lang.Object[][] objArray3 = jFreeChartResources0.getContents();
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNull(locale2);
        org.junit.Assert.assertNotNull(objArray3);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        java.lang.String str2 = textTitle1.getToolTipText();
        java.awt.Paint paint3 = textTitle1.getBackgroundPaint();
        double double4 = textTitle1.getContentXOffset();
        boolean boolean5 = textTitle1.getNotify();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) dateAxis9, polarItemRenderer10);
        int int12 = polarPlot11.getBackgroundImageAlignment();
        boolean boolean13 = polarPlot11.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) polarPlot11);
        int int15 = jFreeChart14.getSubtitleCount();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent18 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) textTitle1, jFreeChart14, (int) (byte) 10, 255);
        int int19 = jFreeChart14.getSubtitleCount();
        boolean boolean20 = jFreeChart14.isBorderVisible();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 15 + "'", int12 == 15);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        java.lang.Number[] numberArray8 = new java.lang.Number[] { 0.4d, 100.0f, 0L, 0.025d, (byte) 1, 1.0f };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 0.4d, 100.0f, 0L, 0.025d, (byte) 1, 1.0f };
        java.lang.Number[] numberArray22 = new java.lang.Number[] { 0.4d, 100.0f, 0L, 0.025d, (byte) 1, 1.0f };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { 0.4d, 100.0f, 0L, 0.025d, (byte) 1, 1.0f };
        java.lang.Number[] numberArray36 = new java.lang.Number[] { 0.4d, 100.0f, 0L, 0.025d, (byte) 1, 1.0f };
        java.lang.Number[] numberArray43 = new java.lang.Number[] { 0.4d, 100.0f, 0L, 0.025d, (byte) 1, 1.0f };
        java.lang.Number[][] numberArray44 = new java.lang.Number[][] { numberArray8, numberArray15, numberArray22, numberArray29, numberArray36, numberArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("PlotOrientation.VERTICAL", "hi!", numberArray44);
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = null;
        org.jfree.chart.axis.NumberAxis numberAxis48 = new org.jfree.chart.axis.NumberAxis("Size2D[width=0.0, height=0.0]");
        numberAxis48.setAutoRangeStickyZero(true);
        boolean boolean51 = numberAxis48.getAutoRangeStickyZero();
        boolean boolean52 = numberAxis48.isVisible();
        java.text.NumberFormat numberFormat53 = numberAxis48.getNumberFormatOverride();
        numberAxis48.setAutoRangeIncludesZero(true);
        java.lang.String str56 = numberAxis48.getLabelToolTip();
        java.text.NumberFormat numberFormat57 = null;
        numberAxis48.setNumberFormatOverride(numberFormat57);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer59 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot(categoryDataset45, categoryAxis46, (org.jfree.chart.axis.ValueAxis) numberAxis48, categoryItemRenderer59);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot61 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset45);
        org.jfree.chart.JFreeChart jFreeChart62 = multiplePiePlot61.getPieChart();
        multiplePiePlot61.setAggregatedItemsKey((java.lang.Comparable) 100L);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray36);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNull(numberFormat53);
        org.junit.Assert.assertNull(str56);
        org.junit.Assert.assertNotNull(jFreeChart62);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis((int) '4', valueAxis3, false);
        org.jfree.chart.axis.AxisLocation axisLocation6 = categoryPlot0.getRangeAxisLocation();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer11 = null;
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot(xYDataset8, (org.jfree.chart.axis.ValueAxis) dateAxis10, polarItemRenderer11);
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = piePlot13.getSimpleLabelOffset();
        double double15 = rectangleInsets14.getRight();
        dateAxis10.setLabelInsets(rectangleInsets14);
        dateAxis10.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("");
        dateAxis21.setRange((double) 0.0f, (double) 10.0f);
        dateAxis21.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis21, xYItemRenderer27);
        xYPlot28.setDomainGridlinesVisible(true);
        double double31 = xYPlot28.getDomainCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation33 = xYPlot28.getDomainAxisLocation((-16777216));
        categoryPlot0.setDomainAxisLocation(axisLocation33);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.18d + "'", double15 == 0.18d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation33);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        xYPlot21.zoomRangeAxes((double) ' ', plotRenderingInfo23, point2D24);
        java.awt.Paint paint26 = xYPlot21.getDomainTickBandPaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent27 = null;
        xYPlot21.rendererChanged(rendererChangeEvent27);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray29 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot21.setRenderers(xYItemRendererArray29);
        org.jfree.data.xy.XYDataset xYDataset31 = null;
        int int32 = xYPlot21.indexOf(xYDataset31);
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot();
        float float34 = categoryPlot33.getForegroundAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        categoryPlot33.setRangeAxis((int) '4', valueAxis36, false);
        categoryPlot33.configureRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset42 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer45 = null;
        org.jfree.chart.plot.PolarPlot polarPlot46 = new org.jfree.chart.plot.PolarPlot(xYDataset42, (org.jfree.chart.axis.ValueAxis) dateAxis44, polarItemRenderer45);
        dateAxis44.setLabelAngle((double) (byte) 1);
        dateAxis44.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color51 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int52 = color51.getAlpha();
        java.lang.String str53 = color51.toString();
        dateAxis44.setTickMarkPaint((java.awt.Paint) color51);
        org.jfree.chart.plot.PiePlot piePlot55 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets56 = piePlot55.getSimpleLabelOffset();
        java.awt.Stroke stroke57 = piePlot55.getLabelOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker58 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, (java.awt.Paint) color51, stroke57);
        org.jfree.chart.util.Layer layer59 = null;
        categoryPlot33.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker58, layer59);
        java.awt.Paint paint61 = valueMarker58.getLabelPaint();
        org.jfree.chart.text.TextAnchor textAnchor62 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        valueMarker58.setLabelTextAnchor(textAnchor62);
        java.lang.Object obj64 = valueMarker58.clone();
        java.awt.Stroke stroke65 = valueMarker58.getOutlineStroke();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor66 = valueMarker58.getLabelAnchor();
        org.jfree.chart.util.RectangleInsets rectangleInsets67 = valueMarker58.getLabelOffset();
        try {
            boolean boolean68 = xYPlot21.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker58);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertNull(paint26);
        org.junit.Assert.assertNotNull(xYItemRendererArray29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + float34 + "' != '" + 1.0f + "'", float34 == 1.0f);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 255 + "'", int52 == 255);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str53.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(rectangleInsets56);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertNotNull(paint61);
        org.junit.Assert.assertNotNull(textAnchor62);
        org.junit.Assert.assertNotNull(obj64);
        org.junit.Assert.assertNotNull(stroke65);
        org.junit.Assert.assertNotNull(rectangleAnchor66);
        org.junit.Assert.assertNotNull(rectangleInsets67);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        int int6 = polarPlot5.getBackgroundImageAlignment();
        boolean boolean7 = polarPlot5.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) polarPlot5);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        java.awt.image.BufferedImage bufferedImage12 = jFreeChart8.createBufferedImage(100, 255, chartRenderingInfo11);
        int int13 = jFreeChart8.getBackgroundImageAlignment();
        org.jfree.chart.event.ChartChangeListener chartChangeListener14 = null;
        try {
            jFreeChart8.removeChangeListener(chartChangeListener14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(bufferedImage12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        double double5 = dateAxis2.getLabelAngle();
        java.lang.Object obj6 = dateAxis2.clone();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = piePlot0.getSimpleLabelOffset();
        java.awt.Paint paint3 = piePlot0.getSectionPaint((java.lang.Comparable) 10);
        java.awt.Color color5 = java.awt.Color.GRAY;
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) dateAxis9, polarItemRenderer10);
        dateAxis9.setLabelAngle((double) (byte) 1);
        dateAxis9.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int17 = color16.getAlpha();
        java.lang.String str18 = color16.toString();
        dateAxis9.setTickMarkPaint((java.awt.Paint) color16);
        org.jfree.chart.plot.PiePlot piePlot20 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = piePlot20.getSimpleLabelOffset();
        java.awt.Stroke stroke22 = piePlot20.getLabelOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, (java.awt.Paint) color16, stroke22);
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((-1.0d), (java.awt.Paint) color5, stroke22);
        piePlot0.setLabelLinkStroke(stroke22);
        piePlot0.setSectionOutlinesVisible(false);
        java.awt.Paint paint28 = piePlot0.getBaseSectionPaint();
        java.awt.Color color31 = java.awt.Color.getColor("Category Plot", (int) '4');
        piePlot0.setLabelBackgroundPaint((java.awt.Paint) color31);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 255 + "'", int17 == 255);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str18.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(color31);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        org.jfree.chart.entity.EntityCollection entityCollection2 = piePlotState1.getEntityCollection();
        java.awt.geom.Rectangle2D rectangle2D3 = piePlotState1.getPieArea();
        org.junit.Assert.assertNull(entityCollection2);
        org.junit.Assert.assertNull(rectangle2D3);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = categoryPlot0.getRenderer();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = categoryPlot0.getDomainAxisEdge(0);
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 0.4d, 100.0f, 0L, 0.025d, (byte) 1, 1.0f };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.4d, 100.0f, 0L, 0.025d, (byte) 1, 1.0f };
        java.lang.Number[] numberArray28 = new java.lang.Number[] { 0.4d, 100.0f, 0L, 0.025d, (byte) 1, 1.0f };
        java.lang.Number[] numberArray35 = new java.lang.Number[] { 0.4d, 100.0f, 0L, 0.025d, (byte) 1, 1.0f };
        java.lang.Number[] numberArray42 = new java.lang.Number[] { 0.4d, 100.0f, 0L, 0.025d, (byte) 1, 1.0f };
        java.lang.Number[] numberArray49 = new java.lang.Number[] { 0.4d, 100.0f, 0L, 0.025d, (byte) 1, 1.0f };
        java.lang.Number[][] numberArray50 = new java.lang.Number[][] { numberArray14, numberArray21, numberArray28, numberArray35, numberArray42, numberArray49 };
        org.jfree.data.category.CategoryDataset categoryDataset51 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("PlotOrientation.VERTICAL", "hi!", numberArray50);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer52 = categoryPlot0.getRendererForDataset(categoryDataset51);
        org.jfree.data.Range range54 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset51, 0.14d);
        org.jfree.data.Range range55 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset51);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNull(categoryItemRenderer3);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(numberArray49);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(categoryDataset51);
        org.junit.Assert.assertNull(categoryItemRenderer52);
        org.junit.Assert.assertNotNull(range54);
        org.junit.Assert.assertNotNull(range55);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        java.lang.String str1 = color0.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=64,g=255,b=64]" + "'", str1.equals("java.awt.Color[r=64,g=255,b=64]"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        java.awt.Font font1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        float[] floatArray9 = new float[] { (-1.0f), 10, (short) 0, '#' };
        float[] floatArray10 = color4.getRGBComponents(floatArray9);
        float[] floatArray11 = color3.getColorComponents(floatArray9);
        float[] floatArray12 = color2.getRGBComponents(floatArray11);
        try {
            org.jfree.chart.text.TextLine textLine13 = new org.jfree.chart.text.TextLine("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0", font1, (java.awt.Paint) color2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setInnerSeparatorExtension((double) '#');
        org.jfree.chart.util.Rotation rotation3 = ringPlot0.getDirection();
        double double4 = ringPlot0.getShadowXOffset();
        java.awt.Font font6 = null;
        java.awt.Paint paint7 = null;
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("", font6, paint7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor12 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        java.awt.Shape shape16 = textBlock8.calculateBounds(graphics2D9, 0.0f, (float) (short) 0, textBlockAnchor12, (float) (byte) 10, (float) 15, (double) 0L);
        boolean boolean17 = ringPlot0.equals((java.lang.Object) textBlock8);
        ringPlot0.setMaximumLabelWidth((double) (-16056329));
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertNotNull(textBlockAnchor12);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = piePlot1.getSimpleLabelOffset();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        piePlot1.markerChanged(markerChangeEvent3);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setLabelBackgroundPaint((java.awt.Paint) color5);
        java.awt.Color color7 = java.awt.Color.getColor("PlotOrientation.VERTICAL", color5);
        java.lang.String str8 = color5.toString();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "java.awt.Color[r=0,g=255,b=0]" + "'", str8.equals("java.awt.Color[r=0,g=255,b=0]"));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("ClassContext");
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) dateAxis4, polarItemRenderer5);
        int int7 = polarPlot6.getBackgroundImageAlignment();
        boolean boolean8 = polarPlot6.isSubplot();
        boolean boolean9 = polarPlot6.isDomainZoomable();
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer13 = null;
        org.jfree.chart.plot.PolarPlot polarPlot14 = new org.jfree.chart.plot.PolarPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) dateAxis12, polarItemRenderer13);
        dateAxis12.setLabelAngle((double) (byte) 1);
        dateAxis12.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int20 = color19.getAlpha();
        dateAxis12.setTickLabelPaint((java.awt.Paint) color19);
        polarPlot6.setAngleGridlinePaint((java.awt.Paint) color19);
        org.jfree.chart.axis.ValueAxis valueAxis23 = polarPlot6.getAxis();
        double double24 = valueAxis23.getUpperBound();
        boolean boolean25 = textFragment1.equals((java.lang.Object) valueAxis23);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer29 = null;
        org.jfree.chart.plot.PolarPlot polarPlot30 = new org.jfree.chart.plot.PolarPlot(xYDataset26, (org.jfree.chart.axis.ValueAxis) dateAxis28, polarItemRenderer29);
        org.jfree.data.time.DateRange dateRange31 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double32 = dateRange31.getUpperBound();
        dateAxis28.setRangeWithMargins((org.jfree.data.Range) dateRange31, false, true);
        boolean boolean36 = textFragment1.equals((java.lang.Object) dateAxis28);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 255 + "'", int20 == 255);
        org.junit.Assert.assertNotNull(valueAxis23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dateRange31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Size2D[width=0.0, height=0.0]");
        numberAxis1.setAutoRangeStickyZero(true);
        boolean boolean4 = numberAxis1.getAutoRangeStickyZero();
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent8 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) boolean4, jFreeChart5, (int) '4', (int) (byte) 100);
        java.lang.Object obj9 = chartProgressEvent8.getSource();
        org.jfree.chart.JFreeChart jFreeChart10 = chartProgressEvent8.getChart();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + obj9 + "' != '" + true + "'", obj9.equals(true));
        org.junit.Assert.assertNull(jFreeChart10);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.clearDomainMarkers(15);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer27 = null;
        org.jfree.chart.plot.PolarPlot polarPlot28 = new org.jfree.chart.plot.PolarPlot(xYDataset24, (org.jfree.chart.axis.ValueAxis) dateAxis26, polarItemRenderer27);
        dateAxis26.setLabelAngle((double) (byte) 1);
        dateAxis26.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color33 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int34 = color33.getAlpha();
        dateAxis26.setTickLabelPaint((java.awt.Paint) color33);
        dateAxis26.setInverted(false);
        double double38 = dateAxis26.getLowerBound();
        org.jfree.data.Range range39 = xYPlot21.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis26);
        java.awt.Stroke stroke40 = null;
        try {
            xYPlot21.setRangeCrosshairStroke(stroke40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 255 + "'", int34 == 255);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNull(range39);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getDomainMarkers(255, layer2);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent4);
        org.junit.Assert.assertNull(collection3);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        dateAxis2.setLabelAngle((double) (byte) 1);
        java.awt.Stroke stroke7 = dateAxis2.getTickMarkStroke();
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot4);
        java.lang.Object obj6 = legendTitle5.clone();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) dateAxis9, polarItemRenderer10);
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = piePlot12.getSimpleLabelOffset();
        double double14 = rectangleInsets13.getRight();
        dateAxis9.setLabelInsets(rectangleInsets13);
        legendTitle5.setLegendItemGraphicPadding(rectangleInsets13);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = legendTitle5.getLegendItemGraphicPadding();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = legendTitle5.getLegendItemGraphicLocation();
        org.jfree.chart.text.TextFragment textFragment20 = new org.jfree.chart.text.TextFragment("ClassContext");
        boolean boolean21 = rectangleAnchor18.equals((java.lang.Object) "ClassContext");
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.18d + "'", double14 == 0.18d);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(rectangleAnchor18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean2 = categoryPlot1.isDomainGridlinesVisible();
        boolean boolean3 = categoryPlot1.isDomainGridlinesVisible();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        boolean boolean8 = categoryPlot1.render(graphics2D4, rectangle2D5, (int) (byte) 10, plotRenderingInfo7);
        org.jfree.data.category.CategoryDataset categoryDataset10 = categoryPlot1.getDataset((int) ' ');
        org.jfree.chart.util.SortOrder sortOrder11 = categoryPlot1.getRowRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("ClassContext", (org.jfree.chart.plot.Plot) categoryPlot1);
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle("hi!");
        java.lang.String str16 = textTitle15.getToolTipText();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment17 = textTitle15.getHorizontalAlignment();
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer21 = null;
        org.jfree.chart.plot.PolarPlot polarPlot22 = new org.jfree.chart.plot.PolarPlot(xYDataset18, (org.jfree.chart.axis.ValueAxis) dateAxis20, polarItemRenderer21);
        org.jfree.chart.title.LegendTitle legendTitle23 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot22);
        boolean boolean24 = horizontalAlignment17.equals((java.lang.Object) legendTitle23);
        java.awt.Paint paint25 = legendTitle23.getBackgroundPaint();
        try {
            jFreeChart12.addSubtitle((-16777216), (org.jfree.chart.title.Title) legendTitle23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'index' argument is out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(categoryDataset10);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(horizontalAlignment17);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(paint25);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = textTitle1.getHorizontalAlignment();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer8 = null;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) dateAxis7, polarItemRenderer8);
        dateAxis7.setLabelAngle((double) (byte) 1);
        dateAxis7.setTickMarkOutsideLength((-1.0f));
        dateAxis7.setFixedDimension(0.4d);
        double double16 = dateAxis7.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer17);
        boolean boolean19 = categoryPlot18.isDomainZoomable();
        boolean boolean20 = horizontalAlignment2.equals((java.lang.Object) categoryPlot18);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        dateAxis2.setLabelAngle((double) (byte) 1);
        dateAxis2.setTickMarkOutsideLength((-1.0f));
        dateAxis2.setFixedDimension(0.4d);
        org.jfree.chart.plot.Plot plot11 = dateAxis2.getPlot();
        java.awt.Stroke stroke12 = dateAxis2.getAxisLineStroke();
        org.junit.Assert.assertNotNull(plot11);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = piePlot0.getSimpleLabelOffset();
        java.awt.Paint paint3 = piePlot0.getSectionPaint((java.lang.Comparable) 10);
        java.awt.Color color5 = java.awt.Color.GRAY;
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) dateAxis9, polarItemRenderer10);
        dateAxis9.setLabelAngle((double) (byte) 1);
        dateAxis9.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int17 = color16.getAlpha();
        java.lang.String str18 = color16.toString();
        dateAxis9.setTickMarkPaint((java.awt.Paint) color16);
        org.jfree.chart.plot.PiePlot piePlot20 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = piePlot20.getSimpleLabelOffset();
        java.awt.Stroke stroke22 = piePlot20.getLabelOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, (java.awt.Paint) color16, stroke22);
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((-1.0d), (java.awt.Paint) color5, stroke22);
        piePlot0.setLabelLinkStroke(stroke22);
        piePlot0.setSectionOutlinesVisible(false);
        java.awt.Paint paint28 = piePlot0.getBaseSectionPaint();
        boolean boolean29 = piePlot0.isSubplot();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 255 + "'", int17 == 255);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str18.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("ClassContext");
        numberAxis3D1.setLabel("RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]");
        org.jfree.data.Range range4 = numberAxis3D1.getDefaultAutoRange();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = numberAxis3D1.getTickUnit();
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(numberTickUnit5);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        java.awt.Stroke stroke22 = xYPlot21.getDomainZeroBaselineStroke();
        int int23 = xYPlot21.getWeight();
        int int24 = xYPlot21.getRangeAxisCount();
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("Size2D[width=0.0, height=0.0]");
        numberAxis2.setAutoRangeStickyZero(true);
        boolean boolean5 = numberAxis2.getAutoRangeStickyZero();
        boolean boolean6 = numberAxis2.isVisible();
        java.text.NumberFormat numberFormat7 = numberAxis2.getNumberFormatOverride();
        numberAxis2.setAutoRangeIncludesZero(true);
        java.lang.String str10 = numberAxis2.getLabelToolTip();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer11 = null;
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, polarItemRenderer11);
        numberAxis2.setAutoRangeMinimumSize((double) 10.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        java.awt.Stroke stroke22 = xYPlot21.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("");
        java.util.Date date26 = dateAxis25.getMaximumDate();
        xYPlot21.setRangeAxis((int) (short) 100, (org.jfree.chart.axis.ValueAxis) dateAxis25);
        xYPlot21.setDomainCrosshairLockedOnData(false);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(date26);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.setDomainCrosshairValue((double) 1.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = xYPlot21.getRenderer();
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertNull(xYItemRenderer24);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoRange(false);
        dateAxis0.setFixedDimension(23.4375d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        java.awt.Color color2 = java.awt.Color.MAGENTA;
        boolean boolean3 = categoryPlot0.equals((java.lang.Object) color2);
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor5 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) dateAxis9, polarItemRenderer10);
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = piePlot12.getSimpleLabelOffset();
        double double14 = rectangleInsets13.getRight();
        dateAxis9.setLabelInsets(rectangleInsets13);
        dateAxis9.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("");
        dateAxis20.setRange((double) 0.0f, (double) 10.0f);
        dateAxis20.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) dateAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer26);
        xYPlot27.clearDomainMarkers(15);
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = xYPlot27.getOrientation();
        categoryPlot0.setOrientation(plotOrientation30);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(categoryAnchor5);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.18d + "'", double14 == 0.18d);
        org.junit.Assert.assertNotNull(plotOrientation30);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer2 = null;
        categoryPlot0.setRenderer(categoryItemRenderer2);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent4);
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("hi!");
        java.lang.String str8 = textTitle7.getToolTipText();
        java.awt.Paint paint9 = textTitle7.getBackgroundPaint();
        double double10 = textTitle7.getContentXOffset();
        org.jfree.chart.block.BlockBorder blockBorder11 = new org.jfree.chart.block.BlockBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = blockBorder11.getInsets();
        textTitle7.setFrame((org.jfree.chart.block.BlockFrame) blockBorder11);
        java.awt.Color color14 = java.awt.Color.gray;
        textTitle7.setPaint((java.awt.Paint) color14);
        org.jfree.chart.block.BlockBorder blockBorder16 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color14);
        categoryPlot0.setOutlinePaint((java.awt.Paint) color14);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(color14);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        polarPlot4.zoomRangeAxes((double) 100, (double) 1.0f, plotRenderingInfo7, point2D8);
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.data.Range range11 = polarPlot4.getDataRange(valueAxis10);
        org.junit.Assert.assertNull(range11);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Size2D[width=0.0, height=0.0]");
        numberAxis1.setAutoRangeStickyZero(true);
        boolean boolean4 = numberAxis1.getAutoRangeStickyZero();
        boolean boolean5 = numberAxis1.isVisible();
        java.text.NumberFormat numberFormat6 = numberAxis1.getNumberFormatOverride();
        numberAxis1.setAutoRangeIncludesZero(true);
        java.text.NumberFormat numberFormat9 = numberAxis1.getNumberFormatOverride();
        boolean boolean10 = numberAxis1.isNegativeArrowVisible();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(numberFormat6);
        org.junit.Assert.assertNull(numberFormat9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        dateAxis1.setRange((double) 0.0f, (double) 10.0f);
        dateAxis1.resizeRange((double) ' ');
        java.awt.Font font7 = dateAxis1.getTickLabelFont();
        double double8 = dateAxis1.getLowerBound();
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-155.0d) + "'", double8 == (-155.0d));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        double double1 = blockParams0.getTranslateY();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot6.getSimpleLabelOffset();
        double double8 = rectangleInsets7.getRight();
        dateAxis3.setLabelInsets(rectangleInsets7);
        dateAxis3.setRangeAboutValue((double) (-1L), 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setRange((double) 0.0f, (double) 10.0f);
        dateAxis14.resizeRange((double) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        xYPlot21.clearDomainMarkers(15);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer27 = null;
        org.jfree.chart.plot.PolarPlot polarPlot28 = new org.jfree.chart.plot.PolarPlot(xYDataset24, (org.jfree.chart.axis.ValueAxis) dateAxis26, polarItemRenderer27);
        dateAxis26.setLabelAngle((double) (byte) 1);
        dateAxis26.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color33 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int34 = color33.getAlpha();
        dateAxis26.setTickLabelPaint((java.awt.Paint) color33);
        dateAxis26.setInverted(false);
        double double38 = dateAxis26.getLowerBound();
        org.jfree.data.Range range39 = xYPlot21.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis26);
        org.jfree.data.xy.XYDataset xYDataset40 = null;
        xYPlot21.setDataset(xYDataset40);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer43 = null;
        xYPlot21.setRenderer(10, xYItemRenderer43);
        int int45 = xYPlot21.getRangeAxisCount();
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18d + "'", double8 == 0.18d);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 255 + "'", int34 == 255);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNull(range39);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) dateAxis4, polarItemRenderer5);
        dateAxis4.setLabelAngle((double) (byte) 1);
        dateAxis4.setTickMarkOutsideLength((-1.0f));
        dateAxis4.setFixedDimension(0.4d);
        double double13 = dateAxis4.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer14);
        boolean boolean16 = categoryPlot15.isDomainZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = categoryPlot15.getDomainAxis(4);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(categoryAxis18);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.lang.Object obj1 = standardPieSectionLabelGenerator0.clone();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) dateAxis5, polarItemRenderer6);
        dateAxis5.setLabelAngle((double) (byte) 1);
        dateAxis5.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int13 = color12.getAlpha();
        dateAxis5.setTickLabelPaint((java.awt.Paint) color12);
        double double15 = dateAxis5.getFixedAutoRange();
        org.jfree.data.Range range16 = dateAxis5.getDefaultAutoRange();
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) dateAxis5, valueAxis17, xYItemRenderer18);
        boolean boolean20 = standardPieSectionLabelGenerator0.equals((java.lang.Object) xYPlot19);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        float float22 = categoryPlot21.getForegroundAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        categoryPlot21.setRangeAxis((int) '4', valueAxis24, false);
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot21.getRangeAxisLocation();
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = categoryPlot21.getRangeAxisEdge((int) (byte) 0);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder30 = categoryPlot21.getDatasetRenderingOrder();
        java.awt.Color color32 = java.awt.Color.GRAY;
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer37 = null;
        org.jfree.chart.plot.PolarPlot polarPlot38 = new org.jfree.chart.plot.PolarPlot(xYDataset34, (org.jfree.chart.axis.ValueAxis) dateAxis36, polarItemRenderer37);
        dateAxis36.setLabelAngle((double) (byte) 1);
        dateAxis36.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color43 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int44 = color43.getAlpha();
        java.lang.String str45 = color43.toString();
        dateAxis36.setTickMarkPaint((java.awt.Paint) color43);
        org.jfree.chart.plot.PiePlot piePlot47 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = piePlot47.getSimpleLabelOffset();
        java.awt.Stroke stroke49 = piePlot47.getLabelOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker50 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, (java.awt.Paint) color43, stroke49);
        org.jfree.chart.plot.ValueMarker valueMarker51 = new org.jfree.chart.plot.ValueMarker((-1.0d), (java.awt.Paint) color32, stroke49);
        org.jfree.chart.util.Layer layer52 = null;
        boolean boolean53 = categoryPlot21.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker51, layer52);
        try {
            boolean boolean54 = xYPlot19.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 255 + "'", int13 == 255);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 1.0f + "'", float22 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertNotNull(datasetRenderingOrder30);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 255 + "'", int44 == 255);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str45.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer4);
        int int6 = polarPlot5.getBackgroundImageAlignment();
        boolean boolean7 = polarPlot5.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) polarPlot5);
        int int9 = jFreeChart8.getSubtitleCount();
        org.jfree.chart.title.LegendTitle legendTitle11 = jFreeChart8.getLegend((-1));
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Color color13 = color12.brighter();
        java.awt.Color color14 = color13.brighter();
        jFreeChart8.setBorderPaint((java.awt.Paint) color14);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNull(legendTitle11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color14);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        float float1 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis((int) '4', valueAxis3, false);
        categoryPlot0.configureRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer12 = null;
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) dateAxis11, polarItemRenderer12);
        dateAxis11.setLabelAngle((double) (byte) 1);
        dateAxis11.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int19 = color18.getAlpha();
        java.lang.String str20 = color18.toString();
        dateAxis11.setTickMarkPaint((java.awt.Paint) color18);
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = piePlot22.getSimpleLabelOffset();
        java.awt.Stroke stroke24 = piePlot22.getLabelOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, (java.awt.Paint) color18, stroke24);
        org.jfree.chart.util.Layer layer26 = null;
        categoryPlot0.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker25, layer26);
        java.awt.Paint paint28 = valueMarker25.getLabelPaint();
        valueMarker25.setLabel("java.awt.Color[r=255,g=255,b=64]");
        valueMarker25.setLabel("Category Plot");
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = valueMarker25.getLabelOffset();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 255 + "'", int19 == 255);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str20.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(rectangleInsets33);
    }
}

