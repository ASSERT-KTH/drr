import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        java.util.ResourceBundle.clearCache();
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.calculateTopInset(0.0d);
        double double3 = rectangleInsets0.getLeft();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 8.0d + "'", double3 == 8.0d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((-1), (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator1 = null;
        barRenderer3D0.setLegendItemURLGenerator(categorySeriesLabelGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            barRenderer3D0.drawBackground(graphics2D3, categoryPlot4, rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator1, false);
        boolean boolean4 = barRenderer0.getBaseCreateEntities();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        barRenderer0.setSeriesStroke((int) (short) 100, stroke6, false);
        java.lang.Boolean boolean10 = barRenderer0.getSeriesVisible((int) (byte) -1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = barRenderer0.getBaseItemLabelGenerator();
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState17 = barRenderer0.initialise(graphics2D12, rectangle2D13, categoryPlot14, 5, plotRenderingInfo16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(boolean10);
        org.junit.Assert.assertNull(categoryItemLabelGenerator11);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("ChartChangeEventType.GENERAL");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean6 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge5);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge5);
        boolean boolean8 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge5);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge5);
        try {
            double double10 = categoryAxis3D1.getCategoryEnd(4, 1, rectangle2D4, rectangleEdge9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(rectangleEdge9);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.getAutoRangeStickyZero();
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        numberAxis1.setTickMarkStroke(stroke3);
        java.awt.Paint paint5 = numberAxis1.getTickMarkPaint();
        float float6 = numberAxis1.getTickMarkOutsideLength();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 2.0f + "'", float6 == 2.0f);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        java.awt.Shape shape5 = null;
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape12 = null;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color14 = java.awt.Color.black;
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("", "hi!", "hi!", "", true, shape5, false, (java.awt.Paint) color7, false, paint9, stroke10, true, shape12, stroke13, (java.awt.Paint) color14);
        java.lang.Number[] numberArray23 = new java.lang.Number[] { (short) 1, 100.0f, 2, (short) -1, (-1.0f) };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { (short) 1, 100.0f, 2, (short) -1, (-1.0f) };
        java.lang.Number[][] numberArray30 = new java.lang.Number[][] { numberArray23, numberArray29 };
        org.jfree.data.category.CategoryDataset categoryDataset31 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray30);
        legendItem15.setDataset((org.jfree.data.general.Dataset) categoryDataset31);
        java.awt.Paint paint33 = legendItem15.getFillPaint();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(categoryDataset31);
        org.junit.Assert.assertNotNull(paint33);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextFillPaint();
        java.awt.Stroke stroke2 = defaultDrawingSupplier0.getNextStroke();
        java.awt.Shape shape3 = defaultDrawingSupplier0.getNextShape();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = minMaxCategoryRenderer0.getBaseToolTipGenerator();
        java.awt.Stroke stroke4 = minMaxCategoryRenderer0.getItemOutlineStroke(2958465, (-1));
        org.jfree.chart.block.ColumnArrangement columnArrangement6 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle();
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.util.Rotation rotation10 = piePlot9.getDirection();
        org.jfree.chart.plot.Plot plot11 = piePlot9.getParent();
        org.jfree.chart.plot.Plot plot12 = piePlot9.getRootPlot();
        java.awt.Color color13 = java.awt.Color.MAGENTA;
        piePlot9.setOutlinePaint((java.awt.Paint) color13);
        columnArrangement6.add((org.jfree.chart.block.Block) textTitle7, (java.lang.Object) color13);
        boolean boolean16 = textTitle7.getExpandToFitSpace();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer17 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator20 = lineAndShapeRenderer17.getToolTipGenerator(2, 1);
        org.jfree.data.general.PieDataset pieDataset21 = null;
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot(pieDataset21);
        org.jfree.chart.util.Rotation rotation23 = piePlot22.getDirection();
        org.jfree.chart.event.PlotChangeListener plotChangeListener24 = null;
        piePlot22.removeChangeListener(plotChangeListener24);
        piePlot22.setLabelLinksVisible(false);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.color.ColorSpace colorSpace29 = color28.getColorSpace();
        piePlot22.setLabelLinkPaint((java.awt.Paint) color28);
        lineAndShapeRenderer17.setBaseFillPaint((java.awt.Paint) color28);
        textTitle7.setBackgroundPaint((java.awt.Paint) color28);
        minMaxCategoryRenderer0.setSeriesFillPaint(11, (java.awt.Paint) color28);
        org.junit.Assert.assertNull(categoryToolTipGenerator1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rotation10);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNotNull(plot12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator20);
        org.junit.Assert.assertNotNull(rotation23);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(colorSpace29);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        double double2 = stackedBarRenderer3D1.getYOffset();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D6 = new org.jfree.chart.axis.CategoryAxis3D("PlotOrientation.VERTICAL");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D7 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D7.setSeriesCreateEntities((int) (short) 1, (java.lang.Boolean) false, false);
        boolean boolean13 = lineRenderer3D7.equals((java.lang.Object) false);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = null;
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean18 = numberAxis17.getAutoRangeStickyZero();
        java.awt.Stroke stroke19 = numberAxis17.getAxisLineStroke();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        long long22 = year21.getLastMillisecond();
        org.jfree.data.gantt.Task task23 = new org.jfree.data.gantt.Task("AxisLocation.TOP_OR_LEFT", (org.jfree.data.time.TimePeriod) year21);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer24 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Paint paint25 = ganttRenderer24.getCompletePaint();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier26 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint27 = defaultDrawingSupplier26.getNextFillPaint();
        java.awt.Stroke stroke28 = defaultDrawingSupplier26.getNextStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker29 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) year21, paint25, stroke28);
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        lineRenderer3D7.drawRangeMarker(graphics2D14, categoryPlot15, (org.jfree.chart.axis.ValueAxis) numberAxis17, (org.jfree.chart.plot.Marker) categoryMarker29, rectangle2D30);
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        try {
            stackedBarRenderer3D1.drawDomainMarker(graphics2D3, categoryPlot4, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D6, categoryMarker29, rectangle2D32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.0d + "'", double2 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577865599999L + "'", long22 == 1577865599999L);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(stroke28);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, 0.0d);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange4, (double) '#');
        numberAxis2.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        boolean boolean10 = numberAxis2.isNegativeArrowVisible();
        boolean boolean11 = numberAxis2.isTickMarksVisible();
        java.lang.Object obj12 = numberAxis2.clone();
        java.awt.Font font17 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand18 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis2, (double) 11, 0.0d, (double) 'a', (double) 100, font17);
        java.awt.Paint paint19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.text.TextBlock textBlock20 = org.jfree.chart.text.TextUtilities.createTextBlock("NO_CHANGE", font17, paint19);
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment22 = textTitle21.getHorizontalAlignment();
        java.util.List list31 = null;
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem32 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 1L, (java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.05d, (java.lang.Number) 5, (java.lang.Number) (-1), (java.lang.Number) 100.0d, (java.lang.Number) 0L, list31);
        boolean boolean33 = horizontalAlignment22.equals((java.lang.Object) 1.0f);
        textBlock20.setLineAlignment(horizontalAlignment22);
        org.jfree.chart.text.TextLine textLine36 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.text.TextFragment textFragment37 = textLine36.getFirstTextFragment();
        textBlock20.addLine(textLine36);
        java.awt.Graphics2D graphics2D39 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double44 = rectangleInsets42.calculateBottomOutset((double) (-1L));
        org.jfree.chart.util.RectangleAnchor rectangleAnchor45 = org.jfree.chart.util.RectangleAnchor.TOP;
        boolean boolean46 = rectangleInsets42.equals((java.lang.Object) rectangleAnchor45);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor47 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor48 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        boolean boolean50 = textAnchor48.equals((java.lang.Object) 'a');
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType52 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition54 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor45, textBlockAnchor47, textAnchor48, (double) (-2208960000000L), categoryLabelWidthType52, (float) 3);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor55 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Graphics2D graphics2D57 = null;
        org.jfree.chart.text.TextAnchor textAnchor60 = null;
        org.jfree.chart.text.TextAnchor textAnchor62 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        java.awt.Shape shape63 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D57, (float) 1, (float) 0, textAnchor60, (double) 100L, textAnchor62);
        java.lang.String str64 = textAnchor62.toString();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType66 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition68 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor45, textBlockAnchor55, textAnchor62, 0.0d, categoryLabelWidthType66, (float) (short) 100);
        org.jfree.chart.text.TextAnchor textAnchor69 = categoryLabelPosition68.getRotationAnchor();
        try {
            textLine36.draw(graphics2D39, (float) (short) 0, (float) 5, textAnchor69, (float) 10, (float) (-1), (double) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(textBlock20);
        org.junit.Assert.assertNotNull(horizontalAlignment22);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(textFragment37);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor47);
        org.junit.Assert.assertNotNull(textAnchor48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(categoryLabelWidthType52);
        org.junit.Assert.assertNotNull(textBlockAnchor55);
        org.junit.Assert.assertNotNull(textAnchor62);
        org.junit.Assert.assertNull(shape63);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "TextAnchor.CENTER_RIGHT" + "'", str64.equals("TextAnchor.CENTER_RIGHT"));
        org.junit.Assert.assertNotNull(categoryLabelWidthType66);
        org.junit.Assert.assertNotNull(textAnchor69);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("PlotOrientation.VERTICAL");
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        boolean boolean2 = lengthAdjustmentType0.equals((java.lang.Object) "ThreadContext");
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = piePlot1.getDirection();
        org.jfree.chart.plot.Plot plot3 = piePlot1.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        piePlot1.datasetChanged(datasetChangeEvent4);
        java.awt.Stroke stroke6 = null;
        piePlot1.setLabelOutlineStroke(stroke6);
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray34 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[][] numberArray40 = new java.lang.Number[][] { numberArray14, numberArray19, numberArray24, numberArray29, numberArray34, numberArray39 };
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray40);
        org.jfree.data.general.PieDataset pieDataset43 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset41, (int) (short) 1);
        piePlot1.setDataset(pieDataset43);
        java.awt.Paint paint45 = piePlot1.getLabelLinkPaint();
        org.junit.Assert.assertNotNull(rotation2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(pieDataset43);
        org.junit.Assert.assertNotNull(paint45);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 11);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape2, "RectangleEdge.LEFT", "NO_CHANGE");
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity8 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) 8.0d, shape2, "({0}, {1}) = {2}", "SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str9 = categoryLabelEntity8.toString();
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator10 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator11 = null;
        try {
            java.lang.String str12 = categoryLabelEntity8.getImageMapAreaTag(toolTipTagFragmentGenerator10, uRLTagFragmentGenerator11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "CategoryLabelEntity: category=8.0, tooltip=({0}, {1}) = {2}, url=SerialDate.weekInMonthToString(): invalid code." + "'", str9.equals("CategoryLabelEntity: category=8.0, tooltip=({0}, {1}) = {2}, url=SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list1 = taskSeriesCollection0.getRowKeys();
        int int3 = taskSeriesCollection0.indexOf((java.lang.Comparable) "({0}, {1}) = {2}");
        int int4 = taskSeriesCollection0.getColumnCount();
        try {
            java.lang.Number number7 = taskSeriesCollection0.getPercentComplete((java.lang.Comparable) 1.0d, (java.lang.Comparable) 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getHorizontalAlignment();
        double double2 = textTitle0.getContentYOffset();
        java.lang.Object obj3 = textTitle0.clone();
        java.lang.Object obj4 = null;
        boolean boolean5 = textTitle0.equals(obj4);
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str1 = projectInfo0.getInfo();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "http://www.jfree.org/jfreechart/index.html" + "'", str1.equals("http://www.jfree.org/jfreechart/index.html"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor3 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition4 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'labelAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.util.Rotation rotation3 = piePlot2.getDirection();
        org.jfree.chart.plot.Plot plot4 = piePlot2.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        piePlot2.datasetChanged(datasetChangeEvent5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        piePlot2.drawBackgroundImage(graphics2D7, rectangle2D8);
        java.awt.Paint paint10 = piePlot2.getBaseSectionOutlinePaint();
        java.awt.Paint paint11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot2.setBaseSectionPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot2);
        boolean boolean14 = jFreeChart13.isBorderVisible();
        try {
            org.jfree.chart.title.Title title16 = jFreeChart13.getSubtitle(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean2 = numberAxis3D1.isTickMarksVisible();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        numberAxis3D1.setLowerBound(90.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(plot3);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        java.awt.Color color0 = java.awt.Color.black;
        java.lang.String str1 = org.jfree.chart.util.PaintUtilities.colorToString(color0);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "black" + "'", str1.equals("black"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.util.Rotation rotation3 = piePlot2.getDirection();
        org.jfree.chart.plot.Plot plot4 = piePlot2.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        piePlot2.datasetChanged(datasetChangeEvent5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        piePlot2.drawBackgroundImage(graphics2D7, rectangle2D8);
        java.awt.Paint paint10 = piePlot2.getBaseSectionOutlinePaint();
        java.awt.Paint paint11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot2.setBaseSectionPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart13.setTitle("({0}, {1}) = {3} - {4}");
        java.lang.Object obj16 = jFreeChart13.clone();
        jFreeChart13.fireChartChanged();
        jFreeChart13.setNotify(false);
        try {
            org.jfree.chart.plot.CategoryPlot categoryPlot20 = jFreeChart13.getCategoryPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PiePlot cannot be cast to org.jfree.chart.plot.CategoryPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getFixedAutoRange();
        boolean boolean3 = numberAxis1.isAxisLineVisible();
        float float4 = numberAxis1.getTickMarkInsideLength();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setBaseLinesVisible(true);
        boolean boolean3 = lineAndShapeRenderer0.getBaseItemLabelsVisible();
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        barRenderer4.setBaseToolTipGenerator(categoryToolTipGenerator5, false);
        boolean boolean8 = barRenderer4.getBaseCreateEntities();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        barRenderer4.setSeriesStroke((int) (short) 100, stroke10, false);
        java.lang.Boolean boolean14 = barRenderer4.getSeriesVisible((int) (byte) -1);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator16 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        barRenderer4.setSeriesToolTipGenerator((int) '#', (org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator16, false);
        lineAndShapeRenderer0.setBaseToolTipGenerator((org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator16);
        int int20 = lineAndShapeRenderer0.getRowCount();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNull(boolean14);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list1 = defaultStatisticalCategoryDataset0.getColumnKeys();
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        java.util.List list3 = defaultStatisticalCategoryDataset0.getRowKeys();
        org.jfree.data.general.PieDataset pieDataset5 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, 0);
        boolean boolean6 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset5);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0.0d + "'", number2.equals(0.0d));
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNotNull(pieDataset5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator1, false);
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.util.Rotation rotation7 = piePlot6.getDirection();
        org.jfree.chart.plot.Plot plot8 = piePlot6.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent9 = null;
        piePlot6.datasetChanged(datasetChangeEvent9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        piePlot6.drawBackgroundImage(graphics2D11, rectangle2D12);
        java.awt.Paint paint14 = piePlot6.getBaseSectionOutlinePaint();
        java.awt.Paint paint15 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot6.setBaseSectionPaint(paint15);
        barRenderer0.setSeriesItemLabelPaint((int) (byte) 0, paint15);
        boolean boolean18 = barRenderer0.getAutoPopulateSeriesShape();
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator20 = new org.jfree.chart.urls.StandardCategoryURLGenerator("RectangleEdge.LEFT");
        barRenderer0.setBaseURLGenerator((org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator20);
        org.jfree.data.general.PieDataset pieDataset22 = null;
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot(pieDataset22);
        org.jfree.chart.util.Rotation rotation24 = piePlot23.getDirection();
        org.jfree.chart.plot.Plot plot25 = piePlot23.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent26 = null;
        piePlot23.datasetChanged(datasetChangeEvent26);
        org.jfree.chart.renderer.category.BarRenderer barRenderer28 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator29 = null;
        barRenderer28.setBaseToolTipGenerator(categoryToolTipGenerator29, false);
        boolean boolean32 = barRenderer28.getBaseCreateEntities();
        java.awt.Stroke stroke34 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        barRenderer28.setSeriesStroke((int) (short) 100, stroke34, false);
        piePlot23.setLabelOutlineStroke(stroke34);
        boolean boolean38 = standardCategoryURLGenerator20.equals((java.lang.Object) piePlot23);
        java.lang.Object obj39 = standardCategoryURLGenerator20.clone();
        org.junit.Assert.assertNotNull(rotation7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(rotation24);
        org.junit.Assert.assertNull(plot25);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(obj39);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.util.Rotation rotation3 = piePlot2.getDirection();
        org.jfree.chart.plot.Plot plot4 = piePlot2.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        piePlot2.datasetChanged(datasetChangeEvent5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        piePlot2.drawBackgroundImage(graphics2D7, rectangle2D8);
        java.awt.Paint paint10 = piePlot2.getBaseSectionOutlinePaint();
        java.awt.Paint paint11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot2.setBaseSectionPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart13.setBackgroundImageAlpha((float) (byte) 10);
        try {
            org.jfree.chart.title.Title title17 = jFreeChart13.getSubtitle((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "({0}, {1}) = {3} - {4}", "", image3, "hi!", "hi!", "({0}, {1}) = {3} - {4}");
        java.lang.String str8 = projectInfo7.getLicenceText();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) str8);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "({0}, {1}) = {3} - {4}" + "'", str8.equals("({0}, {1}) = {3} - {4}"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.chart.ChartColor chartColor5 = new org.jfree.chart.ChartColor((int) (short) 0, (int) (byte) 100, (int) '#');
        boolean boolean6 = spreadsheetDate1.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate9 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate8);
        try {
            org.jfree.data.time.SerialDate serialDate11 = serialDate9.getPreviousDayOfWeek((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(serialDate9);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list1 = axisCollection0.getAxesAtBottom();
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) sortOrder0);
        org.junit.Assert.assertNotNull(sortOrder0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer2 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.LegendItem legendItem5 = stackedAreaRenderer2.getLegendItem((int) 'a', 0);
        java.awt.Shape shape7 = null;
        stackedAreaRenderer2.setSeriesShape((int) '4', shape7, true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = null;
        stackedAreaRenderer2.setBaseURLGenerator(categoryURLGenerator10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = stackedAreaRenderer2.getNegativeItemLabelPosition(100, (int) (short) 0);
        org.jfree.chart.text.TextAnchor textAnchor15 = itemLabelPosition14.getRotationAnchor();
        org.jfree.chart.text.TextAnchor textAnchor16 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.axis.NumberTick numberTick18 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 5, "NO_CHANGE", textAnchor15, textAnchor16, (double) (-1));
        java.lang.Object obj19 = numberTick18.clone();
        org.junit.Assert.assertNull(legendItem5);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertNotNull(textAnchor16);
        org.junit.Assert.assertNotNull(obj19);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator0 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection1 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list2 = taskSeriesCollection1.getRowKeys();
        int int4 = taskSeriesCollection1.indexOf((java.lang.Comparable) "({0}, {1}) = {2}");
        int int5 = taskSeriesCollection1.getSeriesCount();
        try {
            java.lang.String str7 = standardCategoryToolTipGenerator0.generateColumnLabel((org.jfree.data.category.CategoryDataset) taskSeriesCollection1, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator1, false);
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.util.Rotation rotation7 = piePlot6.getDirection();
        org.jfree.chart.plot.Plot plot8 = piePlot6.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent9 = null;
        piePlot6.datasetChanged(datasetChangeEvent9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        piePlot6.drawBackgroundImage(graphics2D11, rectangle2D12);
        java.awt.Paint paint14 = piePlot6.getBaseSectionOutlinePaint();
        java.awt.Paint paint15 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot6.setBaseSectionPaint(paint15);
        barRenderer0.setSeriesItemLabelPaint((int) (byte) 0, paint15);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator19 = barRenderer0.getSeriesItemLabelGenerator(15);
        boolean boolean20 = barRenderer0.getBaseSeriesVisible();
        org.junit.Assert.assertNotNull(rotation7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(categoryItemLabelGenerator19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setDrawOutlines(true);
        lineAndShapeRenderer0.setUseFillPaint(true);
        java.lang.Boolean boolean6 = lineAndShapeRenderer0.getSeriesShapesVisible(2);
        java.awt.Paint paint8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        lineAndShapeRenderer0.setSeriesPaint((int) (byte) 10, paint8, true);
        int int11 = lineAndShapeRenderer0.getPassCount();
        lineAndShapeRenderer0.setSeriesShapesVisible(0, (java.lang.Boolean) true);
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, 0.0d);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange4, (double) '#');
        numberAxis2.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        boolean boolean10 = numberAxis2.isNegativeArrowVisible();
        boolean boolean11 = numberAxis2.isTickMarksVisible();
        java.lang.String str12 = numberAxis2.getLabel();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean15 = numberAxis3D14.isInverted();
        org.jfree.data.time.DateRange dateRange16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis3D14.setRangeWithMargins((org.jfree.data.Range) dateRange16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, xYItemRenderer18);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str23 = numberAxis22.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange24 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange24, 0.0d);
        org.jfree.data.Range range28 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange24, (double) '#');
        numberAxis22.setDefaultAutoRange((org.jfree.data.Range) dateRange24);
        boolean boolean30 = numberAxis22.isNegativeArrowVisible();
        boolean boolean31 = numberAxis22.isTickMarksVisible();
        numberAxis22.setFixedAutoRange((double) 1);
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str36 = numberAxis35.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange37 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint39 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange37, 0.0d);
        org.jfree.data.Range range41 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange37, (double) '#');
        numberAxis35.setDefaultAutoRange((org.jfree.data.Range) dateRange37);
        boolean boolean43 = numberAxis35.isNegativeArrowVisible();
        boolean boolean44 = numberAxis35.isTickMarksVisible();
        java.lang.Object obj45 = numberAxis35.clone();
        java.awt.Font font50 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand51 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis35, (double) 11, 0.0d, (double) 'a', (double) 100, font50);
        java.awt.Graphics2D graphics2D52 = null;
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        markerAxisBand51.draw(graphics2D52, rectangle2D53, rectangle2D54, (double) 12, (double) 12);
        numberAxis22.setMarkerBand(markerAxisBand51);
        xYPlot19.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) numberAxis22);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder60 = xYPlot19.getSeriesRenderingOrder();
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer61 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        org.jfree.chart.LegendItem legendItem64 = boxAndWhiskerRenderer61.getLegendItem(15, (int) '#');
        java.awt.Paint paint67 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.renderer.category.BarRenderer barRenderer68 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator69 = null;
        barRenderer68.setBaseToolTipGenerator(categoryToolTipGenerator69, false);
        boolean boolean72 = barRenderer68.getBaseCreateEntities();
        java.awt.Stroke stroke74 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        barRenderer68.setSeriesStroke((int) (short) 100, stroke74, false);
        org.jfree.chart.plot.ValueMarker valueMarker77 = new org.jfree.chart.plot.ValueMarker(0.0d, paint67, stroke74);
        boxAndWhiskerRenderer61.setSeriesItemLabelPaint(6, paint67, false);
        xYPlot19.setRangeGridlinePaint(paint67);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateRange16);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(dateRange24);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertNotNull(dateRange37);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(obj45);
        org.junit.Assert.assertNotNull(font50);
        org.junit.Assert.assertNotNull(seriesRenderingOrder60);
        org.junit.Assert.assertNull(legendItem64);
        org.junit.Assert.assertNotNull(paint67);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertNotNull(stroke74);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        java.lang.String[] strArray0 = null;
        java.lang.Number[] numberArray8 = new java.lang.Number[] { (short) 1, 100.0f, 2, (short) -1, (-1.0f) };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { (short) 1, 100.0f, 2, (short) -1, (-1.0f) };
        java.lang.Number[][] numberArray15 = new java.lang.Number[][] { numberArray8, numberArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray15);
        java.lang.Number[] numberArray19 = new java.lang.Number[] { 6, 0.0f };
        java.lang.Number[][] numberArray20 = new java.lang.Number[][] { numberArray19 };
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset21 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray0, numberArray15, numberArray20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset: the number of series in the start value dataset does not match the number of series in the end value dataset.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray20);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getHorizontalAlignment();
        java.util.List list10 = null;
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem11 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 1L, (java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.05d, (java.lang.Number) 5, (java.lang.Number) (-1), (java.lang.Number) 100.0d, (java.lang.Number) 0L, list10);
        boolean boolean12 = horizontalAlignment1.equals((java.lang.Object) 1.0f);
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean14 = horizontalAlignment1.equals((java.lang.Object) timeZone13);
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.renderer.category.AreaRenderer areaRenderer0 = new org.jfree.chart.renderer.category.AreaRenderer();
        java.awt.Paint paint2 = areaRenderer0.getSeriesItemLabelPaint((-1));
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = null;
        areaRenderer0.setSeriesItemLabelGenerator((int) '4', categoryItemLabelGenerator4, false);
        java.awt.Paint paint7 = areaRenderer0.getBaseOutlinePaint();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer8 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.LegendItem legendItem11 = stackedAreaRenderer8.getLegendItem((int) 'a', 0);
        java.awt.Shape shape13 = null;
        stackedAreaRenderer8.setSeriesShape((int) '4', shape13, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = stackedAreaRenderer8.getSeriesPositiveItemLabelPosition((int) (byte) 1);
        areaRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition17);
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(legendItem11);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        java.awt.Paint paint2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator4 = null;
        barRenderer3.setBaseToolTipGenerator(categoryToolTipGenerator4, false);
        boolean boolean7 = barRenderer3.getBaseCreateEntities();
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        barRenderer3.setSeriesStroke((int) (short) 100, stroke9, false);
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker(0.0d, paint2, stroke9);
        java.awt.Paint paint13 = valueMarker12.getPaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = valueMarker12.getLabelAnchor();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = valueMarker12.getLabelAnchor();
        try {
            java.awt.geom.Point2D point2D16 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange3, 0.0d);
        org.jfree.data.Range range7 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange3, (double) '#');
        numberAxis1.setDefaultAutoRange((org.jfree.data.Range) dateRange3);
        org.jfree.data.Range range11 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange3, 0.0d, (double) (byte) -1);
        java.util.Date date12 = dateRange3.getUpperDate();
        org.jfree.chart.text.TextAnchor textAnchor14 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.text.TextAnchor textAnchor19 = null;
        org.jfree.chart.text.TextAnchor textAnchor21 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        java.awt.Shape shape22 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D16, (float) 1, (float) 0, textAnchor19, (double) 100L, textAnchor21);
        java.lang.String str23 = textAnchor21.toString();
        org.jfree.chart.axis.DateTick dateTick25 = new org.jfree.chart.axis.DateTick(date12, "TextAnchor.CENTER_RIGHT", textAnchor14, textAnchor21, (double) (-1.0f));
        java.util.Date date26 = dateTick25.getDate();
        java.lang.Object obj27 = dateTick25.clone();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(dateRange3);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(textAnchor14);
        org.junit.Assert.assertNotNull(textAnchor21);
        org.junit.Assert.assertNull(shape22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "TextAnchor.CENTER_RIGHT" + "'", str23.equals("TextAnchor.CENTER_RIGHT"));
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(obj27);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("ChartChangeEventType.GENERAL");
        double double2 = categoryAxis3D1.getUpperMargin();
        java.lang.Comparable comparable3 = null;
        try {
            categoryAxis3D1.addCategoryLabelToolTip(comparable3, "TextAnchor.CENTER_RIGHT");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.util.Rotation rotation4 = piePlot3.getDirection();
        org.jfree.chart.plot.Plot plot5 = piePlot3.getParent();
        org.jfree.chart.plot.Plot plot6 = piePlot3.getRootPlot();
        java.awt.Color color7 = java.awt.Color.MAGENTA;
        piePlot3.setOutlinePaint((java.awt.Paint) color7);
        columnArrangement0.add((org.jfree.chart.block.Block) textTitle1, (java.lang.Object) color7);
        boolean boolean10 = textTitle1.getExpandToFitSpace();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator14 = lineAndShapeRenderer11.getToolTipGenerator(2, 1);
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot(pieDataset15);
        org.jfree.chart.util.Rotation rotation17 = piePlot16.getDirection();
        org.jfree.chart.event.PlotChangeListener plotChangeListener18 = null;
        piePlot16.removeChangeListener(plotChangeListener18);
        piePlot16.setLabelLinksVisible(false);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.color.ColorSpace colorSpace23 = color22.getColorSpace();
        piePlot16.setLabelLinkPaint((java.awt.Paint) color22);
        lineAndShapeRenderer11.setBaseFillPaint((java.awt.Paint) color22);
        textTitle1.setBackgroundPaint((java.awt.Paint) color22);
        java.awt.Graphics2D graphics2D27 = null;
        try {
            org.jfree.chart.util.Size2D size2D28 = textTitle1.arrange(graphics2D27);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(rotation4);
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertNotNull(plot6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator14);
        org.junit.Assert.assertNotNull(rotation17);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(colorSpace23);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.time.TimePeriod timePeriod1 = null;
        org.jfree.data.gantt.Task task2 = new org.jfree.data.gantt.Task("hi!", timePeriod1);
        java.lang.Object obj3 = null;
        boolean boolean4 = task2.equals(obj3);
        org.jfree.data.time.TimePeriod timePeriod6 = null;
        org.jfree.data.gantt.Task task7 = new org.jfree.data.gantt.Task("hi!", timePeriod6);
        java.lang.Object obj8 = null;
        boolean boolean9 = task7.equals(obj8);
        task7.setPercentComplete((java.lang.Double) 90.0d);
        task2.removeSubtask(task7);
        java.lang.Double double13 = task2.getPercentComplete();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(double13);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType0 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        org.junit.Assert.assertNotNull(categoryLabelWidthType0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        java.lang.String str0 = org.jfree.chart.labels.StandardCategorySeriesLabelGenerator.DEFAULT_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Nearest" + "'", str1.equals("Nearest"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.util.Rotation rotation3 = piePlot2.getDirection();
        org.jfree.chart.plot.Plot plot4 = piePlot2.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        piePlot2.datasetChanged(datasetChangeEvent5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        piePlot2.drawBackgroundImage(graphics2D7, rectangle2D8);
        java.awt.Paint paint10 = piePlot2.getBaseSectionOutlinePaint();
        java.awt.Paint paint11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot2.setBaseSectionPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart13.setTitle("({0}, {1}) = {3} - {4}");
        org.jfree.chart.title.TextTitle textTitle16 = jFreeChart13.getTitle();
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment18 = textTitle17.getHorizontalAlignment();
        textTitle17.setExpandToFitSpace(true);
        jFreeChart13.removeSubtitle((org.jfree.chart.title.Title) textTitle17);
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        jFreeChart13.setBackgroundPaint((java.awt.Paint) color22);
        int int24 = jFreeChart13.getSubtitleCount();
        org.jfree.data.KeyToGroupMap keyToGroupMap26 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) true);
        int int28 = keyToGroupMap26.getKeyCount((java.lang.Comparable) 0.05d);
        java.util.List list29 = keyToGroupMap26.getGroups();
        try {
            jFreeChart13.setSubtitles(list29);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Boolean cannot be cast to org.jfree.chart.title.Title");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(textTitle16);
        org.junit.Assert.assertNotNull(horizontalAlignment18);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(list29);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, 0.0d);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange4, (double) '#');
        numberAxis2.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        boolean boolean10 = numberAxis2.isNegativeArrowVisible();
        boolean boolean11 = numberAxis2.isTickMarksVisible();
        java.lang.Object obj12 = numberAxis2.clone();
        numberAxis2.setAutoRangeIncludesZero(true);
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str17 = numberAxis16.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange18 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange18, 0.0d);
        org.jfree.data.Range range22 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange18, (double) '#');
        numberAxis16.setDefaultAutoRange((org.jfree.data.Range) dateRange18);
        boolean boolean24 = numberAxis16.isNegativeArrowVisible();
        boolean boolean25 = numberAxis16.isTickMarksVisible();
        java.lang.Object obj26 = numberAxis16.clone();
        java.awt.Font font31 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand32 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis16, (double) 11, 0.0d, (double) 'a', (double) 100, font31);
        numberAxis2.setTickLabelFont(font31);
        org.jfree.data.general.PieDataset pieDataset34 = null;
        org.jfree.chart.plot.PiePlot piePlot35 = new org.jfree.chart.plot.PiePlot(pieDataset34);
        org.jfree.chart.util.Rotation rotation36 = piePlot35.getDirection();
        org.jfree.chart.plot.Plot plot37 = piePlot35.getParent();
        org.jfree.chart.plot.Plot plot38 = piePlot35.getRootPlot();
        org.jfree.chart.JFreeChart jFreeChart40 = new org.jfree.chart.JFreeChart("PlotOrientation.VERTICAL", font31, (org.jfree.chart.plot.Plot) piePlot35, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent41 = null;
        try {
            jFreeChart40.plotChanged(plotChangeEvent41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(dateRange18);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(rotation36);
        org.junit.Assert.assertNull(plot37);
        org.junit.Assert.assertNotNull(plot38);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        java.awt.Paint paint1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        barRenderer2.setBaseToolTipGenerator(categoryToolTipGenerator3, false);
        boolean boolean6 = barRenderer2.getBaseCreateEntities();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        barRenderer2.setSeriesStroke((int) (short) 100, stroke8, false);
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker(0.0d, paint1, stroke8);
        java.awt.Paint paint12 = valueMarker11.getPaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = valueMarker11.getLabelAnchor();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double16 = numberAxis15.getFixedAutoRange();
        java.text.NumberFormat numberFormat17 = numberAxis15.getNumberFormatOverride();
        java.awt.Paint paint18 = numberAxis15.getAxisLinePaint();
        valueMarker11.setOutlinePaint(paint18);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = valueMarker11.getLabelOffset();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNull(numberFormat17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(rectangleInsets20);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        java.lang.String[] strArray2 = new java.lang.String[] { "SerialDate.weekInMonthToString(): invalid code.", "VerticalAlignment.TOP" };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (short) 1, 100.0f, 2, (short) -1, (-1.0f) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { (short) 1, 100.0f, 2, (short) -1, (-1.0f) };
        java.lang.Number[][] numberArray17 = new java.lang.Number[][] { numberArray10, numberArray16 };
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray17);
        java.lang.Number[][] numberArray19 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset20 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray2, numberArray17, numberArray19);
        int int21 = defaultIntervalCategoryDataset20.getSeriesCount();
        try {
            java.lang.Comparable comparable23 = defaultIntervalCategoryDataset20.getColumnKey(5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(categoryDataset18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2 + "'", int21 == 2);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.block.Arrangement arrangement0 = null;
        java.awt.Shape shape6 = null;
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Paint paint10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape13 = null;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color15 = java.awt.Color.black;
        org.jfree.chart.LegendItem legendItem16 = new org.jfree.chart.LegendItem("", "hi!", "hi!", "", true, shape6, false, (java.awt.Paint) color8, false, paint10, stroke11, true, shape13, stroke14, (java.awt.Paint) color15);
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (short) 1, 100.0f, 2, (short) -1, (-1.0f) };
        java.lang.Number[] numberArray30 = new java.lang.Number[] { (short) 1, 100.0f, 2, (short) -1, (-1.0f) };
        java.lang.Number[][] numberArray31 = new java.lang.Number[][] { numberArray24, numberArray30 };
        org.jfree.data.category.CategoryDataset categoryDataset32 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray31);
        legendItem16.setDataset((org.jfree.data.general.Dataset) categoryDataset32);
        org.jfree.data.KeyedObjects2D keyedObjects2D34 = new org.jfree.data.KeyedObjects2D();
        keyedObjects2D34.removeColumn((java.lang.Comparable) 100.0f);
        org.jfree.data.general.PieDataset pieDataset37 = null;
        org.jfree.chart.plot.PiePlot piePlot38 = new org.jfree.chart.plot.PiePlot(pieDataset37);
        org.jfree.chart.util.Rotation rotation39 = piePlot38.getDirection();
        org.jfree.chart.event.PlotChangeListener plotChangeListener40 = null;
        piePlot38.removeChangeListener(plotChangeListener40);
        piePlot38.setLabelLinksVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = null;
        piePlot38.handleClick(15, 1, plotRenderingInfo46);
        org.jfree.data.general.PieDataset pieDataset48 = null;
        org.jfree.chart.plot.PiePlot piePlot49 = new org.jfree.chart.plot.PiePlot(pieDataset48);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator50 = null;
        piePlot49.setToolTipGenerator(pieToolTipGenerator50);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod54 = new org.jfree.data.time.SimpleTimePeriod((long) 10, (long) 'a');
        java.awt.Stroke stroke55 = piePlot49.getSectionOutlineStroke((java.lang.Comparable) simpleTimePeriod54);
        java.util.Date date56 = simpleTimePeriod54.getEnd();
        keyedObjects2D34.setObject((java.lang.Object) 15, (java.lang.Comparable) simpleTimePeriod54, (java.lang.Comparable) (byte) 0);
        try {
            org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer59 = new org.jfree.chart.title.LegendItemBlockContainer(arrangement0, (org.jfree.data.general.Dataset) categoryDataset32, (java.lang.Comparable) simpleTimePeriod54);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(categoryDataset32);
        org.junit.Assert.assertNotNull(rotation39);
        org.junit.Assert.assertNull(stroke55);
        org.junit.Assert.assertNotNull(date56);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) paint0);
        org.jfree.chart.JFreeChart jFreeChart2 = null;
        chartChangeEvent1.setChart(jFreeChart2);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer5 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.LegendItem legendItem8 = stackedAreaRenderer5.getLegendItem((int) 'a', 0);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator9 = null;
        stackedAreaRenderer5.setBaseItemLabelGenerator(categoryItemLabelGenerator9, true);
        boolean boolean13 = stackedAreaRenderer5.equals((java.lang.Object) 10.0f);
        boolean boolean14 = chartChangeEventType4.equals((java.lang.Object) 10.0f);
        chartChangeEvent1.setType(chartChangeEventType4);
        java.lang.String str16 = chartChangeEventType4.toString();
        org.junit.Assert.assertNotNull(paint0);
        org.junit.Assert.assertNotNull(chartChangeEventType4);
        org.junit.Assert.assertNull(legendItem8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str16.equals("ChartChangeEventType.GENERAL"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.zoomRange(0.0d, 10.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis1.getTickUnit();
        dateAxis0.setTickUnit(dateTickUnit5, false, true);
        int int9 = dateTickUnit5.getRollCount();
        int int10 = dateTickUnit5.getUnit();
        org.junit.Assert.assertNotNull(dateTickUnit5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.util.Rotation rotation3 = piePlot2.getDirection();
        org.jfree.chart.plot.Plot plot4 = piePlot2.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        piePlot2.datasetChanged(datasetChangeEvent5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        piePlot2.drawBackgroundImage(graphics2D7, rectangle2D8);
        java.awt.Paint paint10 = piePlot2.getBaseSectionOutlinePaint();
        java.awt.Paint paint11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot2.setBaseSectionPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart13.setTitle("({0}, {1}) = {3} - {4}");
        org.jfree.chart.title.TextTitle textTitle16 = jFreeChart13.getTitle();
        textTitle16.setToolTipText("");
        org.jfree.data.general.PieDataset pieDataset19 = null;
        org.jfree.chart.plot.PiePlot piePlot20 = new org.jfree.chart.plot.PiePlot(pieDataset19);
        org.jfree.chart.util.Rotation rotation21 = piePlot20.getDirection();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator22 = piePlot20.getURLGenerator();
        piePlot20.setMaximumLabelWidth((double) (short) 100);
        double double26 = piePlot20.getExplodePercent((java.lang.Comparable) 10.0f);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator27 = piePlot20.getLegendLabelGenerator();
        boolean boolean28 = textTitle16.equals((java.lang.Object) piePlot20);
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(textTitle16);
        org.junit.Assert.assertNotNull(rotation21);
        org.junit.Assert.assertNull(pieURLGenerator22);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange3, 0.0d);
        org.jfree.data.Range range7 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange3, (double) '#');
        numberAxis1.setDefaultAutoRange((org.jfree.data.Range) dateRange3);
        boolean boolean9 = numberAxis1.isNegativeArrowVisible();
        org.jfree.data.time.DateRange dateRange10 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis1.setRangeWithMargins((org.jfree.data.Range) dateRange10);
        numberAxis1.setLabelToolTip("ChartChangeEventType.DATASET_UPDATED");
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(dateRange3);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateRange10);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.DAY_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 86400000L + "'", long0 == 86400000L);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.text.TextFragment textFragment4 = textLine3.getFirstTextFragment();
        java.awt.Font font5 = textFragment4.getFont();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.block.LabelBlock labelBlock7 = new org.jfree.chart.block.LabelBlock("hi!", font5, (java.awt.Paint) color6);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer8 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = minMaxCategoryRenderer8.getBaseToolTipGenerator();
        java.awt.Paint paint10 = minMaxCategoryRenderer8.getGroupPaint();
        org.jfree.chart.text.TextMeasurer textMeasurer12 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock13 = org.jfree.chart.text.TextUtilities.createTextBlock("Nearest", font5, paint10, (float) 3, textMeasurer12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textFragment4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(categoryToolTipGenerator9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.util.List list1 = blockContainer0.getBlocks();
        org.jfree.chart.block.ColumnArrangement columnArrangement2 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        org.jfree.chart.util.Rotation rotation6 = piePlot5.getDirection();
        org.jfree.chart.plot.Plot plot7 = piePlot5.getParent();
        org.jfree.chart.plot.Plot plot8 = piePlot5.getRootPlot();
        java.awt.Color color9 = java.awt.Color.MAGENTA;
        piePlot5.setOutlinePaint((java.awt.Paint) color9);
        columnArrangement2.add((org.jfree.chart.block.Block) textTitle3, (java.lang.Object) color9);
        boolean boolean12 = textTitle3.getExpandToFitSpace();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange17 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange17, 0.0d);
        org.jfree.data.Range range21 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange17, (double) '#');
        numberAxis15.setDefaultAutoRange((org.jfree.data.Range) dateRange17);
        boolean boolean23 = numberAxis15.isNegativeArrowVisible();
        boolean boolean24 = numberAxis15.isTickMarksVisible();
        java.lang.Object obj25 = numberAxis15.clone();
        java.awt.Font font30 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand31 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis15, (double) 11, 0.0d, (double) 'a', (double) 100, font30);
        java.awt.Paint paint32 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.text.TextBlock textBlock33 = org.jfree.chart.text.TextUtilities.createTextBlock("NO_CHANGE", font30, paint32);
        org.jfree.chart.title.TextTitle textTitle34 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment35 = textTitle34.getHorizontalAlignment();
        java.util.List list44 = null;
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem45 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 1L, (java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.05d, (java.lang.Number) 5, (java.lang.Number) (-1), (java.lang.Number) 100.0d, (java.lang.Number) 0L, list44);
        boolean boolean46 = horizontalAlignment35.equals((java.lang.Object) 1.0f);
        textBlock33.setLineAlignment(horizontalAlignment35);
        org.jfree.chart.text.TextLine textLine49 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.text.TextFragment textFragment50 = textLine49.getFirstTextFragment();
        textBlock33.addLine(textLine49);
        org.jfree.data.KeyedObjects keyedObjects52 = new org.jfree.data.KeyedObjects();
        int int53 = keyedObjects52.getItemCount();
        boolean boolean54 = textBlock33.equals((java.lang.Object) int53);
        try {
            blockContainer0.add((org.jfree.chart.block.Block) textTitle3, (java.lang.Object) int53);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Integer cannot be cast to org.jfree.chart.util.RectangleEdge");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(rotation6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(plot8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(dateRange17);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(textBlock33);
        org.junit.Assert.assertNotNull(horizontalAlignment35);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(textFragment50);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.text.TextFragment textFragment5 = textLine4.getFirstTextFragment();
        java.awt.Font font6 = textFragment5.getFont();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.block.LabelBlock labelBlock8 = new org.jfree.chart.block.LabelBlock("hi!", font6, (java.awt.Paint) color7);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer9 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Paint paint10 = ganttRenderer9.getCompletePaint();
        org.jfree.chart.block.LabelBlock labelBlock11 = new org.jfree.chart.block.LabelBlock("({0}, {1}) = {3} - {4}", font6, paint10);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer12 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        minMaxCategoryRenderer12.setBaseCreateEntities(false, true);
        org.jfree.data.general.PieDataset pieDataset17 = null;
        org.jfree.chart.plot.PiePlot piePlot18 = new org.jfree.chart.plot.PiePlot(pieDataset17);
        org.jfree.chart.util.Rotation rotation19 = piePlot18.getDirection();
        org.jfree.chart.plot.Plot plot20 = piePlot18.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = null;
        piePlot18.datasetChanged(datasetChangeEvent21);
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        piePlot18.drawBackgroundImage(graphics2D23, rectangle2D24);
        java.awt.Paint paint26 = piePlot18.getBaseSectionOutlinePaint();
        java.awt.Paint paint27 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot18.setBaseSectionPaint(paint27);
        org.jfree.chart.JFreeChart jFreeChart29 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot18);
        jFreeChart29.setTitle("({0}, {1}) = {3} - {4}");
        org.jfree.chart.title.TextTitle textTitle32 = jFreeChart29.getTitle();
        java.awt.Stroke stroke33 = jFreeChart29.getBorderStroke();
        jFreeChart29.setAntiAlias(true);
        org.jfree.chart.ui.Library library40 = new org.jfree.chart.ui.Library("hi!", "hi!", "hi!", "");
        java.awt.Paint paint41 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        boolean boolean42 = library40.equals((java.lang.Object) paint41);
        jFreeChart29.setBorderPaint(paint41);
        minMaxCategoryRenderer12.setGroupPaint(paint41);
        org.jfree.chart.text.TextMeasurer textMeasurer46 = null;
        org.jfree.chart.text.TextBlock textBlock47 = org.jfree.chart.text.TextUtilities.createTextBlock("", font6, paint41, (float) 500, textMeasurer46);
        org.junit.Assert.assertNotNull(textFragment5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rotation19);
        org.junit.Assert.assertNull(plot20);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(textTitle32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(textBlock47);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) "black");
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        ganttRenderer0.setStartPercent((double) 100.0f);
        ganttRenderer0.setIncludeBaseInRange(true);
        double double5 = ganttRenderer0.getStartPercent();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange3, 0.0d);
        org.jfree.data.Range range7 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange3, (double) '#');
        numberAxis1.setDefaultAutoRange((org.jfree.data.Range) dateRange3);
        org.jfree.data.Range range10 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange3, 12.0d);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(dateRange3);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(range10);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Shape shape7 = null;
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Paint paint11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape14 = null;
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color16 = java.awt.Color.black;
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("", "hi!", "hi!", "", true, shape7, false, (java.awt.Paint) color9, false, paint11, stroke12, true, shape14, stroke15, (java.awt.Paint) color16);
        java.awt.Stroke stroke18 = legendItem17.getLineStroke();
        legendItem17.setSeriesIndex((int) (short) 0);
        java.lang.Number[] numberArray27 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray37 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray42 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray47 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray52 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[][] numberArray53 = new java.lang.Number[][] { numberArray27, numberArray32, numberArray37, numberArray42, numberArray47, numberArray52 };
        org.jfree.data.category.CategoryDataset categoryDataset54 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray53);
        org.jfree.data.general.PieDataset pieDataset56 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset54, (int) (short) 1);
        legendItem17.setDataset((org.jfree.data.general.Dataset) categoryDataset54);
        java.awt.Stroke stroke58 = legendItem17.getOutlineStroke();
        piePlot1.setOutlineStroke(stroke58);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray37);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(numberArray47);
        org.junit.Assert.assertNotNull(numberArray52);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(categoryDataset54);
        org.junit.Assert.assertNotNull(pieDataset56);
        org.junit.Assert.assertNotNull(stroke58);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setDrawOutlines(true);
        lineAndShapeRenderer0.setUseFillPaint(true);
        java.lang.Boolean boolean6 = lineAndShapeRenderer0.getSeriesShapesVisible(2);
        lineAndShapeRenderer0.setSeriesVisible((int) ' ', (java.lang.Boolean) false, true);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double14 = numberAxis13.getFixedAutoRange();
        java.text.NumberFormat numberFormat15 = numberAxis13.getNumberFormatOverride();
        boolean boolean16 = numberAxis13.isVerticalTickLabels();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer17 = null;
        org.jfree.chart.plot.PolarPlot polarPlot18 = new org.jfree.chart.plot.PolarPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) numberAxis13, polarItemRenderer17);
        org.jfree.data.general.PieDataset pieDataset19 = null;
        org.jfree.chart.plot.PiePlot piePlot20 = new org.jfree.chart.plot.PiePlot(pieDataset19);
        org.jfree.chart.util.Rotation rotation21 = piePlot20.getDirection();
        org.jfree.chart.plot.Plot plot22 = piePlot20.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent23 = null;
        piePlot20.datasetChanged(datasetChangeEvent23);
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        piePlot20.drawBackgroundImage(graphics2D25, rectangle2D26);
        java.awt.Paint paint28 = piePlot20.getBaseSectionOutlinePaint();
        java.awt.Paint paint29 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot20.setBaseSectionPaint(paint29);
        polarPlot18.setAngleGridlinePaint(paint29);
        boolean boolean32 = lineAndShapeRenderer0.equals((java.lang.Object) polarPlot18);
        java.awt.Graphics2D graphics2D33 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState35 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo34);
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = null;
        org.jfree.chart.axis.NumberAxis numberAxis40 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double41 = numberAxis40.getFixedAutoRange();
        java.text.NumberFormat numberFormat42 = numberAxis40.getNumberFormatOverride();
        java.awt.Paint paint43 = numberAxis40.getAxisLinePaint();
        java.lang.String str44 = numberAxis40.getLabelToolTip();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit45 = numberAxis40.getTickUnit();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection46 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list47 = taskSeriesCollection46.getRowKeys();
        int int49 = taskSeriesCollection46.indexOf((java.lang.Comparable) "({0}, {1}) = {2}");
        org.jfree.chart.axis.NumberAxis numberAxis51 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double52 = numberAxis51.getFixedAutoRange();
        java.text.NumberFormat numberFormat53 = numberAxis51.getNumberFormatOverride();
        java.awt.Paint paint54 = numberAxis51.getAxisLinePaint();
        java.lang.String str55 = numberAxis51.getLabelToolTip();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit56 = numberAxis51.getTickUnit();
        int int57 = taskSeriesCollection46.indexOf((java.lang.Comparable) numberTickUnit56);
        try {
            lineAndShapeRenderer0.drawItem(graphics2D33, categoryItemRendererState35, rectangle2D36, categoryPlot37, categoryAxis38, (org.jfree.chart.axis.ValueAxis) numberAxis40, (org.jfree.data.category.CategoryDataset) taskSeriesCollection46, 0, (int) '#', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNull(numberFormat15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rotation21);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNull(numberFormat42);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertNotNull(numberTickUnit45);
        org.junit.Assert.assertNotNull(list47);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNull(numberFormat53);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNull(str55);
        org.junit.Assert.assertNotNull(numberTickUnit56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1) + "'", int57 == (-1));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.LegendItem legendItem3 = stackedAreaRenderer0.getLegendItem((int) 'a', 0);
        java.lang.Object obj4 = stackedAreaRenderer0.clone();
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange0, 0.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = rectangleConstraint2.toUnconstrainedHeight();
        org.jfree.data.Range range4 = rectangleConstraint2.getHeightRange();
        org.jfree.data.Range range5 = rectangleConstraint2.getWidthRange();
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.data.time.DateRange dateRange7 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange6);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = rectangleConstraint2.toRangeWidth((org.jfree.data.Range) dateRange7);
        org.jfree.data.Range range9 = rectangleConstraint2.getWidthRange();
        org.junit.Assert.assertNotNull(dateRange0);
        org.junit.Assert.assertNotNull(rectangleConstraint3);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertNotNull(rectangleConstraint8);
        org.junit.Assert.assertNotNull(range9);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.util.Rotation rotation3 = piePlot2.getDirection();
        org.jfree.chart.plot.Plot plot4 = piePlot2.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        piePlot2.datasetChanged(datasetChangeEvent5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        piePlot2.drawBackgroundImage(graphics2D7, rectangle2D8);
        java.awt.Paint paint10 = piePlot2.getBaseSectionOutlinePaint();
        java.awt.Paint paint11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot2.setBaseSectionPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart13.setTitle("({0}, {1}) = {3} - {4}");
        org.jfree.chart.title.TextTitle textTitle16 = jFreeChart13.getTitle();
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment18 = textTitle17.getHorizontalAlignment();
        textTitle17.setExpandToFitSpace(true);
        jFreeChart13.removeSubtitle((org.jfree.chart.title.Title) textTitle17);
        java.awt.Image image22 = jFreeChart13.getBackgroundImage();
        try {
            org.jfree.chart.plot.CategoryPlot categoryPlot23 = jFreeChart13.getCategoryPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PiePlot cannot be cast to org.jfree.chart.plot.CategoryPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(textTitle16);
        org.junit.Assert.assertNotNull(horizontalAlignment18);
        org.junit.Assert.assertNull(image22);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 2, (float) 4);
        barRenderer3D4.setSeriesShape((int) (short) 1, shape8, false);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean13 = numberAxis12.getAutoRangeStickyZero();
        java.awt.Stroke stroke14 = numberAxis12.getAxisLineStroke();
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot(pieDataset15);
        org.jfree.chart.util.Rotation rotation17 = piePlot16.getDirection();
        org.jfree.chart.plot.Plot plot18 = piePlot16.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent19 = null;
        piePlot16.datasetChanged(datasetChangeEvent19);
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        piePlot16.drawBackgroundImage(graphics2D21, rectangle2D22);
        java.awt.Paint paint24 = piePlot16.getBaseSectionOutlinePaint();
        java.awt.Paint paint25 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot16.setBaseSectionPaint(paint25);
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "TextAnchor.CENTER_RIGHT", "ChartEntity: tooltip = ", shape8, stroke14, paint25);
        java.lang.Comparable comparable28 = legendItem27.getSeriesKey();
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(rotation17);
        org.junit.Assert.assertNull(plot18);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(comparable28);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getFixedAutoRange();
        java.awt.Stroke stroke3 = numberAxis1.getTickMarkStroke();
        numberAxis1.setLabelAngle(0.0d);
        numberAxis1.setRangeWithMargins(0.0d, 3.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list1 = taskSeriesCollection0.getRowKeys();
        int int3 = taskSeriesCollection0.indexOf((java.lang.Comparable) "({0}, {1}) = {2}");
        int int4 = taskSeriesCollection0.getSeriesCount();
        try {
            java.lang.Number number7 = taskSeriesCollection0.getPercentComplete((java.lang.Comparable) 0.0d, (java.lang.Comparable) (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getHorizontalAlignment();
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = textTitle2.getHorizontalAlignment();
        java.util.List list12 = null;
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem13 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 1L, (java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.05d, (java.lang.Number) 5, (java.lang.Number) (-1), (java.lang.Number) 100.0d, (java.lang.Number) 0L, list12);
        boolean boolean14 = horizontalAlignment3.equals((java.lang.Object) 1.0f);
        textTitle0.setHorizontalAlignment(horizontalAlignment3);
        double double16 = textTitle0.getContentXOffset();
        java.lang.String str17 = textTitle0.getURLText();
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertNull(str17);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("RectangleEdge.LEFT");
        java.lang.Object obj2 = taskSeries1.clone();
        taskSeries1.removeAll();
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        taskSeries1.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.gantt.Task task7 = taskSeries1.get("");
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNull(task7);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.MINUTE_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 60000L + "'", long0 == 60000L);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = lineAndShapeRenderer2.getBaseToolTipGenerator();
        lineAndShapeRenderer2.setBaseShapesVisible(true);
        org.junit.Assert.assertNull(categoryToolTipGenerator3);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean2 = numberAxis3D1.isInverted();
        numberAxis3D1.setLabelToolTip("VerticalAlignment.TOP");
        try {
            numberAxis3D1.setAutoRangeMinimumSize((double) 0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        int int0 = org.jfree.chart.axis.DateTickUnit.MILLISECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.DefaultKeyedValue defaultKeyedValue2 = new org.jfree.data.DefaultKeyedValue((java.lang.Comparable) 10.0f, (java.lang.Number) 3.0d);
        java.lang.Object obj3 = null;
        boolean boolean4 = defaultKeyedValue2.equals(obj3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = piePlot1.getDirection();
        org.jfree.chart.plot.Plot plot3 = piePlot1.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        piePlot1.datasetChanged(datasetChangeEvent4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        piePlot1.drawBackgroundImage(graphics2D6, rectangle2D7);
        java.awt.Paint paint9 = piePlot1.getBaseSectionOutlinePaint();
        java.awt.Paint paint10 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot1.setBaseSectionPaint(paint10);
        boolean boolean12 = piePlot1.getIgnoreZeroValues();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod((long) 10, (long) 'a');
        java.util.Date date16 = simpleTimePeriod15.getEnd();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date16);
        java.util.Date date18 = month17.getStart();
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double21 = numberAxis20.getFixedAutoRange();
        java.awt.Stroke stroke22 = numberAxis20.getTickMarkStroke();
        piePlot1.setSectionOutlineStroke((java.lang.Comparable) month17, stroke22);
        java.util.Calendar calendar24 = null;
        try {
            long long25 = month17.getFirstMillisecond(calendar24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rotation2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        int int1 = keyedObjects0.getItemCount();
        java.lang.Object obj2 = keyedObjects0.clone();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Paint paint2 = lineAndShapeRenderer0.getSeriesItemLabelPaint((int) (byte) -1);
        org.junit.Assert.assertNull(paint2);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis2.zoomRange((double) 1.0f, (double) (byte) 10);
        boolean boolean6 = numberAxis2.isPositiveArrowVisible();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator11 = null;
        piePlot10.setToolTipGenerator(pieToolTipGenerator11);
        numberAxis3D8.setPlot((org.jfree.chart.plot.Plot) piePlot10);
        org.jfree.chart.block.ColumnArrangement columnArrangement14 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle();
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot(pieDataset16);
        org.jfree.chart.util.Rotation rotation18 = piePlot17.getDirection();
        org.jfree.chart.plot.Plot plot19 = piePlot17.getParent();
        org.jfree.chart.plot.Plot plot20 = piePlot17.getRootPlot();
        java.awt.Color color21 = java.awt.Color.MAGENTA;
        piePlot17.setOutlinePaint((java.awt.Paint) color21);
        columnArrangement14.add((org.jfree.chart.block.Block) textTitle15, (java.lang.Object) color21);
        piePlot10.setBackgroundPaint((java.awt.Paint) color21);
        org.jfree.data.general.PieDataset pieDataset26 = null;
        org.jfree.chart.plot.PiePlot piePlot27 = new org.jfree.chart.plot.PiePlot(pieDataset26);
        org.jfree.chart.util.Rotation rotation28 = piePlot27.getDirection();
        org.jfree.chart.plot.Plot plot29 = piePlot27.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent30 = null;
        piePlot27.datasetChanged(datasetChangeEvent30);
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        piePlot27.drawBackgroundImage(graphics2D32, rectangle2D33);
        java.awt.Paint paint35 = piePlot27.getBaseSectionOutlinePaint();
        java.awt.Paint paint36 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot27.setBaseSectionPaint(paint36);
        org.jfree.chart.JFreeChart jFreeChart38 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot27);
        jFreeChart38.setTitle("({0}, {1}) = {3} - {4}");
        org.jfree.chart.title.TextTitle textTitle41 = jFreeChart38.getTitle();
        java.awt.Stroke stroke42 = jFreeChart38.getBorderStroke();
        piePlot10.setBaseSectionOutlineStroke(stroke42);
        boolean boolean44 = piePlot10.isSubplot();
        boolean boolean45 = numberAxis2.hasListener((java.util.EventListener) piePlot10);
        java.awt.Font font46 = piePlot10.getNoDataMessageFont();
        java.awt.Color color47 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.lang.String str49 = rectangleEdge48.toString();
        org.jfree.chart.axis.NumberAxis numberAxis52 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str53 = numberAxis52.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange54 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint56 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange54, 0.0d);
        org.jfree.data.Range range58 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange54, (double) '#');
        numberAxis52.setDefaultAutoRange((org.jfree.data.Range) dateRange54);
        boolean boolean60 = numberAxis52.isNegativeArrowVisible();
        boolean boolean61 = numberAxis52.isTickMarksVisible();
        java.lang.Object obj62 = numberAxis52.clone();
        java.awt.Font font67 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand68 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis52, (double) 11, 0.0d, (double) 'a', (double) 100, font67);
        java.awt.Paint paint69 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.text.TextBlock textBlock70 = org.jfree.chart.text.TextUtilities.createTextBlock("NO_CHANGE", font67, paint69);
        org.jfree.chart.title.TextTitle textTitle71 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment72 = textTitle71.getHorizontalAlignment();
        java.util.List list81 = null;
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem82 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 1L, (java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.05d, (java.lang.Number) 5, (java.lang.Number) (-1), (java.lang.Number) 100.0d, (java.lang.Number) 0L, list81);
        boolean boolean83 = horizontalAlignment72.equals((java.lang.Object) 1.0f);
        textBlock70.setLineAlignment(horizontalAlignment72);
        org.jfree.chart.util.VerticalAlignment verticalAlignment85 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets86 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double88 = rectangleInsets86.calculateTopInset(0.0d);
        try {
            org.jfree.chart.title.TextTitle textTitle89 = new org.jfree.chart.title.TextTitle(" version ({0}, {1}) = {3} - {4}.\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n({0}, {1}) = {3} - {4}", font46, (java.awt.Paint) color47, rectangleEdge48, horizontalAlignment72, verticalAlignment85, rectangleInsets86);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'verticalAlignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rotation18);
        org.junit.Assert.assertNull(plot19);
        org.junit.Assert.assertNotNull(plot20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(rotation28);
        org.junit.Assert.assertNull(plot29);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(textTitle41);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(font46);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(rectangleEdge48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "RectangleEdge.LEFT" + "'", str49.equals("RectangleEdge.LEFT"));
        org.junit.Assert.assertNull(str53);
        org.junit.Assert.assertNotNull(dateRange54);
        org.junit.Assert.assertNotNull(range58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(obj62);
        org.junit.Assert.assertNotNull(font67);
        org.junit.Assert.assertNotNull(paint69);
        org.junit.Assert.assertNotNull(textBlock70);
        org.junit.Assert.assertNotNull(horizontalAlignment72);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(rectangleInsets86);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 4.0d + "'", double88 == 4.0d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        barRenderer4.setBaseToolTipGenerator(categoryToolTipGenerator5, false);
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        org.jfree.chart.util.Rotation rotation11 = piePlot10.getDirection();
        org.jfree.chart.plot.Plot plot12 = piePlot10.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent13 = null;
        piePlot10.datasetChanged(datasetChangeEvent13);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        piePlot10.drawBackgroundImage(graphics2D15, rectangle2D16);
        java.awt.Paint paint18 = piePlot10.getBaseSectionOutlinePaint();
        java.awt.Paint paint19 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot10.setBaseSectionPaint(paint19);
        barRenderer4.setSeriesItemLabelPaint((int) (byte) 0, paint19);
        java.awt.Paint paint23 = barRenderer4.lookupSeriesPaint(0);
        org.jfree.chart.block.BlockBorder blockBorder24 = new org.jfree.chart.block.BlockBorder((double) 100.0f, (double) 100.0f, (double) 'a', 0.0d, paint23);
        org.jfree.data.KeyToGroupMap keyToGroupMap26 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) true);
        java.lang.Object obj27 = keyToGroupMap26.clone();
        boolean boolean28 = blockBorder24.equals((java.lang.Object) keyToGroupMap26);
        org.junit.Assert.assertNotNull(rotation11);
        org.junit.Assert.assertNull(plot12);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.calculateTopInset(0.0d);
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            rectangleInsets0.trim(rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        java.lang.Comparable comparable0 = null;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.util.Rotation rotation3 = piePlot2.getDirection();
        org.jfree.chart.plot.Plot plot4 = piePlot2.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        piePlot2.datasetChanged(datasetChangeEvent5);
        java.awt.Stroke stroke7 = null;
        piePlot2.setLabelOutlineStroke(stroke7);
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray20 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray30 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray35 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray40 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[][] numberArray41 = new java.lang.Number[][] { numberArray15, numberArray20, numberArray25, numberArray30, numberArray35, numberArray40 };
        org.jfree.data.category.CategoryDataset categoryDataset42 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray41);
        org.jfree.data.general.PieDataset pieDataset44 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset42, (int) (short) 1);
        piePlot2.setDataset(pieDataset44);
        org.jfree.data.general.PieDataset pieDataset49 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset44, (java.lang.Comparable) "", 90.0d, (int) (byte) 1);
        double double50 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset44);
        try {
            org.jfree.data.category.CategoryDataset categoryDataset51 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparable0, (org.jfree.data.KeyedValues) pieDataset44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowKey' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(numberArray41);
        org.junit.Assert.assertNotNull(categoryDataset42);
        org.junit.Assert.assertNotNull(pieDataset44);
        org.junit.Assert.assertNotNull(pieDataset49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateBottomOutset((double) (-1L));
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.TOP;
        boolean boolean4 = rectangleInsets0.equals((java.lang.Object) rectangleAnchor3);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor5 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        boolean boolean8 = textAnchor6.equals((java.lang.Object) 'a');
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType10 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition12 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor3, textBlockAnchor5, textAnchor6, (double) (-2208960000000L), categoryLabelWidthType10, (float) 3);
        org.jfree.chart.text.TextAnchor textAnchor13 = categoryLabelPosition12.getRotationAnchor();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor5);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(categoryLabelWidthType10);
        org.junit.Assert.assertNotNull(textAnchor13);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        java.lang.Number number1 = null;
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection8 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list9 = taskSeriesCollection8.getRowKeys();
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem10 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 0.2d, number1, (java.lang.Number) (-2208960000000L), (java.lang.Number) 100.0f, (java.lang.Number) 2.0f, (java.lang.Number) 1.0d, (java.lang.Number) 10, (java.lang.Number) 10.0d, list9);
        java.lang.String str11 = boxAndWhiskerItem10.toString();
        org.junit.Assert.assertNotNull(list9);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        java.awt.Image image6 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo10 = new org.jfree.chart.ui.ProjectInfo("", "({0}, {1}) = {3} - {4}", "", image6, "hi!", "hi!", "({0}, {1}) = {3} - {4}");
        java.lang.String str11 = projectInfo10.getLicenceText();
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        org.jfree.chart.util.Rotation rotation15 = piePlot14.getDirection();
        org.jfree.chart.plot.Plot plot16 = piePlot14.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent17 = null;
        piePlot14.datasetChanged(datasetChangeEvent17);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        piePlot14.drawBackgroundImage(graphics2D19, rectangle2D20);
        java.awt.Paint paint22 = piePlot14.getBaseSectionOutlinePaint();
        java.awt.Paint paint23 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot14.setBaseSectionPaint(paint23);
        org.jfree.chart.JFreeChart jFreeChart25 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot14);
        jFreeChart25.setTitle("({0}, {1}) = {3} - {4}");
        java.lang.Object obj28 = jFreeChart25.clone();
        jFreeChart25.fireChartChanged();
        jFreeChart25.setNotify(false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo35 = null;
        java.awt.image.BufferedImage bufferedImage36 = jFreeChart25.createBufferedImage((int) (byte) 10, 100, 12, chartRenderingInfo35);
        projectInfo10.setLogo((java.awt.Image) bufferedImage36);
        org.jfree.chart.ui.ProjectInfo projectInfo41 = new org.jfree.chart.ui.ProjectInfo("http://www.jfree.org/jfreechart/index.html", "black", "TextAnchor.CENTER_RIGHT", (java.awt.Image) bufferedImage36, "({0}, {1}) = {2}", "hi!", "AxisLocation.TOP_OR_LEFT");
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "({0}, {1}) = {3} - {4}" + "'", str11.equals("({0}, {1}) = {3} - {4}"));
        org.junit.Assert.assertNotNull(rotation15);
        org.junit.Assert.assertNull(plot16);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertNotNull(bufferedImage36);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("ChartChangeEventType.GENERAL");
        double double2 = categoryAxis3D1.getUpperMargin();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.util.Size2D size2D7 = new org.jfree.chart.util.Size2D((double) 0.0f, (double) 1L);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Rectangle2D rectangle2D11 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D7, (double) (byte) 100, (double) 10, rectangleAnchor10);
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        try {
            org.jfree.chart.axis.AxisState axisState15 = categoryAxis3D1.draw(graphics2D3, (double) (byte) 0, rectangle2D11, rectangle2D12, rectangleEdge13, plotRenderingInfo14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertNotNull(rectangleEdge13);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = new org.jfree.chart.axis.CategoryLabelPositions();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double3 = rectangleInsets1.calculateBottomOutset((double) (-1L));
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = org.jfree.chart.util.RectangleAnchor.TOP;
        boolean boolean5 = rectangleInsets1.equals((java.lang.Object) rectangleAnchor4);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor6 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        boolean boolean9 = textAnchor7.equals((java.lang.Object) 'a');
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType11 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition13 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor4, textBlockAnchor6, textAnchor7, (double) (-2208960000000L), categoryLabelWidthType11, (float) 3);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor14 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.text.TextAnchor textAnchor19 = null;
        org.jfree.chart.text.TextAnchor textAnchor21 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        java.awt.Shape shape22 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D16, (float) 1, (float) 0, textAnchor19, (double) 100L, textAnchor21);
        java.lang.String str23 = textAnchor21.toString();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType25 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition27 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor4, textBlockAnchor14, textAnchor21, 0.0d, categoryLabelWidthType25, (float) (short) 100);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor28 = categoryLabelPosition27.getLabelAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions29 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(categoryLabelPositions0, categoryLabelPosition27);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor6);
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(categoryLabelWidthType11);
        org.junit.Assert.assertNotNull(textBlockAnchor14);
        org.junit.Assert.assertNotNull(textAnchor21);
        org.junit.Assert.assertNull(shape22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "TextAnchor.CENTER_RIGHT" + "'", str23.equals("TextAnchor.CENTER_RIGHT"));
        org.junit.Assert.assertNotNull(categoryLabelWidthType25);
        org.junit.Assert.assertNotNull(textBlockAnchor28);
        org.junit.Assert.assertNotNull(categoryLabelPositions29);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        java.awt.Paint paint1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        barRenderer2.setBaseToolTipGenerator(categoryToolTipGenerator3, false);
        boolean boolean6 = barRenderer2.getBaseCreateEntities();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        barRenderer2.setSeriesStroke((int) (short) 100, stroke8, false);
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker(0.0d, paint1, stroke8);
        java.awt.Paint paint12 = valueMarker11.getPaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = valueMarker11.getLabelAnchor();
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle();
        textTitle16.setNotify(false);
        java.lang.Class<?> wildcardClass19 = textTitle16.getClass();
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle();
        textTitle20.setNotify(false);
        java.lang.Class<?> wildcardClass23 = textTitle20.getClass();
        java.lang.Object obj24 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("VerticalAlignment.TOP", (java.lang.Class) wildcardClass19, (java.lang.Class) wildcardClass23);
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle();
        textTitle26.setNotify(false);
        java.lang.Class<?> wildcardClass29 = textTitle26.getClass();
        org.jfree.chart.title.TextTitle textTitle30 = new org.jfree.chart.title.TextTitle();
        textTitle30.setNotify(false);
        java.lang.Class<?> wildcardClass33 = textTitle30.getClass();
        java.lang.Object obj34 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("VerticalAlignment.TOP", (java.lang.Class) wildcardClass29, (java.lang.Class) wildcardClass33);
        java.lang.Object obj35 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ChartChangeEventType.GENERAL", (java.lang.Class) wildcardClass19, (java.lang.Class) wildcardClass29);
        try {
            java.util.EventListener[] eventListenerArray36 = valueMarker11.getListeners((java.lang.Class) wildcardClass29);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: [Lorg.jfree.chart.title.TextTitle; cannot be cast to [Ljava.util.EventListener;");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNull(obj24);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertNull(obj34);
        org.junit.Assert.assertNull(obj35);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        int int1 = defaultStatisticalCategoryDataset0.getColumnCount();
        java.lang.Comparable comparable2 = null;
        int int3 = defaultStatisticalCategoryDataset0.getRowIndex(comparable2);
        java.lang.Number number6 = defaultStatisticalCategoryDataset0.getValue((java.lang.Comparable) 0, (java.lang.Comparable) 3.0d);
        try {
            java.lang.Comparable comparable8 = defaultStatisticalCategoryDataset0.getColumnKey(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNull(number6);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        java.awt.Paint paint1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        barRenderer2.setBaseToolTipGenerator(categoryToolTipGenerator3, false);
        boolean boolean6 = barRenderer2.getBaseCreateEntities();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        barRenderer2.setSeriesStroke((int) (short) 100, stroke8, false);
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker(0.0d, paint1, stroke8);
        java.awt.Paint paint12 = valueMarker11.getPaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = valueMarker11.getLabelAnchor();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double16 = numberAxis15.getFixedAutoRange();
        java.text.NumberFormat numberFormat17 = numberAxis15.getNumberFormatOverride();
        java.awt.Paint paint18 = numberAxis15.getAxisLinePaint();
        valueMarker11.setOutlinePaint(paint18);
        valueMarker11.setLabel("TextAnchor.CENTER_RIGHT");
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = valueMarker11.getLabelOffset();
        org.jfree.chart.text.TextAnchor textAnchor23 = null;
        try {
            valueMarker11.setLabelTextAnchor(textAnchor23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'anchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNull(numberFormat17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(rectangleInsets22);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, 0.0d);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange4, (double) '#');
        numberAxis2.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        boolean boolean10 = numberAxis2.isNegativeArrowVisible();
        boolean boolean11 = numberAxis2.isTickMarksVisible();
        java.lang.Object obj12 = numberAxis2.clone();
        java.awt.Font font17 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand18 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis2, (double) 11, 0.0d, (double) 'a', (double) 100, font17);
        java.awt.Paint paint19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.text.TextBlock textBlock20 = org.jfree.chart.text.TextUtilities.createTextBlock("NO_CHANGE", font17, paint19);
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment22 = textTitle21.getHorizontalAlignment();
        java.util.List list31 = null;
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem32 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 1L, (java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.05d, (java.lang.Number) 5, (java.lang.Number) (-1), (java.lang.Number) 100.0d, (java.lang.Number) 0L, list31);
        boolean boolean33 = horizontalAlignment22.equals((java.lang.Object) 1.0f);
        textBlock20.setLineAlignment(horizontalAlignment22);
        org.jfree.chart.text.TextLine textLine36 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.text.TextFragment textFragment37 = textLine36.getFirstTextFragment();
        textBlock20.addLine(textLine36);
        org.jfree.data.KeyedObjects keyedObjects39 = new org.jfree.data.KeyedObjects();
        int int40 = keyedObjects39.getItemCount();
        boolean boolean41 = textBlock20.equals((java.lang.Object) int40);
        java.awt.Graphics2D graphics2D42 = null;
        try {
            org.jfree.chart.util.Size2D size2D43 = textBlock20.calculateDimensions(graphics2D42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(textBlock20);
        org.junit.Assert.assertNotNull(horizontalAlignment22);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(textFragment37);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = barRenderer0.getBaseToolTipGenerator();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = null;
        barRenderer0.setSeriesURLGenerator(0, categoryURLGenerator3, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = barRenderer0.getSeriesPositiveItemLabelPosition(0);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = null;
        barRenderer0.setSeriesURLGenerator(3, categoryURLGenerator9, true);
        org.junit.Assert.assertNull(categoryToolTipGenerator1);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.BAR_OUTLINE_WIDTH_THRESHOLD;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.0d + "'", double0 == 3.0d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setMaximumBarWidth(8.0d);
        java.awt.Shape shape9 = null;
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape16 = null;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color18 = java.awt.Color.black;
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("", "hi!", "hi!", "", true, shape9, false, (java.awt.Paint) color11, false, paint13, stroke14, true, shape16, stroke17, (java.awt.Paint) color18);
        barRenderer0.setSeriesStroke(2, stroke17);
        double double21 = barRenderer0.getItemLabelAnchorOffset();
        barRenderer0.setBaseSeriesVisible(false, false);
        java.awt.Paint paint27 = barRenderer0.getItemLabelPaint(5, 10);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator29 = barRenderer0.getSeriesItemLabelGenerator(11);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 2.0d + "'", double21 == 2.0d);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNull(categoryItemLabelGenerator29);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        double double1 = lineRenderer3D0.getYOffset();
        lineRenderer3D0.setXOffset((double) 4);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.0d + "'", double1 == 8.0d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.axis.NumberAxis numberAxis0 = null;
        java.awt.Font font5 = null;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis0, (double) 10, (double) 100, (double) '4', (double) (byte) -1, font5);
        java.awt.Graphics2D graphics2D7 = null;
        double double8 = markerAxisBand6.getHeight(graphics2D7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.zoomRange(0.0d, 10.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis0.setTickMarkPosition(dateTickMarkPosition4);
        java.lang.Object obj6 = dateAxis0.clone();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.util.Size2D size2D11 = new org.jfree.chart.util.Size2D((double) 0.0f, (double) 1L);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Rectangle2D rectangle2D15 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D11, (double) (byte) 100, (double) 10, rectangleAnchor14);
        org.jfree.chart.util.Size2D size2D18 = new org.jfree.chart.util.Size2D((double) 0.0f, (double) 1L);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Rectangle2D rectangle2D22 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D18, (double) (byte) 100, (double) 10, rectangleAnchor21);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = org.jfree.chart.util.RectangleEdge.TOP;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        try {
            org.jfree.chart.axis.AxisState axisState25 = dateAxis0.draw(graphics2D7, (double) (byte) 10, rectangle2D15, rectangle2D22, rectangleEdge23, plotRenderingInfo24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(rectangleEdge23);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray32);
        java.lang.String[] strArray36 = new java.lang.String[] { "SerialDate.weekInMonthToString(): invalid code.", "VerticalAlignment.TOP" };
        java.lang.Number[] numberArray44 = new java.lang.Number[] { (short) 1, 100.0f, 2, (short) -1, (-1.0f) };
        java.lang.Number[] numberArray50 = new java.lang.Number[] { (short) 1, 100.0f, 2, (short) -1, (-1.0f) };
        java.lang.Number[][] numberArray51 = new java.lang.Number[][] { numberArray44, numberArray50 };
        org.jfree.data.category.CategoryDataset categoryDataset52 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray51);
        java.lang.Number[][] numberArray53 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset54 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray36, numberArray51, numberArray53);
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset55 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray32, numberArray53);
        java.util.List list56 = defaultIntervalCategoryDataset55.getRowKeys();
        try {
            int int57 = defaultIntervalCategoryDataset55.getColumnCount();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(strArray36);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(categoryDataset52);
        org.junit.Assert.assertNotNull(list56);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 3, 0.0d, (double) 0.5f, (double) 100.0f);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D7 = rectangleInsets5.createOutsetRectangle(rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.zoomRange(0.0d, 10.0d);
        java.util.Date date4 = dateAxis0.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        dateAxis6.zoomRange(0.0d, 10.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = dateAxis6.getTickUnit();
        dateAxis5.setTickUnit(dateTickUnit10, false, true);
        dateAxis0.setTickUnit(dateTickUnit10, true, true);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        dateAxis17.zoomRange(0.0d, 10.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit21 = dateAxis17.getTickUnit();
        java.text.DateFormat dateFormat24 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit25 = new org.jfree.chart.axis.DateTickUnit(0, 0, dateFormat24);
        dateAxis17.setTickUnit(dateTickUnit25);
        try {
            java.util.Date date27 = dateAxis0.calculateHighestVisibleTickValue(dateTickUnit25);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(dateTickUnit10);
        org.junit.Assert.assertNotNull(dateTickUnit21);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = piePlot1.getDirection();
        org.jfree.chart.plot.Plot plot3 = piePlot1.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        piePlot1.datasetChanged(datasetChangeEvent4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        piePlot1.drawBackgroundImage(graphics2D6, rectangle2D7);
        java.awt.Paint paint9 = piePlot1.getBaseSectionOutlinePaint();
        java.awt.Paint paint10 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot1.setBaseSectionPaint(paint10);
        java.awt.Color color12 = java.awt.Color.red;
        piePlot1.setNoDataMessagePaint((java.awt.Paint) color12);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        org.jfree.chart.util.Rotation rotation16 = piePlot15.getDirection();
        org.jfree.chart.plot.Plot plot17 = piePlot15.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent18 = null;
        piePlot15.datasetChanged(datasetChangeEvent18);
        java.awt.Stroke stroke21 = piePlot15.getSectionOutlineStroke((java.lang.Comparable) (short) 100);
        java.awt.Paint paint22 = piePlot15.getNoDataMessagePaint();
        piePlot1.setLabelBackgroundPaint(paint22);
        java.lang.Object obj24 = piePlot1.clone();
        org.junit.Assert.assertNotNull(rotation2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(rotation16);
        org.junit.Assert.assertNull(plot17);
        org.junit.Assert.assertNull(stroke21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(obj24);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = piePlot1.getDirection();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator3 = piePlot1.getURLGenerator();
        piePlot1.setMaximumLabelWidth((double) (short) 100);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        piePlot1.axisChanged(axisChangeEvent6);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator8 = piePlot1.getToolTipGenerator();
        org.junit.Assert.assertNotNull(rotation2);
        org.junit.Assert.assertNull(pieURLGenerator3);
        org.junit.Assert.assertNull(pieToolTipGenerator8);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.LegendItem legendItem3 = stackedAreaRenderer0.getLegendItem((int) 'a', 0);
        boolean boolean5 = stackedAreaRenderer0.equals((java.lang.Object) 23640L);
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.util.Rotation rotation3 = piePlot2.getDirection();
        org.jfree.chart.plot.Plot plot4 = piePlot2.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        piePlot2.datasetChanged(datasetChangeEvent5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        piePlot2.drawBackgroundImage(graphics2D7, rectangle2D8);
        java.awt.Paint paint10 = piePlot2.getBaseSectionOutlinePaint();
        java.awt.Paint paint11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot2.setBaseSectionPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart13.setTitle("({0}, {1}) = {3} - {4}");
        org.jfree.chart.title.TextTitle textTitle16 = jFreeChart13.getTitle();
        textTitle16.setToolTipText("");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment19 = textTitle16.getTextAlignment();
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(textTitle16);
        org.junit.Assert.assertNotNull(horizontalAlignment19);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 2, (float) 4);
        barRenderer3D0.setSeriesShape((int) (short) 1, shape4, false);
        double double7 = barRenderer3D0.getItemLabelAnchorOffset();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        barRenderer3D0.setBaseFillPaint((java.awt.Paint) color8);
        barRenderer3D0.setItemLabelAnchorOffset((double) '4');
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = piePlot1.getDirection();
        org.jfree.chart.plot.Plot plot3 = piePlot1.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        piePlot1.datasetChanged(datasetChangeEvent4);
        java.awt.Stroke stroke6 = null;
        piePlot1.setLabelOutlineStroke(stroke6);
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray34 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[][] numberArray40 = new java.lang.Number[][] { numberArray14, numberArray19, numberArray24, numberArray29, numberArray34, numberArray39 };
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray40);
        org.jfree.data.general.PieDataset pieDataset43 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset41, (int) (short) 1);
        piePlot1.setDataset(pieDataset43);
        org.jfree.data.general.PieDataset pieDataset48 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset43, (java.lang.Comparable) "", 90.0d, (int) (byte) 1);
        double double49 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset43);
        org.jfree.chart.plot.PiePlot piePlot50 = new org.jfree.chart.plot.PiePlot(pieDataset43);
        java.awt.Paint paint51 = piePlot50.getBaseSectionPaint();
        int int52 = piePlot50.getPieIndex();
        org.junit.Assert.assertNotNull(rotation2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(pieDataset43);
        org.junit.Assert.assertNotNull(pieDataset48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getFixedAutoRange();
        java.text.NumberFormat numberFormat4 = numberAxis2.getNumberFormatOverride();
        boolean boolean5 = numberAxis2.isVerticalTickLabels();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, polarItemRenderer6);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer8 = polarPlot7.getRenderer();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNull(numberFormat4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(polarItemRenderer8);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        java.lang.Object obj1 = null;
        boolean boolean2 = axisLocation0.equals(obj1);
        java.awt.Color color3 = java.awt.Color.CYAN;
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder4 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        boolean boolean5 = color3.equals((java.lang.Object) datasetRenderingOrder4);
        boolean boolean6 = axisLocation0.equals((java.lang.Object) boolean5);
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation7);
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(datasetRenderingOrder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(plotOrientation7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setSeriesCreateEntities((int) (short) 1, (java.lang.Boolean) false, false);
        boolean boolean6 = lineRenderer3D0.equals((java.lang.Object) false);
        lineRenderer3D0.setBaseSeriesVisibleInLegend(true, false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.data.time.DateRange dateRange1 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange1, 0.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint3.toUnconstrainedHeight();
        org.jfree.data.time.DateRange dateRange5 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange5, 0.0d);
        org.jfree.data.Range range9 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange5, (double) '#');
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = rectangleConstraint3.toRangeWidth(range9);
        org.jfree.data.Range range11 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range12 = org.jfree.data.Range.combine(range9, range11);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint(0.0d, range12);
        org.jfree.data.time.DateRange dateRange14 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange14, 0.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = rectangleConstraint16.toUnconstrainedHeight();
        org.jfree.data.time.DateRange dateRange18 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange18, 0.0d);
        org.jfree.data.Range range22 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange18, (double) '#');
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = rectangleConstraint16.toRangeWidth(range22);
        org.jfree.data.Range range24 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range25 = org.jfree.data.Range.combine(range22, range24);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = rectangleConstraint13.toRangeHeight(range25);
        org.junit.Assert.assertNotNull(dateRange1);
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertNotNull(dateRange5);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(rectangleConstraint10);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(dateRange14);
        org.junit.Assert.assertNotNull(rectangleConstraint17);
        org.junit.Assert.assertNotNull(dateRange18);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(rectangleConstraint23);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNotNull(rectangleConstraint26);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        java.awt.Font font1 = null;
        try {
            org.jfree.chart.text.TextLine textLine2 = new org.jfree.chart.text.TextLine("({0}, {1}) = {2}", font1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = piePlot1.getDirection();
        org.jfree.chart.plot.Plot plot3 = piePlot1.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        piePlot1.datasetChanged(datasetChangeEvent4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        piePlot1.drawBackgroundImage(graphics2D6, rectangle2D7);
        boolean boolean9 = piePlot1.getSectionOutlinesVisible();
        java.awt.Paint paint10 = piePlot1.getLabelPaint();
        double double11 = piePlot1.getShadowYOffset();
        org.junit.Assert.assertNotNull(rotation2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.ShapeList shapeList2 = new org.jfree.chart.util.ShapeList();
        java.lang.Object obj3 = shapeList2.clone();
        java.lang.Object obj4 = null;
        boolean boolean5 = shapeList2.equals(obj4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, 0.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = rectangleConstraint8.toUnconstrainedHeight();
        org.jfree.data.Range range10 = rectangleConstraint8.getHeightRange();
        org.jfree.data.Range range11 = rectangleConstraint8.getWidthRange();
        boolean boolean12 = shapeList2.equals((java.lang.Object) rectangleConstraint8);
        try {
            org.jfree.chart.util.Size2D size2D13 = blockContainer0.arrange(graphics2D1, rectangleConstraint8);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertNotNull(rectangleConstraint9);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator2 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("UnitType.ABSOLUTE", numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.zoomRange(0.0d, 10.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis0.getTickUnit();
        java.text.DateFormat dateFormat7 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = new org.jfree.chart.axis.DateTickUnit(0, 0, dateFormat7);
        dateAxis0.setTickUnit(dateTickUnit8);
        java.util.Date date10 = null;
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone11;
        try {
            java.util.Date date13 = dateTickUnit8.addToDate(date10, timeZone11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(timeZone11);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) (short) 100, (double) (short) 0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator1, false);
        boolean boolean4 = barRenderer0.getBaseCreateEntities();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        barRenderer0.setSeriesStroke((int) (short) 100, stroke6, false);
        java.awt.Font font11 = barRenderer0.getItemLabelFont(100, (int) (byte) 0);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer13 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        minMaxCategoryRenderer13.setBaseCreateEntities(false, true);
        org.jfree.data.general.PieDataset pieDataset18 = null;
        org.jfree.chart.plot.PiePlot piePlot19 = new org.jfree.chart.plot.PiePlot(pieDataset18);
        org.jfree.chart.util.Rotation rotation20 = piePlot19.getDirection();
        org.jfree.chart.plot.Plot plot21 = piePlot19.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent22 = null;
        piePlot19.datasetChanged(datasetChangeEvent22);
        java.awt.Graphics2D graphics2D24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        piePlot19.drawBackgroundImage(graphics2D24, rectangle2D25);
        java.awt.Paint paint27 = piePlot19.getBaseSectionOutlinePaint();
        java.awt.Paint paint28 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot19.setBaseSectionPaint(paint28);
        org.jfree.chart.JFreeChart jFreeChart30 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot19);
        jFreeChart30.setTitle("({0}, {1}) = {3} - {4}");
        org.jfree.chart.title.TextTitle textTitle33 = jFreeChart30.getTitle();
        java.awt.Stroke stroke34 = jFreeChart30.getBorderStroke();
        jFreeChart30.setAntiAlias(true);
        org.jfree.chart.ui.Library library41 = new org.jfree.chart.ui.Library("hi!", "hi!", "hi!", "");
        java.awt.Paint paint42 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        boolean boolean43 = library41.equals((java.lang.Object) paint42);
        jFreeChart30.setBorderPaint(paint42);
        minMaxCategoryRenderer13.setGroupPaint(paint42);
        try {
            barRenderer0.setSeriesItemLabelPaint((int) (short) -1, paint42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(rotation20);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(textTitle33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getUpperMargin();
        double double3 = numberAxis1.getFixedDimension();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange3, 0.0d);
        org.jfree.data.Range range7 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange3, (double) '#');
        numberAxis1.setDefaultAutoRange((org.jfree.data.Range) dateRange3);
        boolean boolean9 = numberAxis1.isNegativeArrowVisible();
        boolean boolean10 = numberAxis1.isTickMarksVisible();
        org.jfree.chart.plot.Plot plot11 = null;
        numberAxis1.setPlot(plot11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        org.jfree.chart.util.Rotation rotation15 = piePlot14.getDirection();
        org.jfree.chart.plot.Plot plot16 = piePlot14.getParent();
        org.jfree.chart.plot.Plot plot17 = piePlot14.getRootPlot();
        java.awt.Color color18 = java.awt.Color.MAGENTA;
        piePlot14.setOutlinePaint((java.awt.Paint) color18);
        int int20 = piePlot14.getBackgroundImageAlignment();
        java.awt.Paint paint21 = piePlot14.getOutlinePaint();
        boolean boolean22 = numberAxis1.hasListener((java.util.EventListener) piePlot14);
        java.awt.Paint paint23 = numberAxis1.getAxisLinePaint();
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 2, (float) 4);
        org.jfree.chart.entity.ChartEntity chartEntity28 = new org.jfree.chart.entity.ChartEntity(shape26, "");
        numberAxis1.setRightArrow(shape26);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(dateRange3);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(rotation15);
        org.junit.Assert.assertNull(plot16);
        org.junit.Assert.assertNotNull(plot17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 15 + "'", int20 == 15);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(shape26);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 2, (float) 4);
        barRenderer3D0.setSeriesShape((int) (short) 1, shape4, false);
        double double7 = barRenderer3D0.getItemLabelAnchorOffset();
        boolean boolean9 = barRenderer3D0.isSeriesVisible(10);
        java.awt.Shape shape11 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity14 = new org.jfree.chart.entity.TickLabelEntity(shape11, "", "hi!");
        barRenderer3D0.setSeriesShape((int) (short) 0, shape11);
        org.jfree.chart.renderer.category.BarRenderer barRenderer17 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator18 = null;
        barRenderer17.setBaseToolTipGenerator(categoryToolTipGenerator18, false);
        org.jfree.data.general.PieDataset pieDataset22 = null;
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot(pieDataset22);
        org.jfree.chart.util.Rotation rotation24 = piePlot23.getDirection();
        org.jfree.chart.plot.Plot plot25 = piePlot23.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent26 = null;
        piePlot23.datasetChanged(datasetChangeEvent26);
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        piePlot23.drawBackgroundImage(graphics2D28, rectangle2D29);
        java.awt.Paint paint31 = piePlot23.getBaseSectionOutlinePaint();
        java.awt.Paint paint32 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot23.setBaseSectionPaint(paint32);
        barRenderer17.setSeriesItemLabelPaint((int) (byte) 0, paint32);
        boolean boolean35 = barRenderer17.getAutoPopulateSeriesShape();
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator37 = new org.jfree.chart.urls.StandardCategoryURLGenerator("RectangleEdge.LEFT");
        barRenderer17.setBaseURLGenerator((org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator37);
        try {
            barRenderer3D0.setSeriesURLGenerator((int) (byte) -1, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(rotation24);
        org.junit.Assert.assertNull(plot25);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, 0.0d);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange4, (double) '#');
        numberAxis2.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        boolean boolean10 = numberAxis2.isNegativeArrowVisible();
        boolean boolean11 = numberAxis2.isTickMarksVisible();
        java.lang.String str12 = numberAxis2.getLabel();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean15 = numberAxis3D14.isInverted();
        org.jfree.data.time.DateRange dateRange16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis3D14.setRangeWithMargins((org.jfree.data.Range) dateRange16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, xYItemRenderer18);
        java.awt.Paint paint20 = xYPlot19.getDomainGridlinePaint();
        xYPlot19.setRangeCrosshairVisible(true);
        xYPlot19.setRangeCrosshairValue((double) (byte) -1);
        org.jfree.data.xy.XYDataset xYDataset25 = xYPlot19.getDataset();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateRange16);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNull(xYDataset25);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.getAutoRangeStickyZero();
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        numberAxis1.setTickMarkStroke(stroke3);
        numberAxis1.setTickMarkInsideLength(0.0f);
        boolean boolean7 = numberAxis1.isNegativeArrowVisible();
        double double8 = numberAxis1.getFixedDimension();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(true);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, 0.0d);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange4, (double) '#');
        numberAxis2.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        boolean boolean10 = numberAxis2.isNegativeArrowVisible();
        boolean boolean11 = numberAxis2.isTickMarksVisible();
        java.lang.String str12 = numberAxis2.getLabel();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean15 = numberAxis3D14.isInverted();
        org.jfree.data.time.DateRange dateRange16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis3D14.setRangeWithMargins((org.jfree.data.Range) dateRange16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, xYItemRenderer18);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str23 = numberAxis22.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange24 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange24, 0.0d);
        org.jfree.data.Range range28 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange24, (double) '#');
        numberAxis22.setDefaultAutoRange((org.jfree.data.Range) dateRange24);
        boolean boolean30 = numberAxis22.isNegativeArrowVisible();
        boolean boolean31 = numberAxis22.isTickMarksVisible();
        numberAxis22.setFixedAutoRange((double) 1);
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str36 = numberAxis35.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange37 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint39 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange37, 0.0d);
        org.jfree.data.Range range41 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange37, (double) '#');
        numberAxis35.setDefaultAutoRange((org.jfree.data.Range) dateRange37);
        boolean boolean43 = numberAxis35.isNegativeArrowVisible();
        boolean boolean44 = numberAxis35.isTickMarksVisible();
        java.lang.Object obj45 = numberAxis35.clone();
        java.awt.Font font50 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand51 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis35, (double) 11, 0.0d, (double) 'a', (double) 100, font50);
        java.awt.Graphics2D graphics2D52 = null;
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        markerAxisBand51.draw(graphics2D52, rectangle2D53, rectangle2D54, (double) 12, (double) 12);
        numberAxis22.setMarkerBand(markerAxisBand51);
        xYPlot19.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) numberAxis22);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder60 = xYPlot19.getSeriesRenderingOrder();
        int int61 = xYPlot19.getDomainAxisCount();
        java.lang.Object obj62 = xYPlot19.clone();
        boolean boolean63 = xYPlot19.isDomainZoomable();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateRange16);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(dateRange24);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertNotNull(dateRange37);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(obj45);
        org.junit.Assert.assertNotNull(font50);
        org.junit.Assert.assertNotNull(seriesRenderingOrder60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 12 + "'", int61 == 12);
        org.junit.Assert.assertNotNull(obj62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        ganttRenderer0.setStartPercent((double) 100.0f);
        ganttRenderer0.setIncludeBaseInRange(true);
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer5 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        boolean boolean6 = boxAndWhiskerRenderer5.getBaseItemLabelsVisible();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer8 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.LegendItem legendItem11 = stackedAreaRenderer8.getLegendItem((int) 'a', 0);
        java.awt.Shape shape13 = null;
        stackedAreaRenderer8.setSeriesShape((int) '4', shape13, true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator16 = null;
        stackedAreaRenderer8.setBaseURLGenerator(categoryURLGenerator16);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = stackedAreaRenderer8.getNegativeItemLabelPosition(100, (int) (short) 0);
        boxAndWhiskerRenderer5.setSeriesPositiveItemLabelPosition((int) '#', itemLabelPosition20);
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str26 = numberAxis25.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange27 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint29 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange27, 0.0d);
        org.jfree.data.Range range31 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange27, (double) '#');
        numberAxis25.setDefaultAutoRange((org.jfree.data.Range) dateRange27);
        boolean boolean33 = numberAxis25.isNegativeArrowVisible();
        boolean boolean34 = numberAxis25.isTickMarksVisible();
        java.lang.Object obj35 = numberAxis25.clone();
        java.awt.Font font40 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand41 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis25, (double) 11, 0.0d, (double) 'a', (double) 100, font40);
        java.awt.Paint paint42 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.text.TextBlock textBlock43 = org.jfree.chart.text.TextUtilities.createTextBlock("NO_CHANGE", font40, paint42);
        boxAndWhiskerRenderer5.setSeriesOutlinePaint(3, paint42);
        ganttRenderer0.setIncompletePaint(paint42);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(legendItem11);
        org.junit.Assert.assertNotNull(itemLabelPosition20);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNotNull(dateRange27);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(obj35);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(textBlock43);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.text.TextLine textLine2 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.text.TextFragment textFragment3 = textLine2.getFirstTextFragment();
        java.awt.Font font4 = textFragment3.getFont();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("hi!", font4, (java.awt.Paint) color5);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D8 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        double double9 = stackedBarRenderer3D8.getYOffset();
        boolean boolean10 = stackedBarRenderer3D8.getRenderAsPercentages();
        boolean boolean11 = labelBlock6.equals((java.lang.Object) boolean10);
        org.junit.Assert.assertNotNull(textFragment3);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 8.0d + "'", double9 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer2 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.LegendItem legendItem5 = stackedAreaRenderer2.getLegendItem((int) 'a', 0);
        java.awt.Shape shape7 = null;
        stackedAreaRenderer2.setSeriesShape((int) '4', shape7, true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = null;
        stackedAreaRenderer2.setBaseURLGenerator(categoryURLGenerator10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = stackedAreaRenderer2.getNegativeItemLabelPosition(100, (int) (short) 0);
        org.jfree.chart.text.TextAnchor textAnchor15 = itemLabelPosition14.getRotationAnchor();
        org.jfree.chart.text.TextAnchor textAnchor16 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.axis.NumberTick numberTick18 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 5, "NO_CHANGE", textAnchor15, textAnchor16, (double) (-1));
        java.lang.Number number19 = numberTick18.getNumber();
        org.junit.Assert.assertNull(legendItem5);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertNotNull(textAnchor16);
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 5 + "'", number19.equals(5));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement0.clear();
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray32);
        java.lang.String[] strArray36 = new java.lang.String[] { "SerialDate.weekInMonthToString(): invalid code.", "VerticalAlignment.TOP" };
        java.lang.Number[] numberArray44 = new java.lang.Number[] { (short) 1, 100.0f, 2, (short) -1, (-1.0f) };
        java.lang.Number[] numberArray50 = new java.lang.Number[] { (short) 1, 100.0f, 2, (short) -1, (-1.0f) };
        java.lang.Number[][] numberArray51 = new java.lang.Number[][] { numberArray44, numberArray50 };
        org.jfree.data.category.CategoryDataset categoryDataset52 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray51);
        java.lang.Number[][] numberArray53 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset54 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray36, numberArray51, numberArray53);
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset55 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray32, numberArray53);
        try {
            java.lang.Comparable comparable57 = defaultIntervalCategoryDataset55.getColumnKey(6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(strArray36);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(categoryDataset52);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        booleanList0.setBoolean((int) (byte) 0, (java.lang.Boolean) true);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        int int1 = defaultStatisticalCategoryDataset0.getColumnCount();
        java.lang.Comparable comparable2 = null;
        int int3 = defaultStatisticalCategoryDataset0.getRowIndex(comparable2);
        try {
            java.lang.Number number6 = defaultStatisticalCategoryDataset0.getStdDevValue((-2234650), (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        int int5 = color4.getRed();
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder((double) 10L, 0.2d, 0.0d, (double) (-1310400001L), (java.awt.Paint) color4);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator0 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        java.lang.String str1 = standardCategoryToolTipGenerator0.getLabelFormat();
        java.lang.String str2 = standardCategoryToolTipGenerator0.getLabelFormat();
        java.lang.String str3 = standardCategoryToolTipGenerator0.getLabelFormat();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "({0}, {1}) = {2}" + "'", str1.equals("({0}, {1}) = {2}"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "({0}, {1}) = {2}" + "'", str2.equals("({0}, {1}) = {2}"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "({0}, {1}) = {2}" + "'", str3.equals("({0}, {1}) = {2}"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange3, 0.0d);
        org.jfree.data.Range range7 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange3, (double) '#');
        numberAxis1.setDefaultAutoRange((org.jfree.data.Range) dateRange3);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer9.setDrawOutlines(true);
        lineAndShapeRenderer9.setUseFillPaint(true);
        java.lang.Boolean boolean15 = lineAndShapeRenderer9.getSeriesShapesVisible(2);
        java.awt.Paint paint17 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        lineAndShapeRenderer9.setSeriesPaint((int) (byte) 10, paint17, true);
        boolean boolean20 = numberAxis1.equals((java.lang.Object) (byte) 10);
        java.awt.Shape shape21 = numberAxis1.getUpArrow();
        double double22 = numberAxis1.getLabelAngle();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(dateRange3);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(boolean15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("VerticalAlignment.TOP");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = null;
        ganttRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator1, false);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState6 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo5);
        org.jfree.chart.util.Size2D size2D9 = new org.jfree.chart.util.Size2D((double) 0.0f, (double) 1L);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Rectangle2D rectangle2D13 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D9, (double) (byte) 100, (double) 10, rectangleAnchor12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D16 = new org.jfree.chart.axis.CategoryAxis3D("PlotOrientation.VERTICAL");
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis18.zoomRange((double) 1.0f, (double) (byte) 10);
        boolean boolean22 = numberAxis18.isPositiveArrowVisible();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D24 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.general.PieDataset pieDataset25 = null;
        org.jfree.chart.plot.PiePlot piePlot26 = new org.jfree.chart.plot.PiePlot(pieDataset25);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator27 = null;
        piePlot26.setToolTipGenerator(pieToolTipGenerator27);
        numberAxis3D24.setPlot((org.jfree.chart.plot.Plot) piePlot26);
        org.jfree.chart.block.ColumnArrangement columnArrangement30 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.title.TextTitle textTitle31 = new org.jfree.chart.title.TextTitle();
        org.jfree.data.general.PieDataset pieDataset32 = null;
        org.jfree.chart.plot.PiePlot piePlot33 = new org.jfree.chart.plot.PiePlot(pieDataset32);
        org.jfree.chart.util.Rotation rotation34 = piePlot33.getDirection();
        org.jfree.chart.plot.Plot plot35 = piePlot33.getParent();
        org.jfree.chart.plot.Plot plot36 = piePlot33.getRootPlot();
        java.awt.Color color37 = java.awt.Color.MAGENTA;
        piePlot33.setOutlinePaint((java.awt.Paint) color37);
        columnArrangement30.add((org.jfree.chart.block.Block) textTitle31, (java.lang.Object) color37);
        piePlot26.setBackgroundPaint((java.awt.Paint) color37);
        org.jfree.data.general.PieDataset pieDataset42 = null;
        org.jfree.chart.plot.PiePlot piePlot43 = new org.jfree.chart.plot.PiePlot(pieDataset42);
        org.jfree.chart.util.Rotation rotation44 = piePlot43.getDirection();
        org.jfree.chart.plot.Plot plot45 = piePlot43.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent46 = null;
        piePlot43.datasetChanged(datasetChangeEvent46);
        java.awt.Graphics2D graphics2D48 = null;
        java.awt.geom.Rectangle2D rectangle2D49 = null;
        piePlot43.drawBackgroundImage(graphics2D48, rectangle2D49);
        java.awt.Paint paint51 = piePlot43.getBaseSectionOutlinePaint();
        java.awt.Paint paint52 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot43.setBaseSectionPaint(paint52);
        org.jfree.chart.JFreeChart jFreeChart54 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot43);
        jFreeChart54.setTitle("({0}, {1}) = {3} - {4}");
        org.jfree.chart.title.TextTitle textTitle57 = jFreeChart54.getTitle();
        java.awt.Stroke stroke58 = jFreeChart54.getBorderStroke();
        piePlot26.setBaseSectionOutlineStroke(stroke58);
        boolean boolean60 = piePlot26.isSubplot();
        boolean boolean61 = numberAxis18.hasListener((java.util.EventListener) piePlot26);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset62 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list63 = defaultStatisticalCategoryDataset62.getColumnKeys();
        java.lang.Number number64 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset62);
        try {
            ganttRenderer0.drawItem(graphics2D4, categoryItemRendererState6, rectangle2D13, categoryPlot14, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D16, (org.jfree.chart.axis.ValueAxis) numberAxis18, (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset62, (-459), (int) (byte) -1, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(rotation34);
        org.junit.Assert.assertNull(plot35);
        org.junit.Assert.assertNotNull(plot36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(rotation44);
        org.junit.Assert.assertNull(plot45);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNotNull(textTitle57);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(list63);
        org.junit.Assert.assertTrue("'" + number64 + "' != '" + 0.0d + "'", number64.equals(0.0d));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (short) 10, (-1), (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator1, false);
        boolean boolean4 = barRenderer0.getBaseCreateEntities();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        barRenderer0.setSeriesStroke((int) (short) 100, stroke6, false);
        java.lang.Boolean boolean10 = barRenderer0.getSeriesVisible((int) (byte) -1);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator12 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        barRenderer0.setSeriesToolTipGenerator((int) '#', (org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator12, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = barRenderer0.getPositiveItemLabelPositionFallback();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(boolean10);
        org.junit.Assert.assertNull(itemLabelPosition15);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        minMaxCategoryRenderer0.setBaseCreateEntities(false, true);
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.util.Rotation rotation7 = piePlot6.getDirection();
        org.jfree.chart.plot.Plot plot8 = piePlot6.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent9 = null;
        piePlot6.datasetChanged(datasetChangeEvent9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        piePlot6.drawBackgroundImage(graphics2D11, rectangle2D12);
        java.awt.Paint paint14 = piePlot6.getBaseSectionOutlinePaint();
        java.awt.Paint paint15 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot6.setBaseSectionPaint(paint15);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot6);
        jFreeChart17.setTitle("({0}, {1}) = {3} - {4}");
        org.jfree.chart.title.TextTitle textTitle20 = jFreeChart17.getTitle();
        java.awt.Stroke stroke21 = jFreeChart17.getBorderStroke();
        jFreeChart17.setAntiAlias(true);
        org.jfree.chart.ui.Library library28 = new org.jfree.chart.ui.Library("hi!", "hi!", "hi!", "");
        java.awt.Paint paint29 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        boolean boolean30 = library28.equals((java.lang.Object) paint29);
        jFreeChart17.setBorderPaint(paint29);
        minMaxCategoryRenderer0.setGroupPaint(paint29);
        java.awt.Paint paint33 = minMaxCategoryRenderer0.getGroupPaint();
        org.junit.Assert.assertNotNull(rotation7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(textTitle20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(paint33);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextOutlinePaint();
        java.awt.Paint paint2 = defaultDrawingSupplier0.getNextPaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((double) (byte) 10, (double) 1);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        int int1 = defaultStatisticalCategoryDataset0.getColumnCount();
        java.lang.Comparable comparable2 = null;
        int int3 = defaultStatisticalCategoryDataset0.getRowIndex(comparable2);
        double double5 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.util.Rotation rotation4 = piePlot3.getDirection();
        org.jfree.chart.plot.Plot plot5 = piePlot3.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = null;
        piePlot3.datasetChanged(datasetChangeEvent6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        piePlot3.drawBackgroundImage(graphics2D8, rectangle2D9);
        java.awt.Paint paint11 = piePlot3.getBaseSectionOutlinePaint();
        java.awt.Paint paint12 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot3.setBaseSectionPaint(paint12);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot3);
        jFreeChart14.setTitle("({0}, {1}) = {3} - {4}");
        org.jfree.chart.title.TextTitle textTitle17 = jFreeChart14.getTitle();
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment19 = textTitle18.getHorizontalAlignment();
        textTitle18.setExpandToFitSpace(true);
        jFreeChart14.removeSubtitle((org.jfree.chart.title.Title) textTitle18);
        java.awt.Color color23 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        jFreeChart14.setBackgroundPaint((java.awt.Paint) color23);
        java.awt.Color color25 = color23.darker();
        float[] floatArray32 = new float[] { 3, (byte) -1, 10L };
        float[] floatArray33 = java.awt.Color.RGBtoHSB((int) (short) -1, 2, (int) (short) -1, floatArray32);
        float[] floatArray34 = color23.getRGBColorComponents(floatArray33);
        try {
            float[] floatArray35 = color0.getComponents(floatArray34);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(rotation4);
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(textTitle17);
        org.junit.Assert.assertNotNull(horizontalAlignment19);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray34);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setDrawOutlines(true);
        boolean boolean3 = lineAndShapeRenderer0.getBaseLinesVisible();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        org.jfree.chart.util.Rotation rotation6 = piePlot5.getDirection();
        org.jfree.chart.plot.Plot plot7 = piePlot5.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        piePlot5.datasetChanged(datasetChangeEvent8);
        java.awt.Stroke stroke11 = piePlot5.getSectionOutlineStroke((java.lang.Comparable) (short) 100);
        java.awt.Paint paint12 = piePlot5.getNoDataMessagePaint();
        lineAndShapeRenderer0.setBasePaint(paint12, false);
        boolean boolean15 = lineAndShapeRenderer0.getBaseShapesFilled();
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator18 = new org.jfree.chart.urls.StandardCategoryURLGenerator("RectangleEdge.LEFT");
        lineAndShapeRenderer0.setSeriesURLGenerator(0, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator18, false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(rotation6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator1, false);
        boolean boolean4 = barRenderer0.getBaseCreateEntities();
        barRenderer0.setAutoPopulateSeriesFillPaint(false);
        org.jfree.chart.LegendItem legendItem9 = barRenderer0.getLegendItem(0, 9);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(legendItem9);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str6 = numberAxis5.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange7 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange7, 0.0d);
        org.jfree.data.Range range11 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange7, (double) '#');
        numberAxis5.setDefaultAutoRange((org.jfree.data.Range) dateRange7);
        boolean boolean13 = numberAxis5.isNegativeArrowVisible();
        boolean boolean14 = numberAxis5.isTickMarksVisible();
        java.lang.String str15 = numberAxis5.getLabel();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D17 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean18 = numberAxis3D17.isInverted();
        org.jfree.data.time.DateRange dateRange19 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis3D17.setRangeWithMargins((org.jfree.data.Range) dateRange19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) numberAxis5, (org.jfree.chart.axis.ValueAxis) numberAxis3D17, xYItemRenderer21);
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str26 = numberAxis25.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange27 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint29 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange27, 0.0d);
        org.jfree.data.Range range31 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange27, (double) '#');
        numberAxis25.setDefaultAutoRange((org.jfree.data.Range) dateRange27);
        boolean boolean33 = numberAxis25.isNegativeArrowVisible();
        boolean boolean34 = numberAxis25.isTickMarksVisible();
        numberAxis25.setFixedAutoRange((double) 1);
        org.jfree.chart.axis.NumberAxis numberAxis38 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str39 = numberAxis38.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange40 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint42 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange40, 0.0d);
        org.jfree.data.Range range44 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange40, (double) '#');
        numberAxis38.setDefaultAutoRange((org.jfree.data.Range) dateRange40);
        boolean boolean46 = numberAxis38.isNegativeArrowVisible();
        boolean boolean47 = numberAxis38.isTickMarksVisible();
        java.lang.Object obj48 = numberAxis38.clone();
        java.awt.Font font53 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand54 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis38, (double) 11, 0.0d, (double) 'a', (double) 100, font53);
        java.awt.Graphics2D graphics2D55 = null;
        java.awt.geom.Rectangle2D rectangle2D56 = null;
        java.awt.geom.Rectangle2D rectangle2D57 = null;
        markerAxisBand54.draw(graphics2D55, rectangle2D56, rectangle2D57, (double) 12, (double) 12);
        numberAxis25.setMarkerBand(markerAxisBand54);
        xYPlot22.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) numberAxis25);
        org.jfree.chart.renderer.category.BarRenderer barRenderer63 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator64 = barRenderer63.getBaseToolTipGenerator();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator67 = barRenderer63.getToolTipGenerator((int) (byte) 100, 0);
        java.awt.Color color69 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        int int70 = color69.getRed();
        barRenderer63.setSeriesPaint(11, (java.awt.Paint) color69, true);
        xYPlot22.setRangeCrosshairPaint((java.awt.Paint) color69);
        java.awt.Graphics2D graphics2D74 = null;
        org.jfree.chart.util.Size2D size2D77 = new org.jfree.chart.util.Size2D((double) 0.0f, (double) 1L);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor80 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Rectangle2D rectangle2D81 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D77, (double) (byte) 100, (double) 10, rectangleAnchor80);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo83 = null;
        org.jfree.chart.plot.CrosshairState crosshairState84 = null;
        boolean boolean85 = xYPlot22.render(graphics2D74, rectangle2D81, (int) 'a', plotRenderingInfo83, crosshairState84);
        java.awt.geom.Rectangle2D rectangle2D86 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge87 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean88 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge87);
        org.jfree.chart.util.RectangleEdge rectangleEdge89 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge87);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo90 = null;
        try {
            org.jfree.chart.axis.AxisState axisState91 = categoryAxis0.draw(graphics2D1, (double) (short) 10, rectangle2D81, rectangle2D86, rectangleEdge87, plotRenderingInfo90);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(dateRange7);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateRange19);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNotNull(dateRange27);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertNotNull(dateRange40);
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(obj48);
        org.junit.Assert.assertNotNull(font53);
        org.junit.Assert.assertNull(categoryToolTipGenerator64);
        org.junit.Assert.assertNull(categoryToolTipGenerator67);
        org.junit.Assert.assertNotNull(color69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
        org.junit.Assert.assertNotNull(rectangleAnchor80);
        org.junit.Assert.assertNotNull(rectangle2D81);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNotNull(rectangleEdge87);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertNotNull(rectangleEdge89);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.util.Rotation rotation3 = piePlot2.getDirection();
        org.jfree.chart.plot.Plot plot4 = piePlot2.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        piePlot2.datasetChanged(datasetChangeEvent5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        piePlot2.drawBackgroundImage(graphics2D7, rectangle2D8);
        java.awt.Paint paint10 = piePlot2.getBaseSectionOutlinePaint();
        java.awt.Paint paint11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot2.setBaseSectionPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart13.setTitle("({0}, {1}) = {3} - {4}");
        java.lang.Object obj16 = jFreeChart13.clone();
        jFreeChart13.fireChartChanged();
        jFreeChart13.setNotify(false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo23 = null;
        java.awt.image.BufferedImage bufferedImage24 = jFreeChart13.createBufferedImage((int) (byte) 10, 100, 12, chartRenderingInfo23);
        org.jfree.chart.event.ChartChangeListener chartChangeListener25 = null;
        try {
            jFreeChart13.removeChangeListener(chartChangeListener25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(bufferedImage24);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setDrawOutlines(true);
        lineAndShapeRenderer0.setUseFillPaint(true);
        java.awt.Paint paint7 = lineAndShapeRenderer0.getItemPaint((int) (short) -1, (int) '4');
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = lineAndShapeRenderer0.getDrawingSupplier();
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(drawingSupplier8);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.util.Rotation rotation3 = piePlot2.getDirection();
        org.jfree.chart.plot.Plot plot4 = piePlot2.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        piePlot2.datasetChanged(datasetChangeEvent5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        piePlot2.drawBackgroundImage(graphics2D7, rectangle2D8);
        java.awt.Paint paint10 = piePlot2.getBaseSectionOutlinePaint();
        java.awt.Paint paint11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot2.setBaseSectionPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart13.setTitle("({0}, {1}) = {3} - {4}");
        org.jfree.chart.title.TextTitle textTitle16 = jFreeChart13.getTitle();
        java.awt.Stroke stroke17 = jFreeChart13.getBorderStroke();
        jFreeChart13.setAntiAlias(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo23 = null;
        try {
            java.awt.image.BufferedImage bufferedImage24 = jFreeChart13.createBufferedImage((int) ' ', 1, 2958465, chartRenderingInfo23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown image type 2958465");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(textTitle16);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator1, false);
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.util.Rotation rotation7 = piePlot6.getDirection();
        org.jfree.chart.plot.Plot plot8 = piePlot6.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent9 = null;
        piePlot6.datasetChanged(datasetChangeEvent9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        piePlot6.drawBackgroundImage(graphics2D11, rectangle2D12);
        java.awt.Paint paint14 = piePlot6.getBaseSectionOutlinePaint();
        java.awt.Paint paint15 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot6.setBaseSectionPaint(paint15);
        barRenderer0.setSeriesItemLabelPaint((int) (byte) 0, paint15);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator19 = barRenderer0.getSeriesItemLabelGenerator(15);
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.util.Size2D size2D23 = new org.jfree.chart.util.Size2D((double) 0.0f, (double) 1L);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Rectangle2D rectangle2D27 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D23, (double) (byte) 100, (double) 10, rectangleAnchor26);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState31 = barRenderer0.initialise(graphics2D20, rectangle2D27, categoryPlot28, (int) (byte) 0, plotRenderingInfo30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rotation7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(categoryItemLabelGenerator19);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNotNull(rectangle2D27);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange3, 0.0d);
        org.jfree.data.Range range7 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange3, (double) '#');
        numberAxis1.setDefaultAutoRange((org.jfree.data.Range) dateRange3);
        boolean boolean9 = numberAxis1.isNegativeArrowVisible();
        boolean boolean10 = numberAxis1.isTickMarksVisible();
        org.jfree.chart.plot.Plot plot11 = null;
        numberAxis1.setPlot(plot11);
        org.jfree.chart.axis.TickUnitSource tickUnitSource13 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        numberAxis1.setStandardTickUnits(tickUnitSource13);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(dateRange3);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(tickUnitSource13);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.getAutoRangeStickyZero();
        org.jfree.chart.axis.TickUnitSource tickUnitSource3 = numberAxis1.getStandardTickUnits();
        numberAxis1.setTickMarkInsideLength((float) 0);
        java.text.NumberFormat numberFormat6 = null;
        numberAxis1.setNumberFormatOverride(numberFormat6);
        org.jfree.chart.util.UnitType unitType8 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets(unitType8, (double) 3, 0.0d, (double) 0.5f, (double) 100.0f);
        numberAxis1.setLabelInsets(rectangleInsets13);
        double double16 = rectangleInsets13.calculateLeftOutset((double) 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(tickUnitSource3);
        org.junit.Assert.assertNotNull(unitType8);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-0.0d) + "'", double16 == (-0.0d));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        double double1 = axisSpace0.getTop();
        axisSpace0.setLeft(1.05d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("AxisLocation.TOP_OR_LEFT", "ChartEntity: tooltip = ", "CategoryLabelWidthType.CATEGORY", image3, "ChartChangeEventType.DATASET_UPDATED", "NO_CHANGE", "NO_CHANGE");
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = piePlot1.getDirection();
        org.jfree.chart.plot.Plot plot3 = piePlot1.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        piePlot1.datasetChanged(datasetChangeEvent4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        piePlot1.drawBackgroundImage(graphics2D6, rectangle2D7);
        java.awt.Paint paint9 = piePlot1.getBaseSectionOutlinePaint();
        java.awt.Paint paint11 = piePlot1.getSectionPaint((java.lang.Comparable) 10);
        boolean boolean12 = piePlot1.getIgnoreZeroValues();
        org.junit.Assert.assertNotNull(rotation2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list1 = defaultStatisticalCategoryDataset0.getColumnKeys();
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        java.util.List list3 = defaultStatisticalCategoryDataset0.getRowKeys();
        org.jfree.data.general.PieDataset pieDataset5 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, 0);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator10 = null;
        piePlot9.setToolTipGenerator(pieToolTipGenerator10);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod((long) 10, (long) 'a');
        java.awt.Stroke stroke15 = piePlot9.getSectionOutlineStroke((java.lang.Comparable) simpleTimePeriod14);
        java.util.Date date16 = simpleTimePeriod14.getEnd();
        defaultStatisticalCategoryDataset0.add((java.lang.Number) 100, (java.lang.Number) 6, (java.lang.Comparable) simpleTimePeriod14, (java.lang.Comparable) 100);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0.0d + "'", number2.equals(0.0d));
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNotNull(pieDataset5);
        org.junit.Assert.assertNull(stroke15);
        org.junit.Assert.assertNotNull(date16);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(12, 0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.util.Rotation rotation3 = piePlot2.getDirection();
        org.jfree.chart.plot.Plot plot4 = piePlot2.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        piePlot2.datasetChanged(datasetChangeEvent5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        piePlot2.drawBackgroundImage(graphics2D7, rectangle2D8);
        java.awt.Paint paint10 = piePlot2.getBaseSectionOutlinePaint();
        java.awt.Paint paint11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot2.setBaseSectionPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart13.setTitle("({0}, {1}) = {3} - {4}");
        org.jfree.chart.title.TextTitle textTitle16 = jFreeChart13.getTitle();
        java.awt.Stroke stroke17 = jFreeChart13.getBorderStroke();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent18 = null;
        try {
            jFreeChart13.plotChanged(plotChangeEvent18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(textTitle16);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1);
        java.lang.String str3 = textBlockAnchor1.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TextBlockAnchor.CENTER_RIGHT" + "'", str3.equals("TextBlockAnchor.CENTER_RIGHT"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        java.awt.Paint paint1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        barRenderer2.setBaseToolTipGenerator(categoryToolTipGenerator3, false);
        boolean boolean6 = barRenderer2.getBaseCreateEntities();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        barRenderer2.setSeriesStroke((int) (short) 100, stroke8, false);
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker(0.0d, paint1, stroke8);
        java.awt.Paint paint12 = valueMarker11.getPaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = valueMarker11.getLabelAnchor();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = valueMarker11.getLabelAnchor();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor16 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition17 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor15, textBlockAnchor16);
        valueMarker11.setLabelAnchor(rectangleAnchor15);
        java.awt.Paint paint19 = valueMarker11.getLabelPaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNotNull(textBlockAnchor16);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setBaseLinesVisible(true);
        boolean boolean3 = lineAndShapeRenderer0.getAutoPopulateSeriesOutlineStroke();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, 0.0d);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange4, (double) '#');
        numberAxis2.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        boolean boolean10 = numberAxis2.isNegativeArrowVisible();
        boolean boolean11 = numberAxis2.isTickMarksVisible();
        java.lang.String str12 = numberAxis2.getLabel();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean15 = numberAxis3D14.isInverted();
        org.jfree.data.time.DateRange dateRange16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis3D14.setRangeWithMargins((org.jfree.data.Range) dateRange16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, xYItemRenderer18);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str23 = numberAxis22.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange24 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange24, 0.0d);
        org.jfree.data.Range range28 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange24, (double) '#');
        numberAxis22.setDefaultAutoRange((org.jfree.data.Range) dateRange24);
        boolean boolean30 = numberAxis22.isNegativeArrowVisible();
        boolean boolean31 = numberAxis22.isTickMarksVisible();
        numberAxis22.setFixedAutoRange((double) 1);
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str36 = numberAxis35.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange37 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint39 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange37, 0.0d);
        org.jfree.data.Range range41 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange37, (double) '#');
        numberAxis35.setDefaultAutoRange((org.jfree.data.Range) dateRange37);
        boolean boolean43 = numberAxis35.isNegativeArrowVisible();
        boolean boolean44 = numberAxis35.isTickMarksVisible();
        java.lang.Object obj45 = numberAxis35.clone();
        java.awt.Font font50 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand51 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis35, (double) 11, 0.0d, (double) 'a', (double) 100, font50);
        java.awt.Graphics2D graphics2D52 = null;
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        markerAxisBand51.draw(graphics2D52, rectangle2D53, rectangle2D54, (double) 12, (double) 12);
        numberAxis22.setMarkerBand(markerAxisBand51);
        xYPlot19.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) numberAxis22);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder60 = xYPlot19.getSeriesRenderingOrder();
        int int61 = xYPlot19.getDomainAxisCount();
        double double62 = xYPlot19.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation64 = xYPlot19.getRangeAxisLocation(2);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateRange16);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(dateRange24);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertNotNull(dateRange37);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(obj45);
        org.junit.Assert.assertNotNull(font50);
        org.junit.Assert.assertNotNull(seriesRenderingOrder60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 12 + "'", int61 == 12);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation64);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        java.awt.Paint paint1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        barRenderer2.setBaseToolTipGenerator(categoryToolTipGenerator3, false);
        boolean boolean6 = barRenderer2.getBaseCreateEntities();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        barRenderer2.setSeriesStroke((int) (short) 100, stroke8, false);
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker(0.0d, paint1, stroke8);
        java.awt.Paint paint12 = valueMarker11.getPaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = valueMarker11.getLabelAnchor();
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle();
        textTitle15.setNotify(false);
        java.lang.Class<?> wildcardClass18 = textTitle15.getClass();
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle();
        textTitle19.setNotify(false);
        java.lang.Class<?> wildcardClass22 = textTitle19.getClass();
        java.lang.Object obj23 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("VerticalAlignment.TOP", (java.lang.Class) wildcardClass18, (java.lang.Class) wildcardClass22);
        boolean boolean24 = org.jfree.chart.util.SerialUtilities.isSerializable((java.lang.Class) wildcardClass22);
        try {
            java.util.EventListener[] eventListenerArray25 = valueMarker11.getListeners((java.lang.Class) wildcardClass22);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: [Lorg.jfree.chart.title.TextTitle; cannot be cast to [Ljava.util.EventListener;");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNull(obj23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list1 = taskSeriesCollection0.getRowKeys();
        int int3 = taskSeriesCollection0.indexOf((java.lang.Comparable) "({0}, {1}) = {2}");
        int int4 = taskSeriesCollection0.getSeriesCount();
        org.jfree.data.gantt.TaskSeries taskSeries6 = taskSeriesCollection0.getSeries((java.lang.Comparable) 2.0f);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNull(taskSeries6);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        double double4 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator9 = null;
        piePlot8.setToolTipGenerator(pieToolTipGenerator9);
        numberAxis3D6.setPlot((org.jfree.chart.plot.Plot) piePlot8);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str15 = numberAxis14.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange16, 0.0d);
        org.jfree.data.Range range20 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange16, (double) '#');
        numberAxis14.setDefaultAutoRange((org.jfree.data.Range) dateRange16);
        boolean boolean22 = numberAxis14.isNegativeArrowVisible();
        boolean boolean23 = numberAxis14.isTickMarksVisible();
        java.lang.Object obj24 = numberAxis14.clone();
        numberAxis14.setAutoRangeIncludesZero(true);
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str29 = numberAxis28.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange30 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint32 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange30, 0.0d);
        org.jfree.data.Range range34 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange30, (double) '#');
        numberAxis28.setDefaultAutoRange((org.jfree.data.Range) dateRange30);
        boolean boolean36 = numberAxis28.isNegativeArrowVisible();
        boolean boolean37 = numberAxis28.isTickMarksVisible();
        java.lang.Object obj38 = numberAxis28.clone();
        java.awt.Font font43 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand44 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis28, (double) 11, 0.0d, (double) 'a', (double) 100, font43);
        numberAxis14.setTickLabelFont(font43);
        org.jfree.data.general.PieDataset pieDataset46 = null;
        org.jfree.chart.plot.PiePlot piePlot47 = new org.jfree.chart.plot.PiePlot(pieDataset46);
        org.jfree.chart.util.Rotation rotation48 = piePlot47.getDirection();
        org.jfree.chart.plot.Plot plot49 = piePlot47.getParent();
        org.jfree.chart.plot.Plot plot50 = piePlot47.getRootPlot();
        org.jfree.chart.JFreeChart jFreeChart52 = new org.jfree.chart.JFreeChart("PlotOrientation.VERTICAL", font43, (org.jfree.chart.plot.Plot) piePlot47, false);
        piePlot8.setNoDataMessageFont(font43);
        numberAxis2.setTickLabelFont(font43);
        java.awt.Color color55 = java.awt.Color.orange;
        org.jfree.chart.text.TextFragment textFragment56 = new org.jfree.chart.text.TextFragment("hi!", font43, (java.awt.Paint) color55);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(dateRange16);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(dateRange30);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertNotNull(rotation48);
        org.junit.Assert.assertNull(plot49);
        org.junit.Assert.assertNotNull(plot50);
        org.junit.Assert.assertNotNull(color55);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange3, 0.0d);
        org.jfree.data.Range range7 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange3, (double) '#');
        numberAxis1.setDefaultAutoRange((org.jfree.data.Range) dateRange3);
        org.jfree.data.Range range11 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange3, (double) 1, true);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(dateRange3);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(range11);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list1 = taskSeriesCollection0.getRowKeys();
        int int3 = taskSeriesCollection0.indexOf((java.lang.Comparable) "({0}, {1}) = {2}");
        int int4 = taskSeriesCollection0.getSeriesCount();
        try {
            java.lang.Number number7 = taskSeriesCollection0.getValue((java.lang.Comparable) 9, (java.lang.Comparable) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator4 = null;
        piePlot3.setToolTipGenerator(pieToolTipGenerator4);
        numberAxis3D1.setPlot((org.jfree.chart.plot.Plot) piePlot3);
        org.jfree.chart.block.ColumnArrangement columnArrangement7 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle();
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        org.jfree.chart.util.Rotation rotation11 = piePlot10.getDirection();
        org.jfree.chart.plot.Plot plot12 = piePlot10.getParent();
        org.jfree.chart.plot.Plot plot13 = piePlot10.getRootPlot();
        java.awt.Color color14 = java.awt.Color.MAGENTA;
        piePlot10.setOutlinePaint((java.awt.Paint) color14);
        columnArrangement7.add((org.jfree.chart.block.Block) textTitle8, (java.lang.Object) color14);
        piePlot3.setBackgroundPaint((java.awt.Paint) color14);
        org.jfree.data.general.PieDataset pieDataset19 = null;
        org.jfree.chart.plot.PiePlot piePlot20 = new org.jfree.chart.plot.PiePlot(pieDataset19);
        org.jfree.chart.util.Rotation rotation21 = piePlot20.getDirection();
        org.jfree.chart.plot.Plot plot22 = piePlot20.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent23 = null;
        piePlot20.datasetChanged(datasetChangeEvent23);
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        piePlot20.drawBackgroundImage(graphics2D25, rectangle2D26);
        java.awt.Paint paint28 = piePlot20.getBaseSectionOutlinePaint();
        java.awt.Paint paint29 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot20.setBaseSectionPaint(paint29);
        org.jfree.chart.JFreeChart jFreeChart31 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot20);
        jFreeChart31.setTitle("({0}, {1}) = {3} - {4}");
        org.jfree.chart.title.TextTitle textTitle34 = jFreeChart31.getTitle();
        java.awt.Stroke stroke35 = jFreeChart31.getBorderStroke();
        piePlot3.setBaseSectionOutlineStroke(stroke35);
        boolean boolean37 = piePlot3.isSubplot();
        double double38 = piePlot3.getLabelLinkMargin();
        org.junit.Assert.assertNotNull(rotation11);
        org.junit.Assert.assertNull(plot12);
        org.junit.Assert.assertNotNull(plot13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(rotation21);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(textTitle34);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.05d + "'", double38 == 0.05d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, 0.0d);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange4, (double) '#');
        numberAxis2.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        boolean boolean10 = numberAxis2.isNegativeArrowVisible();
        boolean boolean11 = numberAxis2.isTickMarksVisible();
        java.lang.String str12 = numberAxis2.getLabel();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean15 = numberAxis3D14.isInverted();
        org.jfree.data.time.DateRange dateRange16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis3D14.setRangeWithMargins((org.jfree.data.Range) dateRange16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, xYItemRenderer18);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray20 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot19.setRenderers(xYItemRendererArray20);
        int int22 = xYPlot19.getSeriesCount();
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double26 = numberAxis25.getFixedAutoRange();
        java.text.NumberFormat numberFormat27 = numberAxis25.getNumberFormatOverride();
        java.awt.Paint paint28 = numberAxis25.getAxisLinePaint();
        java.lang.String str29 = numberAxis25.getLabelToolTip();
        xYPlot19.setDomainAxis((int) '#', (org.jfree.chart.axis.ValueAxis) numberAxis25, true);
        java.awt.Paint paint32 = xYPlot19.getRangeZeroBaselinePaint();
        java.awt.Graphics2D graphics2D33 = null;
        org.jfree.chart.util.Size2D size2D36 = new org.jfree.chart.util.Size2D((double) 0.0f, (double) 1L);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor39 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Rectangle2D rectangle2D40 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D36, (double) (byte) 100, (double) 10, rectangleAnchor39);
        try {
            xYPlot19.drawBackground(graphics2D33, rectangle2D40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateRange16);
        org.junit.Assert.assertNotNull(xYItemRendererArray20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNull(numberFormat27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(rectangleAnchor39);
        org.junit.Assert.assertNotNull(rectangle2D40);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, 0.0d);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange4, (double) '#');
        numberAxis2.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        boolean boolean10 = numberAxis2.isNegativeArrowVisible();
        boolean boolean11 = numberAxis2.isTickMarksVisible();
        java.lang.String str12 = numberAxis2.getLabel();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean15 = numberAxis3D14.isInverted();
        org.jfree.data.time.DateRange dateRange16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis3D14.setRangeWithMargins((org.jfree.data.Range) dateRange16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, xYItemRenderer18);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str23 = numberAxis22.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange24 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange24, 0.0d);
        org.jfree.data.Range range28 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange24, (double) '#');
        numberAxis22.setDefaultAutoRange((org.jfree.data.Range) dateRange24);
        boolean boolean30 = numberAxis22.isNegativeArrowVisible();
        boolean boolean31 = numberAxis22.isTickMarksVisible();
        numberAxis22.setFixedAutoRange((double) 1);
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str36 = numberAxis35.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange37 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint39 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange37, 0.0d);
        org.jfree.data.Range range41 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange37, (double) '#');
        numberAxis35.setDefaultAutoRange((org.jfree.data.Range) dateRange37);
        boolean boolean43 = numberAxis35.isNegativeArrowVisible();
        boolean boolean44 = numberAxis35.isTickMarksVisible();
        java.lang.Object obj45 = numberAxis35.clone();
        java.awt.Font font50 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand51 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis35, (double) 11, 0.0d, (double) 'a', (double) 100, font50);
        java.awt.Graphics2D graphics2D52 = null;
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        markerAxisBand51.draw(graphics2D52, rectangle2D53, rectangle2D54, (double) 12, (double) 12);
        numberAxis22.setMarkerBand(markerAxisBand51);
        xYPlot19.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) numberAxis22);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder60 = xYPlot19.getSeriesRenderingOrder();
        int int61 = xYPlot19.getDomainAxisCount();
        double double62 = xYPlot19.getRangeCrosshairValue();
        java.lang.Object obj63 = xYPlot19.clone();
        xYPlot19.setDomainCrosshairLockedOnData(true);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateRange16);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(dateRange24);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertNotNull(dateRange37);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(obj45);
        org.junit.Assert.assertNotNull(font50);
        org.junit.Assert.assertNotNull(seriesRenderingOrder60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 12 + "'", int61 == 12);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertNotNull(obj63);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setDrawOutlines(true);
        lineAndShapeRenderer0.setUseFillPaint(true);
        java.lang.Boolean boolean6 = lineAndShapeRenderer0.getSeriesShapesVisible(2);
        lineAndShapeRenderer0.setSeriesShapesFilled((int) '4', (java.lang.Boolean) true);
        org.junit.Assert.assertNull(boolean6);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (byte) 1, (float) (-2234650));
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = piePlot1.getDirection();
        org.jfree.chart.plot.Plot plot3 = piePlot1.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        piePlot1.datasetChanged(datasetChangeEvent4);
        java.awt.Stroke stroke7 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) (short) 100);
        java.awt.Shape shape13 = null;
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape20 = null;
        java.awt.Stroke stroke21 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color22 = java.awt.Color.black;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("", "hi!", "hi!", "", true, shape13, false, (java.awt.Paint) color15, false, paint17, stroke18, true, shape20, stroke21, (java.awt.Paint) color22);
        piePlot1.setOutlineStroke(stroke18);
        org.junit.Assert.assertNotNull(rotation2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNull(stroke7);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color22);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.LegendItem legendItem3 = stackedAreaRenderer0.getLegendItem((int) 'a', 0);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = null;
        stackedAreaRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator4, true);
        boolean boolean8 = stackedAreaRenderer0.equals((java.lang.Object) 10.0f);
        boolean boolean9 = stackedAreaRenderer0.getRenderAsPercentages();
        boolean boolean10 = stackedAreaRenderer0.getRenderAsPercentages();
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, 0.0d);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange4, (double) '#');
        numberAxis2.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        boolean boolean10 = numberAxis2.isNegativeArrowVisible();
        boolean boolean11 = numberAxis2.isTickMarksVisible();
        java.lang.String str12 = numberAxis2.getLabel();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean15 = numberAxis3D14.isInverted();
        org.jfree.data.time.DateRange dateRange16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis3D14.setRangeWithMargins((org.jfree.data.Range) dateRange16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, xYItemRenderer18);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray20 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot19.setRenderers(xYItemRendererArray20);
        int int22 = xYPlot19.getSeriesCount();
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double26 = numberAxis25.getFixedAutoRange();
        java.text.NumberFormat numberFormat27 = numberAxis25.getNumberFormatOverride();
        java.awt.Paint paint28 = numberAxis25.getAxisLinePaint();
        java.lang.String str29 = numberAxis25.getLabelToolTip();
        xYPlot19.setDomainAxis((int) '#', (org.jfree.chart.axis.ValueAxis) numberAxis25, true);
        org.jfree.chart.axis.AxisLocation axisLocation32 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        java.lang.Object obj33 = null;
        boolean boolean34 = axisLocation32.equals(obj33);
        xYPlot19.setRangeAxisLocation(axisLocation32);
        org.jfree.chart.axis.AxisLocation axisLocation36 = axisLocation32.getOpposite();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateRange16);
        org.junit.Assert.assertNotNull(xYItemRendererArray20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNull(numberFormat27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(axisLocation36);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getFixedAutoRange();
        java.text.NumberFormat numberFormat3 = numberAxis1.getNumberFormatOverride();
        java.awt.Paint paint4 = numberAxis1.getAxisLinePaint();
        java.lang.String str5 = numberAxis1.getLabelToolTip();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = numberAxis1.getLabelInsets();
        double double8 = rectangleInsets6.calculateTopOutset(0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNull(numberFormat3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.0d + "'", double8 == 3.0d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getFixedAutoRange();
        java.text.NumberFormat numberFormat4 = numberAxis2.getNumberFormatOverride();
        boolean boolean5 = numberAxis2.isVerticalTickLabels();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, polarItemRenderer6);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.util.Rotation rotation10 = piePlot9.getDirection();
        org.jfree.chart.plot.Plot plot11 = piePlot9.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = null;
        piePlot9.datasetChanged(datasetChangeEvent12);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        piePlot9.drawBackgroundImage(graphics2D14, rectangle2D15);
        java.awt.Paint paint17 = piePlot9.getBaseSectionOutlinePaint();
        java.awt.Paint paint18 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot9.setBaseSectionPaint(paint18);
        polarPlot7.setAngleGridlinePaint(paint18);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D22 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean23 = numberAxis3D22.isTickMarksVisible();
        org.jfree.chart.plot.Plot plot24 = numberAxis3D22.getPlot();
        org.jfree.data.Range range25 = polarPlot7.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D22);
        java.awt.Paint paint26 = polarPlot7.getAngleLabelPaint();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNull(numberFormat4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rotation10);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(plot24);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (-2208960000000L));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        int int1 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getFixedAutoRange();
        boolean boolean3 = numberAxis1.isAxisLineVisible();
        double double4 = numberAxis1.getLabelAngle();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.AxisState axisState6 = new org.jfree.chart.axis.AxisState();
        axisState6.cursorLeft((double) (-1L));
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str12 = numberAxis11.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange13 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange13, 0.0d);
        org.jfree.data.Range range17 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange13, (double) '#');
        numberAxis11.setDefaultAutoRange((org.jfree.data.Range) dateRange13);
        boolean boolean19 = numberAxis11.isNegativeArrowVisible();
        boolean boolean20 = numberAxis11.isTickMarksVisible();
        java.lang.String str21 = numberAxis11.getLabel();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D23 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean24 = numberAxis3D23.isInverted();
        org.jfree.data.time.DateRange dateRange25 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis3D23.setRangeWithMargins((org.jfree.data.Range) dateRange25);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) numberAxis11, (org.jfree.chart.axis.ValueAxis) numberAxis3D23, xYItemRenderer27);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str32 = numberAxis31.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange33 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint35 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange33, 0.0d);
        org.jfree.data.Range range37 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange33, (double) '#');
        numberAxis31.setDefaultAutoRange((org.jfree.data.Range) dateRange33);
        boolean boolean39 = numberAxis31.isNegativeArrowVisible();
        boolean boolean40 = numberAxis31.isTickMarksVisible();
        numberAxis31.setFixedAutoRange((double) 1);
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str45 = numberAxis44.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange46 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint48 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange46, 0.0d);
        org.jfree.data.Range range50 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange46, (double) '#');
        numberAxis44.setDefaultAutoRange((org.jfree.data.Range) dateRange46);
        boolean boolean52 = numberAxis44.isNegativeArrowVisible();
        boolean boolean53 = numberAxis44.isTickMarksVisible();
        java.lang.Object obj54 = numberAxis44.clone();
        java.awt.Font font59 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand60 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis44, (double) 11, 0.0d, (double) 'a', (double) 100, font59);
        java.awt.Graphics2D graphics2D61 = null;
        java.awt.geom.Rectangle2D rectangle2D62 = null;
        java.awt.geom.Rectangle2D rectangle2D63 = null;
        markerAxisBand60.draw(graphics2D61, rectangle2D62, rectangle2D63, (double) 12, (double) 12);
        numberAxis31.setMarkerBand(markerAxisBand60);
        xYPlot28.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) numberAxis31);
        org.jfree.chart.renderer.category.BarRenderer barRenderer69 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator70 = barRenderer69.getBaseToolTipGenerator();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator73 = barRenderer69.getToolTipGenerator((int) (byte) 100, 0);
        java.awt.Color color75 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        int int76 = color75.getRed();
        barRenderer69.setSeriesPaint(11, (java.awt.Paint) color75, true);
        xYPlot28.setRangeCrosshairPaint((java.awt.Paint) color75);
        java.awt.Graphics2D graphics2D80 = null;
        org.jfree.chart.util.Size2D size2D83 = new org.jfree.chart.util.Size2D((double) 0.0f, (double) 1L);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor86 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Rectangle2D rectangle2D87 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D83, (double) (byte) 100, (double) 10, rectangleAnchor86);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo89 = null;
        org.jfree.chart.plot.CrosshairState crosshairState90 = null;
        boolean boolean91 = xYPlot28.render(graphics2D80, rectangle2D87, (int) 'a', plotRenderingInfo89, crosshairState90);
        org.jfree.chart.util.RectangleEdge rectangleEdge92 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean93 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge92);
        try {
            java.util.List list94 = numberAxis1.refreshTicks(graphics2D5, axisState6, rectangle2D87, rectangleEdge92);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(dateRange13);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(dateRange25);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertNotNull(dateRange33);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertNotNull(dateRange46);
        org.junit.Assert.assertNotNull(range50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(obj54);
        org.junit.Assert.assertNotNull(font59);
        org.junit.Assert.assertNull(categoryToolTipGenerator70);
        org.junit.Assert.assertNull(categoryToolTipGenerator73);
        org.junit.Assert.assertNotNull(color75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
        org.junit.Assert.assertNotNull(rectangleAnchor86);
        org.junit.Assert.assertNotNull(rectangle2D87);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertNotNull(rectangleEdge92);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = piePlot1.getDirection();
        org.jfree.chart.plot.Plot plot3 = piePlot1.getParent();
        org.jfree.chart.plot.Plot plot4 = piePlot1.getRootPlot();
        double double5 = piePlot1.getLabelGap();
        java.awt.Paint paint6 = piePlot1.getOutlinePaint();
        org.junit.Assert.assertNotNull(rotation2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(plot4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((double) ' ', 0.0d);
        java.lang.Number number3 = meanAndStandardDeviation2.getMean();
        java.lang.Number number4 = meanAndStandardDeviation2.getStandardDeviation();
        java.lang.Number number5 = meanAndStandardDeviation2.getMean();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 32.0d + "'", number3.equals(32.0d));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.0d + "'", number4.equals(0.0d));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 32.0d + "'", number5.equals(32.0d));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.util.Rotation rotation3 = piePlot2.getDirection();
        org.jfree.chart.plot.Plot plot4 = piePlot2.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        piePlot2.datasetChanged(datasetChangeEvent5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        piePlot2.drawBackgroundImage(graphics2D7, rectangle2D8);
        java.awt.Paint paint10 = piePlot2.getBaseSectionOutlinePaint();
        java.awt.Paint paint11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot2.setBaseSectionPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot2);
        java.awt.Stroke stroke14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        piePlot2.setLabelLinkStroke(stroke14);
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType0 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        java.lang.String str1 = categoryLabelWidthType0.toString();
        java.lang.String str2 = categoryLabelWidthType0.toString();
        org.junit.Assert.assertNotNull(categoryLabelWidthType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CategoryLabelWidthType.CATEGORY" + "'", str1.equals("CategoryLabelWidthType.CATEGORY"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "CategoryLabelWidthType.CATEGORY" + "'", str2.equals("CategoryLabelWidthType.CATEGORY"));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 11);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape2, "RectangleEdge.LEFT", "NO_CHANGE");
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity8 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) 8.0d, shape2, "({0}, {1}) = {2}", "SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str9 = categoryLabelEntity8.getToolTipText();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "({0}, {1}) = {2}" + "'", str9.equals("({0}, {1}) = {2}"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.text.TextFragment textFragment4 = textLine3.getFirstTextFragment();
        java.awt.Font font5 = textFragment4.getFont();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.block.LabelBlock labelBlock7 = new org.jfree.chart.block.LabelBlock("hi!", font5, (java.awt.Paint) color6);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer8 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Paint paint9 = ganttRenderer8.getCompletePaint();
        org.jfree.chart.block.LabelBlock labelBlock10 = new org.jfree.chart.block.LabelBlock("({0}, {1}) = {3} - {4}", font5, paint9);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection11 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list12 = taskSeriesCollection11.getRowKeys();
        int int14 = taskSeriesCollection11.indexOf((java.lang.Comparable) "({0}, {1}) = {2}");
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double17 = numberAxis16.getFixedAutoRange();
        java.text.NumberFormat numberFormat18 = numberAxis16.getNumberFormatOverride();
        java.awt.Paint paint19 = numberAxis16.getAxisLinePaint();
        java.lang.String str20 = numberAxis16.getLabelToolTip();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit21 = numberAxis16.getTickUnit();
        int int22 = taskSeriesCollection11.indexOf((java.lang.Comparable) numberTickUnit21);
        boolean boolean23 = labelBlock10.equals((java.lang.Object) numberTickUnit21);
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.util.Size2D size2D27 = new org.jfree.chart.util.Size2D((double) 0.0f, (double) 1L);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor30 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Rectangle2D rectangle2D31 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D27, (double) (byte) 100, (double) 10, rectangleAnchor30);
        try {
            labelBlock10.draw(graphics2D24, rectangle2D31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textFragment4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNull(numberFormat18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(numberTickUnit21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor30);
        org.junit.Assert.assertNotNull(rectangle2D31);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        stackedAreaRenderer0.setSeriesVisibleInLegend((int) (byte) 1, (java.lang.Boolean) false);
        java.lang.Object obj4 = stackedAreaRenderer0.clone();
        stackedAreaRenderer0.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setLicenceName("SerialDate.weekInMonthToString(): invalid code.");
        org.junit.Assert.assertNotNull(projectInfo0);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        int int1 = defaultStatisticalCategoryDataset0.getColumnCount();
        java.lang.Comparable comparable2 = null;
        int int3 = defaultStatisticalCategoryDataset0.getRowIndex(comparable2);
        java.lang.Object obj4 = defaultStatisticalCategoryDataset0.clone();
        java.util.List list5 = defaultStatisticalCategoryDataset0.getColumnKeys();
        org.jfree.data.general.DatasetGroup datasetGroup6 = new org.jfree.data.general.DatasetGroup();
        defaultStatisticalCategoryDataset0.setGroup(datasetGroup6);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(list5);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.lang.Object obj1 = defaultKeyedValues2D0.clone();
        try {
            java.lang.Comparable comparable3 = defaultKeyedValues2D0.getColumnKey(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.zoomRange(0.0d, 10.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis1.getTickUnit();
        dateAxis0.setTickUnit(dateTickUnit5, false, true);
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double12 = numberAxis11.getFixedAutoRange();
        java.text.NumberFormat numberFormat13 = numberAxis11.getNumberFormatOverride();
        boolean boolean14 = numberAxis11.isVerticalTickLabels();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer15 = null;
        org.jfree.chart.plot.PolarPlot polarPlot16 = new org.jfree.chart.plot.PolarPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) numberAxis11, polarItemRenderer15);
        boolean boolean17 = dateAxis0.equals((java.lang.Object) numberAxis11);
        double double18 = numberAxis11.getUpperMargin();
        org.junit.Assert.assertNotNull(dateTickUnit5);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNull(numberFormat13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.05d + "'", double18 == 0.05d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType2 = valueMarker1.getLabelOffsetType();
        java.awt.Stroke stroke3 = valueMarker1.getStroke();
        org.junit.Assert.assertNotNull(lengthAdjustmentType2);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        boxAndWhiskerRenderer0.setFillBox(true);
        double double3 = boxAndWhiskerRenderer0.getItemMargin();
        java.awt.Stroke stroke6 = boxAndWhiskerRenderer0.getItemOutlineStroke((int) (short) 10, 3);
        org.jfree.chart.text.TextLine textLine10 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.text.TextFragment textFragment11 = textLine10.getFirstTextFragment();
        java.awt.Font font12 = textFragment11.getFont();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.block.LabelBlock labelBlock14 = new org.jfree.chart.block.LabelBlock("hi!", font12, (java.awt.Paint) color13);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer15 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Paint paint16 = ganttRenderer15.getCompletePaint();
        org.jfree.chart.block.LabelBlock labelBlock17 = new org.jfree.chart.block.LabelBlock("({0}, {1}) = {3} - {4}", font12, paint16);
        boxAndWhiskerRenderer0.setArtifactPaint(paint16);
        boolean boolean21 = boxAndWhiskerRenderer0.getItemCreateEntity(12, (-459));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(textFragment11);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange3, 0.0d);
        org.jfree.data.Range range7 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange3, (double) '#');
        numberAxis1.setDefaultAutoRange((org.jfree.data.Range) dateRange3);
        boolean boolean9 = numberAxis1.isNegativeArrowVisible();
        boolean boolean10 = numberAxis1.isTickMarksVisible();
        org.jfree.chart.plot.Plot plot11 = null;
        numberAxis1.setPlot(plot11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        org.jfree.chart.util.Rotation rotation15 = piePlot14.getDirection();
        org.jfree.chart.plot.Plot plot16 = piePlot14.getParent();
        org.jfree.chart.plot.Plot plot17 = piePlot14.getRootPlot();
        java.awt.Color color18 = java.awt.Color.MAGENTA;
        piePlot14.setOutlinePaint((java.awt.Paint) color18);
        int int20 = piePlot14.getBackgroundImageAlignment();
        java.awt.Paint paint21 = piePlot14.getOutlinePaint();
        boolean boolean22 = numberAxis1.hasListener((java.util.EventListener) piePlot14);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit23 = null;
        try {
            numberAxis1.setTickUnit(numberTickUnit23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(dateRange3);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(rotation15);
        org.junit.Assert.assertNull(plot16);
        org.junit.Assert.assertNotNull(plot17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 15 + "'", int20 == 15);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) '#');
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        double[] doubleArray5 = new double[] { (short) 1 };
        double[] doubleArray7 = new double[] { (short) 1 };
        double[] doubleArray9 = new double[] { (short) 1 };
        double[][] doubleArray10 = new double[][] { doubleArray5, doubleArray7, doubleArray9 };
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "VerticalAlignment.TOP", doubleArray10);
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", " version ({0}, {1}) = {3} - {4}.\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n({0}, {1}) = {3} - {4}", doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
        org.junit.Assert.assertNotNull(categoryDataset12);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.ColumnArrangement columnArrangement1 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        org.jfree.chart.util.Rotation rotation5 = piePlot4.getDirection();
        org.jfree.chart.plot.Plot plot6 = piePlot4.getParent();
        org.jfree.chart.plot.Plot plot7 = piePlot4.getRootPlot();
        java.awt.Color color8 = java.awt.Color.MAGENTA;
        piePlot4.setOutlinePaint((java.awt.Paint) color8);
        columnArrangement1.add((org.jfree.chart.block.Block) textTitle2, (java.lang.Object) color8);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection11 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent12 = null;
        taskSeriesCollection11.seriesChanged(seriesChangeEvent12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.next();
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer16 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement1, (org.jfree.data.general.Dataset) taskSeriesCollection11, (java.lang.Comparable) year14);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.data.time.DateRange dateRange18 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange18, 0.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = rectangleConstraint20.toUnconstrainedHeight();
        org.jfree.data.Range range22 = rectangleConstraint20.getHeightRange();
        org.jfree.data.Range range23 = rectangleConstraint20.getWidthRange();
        org.jfree.data.time.DateRange dateRange24 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.data.time.DateRange dateRange25 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange24);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = rectangleConstraint20.toRangeWidth((org.jfree.data.Range) dateRange25);
        double double27 = rectangleConstraint26.getWidth();
        org.jfree.chart.util.Size2D size2D28 = columnArrangement0.arrange((org.jfree.chart.block.BlockContainer) legendItemBlockContainer16, graphics2D17, rectangleConstraint26);
        org.junit.Assert.assertNotNull(rotation5);
        org.junit.Assert.assertNull(plot6);
        org.junit.Assert.assertNotNull(plot7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(dateRange18);
        org.junit.Assert.assertNotNull(rectangleConstraint21);
        org.junit.Assert.assertNull(range22);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNotNull(dateRange24);
        org.junit.Assert.assertNotNull(rectangleConstraint26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.0d + "'", double27 == 1.0d);
        org.junit.Assert.assertNotNull(size2D28);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = barRenderer0.getBaseToolTipGenerator();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator4 = barRenderer0.getToolTipGenerator((int) (byte) 100, 0);
        boolean boolean5 = barRenderer0.getAutoPopulateSeriesPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = null;
        barRenderer0.setSeriesNegativeItemLabelPosition((int) (byte) 100, itemLabelPosition7, false);
        barRenderer0.setBaseSeriesVisible(false);
        boolean boolean14 = barRenderer0.getItemCreateEntity((int) (byte) 10, (int) (byte) 100);
        barRenderer0.setBaseSeriesVisibleInLegend(false);
        org.junit.Assert.assertNull(categoryToolTipGenerator1);
        org.junit.Assert.assertNull(categoryToolTipGenerator4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(255);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.util.Rotation rotation4 = piePlot3.getDirection();
        org.jfree.chart.plot.Plot plot5 = piePlot3.getParent();
        org.jfree.chart.plot.Plot plot6 = piePlot3.getRootPlot();
        java.awt.Color color7 = java.awt.Color.MAGENTA;
        piePlot3.setOutlinePaint((java.awt.Paint) color7);
        columnArrangement0.add((org.jfree.chart.block.Block) textTitle1, (java.lang.Object) color7);
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        org.jfree.chart.util.Rotation rotation12 = piePlot11.getDirection();
        org.jfree.chart.plot.Plot plot13 = piePlot11.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent14 = null;
        piePlot11.datasetChanged(datasetChangeEvent14);
        java.awt.Stroke stroke16 = null;
        piePlot11.setLabelOutlineStroke(stroke16);
        java.lang.Number[] numberArray24 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray34 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray44 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray49 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[][] numberArray50 = new java.lang.Number[][] { numberArray24, numberArray29, numberArray34, numberArray39, numberArray44, numberArray49 };
        org.jfree.data.category.CategoryDataset categoryDataset51 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray50);
        org.jfree.data.general.PieDataset pieDataset53 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset51, (int) (short) 1);
        piePlot11.setDataset(pieDataset53);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer56 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0, (org.jfree.data.general.Dataset) pieDataset53, (java.lang.Comparable) 500);
        org.jfree.data.general.Dataset dataset57 = legendItemBlockContainer56.getDataset();
        java.lang.String str58 = legendItemBlockContainer56.getID();
        java.lang.String str59 = legendItemBlockContainer56.getToolTipText();
        org.junit.Assert.assertNotNull(rotation4);
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertNotNull(plot6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(rotation12);
        org.junit.Assert.assertNull(plot13);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(numberArray49);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(categoryDataset51);
        org.junit.Assert.assertNotNull(pieDataset53);
        org.junit.Assert.assertNotNull(dataset57);
        org.junit.Assert.assertNull(str58);
        org.junit.Assert.assertNull(str59);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(500);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 500");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.calculateTopInset(0.0d);
        double double4 = rectangleInsets0.extendHeight((double) 15);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 23.0d + "'", double4 == 23.0d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape2 = shapeList0.getShape((int) (short) -1);
        org.junit.Assert.assertNull(shape2);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = piePlot1.getDirection();
        org.jfree.chart.plot.Plot plot3 = piePlot1.getParent();
        org.jfree.chart.plot.Plot plot4 = piePlot1.getRootPlot();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.util.Rotation rotation7 = piePlot6.getDirection();
        org.jfree.chart.plot.Plot plot8 = piePlot6.getParent();
        org.jfree.chart.plot.Plot plot9 = piePlot6.getRootPlot();
        java.awt.Color color10 = java.awt.Color.MAGENTA;
        piePlot6.setOutlinePaint((java.awt.Paint) color10);
        piePlot1.setLabelLinkPaint((java.awt.Paint) color10);
        java.awt.Color color13 = color10.brighter();
        org.junit.Assert.assertNotNull(rotation2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(plot4);
        org.junit.Assert.assertNotNull(rotation7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color13);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, 0.0d);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange4, (double) '#');
        numberAxis2.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        boolean boolean10 = numberAxis2.isNegativeArrowVisible();
        boolean boolean11 = numberAxis2.isTickMarksVisible();
        java.lang.String str12 = numberAxis2.getLabel();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean15 = numberAxis3D14.isInverted();
        org.jfree.data.time.DateRange dateRange16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis3D14.setRangeWithMargins((org.jfree.data.Range) dateRange16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, xYItemRenderer18);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray20 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot19.setRenderers(xYItemRendererArray20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        xYPlot19.zoomRangeAxes((double) (-1L), plotRenderingInfo23, point2D24);
        org.jfree.chart.util.Layer layer26 = null;
        java.util.Collection collection27 = xYPlot19.getRangeMarkers(layer26);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateRange16);
        org.junit.Assert.assertNotNull(xYItemRendererArray20);
        org.junit.Assert.assertNull(collection27);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator4 = null;
        piePlot3.setToolTipGenerator(pieToolTipGenerator4);
        numberAxis3D1.setPlot((org.jfree.chart.plot.Plot) piePlot3);
        org.jfree.chart.block.ColumnArrangement columnArrangement7 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle();
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        org.jfree.chart.util.Rotation rotation11 = piePlot10.getDirection();
        org.jfree.chart.plot.Plot plot12 = piePlot10.getParent();
        org.jfree.chart.plot.Plot plot13 = piePlot10.getRootPlot();
        java.awt.Color color14 = java.awt.Color.MAGENTA;
        piePlot10.setOutlinePaint((java.awt.Paint) color14);
        columnArrangement7.add((org.jfree.chart.block.Block) textTitle8, (java.lang.Object) color14);
        piePlot3.setBackgroundPaint((java.awt.Paint) color14);
        org.jfree.data.general.PieDataset pieDataset19 = null;
        org.jfree.chart.plot.PiePlot piePlot20 = new org.jfree.chart.plot.PiePlot(pieDataset19);
        org.jfree.chart.util.Rotation rotation21 = piePlot20.getDirection();
        org.jfree.chart.plot.Plot plot22 = piePlot20.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent23 = null;
        piePlot20.datasetChanged(datasetChangeEvent23);
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        piePlot20.drawBackgroundImage(graphics2D25, rectangle2D26);
        java.awt.Paint paint28 = piePlot20.getBaseSectionOutlinePaint();
        java.awt.Paint paint29 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot20.setBaseSectionPaint(paint29);
        org.jfree.chart.JFreeChart jFreeChart31 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot20);
        jFreeChart31.setTitle("({0}, {1}) = {3} - {4}");
        org.jfree.chart.title.TextTitle textTitle34 = jFreeChart31.getTitle();
        java.awt.Stroke stroke35 = jFreeChart31.getBorderStroke();
        piePlot3.setBaseSectionOutlineStroke(stroke35);
        java.awt.Graphics2D graphics2D37 = null;
        org.jfree.chart.util.Size2D size2D40 = new org.jfree.chart.util.Size2D((double) 0.0f, (double) 1L);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor43 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Rectangle2D rectangle2D44 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D40, (double) (byte) 100, (double) 10, rectangleAnchor43);
        java.awt.Shape shape48 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D44, (double) 1, (float) (byte) 0, (float) '4');
        try {
            piePlot3.drawOutline(graphics2D37, rectangle2D44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rotation11);
        org.junit.Assert.assertNull(plot12);
        org.junit.Assert.assertNotNull(plot13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(rotation21);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(textTitle34);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(rectangleAnchor43);
        org.junit.Assert.assertNotNull(rectangle2D44);
        org.junit.Assert.assertNotNull(shape48);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_90;
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double3 = rectangleInsets1.calculateBottomOutset((double) (-1L));
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = org.jfree.chart.util.RectangleAnchor.TOP;
        boolean boolean5 = rectangleInsets1.equals((java.lang.Object) rectangleAnchor4);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor6 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        boolean boolean9 = textAnchor7.equals((java.lang.Object) 'a');
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType11 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition13 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor4, textBlockAnchor6, textAnchor7, (double) (-2208960000000L), categoryLabelWidthType11, (float) 3);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor14 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.text.TextAnchor textAnchor19 = null;
        org.jfree.chart.text.TextAnchor textAnchor21 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        java.awt.Shape shape22 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D16, (float) 1, (float) 0, textAnchor19, (double) 100L, textAnchor21);
        java.lang.String str23 = textAnchor21.toString();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType25 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition27 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor4, textBlockAnchor14, textAnchor21, 0.0d, categoryLabelWidthType25, (float) (short) 100);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions28 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions0, categoryLabelPosition27);
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor6);
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(categoryLabelWidthType11);
        org.junit.Assert.assertNotNull(textBlockAnchor14);
        org.junit.Assert.assertNotNull(textAnchor21);
        org.junit.Assert.assertNull(shape22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "TextAnchor.CENTER_RIGHT" + "'", str23.equals("TextAnchor.CENTER_RIGHT"));
        org.junit.Assert.assertNotNull(categoryLabelWidthType25);
        org.junit.Assert.assertNotNull(categoryLabelPositions28);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, 0.0d);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange4, (double) '#');
        numberAxis2.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        boolean boolean10 = numberAxis2.isNegativeArrowVisible();
        boolean boolean11 = numberAxis2.isTickMarksVisible();
        java.lang.String str12 = numberAxis2.getLabel();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean15 = numberAxis3D14.isInverted();
        org.jfree.data.time.DateRange dateRange16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis3D14.setRangeWithMargins((org.jfree.data.Range) dateRange16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, xYItemRenderer18);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str23 = numberAxis22.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange24 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange24, 0.0d);
        org.jfree.data.Range range28 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange24, (double) '#');
        numberAxis22.setDefaultAutoRange((org.jfree.data.Range) dateRange24);
        boolean boolean30 = numberAxis22.isNegativeArrowVisible();
        boolean boolean31 = numberAxis22.isTickMarksVisible();
        numberAxis22.setFixedAutoRange((double) 1);
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str36 = numberAxis35.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange37 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint39 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange37, 0.0d);
        org.jfree.data.Range range41 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange37, (double) '#');
        numberAxis35.setDefaultAutoRange((org.jfree.data.Range) dateRange37);
        boolean boolean43 = numberAxis35.isNegativeArrowVisible();
        boolean boolean44 = numberAxis35.isTickMarksVisible();
        java.lang.Object obj45 = numberAxis35.clone();
        java.awt.Font font50 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand51 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis35, (double) 11, 0.0d, (double) 'a', (double) 100, font50);
        java.awt.Graphics2D graphics2D52 = null;
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        markerAxisBand51.draw(graphics2D52, rectangle2D53, rectangle2D54, (double) 12, (double) 12);
        numberAxis22.setMarkerBand(markerAxisBand51);
        xYPlot19.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) numberAxis22);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder60 = xYPlot19.getSeriesRenderingOrder();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer61 = null;
        xYPlot19.setRenderer(xYItemRenderer61);
        xYPlot19.clearDomainMarkers();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D65 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.general.PieDataset pieDataset66 = null;
        org.jfree.chart.plot.PiePlot piePlot67 = new org.jfree.chart.plot.PiePlot(pieDataset66);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator68 = null;
        piePlot67.setToolTipGenerator(pieToolTipGenerator68);
        numberAxis3D65.setPlot((org.jfree.chart.plot.Plot) piePlot67);
        xYPlot19.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D65);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateRange16);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(dateRange24);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertNotNull(dateRange37);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(obj45);
        org.junit.Assert.assertNotNull(font50);
        org.junit.Assert.assertNotNull(seriesRenderingOrder60);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, (double) (-1310400001L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str4 = numberAxis3.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange5 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange5, 0.0d);
        org.jfree.data.Range range9 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange5, (double) '#');
        numberAxis3.setDefaultAutoRange((org.jfree.data.Range) dateRange5);
        boolean boolean11 = numberAxis3.isNegativeArrowVisible();
        boolean boolean12 = numberAxis3.isTickMarksVisible();
        java.lang.Object obj13 = numberAxis3.clone();
        java.awt.Font font18 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand19 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis3, (double) 11, 0.0d, (double) 'a', (double) 100, font18);
        java.awt.Paint paint20 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.text.TextBlock textBlock21 = org.jfree.chart.text.TextUtilities.createTextBlock("NO_CHANGE", font18, paint20);
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment23 = textTitle22.getHorizontalAlignment();
        java.util.List list32 = null;
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem33 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 1L, (java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.05d, (java.lang.Number) 5, (java.lang.Number) (-1), (java.lang.Number) 100.0d, (java.lang.Number) 0L, list32);
        boolean boolean34 = horizontalAlignment23.equals((java.lang.Object) 1.0f);
        textBlock21.setLineAlignment(horizontalAlignment23);
        textTitle0.setTextAlignment(horizontalAlignment23);
        textTitle0.setNotify(false);
        java.lang.String str39 = textTitle0.getURLText();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(dateRange5);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(textBlock21);
        org.junit.Assert.assertNotNull(horizontalAlignment23);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNull(str39);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Comparable comparable1 = null;
        try {
            java.lang.Number number3 = defaultCategoryDataset0.getValue(comparable1, (java.lang.Comparable) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowKey' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
        statisticalLineAndShapeRenderer2.setBaseShapesVisible(false);
        boolean boolean7 = statisticalLineAndShapeRenderer2.getItemShapeFilled((-2234650), (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.util.Rotation rotation3 = piePlot2.getDirection();
        org.jfree.chart.plot.Plot plot4 = piePlot2.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        piePlot2.datasetChanged(datasetChangeEvent5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        piePlot2.drawBackgroundImage(graphics2D7, rectangle2D8);
        java.awt.Paint paint10 = piePlot2.getBaseSectionOutlinePaint();
        java.awt.Paint paint11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot2.setBaseSectionPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart13.setTitle("({0}, {1}) = {3} - {4}");
        java.lang.Object obj16 = jFreeChart13.clone();
        jFreeChart13.fireChartChanged();
        jFreeChart13.setNotify(false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo23 = null;
        java.awt.image.BufferedImage bufferedImage24 = jFreeChart13.createBufferedImage((int) (byte) 10, 100, 12, chartRenderingInfo23);
        jFreeChart13.fireChartChanged();
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(bufferedImage24);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        int int0 = org.jfree.data.time.SerialDate.MONDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        double double0 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_Y_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 8.0d + "'", double0 == 8.0d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        int int2 = spreadsheetDate1.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.chart.ChartColor chartColor8 = new org.jfree.chart.ChartColor((int) (short) 0, (int) (byte) 100, (int) '#');
        boolean boolean9 = spreadsheetDate4.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate12 = spreadsheetDate4.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.chart.ChartColor chartColor18 = new org.jfree.chart.ChartColor((int) (short) 0, (int) (byte) 100, (int) '#');
        boolean boolean19 = spreadsheetDate14.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate22 = spreadsheetDate14.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SerialDate serialDate24 = serialDate22.getPreviousDayOfWeek(6);
        boolean boolean25 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate11, serialDate24);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.chart.ChartColor chartColor31 = new org.jfree.chart.ChartColor((int) (short) 0, (int) (byte) 100, (int) '#');
        boolean boolean32 = spreadsheetDate27.equals((java.lang.Object) (short) 0);
        int int33 = spreadsheetDate27.getDayOfWeek();
        boolean boolean34 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2 + "'", int33 == 2);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.chart.ChartColor chartColor6 = new org.jfree.chart.ChartColor((int) (short) 0, (int) (byte) 100, (int) '#');
        boolean boolean7 = spreadsheetDate2.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate10 = spreadsheetDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate9);
        try {
            org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (short) 0, serialDate10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(serialDate10);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.data.time.DateRange dateRange1 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange0);
        java.lang.String str2 = dateRange1.toString();
        org.junit.Assert.assertNotNull(dateRange0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str2.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = lineAndShapeRenderer0.getToolTipGenerator(2, 1);
        lineAndShapeRenderer0.setSeriesShapesFilled((int) ' ', (java.lang.Boolean) false);
        boolean boolean7 = lineAndShapeRenderer0.getBaseLinesVisible();
        lineAndShapeRenderer0.setBaseLinesVisible(false);
        org.junit.Assert.assertNull(categoryToolTipGenerator3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("RectangleEdge.LEFT");
        java.lang.Object obj2 = taskSeries1.clone();
        taskSeries1.removeAll();
        org.jfree.data.time.TimePeriod timePeriod5 = null;
        org.jfree.data.gantt.Task task6 = new org.jfree.data.gantt.Task("hi!", timePeriod5);
        java.lang.Object obj7 = null;
        boolean boolean8 = task6.equals(obj7);
        org.jfree.data.time.TimePeriod timePeriod10 = null;
        org.jfree.data.gantt.Task task11 = new org.jfree.data.gantt.Task("hi!", timePeriod10);
        java.lang.Object obj12 = null;
        boolean boolean13 = task11.equals(obj12);
        task11.setPercentComplete((java.lang.Double) 90.0d);
        task6.removeSubtask(task11);
        taskSeries1.remove(task11);
        taskSeries1.setNotify(false);
        taskSeries1.removeAll();
        boolean boolean21 = taskSeries1.getNotify();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.util.Rotation rotation3 = piePlot2.getDirection();
        org.jfree.chart.plot.Plot plot4 = piePlot2.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        piePlot2.datasetChanged(datasetChangeEvent5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        piePlot2.drawBackgroundImage(graphics2D7, rectangle2D8);
        java.awt.Paint paint10 = piePlot2.getBaseSectionOutlinePaint();
        java.awt.Paint paint11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot2.setBaseSectionPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart13.setTitle("({0}, {1}) = {3} - {4}");
        org.jfree.chart.text.TextLine textLine17 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.text.TextFragment textFragment18 = textLine17.getFirstTextFragment();
        java.awt.Font font19 = textFragment18.getFont();
        boolean boolean20 = jFreeChart13.equals((java.lang.Object) textFragment18);
        java.lang.String str21 = textFragment18.getText();
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(textFragment18);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list1 = taskSeriesCollection0.getRowKeys();
        int int3 = taskSeriesCollection0.indexOf((java.lang.Comparable) "({0}, {1}) = {2}");
        try {
            java.lang.Comparable comparable5 = taskSeriesCollection0.getSeriesKey((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "({0}, {1}) = {3} - {4}", "", image3, "hi!", "hi!", "({0}, {1}) = {3} - {4}");
        java.util.List list8 = projectInfo7.getContributors();
        projectInfo7.setLicenceText("Last");
        org.junit.Assert.assertNull(list8);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = piePlot1.getDirection();
        org.jfree.chart.plot.Plot plot3 = piePlot1.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        piePlot1.datasetChanged(datasetChangeEvent4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        piePlot1.drawBackgroundImage(graphics2D6, rectangle2D7);
        java.awt.Paint paint9 = piePlot1.getBaseSectionOutlinePaint();
        java.awt.Paint paint11 = piePlot1.getSectionPaint((java.lang.Comparable) 10);
        boolean boolean12 = piePlot1.getLabelLinksVisible();
        org.junit.Assert.assertNotNull(rotation2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.chart.axis.NumberAxis numberAxis0 = null;
        java.awt.Font font5 = null;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis0, (double) 10, (double) 100, (double) '4', (double) (byte) -1, font5);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        boolean boolean8 = markerAxisBand6.equals((java.lang.Object) rectangleAnchor7);
        org.jfree.chart.plot.IntervalMarker intervalMarker9 = null;
        markerAxisBand6.addMarker(intervalMarker9);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, 0.0d);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange4, (double) '#');
        numberAxis2.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        boolean boolean10 = numberAxis2.isNegativeArrowVisible();
        boolean boolean11 = numberAxis2.isTickMarksVisible();
        java.lang.String str12 = numberAxis2.getLabel();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean15 = numberAxis3D14.isInverted();
        org.jfree.data.time.DateRange dateRange16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis3D14.setRangeWithMargins((org.jfree.data.Range) dateRange16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, xYItemRenderer18);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str23 = numberAxis22.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange24 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange24, 0.0d);
        org.jfree.data.Range range28 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange24, (double) '#');
        numberAxis22.setDefaultAutoRange((org.jfree.data.Range) dateRange24);
        boolean boolean30 = numberAxis22.isNegativeArrowVisible();
        boolean boolean31 = numberAxis22.isTickMarksVisible();
        numberAxis22.setFixedAutoRange((double) 1);
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str36 = numberAxis35.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange37 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint39 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange37, 0.0d);
        org.jfree.data.Range range41 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange37, (double) '#');
        numberAxis35.setDefaultAutoRange((org.jfree.data.Range) dateRange37);
        boolean boolean43 = numberAxis35.isNegativeArrowVisible();
        boolean boolean44 = numberAxis35.isTickMarksVisible();
        java.lang.Object obj45 = numberAxis35.clone();
        java.awt.Font font50 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand51 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis35, (double) 11, 0.0d, (double) 'a', (double) 100, font50);
        java.awt.Graphics2D graphics2D52 = null;
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        markerAxisBand51.draw(graphics2D52, rectangle2D53, rectangle2D54, (double) 12, (double) 12);
        numberAxis22.setMarkerBand(markerAxisBand51);
        xYPlot19.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) numberAxis22);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer60 = null;
        xYPlot19.setRenderer(xYItemRenderer60);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateRange16);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(dateRange24);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertNotNull(dateRange37);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(obj45);
        org.junit.Assert.assertNotNull(font50);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        java.awt.Paint paint1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        barRenderer2.setBaseToolTipGenerator(categoryToolTipGenerator3, false);
        boolean boolean6 = barRenderer2.getBaseCreateEntities();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        barRenderer2.setSeriesStroke((int) (short) 100, stroke8, false);
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker(0.0d, paint1, stroke8);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean14 = numberAxis13.getAutoRangeStickyZero();
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        numberAxis13.setTickMarkStroke(stroke15);
        valueMarker11.setOutlineStroke(stroke15);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        valueMarker11.setLabelAnchor(rectangleAnchor18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions21 = categoryAxis3D20.getCategoryLabelPositions();
        org.jfree.chart.text.TextLine textLine24 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.text.TextFragment textFragment25 = textLine24.getFirstTextFragment();
        java.awt.Font font26 = textFragment25.getFont();
        java.awt.Font font27 = textFragment25.getFont();
        categoryAxis3D20.setTickLabelFont((java.lang.Comparable) (short) 1, font27);
        valueMarker11.setLabelFont(font27);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(rectangleAnchor18);
        org.junit.Assert.assertNotNull(categoryLabelPositions21);
        org.junit.Assert.assertNotNull(textFragment25);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(font27);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        java.awt.Shape shape5 = null;
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape12 = null;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color14 = java.awt.Color.black;
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("", "hi!", "hi!", "", true, shape5, false, (java.awt.Paint) color7, false, paint9, stroke10, true, shape12, stroke13, (java.awt.Paint) color14);
        java.awt.Stroke stroke16 = legendItem15.getLineStroke();
        legendItem15.setSeriesIndex((int) (short) 0);
        int int19 = legendItem15.getSeriesIndex();
        java.lang.String str20 = legendItem15.getDescription();
        boolean boolean21 = legendItem15.isLineVisible();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor4 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.text.TextAnchor textAnchor9 = null;
        org.jfree.chart.text.TextAnchor textAnchor11 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        java.awt.Shape shape12 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D6, (float) 1, (float) 0, textAnchor9, (double) 100L, textAnchor11);
        org.jfree.chart.text.TextAnchor textAnchor13 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor4, textAnchor11, textAnchor13, (double) (byte) 100);
        org.jfree.chart.text.TextAnchor textAnchor17 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        boolean boolean19 = textAnchor17.equals((java.lang.Object) 'a');
        try {
            java.awt.Shape shape20 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("{0}", graphics2D1, (float) (-459), (float) 1, textAnchor13, 1.0d, textAnchor17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelAnchor4);
        org.junit.Assert.assertNotNull(textAnchor11);
        org.junit.Assert.assertNull(shape12);
        org.junit.Assert.assertNotNull(textAnchor13);
        org.junit.Assert.assertNotNull(textAnchor17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("TextBlockAnchor.CENTER_RIGHT");
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange3, 0.0d);
        org.jfree.data.Range range7 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange3, (double) '#');
        numberAxis1.setDefaultAutoRange((org.jfree.data.Range) dateRange3);
        org.jfree.data.Range range11 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange3, 0.0d, (double) (byte) -1);
        java.util.Date date12 = dateRange3.getUpperDate();
        org.jfree.chart.text.TextAnchor textAnchor14 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.text.TextAnchor textAnchor19 = null;
        org.jfree.chart.text.TextAnchor textAnchor21 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        java.awt.Shape shape22 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D16, (float) 1, (float) 0, textAnchor19, (double) 100L, textAnchor21);
        java.lang.String str23 = textAnchor21.toString();
        org.jfree.chart.axis.DateTick dateTick25 = new org.jfree.chart.axis.DateTick(date12, "TextAnchor.CENTER_RIGHT", textAnchor14, textAnchor21, (double) (-1.0f));
        java.util.Date date26 = dateTick25.getDate();
        java.lang.String str27 = dateTick25.toString();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(dateRange3);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(textAnchor14);
        org.junit.Assert.assertNotNull(textAnchor21);
        org.junit.Assert.assertNull(shape22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "TextAnchor.CENTER_RIGHT" + "'", str23.equals("TextAnchor.CENTER_RIGHT"));
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "TextAnchor.CENTER_RIGHT" + "'", str27.equals("TextAnchor.CENTER_RIGHT"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, 0.0d);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange4, (double) '#');
        numberAxis2.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        boolean boolean10 = numberAxis2.isNegativeArrowVisible();
        boolean boolean11 = numberAxis2.isTickMarksVisible();
        java.lang.Object obj12 = numberAxis2.clone();
        numberAxis2.setAutoRangeIncludesZero(true);
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str17 = numberAxis16.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange18 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange18, 0.0d);
        org.jfree.data.Range range22 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange18, (double) '#');
        numberAxis16.setDefaultAutoRange((org.jfree.data.Range) dateRange18);
        boolean boolean24 = numberAxis16.isNegativeArrowVisible();
        boolean boolean25 = numberAxis16.isTickMarksVisible();
        java.lang.Object obj26 = numberAxis16.clone();
        java.awt.Font font31 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand32 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis16, (double) 11, 0.0d, (double) 'a', (double) 100, font31);
        numberAxis2.setTickLabelFont(font31);
        org.jfree.data.general.PieDataset pieDataset34 = null;
        org.jfree.chart.plot.PiePlot piePlot35 = new org.jfree.chart.plot.PiePlot(pieDataset34);
        org.jfree.chart.util.Rotation rotation36 = piePlot35.getDirection();
        org.jfree.chart.plot.Plot plot37 = piePlot35.getParent();
        org.jfree.chart.plot.Plot plot38 = piePlot35.getRootPlot();
        org.jfree.chart.JFreeChart jFreeChart40 = new org.jfree.chart.JFreeChart("PlotOrientation.VERTICAL", font31, (org.jfree.chart.plot.Plot) piePlot35, false);
        boolean boolean41 = piePlot35.getSectionOutlinesVisible();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(dateRange18);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(rotation36);
        org.junit.Assert.assertNull(plot37);
        org.junit.Assert.assertNotNull(plot38);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("PlotOrientation.VERTICAL");
        categoryAxis3D2.removeCategoryLabelToolTip((java.lang.Comparable) 10);
        boolean boolean5 = gradientPaintTransformType0.equals((java.lang.Object) 10);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator1 = lineAndShapeRenderer0.getBaseURLGenerator();
        boolean boolean3 = lineAndShapeRenderer0.isSeriesVisibleInLegend((int) ' ');
        org.junit.Assert.assertNull(categoryURLGenerator1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        java.awt.Color color0 = java.awt.Color.PINK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit(0, 0, dateFormat2);
        org.jfree.data.KeyToGroupMap keyToGroupMap5 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) true);
        int int7 = keyToGroupMap5.getKeyCount((java.lang.Comparable) 0.05d);
        java.util.List list8 = keyToGroupMap5.getGroups();
        boolean boolean9 = dateTickUnit3.equals((java.lang.Object) keyToGroupMap5);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod((long) 10, (long) 'a');
        java.util.Date date13 = simpleTimePeriod12.getEnd();
        java.util.Date date14 = dateTickUnit3.addToDate(date13);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date14);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getFixedAutoRange();
        java.text.NumberFormat numberFormat4 = numberAxis2.getNumberFormatOverride();
        boolean boolean5 = numberAxis2.isVerticalTickLabels();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, polarItemRenderer6);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.util.Rotation rotation10 = piePlot9.getDirection();
        org.jfree.chart.plot.Plot plot11 = piePlot9.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = null;
        piePlot9.datasetChanged(datasetChangeEvent12);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        piePlot9.drawBackgroundImage(graphics2D14, rectangle2D15);
        java.awt.Paint paint17 = piePlot9.getBaseSectionOutlinePaint();
        java.awt.Paint paint18 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot9.setBaseSectionPaint(paint18);
        polarPlot7.setAngleGridlinePaint(paint18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        polarPlot7.zoomRangeAxes((double) 1577865599999L, 0.0d, plotRenderingInfo23, point2D24);
        java.lang.Object obj26 = polarPlot7.clone();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNull(numberFormat4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rotation10);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(obj26);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setDrawOutlines(true);
        boolean boolean3 = lineAndShapeRenderer0.getBaseLinesVisible();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        org.jfree.chart.util.Rotation rotation6 = piePlot5.getDirection();
        org.jfree.chart.plot.Plot plot7 = piePlot5.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        piePlot5.datasetChanged(datasetChangeEvent8);
        java.awt.Stroke stroke11 = piePlot5.getSectionOutlineStroke((java.lang.Comparable) (short) 100);
        java.awt.Paint paint12 = piePlot5.getNoDataMessagePaint();
        lineAndShapeRenderer0.setBasePaint(paint12, false);
        boolean boolean15 = lineAndShapeRenderer0.getBaseShapesFilled();
        org.jfree.chart.LegendItem legendItem18 = lineAndShapeRenderer0.getLegendItem((int) (byte) 1, 15);
        lineAndShapeRenderer0.setSeriesShapesVisible((int) ' ', false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(rotation6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(legendItem18);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = barRenderer0.getBaseToolTipGenerator();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = null;
        barRenderer0.setSeriesURLGenerator(0, categoryURLGenerator3, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator6, false);
        java.awt.Paint paint10 = barRenderer0.lookupSeriesPaint(2);
        org.junit.Assert.assertNull(categoryToolTipGenerator1);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("RectangleEdge.LEFT");
        java.lang.Object obj2 = taskSeries1.clone();
        taskSeries1.removeAll();
        org.jfree.data.time.TimePeriod timePeriod5 = null;
        org.jfree.data.gantt.Task task6 = new org.jfree.data.gantt.Task("hi!", timePeriod5);
        java.lang.Object obj7 = null;
        boolean boolean8 = task6.equals(obj7);
        org.jfree.data.time.TimePeriod timePeriod10 = null;
        org.jfree.data.gantt.Task task11 = new org.jfree.data.gantt.Task("hi!", timePeriod10);
        java.lang.Object obj12 = null;
        boolean boolean13 = task11.equals(obj12);
        task11.setPercentComplete((java.lang.Double) 90.0d);
        task6.removeSubtask(task11);
        taskSeries1.remove(task11);
        taskSeries1.setNotify(false);
        java.util.List list20 = taskSeries1.getTasks();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(list20);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 255, 0.0d, false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange0, 0.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = rectangleConstraint2.toUnconstrainedHeight();
        org.jfree.data.Range range4 = rectangleConstraint3.getWidthRange();
        org.jfree.data.Range range7 = org.jfree.data.Range.shift(range4, 0.0d, false);
        org.junit.Assert.assertNotNull(dateRange0);
        org.junit.Assert.assertNotNull(rectangleConstraint3);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(range7);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("PlotOrientation.VERTICAL", graphics2D1, 0.0f, 0.0f, (double) 5, (float) (-1L), (float) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.lang.Object obj1 = defaultKeyedValues2D0.clone();
        java.text.DateFormat dateFormat5 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = new org.jfree.chart.axis.DateTickUnit(0, 0, dateFormat5);
        defaultKeyedValues2D0.addValue((java.lang.Number) (-0.0d), (java.lang.Comparable) 0, (java.lang.Comparable) 1.0E-5d);
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.junit.Assert.assertNotNull(dateTickUnit0);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "({0}, {1}) = {3} - {4}", "", image3, "hi!", "hi!", "({0}, {1}) = {3} - {4}");
        projectInfo7.setInfo("RectangleEdge.LEFT");
        java.awt.Image image10 = projectInfo7.getLogo();
        java.lang.String str11 = projectInfo7.getCopyright();
        projectInfo7.setVersion("ChartEntity: tooltip = ");
        org.junit.Assert.assertNull(image10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 11);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape2, "RectangleEdge.LEFT", "NO_CHANGE");
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity8 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) 8.0d, shape2, "({0}, {1}) = {2}", "SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str9 = categoryLabelEntity8.toString();
        java.lang.String str10 = categoryLabelEntity8.toString();
        java.lang.String str11 = categoryLabelEntity8.toString();
        java.lang.String str12 = categoryLabelEntity8.getShapeType();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "CategoryLabelEntity: category=8.0, tooltip=({0}, {1}) = {2}, url=SerialDate.weekInMonthToString(): invalid code." + "'", str9.equals("CategoryLabelEntity: category=8.0, tooltip=({0}, {1}) = {2}, url=SerialDate.weekInMonthToString(): invalid code."));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "CategoryLabelEntity: category=8.0, tooltip=({0}, {1}) = {2}, url=SerialDate.weekInMonthToString(): invalid code." + "'", str10.equals("CategoryLabelEntity: category=8.0, tooltip=({0}, {1}) = {2}, url=SerialDate.weekInMonthToString(): invalid code."));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "CategoryLabelEntity: category=8.0, tooltip=({0}, {1}) = {2}, url=SerialDate.weekInMonthToString(): invalid code." + "'", str11.equals("CategoryLabelEntity: category=8.0, tooltip=({0}, {1}) = {2}, url=SerialDate.weekInMonthToString(): invalid code."));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "poly" + "'", str12.equals("poly"));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, 0.0d);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange4, (double) '#');
        numberAxis2.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        boolean boolean10 = numberAxis2.isNegativeArrowVisible();
        boolean boolean11 = numberAxis2.isTickMarksVisible();
        java.lang.String str12 = numberAxis2.getLabel();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean15 = numberAxis3D14.isInverted();
        org.jfree.data.time.DateRange dateRange16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis3D14.setRangeWithMargins((org.jfree.data.Range) dateRange16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, xYItemRenderer18);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray20 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot19.setRenderers(xYItemRendererArray20);
        int int22 = xYPlot19.getSeriesCount();
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double26 = numberAxis25.getFixedAutoRange();
        java.text.NumberFormat numberFormat27 = numberAxis25.getNumberFormatOverride();
        java.awt.Paint paint28 = numberAxis25.getAxisLinePaint();
        java.lang.String str29 = numberAxis25.getLabelToolTip();
        xYPlot19.setDomainAxis((int) '#', (org.jfree.chart.axis.ValueAxis) numberAxis25, true);
        java.awt.Paint paint32 = xYPlot19.getRangeZeroBaselinePaint();
        java.awt.Stroke stroke33 = xYPlot19.getRangeCrosshairStroke();
        xYPlot19.setWeight(10);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateRange16);
        org.junit.Assert.assertNotNull(xYItemRendererArray20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNull(numberFormat27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(stroke33);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.chart.ChartColor chartColor5 = new org.jfree.chart.ChartColor((int) (short) 0, (int) (byte) 100, (int) '#');
        boolean boolean6 = spreadsheetDate1.equals((java.lang.Object) (short) 0);
        int int7 = spreadsheetDate1.getDayOfWeek();
        int int8 = spreadsheetDate1.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.chart.ChartColor chartColor14 = new org.jfree.chart.ChartColor((int) (short) 0, (int) (byte) 100, (int) '#');
        boolean boolean15 = spreadsheetDate10.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate18 = spreadsheetDate10.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate17);
        boolean boolean19 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.general.PieDataset pieDataset20 = null;
        org.jfree.chart.plot.PiePlot piePlot21 = new org.jfree.chart.plot.PiePlot(pieDataset20);
        org.jfree.chart.util.Rotation rotation22 = piePlot21.getDirection();
        org.jfree.chart.plot.Plot plot23 = piePlot21.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent24 = null;
        piePlot21.datasetChanged(datasetChangeEvent24);
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        piePlot21.drawBackgroundImage(graphics2D26, rectangle2D27);
        boolean boolean29 = piePlot21.getSectionOutlinesVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        piePlot21.setInsets(rectangleInsets30, true);
        double double33 = rectangleInsets30.getRight();
        org.jfree.data.general.PieDataset pieDataset34 = null;
        org.jfree.chart.plot.PiePlot piePlot35 = new org.jfree.chart.plot.PiePlot(pieDataset34);
        org.jfree.chart.util.Rotation rotation36 = piePlot35.getDirection();
        org.jfree.chart.plot.Plot plot37 = piePlot35.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent38 = null;
        piePlot35.datasetChanged(datasetChangeEvent38);
        java.awt.Stroke stroke40 = null;
        piePlot35.setLabelOutlineStroke(stroke40);
        java.lang.Number[] numberArray48 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray58 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray63 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray68 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray73 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[][] numberArray74 = new java.lang.Number[][] { numberArray48, numberArray53, numberArray58, numberArray63, numberArray68, numberArray73 };
        org.jfree.data.category.CategoryDataset categoryDataset75 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray74);
        org.jfree.data.general.PieDataset pieDataset77 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset75, (int) (short) 1);
        piePlot35.setDataset(pieDataset77);
        java.awt.Paint paint79 = piePlot35.getLabelOutlinePaint();
        org.jfree.chart.block.BlockBorder blockBorder80 = new org.jfree.chart.block.BlockBorder(rectangleInsets30, paint79);
        try {
            int int81 = spreadsheetDate1.compareTo((java.lang.Object) paint79);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.awt.Color cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(rotation22);
        org.junit.Assert.assertNull(plot23);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 3.0d + "'", double33 == 3.0d);
        org.junit.Assert.assertNotNull(rotation36);
        org.junit.Assert.assertNull(plot37);
        org.junit.Assert.assertNotNull(numberArray48);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray58);
        org.junit.Assert.assertNotNull(numberArray63);
        org.junit.Assert.assertNotNull(numberArray68);
        org.junit.Assert.assertNotNull(numberArray73);
        org.junit.Assert.assertNotNull(numberArray74);
        org.junit.Assert.assertNotNull(categoryDataset75);
        org.junit.Assert.assertNotNull(pieDataset77);
        org.junit.Assert.assertNotNull(paint79);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setMaximumBarWidth(8.0d);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getBaseURLGenerator();
        org.junit.Assert.assertNull(categoryURLGenerator3);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.chart.renderer.category.AreaRenderer areaRenderer0 = new org.jfree.chart.renderer.category.AreaRenderer();
        java.awt.Paint paint2 = areaRenderer0.getSeriesItemLabelPaint((-1));
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = null;
        areaRenderer0.setSeriesItemLabelGenerator((int) '4', categoryItemLabelGenerator4, false);
        java.awt.Paint paint7 = areaRenderer0.getBaseOutlinePaint();
        org.jfree.chart.LegendItem legendItem10 = areaRenderer0.getLegendItem(12, 100);
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(legendItem10);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.util.List list1 = blockContainer0.getBlocks();
        blockContainer0.clear();
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "ChartChangeEventType.DATASET_UPDATED");
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double7 = numberAxis6.getFixedAutoRange();
        java.text.NumberFormat numberFormat8 = numberAxis6.getNumberFormatOverride();
        boolean boolean9 = numberAxis6.isVerticalTickLabels();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) numberAxis6, polarItemRenderer10);
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        org.jfree.chart.util.Rotation rotation14 = piePlot13.getDirection();
        org.jfree.chart.plot.Plot plot15 = piePlot13.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent16 = null;
        piePlot13.datasetChanged(datasetChangeEvent16);
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        piePlot13.drawBackgroundImage(graphics2D18, rectangle2D19);
        java.awt.Paint paint21 = piePlot13.getBaseSectionOutlinePaint();
        java.awt.Paint paint22 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot13.setBaseSectionPaint(paint22);
        polarPlot11.setAngleGridlinePaint(paint22);
        org.jfree.chart.text.TextFragment textFragment25 = new org.jfree.chart.text.TextFragment("Last", font3, paint22);
        boolean boolean26 = categoryMarker1.equals((java.lang.Object) paint22);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(numberFormat8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rotation14);
        org.junit.Assert.assertNull(plot15);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = barRenderer0.getBaseToolTipGenerator();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = null;
        barRenderer0.setSeriesURLGenerator(0, categoryURLGenerator3, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator6, false);
        java.lang.Boolean boolean10 = barRenderer0.getSeriesItemLabelsVisible(500);
        org.junit.Assert.assertNull(categoryToolTipGenerator1);
        org.junit.Assert.assertNull(boolean10);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.text.TextFragment textFragment2 = textLine1.getFirstTextFragment();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer5 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean6 = textAnchor4.equals((java.lang.Object) intervalBarRenderer5);
        try {
            float float7 = textFragment2.calculateBaselineOffset(graphics2D3, textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textFragment2);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(xYDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setMaximumBarWidth(8.0d);
        java.awt.Shape shape9 = null;
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape16 = null;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color18 = java.awt.Color.black;
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("", "hi!", "hi!", "", true, shape9, false, (java.awt.Paint) color11, false, paint13, stroke14, true, shape16, stroke17, (java.awt.Paint) color18);
        barRenderer0.setSeriesStroke(2, stroke17);
        double double21 = barRenderer0.getItemLabelAnchorOffset();
        barRenderer0.setBaseSeriesVisible(false, false);
        java.awt.Paint paint27 = barRenderer0.getItemLabelPaint(5, 10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator29 = barRenderer0.getSeriesToolTipGenerator(10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 2.0d + "'", double21 == 2.0d);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNull(categoryToolTipGenerator29);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str6 = numberAxis5.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange7 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange7, 0.0d);
        org.jfree.data.Range range11 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange7, (double) '#');
        numberAxis5.setDefaultAutoRange((org.jfree.data.Range) dateRange7);
        boolean boolean13 = numberAxis5.isNegativeArrowVisible();
        boolean boolean14 = numberAxis5.isTickMarksVisible();
        java.lang.String str15 = numberAxis5.getLabel();
        boolean boolean16 = numberAxis5.getAutoRangeStickyZero();
        boolean boolean17 = numberAxis5.isPositiveArrowVisible();
        java.awt.Shape shape18 = numberAxis5.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str21 = numberAxis20.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange22 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint24 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange22, 0.0d);
        org.jfree.data.Range range26 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange22, (double) '#');
        numberAxis20.setDefaultAutoRange((org.jfree.data.Range) dateRange22);
        boolean boolean28 = numberAxis20.isNegativeArrowVisible();
        boolean boolean29 = numberAxis20.isTickMarksVisible();
        org.jfree.chart.plot.Plot plot30 = null;
        numberAxis20.setPlot(plot30);
        org.jfree.data.general.PieDataset pieDataset32 = null;
        org.jfree.chart.plot.PiePlot piePlot33 = new org.jfree.chart.plot.PiePlot(pieDataset32);
        org.jfree.chart.util.Rotation rotation34 = piePlot33.getDirection();
        org.jfree.chart.plot.Plot plot35 = piePlot33.getParent();
        org.jfree.chart.plot.Plot plot36 = piePlot33.getRootPlot();
        java.awt.Color color37 = java.awt.Color.MAGENTA;
        piePlot33.setOutlinePaint((java.awt.Paint) color37);
        int int39 = piePlot33.getBackgroundImageAlignment();
        java.awt.Paint paint40 = piePlot33.getOutlinePaint();
        boolean boolean41 = numberAxis20.hasListener((java.util.EventListener) piePlot33);
        java.awt.Paint paint42 = numberAxis20.getAxisLinePaint();
        java.awt.Shape shape43 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Color color44 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic45 = new org.jfree.chart.title.LegendGraphic(shape43, (java.awt.Paint) color44);
        org.jfree.data.general.PieDataset pieDataset46 = null;
        org.jfree.chart.plot.PiePlot piePlot47 = new org.jfree.chart.plot.PiePlot(pieDataset46);
        org.jfree.chart.util.Rotation rotation48 = piePlot47.getDirection();
        org.jfree.chart.plot.Plot plot49 = piePlot47.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent50 = null;
        piePlot47.datasetChanged(datasetChangeEvent50);
        java.awt.Graphics2D graphics2D52 = null;
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        piePlot47.drawBackgroundImage(graphics2D52, rectangle2D53);
        java.awt.Shape shape60 = null;
        java.awt.Color color62 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Paint paint64 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke65 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape67 = null;
        java.awt.Stroke stroke68 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color69 = java.awt.Color.black;
        org.jfree.chart.LegendItem legendItem70 = new org.jfree.chart.LegendItem("", "hi!", "hi!", "", true, shape60, false, (java.awt.Paint) color62, false, paint64, stroke65, true, shape67, stroke68, (java.awt.Paint) color69);
        java.awt.Stroke stroke71 = legendItem70.getLineStroke();
        piePlot47.setBaseSectionOutlineStroke(stroke71);
        legendGraphic45.setOutlineStroke(stroke71);
        org.jfree.data.general.PieDataset pieDataset75 = null;
        org.jfree.chart.plot.PiePlot piePlot76 = new org.jfree.chart.plot.PiePlot(pieDataset75);
        org.jfree.chart.util.Rotation rotation77 = piePlot76.getDirection();
        org.jfree.chart.plot.Plot plot78 = piePlot76.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent79 = null;
        piePlot76.datasetChanged(datasetChangeEvent79);
        java.awt.Graphics2D graphics2D81 = null;
        java.awt.geom.Rectangle2D rectangle2D82 = null;
        piePlot76.drawBackgroundImage(graphics2D81, rectangle2D82);
        java.awt.Paint paint84 = piePlot76.getBaseSectionOutlinePaint();
        java.awt.Paint paint85 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot76.setBaseSectionPaint(paint85);
        org.jfree.chart.JFreeChart jFreeChart87 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot76);
        jFreeChart87.setTitle("({0}, {1}) = {3} - {4}");
        org.jfree.chart.title.TextTitle textTitle90 = jFreeChart87.getTitle();
        org.jfree.chart.title.TextTitle textTitle91 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment92 = textTitle91.getHorizontalAlignment();
        textTitle91.setExpandToFitSpace(true);
        jFreeChart87.removeSubtitle((org.jfree.chart.title.Title) textTitle91);
        java.awt.Color color96 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        jFreeChart87.setBackgroundPaint((java.awt.Paint) color96);
        try {
            org.jfree.chart.LegendItem legendItem98 = new org.jfree.chart.LegendItem(attributedString0, "", "", "PlotOrientation.VERTICAL", shape18, paint42, stroke71, (java.awt.Paint) color96);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(dateRange7);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(dateRange22);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(rotation34);
        org.junit.Assert.assertNull(plot35);
        org.junit.Assert.assertNotNull(plot36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 15 + "'", int39 == 15);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(rotation48);
        org.junit.Assert.assertNull(plot49);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertNotNull(paint64);
        org.junit.Assert.assertNotNull(stroke65);
        org.junit.Assert.assertNotNull(stroke68);
        org.junit.Assert.assertNotNull(color69);
        org.junit.Assert.assertNotNull(stroke71);
        org.junit.Assert.assertNotNull(rotation77);
        org.junit.Assert.assertNull(plot78);
        org.junit.Assert.assertNotNull(paint84);
        org.junit.Assert.assertNotNull(paint85);
        org.junit.Assert.assertNotNull(textTitle90);
        org.junit.Assert.assertNotNull(horizontalAlignment92);
        org.junit.Assert.assertNotNull(color96);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getFixedAutoRange();
        java.text.NumberFormat numberFormat4 = numberAxis2.getNumberFormatOverride();
        boolean boolean5 = numberAxis2.isVerticalTickLabels();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, polarItemRenderer6);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.util.Rotation rotation10 = piePlot9.getDirection();
        org.jfree.chart.plot.Plot plot11 = piePlot9.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = null;
        piePlot9.datasetChanged(datasetChangeEvent12);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        piePlot9.drawBackgroundImage(graphics2D14, rectangle2D15);
        java.awt.Paint paint17 = piePlot9.getBaseSectionOutlinePaint();
        java.awt.Paint paint18 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot9.setBaseSectionPaint(paint18);
        polarPlot7.setAngleGridlinePaint(paint18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        polarPlot7.zoomRangeAxes((double) 1577865599999L, 0.0d, plotRenderingInfo23, point2D24);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        java.awt.geom.Point2D point2D28 = null;
        polarPlot7.zoomRangeAxes((double) ' ', plotRenderingInfo27, point2D28);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNull(numberFormat4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rotation10);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.zoomRange(0.0d, 10.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis1.getTickUnit();
        dateAxis0.setTickUnit(dateTickUnit5, false, true);
        java.awt.Shape shape9 = dateAxis0.getUpArrow();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        dateAxis10.zoomRange(0.0d, 10.0d);
        java.util.Date date14 = dateAxis10.getMinimumDate();
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str18 = numberAxis17.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange19 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange19, 0.0d);
        org.jfree.data.Range range23 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange19, (double) '#');
        numberAxis17.setDefaultAutoRange((org.jfree.data.Range) dateRange19);
        boolean boolean25 = numberAxis17.isNegativeArrowVisible();
        boolean boolean26 = numberAxis17.isTickMarksVisible();
        java.lang.String str27 = numberAxis17.getLabel();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D29 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean30 = numberAxis3D29.isInverted();
        org.jfree.data.time.DateRange dateRange31 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis3D29.setRangeWithMargins((org.jfree.data.Range) dateRange31);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) numberAxis17, (org.jfree.chart.axis.ValueAxis) numberAxis3D29, xYItemRenderer33);
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str38 = numberAxis37.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange39 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint41 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange39, 0.0d);
        org.jfree.data.Range range43 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange39, (double) '#');
        numberAxis37.setDefaultAutoRange((org.jfree.data.Range) dateRange39);
        boolean boolean45 = numberAxis37.isNegativeArrowVisible();
        boolean boolean46 = numberAxis37.isTickMarksVisible();
        numberAxis37.setFixedAutoRange((double) 1);
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str51 = numberAxis50.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange52 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint54 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange52, 0.0d);
        org.jfree.data.Range range56 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange52, (double) '#');
        numberAxis50.setDefaultAutoRange((org.jfree.data.Range) dateRange52);
        boolean boolean58 = numberAxis50.isNegativeArrowVisible();
        boolean boolean59 = numberAxis50.isTickMarksVisible();
        java.lang.Object obj60 = numberAxis50.clone();
        java.awt.Font font65 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand66 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis50, (double) 11, 0.0d, (double) 'a', (double) 100, font65);
        java.awt.Graphics2D graphics2D67 = null;
        java.awt.geom.Rectangle2D rectangle2D68 = null;
        java.awt.geom.Rectangle2D rectangle2D69 = null;
        markerAxisBand66.draw(graphics2D67, rectangle2D68, rectangle2D69, (double) 12, (double) 12);
        numberAxis37.setMarkerBand(markerAxisBand66);
        xYPlot34.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) numberAxis37);
        org.jfree.chart.renderer.category.BarRenderer barRenderer75 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator76 = barRenderer75.getBaseToolTipGenerator();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator79 = barRenderer75.getToolTipGenerator((int) (byte) 100, 0);
        java.awt.Color color81 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        int int82 = color81.getRed();
        barRenderer75.setSeriesPaint(11, (java.awt.Paint) color81, true);
        xYPlot34.setRangeCrosshairPaint((java.awt.Paint) color81);
        java.awt.Graphics2D graphics2D86 = null;
        org.jfree.chart.util.Size2D size2D89 = new org.jfree.chart.util.Size2D((double) 0.0f, (double) 1L);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor92 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Rectangle2D rectangle2D93 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D89, (double) (byte) 100, (double) 10, rectangleAnchor92);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo95 = null;
        org.jfree.chart.plot.CrosshairState crosshairState96 = null;
        boolean boolean97 = xYPlot34.render(graphics2D86, rectangle2D93, (int) 'a', plotRenderingInfo95, crosshairState96);
        org.jfree.chart.util.RectangleEdge rectangleEdge98 = null;
        double double99 = dateAxis0.dateToJava2D(date14, rectangle2D93, rectangleEdge98);
        org.junit.Assert.assertNotNull(dateTickUnit5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(dateRange19);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "hi!" + "'", str27.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(dateRange31);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertNotNull(dateRange39);
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNull(str51);
        org.junit.Assert.assertNotNull(dateRange52);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(obj60);
        org.junit.Assert.assertNotNull(font65);
        org.junit.Assert.assertNull(categoryToolTipGenerator76);
        org.junit.Assert.assertNull(categoryToolTipGenerator79);
        org.junit.Assert.assertNotNull(color81);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 0 + "'", int82 == 0);
        org.junit.Assert.assertNotNull(rectangleAnchor92);
        org.junit.Assert.assertNotNull(rectangle2D93);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + false + "'", boolean97 == false);
        org.junit.Assert.assertTrue("'" + double99 + "' != '" + 0.0d + "'", double99 == 0.0d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.util.Rotation rotation3 = piePlot2.getDirection();
        org.jfree.chart.plot.Plot plot4 = piePlot2.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        piePlot2.datasetChanged(datasetChangeEvent5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        piePlot2.drawBackgroundImage(graphics2D7, rectangle2D8);
        java.awt.Paint paint10 = piePlot2.getBaseSectionOutlinePaint();
        java.awt.Paint paint11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot2.setBaseSectionPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart13.setTitle("({0}, {1}) = {3} - {4}");
        java.lang.Object obj16 = jFreeChart13.clone();
        java.util.List list17 = null;
        try {
            jFreeChart13.setSubtitles(list17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'subtitles' argument.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("({0}, {1}) = {2}");
        java.lang.Object obj2 = standardCategorySeriesLabelGenerator1.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        java.awt.Paint paint1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        barRenderer2.setBaseToolTipGenerator(categoryToolTipGenerator3, false);
        boolean boolean6 = barRenderer2.getBaseCreateEntities();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        barRenderer2.setSeriesStroke((int) (short) 100, stroke8, false);
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker(0.0d, paint1, stroke8);
        java.awt.Paint paint12 = valueMarker11.getPaint();
        valueMarker11.setLabel("SortOrder.ASCENDING");
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean17 = numberAxis16.getAutoRangeStickyZero();
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        numberAxis16.setTickMarkStroke(stroke18);
        valueMarker11.setOutlineStroke(stroke18);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("RectangleEdge.LEFT");
        java.lang.Object obj2 = taskSeries1.clone();
        taskSeries1.removeAll();
        org.jfree.data.time.TimePeriod timePeriod5 = null;
        org.jfree.data.gantt.Task task6 = new org.jfree.data.gantt.Task("hi!", timePeriod5);
        java.lang.Object obj7 = null;
        boolean boolean8 = task6.equals(obj7);
        org.jfree.data.time.TimePeriod timePeriod10 = null;
        org.jfree.data.gantt.Task task11 = new org.jfree.data.gantt.Task("hi!", timePeriod10);
        java.lang.Object obj12 = null;
        boolean boolean13 = task11.equals(obj12);
        task11.setPercentComplete((java.lang.Double) 90.0d);
        task6.removeSubtask(task11);
        taskSeries1.remove(task11);
        taskSeries1.setNotify(false);
        java.lang.Object obj20 = taskSeries1.clone();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(obj20);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        try {
            defaultKeyedValues0.removeValue((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray32);
        java.lang.String[] strArray36 = new java.lang.String[] { "SerialDate.weekInMonthToString(): invalid code.", "VerticalAlignment.TOP" };
        java.lang.Number[] numberArray44 = new java.lang.Number[] { (short) 1, 100.0f, 2, (short) -1, (-1.0f) };
        java.lang.Number[] numberArray50 = new java.lang.Number[] { (short) 1, 100.0f, 2, (short) -1, (-1.0f) };
        java.lang.Number[][] numberArray51 = new java.lang.Number[][] { numberArray44, numberArray50 };
        org.jfree.data.category.CategoryDataset categoryDataset52 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray51);
        java.lang.Number[][] numberArray53 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset54 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray36, numberArray51, numberArray53);
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset55 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray32, numberArray53);
        org.jfree.chart.axis.NumberAxis numberAxis58 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str59 = numberAxis58.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange60 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint62 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange60, 0.0d);
        org.jfree.data.Range range64 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange60, (double) '#');
        numberAxis58.setDefaultAutoRange((org.jfree.data.Range) dateRange60);
        org.jfree.data.Range range68 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange60, 0.0d, (double) (byte) -1);
        java.util.Date date69 = dateRange60.getUpperDate();
        org.jfree.chart.text.TextAnchor textAnchor71 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        java.awt.Graphics2D graphics2D73 = null;
        org.jfree.chart.text.TextAnchor textAnchor76 = null;
        org.jfree.chart.text.TextAnchor textAnchor78 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        java.awt.Shape shape79 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D73, (float) 1, (float) 0, textAnchor76, (double) 100L, textAnchor78);
        java.lang.String str80 = textAnchor78.toString();
        org.jfree.chart.axis.DateTick dateTick82 = new org.jfree.chart.axis.DateTick(date69, "TextAnchor.CENTER_RIGHT", textAnchor71, textAnchor78, (double) (-1.0f));
        java.util.Date date83 = dateTick82.getDate();
        try {
            java.lang.Number number84 = defaultIntervalCategoryDataset55.getValue((java.lang.Comparable) 3.0d, (java.lang.Comparable) date83);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(strArray36);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(categoryDataset52);
        org.junit.Assert.assertNull(str59);
        org.junit.Assert.assertNotNull(dateRange60);
        org.junit.Assert.assertNotNull(range64);
        org.junit.Assert.assertNotNull(range68);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertNotNull(textAnchor71);
        org.junit.Assert.assertNotNull(textAnchor78);
        org.junit.Assert.assertNull(shape79);
        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "TextAnchor.CENTER_RIGHT" + "'", str80.equals("TextAnchor.CENTER_RIGHT"));
        org.junit.Assert.assertNotNull(date83);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Color color1 = java.awt.Color.white;
        ganttRenderer0.setBasePaint((java.awt.Paint) color1);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double6 = numberAxis5.getFixedAutoRange();
        java.text.NumberFormat numberFormat7 = numberAxis5.getNumberFormatOverride();
        boolean boolean8 = numberAxis5.isVerticalTickLabels();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) numberAxis5, polarItemRenderer9);
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        org.jfree.chart.util.Rotation rotation13 = piePlot12.getDirection();
        org.jfree.chart.plot.Plot plot14 = piePlot12.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent15 = null;
        piePlot12.datasetChanged(datasetChangeEvent15);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        piePlot12.drawBackgroundImage(graphics2D17, rectangle2D18);
        java.awt.Paint paint20 = piePlot12.getBaseSectionOutlinePaint();
        java.awt.Paint paint21 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot12.setBaseSectionPaint(paint21);
        polarPlot10.setAngleGridlinePaint(paint21);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D25 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean26 = numberAxis3D25.isTickMarksVisible();
        org.jfree.chart.plot.Plot plot27 = numberAxis3D25.getPlot();
        org.jfree.data.Range range28 = polarPlot10.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D25);
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        polarPlot10.setDataset(xYDataset29);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D31 = new org.jfree.chart.renderer.category.BarRenderer3D();
        java.awt.Shape shape35 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 2, (float) 4);
        barRenderer3D31.setSeriesShape((int) (short) 1, shape35, false);
        double double38 = barRenderer3D31.getItemLabelAnchorOffset();
        boolean boolean40 = barRenderer3D31.isSeriesVisible(10);
        java.awt.Paint paint41 = barRenderer3D31.getWallPaint();
        polarPlot10.setAngleGridlinePaint(paint41);
        java.awt.Paint paint43 = polarPlot10.getAngleGridlinePaint();
        ganttRenderer0.setBaseFillPaint(paint43, false);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rotation13);
        org.junit.Assert.assertNull(plot14);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 2.0d + "'", double38 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(paint43);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange3, 0.0d);
        org.jfree.data.Range range7 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange3, (double) '#');
        numberAxis1.setDefaultAutoRange((org.jfree.data.Range) dateRange3);
        boolean boolean9 = numberAxis1.isNegativeArrowVisible();
        boolean boolean10 = numberAxis1.isTickMarksVisible();
        java.lang.String str11 = numberAxis1.getLabel();
        boolean boolean12 = numberAxis1.getAutoRangeStickyZero();
        numberAxis1.setTickMarkInsideLength((float) 0L);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(dateRange3);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = barRenderer0.getBaseToolTipGenerator();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = barRenderer0.getDrawingSupplier();
        int int3 = barRenderer0.getRowCount();
        java.awt.Stroke stroke6 = barRenderer0.getItemOutlineStroke(0, 0);
        org.junit.Assert.assertNull(categoryToolTipGenerator1);
        org.junit.Assert.assertNull(drawingSupplier2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = piePlot1.getDirection();
        org.jfree.chart.plot.Plot plot3 = piePlot1.getParent();
        org.jfree.chart.plot.Plot plot4 = piePlot1.getRootPlot();
        java.awt.Color color5 = java.awt.Color.MAGENTA;
        piePlot1.setOutlinePaint((java.awt.Paint) color5);
        java.awt.Stroke stroke7 = piePlot1.getOutlineStroke();
        piePlot1.zoom((double) (-1));
        org.jfree.chart.util.Size2D size2D12 = new org.jfree.chart.util.Size2D((double) 0.0f, (double) 1L);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Rectangle2D rectangle2D16 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D12, (double) (byte) 100, (double) 10, rectangleAnchor15);
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D16, (double) 1, (float) (byte) 0, (float) '4');
        piePlot1.setLegendItemShape(shape20);
        org.junit.Assert.assertNotNull(rotation2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(plot4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(shape20);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("RectangleEdge.LEFT");
        java.lang.Object obj2 = taskSeries1.clone();
        boolean boolean3 = taskSeries1.getNotify();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getUpperMargin();
        double double3 = numberAxis1.getUpperMargin();
        java.awt.Paint paint4 = numberAxis1.getAxisLinePaint();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.chart.axis.SegmentedTimeline.FIRST_MONDAY_AFTER_1900 = 10;
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setVersion("");
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        org.jfree.chart.util.Rotation rotation6 = piePlot5.getDirection();
        org.jfree.chart.plot.Plot plot7 = piePlot5.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        piePlot5.datasetChanged(datasetChangeEvent8);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        piePlot5.drawBackgroundImage(graphics2D10, rectangle2D11);
        java.awt.Paint paint13 = piePlot5.getBaseSectionOutlinePaint();
        java.awt.Paint paint14 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot5.setBaseSectionPaint(paint14);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot5);
        jFreeChart16.setTitle("({0}, {1}) = {3} - {4}");
        java.lang.Object obj19 = jFreeChart16.clone();
        jFreeChart16.fireChartChanged();
        jFreeChart16.setNotify(false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo26 = null;
        java.awt.image.BufferedImage bufferedImage27 = jFreeChart16.createBufferedImage((int) (byte) 10, 100, 12, chartRenderingInfo26);
        projectInfo0.setLogo((java.awt.Image) bufferedImage27);
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(rotation6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNotNull(bufferedImage27);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator1, false);
        boolean boolean4 = barRenderer0.getBaseCreateEntities();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        barRenderer0.setSeriesStroke((int) (short) 100, stroke6, false);
        java.lang.Boolean boolean10 = barRenderer0.getSeriesVisible((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = null;
        barRenderer0.setSeriesURLGenerator(100, categoryURLGenerator12);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer14.setDrawOutlines(true);
        boolean boolean17 = lineAndShapeRenderer14.getBaseLinesVisible();
        org.jfree.data.general.PieDataset pieDataset18 = null;
        org.jfree.chart.plot.PiePlot piePlot19 = new org.jfree.chart.plot.PiePlot(pieDataset18);
        org.jfree.chart.util.Rotation rotation20 = piePlot19.getDirection();
        org.jfree.chart.plot.Plot plot21 = piePlot19.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent22 = null;
        piePlot19.datasetChanged(datasetChangeEvent22);
        java.awt.Stroke stroke25 = piePlot19.getSectionOutlineStroke((java.lang.Comparable) (short) 100);
        java.awt.Paint paint26 = piePlot19.getNoDataMessagePaint();
        lineAndShapeRenderer14.setBasePaint(paint26, false);
        boolean boolean29 = lineAndShapeRenderer14.getBaseShapesFilled();
        boolean boolean30 = barRenderer0.equals((java.lang.Object) boolean29);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(boolean10);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(rotation20);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertNull(stroke25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        int int0 = org.jfree.data.time.SerialDate.SECOND_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator2 = null;
        piePlot1.setToolTipGenerator(pieToolTipGenerator2);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod6 = new org.jfree.data.time.SimpleTimePeriod((long) 10, (long) 'a');
        java.awt.Stroke stroke7 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) simpleTimePeriod6);
        float float8 = piePlot1.getBackgroundAlpha();
        org.junit.Assert.assertNull(stroke7);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = categoryAxis3D0.getCategoryLabelPositions();
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.text.TextFragment textFragment5 = textLine4.getFirstTextFragment();
        java.awt.Font font6 = textFragment5.getFont();
        java.awt.Font font7 = textFragment5.getFont();
        categoryAxis3D0.setTickLabelFont((java.lang.Comparable) (short) 1, font7);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = org.jfree.chart.axis.CategoryAnchor.START;
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        org.jfree.chart.util.Rotation rotation15 = piePlot14.getDirection();
        org.jfree.chart.plot.Plot plot16 = piePlot14.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent17 = null;
        piePlot14.datasetChanged(datasetChangeEvent17);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        piePlot14.drawBackgroundImage(graphics2D19, rectangle2D20);
        java.awt.Paint paint22 = piePlot14.getBaseSectionOutlinePaint();
        java.awt.Paint paint23 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot14.setBaseSectionPaint(paint23);
        org.jfree.chart.JFreeChart jFreeChart25 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot14);
        jFreeChart25.setTitle("({0}, {1}) = {3} - {4}");
        org.jfree.chart.title.TextTitle textTitle28 = jFreeChart25.getTitle();
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment30 = textTitle29.getHorizontalAlignment();
        textTitle29.setExpandToFitSpace(true);
        jFreeChart25.removeSubtitle((org.jfree.chart.title.Title) textTitle29);
        org.jfree.chart.title.TextTitle textTitle34 = new org.jfree.chart.title.TextTitle();
        textTitle34.setNotify(false);
        jFreeChart25.removeSubtitle((org.jfree.chart.title.Title) textTitle34);
        java.awt.geom.Rectangle2D rectangle2D38 = textTitle34.getBounds();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions39 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition41 = categoryLabelPositions39.getLabelPosition(rectangleEdge40);
        try {
            double double42 = categoryAxis3D0.getCategoryJava2DCoordinate(categoryAnchor9, 10, (int) (byte) -1, rectangle2D38, rectangleEdge40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertNotNull(textFragment5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(categoryAnchor9);
        org.junit.Assert.assertNotNull(rotation15);
        org.junit.Assert.assertNull(plot16);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(textTitle28);
        org.junit.Assert.assertNotNull(horizontalAlignment30);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertNotNull(categoryLabelPositions39);
        org.junit.Assert.assertNotNull(rectangleEdge40);
        org.junit.Assert.assertNotNull(categoryLabelPosition41);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.chart.renderer.category.AreaRenderer areaRenderer0 = new org.jfree.chart.renderer.category.AreaRenderer();
        java.awt.Paint paint2 = areaRenderer0.getSeriesItemLabelPaint((-1));
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = null;
        areaRenderer0.setSeriesItemLabelGenerator((int) '4', categoryItemLabelGenerator4, false);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator8 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("({0}, {1}) = {2}");
        areaRenderer0.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator8);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = null;
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str15 = numberAxis14.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange16, 0.0d);
        org.jfree.data.Range range20 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange16, (double) '#');
        numberAxis14.setDefaultAutoRange((org.jfree.data.Range) dateRange16);
        boolean boolean22 = numberAxis14.isNegativeArrowVisible();
        boolean boolean23 = numberAxis14.isTickMarksVisible();
        java.lang.String str24 = numberAxis14.getLabel();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D26 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean27 = numberAxis3D26.isInverted();
        org.jfree.data.time.DateRange dateRange28 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis3D26.setRangeWithMargins((org.jfree.data.Range) dateRange28);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) numberAxis14, (org.jfree.chart.axis.ValueAxis) numberAxis3D26, xYItemRenderer30);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str35 = numberAxis34.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange36 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint38 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange36, 0.0d);
        org.jfree.data.Range range40 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange36, (double) '#');
        numberAxis34.setDefaultAutoRange((org.jfree.data.Range) dateRange36);
        boolean boolean42 = numberAxis34.isNegativeArrowVisible();
        boolean boolean43 = numberAxis34.isTickMarksVisible();
        numberAxis34.setFixedAutoRange((double) 1);
        org.jfree.chart.axis.NumberAxis numberAxis47 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str48 = numberAxis47.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange49 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint51 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange49, 0.0d);
        org.jfree.data.Range range53 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange49, (double) '#');
        numberAxis47.setDefaultAutoRange((org.jfree.data.Range) dateRange49);
        boolean boolean55 = numberAxis47.isNegativeArrowVisible();
        boolean boolean56 = numberAxis47.isTickMarksVisible();
        java.lang.Object obj57 = numberAxis47.clone();
        java.awt.Font font62 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand63 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis47, (double) 11, 0.0d, (double) 'a', (double) 100, font62);
        java.awt.Graphics2D graphics2D64 = null;
        java.awt.geom.Rectangle2D rectangle2D65 = null;
        java.awt.geom.Rectangle2D rectangle2D66 = null;
        markerAxisBand63.draw(graphics2D64, rectangle2D65, rectangle2D66, (double) 12, (double) 12);
        numberAxis34.setMarkerBand(markerAxisBand63);
        xYPlot31.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) numberAxis34);
        org.jfree.chart.renderer.category.BarRenderer barRenderer72 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator73 = barRenderer72.getBaseToolTipGenerator();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator76 = barRenderer72.getToolTipGenerator((int) (byte) 100, 0);
        java.awt.Color color78 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        int int79 = color78.getRed();
        barRenderer72.setSeriesPaint(11, (java.awt.Paint) color78, true);
        xYPlot31.setRangeCrosshairPaint((java.awt.Paint) color78);
        java.awt.Graphics2D graphics2D83 = null;
        org.jfree.chart.util.Size2D size2D86 = new org.jfree.chart.util.Size2D((double) 0.0f, (double) 1L);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor89 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Rectangle2D rectangle2D90 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D86, (double) (byte) 100, (double) 10, rectangleAnchor89);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo92 = null;
        org.jfree.chart.plot.CrosshairState crosshairState93 = null;
        boolean boolean94 = xYPlot31.render(graphics2D83, rectangle2D90, (int) 'a', plotRenderingInfo92, crosshairState93);
        try {
            areaRenderer0.drawBackground(graphics2D10, categoryPlot11, rectangle2D90);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(dateRange16);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(dateRange28);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertNotNull(dateRange36);
        org.junit.Assert.assertNotNull(range40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertNotNull(dateRange49);
        org.junit.Assert.assertNotNull(range53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNotNull(obj57);
        org.junit.Assert.assertNotNull(font62);
        org.junit.Assert.assertNull(categoryToolTipGenerator73);
        org.junit.Assert.assertNull(categoryToolTipGenerator76);
        org.junit.Assert.assertNotNull(color78);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
        org.junit.Assert.assertNotNull(rectangleAnchor89);
        org.junit.Assert.assertNotNull(rectangle2D90);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        int int1 = keyedObjects0.getItemCount();
        try {
            keyedObjects0.removeValue((java.lang.Comparable) "Other");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setNotify(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double5 = rectangleInsets3.calculateBottomOutset((double) (-1L));
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.TOP;
        boolean boolean7 = rectangleInsets3.equals((java.lang.Object) rectangleAnchor6);
        textTitle0.setPadding(rectangleInsets3);
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D12 = rectangleInsets3.createOutsetRectangle(rectangle2D9, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.util.Rotation rotation3 = piePlot2.getDirection();
        org.jfree.chart.plot.Plot plot4 = piePlot2.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        piePlot2.datasetChanged(datasetChangeEvent5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        piePlot2.drawBackgroundImage(graphics2D7, rectangle2D8);
        java.awt.Paint paint10 = piePlot2.getBaseSectionOutlinePaint();
        java.awt.Paint paint11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot2.setBaseSectionPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot2);
        boolean boolean14 = jFreeChart13.isBorderVisible();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        try {
            java.awt.image.BufferedImage bufferedImage18 = jFreeChart13.createBufferedImage((-1), (int) (short) 10, chartRenderingInfo17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (-1) and height (10) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        org.jfree.chart.util.SortOrder sortOrder1 = org.jfree.chart.util.SortOrder.DESCENDING;
        defaultKeyedValues0.sortByKeys(sortOrder1);
        java.lang.Comparable comparable3 = null;
        try {
            java.lang.Number number4 = defaultKeyedValues0.getValue(comparable3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(sortOrder1);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Paint paint1 = ganttRenderer0.getCompletePaint();
        ganttRenderer0.setEndPercent(1.0E-8d);
        org.jfree.data.KeyToGroupMap keyToGroupMap5 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) true);
        java.util.List list6 = keyToGroupMap5.getGroups();
        boolean boolean7 = ganttRenderer0.equals((java.lang.Object) keyToGroupMap5);
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 6);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D10 = new org.jfree.chart.renderer.category.BarRenderer3D();
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 2, (float) 4);
        barRenderer3D10.setSeriesShape((int) (short) 1, shape14, false);
        boolean boolean17 = org.jfree.chart.util.ShapeUtilities.equal(shape9, shape14);
        java.awt.Shape shape19 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 6);
        boolean boolean20 = org.jfree.chart.util.ShapeUtilities.equal(shape14, shape19);
        boolean boolean21 = keyToGroupMap5.equals((java.lang.Object) shape14);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.util.Rotation rotation3 = piePlot2.getDirection();
        org.jfree.chart.plot.Plot plot4 = piePlot2.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        piePlot2.datasetChanged(datasetChangeEvent5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        piePlot2.drawBackgroundImage(graphics2D7, rectangle2D8);
        java.awt.Paint paint10 = piePlot2.getBaseSectionOutlinePaint();
        java.awt.Paint paint11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot2.setBaseSectionPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart13.setTitle("({0}, {1}) = {3} - {4}");
        org.jfree.chart.title.TextTitle textTitle16 = jFreeChart13.getTitle();
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment18 = textTitle17.getHorizontalAlignment();
        textTitle17.setExpandToFitSpace(true);
        jFreeChart13.removeSubtitle((org.jfree.chart.title.Title) textTitle17);
        org.jfree.chart.title.LegendTitle legendTitle22 = null;
        try {
            jFreeChart13.addLegend(legendTitle22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'subtitle' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(textTitle16);
        org.junit.Assert.assertNotNull(horizontalAlignment18);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        stackedAreaRenderer0.setSeriesVisibleInLegend((int) (byte) 1, (java.lang.Boolean) false);
        java.lang.Object obj4 = stackedAreaRenderer0.clone();
        java.awt.Paint paint7 = stackedAreaRenderer0.getItemLabelPaint(1, 500);
        boolean boolean8 = stackedAreaRenderer0.getBaseSeriesVisibleInLegend();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        ganttRenderer0.setStartPercent((double) 0.0f);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        double[] doubleArray3 = new double[] { (short) 1 };
        double[] doubleArray5 = new double[] { (short) 1 };
        double[] doubleArray7 = new double[] { (short) 1 };
        double[][] doubleArray8 = new double[][] { doubleArray3, doubleArray5, doubleArray7 };
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "VerticalAlignment.TOP", doubleArray8);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset9, true);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertNotNull(range11);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 11, 0.0f);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getFixedAutoRange();
        java.text.NumberFormat numberFormat4 = numberAxis2.getNumberFormatOverride();
        boolean boolean5 = numberAxis2.isVerticalTickLabels();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, polarItemRenderer6);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.util.Rotation rotation10 = piePlot9.getDirection();
        org.jfree.chart.plot.Plot plot11 = piePlot9.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = null;
        piePlot9.datasetChanged(datasetChangeEvent12);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        piePlot9.drawBackgroundImage(graphics2D14, rectangle2D15);
        java.awt.Paint paint17 = piePlot9.getBaseSectionOutlinePaint();
        java.awt.Paint paint18 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot9.setBaseSectionPaint(paint18);
        polarPlot7.setAngleGridlinePaint(paint18);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D22 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean23 = numberAxis3D22.isTickMarksVisible();
        org.jfree.chart.plot.Plot plot24 = numberAxis3D22.getPlot();
        org.jfree.data.Range range25 = polarPlot7.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D22);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D31 = new org.jfree.chart.axis.CategoryAxis3D("PlotOrientation.VERTICAL");
        java.awt.Font font33 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis3D31.setTickLabelFont((java.lang.Comparable) (-1), font33);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand35 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis) numberAxis3D22, 2.0d, (double) 3, 0.0d, (double) 1577865599999L, font33);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNull(numberFormat4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rotation10);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(plot24);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertNotNull(font33);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str6 = numberAxis5.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange7 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange7, 0.0d);
        org.jfree.data.Range range11 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange7, (double) '#');
        numberAxis5.setDefaultAutoRange((org.jfree.data.Range) dateRange7);
        boolean boolean13 = numberAxis5.isNegativeArrowVisible();
        boolean boolean14 = numberAxis5.isTickMarksVisible();
        java.lang.String str15 = numberAxis5.getLabel();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D17 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean18 = numberAxis3D17.isInverted();
        org.jfree.data.time.DateRange dateRange19 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis3D17.setRangeWithMargins((org.jfree.data.Range) dateRange19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) numberAxis5, (org.jfree.chart.axis.ValueAxis) numberAxis3D17, xYItemRenderer21);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray23 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot22.setRenderers(xYItemRendererArray23);
        xYPlot22.clearRangeAxes();
        java.awt.Stroke stroke26 = xYPlot22.getRangeZeroBaselineStroke();
        boolean boolean27 = statisticalBarRenderer0.equals((java.lang.Object) xYPlot22);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(dateRange7);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateRange19);
        org.junit.Assert.assertNotNull(xYItemRendererArray23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isDomainZeroBaselineVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, 0.0d);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange4, (double) '#');
        numberAxis2.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        boolean boolean10 = numberAxis2.isNegativeArrowVisible();
        boolean boolean11 = numberAxis2.isTickMarksVisible();
        java.lang.String str12 = numberAxis2.getLabel();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean15 = numberAxis3D14.isInverted();
        org.jfree.data.time.DateRange dateRange16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis3D14.setRangeWithMargins((org.jfree.data.Range) dateRange16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, xYItemRenderer18);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str23 = numberAxis22.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange24 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange24, 0.0d);
        org.jfree.data.Range range28 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange24, (double) '#');
        numberAxis22.setDefaultAutoRange((org.jfree.data.Range) dateRange24);
        boolean boolean30 = numberAxis22.isNegativeArrowVisible();
        boolean boolean31 = numberAxis22.isTickMarksVisible();
        numberAxis22.setFixedAutoRange((double) 1);
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str36 = numberAxis35.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange37 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint39 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange37, 0.0d);
        org.jfree.data.Range range41 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange37, (double) '#');
        numberAxis35.setDefaultAutoRange((org.jfree.data.Range) dateRange37);
        boolean boolean43 = numberAxis35.isNegativeArrowVisible();
        boolean boolean44 = numberAxis35.isTickMarksVisible();
        java.lang.Object obj45 = numberAxis35.clone();
        java.awt.Font font50 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand51 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis35, (double) 11, 0.0d, (double) 'a', (double) 100, font50);
        java.awt.Graphics2D graphics2D52 = null;
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        markerAxisBand51.draw(graphics2D52, rectangle2D53, rectangle2D54, (double) 12, (double) 12);
        numberAxis22.setMarkerBand(markerAxisBand51);
        xYPlot19.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) numberAxis22);
        org.jfree.chart.renderer.category.BarRenderer barRenderer60 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator61 = barRenderer60.getBaseToolTipGenerator();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator64 = barRenderer60.getToolTipGenerator((int) (byte) 100, 0);
        java.awt.Color color66 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        int int67 = color66.getRed();
        barRenderer60.setSeriesPaint(11, (java.awt.Paint) color66, true);
        xYPlot19.setRangeCrosshairPaint((java.awt.Paint) color66);
        org.jfree.data.xy.XYDataset xYDataset71 = null;
        int int72 = xYPlot19.indexOf(xYDataset71);
        xYPlot19.configureDomainAxes();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateRange16);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(dateRange24);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertNotNull(dateRange37);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(obj45);
        org.junit.Assert.assertNotNull(font50);
        org.junit.Assert.assertNull(categoryToolTipGenerator61);
        org.junit.Assert.assertNull(categoryToolTipGenerator64);
        org.junit.Assert.assertNotNull(color66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        double double1 = textTitle0.getWidth();
        textTitle0.setMargin((double) 6, (double) (short) 1, (double) 'a', 8.0d);
        java.lang.Object obj7 = textTitle0.clone();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, 0.0d);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange4, (double) '#');
        numberAxis2.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        boolean boolean10 = numberAxis2.isNegativeArrowVisible();
        boolean boolean11 = numberAxis2.isTickMarksVisible();
        java.lang.String str12 = numberAxis2.getLabel();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean15 = numberAxis3D14.isInverted();
        org.jfree.data.time.DateRange dateRange16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis3D14.setRangeWithMargins((org.jfree.data.Range) dateRange16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, xYItemRenderer18);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray20 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot19.setRenderers(xYItemRendererArray20);
        int int22 = xYPlot19.getSeriesCount();
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double26 = numberAxis25.getFixedAutoRange();
        java.text.NumberFormat numberFormat27 = numberAxis25.getNumberFormatOverride();
        java.awt.Paint paint28 = numberAxis25.getAxisLinePaint();
        java.lang.String str29 = numberAxis25.getLabelToolTip();
        xYPlot19.setDomainAxis((int) '#', (org.jfree.chart.axis.ValueAxis) numberAxis25, true);
        java.awt.Paint paint32 = xYPlot19.getRangeZeroBaselinePaint();
        float float33 = xYPlot19.getForegroundAlpha();
        org.jfree.chart.plot.PlotOrientation plotOrientation34 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        java.lang.String str35 = plotOrientation34.toString();
        xYPlot19.setOrientation(plotOrientation34);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateRange16);
        org.junit.Assert.assertNotNull(xYItemRendererArray20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNull(numberFormat27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 1.0f + "'", float33 == 1.0f);
        org.junit.Assert.assertNotNull(plotOrientation34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "PlotOrientation.VERTICAL" + "'", str35.equals("PlotOrientation.VERTICAL"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        long long2 = year1.getLastMillisecond();
        org.jfree.data.gantt.Task task3 = new org.jfree.data.gantt.Task("AxisLocation.TOP_OR_LEFT", (org.jfree.data.time.TimePeriod) year1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year1.next();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        org.jfree.chart.util.SortOrder sortOrder1 = org.jfree.chart.util.SortOrder.DESCENDING;
        defaultKeyedValues0.sortByKeys(sortOrder1);
        defaultKeyedValues0.clear();
        org.junit.Assert.assertNotNull(sortOrder1);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = piePlot1.getDirection();
        org.jfree.chart.plot.Plot plot3 = piePlot1.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        piePlot1.datasetChanged(datasetChangeEvent4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        piePlot1.drawBackgroundImage(graphics2D6, rectangle2D7);
        java.awt.Paint paint9 = piePlot1.getBaseSectionOutlinePaint();
        java.awt.Stroke stroke10 = piePlot1.getLabelOutlineStroke();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator11 = piePlot1.getURLGenerator();
        piePlot1.setStartAngle((double) 3600000L);
        org.junit.Assert.assertNotNull(rotation2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNull(pieURLGenerator11);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (-2208960000000L), (float) 15);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray32);
        java.lang.String[] strArray36 = new java.lang.String[] { "SerialDate.weekInMonthToString(): invalid code.", "VerticalAlignment.TOP" };
        java.lang.Number[] numberArray44 = new java.lang.Number[] { (short) 1, 100.0f, 2, (short) -1, (-1.0f) };
        java.lang.Number[] numberArray50 = new java.lang.Number[] { (short) 1, 100.0f, 2, (short) -1, (-1.0f) };
        java.lang.Number[][] numberArray51 = new java.lang.Number[][] { numberArray44, numberArray50 };
        org.jfree.data.category.CategoryDataset categoryDataset52 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray51);
        java.lang.Number[][] numberArray53 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset54 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray36, numberArray51, numberArray53);
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset55 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray32, numberArray53);
        org.jfree.data.general.PieDataset pieDataset57 = null;
        org.jfree.chart.plot.PiePlot piePlot58 = new org.jfree.chart.plot.PiePlot(pieDataset57);
        org.jfree.chart.util.Rotation rotation59 = piePlot58.getDirection();
        org.jfree.chart.plot.Plot plot60 = piePlot58.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent61 = null;
        piePlot58.datasetChanged(datasetChangeEvent61);
        java.awt.Graphics2D graphics2D63 = null;
        java.awt.geom.Rectangle2D rectangle2D64 = null;
        piePlot58.drawBackgroundImage(graphics2D63, rectangle2D64);
        java.awt.Paint paint66 = piePlot58.getBaseSectionOutlinePaint();
        java.awt.Paint paint67 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot58.setBaseSectionPaint(paint67);
        boolean boolean69 = piePlot58.getIgnoreZeroValues();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod72 = new org.jfree.data.time.SimpleTimePeriod((long) 10, (long) 'a');
        java.util.Date date73 = simpleTimePeriod72.getEnd();
        org.jfree.data.time.Month month74 = new org.jfree.data.time.Month(date73);
        java.util.Date date75 = month74.getStart();
        org.jfree.chart.axis.NumberAxis numberAxis77 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double78 = numberAxis77.getFixedAutoRange();
        java.awt.Stroke stroke79 = numberAxis77.getTickMarkStroke();
        piePlot58.setSectionOutlineStroke((java.lang.Comparable) month74, stroke79);
        try {
            defaultIntervalCategoryDataset55.setStartValue(0, (java.lang.Comparable) month74, (java.lang.Number) 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(strArray36);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(categoryDataset52);
        org.junit.Assert.assertNotNull(rotation59);
        org.junit.Assert.assertNull(plot60);
        org.junit.Assert.assertNotNull(paint66);
        org.junit.Assert.assertNotNull(paint67);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertNotNull(date75);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
        org.junit.Assert.assertNotNull(stroke79);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) ' ');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        double double1 = axisSpace0.getRight();
        axisSpace0.setLeft((double) 0L);
        boolean boolean5 = axisSpace0.equals((java.lang.Object) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange3, 0.0d);
        org.jfree.data.Range range7 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange3, (double) '#');
        numberAxis1.setDefaultAutoRange((org.jfree.data.Range) dateRange3);
        boolean boolean9 = numberAxis1.isNegativeArrowVisible();
        boolean boolean10 = numberAxis1.isTickMarksVisible();
        org.jfree.chart.plot.Plot plot11 = null;
        numberAxis1.setPlot(plot11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        org.jfree.chart.util.Rotation rotation15 = piePlot14.getDirection();
        org.jfree.chart.plot.Plot plot16 = piePlot14.getParent();
        org.jfree.chart.plot.Plot plot17 = piePlot14.getRootPlot();
        java.awt.Color color18 = java.awt.Color.MAGENTA;
        piePlot14.setOutlinePaint((java.awt.Paint) color18);
        int int20 = piePlot14.getBackgroundImageAlignment();
        java.awt.Paint paint21 = piePlot14.getOutlinePaint();
        boolean boolean22 = numberAxis1.hasListener((java.util.EventListener) piePlot14);
        java.awt.Paint paint23 = numberAxis1.getAxisLinePaint();
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str27 = numberAxis26.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange28 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange28, 0.0d);
        org.jfree.data.Range range32 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange28, (double) '#');
        numberAxis26.setDefaultAutoRange((org.jfree.data.Range) dateRange28);
        boolean boolean34 = numberAxis26.isNegativeArrowVisible();
        boolean boolean35 = numberAxis26.isTickMarksVisible();
        java.lang.String str36 = numberAxis26.getLabel();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D38 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean39 = numberAxis3D38.isInverted();
        org.jfree.data.time.DateRange dateRange40 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis3D38.setRangeWithMargins((org.jfree.data.Range) dateRange40);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = null;
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot(xYDataset24, (org.jfree.chart.axis.ValueAxis) numberAxis26, (org.jfree.chart.axis.ValueAxis) numberAxis3D38, xYItemRenderer42);
        numberAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot43);
        java.awt.Paint paint45 = null;
        try {
            xYPlot43.setRangeCrosshairPaint(paint45);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(dateRange3);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(rotation15);
        org.junit.Assert.assertNull(plot16);
        org.junit.Assert.assertNotNull(plot17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 15 + "'", int20 == 15);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(dateRange28);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(dateRange40);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        java.awt.Paint paint1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        barRenderer2.setBaseToolTipGenerator(categoryToolTipGenerator3, false);
        boolean boolean6 = barRenderer2.getBaseCreateEntities();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        barRenderer2.setSeriesStroke((int) (short) 100, stroke8, false);
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker(0.0d, paint1, stroke8);
        java.awt.Paint paint12 = null;
        try {
            valueMarker11.setPaint(paint12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setBaseLinesVisible(true);
        boolean boolean3 = lineAndShapeRenderer0.getBaseItemLabelsVisible();
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        barRenderer4.setBaseToolTipGenerator(categoryToolTipGenerator5, false);
        boolean boolean8 = barRenderer4.getBaseCreateEntities();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        barRenderer4.setSeriesStroke((int) (short) 100, stroke10, false);
        java.lang.Boolean boolean14 = barRenderer4.getSeriesVisible((int) (byte) -1);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator16 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        barRenderer4.setSeriesToolTipGenerator((int) '#', (org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator16, false);
        lineAndShapeRenderer0.setBaseToolTipGenerator((org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator16);
        boolean boolean22 = lineAndShapeRenderer0.getItemLineVisible((int) (byte) 10, 6);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNull(boolean14);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = regularTimePeriod1.getMiddleMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) (short) 10);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, 0.0d);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange4, (double) '#');
        numberAxis2.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        boolean boolean10 = numberAxis2.isNegativeArrowVisible();
        boolean boolean11 = numberAxis2.isTickMarksVisible();
        java.lang.Object obj12 = numberAxis2.clone();
        numberAxis2.setAutoRangeIncludesZero(true);
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str17 = numberAxis16.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange18 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange18, 0.0d);
        org.jfree.data.Range range22 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange18, (double) '#');
        numberAxis16.setDefaultAutoRange((org.jfree.data.Range) dateRange18);
        boolean boolean24 = numberAxis16.isNegativeArrowVisible();
        boolean boolean25 = numberAxis16.isTickMarksVisible();
        java.lang.Object obj26 = numberAxis16.clone();
        java.awt.Font font31 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand32 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis16, (double) 11, 0.0d, (double) 'a', (double) 100, font31);
        numberAxis2.setTickLabelFont(font31);
        java.awt.Color color34 = java.awt.Color.WHITE;
        org.jfree.chart.block.LabelBlock labelBlock35 = new org.jfree.chart.block.LabelBlock("", font31, (java.awt.Paint) color34);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(dateRange18);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(color34);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = piePlot1.getDirection();
        org.jfree.chart.plot.Plot plot3 = piePlot1.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        piePlot1.datasetChanged(datasetChangeEvent4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        piePlot1.drawBackgroundImage(graphics2D6, rectangle2D7);
        java.awt.Paint paint9 = piePlot1.getBaseSectionOutlinePaint();
        java.awt.Paint paint11 = piePlot1.getSectionPaint((java.lang.Comparable) 10);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent12 = null;
        piePlot1.notifyListeners(plotChangeEvent12);
        org.junit.Assert.assertNotNull(rotation2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(paint11);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = barRenderer0.getBaseToolTipGenerator();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator4 = barRenderer0.getToolTipGenerator((int) (byte) 100, 0);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer5 = barRenderer0.getGradientPaintTransformer();
        java.awt.Shape shape6 = null;
        try {
            barRenderer0.setBaseShape(shape6, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator1);
        org.junit.Assert.assertNull(categoryToolTipGenerator4);
        org.junit.Assert.assertNotNull(gradientPaintTransformer5);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 3, 0.0d, (double) 0.5f, (double) 100.0f);
        java.lang.Object obj6 = null;
        boolean boolean7 = unitType0.equals(obj6);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle(" version ({0}, {1}) = {3} - {4}.\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n({0}, {1}) = {3} - {4}", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.util.Rotation rotation3 = piePlot2.getDirection();
        org.jfree.chart.plot.Plot plot4 = piePlot2.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        piePlot2.datasetChanged(datasetChangeEvent5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        piePlot2.drawBackgroundImage(graphics2D7, rectangle2D8);
        java.awt.Paint paint10 = piePlot2.getBaseSectionOutlinePaint();
        java.awt.Paint paint11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot2.setBaseSectionPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart13.setBackgroundImageAlpha((float) (byte) 10);
        org.jfree.chart.event.ChartProgressListener chartProgressListener16 = null;
        jFreeChart13.removeProgressListener(chartProgressListener16);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer18 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean19 = jFreeChart13.equals((java.lang.Object) lineAndShapeRenderer18);
        try {
            lineAndShapeRenderer18.setSeriesLinesVisible((-2234650), false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.util.Rotation rotation4 = piePlot3.getDirection();
        org.jfree.chart.plot.Plot plot5 = piePlot3.getParent();
        org.jfree.chart.plot.Plot plot6 = piePlot3.getRootPlot();
        java.awt.Color color7 = java.awt.Color.MAGENTA;
        piePlot3.setOutlinePaint((java.awt.Paint) color7);
        columnArrangement0.add((org.jfree.chart.block.Block) textTitle1, (java.lang.Object) color7);
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        org.jfree.chart.util.Rotation rotation12 = piePlot11.getDirection();
        org.jfree.chart.plot.Plot plot13 = piePlot11.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent14 = null;
        piePlot11.datasetChanged(datasetChangeEvent14);
        java.awt.Stroke stroke16 = null;
        piePlot11.setLabelOutlineStroke(stroke16);
        java.lang.Number[] numberArray24 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray34 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray44 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray49 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[][] numberArray50 = new java.lang.Number[][] { numberArray24, numberArray29, numberArray34, numberArray39, numberArray44, numberArray49 };
        org.jfree.data.category.CategoryDataset categoryDataset51 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray50);
        org.jfree.data.general.PieDataset pieDataset53 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset51, (int) (short) 1);
        piePlot11.setDataset(pieDataset53);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer56 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0, (org.jfree.data.general.Dataset) pieDataset53, (java.lang.Comparable) 500);
        org.jfree.chart.util.RectangleInsets rectangleInsets57 = legendItemBlockContainer56.getMargin();
        org.junit.Assert.assertNotNull(rotation4);
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertNotNull(plot6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(rotation12);
        org.junit.Assert.assertNull(plot13);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(numberArray49);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(categoryDataset51);
        org.junit.Assert.assertNotNull(pieDataset53);
        org.junit.Assert.assertNotNull(rectangleInsets57);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 2, (float) 4);
        org.jfree.chart.entity.ChartEntity chartEntity8 = new org.jfree.chart.entity.ChartEntity(shape6, "");
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity11 = new org.jfree.chart.entity.TickLabelEntity(shape6, "RectangleEdge.LEFT", "RectangleEdge.LEFT");
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape6, 1.0E-8d, 0.0f, (float) 100L);
        java.awt.Paint paint16 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer17 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer17.setDrawOutlines(true);
        lineAndShapeRenderer17.setUseFillPaint(true);
        java.lang.Boolean boolean23 = lineAndShapeRenderer17.getSeriesShapesVisible(2);
        lineAndShapeRenderer17.setSeriesVisible((int) ' ', (java.lang.Boolean) false, true);
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double31 = numberAxis30.getFixedAutoRange();
        java.text.NumberFormat numberFormat32 = numberAxis30.getNumberFormatOverride();
        boolean boolean33 = numberAxis30.isVerticalTickLabels();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer34 = null;
        org.jfree.chart.plot.PolarPlot polarPlot35 = new org.jfree.chart.plot.PolarPlot(xYDataset28, (org.jfree.chart.axis.ValueAxis) numberAxis30, polarItemRenderer34);
        org.jfree.data.general.PieDataset pieDataset36 = null;
        org.jfree.chart.plot.PiePlot piePlot37 = new org.jfree.chart.plot.PiePlot(pieDataset36);
        org.jfree.chart.util.Rotation rotation38 = piePlot37.getDirection();
        org.jfree.chart.plot.Plot plot39 = piePlot37.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent40 = null;
        piePlot37.datasetChanged(datasetChangeEvent40);
        java.awt.Graphics2D graphics2D42 = null;
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        piePlot37.drawBackgroundImage(graphics2D42, rectangle2D43);
        java.awt.Paint paint45 = piePlot37.getBaseSectionOutlinePaint();
        java.awt.Paint paint46 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot37.setBaseSectionPaint(paint46);
        polarPlot35.setAngleGridlinePaint(paint46);
        boolean boolean49 = lineAndShapeRenderer17.equals((java.lang.Object) polarPlot35);
        org.jfree.chart.plot.PlotOrientation plotOrientation50 = polarPlot35.getOrientation();
        java.awt.Stroke stroke51 = polarPlot35.getRadiusGridlineStroke();
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer52 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        org.jfree.chart.LegendItem legendItem55 = boxAndWhiskerRenderer52.getLegendItem(15, (int) '#');
        java.awt.Paint paint58 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.renderer.category.BarRenderer barRenderer59 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator60 = null;
        barRenderer59.setBaseToolTipGenerator(categoryToolTipGenerator60, false);
        boolean boolean63 = barRenderer59.getBaseCreateEntities();
        java.awt.Stroke stroke65 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        barRenderer59.setSeriesStroke((int) (short) 100, stroke65, false);
        org.jfree.chart.plot.ValueMarker valueMarker68 = new org.jfree.chart.plot.ValueMarker(0.0d, paint58, stroke65);
        boxAndWhiskerRenderer52.setSeriesItemLabelPaint(6, paint58, false);
        try {
            org.jfree.chart.LegendItem legendItem71 = new org.jfree.chart.LegendItem(attributedString0, "PlotOrientation.VERTICAL", "CategoryLabelEntity: category=8.0, tooltip=({0}, {1}) = {2}, url=SerialDate.weekInMonthToString(): invalid code.", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", shape15, paint16, stroke51, paint58);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNull(boolean23);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNull(numberFormat32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(rotation38);
        org.junit.Assert.assertNull(plot39);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(plotOrientation50);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNull(legendItem55);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(stroke65);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        java.awt.Shape shape6 = null;
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Paint paint10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape13 = null;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color15 = java.awt.Color.black;
        org.jfree.chart.LegendItem legendItem16 = new org.jfree.chart.LegendItem("", "hi!", "hi!", "", true, shape6, false, (java.awt.Paint) color8, false, paint10, stroke11, true, shape13, stroke14, (java.awt.Paint) color15);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean19 = numberAxis18.getAutoRangeStickyZero();
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        numberAxis18.setTickMarkStroke(stroke20);
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 12, (java.awt.Paint) color8, stroke20);
        org.jfree.data.time.TimePeriod timePeriod24 = null;
        org.jfree.data.gantt.Task task25 = new org.jfree.data.gantt.Task("hi!", timePeriod24);
        java.lang.Object obj26 = null;
        boolean boolean27 = task25.equals(obj26);
        org.jfree.data.time.TimePeriod timePeriod29 = null;
        org.jfree.data.gantt.Task task30 = new org.jfree.data.gantt.Task("hi!", timePeriod29);
        java.lang.Object obj31 = null;
        boolean boolean32 = task30.equals(obj31);
        task30.setPercentComplete((java.lang.Double) 90.0d);
        task25.removeSubtask(task30);
        boolean boolean36 = categoryMarker22.equals((java.lang.Object) task30);
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType38 = rectangleInsets37.getUnitType();
        categoryMarker22.setLabelOffset(rectangleInsets37);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertNotNull(unitType38);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        keyedObjects2D0.removeColumn((java.lang.Comparable) 100.0f);
        int int3 = keyedObjects2D0.getRowCount();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        minMaxCategoryRenderer0.setBaseCreateEntities(false, true);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer4 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        javax.swing.Icon icon5 = minMaxCategoryRenderer4.getMaxIcon();
        minMaxCategoryRenderer0.setObjectIcon(icon5);
        boolean boolean7 = minMaxCategoryRenderer0.getAutoPopulateSeriesPaint();
        minMaxCategoryRenderer0.setDrawLines(true);
        java.awt.Paint paint11 = minMaxCategoryRenderer0.getSeriesOutlinePaint((int) (byte) 1);
        org.junit.Assert.assertNotNull(icon5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(paint11);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = piePlot1.getDirection();
        org.jfree.chart.plot.Plot plot3 = piePlot1.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        piePlot1.datasetChanged(datasetChangeEvent4);
        java.awt.Stroke stroke7 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) (short) 100);
        java.awt.Paint paint8 = piePlot1.getNoDataMessagePaint();
        org.jfree.data.general.PieDataset pieDataset9 = piePlot1.getDataset();
        float float10 = piePlot1.getBackgroundImageAlpha();
        org.junit.Assert.assertNotNull(rotation2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNull(stroke7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(pieDataset9);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.5f + "'", float10 == 0.5f);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.TOP;
        boolean boolean2 = categoryLabelPositions0.equals((java.lang.Object) verticalAlignment1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double5 = rectangleInsets3.calculateBottomOutset((double) (-1L));
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.TOP;
        boolean boolean7 = rectangleInsets3.equals((java.lang.Object) rectangleAnchor6);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor8 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor9 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        boolean boolean11 = textAnchor9.equals((java.lang.Object) 'a');
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType13 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition15 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor6, textBlockAnchor8, textAnchor9, (double) (-2208960000000L), categoryLabelWidthType13, (float) 3);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor16 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.text.TextAnchor textAnchor21 = null;
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        java.awt.Shape shape24 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D18, (float) 1, (float) 0, textAnchor21, (double) 100L, textAnchor23);
        java.lang.String str25 = textAnchor23.toString();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType27 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition29 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor6, textBlockAnchor16, textAnchor23, 0.0d, categoryLabelWidthType27, (float) (short) 100);
        org.jfree.chart.text.TextAnchor textAnchor30 = categoryLabelPosition29.getRotationAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions31 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions0, categoryLabelPosition29);
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor8);
        org.junit.Assert.assertNotNull(textAnchor9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(categoryLabelWidthType13);
        org.junit.Assert.assertNotNull(textBlockAnchor16);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNull(shape24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "TextAnchor.CENTER_RIGHT" + "'", str25.equals("TextAnchor.CENTER_RIGHT"));
        org.junit.Assert.assertNotNull(categoryLabelWidthType27);
        org.junit.Assert.assertNotNull(textAnchor30);
        org.junit.Assert.assertNotNull(categoryLabelPositions31);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setSeriesCreateEntities((int) (short) 1, (java.lang.Boolean) false, false);
        boolean boolean6 = lineRenderer3D0.equals((java.lang.Object) false);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean11 = numberAxis10.getAutoRangeStickyZero();
        java.awt.Stroke stroke12 = numberAxis10.getAxisLineStroke();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getLastMillisecond();
        org.jfree.data.gantt.Task task16 = new org.jfree.data.gantt.Task("AxisLocation.TOP_OR_LEFT", (org.jfree.data.time.TimePeriod) year14);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer17 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Paint paint18 = ganttRenderer17.getCompletePaint();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint20 = defaultDrawingSupplier19.getNextFillPaint();
        java.awt.Stroke stroke21 = defaultDrawingSupplier19.getNextStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) year14, paint18, stroke21);
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        lineRenderer3D0.drawRangeMarker(graphics2D7, categoryPlot8, (org.jfree.chart.axis.ValueAxis) numberAxis10, (org.jfree.chart.plot.Marker) categoryMarker22, rectangle2D23);
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState27 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo26);
        org.jfree.chart.util.Size2D size2D30 = new org.jfree.chart.util.Size2D((double) 0.0f, (double) 1L);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Rectangle2D rectangle2D34 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D30, (double) (byte) 100, (double) 10, rectangleAnchor33);
        java.awt.Shape shape38 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D34, (double) 1, (float) (byte) 0, (float) '4');
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D41 = new org.jfree.chart.axis.CategoryAxis3D("PlotOrientation.VERTICAL");
        org.jfree.data.xy.XYDataset xYDataset42 = null;
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str45 = numberAxis44.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange46 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint48 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange46, 0.0d);
        org.jfree.data.Range range50 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange46, (double) '#');
        numberAxis44.setDefaultAutoRange((org.jfree.data.Range) dateRange46);
        boolean boolean52 = numberAxis44.isNegativeArrowVisible();
        boolean boolean53 = numberAxis44.isTickMarksVisible();
        java.lang.String str54 = numberAxis44.getLabel();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D56 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean57 = numberAxis3D56.isInverted();
        org.jfree.data.time.DateRange dateRange58 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis3D56.setRangeWithMargins((org.jfree.data.Range) dateRange58);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer60 = null;
        org.jfree.chart.plot.XYPlot xYPlot61 = new org.jfree.chart.plot.XYPlot(xYDataset42, (org.jfree.chart.axis.ValueAxis) numberAxis44, (org.jfree.chart.axis.ValueAxis) numberAxis3D56, xYItemRenderer60);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray62 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot61.setRenderers(xYItemRendererArray62);
        int int64 = xYPlot61.getSeriesCount();
        org.jfree.chart.axis.NumberAxis numberAxis67 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double68 = numberAxis67.getFixedAutoRange();
        java.text.NumberFormat numberFormat69 = numberAxis67.getNumberFormatOverride();
        java.awt.Paint paint70 = numberAxis67.getAxisLinePaint();
        java.lang.String str71 = numberAxis67.getLabelToolTip();
        xYPlot61.setDomainAxis((int) '#', (org.jfree.chart.axis.ValueAxis) numberAxis67, true);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection74 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int76 = taskSeriesCollection74.indexOf((java.lang.Comparable) '4');
        try {
            lineRenderer3D0.drawItem(graphics2D25, categoryItemRendererState27, rectangle2D34, categoryPlot39, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D41, (org.jfree.chart.axis.ValueAxis) numberAxis67, (org.jfree.data.category.CategoryDataset) taskSeriesCollection74, 12, 255, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(rectangleAnchor33);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertNotNull(dateRange46);
        org.junit.Assert.assertNotNull(range50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "hi!" + "'", str54.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(dateRange58);
        org.junit.Assert.assertNotNull(xYItemRendererArray62);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertNull(numberFormat69);
        org.junit.Assert.assertNotNull(paint70);
        org.junit.Assert.assertNull(str71);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + (-1) + "'", int76 == (-1));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str4 = numberAxis3.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange5 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange5, 0.0d);
        org.jfree.data.Range range9 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange5, (double) '#');
        numberAxis3.setDefaultAutoRange((org.jfree.data.Range) dateRange5);
        boolean boolean11 = numberAxis3.isNegativeArrowVisible();
        boolean boolean12 = numberAxis3.isTickMarksVisible();
        java.lang.Object obj13 = numberAxis3.clone();
        java.awt.Font font18 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand19 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis3, (double) 11, 0.0d, (double) 'a', (double) 100, font18);
        java.awt.Paint paint20 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.text.TextBlock textBlock21 = org.jfree.chart.text.TextUtilities.createTextBlock("NO_CHANGE", font18, paint20);
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment23 = textTitle22.getHorizontalAlignment();
        java.util.List list32 = null;
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem33 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 1L, (java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.05d, (java.lang.Number) 5, (java.lang.Number) (-1), (java.lang.Number) 100.0d, (java.lang.Number) 0L, list32);
        boolean boolean34 = horizontalAlignment23.equals((java.lang.Object) 1.0f);
        textBlock21.setLineAlignment(horizontalAlignment23);
        textTitle0.setTextAlignment(horizontalAlignment23);
        textTitle0.setNotify(false);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment39 = textTitle0.getTextAlignment();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(dateRange5);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(textBlock21);
        org.junit.Assert.assertNotNull(horizontalAlignment23);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment39);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.zoomRange(0.0d, 10.0d);
        java.util.Date date4 = dateAxis0.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        dateAxis6.zoomRange(0.0d, 10.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = dateAxis6.getTickUnit();
        dateAxis5.setTickUnit(dateTickUnit10, false, true);
        dateAxis0.setTickUnit(dateTickUnit10, true, true);
        java.lang.Object obj17 = null;
        boolean boolean18 = dateAxis0.equals(obj17);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(dateTickUnit10);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        java.awt.Shape shape5 = null;
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape12 = null;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color14 = java.awt.Color.black;
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("", "hi!", "hi!", "", true, shape5, false, (java.awt.Paint) color7, false, paint9, stroke10, true, shape12, stroke13, (java.awt.Paint) color14);
        java.lang.Number[] numberArray23 = new java.lang.Number[] { (short) 1, 100.0f, 2, (short) -1, (-1.0f) };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { (short) 1, 100.0f, 2, (short) -1, (-1.0f) };
        java.lang.Number[][] numberArray30 = new java.lang.Number[][] { numberArray23, numberArray29 };
        org.jfree.data.category.CategoryDataset categoryDataset31 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray30);
        legendItem15.setDataset((org.jfree.data.general.Dataset) categoryDataset31);
        legendItem15.setSeriesIndex((int) (byte) 10);
        java.lang.Comparable comparable35 = legendItem15.getSeriesKey();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(categoryDataset31);
        org.junit.Assert.assertNull(comparable35);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        java.awt.geom.Point2D point2D0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePoint2D(point2D0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list1 = defaultStatisticalCategoryDataset0.getColumnKeys();
        int int3 = defaultStatisticalCategoryDataset0.getColumnIndex((java.lang.Comparable) "poly");
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        barRenderer2.setBaseToolTipGenerator(categoryToolTipGenerator3, false);
        boolean boolean6 = barRenderer2.getBaseCreateEntities();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        barRenderer2.setSeriesStroke((int) (short) 100, stroke8, false);
        strokeList0.setStroke(4, stroke8);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer12.setDrawOutlines(true);
        lineAndShapeRenderer12.setUseFillPaint(true);
        java.lang.Boolean boolean18 = lineAndShapeRenderer12.getSeriesShapesVisible(2);
        lineAndShapeRenderer12.setSeriesVisible((int) ' ', (java.lang.Boolean) false, true);
        boolean boolean23 = strokeList0.equals((java.lang.Object) false);
        java.lang.Object obj24 = strokeList0.clone();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer25 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator26 = statisticalLineAndShapeRenderer25.getBaseURLGenerator();
        boolean boolean27 = strokeList0.equals((java.lang.Object) categoryURLGenerator26);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(boolean18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNull(categoryURLGenerator26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) (short) 10);
        categoryAxis0.setCategoryLabelPositionOffset((int) (short) -1);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.zoomRange(0.0d, (double) 10L);
        double double4 = numberAxis3D0.getLabelAngle();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, 0.0d);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange4, (double) '#');
        numberAxis2.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        boolean boolean10 = numberAxis2.isNegativeArrowVisible();
        boolean boolean11 = numberAxis2.isTickMarksVisible();
        java.lang.String str12 = numberAxis2.getLabel();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean15 = numberAxis3D14.isInverted();
        org.jfree.data.time.DateRange dateRange16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis3D14.setRangeWithMargins((org.jfree.data.Range) dateRange16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, xYItemRenderer18);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str23 = numberAxis22.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange24 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange24, 0.0d);
        org.jfree.data.Range range28 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange24, (double) '#');
        numberAxis22.setDefaultAutoRange((org.jfree.data.Range) dateRange24);
        boolean boolean30 = numberAxis22.isNegativeArrowVisible();
        boolean boolean31 = numberAxis22.isTickMarksVisible();
        numberAxis22.setFixedAutoRange((double) 1);
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str36 = numberAxis35.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange37 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint39 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange37, 0.0d);
        org.jfree.data.Range range41 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange37, (double) '#');
        numberAxis35.setDefaultAutoRange((org.jfree.data.Range) dateRange37);
        boolean boolean43 = numberAxis35.isNegativeArrowVisible();
        boolean boolean44 = numberAxis35.isTickMarksVisible();
        java.lang.Object obj45 = numberAxis35.clone();
        java.awt.Font font50 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand51 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis35, (double) 11, 0.0d, (double) 'a', (double) 100, font50);
        java.awt.Graphics2D graphics2D52 = null;
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        markerAxisBand51.draw(graphics2D52, rectangle2D53, rectangle2D54, (double) 12, (double) 12);
        numberAxis22.setMarkerBand(markerAxisBand51);
        xYPlot19.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) numberAxis22);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder60 = xYPlot19.getSeriesRenderingOrder();
        xYPlot19.setRangeCrosshairVisible(true);
        java.awt.Color color63 = java.awt.Color.RED;
        xYPlot19.setDomainGridlinePaint((java.awt.Paint) color63);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateRange16);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(dateRange24);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertNotNull(dateRange37);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(obj45);
        org.junit.Assert.assertNotNull(font50);
        org.junit.Assert.assertNotNull(seriesRenderingOrder60);
        org.junit.Assert.assertNotNull(color63);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, 0.0d);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange4, (double) '#');
        numberAxis2.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        boolean boolean10 = numberAxis2.isNegativeArrowVisible();
        boolean boolean11 = numberAxis2.isTickMarksVisible();
        java.lang.String str12 = numberAxis2.getLabel();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean15 = numberAxis3D14.isInverted();
        org.jfree.data.time.DateRange dateRange16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis3D14.setRangeWithMargins((org.jfree.data.Range) dateRange16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, xYItemRenderer18);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray20 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot19.setRenderers(xYItemRendererArray20);
        xYPlot19.clearRangeAxes();
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        org.jfree.chart.plot.CrosshairState crosshairState27 = null;
        boolean boolean28 = xYPlot19.render(graphics2D23, rectangle2D24, (int) (byte) 1, plotRenderingInfo26, crosshairState27);
        org.jfree.chart.axis.AxisLocation axisLocation29 = xYPlot19.getRangeAxisLocation();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateRange16);
        org.junit.Assert.assertNotNull(xYItemRendererArray20);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(axisLocation29);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, 0.0d);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange4, (double) '#');
        numberAxis2.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        org.jfree.data.Range range12 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange4, 0.0d, (double) (byte) -1);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType13 = null;
        org.jfree.data.time.DateRange dateRange15 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double16 = dateRange15.getUpperBound();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType17 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = new org.jfree.chart.block.RectangleConstraint(0.0d, range12, lengthConstraintType13, 0.2d, (org.jfree.data.Range) dateRange15, lengthConstraintType17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'widthType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(dateRange15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic2 = new org.jfree.chart.title.LegendGraphic(shape0, (java.awt.Paint) color1);
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        org.jfree.chart.util.Rotation rotation5 = piePlot4.getDirection();
        org.jfree.chart.plot.Plot plot6 = piePlot4.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        piePlot4.datasetChanged(datasetChangeEvent7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        piePlot4.drawBackgroundImage(graphics2D9, rectangle2D10);
        java.awt.Shape shape17 = null;
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Paint paint21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke22 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape24 = null;
        java.awt.Stroke stroke25 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color26 = java.awt.Color.black;
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("", "hi!", "hi!", "", true, shape17, false, (java.awt.Paint) color19, false, paint21, stroke22, true, shape24, stroke25, (java.awt.Paint) color26);
        java.awt.Stroke stroke28 = legendItem27.getLineStroke();
        piePlot4.setBaseSectionOutlineStroke(stroke28);
        legendGraphic2.setOutlineStroke(stroke28);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor31 = legendGraphic2.getShapeLocation();
        boolean boolean32 = legendGraphic2.isShapeVisible();
        java.awt.Shape shape35 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 11);
        org.jfree.chart.entity.ChartEntity chartEntity38 = new org.jfree.chart.entity.ChartEntity(shape35, "RectangleEdge.LEFT", "NO_CHANGE");
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity41 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) 8.0d, shape35, "({0}, {1}) = {2}", "SerialDate.weekInMonthToString(): invalid code.");
        legendGraphic2.setShape(shape35);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rotation5);
        org.junit.Assert.assertNull(plot6);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(rectangleAnchor31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(shape35);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str4 = numberAxis3.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange5 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange5, 0.0d);
        org.jfree.data.Range range9 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange5, (double) '#');
        numberAxis3.setDefaultAutoRange((org.jfree.data.Range) dateRange5);
        boolean boolean11 = numberAxis3.isNegativeArrowVisible();
        boolean boolean12 = numberAxis3.isTickMarksVisible();
        java.lang.Object obj13 = numberAxis3.clone();
        java.awt.Font font18 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand19 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis3, (double) 11, 0.0d, (double) 'a', (double) 100, font18);
        java.awt.Paint paint20 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.text.TextBlock textBlock21 = org.jfree.chart.text.TextUtilities.createTextBlock("NO_CHANGE", font18, paint20);
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment23 = textTitle22.getHorizontalAlignment();
        java.util.List list32 = null;
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem33 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 1L, (java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.05d, (java.lang.Number) 5, (java.lang.Number) (-1), (java.lang.Number) 100.0d, (java.lang.Number) 0L, list32);
        boolean boolean34 = horizontalAlignment23.equals((java.lang.Object) 1.0f);
        textBlock21.setLineAlignment(horizontalAlignment23);
        textTitle0.setTextAlignment(horizontalAlignment23);
        textTitle0.setNotify(false);
        org.jfree.chart.axis.AxisState axisState39 = new org.jfree.chart.axis.AxisState();
        boolean boolean40 = textTitle0.equals((java.lang.Object) axisState39);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(dateRange5);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(textBlock21);
        org.junit.Assert.assertNotNull(horizontalAlignment23);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        int int1 = defaultStatisticalCategoryDataset0.getColumnCount();
        java.lang.Comparable comparable2 = null;
        int int3 = defaultStatisticalCategoryDataset0.getRowIndex(comparable2);
        java.lang.Number number4 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        java.lang.Number number7 = defaultStatisticalCategoryDataset0.getValue((java.lang.Comparable) 10L, (java.lang.Comparable) "AxisLocation.TOP_OR_LEFT");
        java.util.List list8 = defaultStatisticalCategoryDataset0.getRowKeys();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertEquals((double) number4, Double.NaN, 0);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertNotNull(list8);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.util.Rotation rotation4 = piePlot3.getDirection();
        org.jfree.chart.plot.Plot plot5 = piePlot3.getParent();
        org.jfree.chart.plot.Plot plot6 = piePlot3.getRootPlot();
        java.awt.Color color7 = java.awt.Color.MAGENTA;
        piePlot3.setOutlinePaint((java.awt.Paint) color7);
        columnArrangement0.add((org.jfree.chart.block.Block) textTitle1, (java.lang.Object) color7);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection10 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent11 = null;
        taskSeriesCollection10.seriesChanged(seriesChangeEvent11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.next();
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer15 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0, (org.jfree.data.general.Dataset) taskSeriesCollection10, (java.lang.Comparable) year13);
        java.util.List list16 = taskSeriesCollection10.getColumnKeys();
        org.junit.Assert.assertNotNull(rotation4);
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertNotNull(plot6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(list16);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list1 = defaultStatisticalCategoryDataset0.getColumnKeys();
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        java.util.List list3 = defaultStatisticalCategoryDataset0.getRowKeys();
        org.jfree.data.general.PieDataset pieDataset5 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, 0);
        java.lang.Number number8 = defaultStatisticalCategoryDataset0.getStdDevValue((java.lang.Comparable) 11, (java.lang.Comparable) 2.0d);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0.0d + "'", number2.equals(0.0d));
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNotNull(pieDataset5);
        org.junit.Assert.assertNull(number8);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.LegendItem legendItem3 = stackedAreaRenderer0.getLegendItem((int) 'a', 0);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = null;
        stackedAreaRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator4, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator7 = stackedAreaRenderer0.getLegendItemToolTipGenerator();
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator7);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = minMaxCategoryRenderer0.getBaseToolTipGenerator();
        java.awt.Stroke stroke4 = minMaxCategoryRenderer0.getItemOutlineStroke(2958465, (-1));
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer5 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        minMaxCategoryRenderer5.setBaseCreateEntities(false, true);
        javax.swing.Icon icon9 = minMaxCategoryRenderer5.getMaxIcon();
        minMaxCategoryRenderer0.setMinIcon(icon9);
        org.junit.Assert.assertNull(categoryToolTipGenerator1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(icon9);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        boxAndWhiskerRenderer0.setFillBox(true);
        double double3 = boxAndWhiskerRenderer0.getItemMargin();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.util.Rotation rotation7 = piePlot6.getDirection();
        org.jfree.chart.plot.Plot plot8 = piePlot6.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent9 = null;
        piePlot6.datasetChanged(datasetChangeEvent9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        piePlot6.drawBackgroundImage(graphics2D11, rectangle2D12);
        java.awt.Paint paint14 = piePlot6.getBaseSectionOutlinePaint();
        java.awt.Paint paint15 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot6.setBaseSectionPaint(paint15);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot6);
        jFreeChart17.setTitle("({0}, {1}) = {3} - {4}");
        org.jfree.chart.title.TextTitle textTitle20 = jFreeChart17.getTitle();
        java.awt.Stroke stroke21 = jFreeChart17.getBorderStroke();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent24 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) double3, jFreeChart17, 2, 15);
        java.awt.Color color25 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        jFreeChart17.setBorderPaint((java.awt.Paint) color25);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(rotation7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(textTitle20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color25);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-2234650), (double) 10L);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = piePlot1.getDirection();
        org.jfree.chart.plot.Plot plot3 = piePlot1.getParent();
        org.jfree.chart.plot.Plot plot4 = piePlot1.getRootPlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator5 = piePlot1.getLegendLabelGenerator();
        java.awt.Paint paint6 = piePlot1.getBackgroundPaint();
        org.junit.Assert.assertNotNull(rotation2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(plot4);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.data.DefaultKeyedValue defaultKeyedValue2 = new org.jfree.data.DefaultKeyedValue((java.lang.Comparable) 10.0f, (java.lang.Number) 3.0d);
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        org.jfree.chart.util.Rotation rotation5 = piePlot4.getDirection();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator6 = piePlot4.getURLGenerator();
        piePlot4.setMaximumLabelWidth((double) (short) 100);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent9 = null;
        piePlot4.axisChanged(axisChangeEvent9);
        boolean boolean11 = defaultKeyedValue2.equals((java.lang.Object) axisChangeEvent9);
        org.junit.Assert.assertNotNull(rotation5);
        org.junit.Assert.assertNull(pieURLGenerator6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        java.awt.Shape shape5 = null;
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape12 = null;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color14 = java.awt.Color.black;
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("", "hi!", "hi!", "", true, shape5, false, (java.awt.Paint) color7, false, paint9, stroke10, true, shape12, stroke13, (java.awt.Paint) color14);
        legendItem15.setSeriesIndex((int) (short) 1);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color14);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, 0.0d);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange4, (double) '#');
        numberAxis2.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        boolean boolean10 = numberAxis2.isNegativeArrowVisible();
        boolean boolean11 = numberAxis2.isTickMarksVisible();
        java.lang.String str12 = numberAxis2.getLabel();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean15 = numberAxis3D14.isInverted();
        org.jfree.data.time.DateRange dateRange16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis3D14.setRangeWithMargins((org.jfree.data.Range) dateRange16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, xYItemRenderer18);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray20 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot19.setRenderers(xYItemRendererArray20);
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        xYPlot19.setDataset((int) (byte) 1, xYDataset23);
        xYPlot19.setRangeCrosshairValue(0.0d, true);
        java.awt.Paint paint29 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.renderer.category.BarRenderer barRenderer30 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator31 = null;
        barRenderer30.setBaseToolTipGenerator(categoryToolTipGenerator31, false);
        boolean boolean34 = barRenderer30.getBaseCreateEntities();
        java.awt.Stroke stroke36 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        barRenderer30.setSeriesStroke((int) (short) 100, stroke36, false);
        org.jfree.chart.plot.ValueMarker valueMarker39 = new org.jfree.chart.plot.ValueMarker(0.0d, paint29, stroke36);
        java.awt.Paint paint40 = valueMarker39.getPaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor41 = valueMarker39.getLabelAnchor();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor42 = valueMarker39.getLabelAnchor();
        xYPlot19.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker39);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateRange16);
        org.junit.Assert.assertNotNull(xYItemRendererArray20);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(rectangleAnchor41);
        org.junit.Assert.assertNotNull(rectangleAnchor42);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.cursorLeft(1.0E-8d);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        java.text.DateFormat dateFormat2 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit((int) ' ', (int) (byte) 1, dateFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DateTickUnit.getMillisecondCount() : unit must be one of the constants YEAR, MONTH, DAY, HOUR, MINUTE, SECOND or MILLISECOND defined in the DateTickUnit class. Do *not* use the constants defined in java.util.Calendar.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.chart.renderer.category.LayeredBarRenderer layeredBarRenderer0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState3 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo2);
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis6.setCategoryMargin((double) 100L);
        java.lang.String str10 = categoryAxis6.getCategoryLabelToolTip((java.lang.Comparable) 2.0f);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean13 = numberAxis12.getAutoRangeStickyZero();
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        numberAxis12.setTickMarkStroke(stroke14);
        numberAxis12.setTickMarkInsideLength(0.0f);
        float float18 = numberAxis12.getTickMarkOutsideLength();
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray30 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray35 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray40 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray45 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray50 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[][] numberArray51 = new java.lang.Number[][] { numberArray25, numberArray30, numberArray35, numberArray40, numberArray45, numberArray50 };
        org.jfree.data.category.CategoryDataset categoryDataset52 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray51);
        java.lang.String[] strArray55 = new java.lang.String[] { "SerialDate.weekInMonthToString(): invalid code.", "VerticalAlignment.TOP" };
        java.lang.Number[] numberArray63 = new java.lang.Number[] { (short) 1, 100.0f, 2, (short) -1, (-1.0f) };
        java.lang.Number[] numberArray69 = new java.lang.Number[] { (short) 1, 100.0f, 2, (short) -1, (-1.0f) };
        java.lang.Number[][] numberArray70 = new java.lang.Number[][] { numberArray63, numberArray69 };
        org.jfree.data.category.CategoryDataset categoryDataset71 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray70);
        java.lang.Number[][] numberArray72 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset73 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray55, numberArray70, numberArray72);
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset74 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray51, numberArray72);
        java.util.List list75 = defaultIntervalCategoryDataset74.getRowKeys();
        try {
            layeredBarRenderer0.drawItem(graphics2D1, categoryItemRendererState3, rectangle2D4, categoryPlot5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis12, (org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset74, 1, (int) (byte) -1, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 2.0f + "'", float18 == 2.0f);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(categoryDataset52);
        org.junit.Assert.assertNotNull(strArray55);
        org.junit.Assert.assertNotNull(numberArray63);
        org.junit.Assert.assertNotNull(numberArray69);
        org.junit.Assert.assertNotNull(numberArray70);
        org.junit.Assert.assertNotNull(categoryDataset71);
        org.junit.Assert.assertNotNull(list75);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("({0}, {1}) = {2}");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name ({0}, {1}) = {2}, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.zoomRange(0.0d, 10.0d);
        java.util.Date date4 = dateAxis0.getMinimumDate();
        dateAxis0.setAutoRange(true);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        java.awt.Paint paint1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        barRenderer2.setBaseToolTipGenerator(categoryToolTipGenerator3, false);
        boolean boolean6 = barRenderer2.getBaseCreateEntities();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        barRenderer2.setSeriesStroke((int) (short) 100, stroke8, false);
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker(0.0d, paint1, stroke8);
        java.awt.Paint paint12 = valueMarker11.getPaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = valueMarker11.getLabelAnchor();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double16 = numberAxis15.getFixedAutoRange();
        java.text.NumberFormat numberFormat17 = numberAxis15.getNumberFormatOverride();
        java.awt.Paint paint18 = numberAxis15.getAxisLinePaint();
        valueMarker11.setOutlinePaint(paint18);
        float float20 = valueMarker11.getAlpha();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNull(numberFormat17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 1.0f + "'", float20 == 1.0f);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange3, 0.0d);
        org.jfree.data.Range range7 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange3, (double) '#');
        numberAxis1.setDefaultAutoRange((org.jfree.data.Range) dateRange3);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer9.setDrawOutlines(true);
        lineAndShapeRenderer9.setUseFillPaint(true);
        java.lang.Boolean boolean15 = lineAndShapeRenderer9.getSeriesShapesVisible(2);
        java.awt.Paint paint17 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        lineAndShapeRenderer9.setSeriesPaint((int) (byte) 10, paint17, true);
        boolean boolean20 = numberAxis1.equals((java.lang.Object) (byte) 10);
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer21 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        boolean boolean22 = boxAndWhiskerRenderer21.getBaseItemLabelsVisible();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer24 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.LegendItem legendItem27 = stackedAreaRenderer24.getLegendItem((int) 'a', 0);
        java.awt.Shape shape29 = null;
        stackedAreaRenderer24.setSeriesShape((int) '4', shape29, true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator32 = null;
        stackedAreaRenderer24.setBaseURLGenerator(categoryURLGenerator32);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition36 = stackedAreaRenderer24.getNegativeItemLabelPosition(100, (int) (short) 0);
        boxAndWhiskerRenderer21.setSeriesPositiveItemLabelPosition((int) '#', itemLabelPosition36);
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str42 = numberAxis41.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange43 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint45 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange43, 0.0d);
        org.jfree.data.Range range47 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange43, (double) '#');
        numberAxis41.setDefaultAutoRange((org.jfree.data.Range) dateRange43);
        boolean boolean49 = numberAxis41.isNegativeArrowVisible();
        boolean boolean50 = numberAxis41.isTickMarksVisible();
        java.lang.Object obj51 = numberAxis41.clone();
        java.awt.Font font56 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand57 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis41, (double) 11, 0.0d, (double) 'a', (double) 100, font56);
        java.awt.Paint paint58 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.text.TextBlock textBlock59 = org.jfree.chart.text.TextUtilities.createTextBlock("NO_CHANGE", font56, paint58);
        boxAndWhiskerRenderer21.setSeriesOutlinePaint(3, paint58);
        numberAxis1.setAxisLinePaint(paint58);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(dateRange3);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(boolean15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(legendItem27);
        org.junit.Assert.assertNotNull(itemLabelPosition36);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertNotNull(dateRange43);
        org.junit.Assert.assertNotNull(range47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(obj51);
        org.junit.Assert.assertNotNull(font56);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertNotNull(textBlock59);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.jfree.data.time.TimePeriod timePeriod1 = null;
        org.jfree.data.gantt.Task task2 = new org.jfree.data.gantt.Task("hi!", timePeriod1);
        java.lang.Object obj3 = null;
        boolean boolean4 = task2.equals(obj3);
        org.jfree.data.time.TimePeriod timePeriod6 = null;
        org.jfree.data.gantt.Task task7 = new org.jfree.data.gantt.Task("hi!", timePeriod6);
        java.lang.Object obj8 = null;
        boolean boolean9 = task7.equals(obj8);
        task7.setPercentComplete((java.lang.Double) 90.0d);
        task2.removeSubtask(task7);
        org.jfree.data.time.TimePeriod timePeriod13 = null;
        task2.setDuration(timePeriod13);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = lineAndShapeRenderer0.getToolTipGenerator(2, 1);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        org.jfree.chart.util.Rotation rotation6 = piePlot5.getDirection();
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        piePlot5.removeChangeListener(plotChangeListener7);
        piePlot5.setLabelLinksVisible(false);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.color.ColorSpace colorSpace12 = color11.getColorSpace();
        piePlot5.setLabelLinkPaint((java.awt.Paint) color11);
        lineAndShapeRenderer0.setBaseFillPaint((java.awt.Paint) color11);
        lineAndShapeRenderer0.setDrawOutlines(false);
        boolean boolean17 = lineAndShapeRenderer0.getAutoPopulateSeriesStroke();
        org.junit.Assert.assertNull(categoryToolTipGenerator3);
        org.junit.Assert.assertNotNull(rotation6);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(colorSpace12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("RectangleEdge.LEFT");
        java.lang.Object obj2 = taskSeries1.clone();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        taskSeries1.addChangeListener(seriesChangeListener3);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (100) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        try {
            booleanList0.setBoolean((int) (short) -1, (java.lang.Boolean) false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.MIDDLE;
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getFixedAutoRange();
        java.awt.Stroke stroke3 = numberAxis1.getTickMarkStroke();
        java.lang.Object obj4 = numberAxis1.clone();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.color.ColorSpace colorSpace6 = color5.getColorSpace();
        java.awt.Paint paint8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator10 = null;
        barRenderer9.setBaseToolTipGenerator(categoryToolTipGenerator10, false);
        boolean boolean13 = barRenderer9.getBaseCreateEntities();
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        barRenderer9.setSeriesStroke((int) (short) 100, stroke15, false);
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker(0.0d, paint8, stroke15);
        org.jfree.data.general.PieDataset pieDataset20 = null;
        org.jfree.chart.plot.PiePlot piePlot21 = new org.jfree.chart.plot.PiePlot(pieDataset20);
        org.jfree.chart.util.Rotation rotation22 = piePlot21.getDirection();
        org.jfree.chart.plot.Plot plot23 = piePlot21.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent24 = null;
        piePlot21.datasetChanged(datasetChangeEvent24);
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        piePlot21.drawBackgroundImage(graphics2D26, rectangle2D27);
        java.awt.Paint paint29 = piePlot21.getBaseSectionOutlinePaint();
        java.awt.Paint paint30 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot21.setBaseSectionPaint(paint30);
        org.jfree.chart.JFreeChart jFreeChart32 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot21);
        jFreeChart32.setTitle("({0}, {1}) = {3} - {4}");
        org.jfree.chart.title.TextTitle textTitle35 = jFreeChart32.getTitle();
        org.jfree.chart.title.TextTitle textTitle36 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment37 = textTitle36.getHorizontalAlignment();
        textTitle36.setExpandToFitSpace(true);
        jFreeChart32.removeSubtitle((org.jfree.chart.title.Title) textTitle36);
        textTitle36.setExpandToFitSpace(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = textTitle36.getMargin();
        org.jfree.chart.block.LineBorder lineBorder44 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color5, stroke15, rectangleInsets43);
        double double45 = rectangleInsets43.getTop();
        numberAxis1.setLabelInsets(rectangleInsets43);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(colorSpace6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(rotation22);
        org.junit.Assert.assertNull(plot23);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(textTitle35);
        org.junit.Assert.assertNotNull(horizontalAlignment37);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = piePlot1.getDirection();
        org.jfree.chart.plot.Plot plot3 = piePlot1.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        piePlot1.datasetChanged(datasetChangeEvent4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        piePlot1.drawBackgroundImage(graphics2D6, rectangle2D7);
        java.awt.Paint paint9 = piePlot1.getBaseSectionOutlinePaint();
        java.awt.Paint paint10 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot1.setBaseSectionPaint(paint10);
        boolean boolean12 = piePlot1.getIgnoreZeroValues();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod((long) 10, (long) 'a');
        java.util.Date date16 = simpleTimePeriod15.getEnd();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date16);
        java.util.Date date18 = month17.getStart();
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double21 = numberAxis20.getFixedAutoRange();
        java.awt.Stroke stroke22 = numberAxis20.getTickMarkStroke();
        piePlot1.setSectionOutlineStroke((java.lang.Comparable) month17, stroke22);
        java.awt.Image image27 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo31 = new org.jfree.chart.ui.ProjectInfo("", "({0}, {1}) = {3} - {4}", "", image27, "hi!", "hi!", "({0}, {1}) = {3} - {4}");
        java.awt.Image image32 = null;
        projectInfo31.setLogo(image32);
        boolean boolean34 = month17.equals((java.lang.Object) image32);
        org.junit.Assert.assertNotNull(rotation2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.util.Rotation rotation3 = piePlot2.getDirection();
        org.jfree.chart.plot.Plot plot4 = piePlot2.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        piePlot2.datasetChanged(datasetChangeEvent5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        piePlot2.drawBackgroundImage(graphics2D7, rectangle2D8);
        java.awt.Paint paint10 = piePlot2.getBaseSectionOutlinePaint();
        java.awt.Paint paint11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot2.setBaseSectionPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart13.setTitle("({0}, {1}) = {3} - {4}");
        org.jfree.chart.title.TextTitle textTitle16 = jFreeChart13.getTitle();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo21 = null;
        java.awt.image.BufferedImage bufferedImage22 = jFreeChart13.createBufferedImage((int) (short) 100, 9, 32.0d, (double) 2958465, chartRenderingInfo21);
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(textTitle16);
        org.junit.Assert.assertNotNull(bufferedImage22);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, 0.0d);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange4, (double) '#');
        numberAxis2.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        boolean boolean10 = numberAxis2.isNegativeArrowVisible();
        boolean boolean11 = numberAxis2.isTickMarksVisible();
        java.lang.String str12 = numberAxis2.getLabel();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean15 = numberAxis3D14.isInverted();
        org.jfree.data.time.DateRange dateRange16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis3D14.setRangeWithMargins((org.jfree.data.Range) dateRange16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, xYItemRenderer18);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray20 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot19.setRenderers(xYItemRendererArray20);
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        xYPlot19.setDataset((int) (byte) 1, xYDataset23);
        xYPlot19.setRangeCrosshairValue(0.0d, true);
        boolean boolean28 = xYPlot19.isRangeCrosshairLockedOnData();
        int int29 = xYPlot19.getRangeAxisCount();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateRange16);
        org.junit.Assert.assertNotNull(xYItemRendererArray20);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange3, 0.0d);
        org.jfree.data.Range range7 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange3, (double) '#');
        numberAxis1.setDefaultAutoRange((org.jfree.data.Range) dateRange3);
        boolean boolean9 = numberAxis1.isNegativeArrowVisible();
        boolean boolean10 = numberAxis1.isTickMarksVisible();
        org.jfree.chart.plot.Plot plot11 = null;
        numberAxis1.setPlot(plot11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        org.jfree.chart.util.Rotation rotation15 = piePlot14.getDirection();
        org.jfree.chart.plot.Plot plot16 = piePlot14.getParent();
        org.jfree.chart.plot.Plot plot17 = piePlot14.getRootPlot();
        java.awt.Color color18 = java.awt.Color.MAGENTA;
        piePlot14.setOutlinePaint((java.awt.Paint) color18);
        int int20 = piePlot14.getBackgroundImageAlignment();
        java.awt.Paint paint21 = piePlot14.getOutlinePaint();
        boolean boolean22 = numberAxis1.hasListener((java.util.EventListener) piePlot14);
        java.lang.String str23 = numberAxis1.getLabelToolTip();
        org.jfree.data.general.PieDataset pieDataset24 = null;
        org.jfree.chart.plot.PiePlot piePlot25 = new org.jfree.chart.plot.PiePlot(pieDataset24);
        org.jfree.chart.util.Rotation rotation26 = piePlot25.getDirection();
        org.jfree.chart.plot.Plot plot27 = piePlot25.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent28 = null;
        piePlot25.datasetChanged(datasetChangeEvent28);
        java.awt.Graphics2D graphics2D30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        piePlot25.drawBackgroundImage(graphics2D30, rectangle2D31);
        boolean boolean33 = numberAxis1.hasListener((java.util.EventListener) piePlot25);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(dateRange3);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(rotation15);
        org.junit.Assert.assertNull(plot16);
        org.junit.Assert.assertNotNull(plot17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 15 + "'", int20 == 15);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(rotation26);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, 0.0d);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange4, (double) '#');
        numberAxis2.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        boolean boolean10 = numberAxis2.isNegativeArrowVisible();
        boolean boolean11 = numberAxis2.isTickMarksVisible();
        java.lang.String str12 = numberAxis2.getLabel();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean15 = numberAxis3D14.isInverted();
        org.jfree.data.time.DateRange dateRange16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis3D14.setRangeWithMargins((org.jfree.data.Range) dateRange16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, xYItemRenderer18);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray20 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot19.setRenderers(xYItemRendererArray20);
        boolean boolean22 = xYPlot19.isRangeGridlinesVisible();
        java.awt.Paint paint23 = xYPlot19.getRangeTickBandPaint();
        float float24 = xYPlot19.getForegroundAlpha();
        xYPlot19.setDomainCrosshairValue((double) 100.0f);
        org.jfree.chart.util.Layer layer27 = null;
        java.util.Collection collection28 = xYPlot19.getRangeMarkers(layer27);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateRange16);
        org.junit.Assert.assertNotNull(xYItemRendererArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNull(paint23);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 1.0f + "'", float24 == 1.0f);
        org.junit.Assert.assertNull(collection28);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 10, (float) (short) 10);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        try {
            org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange(12.0d, (double) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (12.0) <= upper (10.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator2 = null;
        piePlot1.setToolTipGenerator(pieToolTipGenerator2);
        float float4 = piePlot1.getForegroundAlpha();
        java.awt.Paint paint5 = piePlot1.getLabelBackgroundPaint();
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getFixedAutoRange();
        java.text.NumberFormat numberFormat3 = numberAxis1.getNumberFormatOverride();
        numberAxis1.setAutoTickUnitSelection(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = numberAxis1.getTickLabelInsets();
        java.lang.String str7 = numberAxis1.getLabelToolTip();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNull(numberFormat3);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = lineAndShapeRenderer2.getBaseToolTipGenerator();
        java.awt.Paint paint4 = null;
        lineAndShapeRenderer2.setBasePaint(paint4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        lineAndShapeRenderer2.notifyListeners(rendererChangeEvent6);
        org.junit.Assert.assertNull(categoryToolTipGenerator3);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = piePlot1.getDirection();
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot1.removeChangeListener(plotChangeListener3);
        piePlot1.setLabelLinksVisible(false);
        java.lang.Object obj7 = piePlot1.clone();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str11 = numberAxis10.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange12 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange12, 0.0d);
        org.jfree.data.Range range16 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange12, (double) '#');
        numberAxis10.setDefaultAutoRange((org.jfree.data.Range) dateRange12);
        boolean boolean18 = numberAxis10.isNegativeArrowVisible();
        boolean boolean19 = numberAxis10.isTickMarksVisible();
        java.lang.Object obj20 = numberAxis10.clone();
        java.awt.Font font25 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand26 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis10, (double) 11, 0.0d, (double) 'a', (double) 100, font25);
        java.awt.Paint paint27 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.text.TextBlock textBlock28 = org.jfree.chart.text.TextUtilities.createTextBlock("NO_CHANGE", font25, paint27);
        piePlot1.setNoDataMessagePaint(paint27);
        java.awt.Paint paint30 = piePlot1.getLabelShadowPaint();
        org.junit.Assert.assertNotNull(rotation2);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(dateRange12);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(textBlock28);
        org.junit.Assert.assertNotNull(paint30);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor2 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.text.TextAnchor textAnchor7 = null;
        org.jfree.chart.text.TextAnchor textAnchor9 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        java.awt.Shape shape10 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D4, (float) 1, (float) 0, textAnchor7, (double) 100L, textAnchor9);
        org.jfree.chart.text.TextAnchor textAnchor11 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor2, textAnchor9, textAnchor11, (double) (byte) 100);
        boolean boolean14 = textLine1.equals((java.lang.Object) itemLabelAnchor2);
        org.junit.Assert.assertNotNull(itemLabelAnchor2);
        org.junit.Assert.assertNotNull(textAnchor9);
        org.junit.Assert.assertNull(shape10);
        org.junit.Assert.assertNotNull(textAnchor11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        java.awt.Shape shape5 = null;
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape12 = null;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color14 = java.awt.Color.black;
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("", "hi!", "hi!", "", true, shape5, false, (java.awt.Paint) color7, false, paint9, stroke10, true, shape12, stroke13, (java.awt.Paint) color14);
        java.awt.Stroke stroke16 = legendItem15.getLineStroke();
        legendItem15.setSeriesIndex((int) (short) 0);
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray30 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray35 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray40 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray45 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray50 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[][] numberArray51 = new java.lang.Number[][] { numberArray25, numberArray30, numberArray35, numberArray40, numberArray45, numberArray50 };
        org.jfree.data.category.CategoryDataset categoryDataset52 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray51);
        org.jfree.data.general.PieDataset pieDataset54 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset52, (int) (short) 1);
        legendItem15.setDataset((org.jfree.data.general.Dataset) categoryDataset52);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot56 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset52);
        org.jfree.chart.text.TextLine textLine60 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.text.TextFragment textFragment61 = textLine60.getFirstTextFragment();
        java.awt.Font font62 = textFragment61.getFont();
        java.awt.Color color63 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.block.LabelBlock labelBlock64 = new org.jfree.chart.block.LabelBlock("hi!", font62, (java.awt.Paint) color63);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer65 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Paint paint66 = ganttRenderer65.getCompletePaint();
        org.jfree.chart.block.LabelBlock labelBlock67 = new org.jfree.chart.block.LabelBlock("({0}, {1}) = {3} - {4}", font62, paint66);
        java.awt.Paint paint68 = labelBlock67.getPaint();
        multiplePiePlot56.setAggregatedItemsPaint(paint68);
        org.jfree.chart.util.TableOrder tableOrder70 = null;
        try {
            multiplePiePlot56.setDataExtractOrder(tableOrder70);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(categoryDataset52);
        org.junit.Assert.assertNotNull(pieDataset54);
        org.junit.Assert.assertNotNull(textFragment61);
        org.junit.Assert.assertNotNull(font62);
        org.junit.Assert.assertNotNull(color63);
        org.junit.Assert.assertNotNull(paint66);
        org.junit.Assert.assertNotNull(paint68);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) ' ', (-459), (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        int int3 = java.awt.Color.HSBtoRGB((float) 2, (float) (-2234650), (float) 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-162432) + "'", int3 == (-162432));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        double double0 = org.jfree.chart.plot.PiePlot.MAX_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.4d + "'", double0 == 0.4d);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.cursorLeft((double) (-1L));
        axisState0.cursorDown((double) (byte) 100);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean7 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge6);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge6);
        axisState0.moveCursor((double) 500, rectangleEdge8);
        double double10 = axisState0.getCursor();
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-399.0d) + "'", double10 == (-399.0d));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.zoomRange(0.0d, 10.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis0.getTickUnit();
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer6 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        boxAndWhiskerRenderer6.setAutoPopulateSeriesShape(true);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((long) 10, (long) 'a');
        java.util.Date date12 = simpleTimePeriod11.getEnd();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date12);
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone14;
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date12, timeZone14);
        boolean boolean17 = boxAndWhiskerRenderer6.equals((java.lang.Object) date12);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((long) 10, (long) 'a');
        java.util.Date date21 = simpleTimePeriod20.getEnd();
        org.jfree.data.gantt.Task task22 = new org.jfree.data.gantt.Task("Size2D[width=0.0, height=1.0]", date12, date21);
        dateAxis0.setMaximumDate(date21);
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date21, timeZone24);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone24);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = piePlot1.getDirection();
        org.jfree.chart.plot.Plot plot3 = piePlot1.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        piePlot1.datasetChanged(datasetChangeEvent4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        piePlot1.drawBackgroundImage(graphics2D6, rectangle2D7);
        java.awt.Paint paint9 = piePlot1.getBaseSectionOutlinePaint();
        java.awt.Paint paint11 = piePlot1.getSectionPaint((java.lang.Comparable) 10);
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        org.jfree.chart.util.Rotation rotation14 = piePlot13.getDirection();
        org.jfree.chart.plot.Plot plot15 = piePlot13.getParent();
        org.jfree.chart.plot.Plot plot16 = piePlot13.getRootPlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator17 = piePlot13.getLegendLabelGenerator();
        piePlot1.setLabelGenerator(pieSectionLabelGenerator17);
        double double19 = piePlot1.getLabelGap();
        java.lang.Object obj20 = piePlot1.clone();
        org.junit.Assert.assertNotNull(rotation2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(rotation14);
        org.junit.Assert.assertNull(plot15);
        org.junit.Assert.assertNotNull(plot16);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.05d + "'", double19 == 0.05d);
        org.junit.Assert.assertNotNull(obj20);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        boxAndWhiskerRenderer0.setFillBox(true);
        double double3 = boxAndWhiskerRenderer0.getItemMargin();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.util.Rotation rotation7 = piePlot6.getDirection();
        org.jfree.chart.plot.Plot plot8 = piePlot6.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent9 = null;
        piePlot6.datasetChanged(datasetChangeEvent9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        piePlot6.drawBackgroundImage(graphics2D11, rectangle2D12);
        java.awt.Paint paint14 = piePlot6.getBaseSectionOutlinePaint();
        java.awt.Paint paint15 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot6.setBaseSectionPaint(paint15);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot6);
        jFreeChart17.setTitle("({0}, {1}) = {3} - {4}");
        org.jfree.chart.title.TextTitle textTitle20 = jFreeChart17.getTitle();
        java.awt.Stroke stroke21 = jFreeChart17.getBorderStroke();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent24 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) double3, jFreeChart17, 2, 15);
        org.jfree.chart.block.ColumnArrangement columnArrangement25 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle();
        org.jfree.data.general.PieDataset pieDataset27 = null;
        org.jfree.chart.plot.PiePlot piePlot28 = new org.jfree.chart.plot.PiePlot(pieDataset27);
        org.jfree.chart.util.Rotation rotation29 = piePlot28.getDirection();
        org.jfree.chart.plot.Plot plot30 = piePlot28.getParent();
        org.jfree.chart.plot.Plot plot31 = piePlot28.getRootPlot();
        java.awt.Color color32 = java.awt.Color.MAGENTA;
        piePlot28.setOutlinePaint((java.awt.Paint) color32);
        columnArrangement25.add((org.jfree.chart.block.Block) textTitle26, (java.lang.Object) color32);
        jFreeChart17.setBorderPaint((java.awt.Paint) color32);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(rotation7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(textTitle20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(rotation29);
        org.junit.Assert.assertNull(plot30);
        org.junit.Assert.assertNotNull(plot31);
        org.junit.Assert.assertNotNull(color32);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) (short) 10);
        java.lang.String str3 = categoryAxis0.getLabelURL();
        double double4 = categoryAxis0.getUpperMargin();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 9, (-1310400001L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires end >= start.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        long long2 = year0.getLastMillisecond();
        org.jfree.chart.block.BlockParams blockParams3 = new org.jfree.chart.block.BlockParams();
        boolean boolean4 = blockParams3.getGenerateEntities();
        blockParams3.setTranslateX(1.0E-5d);
        int int7 = year0.compareTo((java.lang.Object) blockParams3);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getFixedAutoRange();
        java.text.NumberFormat numberFormat4 = numberAxis2.getNumberFormatOverride();
        boolean boolean5 = numberAxis2.isVerticalTickLabels();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, polarItemRenderer6);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.util.Rotation rotation10 = piePlot9.getDirection();
        org.jfree.chart.plot.Plot plot11 = piePlot9.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = null;
        piePlot9.datasetChanged(datasetChangeEvent12);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        piePlot9.drawBackgroundImage(graphics2D14, rectangle2D15);
        java.awt.Paint paint17 = piePlot9.getBaseSectionOutlinePaint();
        java.awt.Paint paint18 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot9.setBaseSectionPaint(paint18);
        polarPlot7.setAngleGridlinePaint(paint18);
        boolean boolean21 = polarPlot7.isDomainZoomable();
        boolean boolean22 = polarPlot7.isDomainZoomable();
        polarPlot7.clearCornerTextItems();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent24 = null;
        polarPlot7.rendererChanged(rendererChangeEvent24);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNull(numberFormat4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rotation10);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getFixedAutoRange();
        java.text.NumberFormat numberFormat4 = numberAxis2.getNumberFormatOverride();
        boolean boolean5 = numberAxis2.isVerticalTickLabels();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, polarItemRenderer6);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean10 = numberAxis9.getAutoRangeStickyZero();
        polarPlot7.setAxis((org.jfree.chart.axis.ValueAxis) numberAxis9);
        java.awt.Font font12 = numberAxis9.getLabelFont();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNull(numberFormat4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(font12);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, 0.0d);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange4, (double) '#');
        numberAxis2.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        boolean boolean10 = numberAxis2.isNegativeArrowVisible();
        boolean boolean11 = numberAxis2.isTickMarksVisible();
        java.lang.String str12 = numberAxis2.getLabel();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean15 = numberAxis3D14.isInverted();
        org.jfree.data.time.DateRange dateRange16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis3D14.setRangeWithMargins((org.jfree.data.Range) dateRange16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, xYItemRenderer18);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray20 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot19.setRenderers(xYItemRendererArray20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        xYPlot19.zoomRangeAxes((double) (-1L), plotRenderingInfo23, point2D24);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        xYPlot19.setDataset(xYDataset26);
        xYPlot19.configureDomainAxes();
        org.jfree.chart.axis.AxisSpace axisSpace29 = new org.jfree.chart.axis.AxisSpace();
        double double30 = axisSpace29.getRight();
        xYPlot19.setFixedDomainAxisSpace(axisSpace29);
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.data.Range range33 = xYPlot19.getDataRange(valueAxis32);
        org.jfree.chart.axis.AxisLocation axisLocation34 = xYPlot19.getRangeAxisLocation();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateRange16);
        org.junit.Assert.assertNotNull(xYItemRendererArray20);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertNotNull(axisLocation34);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, 0.0d);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange4, (double) '#');
        numberAxis2.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        boolean boolean10 = numberAxis2.isNegativeArrowVisible();
        boolean boolean11 = numberAxis2.isTickMarksVisible();
        java.lang.String str12 = numberAxis2.getLabel();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean15 = numberAxis3D14.isInverted();
        org.jfree.data.time.DateRange dateRange16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis3D14.setRangeWithMargins((org.jfree.data.Range) dateRange16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, xYItemRenderer18);
        java.awt.Paint paint20 = xYPlot19.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation22 = xYPlot19.getRangeAxisLocation(1969);
        boolean boolean23 = xYPlot19.isDomainCrosshairVisible();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateRange16);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getHorizontalAlignment();
        java.lang.Object obj2 = textTitle0.clone();
        java.awt.Font font3 = textTitle0.getFont();
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, 0.0d);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange4, (double) '#');
        numberAxis2.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        boolean boolean10 = numberAxis2.isNegativeArrowVisible();
        boolean boolean11 = numberAxis2.isTickMarksVisible();
        java.lang.String str12 = numberAxis2.getLabel();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean15 = numberAxis3D14.isInverted();
        org.jfree.data.time.DateRange dateRange16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis3D14.setRangeWithMargins((org.jfree.data.Range) dateRange16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, xYItemRenderer18);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str23 = numberAxis22.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange24 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange24, 0.0d);
        org.jfree.data.Range range28 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange24, (double) '#');
        numberAxis22.setDefaultAutoRange((org.jfree.data.Range) dateRange24);
        boolean boolean30 = numberAxis22.isNegativeArrowVisible();
        boolean boolean31 = numberAxis22.isTickMarksVisible();
        numberAxis22.setFixedAutoRange((double) 1);
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str36 = numberAxis35.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange37 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint39 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange37, 0.0d);
        org.jfree.data.Range range41 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange37, (double) '#');
        numberAxis35.setDefaultAutoRange((org.jfree.data.Range) dateRange37);
        boolean boolean43 = numberAxis35.isNegativeArrowVisible();
        boolean boolean44 = numberAxis35.isTickMarksVisible();
        java.lang.Object obj45 = numberAxis35.clone();
        java.awt.Font font50 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand51 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis35, (double) 11, 0.0d, (double) 'a', (double) 100, font50);
        java.awt.Graphics2D graphics2D52 = null;
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        markerAxisBand51.draw(graphics2D52, rectangle2D53, rectangle2D54, (double) 12, (double) 12);
        numberAxis22.setMarkerBand(markerAxisBand51);
        xYPlot19.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) numberAxis22);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder60 = xYPlot19.getSeriesRenderingOrder();
        int int61 = xYPlot19.getDomainAxisCount();
        java.lang.Object obj62 = xYPlot19.clone();
        java.awt.Graphics2D graphics2D63 = null;
        org.jfree.data.general.PieDataset pieDataset65 = null;
        org.jfree.chart.plot.PiePlot piePlot66 = new org.jfree.chart.plot.PiePlot(pieDataset65);
        org.jfree.chart.util.Rotation rotation67 = piePlot66.getDirection();
        org.jfree.chart.plot.Plot plot68 = piePlot66.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent69 = null;
        piePlot66.datasetChanged(datasetChangeEvent69);
        java.awt.Graphics2D graphics2D71 = null;
        java.awt.geom.Rectangle2D rectangle2D72 = null;
        piePlot66.drawBackgroundImage(graphics2D71, rectangle2D72);
        java.awt.Paint paint74 = piePlot66.getBaseSectionOutlinePaint();
        java.awt.Paint paint75 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot66.setBaseSectionPaint(paint75);
        org.jfree.chart.JFreeChart jFreeChart77 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot66);
        jFreeChart77.setTitle("({0}, {1}) = {3} - {4}");
        org.jfree.chart.title.TextTitle textTitle80 = jFreeChart77.getTitle();
        org.jfree.chart.title.TextTitle textTitle81 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment82 = textTitle81.getHorizontalAlignment();
        textTitle81.setExpandToFitSpace(true);
        jFreeChart77.removeSubtitle((org.jfree.chart.title.Title) textTitle81);
        org.jfree.chart.title.TextTitle textTitle86 = new org.jfree.chart.title.TextTitle();
        textTitle86.setNotify(false);
        jFreeChart77.removeSubtitle((org.jfree.chart.title.Title) textTitle86);
        java.awt.geom.Rectangle2D rectangle2D90 = textTitle86.getBounds();
        try {
            xYPlot19.drawBackground(graphics2D63, rectangle2D90);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateRange16);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(dateRange24);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertNotNull(dateRange37);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(obj45);
        org.junit.Assert.assertNotNull(font50);
        org.junit.Assert.assertNotNull(seriesRenderingOrder60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 12 + "'", int61 == 12);
        org.junit.Assert.assertNotNull(obj62);
        org.junit.Assert.assertNotNull(rotation67);
        org.junit.Assert.assertNull(plot68);
        org.junit.Assert.assertNotNull(paint74);
        org.junit.Assert.assertNotNull(paint75);
        org.junit.Assert.assertNotNull(textTitle80);
        org.junit.Assert.assertNotNull(horizontalAlignment82);
        org.junit.Assert.assertNotNull(rectangle2D90);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.util.Rotation rotation3 = piePlot2.getDirection();
        org.jfree.chart.plot.Plot plot4 = piePlot2.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        piePlot2.datasetChanged(datasetChangeEvent5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        piePlot2.drawBackgroundImage(graphics2D7, rectangle2D8);
        java.awt.Paint paint10 = piePlot2.getBaseSectionOutlinePaint();
        java.awt.Paint paint11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot2.setBaseSectionPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart13.setBackgroundImageAlpha((float) (byte) 10);
        org.jfree.chart.event.ChartProgressListener chartProgressListener16 = null;
        jFreeChart13.removeProgressListener(chartProgressListener16);
        jFreeChart13.fireChartChanged();
        jFreeChart13.removeLegend();
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge0);
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge0);
        java.lang.String str3 = rectangleEdge2.toString();
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleEdge.TOP" + "'", str3.equals("RectangleEdge.TOP"));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        int int1 = keyedObjects0.getItemCount();
        java.lang.Object obj3 = keyedObjects0.getObject((java.lang.Comparable) (short) -1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.chart.ChartColor chartColor9 = new org.jfree.chart.ChartColor((int) (short) 0, (int) (byte) 100, (int) '#');
        boolean boolean10 = spreadsheetDate5.equals((java.lang.Object) (short) 0);
        int int11 = spreadsheetDate5.getDayOfWeek();
        int int12 = keyedObjects0.getIndex((java.lang.Comparable) spreadsheetDate5);
        java.lang.Object obj13 = keyedObjects0.clone();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list1 = taskSeriesCollection0.getRowKeys();
        taskSeriesCollection0.removeAll();
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.util.Rotation rotation3 = piePlot2.getDirection();
        org.jfree.chart.plot.Plot plot4 = piePlot2.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        piePlot2.datasetChanged(datasetChangeEvent5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        piePlot2.drawBackgroundImage(graphics2D7, rectangle2D8);
        java.awt.Paint paint10 = piePlot2.getBaseSectionOutlinePaint();
        java.awt.Paint paint11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot2.setBaseSectionPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart13.setTitle("({0}, {1}) = {3} - {4}");
        org.jfree.chart.title.TextTitle textTitle16 = jFreeChart13.getTitle();
        textTitle16.setID("Other");
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(textTitle16);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "({0}, {1}) = {3} - {4}", "", image3, "hi!", "hi!", "({0}, {1}) = {3} - {4}");
        java.util.List list8 = projectInfo7.getContributors();
        java.awt.Image image12 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo16 = new org.jfree.chart.ui.ProjectInfo("", "({0}, {1}) = {3} - {4}", "", image12, "hi!", "hi!", "({0}, {1}) = {3} - {4}");
        java.awt.Image image17 = null;
        projectInfo16.setLogo(image17);
        projectInfo7.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo16);
        java.awt.Image image20 = projectInfo7.getLogo();
        org.junit.Assert.assertNull(list8);
        org.junit.Assert.assertNull(image20);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange3, 0.0d);
        org.jfree.data.Range range7 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange3, (double) '#');
        numberAxis1.setDefaultAutoRange((org.jfree.data.Range) dateRange3);
        boolean boolean9 = numberAxis1.isNegativeArrowVisible();
        boolean boolean10 = numberAxis1.isTickMarksVisible();
        java.lang.Object obj11 = numberAxis1.clone();
        java.awt.Font font16 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand17 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis1, (double) 11, 0.0d, (double) 'a', (double) 100, font16);
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str21 = numberAxis20.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange22 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint24 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange22, 0.0d);
        org.jfree.data.Range range26 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange22, (double) '#');
        numberAxis20.setDefaultAutoRange((org.jfree.data.Range) dateRange22);
        boolean boolean28 = numberAxis20.isNegativeArrowVisible();
        boolean boolean29 = numberAxis20.isTickMarksVisible();
        java.lang.Object obj30 = numberAxis20.clone();
        numberAxis20.setAutoRangeIncludesZero(true);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str35 = numberAxis34.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange36 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint38 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange36, 0.0d);
        org.jfree.data.Range range40 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange36, (double) '#');
        numberAxis34.setDefaultAutoRange((org.jfree.data.Range) dateRange36);
        boolean boolean42 = numberAxis34.isNegativeArrowVisible();
        boolean boolean43 = numberAxis34.isTickMarksVisible();
        java.lang.Object obj44 = numberAxis34.clone();
        java.awt.Font font49 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand50 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis34, (double) 11, 0.0d, (double) 'a', (double) 100, font49);
        numberAxis20.setTickLabelFont(font49);
        org.jfree.data.general.PieDataset pieDataset52 = null;
        org.jfree.chart.plot.PiePlot piePlot53 = new org.jfree.chart.plot.PiePlot(pieDataset52);
        org.jfree.chart.util.Rotation rotation54 = piePlot53.getDirection();
        org.jfree.chart.plot.Plot plot55 = piePlot53.getParent();
        org.jfree.chart.plot.Plot plot56 = piePlot53.getRootPlot();
        org.jfree.chart.JFreeChart jFreeChart58 = new org.jfree.chart.JFreeChart("PlotOrientation.VERTICAL", font49, (org.jfree.chart.plot.Plot) piePlot53, false);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent61 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) 'a', jFreeChart58, 100, 0);
        chartProgressEvent61.setPercent(0);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(dateRange3);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(dateRange22);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertNotNull(dateRange36);
        org.junit.Assert.assertNotNull(range40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(obj44);
        org.junit.Assert.assertNotNull(font49);
        org.junit.Assert.assertNotNull(rotation54);
        org.junit.Assert.assertNull(plot55);
        org.junit.Assert.assertNotNull(plot56);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 0.0f, (double) 1L);
        double double3 = size2D2.width;
        double double4 = size2D2.getHeight();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        java.awt.Shape shape5 = null;
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape12 = null;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color14 = java.awt.Color.black;
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("", "hi!", "hi!", "", true, shape5, false, (java.awt.Paint) color7, false, paint9, stroke10, true, shape12, stroke13, (java.awt.Paint) color14);
        java.awt.Stroke stroke16 = legendItem15.getLineStroke();
        boolean boolean17 = legendItem15.isShapeVisible();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.cursorLeft((double) (-1L));
        axisState0.cursorDown((double) (byte) 100);
        axisState0.cursorUp((double) (-459));
        axisState0.cursorDown(0.0d);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 10, (long) 'a');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        java.util.Date date5 = month4.getStart();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = month4.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        boolean boolean1 = blockParams0.getGenerateEntities();
        blockParams0.setTranslateX(1.0E-5d);
        double double4 = blockParams0.getTranslateX();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-5d + "'", double4 == 1.0E-5d);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "ChartChangeEventType.DATASET_UPDATED");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.chart.ChartColor chartColor7 = new org.jfree.chart.ChartColor((int) (short) 0, (int) (byte) 100, (int) '#');
        boolean boolean8 = spreadsheetDate3.equals((java.lang.Object) (short) 0);
        int int9 = spreadsheetDate3.getDayOfWeek();
        categoryMarker1.setKey((java.lang.Comparable) spreadsheetDate3);
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 2, (float) 4);
        org.jfree.chart.entity.ChartEntity chartEntity15 = new org.jfree.chart.entity.ChartEntity(shape13, "");
        java.lang.String str16 = chartEntity15.getURLText();
        boolean boolean17 = categoryMarker1.equals((java.lang.Object) str16);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        javax.swing.Icon icon1 = minMaxCategoryRenderer0.getMaxIcon();
        java.awt.Stroke stroke2 = minMaxCategoryRenderer0.getGroupStroke();
        org.junit.Assert.assertNotNull(icon1);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, 0.0d);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange4, (double) '#');
        numberAxis2.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        boolean boolean10 = numberAxis2.isNegativeArrowVisible();
        boolean boolean11 = numberAxis2.isTickMarksVisible();
        java.lang.String str12 = numberAxis2.getLabel();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean15 = numberAxis3D14.isInverted();
        org.jfree.data.time.DateRange dateRange16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis3D14.setRangeWithMargins((org.jfree.data.Range) dateRange16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, xYItemRenderer18);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray20 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot19.setRenderers(xYItemRendererArray20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        xYPlot19.zoomRangeAxes((double) (-1L), plotRenderingInfo23, point2D24);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        xYPlot19.setDataset(xYDataset26);
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str32 = numberAxis31.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange33 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint35 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange33, 0.0d);
        org.jfree.data.Range range37 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange33, (double) '#');
        numberAxis31.setDefaultAutoRange((org.jfree.data.Range) dateRange33);
        boolean boolean39 = numberAxis31.isNegativeArrowVisible();
        boolean boolean40 = numberAxis31.isTickMarksVisible();
        java.lang.String str41 = numberAxis31.getLabel();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D43 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean44 = numberAxis3D43.isInverted();
        org.jfree.data.time.DateRange dateRange45 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis3D43.setRangeWithMargins((org.jfree.data.Range) dateRange45);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset29, (org.jfree.chart.axis.ValueAxis) numberAxis31, (org.jfree.chart.axis.ValueAxis) numberAxis3D43, xYItemRenderer47);
        java.awt.Paint paint49 = xYPlot48.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation51 = xYPlot48.getRangeAxisLocation(1969);
        xYPlot19.setDomainAxisLocation(1, axisLocation51, false);
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D54 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D54.setSeriesCreateEntities((int) (short) 1, (java.lang.Boolean) false, false);
        boolean boolean60 = lineRenderer3D54.equals((java.lang.Object) false);
        java.awt.Graphics2D graphics2D61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = null;
        org.jfree.chart.axis.NumberAxis numberAxis64 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean65 = numberAxis64.getAutoRangeStickyZero();
        java.awt.Stroke stroke66 = numberAxis64.getAxisLineStroke();
        org.jfree.data.time.Year year68 = new org.jfree.data.time.Year();
        long long69 = year68.getLastMillisecond();
        org.jfree.data.gantt.Task task70 = new org.jfree.data.gantt.Task("AxisLocation.TOP_OR_LEFT", (org.jfree.data.time.TimePeriod) year68);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer71 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Paint paint72 = ganttRenderer71.getCompletePaint();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier73 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint74 = defaultDrawingSupplier73.getNextFillPaint();
        java.awt.Stroke stroke75 = defaultDrawingSupplier73.getNextStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker76 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) year68, paint72, stroke75);
        java.awt.geom.Rectangle2D rectangle2D77 = null;
        lineRenderer3D54.drawRangeMarker(graphics2D61, categoryPlot62, (org.jfree.chart.axis.ValueAxis) numberAxis64, (org.jfree.chart.plot.Marker) categoryMarker76, rectangle2D77);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType79 = categoryMarker76.getLabelOffsetType();
        org.jfree.chart.util.Layer layer80 = null;
        xYPlot19.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker76, layer80);
        org.jfree.chart.axis.AxisLocation axisLocation83 = xYPlot19.getRangeAxisLocation((int) (byte) -1);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateRange16);
        org.junit.Assert.assertNotNull(xYItemRendererArray20);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertNotNull(dateRange33);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "hi!" + "'", str41.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(dateRange45);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(axisLocation51);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertNotNull(stroke66);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 1577865599999L + "'", long69 == 1577865599999L);
        org.junit.Assert.assertNotNull(paint72);
        org.junit.Assert.assertNotNull(paint74);
        org.junit.Assert.assertNotNull(stroke75);
        org.junit.Assert.assertNotNull(lengthAdjustmentType79);
        org.junit.Assert.assertNotNull(axisLocation83);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("({0}, {1}) = {3} - {4}");
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = null;
        ganttRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator1, false);
        java.awt.Paint paint4 = ganttRenderer0.getCompletePaint();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D10 = new org.jfree.chart.renderer.category.BarRenderer3D();
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 2, (float) 4);
        barRenderer3D10.setSeriesShape((int) (short) 1, shape14, false);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean19 = numberAxis18.getAutoRangeStickyZero();
        java.awt.Stroke stroke20 = numberAxis18.getAxisLineStroke();
        org.jfree.data.general.PieDataset pieDataset21 = null;
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot(pieDataset21);
        org.jfree.chart.util.Rotation rotation23 = piePlot22.getDirection();
        org.jfree.chart.plot.Plot plot24 = piePlot22.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent25 = null;
        piePlot22.datasetChanged(datasetChangeEvent25);
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        piePlot22.drawBackgroundImage(graphics2D27, rectangle2D28);
        java.awt.Paint paint30 = piePlot22.getBaseSectionOutlinePaint();
        java.awt.Paint paint31 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot22.setBaseSectionPaint(paint31);
        org.jfree.chart.LegendItem legendItem33 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "TextAnchor.CENTER_RIGHT", "ChartEntity: tooltip = ", shape14, stroke20, paint31);
        ganttRenderer0.setSeriesShape(10, shape14);
        java.awt.Shape shape41 = null;
        java.awt.Color color43 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Paint paint45 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke46 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape48 = null;
        java.awt.Stroke stroke49 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color50 = java.awt.Color.black;
        org.jfree.chart.LegendItem legendItem51 = new org.jfree.chart.LegendItem("", "hi!", "hi!", "", true, shape41, false, (java.awt.Paint) color43, false, paint45, stroke46, true, shape48, stroke49, (java.awt.Paint) color50);
        java.awt.Stroke stroke52 = legendItem51.getLineStroke();
        legendItem51.setSeriesIndex((int) (short) 0);
        java.awt.Paint paint55 = legendItem51.getFillPaint();
        ganttRenderer0.setSeriesItemLabelPaint(11, paint55);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(rotation23);
        org.junit.Assert.assertNull(plot24);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(paint55);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list1 = taskSeriesCollection0.getRowKeys();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        try {
            java.lang.Number number5 = taskSeriesCollection0.getEndValue((-162432), (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic2 = new org.jfree.chart.title.LegendGraphic(shape0, (java.awt.Paint) color1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = legendGraphic2.getFillPaintTransformer();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double6 = rectangleInsets4.calculateBottomOutset((double) (-1L));
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.TOP;
        boolean boolean8 = rectangleInsets4.equals((java.lang.Object) rectangleAnchor7);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor9 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        boolean boolean12 = textAnchor10.equals((java.lang.Object) 'a');
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType14 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition16 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor7, textBlockAnchor9, textAnchor10, (double) (-2208960000000L), categoryLabelWidthType14, (float) 3);
        legendGraphic2.setShapeAnchor(rectangleAnchor7);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(gradientPaintTransformer3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor9);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(categoryLabelWidthType14);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        long long3 = year0.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, 0.0d);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange4, (double) '#');
        numberAxis2.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        boolean boolean10 = numberAxis2.isNegativeArrowVisible();
        boolean boolean11 = numberAxis2.isTickMarksVisible();
        java.lang.String str12 = numberAxis2.getLabel();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean15 = numberAxis3D14.isInverted();
        org.jfree.data.time.DateRange dateRange16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis3D14.setRangeWithMargins((org.jfree.data.Range) dateRange16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, xYItemRenderer18);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray20 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot19.setRenderers(xYItemRendererArray20);
        xYPlot19.clearRangeAxes();
        java.awt.Stroke stroke23 = xYPlot19.getRangeZeroBaselineStroke();
        org.jfree.chart.util.Layer layer24 = null;
        java.util.Collection collection25 = xYPlot19.getRangeMarkers(layer24);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateRange16);
        org.junit.Assert.assertNotNull(xYItemRendererArray20);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNull(collection25);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        double double1 = levelRenderer0.getItemMargin();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.util.Rotation rotation3 = piePlot2.getDirection();
        org.jfree.chart.plot.Plot plot4 = piePlot2.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        piePlot2.datasetChanged(datasetChangeEvent5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        piePlot2.drawBackgroundImage(graphics2D7, rectangle2D8);
        java.awt.Paint paint10 = piePlot2.getBaseSectionOutlinePaint();
        java.awt.Paint paint11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot2.setBaseSectionPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart13.setTitle("({0}, {1}) = {3} - {4}");
        java.lang.Object obj16 = jFreeChart13.clone();
        jFreeChart13.fireChartChanged();
        java.awt.Paint paint18 = jFreeChart13.getBackgroundPaint();
        jFreeChart13.setBackgroundImageAlignment((int) (byte) 1);
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray32);
        org.jfree.data.general.PieDataset pieDataset35 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset33, (int) (short) 1);
        double double36 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset35);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(pieDataset35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 10, (long) 'a');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        java.util.Date date5 = month4.getStart();
        long long6 = month4.getMiddleMillisecond();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean8 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge7);
        org.jfree.data.KeyedObject keyedObject9 = new org.jfree.data.KeyedObject((java.lang.Comparable) month4, (java.lang.Object) rectangleEdge7);
        long long10 = month4.getSerialIndex();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = month4.getLastMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1310400001L) + "'", long6 == (-1310400001L));
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 23640L + "'", long10 == 23640L);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit((int) (byte) 10, 500);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DateTickUnit.getMillisecondCount() : unit must be one of the constants YEAR, MONTH, DAY, HOUR, MINUTE, SECOND or MILLISECOND defined in the DateTickUnit class. Do *not* use the constants defined in java.util.Calendar.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray32);
        java.lang.String[] strArray36 = new java.lang.String[] { "SerialDate.weekInMonthToString(): invalid code.", "VerticalAlignment.TOP" };
        java.lang.Number[] numberArray44 = new java.lang.Number[] { (short) 1, 100.0f, 2, (short) -1, (-1.0f) };
        java.lang.Number[] numberArray50 = new java.lang.Number[] { (short) 1, 100.0f, 2, (short) -1, (-1.0f) };
        java.lang.Number[][] numberArray51 = new java.lang.Number[][] { numberArray44, numberArray50 };
        org.jfree.data.category.CategoryDataset categoryDataset52 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray51);
        java.lang.Number[][] numberArray53 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset54 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray36, numberArray51, numberArray53);
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset55 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray32, numberArray53);
        try {
            org.jfree.data.Range range57 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset55, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(strArray36);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(categoryDataset52);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        stackedAreaRenderer0.setSeriesVisibleInLegend((int) (byte) 1, (java.lang.Boolean) false);
        java.lang.Object obj4 = stackedAreaRenderer0.clone();
        java.awt.Paint paint7 = stackedAreaRenderer0.getItemLabelPaint(1, 500);
        stackedAreaRenderer0.setRenderAsPercentages(true);
        boolean boolean11 = stackedAreaRenderer0.equals((java.lang.Object) "ChartChangeEventType.GENERAL");
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, 0.0d);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange4, (double) '#');
        numberAxis2.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        boolean boolean10 = numberAxis2.isNegativeArrowVisible();
        boolean boolean11 = numberAxis2.isTickMarksVisible();
        java.lang.Object obj12 = numberAxis2.clone();
        java.awt.Font font17 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand18 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis2, (double) 11, 0.0d, (double) 'a', (double) 100, font17);
        org.jfree.chart.ChartColor chartColor22 = new org.jfree.chart.ChartColor(0, (int) '#', (int) (byte) 10);
        org.jfree.chart.text.TextMeasurer textMeasurer25 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock26 = org.jfree.chart.text.TextUtilities.createTextBlock("http://www.jfree.org/jfreechart/index.html", font17, (java.awt.Paint) chartColor22, (float) 100L, (int) ' ', textMeasurer25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(font17);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(255);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic2 = new org.jfree.chart.title.LegendGraphic(shape0, (java.awt.Paint) color1);
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        org.jfree.chart.util.Rotation rotation5 = piePlot4.getDirection();
        org.jfree.chart.plot.Plot plot6 = piePlot4.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        piePlot4.datasetChanged(datasetChangeEvent7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        piePlot4.drawBackgroundImage(graphics2D9, rectangle2D10);
        java.awt.Shape shape17 = null;
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Paint paint21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke22 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape24 = null;
        java.awt.Stroke stroke25 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color26 = java.awt.Color.black;
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("", "hi!", "hi!", "", true, shape17, false, (java.awt.Paint) color19, false, paint21, stroke22, true, shape24, stroke25, (java.awt.Paint) color26);
        java.awt.Stroke stroke28 = legendItem27.getLineStroke();
        piePlot4.setBaseSectionOutlineStroke(stroke28);
        legendGraphic2.setOutlineStroke(stroke28);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor31 = legendGraphic2.getShapeLocation();
        java.awt.Graphics2D graphics2D32 = null;
        org.jfree.chart.util.Size2D size2D35 = new org.jfree.chart.util.Size2D((double) 0.0f, (double) 1L);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor38 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Rectangle2D rectangle2D39 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D35, (double) (byte) 100, (double) 10, rectangleAnchor38);
        try {
            legendGraphic2.draw(graphics2D32, rectangle2D39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rotation5);
        org.junit.Assert.assertNull(plot6);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(rectangleAnchor31);
        org.junit.Assert.assertNotNull(rectangleAnchor38);
        org.junit.Assert.assertNotNull(rectangle2D39);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list1 = defaultCategoryDataset0.getRowKeys();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod6 = new org.jfree.data.time.SimpleTimePeriod((long) 10, (long) 'a');
        java.util.Date date7 = simpleTimePeriod6.getEnd();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date7);
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone9;
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date7, timeZone9);
        defaultCategoryDataset0.addValue((java.lang.Number) (-0.0d), (java.lang.Comparable) "CategoryLabelWidthType.CATEGORY", (java.lang.Comparable) date7);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone9);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.util.Rotation rotation3 = piePlot2.getDirection();
        org.jfree.chart.plot.Plot plot4 = piePlot2.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        piePlot2.datasetChanged(datasetChangeEvent5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        piePlot2.drawBackgroundImage(graphics2D7, rectangle2D8);
        java.awt.Paint paint10 = piePlot2.getBaseSectionOutlinePaint();
        java.awt.Paint paint11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot2.setBaseSectionPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot2);
        boolean boolean14 = jFreeChart13.isBorderVisible();
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment16 = textTitle15.getHorizontalAlignment();
        jFreeChart13.addSubtitle((org.jfree.chart.title.Title) textTitle15);
        int int18 = jFreeChart13.getBackgroundImageAlignment();
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 15 + "'", int18 == 15);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        java.awt.Paint paint0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 0.0f, (double) 1L);
        double double3 = size2D2.width;
        java.lang.String str4 = size2D2.toString();
        size2D2.width = 0.25d;
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Size2D[width=0.0, height=1.0]" + "'", str4.equals("Size2D[width=0.0, height=1.0]"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, 0.0d);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange4, (double) '#');
        numberAxis2.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        boolean boolean10 = numberAxis2.isNegativeArrowVisible();
        boolean boolean11 = numberAxis2.isTickMarksVisible();
        java.lang.String str12 = numberAxis2.getLabel();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean15 = numberAxis3D14.isInverted();
        org.jfree.data.time.DateRange dateRange16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis3D14.setRangeWithMargins((org.jfree.data.Range) dateRange16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, xYItemRenderer18);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray20 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot19.setRenderers(xYItemRendererArray20);
        int int22 = xYPlot19.getSeriesCount();
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double26 = numberAxis25.getFixedAutoRange();
        java.text.NumberFormat numberFormat27 = numberAxis25.getNumberFormatOverride();
        java.awt.Paint paint28 = numberAxis25.getAxisLinePaint();
        java.lang.String str29 = numberAxis25.getLabelToolTip();
        xYPlot19.setDomainAxis((int) '#', (org.jfree.chart.axis.ValueAxis) numberAxis25, true);
        java.awt.Paint paint32 = xYPlot19.getRangeZeroBaselinePaint();
        xYPlot19.mapDatasetToDomainAxis((int) (byte) 100, 11);
        org.jfree.chart.axis.NumberAxis numberAxis38 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double39 = numberAxis38.getFixedAutoRange();
        java.awt.Stroke stroke40 = numberAxis38.getTickMarkStroke();
        xYPlot19.setRangeAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) numberAxis38, false);
        boolean boolean43 = xYPlot19.isDomainZoomable();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateRange16);
        org.junit.Assert.assertNotNull(xYItemRendererArray20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNull(numberFormat27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, 0.0d);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange4, (double) '#');
        numberAxis2.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        boolean boolean10 = numberAxis2.isNegativeArrowVisible();
        boolean boolean11 = numberAxis2.isTickMarksVisible();
        java.lang.Object obj12 = numberAxis2.clone();
        java.awt.Font font17 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand18 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis2, (double) 11, 0.0d, (double) 'a', (double) 100, font17);
        java.awt.Paint paint19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.text.TextBlock textBlock20 = org.jfree.chart.text.TextUtilities.createTextBlock("NO_CHANGE", font17, paint19);
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment22 = textTitle21.getHorizontalAlignment();
        java.util.List list31 = null;
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem32 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 1L, (java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.05d, (java.lang.Number) 5, (java.lang.Number) (-1), (java.lang.Number) 100.0d, (java.lang.Number) 0L, list31);
        boolean boolean33 = horizontalAlignment22.equals((java.lang.Object) 1.0f);
        textBlock20.setLineAlignment(horizontalAlignment22);
        org.jfree.chart.text.TextLine textLine36 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.text.TextFragment textFragment37 = textLine36.getFirstTextFragment();
        textBlock20.addLine(textLine36);
        java.awt.Graphics2D graphics2D39 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor42 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor43 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition44 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor42, textBlockAnchor43);
        try {
            java.awt.Shape shape48 = textBlock20.calculateBounds(graphics2D39, 0.0f, 0.0f, textBlockAnchor43, (float) (byte) 1, (float) 10, 0.2d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(textBlock20);
        org.junit.Assert.assertNotNull(horizontalAlignment22);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(textFragment37);
        org.junit.Assert.assertNotNull(rectangleAnchor42);
        org.junit.Assert.assertNotNull(textBlockAnchor43);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle(" version ({0}, {1}) = {3} - {4}.\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n({0}, {1}) = {3} - {4}", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, 0.0d);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange4, (double) '#');
        numberAxis2.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        boolean boolean10 = numberAxis2.isNegativeArrowVisible();
        boolean boolean11 = numberAxis2.isTickMarksVisible();
        java.lang.String str12 = numberAxis2.getLabel();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean15 = numberAxis3D14.isInverted();
        org.jfree.data.time.DateRange dateRange16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis3D14.setRangeWithMargins((org.jfree.data.Range) dateRange16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, xYItemRenderer18);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray20 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot19.setRenderers(xYItemRendererArray20);
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        xYPlot19.setDataset((int) (byte) 1, xYDataset23);
        xYPlot19.setRangeCrosshairValue(0.0d, true);
        boolean boolean28 = xYPlot19.isRangeCrosshairLockedOnData();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent29 = null;
        xYPlot19.notifyListeners(plotChangeEvent29);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateRange16);
        org.junit.Assert.assertNotNull(xYItemRendererArray20);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("RectangleEdge.LEFT");
        java.lang.Object obj2 = taskSeries1.clone();
        taskSeries1.removeAll();
        taskSeries1.setKey((java.lang.Comparable) "Other");
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        int int1 = keyedObjects0.getItemCount();
        java.lang.Object obj3 = keyedObjects0.getObject((java.lang.Comparable) (short) -1);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean6 = numberAxis5.getAutoRangeStickyZero();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        numberAxis5.setTickMarkStroke(stroke7);
        numberAxis5.setTickMarkInsideLength(0.0f);
        numberAxis5.setAutoRangeMinimumSize((double) 3, false);
        boolean boolean14 = keyedObjects0.equals((java.lang.Object) numberAxis5);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection15 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list16 = taskSeriesCollection15.getRowKeys();
        int int18 = taskSeriesCollection15.indexOf((java.lang.Comparable) "({0}, {1}) = {2}");
        int int19 = taskSeriesCollection15.getColumnCount();
        boolean boolean20 = numberAxis5.hasListener((java.util.EventListener) taskSeriesCollection15);
        org.jfree.data.general.PieDataset pieDataset21 = null;
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot(pieDataset21);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator23 = null;
        piePlot22.setToolTipGenerator(pieToolTipGenerator23);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod((long) 10, (long) 'a');
        java.awt.Stroke stroke28 = piePlot22.getSectionOutlineStroke((java.lang.Comparable) simpleTimePeriod27);
        java.util.Date date29 = simpleTimePeriod27.getEnd();
        java.util.Date date30 = simpleTimePeriod27.getEnd();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.chart.ChartColor chartColor36 = new org.jfree.chart.ChartColor((int) (short) 0, (int) (byte) 100, (int) '#');
        boolean boolean37 = spreadsheetDate32.equals((java.lang.Object) (short) 0);
        int int38 = spreadsheetDate32.getDayOfWeek();
        try {
            java.lang.Number number39 = taskSeriesCollection15.getEndValue((java.lang.Comparable) simpleTimePeriod27, (java.lang.Comparable) int38);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(stroke28);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2 + "'", int38 == 2);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.util.Rotation rotation3 = piePlot2.getDirection();
        org.jfree.chart.plot.Plot plot4 = piePlot2.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        piePlot2.datasetChanged(datasetChangeEvent5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        piePlot2.drawBackgroundImage(graphics2D7, rectangle2D8);
        java.awt.Paint paint10 = piePlot2.getBaseSectionOutlinePaint();
        java.awt.Paint paint11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot2.setBaseSectionPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart13.setTitle("({0}, {1}) = {3} - {4}");
        org.jfree.chart.title.TextTitle textTitle16 = jFreeChart13.getTitle();
        java.awt.Stroke stroke17 = jFreeChart13.getBorderStroke();
        jFreeChart13.setAntiAlias(true);
        org.jfree.chart.ui.Library library24 = new org.jfree.chart.ui.Library("hi!", "hi!", "hi!", "");
        java.awt.Paint paint25 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        boolean boolean26 = library24.equals((java.lang.Object) paint25);
        jFreeChart13.setBorderPaint(paint25);
        jFreeChart13.setTextAntiAlias(true);
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(textTitle16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 2, (float) 4);
        barRenderer3D0.setSeriesShape((int) (short) 1, shape4, false);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer8 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.LegendItem legendItem11 = stackedAreaRenderer8.getLegendItem((int) 'a', 0);
        java.awt.Shape shape13 = null;
        stackedAreaRenderer8.setSeriesShape((int) '4', shape13, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = stackedAreaRenderer8.getSeriesPositiveItemLabelPosition((int) (byte) 1);
        barRenderer3D0.setSeriesPositiveItemLabelPosition((int) '#', itemLabelPosition17);
        barRenderer3D0.setMaximumBarWidth((double) ' ');
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(legendItem11);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset2 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        int int3 = defaultStatisticalCategoryDataset2.getColumnCount();
        java.lang.Comparable comparable4 = null;
        int int5 = defaultStatisticalCategoryDataset2.getRowIndex(comparable4);
        java.lang.Object obj6 = defaultStatisticalCategoryDataset2.clone();
        java.util.List list7 = defaultStatisticalCategoryDataset2.getColumnKeys();
        org.jfree.data.general.PieDataset pieDataset9 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset2, 500);
        org.jfree.data.Range range10 = stackedBarRenderer3D1.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset2);
        try {
            java.lang.Number number13 = defaultStatisticalCategoryDataset2.getStdDevValue(15, (-162432));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 15, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNotNull(pieDataset9);
        org.junit.Assert.assertNull(range10);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        boolean boolean1 = boxAndWhiskerRenderer0.getBaseItemLabelsVisible();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer3 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.LegendItem legendItem6 = stackedAreaRenderer3.getLegendItem((int) 'a', 0);
        java.awt.Shape shape8 = null;
        stackedAreaRenderer3.setSeriesShape((int) '4', shape8, true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator11 = null;
        stackedAreaRenderer3.setBaseURLGenerator(categoryURLGenerator11);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = stackedAreaRenderer3.getNegativeItemLabelPosition(100, (int) (short) 0);
        boxAndWhiskerRenderer0.setSeriesPositiveItemLabelPosition((int) '#', itemLabelPosition15);
        double double17 = itemLabelPosition15.getAngle();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(legendItem6);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, 0.0d);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange4, (double) '#');
        numberAxis2.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        boolean boolean10 = numberAxis2.isNegativeArrowVisible();
        boolean boolean11 = numberAxis2.isTickMarksVisible();
        java.lang.String str12 = numberAxis2.getLabel();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean15 = numberAxis3D14.isInverted();
        org.jfree.data.time.DateRange dateRange16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis3D14.setRangeWithMargins((org.jfree.data.Range) dateRange16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, xYItemRenderer18);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray20 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot19.setRenderers(xYItemRendererArray20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        xYPlot19.zoomRangeAxes((double) (-1L), plotRenderingInfo23, point2D24);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        xYPlot19.setDataset(xYDataset26);
        xYPlot19.configureDomainAxes();
        org.jfree.chart.axis.AxisSpace axisSpace29 = new org.jfree.chart.axis.AxisSpace();
        double double30 = axisSpace29.getRight();
        xYPlot19.setFixedDomainAxisSpace(axisSpace29);
        double double32 = axisSpace29.getLeft();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateRange16);
        org.junit.Assert.assertNotNull(xYItemRendererArray20);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray32);
        java.lang.String[] strArray36 = new java.lang.String[] { "SerialDate.weekInMonthToString(): invalid code.", "VerticalAlignment.TOP" };
        java.lang.Number[] numberArray44 = new java.lang.Number[] { (short) 1, 100.0f, 2, (short) -1, (-1.0f) };
        java.lang.Number[] numberArray50 = new java.lang.Number[] { (short) 1, 100.0f, 2, (short) -1, (-1.0f) };
        java.lang.Number[][] numberArray51 = new java.lang.Number[][] { numberArray44, numberArray50 };
        org.jfree.data.category.CategoryDataset categoryDataset52 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray51);
        java.lang.Number[][] numberArray53 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset54 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray36, numberArray51, numberArray53);
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset55 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray32, numberArray53);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate57 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.chart.ChartColor chartColor61 = new org.jfree.chart.ChartColor((int) (short) 0, (int) (byte) 100, (int) '#');
        boolean boolean62 = spreadsheetDate57.equals((java.lang.Object) (short) 0);
        int int63 = spreadsheetDate57.getDayOfWeek();
        int int64 = spreadsheetDate57.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate66 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.chart.ChartColor chartColor70 = new org.jfree.chart.ChartColor((int) (short) 0, (int) (byte) 100, (int) '#');
        boolean boolean71 = spreadsheetDate66.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate73 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate74 = spreadsheetDate66.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate73);
        boolean boolean75 = spreadsheetDate57.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate66);
        try {
            int int76 = defaultIntervalCategoryDataset55.getSeriesIndex((java.lang.Comparable) spreadsheetDate66);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(strArray36);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(categoryDataset52);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 2 + "'", int63 == 2);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 100 + "'", int64 == 100);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(serialDate74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, 0.0d);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange4, (double) '#');
        numberAxis2.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        boolean boolean10 = numberAxis2.isNegativeArrowVisible();
        boolean boolean11 = numberAxis2.isTickMarksVisible();
        java.lang.String str12 = numberAxis2.getLabel();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean15 = numberAxis3D14.isInverted();
        org.jfree.data.time.DateRange dateRange16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis3D14.setRangeWithMargins((org.jfree.data.Range) dateRange16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, xYItemRenderer18);
        numberAxis3D14.setTickMarksVisible(false);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateRange16);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.util.Rotation rotation3 = piePlot2.getDirection();
        org.jfree.chart.plot.Plot plot4 = piePlot2.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        piePlot2.datasetChanged(datasetChangeEvent5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        piePlot2.drawBackgroundImage(graphics2D7, rectangle2D8);
        java.awt.Paint paint10 = piePlot2.getBaseSectionOutlinePaint();
        java.awt.Paint paint11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot2.setBaseSectionPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart13.setBackgroundImageAlpha((float) (byte) 10);
        org.jfree.chart.event.ChartProgressListener chartProgressListener16 = null;
        jFreeChart13.removeProgressListener(chartProgressListener16);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer18 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean19 = jFreeChart13.equals((java.lang.Object) lineAndShapeRenderer18);
        int int20 = jFreeChart13.getSubtitleCount();
        java.util.List list21 = jFreeChart13.getSubtitles();
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(list21);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = piePlot1.getDirection();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator3 = piePlot1.getURLGenerator();
        piePlot1.setMaximumLabelWidth((double) (short) 100);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        org.jfree.chart.util.Rotation rotation8 = piePlot7.getDirection();
        org.jfree.chart.plot.Plot plot9 = piePlot7.getParent();
        org.jfree.chart.plot.Plot plot10 = piePlot7.getRootPlot();
        java.awt.Color color11 = java.awt.Color.MAGENTA;
        piePlot7.setOutlinePaint((java.awt.Paint) color11);
        java.awt.Stroke stroke13 = piePlot7.getOutlineStroke();
        piePlot1.setBaseSectionOutlineStroke(stroke13);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator15 = null;
        piePlot1.setToolTipGenerator(pieToolTipGenerator15);
        org.junit.Assert.assertNotNull(rotation2);
        org.junit.Assert.assertNull(pieURLGenerator3);
        org.junit.Assert.assertNotNull(rotation8);
        org.junit.Assert.assertNull(plot9);
        org.junit.Assert.assertNotNull(plot10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP;
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double3 = rectangleInsets1.calculateBottomOutset((double) (-1L));
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = org.jfree.chart.util.RectangleAnchor.TOP;
        boolean boolean5 = rectangleInsets1.equals((java.lang.Object) rectangleAnchor4);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor6 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        boolean boolean9 = textAnchor7.equals((java.lang.Object) 'a');
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType11 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition13 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor4, textBlockAnchor6, textAnchor7, (double) (-2208960000000L), categoryLabelWidthType11, (float) 3);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor14 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.text.TextAnchor textAnchor19 = null;
        org.jfree.chart.text.TextAnchor textAnchor21 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        java.awt.Shape shape22 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D16, (float) 1, (float) 0, textAnchor19, (double) 100L, textAnchor21);
        java.lang.String str23 = textAnchor21.toString();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType25 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition27 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor4, textBlockAnchor14, textAnchor21, 0.0d, categoryLabelWidthType25, (float) (short) 100);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor28 = categoryLabelPosition27.getLabelAnchor();
        org.jfree.chart.text.TextAnchor textAnchor29 = null;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType31 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition33 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor28, textAnchor29, (double) 1969, categoryLabelWidthType31, (float) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rotationAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor6);
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(categoryLabelWidthType11);
        org.junit.Assert.assertNotNull(textBlockAnchor14);
        org.junit.Assert.assertNotNull(textAnchor21);
        org.junit.Assert.assertNull(shape22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "TextAnchor.CENTER_RIGHT" + "'", str23.equals("TextAnchor.CENTER_RIGHT"));
        org.junit.Assert.assertNotNull(categoryLabelWidthType25);
        org.junit.Assert.assertNotNull(textBlockAnchor28);
        org.junit.Assert.assertNotNull(categoryLabelWidthType31);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("ChartEntity: tooltip = ");
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        java.awt.Image image0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE;
        org.junit.Assert.assertNull(image0);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        int int1 = keyedObjects0.getItemCount();
        java.lang.Object obj3 = keyedObjects0.getObject((java.lang.Comparable) (short) -1);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean6 = numberAxis5.getAutoRangeStickyZero();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        numberAxis5.setTickMarkStroke(stroke7);
        numberAxis5.setTickMarkInsideLength(0.0f);
        numberAxis5.setAutoRangeMinimumSize((double) 3, false);
        boolean boolean14 = keyedObjects0.equals((java.lang.Object) numberAxis5);
        java.lang.Object obj15 = keyedObjects0.clone();
        int int17 = keyedObjects0.getIndex((java.lang.Comparable) 90.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getFixedAutoRange();
        java.text.NumberFormat numberFormat4 = numberAxis2.getNumberFormatOverride();
        boolean boolean5 = numberAxis2.isVerticalTickLabels();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, polarItemRenderer6);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.util.Rotation rotation10 = piePlot9.getDirection();
        org.jfree.chart.plot.Plot plot11 = piePlot9.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = null;
        piePlot9.datasetChanged(datasetChangeEvent12);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        piePlot9.drawBackgroundImage(graphics2D14, rectangle2D15);
        java.awt.Paint paint17 = piePlot9.getBaseSectionOutlinePaint();
        java.awt.Paint paint18 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot9.setBaseSectionPaint(paint18);
        polarPlot7.setAngleGridlinePaint(paint18);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D22 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean23 = numberAxis3D22.isTickMarksVisible();
        org.jfree.chart.plot.Plot plot24 = numberAxis3D22.getPlot();
        org.jfree.data.Range range25 = polarPlot7.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D22);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        polarPlot7.setDataset(xYDataset26);
        polarPlot7.zoom(32.0d);
        boolean boolean30 = polarPlot7.isRadiusGridlinesVisible();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNull(numberFormat4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rotation10);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(plot24);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_FINISHED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        float float1 = categoryAxis3D0.getMaximumCategoryLabelWidthRatio();
        java.lang.Object obj2 = categoryAxis3D0.clone();
        double double3 = categoryAxis3D0.getLowerMargin();
        float float4 = categoryAxis3D0.getMaximumCategoryLabelWidthRatio();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.CENTER;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        stackedAreaRenderer0.setSeriesVisibleInLegend((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType4 = stackedAreaRenderer0.getEndType();
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType5 = org.jfree.chart.renderer.AreaRendererEndType.LEVEL;
        stackedAreaRenderer0.setEndType(areaRendererEndType5);
        org.junit.Assert.assertNotNull(areaRendererEndType4);
        org.junit.Assert.assertNotNull(areaRendererEndType5);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setDrawOutlines(true);
        boolean boolean5 = lineAndShapeRenderer0.getItemShapeVisible(0, 6);
        boolean boolean6 = lineAndShapeRenderer0.getUseOutlinePaint();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange3, 0.0d);
        org.jfree.data.Range range7 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange3, (double) '#');
        numberAxis1.setDefaultAutoRange((org.jfree.data.Range) dateRange3);
        java.lang.String str9 = dateRange3.toString();
        double double10 = dateRange3.getLowerBound();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(dateRange3);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str9.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        java.awt.Shape shape6 = null;
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Paint paint10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape13 = null;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color15 = java.awt.Color.black;
        org.jfree.chart.LegendItem legendItem16 = new org.jfree.chart.LegendItem("", "hi!", "hi!", "", true, shape6, false, (java.awt.Paint) color8, false, paint10, stroke11, true, shape13, stroke14, (java.awt.Paint) color15);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean19 = numberAxis18.getAutoRangeStickyZero();
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        numberAxis18.setTickMarkStroke(stroke20);
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 12, (java.awt.Paint) color8, stroke20);
        org.jfree.data.time.TimePeriod timePeriod24 = null;
        org.jfree.data.gantt.Task task25 = new org.jfree.data.gantt.Task("hi!", timePeriod24);
        java.lang.Object obj26 = null;
        boolean boolean27 = task25.equals(obj26);
        org.jfree.data.time.TimePeriod timePeriod29 = null;
        org.jfree.data.gantt.Task task30 = new org.jfree.data.gantt.Task("hi!", timePeriod29);
        java.lang.Object obj31 = null;
        boolean boolean32 = task30.equals(obj31);
        task30.setPercentComplete((java.lang.Double) 90.0d);
        task25.removeSubtask(task30);
        boolean boolean36 = categoryMarker22.equals((java.lang.Object) task30);
        java.lang.String str37 = task30.getDescription();
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year38.next();
        long long40 = year38.getLastMillisecond();
        task30.setDuration((org.jfree.data.time.TimePeriod) year38);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "hi!" + "'", str37.equals("hi!"));
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1577865599999L + "'", long40 == 1577865599999L);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        java.awt.Shape shape5 = null;
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape12 = null;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color14 = java.awt.Color.black;
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("", "hi!", "hi!", "", true, shape5, false, (java.awt.Paint) color7, false, paint9, stroke10, true, shape12, stroke13, (java.awt.Paint) color14);
        java.awt.Stroke stroke16 = legendItem15.getLineStroke();
        legendItem15.setSeriesIndex((int) (short) 0);
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray30 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray35 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray40 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray45 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray50 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[][] numberArray51 = new java.lang.Number[][] { numberArray25, numberArray30, numberArray35, numberArray40, numberArray45, numberArray50 };
        org.jfree.data.category.CategoryDataset categoryDataset52 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray51);
        org.jfree.data.general.PieDataset pieDataset54 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset52, (int) (short) 1);
        legendItem15.setDataset((org.jfree.data.general.Dataset) categoryDataset52);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot56 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset52);
        org.jfree.chart.text.TextLine textLine60 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.text.TextFragment textFragment61 = textLine60.getFirstTextFragment();
        java.awt.Font font62 = textFragment61.getFont();
        java.awt.Color color63 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.block.LabelBlock labelBlock64 = new org.jfree.chart.block.LabelBlock("hi!", font62, (java.awt.Paint) color63);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer65 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Paint paint66 = ganttRenderer65.getCompletePaint();
        org.jfree.chart.block.LabelBlock labelBlock67 = new org.jfree.chart.block.LabelBlock("({0}, {1}) = {3} - {4}", font62, paint66);
        java.awt.Paint paint68 = labelBlock67.getPaint();
        multiplePiePlot56.setAggregatedItemsPaint(paint68);
        boolean boolean71 = multiplePiePlot56.equals((java.lang.Object) 4);
        org.jfree.chart.util.TableOrder tableOrder72 = multiplePiePlot56.getDataExtractOrder();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(categoryDataset52);
        org.junit.Assert.assertNotNull(pieDataset54);
        org.junit.Assert.assertNotNull(textFragment61);
        org.junit.Assert.assertNotNull(font62);
        org.junit.Assert.assertNotNull(color63);
        org.junit.Assert.assertNotNull(paint66);
        org.junit.Assert.assertNotNull(paint68);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(tableOrder72);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, 0.0d);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange4, (double) '#');
        numberAxis2.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        boolean boolean10 = numberAxis2.isNegativeArrowVisible();
        boolean boolean11 = numberAxis2.isTickMarksVisible();
        java.lang.String str12 = numberAxis2.getLabel();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean15 = numberAxis3D14.isInverted();
        org.jfree.data.time.DateRange dateRange16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis3D14.setRangeWithMargins((org.jfree.data.Range) dateRange16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, xYItemRenderer18);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str23 = numberAxis22.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange24 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange24, 0.0d);
        org.jfree.data.Range range28 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange24, (double) '#');
        numberAxis22.setDefaultAutoRange((org.jfree.data.Range) dateRange24);
        boolean boolean30 = numberAxis22.isNegativeArrowVisible();
        boolean boolean31 = numberAxis22.isTickMarksVisible();
        numberAxis22.setFixedAutoRange((double) 1);
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str36 = numberAxis35.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange37 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint39 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange37, 0.0d);
        org.jfree.data.Range range41 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange37, (double) '#');
        numberAxis35.setDefaultAutoRange((org.jfree.data.Range) dateRange37);
        boolean boolean43 = numberAxis35.isNegativeArrowVisible();
        boolean boolean44 = numberAxis35.isTickMarksVisible();
        java.lang.Object obj45 = numberAxis35.clone();
        java.awt.Font font50 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand51 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis35, (double) 11, 0.0d, (double) 'a', (double) 100, font50);
        java.awt.Graphics2D graphics2D52 = null;
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        markerAxisBand51.draw(graphics2D52, rectangle2D53, rectangle2D54, (double) 12, (double) 12);
        numberAxis22.setMarkerBand(markerAxisBand51);
        xYPlot19.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) numberAxis22);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder60 = xYPlot19.getSeriesRenderingOrder();
        int int61 = xYPlot19.getDomainAxisCount();
        java.lang.Object obj62 = xYPlot19.clone();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent63 = null;
        xYPlot19.datasetChanged(datasetChangeEvent63);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateRange16);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(dateRange24);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertNotNull(dateRange37);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(obj45);
        org.junit.Assert.assertNotNull(font50);
        org.junit.Assert.assertNotNull(seriesRenderingOrder60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 12 + "'", int61 == 12);
        org.junit.Assert.assertNotNull(obj62);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) paint0);
        org.jfree.chart.JFreeChart jFreeChart2 = null;
        chartChangeEvent1.setChart(jFreeChart2);
        org.jfree.chart.JFreeChart jFreeChart4 = chartChangeEvent1.getChart();
        java.lang.Object obj5 = chartChangeEvent1.getSource();
        org.junit.Assert.assertNotNull(paint0);
        org.junit.Assert.assertNull(jFreeChart4);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "({0}, {1}) = {3} - {4}", "", image3, "hi!", "hi!", "({0}, {1}) = {3} - {4}");
        java.util.List list8 = projectInfo7.getContributors();
        java.awt.Image image12 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo16 = new org.jfree.chart.ui.ProjectInfo("", "({0}, {1}) = {3} - {4}", "", image12, "hi!", "hi!", "({0}, {1}) = {3} - {4}");
        java.awt.Image image17 = null;
        projectInfo16.setLogo(image17);
        projectInfo7.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo16);
        projectInfo7.setLicenceName("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        org.junit.Assert.assertNull(list8);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 2, (float) 4);
        barRenderer3D0.setSeriesShape((int) (short) 1, shape4, false);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer8 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.LegendItem legendItem11 = stackedAreaRenderer8.getLegendItem((int) 'a', 0);
        java.awt.Shape shape13 = null;
        stackedAreaRenderer8.setSeriesShape((int) '4', shape13, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = stackedAreaRenderer8.getSeriesPositiveItemLabelPosition((int) (byte) 1);
        barRenderer3D0.setSeriesPositiveItemLabelPosition((int) '#', itemLabelPosition17);
        java.awt.Stroke stroke19 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer3D0.setBaseOutlineStroke(stroke19);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(legendItem11);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertNotNull(stroke19);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, 0.0d);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange4, (double) '#');
        numberAxis2.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        boolean boolean10 = numberAxis2.isNegativeArrowVisible();
        boolean boolean11 = numberAxis2.isTickMarksVisible();
        java.lang.Object obj12 = numberAxis2.clone();
        numberAxis2.setAutoRangeIncludesZero(true);
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str17 = numberAxis16.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange18 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange18, 0.0d);
        org.jfree.data.Range range22 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange18, (double) '#');
        numberAxis16.setDefaultAutoRange((org.jfree.data.Range) dateRange18);
        boolean boolean24 = numberAxis16.isNegativeArrowVisible();
        boolean boolean25 = numberAxis16.isTickMarksVisible();
        java.lang.Object obj26 = numberAxis16.clone();
        java.awt.Font font31 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand32 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis16, (double) 11, 0.0d, (double) 'a', (double) 100, font31);
        numberAxis2.setTickLabelFont(font31);
        org.jfree.data.general.PieDataset pieDataset34 = null;
        org.jfree.chart.plot.PiePlot piePlot35 = new org.jfree.chart.plot.PiePlot(pieDataset34);
        org.jfree.chart.util.Rotation rotation36 = piePlot35.getDirection();
        org.jfree.chart.plot.Plot plot37 = piePlot35.getParent();
        org.jfree.chart.plot.Plot plot38 = piePlot35.getRootPlot();
        org.jfree.chart.JFreeChart jFreeChart40 = new org.jfree.chart.JFreeChart("PlotOrientation.VERTICAL", font31, (org.jfree.chart.plot.Plot) piePlot35, false);
        org.jfree.chart.title.TextTitle textTitle41 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment42 = textTitle41.getHorizontalAlignment();
        org.jfree.chart.title.TextTitle textTitle43 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment44 = textTitle43.getHorizontalAlignment();
        java.util.List list53 = null;
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem54 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 1L, (java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.05d, (java.lang.Number) 5, (java.lang.Number) (-1), (java.lang.Number) 100.0d, (java.lang.Number) 0L, list53);
        boolean boolean55 = horizontalAlignment44.equals((java.lang.Object) 1.0f);
        textTitle41.setHorizontalAlignment(horizontalAlignment44);
        jFreeChart40.removeSubtitle((org.jfree.chart.title.Title) textTitle41);
        boolean boolean58 = textTitle41.getNotify();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(dateRange18);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(rotation36);
        org.junit.Assert.assertNull(plot37);
        org.junit.Assert.assertNotNull(plot38);
        org.junit.Assert.assertNotNull(horizontalAlignment42);
        org.junit.Assert.assertNotNull(horizontalAlignment44);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic2 = new org.jfree.chart.title.LegendGraphic(shape0, (java.awt.Paint) color1);
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        org.jfree.chart.util.Rotation rotation5 = piePlot4.getDirection();
        org.jfree.chart.plot.Plot plot6 = piePlot4.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        piePlot4.datasetChanged(datasetChangeEvent7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        piePlot4.drawBackgroundImage(graphics2D9, rectangle2D10);
        java.awt.Shape shape17 = null;
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Paint paint21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke22 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape24 = null;
        java.awt.Stroke stroke25 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color26 = java.awt.Color.black;
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("", "hi!", "hi!", "", true, shape17, false, (java.awt.Paint) color19, false, paint21, stroke22, true, shape24, stroke25, (java.awt.Paint) color26);
        java.awt.Stroke stroke28 = legendItem27.getLineStroke();
        piePlot4.setBaseSectionOutlineStroke(stroke28);
        legendGraphic2.setOutlineStroke(stroke28);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor31 = legendGraphic2.getShapeLocation();
        java.awt.Stroke stroke32 = legendGraphic2.getOutlineStroke();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rotation5);
        org.junit.Assert.assertNull(plot6);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(rectangleAnchor31);
        org.junit.Assert.assertNotNull(stroke32);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = barRenderer0.getBaseToolTipGenerator();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator4 = barRenderer0.getToolTipGenerator((int) (byte) 100, 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = barRenderer0.getPlot();
        org.junit.Assert.assertNull(categoryToolTipGenerator1);
        org.junit.Assert.assertNull(categoryToolTipGenerator4);
        org.junit.Assert.assertNull(categoryPlot5);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, 0.0d);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange4, (double) '#');
        numberAxis2.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        boolean boolean10 = numberAxis2.isNegativeArrowVisible();
        boolean boolean11 = numberAxis2.isTickMarksVisible();
        java.lang.String str12 = numberAxis2.getLabel();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean15 = numberAxis3D14.isInverted();
        org.jfree.data.time.DateRange dateRange16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis3D14.setRangeWithMargins((org.jfree.data.Range) dateRange16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, xYItemRenderer18);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray20 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot19.setRenderers(xYItemRendererArray20);
        boolean boolean22 = xYPlot19.isRangeGridlinesVisible();
        java.awt.Paint paint23 = xYPlot19.getRangeTickBandPaint();
        float float24 = xYPlot19.getForegroundAlpha();
        xYPlot19.setDomainCrosshairValue((double) 100.0f);
        java.awt.Paint paint27 = xYPlot19.getRangeGridlinePaint();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateRange16);
        org.junit.Assert.assertNotNull(xYItemRendererArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNull(paint23);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 1.0f + "'", float24 == 1.0f);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.getAutoRangeStickyZero();
        org.jfree.chart.axis.TickUnitSource tickUnitSource3 = numberAxis1.getStandardTickUnits();
        numberAxis1.setTickMarkInsideLength((float) 0);
        java.text.NumberFormat numberFormat6 = null;
        numberAxis1.setNumberFormatOverride(numberFormat6);
        org.jfree.chart.util.UnitType unitType8 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets(unitType8, (double) 3, 0.0d, (double) 0.5f, (double) 100.0f);
        numberAxis1.setLabelInsets(rectangleInsets13);
        numberAxis1.zoomRange((double) 100, Double.NaN);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(tickUnitSource3);
        org.junit.Assert.assertNotNull(unitType8);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic2 = new org.jfree.chart.title.LegendGraphic(shape0, (java.awt.Paint) color1);
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        org.jfree.chart.util.Rotation rotation5 = piePlot4.getDirection();
        org.jfree.chart.plot.Plot plot6 = piePlot4.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        piePlot4.datasetChanged(datasetChangeEvent7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        piePlot4.drawBackgroundImage(graphics2D9, rectangle2D10);
        java.awt.Shape shape17 = null;
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Paint paint21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke22 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape24 = null;
        java.awt.Stroke stroke25 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color26 = java.awt.Color.black;
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("", "hi!", "hi!", "", true, shape17, false, (java.awt.Paint) color19, false, paint21, stroke22, true, shape24, stroke25, (java.awt.Paint) color26);
        java.awt.Stroke stroke28 = legendItem27.getLineStroke();
        piePlot4.setBaseSectionOutlineStroke(stroke28);
        legendGraphic2.setOutlineStroke(stroke28);
        java.awt.Graphics2D graphics2D31 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint32 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint34 = rectangleConstraint32.toFixedWidth(4.0d);
        try {
            org.jfree.chart.util.Size2D size2D35 = legendGraphic2.arrange(graphics2D31, rectangleConstraint34);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rotation5);
        org.junit.Assert.assertNull(plot6);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(rectangleConstraint32);
        org.junit.Assert.assertNotNull(rectangleConstraint34);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getFixedAutoRange();
        java.text.NumberFormat numberFormat4 = numberAxis2.getNumberFormatOverride();
        boolean boolean5 = numberAxis2.isVerticalTickLabels();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, polarItemRenderer6);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.util.Rotation rotation10 = piePlot9.getDirection();
        org.jfree.chart.plot.Plot plot11 = piePlot9.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = null;
        piePlot9.datasetChanged(datasetChangeEvent12);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        piePlot9.drawBackgroundImage(graphics2D14, rectangle2D15);
        java.awt.Paint paint17 = piePlot9.getBaseSectionOutlinePaint();
        java.awt.Paint paint18 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot9.setBaseSectionPaint(paint18);
        polarPlot7.setAngleGridlinePaint(paint18);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D22 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean23 = numberAxis3D22.isTickMarksVisible();
        org.jfree.chart.plot.Plot plot24 = numberAxis3D22.getPlot();
        org.jfree.data.Range range25 = polarPlot7.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D22);
        java.awt.Paint paint26 = null;
        polarPlot7.setAngleGridlinePaint(paint26);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.color.ColorSpace colorSpace29 = color28.getColorSpace();
        polarPlot7.setRadiusGridlinePaint((java.awt.Paint) color28);
        int int31 = color28.getRed();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNull(numberFormat4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rotation10);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(plot24);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(colorSpace29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.util.Rotation rotation3 = piePlot2.getDirection();
        org.jfree.chart.plot.Plot plot4 = piePlot2.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        piePlot2.datasetChanged(datasetChangeEvent5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        piePlot2.drawBackgroundImage(graphics2D7, rectangle2D8);
        java.awt.Paint paint10 = piePlot2.getBaseSectionOutlinePaint();
        java.awt.Paint paint11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot2.setBaseSectionPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart13.setTitle("({0}, {1}) = {3} - {4}");
        java.lang.Object obj16 = jFreeChart13.clone();
        jFreeChart13.fireChartChanged();
        jFreeChart13.setNotify(false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo23 = null;
        java.awt.image.BufferedImage bufferedImage24 = jFreeChart13.createBufferedImage((int) (byte) 10, 100, 12, chartRenderingInfo23);
        org.jfree.chart.event.ChartProgressListener chartProgressListener25 = null;
        jFreeChart13.addProgressListener(chartProgressListener25);
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(bufferedImage24);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.awt.GradientPaint gradientPaint1 = null;
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 2, (float) 4);
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape4, "");
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity9 = new org.jfree.chart.entity.TickLabelEntity(shape4, "RectangleEdge.LEFT", "RectangleEdge.LEFT");
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape4, 1.0E-8d, 0.0f, (float) 100L);
        java.lang.Number[] numberArray22 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray27 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray37 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray42 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray47 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[][] numberArray48 = new java.lang.Number[][] { numberArray22, numberArray27, numberArray32, numberArray37, numberArray42, numberArray47 };
        org.jfree.data.category.CategoryDataset categoryDataset49 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray48);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod52 = new org.jfree.data.time.SimpleTimePeriod((long) 10, (long) 'a');
        java.lang.Comparable comparable53 = null;
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity54 = new org.jfree.chart.entity.CategoryItemEntity(shape13, "({0}, {1}) = {3} - {4}", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", categoryDataset49, (java.lang.Comparable) 10, comparable53);
        try {
            java.awt.GradientPaint gradientPaint55 = standardGradientPaintTransformer0.transform(gradientPaint1, shape13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray37);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(numberArray47);
        org.junit.Assert.assertNotNull(numberArray48);
        org.junit.Assert.assertNotNull(categoryDataset49);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, 0.0d);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange4, (double) '#');
        numberAxis2.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        boolean boolean10 = numberAxis2.isNegativeArrowVisible();
        boolean boolean11 = numberAxis2.isTickMarksVisible();
        java.lang.String str12 = numberAxis2.getLabel();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean15 = numberAxis3D14.isInverted();
        org.jfree.data.time.DateRange dateRange16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis3D14.setRangeWithMargins((org.jfree.data.Range) dateRange16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, xYItemRenderer18);
        java.awt.Paint paint20 = xYPlot19.getDomainGridlinePaint();
        xYPlot19.setRangeCrosshairVisible(true);
        xYPlot19.setRangeCrosshairValue((double) (byte) -1);
        xYPlot19.clearDomainMarkers(5);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateRange16);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = piePlot1.getDirection();
        org.jfree.chart.plot.Plot plot3 = piePlot1.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        piePlot1.datasetChanged(datasetChangeEvent4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        piePlot1.drawBackgroundImage(graphics2D6, rectangle2D7);
        java.awt.Paint paint9 = piePlot1.getBaseSectionOutlinePaint();
        java.awt.Paint paint10 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot1.setBaseSectionPaint(paint10);
        java.awt.Color color12 = java.awt.Color.red;
        piePlot1.setNoDataMessagePaint((java.awt.Paint) color12);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator14 = piePlot1.getURLGenerator();
        java.awt.Paint paint15 = piePlot1.getBackgroundPaint();
        org.junit.Assert.assertNotNull(rotation2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNull(pieURLGenerator14);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        org.jfree.data.time.TimePeriod timePeriod1 = null;
        org.jfree.data.gantt.Task task2 = new org.jfree.data.gantt.Task("hi!", timePeriod1);
        org.jfree.data.time.TimePeriod timePeriod4 = null;
        org.jfree.data.gantt.Task task5 = new org.jfree.data.gantt.Task("hi!", timePeriod4);
        java.lang.Object obj6 = null;
        boolean boolean7 = task5.equals(obj6);
        org.jfree.data.time.TimePeriod timePeriod9 = null;
        org.jfree.data.gantt.Task task10 = new org.jfree.data.gantt.Task("hi!", timePeriod9);
        java.lang.Object obj11 = null;
        boolean boolean12 = task10.equals(obj11);
        task10.setPercentComplete((java.lang.Double) 90.0d);
        task5.removeSubtask(task10);
        java.lang.String str16 = task5.getDescription();
        task2.removeSubtask(task5);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        long long20 = year19.getLastMillisecond();
        org.jfree.data.gantt.Task task21 = new org.jfree.data.gantt.Task("AxisLocation.TOP_OR_LEFT", (org.jfree.data.time.TimePeriod) year19);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer22 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Paint paint23 = ganttRenderer22.getCompletePaint();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier24 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint25 = defaultDrawingSupplier24.getNextFillPaint();
        java.awt.Stroke stroke26 = defaultDrawingSupplier24.getNextStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker27 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) year19, paint23, stroke26);
        task5.setDuration((org.jfree.data.time.TimePeriod) year19);
        task5.setDescription("VerticalAlignment.TOP");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1577865599999L + "'", long20 == 1577865599999L);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(stroke26);
    }
}

