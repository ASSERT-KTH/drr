import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator2 = barRenderer1.getBaseToolTipGenerator();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = barRenderer1.getToolTipGenerator((int) (byte) 100, 0);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        int int8 = color7.getRed();
        barRenderer1.setSeriesPaint(11, (java.awt.Paint) color7, true);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str14 = numberAxis13.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange15 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange15, 0.0d);
        org.jfree.data.Range range19 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange15, (double) '#');
        numberAxis13.setDefaultAutoRange((org.jfree.data.Range) dateRange15);
        boolean boolean21 = numberAxis13.isNegativeArrowVisible();
        boolean boolean22 = numberAxis13.isTickMarksVisible();
        numberAxis13.setFixedAutoRange((double) 1);
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str27 = numberAxis26.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange28 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange28, 0.0d);
        org.jfree.data.Range range32 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange28, (double) '#');
        numberAxis26.setDefaultAutoRange((org.jfree.data.Range) dateRange28);
        boolean boolean34 = numberAxis26.isNegativeArrowVisible();
        boolean boolean35 = numberAxis26.isTickMarksVisible();
        java.lang.Object obj36 = numberAxis26.clone();
        java.awt.Font font41 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand42 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis26, (double) 11, 0.0d, (double) 'a', (double) 100, font41);
        java.awt.Graphics2D graphics2D43 = null;
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        markerAxisBand42.draw(graphics2D43, rectangle2D44, rectangle2D45, (double) 12, (double) 12);
        numberAxis13.setMarkerBand(markerAxisBand42);
        org.jfree.chart.renderer.category.BarRenderer barRenderer50 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator51 = barRenderer50.getBaseToolTipGenerator();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator53 = null;
        barRenderer50.setSeriesURLGenerator(0, categoryURLGenerator53, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition57 = barRenderer50.getSeriesPositiveItemLabelPosition(0);
        boolean boolean58 = markerAxisBand42.equals((java.lang.Object) itemLabelPosition57);
        barRenderer1.setSeriesNegativeItemLabelPosition((int) '4', itemLabelPosition57, true);
        java.awt.Shape shape66 = null;
        java.awt.Color color68 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Paint paint70 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke71 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape73 = null;
        java.awt.Stroke stroke74 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color75 = java.awt.Color.black;
        org.jfree.chart.LegendItem legendItem76 = new org.jfree.chart.LegendItem("", "hi!", "hi!", "", true, shape66, false, (java.awt.Paint) color68, false, paint70, stroke71, true, shape73, stroke74, (java.awt.Paint) color75);
        barRenderer1.setBasePaint((java.awt.Paint) color68);
        waterfallBarRenderer0.setFirstBarPaint((java.awt.Paint) color68);
        org.junit.Assert.assertNull(categoryToolTipGenerator2);
        org.junit.Assert.assertNull(categoryToolTipGenerator5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(dateRange15);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(dateRange28);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(obj36);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertNull(categoryToolTipGenerator51);
        org.junit.Assert.assertNotNull(itemLabelPosition57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(color68);
        org.junit.Assert.assertNotNull(paint70);
        org.junit.Assert.assertNotNull(stroke71);
        org.junit.Assert.assertNotNull(stroke74);
        org.junit.Assert.assertNotNull(color75);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator1 = lineAndShapeRenderer0.getBaseURLGenerator();
        int int2 = lineAndShapeRenderer0.getPassCount();
        org.junit.Assert.assertNull(categoryURLGenerator1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator1, false);
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.util.Rotation rotation7 = piePlot6.getDirection();
        org.jfree.chart.plot.Plot plot8 = piePlot6.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent9 = null;
        piePlot6.datasetChanged(datasetChangeEvent9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        piePlot6.drawBackgroundImage(graphics2D11, rectangle2D12);
        java.awt.Paint paint14 = piePlot6.getBaseSectionOutlinePaint();
        java.awt.Paint paint15 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot6.setBaseSectionPaint(paint15);
        barRenderer0.setSeriesItemLabelPaint((int) (byte) 0, paint15);
        boolean boolean18 = barRenderer0.getAutoPopulateSeriesShape();
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator20 = new org.jfree.chart.urls.StandardCategoryURLGenerator("RectangleEdge.LEFT");
        barRenderer0.setBaseURLGenerator((org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator20);
        org.jfree.data.general.PieDataset pieDataset22 = null;
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot(pieDataset22);
        org.jfree.chart.util.Rotation rotation24 = piePlot23.getDirection();
        org.jfree.chart.plot.Plot plot25 = piePlot23.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent26 = null;
        piePlot23.datasetChanged(datasetChangeEvent26);
        org.jfree.chart.renderer.category.BarRenderer barRenderer28 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator29 = null;
        barRenderer28.setBaseToolTipGenerator(categoryToolTipGenerator29, false);
        boolean boolean32 = barRenderer28.getBaseCreateEntities();
        java.awt.Stroke stroke34 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        barRenderer28.setSeriesStroke((int) (short) 100, stroke34, false);
        piePlot23.setLabelOutlineStroke(stroke34);
        boolean boolean38 = standardCategoryURLGenerator20.equals((java.lang.Object) piePlot23);
        org.jfree.data.general.PieDataset pieDataset39 = piePlot23.getDataset();
        org.junit.Assert.assertNotNull(rotation7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(rotation24);
        org.junit.Assert.assertNull(plot25);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(pieDataset39);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.zoomRange((double) 1.0f, (double) (byte) 10);
        boolean boolean5 = numberAxis1.isPositiveArrowVisible();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 10, (long) 'a');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str7 = numberAxis6.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange8 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange8, 0.0d);
        org.jfree.data.Range range12 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange8, (double) '#');
        numberAxis6.setDefaultAutoRange((org.jfree.data.Range) dateRange8);
        org.jfree.data.Range range16 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange8, 0.0d, (double) (byte) -1);
        java.util.Date date17 = dateRange8.getUpperDate();
        org.jfree.chart.text.TextAnchor textAnchor19 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.text.TextAnchor textAnchor24 = null;
        org.jfree.chart.text.TextAnchor textAnchor26 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        java.awt.Shape shape27 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D21, (float) 1, (float) 0, textAnchor24, (double) 100L, textAnchor26);
        java.lang.String str28 = textAnchor26.toString();
        org.jfree.chart.axis.DateTick dateTick30 = new org.jfree.chart.axis.DateTick(date17, "TextAnchor.CENTER_RIGHT", textAnchor19, textAnchor26, (double) (-1.0f));
        java.util.Date date31 = dateTick30.getDate();
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod32 = new org.jfree.data.time.SimpleTimePeriod(date3, date31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires end >= start.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(dateRange8);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(textAnchor19);
        org.junit.Assert.assertNotNull(textAnchor26);
        org.junit.Assert.assertNull(shape27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "TextAnchor.CENTER_RIGHT" + "'", str28.equals("TextAnchor.CENTER_RIGHT"));
        org.junit.Assert.assertNotNull(date31);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange3, 0.0d);
        org.jfree.data.Range range7 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange3, (double) '#');
        numberAxis1.setDefaultAutoRange((org.jfree.data.Range) dateRange3);
        boolean boolean9 = numberAxis1.isNegativeArrowVisible();
        boolean boolean10 = numberAxis1.isTickMarksVisible();
        java.lang.Object obj11 = numberAxis1.clone();
        java.awt.Shape shape17 = null;
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Paint paint21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke22 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape24 = null;
        java.awt.Stroke stroke25 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color26 = java.awt.Color.black;
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("", "hi!", "hi!", "", true, shape17, false, (java.awt.Paint) color19, false, paint21, stroke22, true, shape24, stroke25, (java.awt.Paint) color26);
        java.lang.Number[] numberArray35 = new java.lang.Number[] { (short) 1, 100.0f, 2, (short) -1, (-1.0f) };
        java.lang.Number[] numberArray41 = new java.lang.Number[] { (short) 1, 100.0f, 2, (short) -1, (-1.0f) };
        java.lang.Number[][] numberArray42 = new java.lang.Number[][] { numberArray35, numberArray41 };
        org.jfree.data.category.CategoryDataset categoryDataset43 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray42);
        legendItem27.setDataset((org.jfree.data.general.Dataset) categoryDataset43);
        boolean boolean45 = numberAxis1.equals((java.lang.Object) legendItem27);
        boolean boolean46 = legendItem27.isLineVisible();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(dateRange3);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(numberArray41);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(categoryDataset43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setDrawOutlines(true);
        boolean boolean5 = lineAndShapeRenderer0.getItemShapeVisible(0, 6);
        java.awt.Paint paint8 = lineAndShapeRenderer0.getItemFillPaint((int) '4', 15);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.util.List list1 = defaultKeyedValues2D0.getColumnKeys();
        try {
            java.lang.Comparable comparable3 = defaultKeyedValues2D0.getRowKey((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.util.Size2D size2D3 = new org.jfree.chart.util.Size2D((double) 0.0f, (double) 1L);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Rectangle2D rectangle2D7 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D3, (double) (byte) 100, (double) 10, rectangleAnchor6);
        org.jfree.chart.util.Size2D size2D8 = rectangleConstraint0.calculateConstrainedSize(size2D3);
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(size2D8);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.NEGATIVE;
        boolean boolean2 = rangeType0.equals((java.lang.Object) (byte) 1);
        org.junit.Assert.assertNotNull(rangeType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = categoryLabelPositions0.getLabelPosition(rectangleEdge1);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge1);
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertNotNull(rectangleEdge1);
        org.junit.Assert.assertNotNull(categoryLabelPosition2);
        org.junit.Assert.assertNotNull(rectangleEdge3);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, 0.0d);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange4, (double) '#');
        numberAxis2.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        boolean boolean10 = numberAxis2.isNegativeArrowVisible();
        boolean boolean11 = numberAxis2.isTickMarksVisible();
        java.lang.String str12 = numberAxis2.getLabel();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean15 = numberAxis3D14.isInverted();
        org.jfree.data.time.DateRange dateRange16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis3D14.setRangeWithMargins((org.jfree.data.Range) dateRange16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, xYItemRenderer18);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str23 = numberAxis22.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange24 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange24, 0.0d);
        org.jfree.data.Range range28 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange24, (double) '#');
        numberAxis22.setDefaultAutoRange((org.jfree.data.Range) dateRange24);
        boolean boolean30 = numberAxis22.isNegativeArrowVisible();
        boolean boolean31 = numberAxis22.isTickMarksVisible();
        numberAxis22.setFixedAutoRange((double) 1);
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str36 = numberAxis35.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange37 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint39 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange37, 0.0d);
        org.jfree.data.Range range41 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange37, (double) '#');
        numberAxis35.setDefaultAutoRange((org.jfree.data.Range) dateRange37);
        boolean boolean43 = numberAxis35.isNegativeArrowVisible();
        boolean boolean44 = numberAxis35.isTickMarksVisible();
        java.lang.Object obj45 = numberAxis35.clone();
        java.awt.Font font50 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand51 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis35, (double) 11, 0.0d, (double) 'a', (double) 100, font50);
        java.awt.Graphics2D graphics2D52 = null;
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        markerAxisBand51.draw(graphics2D52, rectangle2D53, rectangle2D54, (double) 12, (double) 12);
        numberAxis22.setMarkerBand(markerAxisBand51);
        xYPlot19.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) numberAxis22);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder60 = xYPlot19.getSeriesRenderingOrder();
        xYPlot19.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation64 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot19.setDomainAxisLocation(11, axisLocation64);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateRange16);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(dateRange24);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertNotNull(dateRange37);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(obj45);
        org.junit.Assert.assertNotNull(font50);
        org.junit.Assert.assertNotNull(seriesRenderingOrder60);
        org.junit.Assert.assertNotNull(axisLocation64);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange3, 0.0d);
        org.jfree.data.Range range7 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange3, (double) '#');
        numberAxis1.setDefaultAutoRange((org.jfree.data.Range) dateRange3);
        numberAxis1.setUpperBound((double) (-1L));
        double double11 = numberAxis1.getUpperBound();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(dateRange3);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0d) + "'", double11 == (-1.0d));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) true);
        java.lang.Object obj2 = keyToGroupMap1.clone();
        int int4 = keyToGroupMap1.getGroupIndex((java.lang.Comparable) " version ({0}, {1}) = {3} - {4}.\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n({0}, {1}) = {3} - {4}");
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.zoomRange(0.0d, 10.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis0.setTickMarkPosition(dateTickMarkPosition4);
        dateAxis0.setNegativeArrowVisible(false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange3, 0.0d);
        org.jfree.data.Range range7 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange3, (double) '#');
        numberAxis1.setDefaultAutoRange((org.jfree.data.Range) dateRange3);
        boolean boolean9 = numberAxis1.isNegativeArrowVisible();
        boolean boolean10 = numberAxis1.isTickMarksVisible();
        java.lang.Object obj11 = numberAxis1.clone();
        numberAxis1.setAutoRangeIncludesZero(true);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        org.jfree.chart.util.Rotation rotation16 = piePlot15.getDirection();
        org.jfree.chart.plot.Plot plot17 = piePlot15.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent18 = null;
        piePlot15.datasetChanged(datasetChangeEvent18);
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        piePlot15.drawBackgroundImage(graphics2D20, rectangle2D21);
        java.awt.Paint paint23 = piePlot15.getBaseSectionOutlinePaint();
        numberAxis1.setLabelPaint(paint23);
        java.awt.Paint paint25 = numberAxis1.getAxisLinePaint();
        numberAxis1.resizeRange((double) (-2208960000000L));
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(dateRange3);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(rotation16);
        org.junit.Assert.assertNull(plot17);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        java.awt.Color color2 = java.awt.Color.getColor("poly", 11);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        barRenderer4.setBaseToolTipGenerator(categoryToolTipGenerator5, false);
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        org.jfree.chart.util.Rotation rotation11 = piePlot10.getDirection();
        org.jfree.chart.plot.Plot plot12 = piePlot10.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent13 = null;
        piePlot10.datasetChanged(datasetChangeEvent13);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        piePlot10.drawBackgroundImage(graphics2D15, rectangle2D16);
        java.awt.Paint paint18 = piePlot10.getBaseSectionOutlinePaint();
        java.awt.Paint paint19 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot10.setBaseSectionPaint(paint19);
        barRenderer4.setSeriesItemLabelPaint((int) (byte) 0, paint19);
        java.awt.Paint paint23 = barRenderer4.lookupSeriesPaint(0);
        org.jfree.chart.block.BlockBorder blockBorder24 = new org.jfree.chart.block.BlockBorder((double) 100.0f, (double) 100.0f, (double) 'a', 0.0d, paint23);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = blockBorder24.getInsets();
        double double26 = rectangleInsets25.getLeft();
        org.junit.Assert.assertNotNull(rotation11);
        org.junit.Assert.assertNull(plot12);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 100.0d + "'", double26 == 100.0d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic2 = new org.jfree.chart.title.LegendGraphic(shape0, (java.awt.Paint) color1);
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        org.jfree.chart.util.Rotation rotation5 = piePlot4.getDirection();
        org.jfree.chart.plot.Plot plot6 = piePlot4.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        piePlot4.datasetChanged(datasetChangeEvent7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        piePlot4.drawBackgroundImage(graphics2D9, rectangle2D10);
        java.awt.Shape shape17 = null;
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Paint paint21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke22 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape24 = null;
        java.awt.Stroke stroke25 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color26 = java.awt.Color.black;
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("", "hi!", "hi!", "", true, shape17, false, (java.awt.Paint) color19, false, paint21, stroke22, true, shape24, stroke25, (java.awt.Paint) color26);
        java.awt.Stroke stroke28 = legendItem27.getLineStroke();
        piePlot4.setBaseSectionOutlineStroke(stroke28);
        legendGraphic2.setOutlineStroke(stroke28);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor31 = legendGraphic2.getShapeLocation();
        java.lang.Object obj32 = legendGraphic2.clone();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rotation5);
        org.junit.Assert.assertNull(plot6);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(rectangleAnchor31);
        org.junit.Assert.assertNotNull(obj32);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 10, (long) 'a');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month4.previous();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        float float1 = categoryAxis3D0.getMaximumCategoryLabelWidthRatio();
        java.lang.Object obj2 = categoryAxis3D0.clone();
        double double3 = categoryAxis3D0.getLowerMargin();
        java.lang.Object obj4 = categoryAxis3D0.clone();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.util.Rotation rotation3 = piePlot2.getDirection();
        org.jfree.chart.plot.Plot plot4 = piePlot2.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        piePlot2.datasetChanged(datasetChangeEvent5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        piePlot2.drawBackgroundImage(graphics2D7, rectangle2D8);
        java.awt.Paint paint10 = piePlot2.getBaseSectionOutlinePaint();
        java.awt.Paint paint11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot2.setBaseSectionPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart13.setTitle("({0}, {1}) = {3} - {4}");
        org.jfree.chart.title.TextTitle textTitle16 = jFreeChart13.getTitle();
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment18 = textTitle17.getHorizontalAlignment();
        textTitle17.setExpandToFitSpace(true);
        jFreeChart13.removeSubtitle((org.jfree.chart.title.Title) textTitle17);
        java.lang.Object obj22 = textTitle17.clone();
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(textTitle16);
        org.junit.Assert.assertNotNull(horizontalAlignment18);
        org.junit.Assert.assertNotNull(obj22);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        java.text.DateFormat dateFormat1 = null;
        try {
            org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator2 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("({0}, {1}) = {2}", dateFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, 0.0d);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange4, (double) '#');
        numberAxis2.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        boolean boolean10 = numberAxis2.isNegativeArrowVisible();
        boolean boolean11 = numberAxis2.isTickMarksVisible();
        java.lang.String str12 = numberAxis2.getLabel();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean15 = numberAxis3D14.isInverted();
        org.jfree.data.time.DateRange dateRange16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis3D14.setRangeWithMargins((org.jfree.data.Range) dateRange16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, xYItemRenderer18);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str23 = numberAxis22.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange24 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange24, 0.0d);
        org.jfree.data.Range range28 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange24, (double) '#');
        numberAxis22.setDefaultAutoRange((org.jfree.data.Range) dateRange24);
        boolean boolean30 = numberAxis22.isNegativeArrowVisible();
        boolean boolean31 = numberAxis22.isTickMarksVisible();
        numberAxis22.setFixedAutoRange((double) 1);
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str36 = numberAxis35.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange37 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint39 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange37, 0.0d);
        org.jfree.data.Range range41 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange37, (double) '#');
        numberAxis35.setDefaultAutoRange((org.jfree.data.Range) dateRange37);
        boolean boolean43 = numberAxis35.isNegativeArrowVisible();
        boolean boolean44 = numberAxis35.isTickMarksVisible();
        java.lang.Object obj45 = numberAxis35.clone();
        java.awt.Font font50 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand51 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis35, (double) 11, 0.0d, (double) 'a', (double) 100, font50);
        java.awt.Graphics2D graphics2D52 = null;
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        markerAxisBand51.draw(graphics2D52, rectangle2D53, rectangle2D54, (double) 12, (double) 12);
        numberAxis22.setMarkerBand(markerAxisBand51);
        xYPlot19.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) numberAxis22);
        xYPlot19.setDomainGridlinesVisible(true);
        int int62 = xYPlot19.getWeight();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateRange16);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(dateRange24);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertNotNull(dateRange37);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(obj45);
        org.junit.Assert.assertNotNull(font50);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        int int0 = org.jfree.data.time.SerialDate.MAXIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.chart.ChartColor chartColor5 = new org.jfree.chart.ChartColor((int) (short) 0, (int) (byte) 100, (int) '#');
        boolean boolean6 = spreadsheetDate1.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate9 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate8);
        java.lang.String str10 = serialDate9.getDescription();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, 0.0d);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange4, (double) '#');
        numberAxis2.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        boolean boolean10 = numberAxis2.isNegativeArrowVisible();
        boolean boolean11 = numberAxis2.isTickMarksVisible();
        java.lang.String str12 = numberAxis2.getLabel();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean15 = numberAxis3D14.isInverted();
        org.jfree.data.time.DateRange dateRange16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis3D14.setRangeWithMargins((org.jfree.data.Range) dateRange16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, xYItemRenderer18);
        java.awt.Paint paint20 = xYPlot19.getDomainGridlinePaint();
        xYPlot19.setRangeCrosshairVisible(true);
        java.awt.geom.Point2D point2D23 = xYPlot19.getQuadrantOrigin();
        java.io.ObjectOutputStream objectOutputStream24 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePoint2D(point2D23, objectOutputStream24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateRange16);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(point2D23);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 2, (float) 4);
        org.jfree.chart.entity.ChartEntity chartEntity4 = new org.jfree.chart.entity.ChartEntity(shape2, "");
        java.lang.String str5 = chartEntity4.getToolTipText();
        java.lang.String str6 = chartEntity4.toString();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "ChartEntity: tooltip = " + "'", str6.equals("ChartEntity: tooltip = "));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        org.jfree.chart.util.SortOrder sortOrder1 = org.jfree.chart.util.SortOrder.DESCENDING;
        defaultKeyedValues0.sortByKeys(sortOrder1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.chart.ChartColor chartColor8 = new org.jfree.chart.ChartColor((int) (short) 0, (int) (byte) 100, (int) '#');
        boolean boolean9 = spreadsheetDate4.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate12 = spreadsheetDate4.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(100);
        int int15 = spreadsheetDate14.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.chart.ChartColor chartColor21 = new org.jfree.chart.ChartColor((int) (short) 0, (int) (byte) 100, (int) '#');
        boolean boolean22 = spreadsheetDate17.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate25 = spreadsheetDate17.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate24);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.chart.ChartColor chartColor31 = new org.jfree.chart.ChartColor((int) (short) 0, (int) (byte) 100, (int) '#');
        boolean boolean32 = spreadsheetDate27.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate35 = spreadsheetDate27.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate34);
        org.jfree.data.time.SerialDate serialDate37 = serialDate35.getPreviousDayOfWeek(6);
        boolean boolean38 = spreadsheetDate14.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate24, serialDate37);
        boolean boolean39 = spreadsheetDate11.isOn(serialDate37);
        defaultKeyedValues0.setValue((java.lang.Comparable) serialDate37, (double) 100);
        org.junit.Assert.assertNotNull(sortOrder1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setVersion("");
        org.jfree.chart.ui.Library[] libraryArray3 = projectInfo0.getLibraries();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(libraryArray3);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("Other");
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setXOffset((double) 3600000L);
        lineRenderer3D0.setYOffset(2.0d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, 0.0d);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange4, (double) '#');
        numberAxis2.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        boolean boolean10 = numberAxis2.isNegativeArrowVisible();
        boolean boolean11 = numberAxis2.isTickMarksVisible();
        java.lang.String str12 = numberAxis2.getLabel();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean15 = numberAxis3D14.isInverted();
        org.jfree.data.time.DateRange dateRange16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis3D14.setRangeWithMargins((org.jfree.data.Range) dateRange16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, xYItemRenderer18);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray20 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot19.setRenderers(xYItemRendererArray20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        xYPlot19.zoomRangeAxes((double) (-1L), plotRenderingInfo23, point2D24);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        xYPlot19.setDataset(xYDataset26);
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str32 = numberAxis31.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange33 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint35 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange33, 0.0d);
        org.jfree.data.Range range37 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange33, (double) '#');
        numberAxis31.setDefaultAutoRange((org.jfree.data.Range) dateRange33);
        boolean boolean39 = numberAxis31.isNegativeArrowVisible();
        boolean boolean40 = numberAxis31.isTickMarksVisible();
        java.lang.String str41 = numberAxis31.getLabel();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D43 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean44 = numberAxis3D43.isInverted();
        org.jfree.data.time.DateRange dateRange45 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis3D43.setRangeWithMargins((org.jfree.data.Range) dateRange45);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset29, (org.jfree.chart.axis.ValueAxis) numberAxis31, (org.jfree.chart.axis.ValueAxis) numberAxis3D43, xYItemRenderer47);
        java.awt.Paint paint49 = xYPlot48.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation51 = xYPlot48.getRangeAxisLocation(1969);
        xYPlot19.setDomainAxisLocation(1, axisLocation51, false);
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D54 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D54.setSeriesCreateEntities((int) (short) 1, (java.lang.Boolean) false, false);
        boolean boolean60 = lineRenderer3D54.equals((java.lang.Object) false);
        java.awt.Graphics2D graphics2D61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = null;
        org.jfree.chart.axis.NumberAxis numberAxis64 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean65 = numberAxis64.getAutoRangeStickyZero();
        java.awt.Stroke stroke66 = numberAxis64.getAxisLineStroke();
        org.jfree.data.time.Year year68 = new org.jfree.data.time.Year();
        long long69 = year68.getLastMillisecond();
        org.jfree.data.gantt.Task task70 = new org.jfree.data.gantt.Task("AxisLocation.TOP_OR_LEFT", (org.jfree.data.time.TimePeriod) year68);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer71 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Paint paint72 = ganttRenderer71.getCompletePaint();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier73 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint74 = defaultDrawingSupplier73.getNextFillPaint();
        java.awt.Stroke stroke75 = defaultDrawingSupplier73.getNextStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker76 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) year68, paint72, stroke75);
        java.awt.geom.Rectangle2D rectangle2D77 = null;
        lineRenderer3D54.drawRangeMarker(graphics2D61, categoryPlot62, (org.jfree.chart.axis.ValueAxis) numberAxis64, (org.jfree.chart.plot.Marker) categoryMarker76, rectangle2D77);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType79 = categoryMarker76.getLabelOffsetType();
        org.jfree.chart.util.Layer layer80 = null;
        xYPlot19.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker76, layer80);
        org.jfree.chart.axis.NumberAxis numberAxis84 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean85 = numberAxis84.getAutoRangeStickyZero();
        java.awt.Stroke stroke86 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        numberAxis84.setTickMarkStroke(stroke86);
        java.awt.Paint paint88 = numberAxis84.getTickMarkPaint();
        try {
            xYPlot19.setQuadrantPaint((int) (short) -1, paint88);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateRange16);
        org.junit.Assert.assertNotNull(xYItemRendererArray20);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertNotNull(dateRange33);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "hi!" + "'", str41.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(dateRange45);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(axisLocation51);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertNotNull(stroke66);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 1577865599999L + "'", long69 == 1577865599999L);
        org.junit.Assert.assertNotNull(paint72);
        org.junit.Assert.assertNotNull(paint74);
        org.junit.Assert.assertNotNull(stroke75);
        org.junit.Assert.assertNotNull(lengthAdjustmentType79);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
        org.junit.Assert.assertNotNull(stroke86);
        org.junit.Assert.assertNotNull(paint88);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) paint0);
        org.jfree.chart.JFreeChart jFreeChart2 = null;
        chartChangeEvent1.setChart(jFreeChart2);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer5 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.LegendItem legendItem8 = stackedAreaRenderer5.getLegendItem((int) 'a', 0);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator9 = null;
        stackedAreaRenderer5.setBaseItemLabelGenerator(categoryItemLabelGenerator9, true);
        boolean boolean13 = stackedAreaRenderer5.equals((java.lang.Object) 10.0f);
        boolean boolean14 = chartChangeEventType4.equals((java.lang.Object) 10.0f);
        chartChangeEvent1.setType(chartChangeEventType4);
        java.lang.Object obj16 = chartChangeEvent1.getSource();
        org.junit.Assert.assertNotNull(paint0);
        org.junit.Assert.assertNotNull(chartChangeEventType4);
        org.junit.Assert.assertNull(legendItem8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.util.Rotation rotation4 = piePlot3.getDirection();
        org.jfree.chart.plot.Plot plot5 = piePlot3.getParent();
        org.jfree.chart.plot.Plot plot6 = piePlot3.getRootPlot();
        java.awt.Color color7 = java.awt.Color.MAGENTA;
        piePlot3.setOutlinePaint((java.awt.Paint) color7);
        columnArrangement0.add((org.jfree.chart.block.Block) textTitle1, (java.lang.Object) color7);
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        org.jfree.chart.util.Rotation rotation12 = piePlot11.getDirection();
        org.jfree.chart.plot.Plot plot13 = piePlot11.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent14 = null;
        piePlot11.datasetChanged(datasetChangeEvent14);
        java.awt.Stroke stroke16 = null;
        piePlot11.setLabelOutlineStroke(stroke16);
        java.lang.Number[] numberArray24 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray34 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray44 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray49 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[][] numberArray50 = new java.lang.Number[][] { numberArray24, numberArray29, numberArray34, numberArray39, numberArray44, numberArray49 };
        org.jfree.data.category.CategoryDataset categoryDataset51 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray50);
        org.jfree.data.general.PieDataset pieDataset53 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset51, (int) (short) 1);
        piePlot11.setDataset(pieDataset53);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer56 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0, (org.jfree.data.general.Dataset) pieDataset53, (java.lang.Comparable) 500);
        org.jfree.data.general.Dataset dataset57 = legendItemBlockContainer56.getDataset();
        java.lang.String str58 = legendItemBlockContainer56.getToolTipText();
        java.awt.Graphics2D graphics2D59 = null;
        org.jfree.chart.util.Size2D size2D62 = new org.jfree.chart.util.Size2D((double) 0.0f, (double) 1L);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor65 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Rectangle2D rectangle2D66 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D62, (double) (byte) 100, (double) 10, rectangleAnchor65);
        org.jfree.data.KeyToGroupMap keyToGroupMap67 = new org.jfree.data.KeyToGroupMap();
        try {
            java.lang.Object obj68 = legendItemBlockContainer56.draw(graphics2D59, rectangle2D66, (java.lang.Object) keyToGroupMap67);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rotation4);
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertNotNull(plot6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(rotation12);
        org.junit.Assert.assertNull(plot13);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(numberArray49);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(categoryDataset51);
        org.junit.Assert.assertNotNull(pieDataset53);
        org.junit.Assert.assertNotNull(dataset57);
        org.junit.Assert.assertNull(str58);
        org.junit.Assert.assertNotNull(rectangleAnchor65);
        org.junit.Assert.assertNotNull(rectangle2D66);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        org.jfree.chart.util.SortOrder sortOrder1 = org.jfree.chart.util.SortOrder.DESCENDING;
        defaultKeyedValues0.sortByKeys(sortOrder1);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod5 = new org.jfree.data.time.SimpleTimePeriod((long) 10, (long) 'a');
        java.util.Date date6 = simpleTimePeriod5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        java.util.Date date8 = month7.getStart();
        long long9 = month7.getMiddleMillisecond();
        int int10 = defaultKeyedValues0.getIndex((java.lang.Comparable) month7);
        org.junit.Assert.assertNotNull(sortOrder1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1310400001L) + "'", long9 == (-1310400001L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic2 = new org.jfree.chart.title.LegendGraphic(shape0, (java.awt.Paint) color1);
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        org.jfree.chart.util.Rotation rotation5 = piePlot4.getDirection();
        org.jfree.chart.plot.Plot plot6 = piePlot4.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        piePlot4.datasetChanged(datasetChangeEvent7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        piePlot4.drawBackgroundImage(graphics2D9, rectangle2D10);
        java.awt.Shape shape17 = null;
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Paint paint21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke22 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape24 = null;
        java.awt.Stroke stroke25 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color26 = java.awt.Color.black;
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("", "hi!", "hi!", "", true, shape17, false, (java.awt.Paint) color19, false, paint21, stroke22, true, shape24, stroke25, (java.awt.Paint) color26);
        java.awt.Stroke stroke28 = legendItem27.getLineStroke();
        piePlot4.setBaseSectionOutlineStroke(stroke28);
        legendGraphic2.setOutlineStroke(stroke28);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor31 = legendGraphic2.getShapeLocation();
        boolean boolean32 = legendGraphic2.isShapeVisible();
        boolean boolean33 = legendGraphic2.isShapeVisible();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rotation5);
        org.junit.Assert.assertNull(plot6);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(rectangleAnchor31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = barRenderer0.getBaseToolTipGenerator();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator4 = barRenderer0.getToolTipGenerator((int) (byte) 100, 0);
        boolean boolean5 = barRenderer0.getAutoPopulateSeriesPaint();
        double double6 = barRenderer0.getUpperClip();
        org.jfree.chart.LegendItem legendItem9 = barRenderer0.getLegendItem(2, (int) (short) 1);
        org.junit.Assert.assertNull(categoryToolTipGenerator1);
        org.junit.Assert.assertNull(categoryToolTipGenerator4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNull(legendItem9);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "({0}, {1}) = {3} - {4}", "", image3, "hi!", "hi!", "({0}, {1}) = {3} - {4}");
        java.lang.String str8 = projectInfo7.getLicenceText();
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        org.jfree.chart.util.Rotation rotation12 = piePlot11.getDirection();
        org.jfree.chart.plot.Plot plot13 = piePlot11.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent14 = null;
        piePlot11.datasetChanged(datasetChangeEvent14);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        piePlot11.drawBackgroundImage(graphics2D16, rectangle2D17);
        java.awt.Paint paint19 = piePlot11.getBaseSectionOutlinePaint();
        java.awt.Paint paint20 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot11.setBaseSectionPaint(paint20);
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot11);
        jFreeChart22.setTitle("({0}, {1}) = {3} - {4}");
        java.lang.Object obj25 = jFreeChart22.clone();
        jFreeChart22.fireChartChanged();
        jFreeChart22.setNotify(false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo32 = null;
        java.awt.image.BufferedImage bufferedImage33 = jFreeChart22.createBufferedImage((int) (byte) 10, 100, 12, chartRenderingInfo32);
        projectInfo7.setLogo((java.awt.Image) bufferedImage33);
        java.lang.String str35 = projectInfo7.toString();
        java.util.List list36 = projectInfo7.getContributors();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "({0}, {1}) = {3} - {4}" + "'", str8.equals("({0}, {1}) = {3} - {4}"));
        org.junit.Assert.assertNotNull(rotation12);
        org.junit.Assert.assertNull(plot13);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNotNull(bufferedImage33);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + " version ({0}, {1}) = {3} - {4}.\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n({0}, {1}) = {3} - {4}" + "'", str35.equals(" version ({0}, {1}) = {3} - {4}.\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n({0}, {1}) = {3} - {4}"));
        org.junit.Assert.assertNull(list36);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator1, false);
        boolean boolean4 = barRenderer0.getBaseCreateEntities();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        barRenderer0.setSeriesStroke((int) (short) 100, stroke6, false);
        org.jfree.data.KeyToGroupMap keyToGroupMap9 = new org.jfree.data.KeyToGroupMap();
        boolean boolean10 = barRenderer0.equals((java.lang.Object) keyToGroupMap9);
        boolean boolean11 = barRenderer0.getBaseSeriesVisibleInLegend();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("SortOrder.ASCENDING", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        boxAndWhiskerRenderer0.setAutoPopulateSeriesShape(true);
        boolean boolean3 = boxAndWhiskerRenderer0.getFillBox();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(2, 11, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, 0.0d);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange4, (double) '#');
        numberAxis2.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        boolean boolean10 = numberAxis2.isNegativeArrowVisible();
        boolean boolean11 = numberAxis2.isTickMarksVisible();
        java.lang.String str12 = numberAxis2.getLabel();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean15 = numberAxis3D14.isInverted();
        org.jfree.data.time.DateRange dateRange16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis3D14.setRangeWithMargins((org.jfree.data.Range) dateRange16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, xYItemRenderer18);
        java.awt.Paint paint20 = xYPlot19.getDomainGridlinePaint();
        xYPlot19.setRangeCrosshairVisible(true);
        java.awt.geom.Point2D point2D23 = xYPlot19.getQuadrantOrigin();
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        int int25 = xYPlot19.indexOf(xYDataset24);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateRange16);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(point2D23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("Other", "Nearest");
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, 0.0d);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange4, (double) '#');
        numberAxis2.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        boolean boolean10 = numberAxis2.isNegativeArrowVisible();
        boolean boolean11 = numberAxis2.isTickMarksVisible();
        java.lang.String str12 = numberAxis2.getLabel();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean15 = numberAxis3D14.isInverted();
        org.jfree.data.time.DateRange dateRange16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis3D14.setRangeWithMargins((org.jfree.data.Range) dateRange16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, xYItemRenderer18);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray20 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot19.setRenderers(xYItemRendererArray20);
        int int22 = xYPlot19.getSeriesCount();
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double26 = numberAxis25.getFixedAutoRange();
        java.text.NumberFormat numberFormat27 = numberAxis25.getNumberFormatOverride();
        java.awt.Paint paint28 = numberAxis25.getAxisLinePaint();
        java.lang.String str29 = numberAxis25.getLabelToolTip();
        xYPlot19.setDomainAxis((int) '#', (org.jfree.chart.axis.ValueAxis) numberAxis25, true);
        java.awt.Paint paint32 = xYPlot19.getRangeZeroBaselinePaint();
        boolean boolean33 = xYPlot19.isRangeGridlinesVisible();
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        int int35 = xYPlot19.indexOf(xYDataset34);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateRange16);
        org.junit.Assert.assertNotNull(xYItemRendererArray20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNull(numberFormat27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        java.awt.Paint paint1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        barRenderer2.setBaseToolTipGenerator(categoryToolTipGenerator3, false);
        boolean boolean6 = barRenderer2.getBaseCreateEntities();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        barRenderer2.setSeriesStroke((int) (short) 100, stroke8, false);
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker(0.0d, paint1, stroke8);
        java.awt.Paint paint12 = valueMarker11.getPaint();
        valueMarker11.setLabel("SortOrder.ASCENDING");
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent15 = null;
        valueMarker11.notifyListeners(markerChangeEvent15);
        org.jfree.data.general.PieDataset pieDataset18 = null;
        org.jfree.chart.plot.PiePlot piePlot19 = new org.jfree.chart.plot.PiePlot(pieDataset18);
        org.jfree.chart.util.Rotation rotation20 = piePlot19.getDirection();
        org.jfree.chart.plot.Plot plot21 = piePlot19.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent22 = null;
        piePlot19.datasetChanged(datasetChangeEvent22);
        java.awt.Graphics2D graphics2D24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        piePlot19.drawBackgroundImage(graphics2D24, rectangle2D25);
        java.awt.Paint paint27 = piePlot19.getBaseSectionOutlinePaint();
        java.awt.Paint paint28 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot19.setBaseSectionPaint(paint28);
        org.jfree.chart.JFreeChart jFreeChart30 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot19);
        jFreeChart30.setTitle("({0}, {1}) = {3} - {4}");
        org.jfree.chart.title.TextTitle textTitle33 = jFreeChart30.getTitle();
        org.jfree.chart.title.TextTitle textTitle34 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment35 = textTitle34.getHorizontalAlignment();
        textTitle34.setExpandToFitSpace(true);
        jFreeChart30.removeSubtitle((org.jfree.chart.title.Title) textTitle34);
        java.awt.Color color39 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        jFreeChart30.setBackgroundPaint((java.awt.Paint) color39);
        java.awt.Color color41 = color39.darker();
        valueMarker11.setOutlinePaint((java.awt.Paint) color39);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent43 = null;
        valueMarker11.notifyListeners(markerChangeEvent43);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(rotation20);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(textTitle33);
        org.junit.Assert.assertNotNull(horizontalAlignment35);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(color41);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        boolean boolean7 = textAnchor5.equals((java.lang.Object) 'a');
        try {
            textFragment1.draw(graphics2D2, (float) ' ', 0.0f, textAnchor5, (float) 2958465, (float) 11, (double) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        double double1 = textTitle0.getWidth();
        textTitle0.setMargin((double) 6, (double) (short) 1, (double) 'a', 8.0d);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions7 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition9 = categoryLabelPositions7.getLabelPosition(rectangleEdge8);
        textTitle0.setPosition(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(categoryLabelPositions7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(categoryLabelPosition9);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = piePlot1.getDirection();
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot1.removeChangeListener(plotChangeListener3);
        piePlot1.setLabelLinksVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        piePlot1.handleClick(15, 1, plotRenderingInfo9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        piePlot1.drawBackgroundImage(graphics2D11, rectangle2D12);
        java.awt.Stroke stroke14 = piePlot1.getBaseSectionOutlineStroke();
        org.junit.Assert.assertNotNull(rotation2);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        try {
            java.lang.Number number3 = taskSeriesCollection0.getStartValue((int) (short) -1, 15);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 10, (long) 'a');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        java.util.Date date5 = month4.getStart();
        long long6 = month4.getMiddleMillisecond();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean8 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge7);
        org.jfree.data.KeyedObject keyedObject9 = new org.jfree.data.KeyedObject((java.lang.Comparable) month4, (java.lang.Object) rectangleEdge7);
        int int10 = month4.getYearValue();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1310400001L) + "'", long6 == (-1310400001L));
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1969 + "'", int10 == 1969);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray32);
        java.lang.String[] strArray36 = new java.lang.String[] { "SerialDate.weekInMonthToString(): invalid code.", "VerticalAlignment.TOP" };
        java.lang.Number[] numberArray44 = new java.lang.Number[] { (short) 1, 100.0f, 2, (short) -1, (-1.0f) };
        java.lang.Number[] numberArray50 = new java.lang.Number[] { (short) 1, 100.0f, 2, (short) -1, (-1.0f) };
        java.lang.Number[][] numberArray51 = new java.lang.Number[][] { numberArray44, numberArray50 };
        org.jfree.data.category.CategoryDataset categoryDataset52 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray51);
        java.lang.Number[][] numberArray53 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset54 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray36, numberArray51, numberArray53);
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset55 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray32, numberArray53);
        try {
            java.lang.Number number58 = defaultIntervalCategoryDataset55.getStartValue((-459), (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset.getValue(): series index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(strArray36);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(categoryDataset52);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(1.0E-8d, (double) 100);
        double double3 = intervalMarker2.getStartValue();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-8d + "'", double3 == 1.0E-8d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        double double1 = lineRenderer3D0.getYOffset();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = null;
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        org.jfree.chart.util.Rotation rotation6 = piePlot5.getDirection();
        org.jfree.chart.plot.Plot plot7 = piePlot5.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        piePlot5.datasetChanged(datasetChangeEvent8);
        java.awt.Stroke stroke10 = null;
        piePlot5.setLabelOutlineStroke(stroke10);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange17 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange17, 0.0d);
        org.jfree.data.Range range21 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange17, (double) '#');
        numberAxis15.setDefaultAutoRange((org.jfree.data.Range) dateRange17);
        boolean boolean23 = numberAxis15.isNegativeArrowVisible();
        boolean boolean24 = numberAxis15.isTickMarksVisible();
        java.lang.String str25 = numberAxis15.getLabel();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D27 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean28 = numberAxis3D27.isInverted();
        org.jfree.data.time.DateRange dateRange29 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis3D27.setRangeWithMargins((org.jfree.data.Range) dateRange29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) numberAxis15, (org.jfree.chart.axis.ValueAxis) numberAxis3D27, xYItemRenderer31);
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str36 = numberAxis35.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange37 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint39 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange37, 0.0d);
        org.jfree.data.Range range41 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange37, (double) '#');
        numberAxis35.setDefaultAutoRange((org.jfree.data.Range) dateRange37);
        boolean boolean43 = numberAxis35.isNegativeArrowVisible();
        boolean boolean44 = numberAxis35.isTickMarksVisible();
        numberAxis35.setFixedAutoRange((double) 1);
        org.jfree.chart.axis.NumberAxis numberAxis48 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str49 = numberAxis48.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange50 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint52 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange50, 0.0d);
        org.jfree.data.Range range54 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange50, (double) '#');
        numberAxis48.setDefaultAutoRange((org.jfree.data.Range) dateRange50);
        boolean boolean56 = numberAxis48.isNegativeArrowVisible();
        boolean boolean57 = numberAxis48.isTickMarksVisible();
        java.lang.Object obj58 = numberAxis48.clone();
        java.awt.Font font63 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand64 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis48, (double) 11, 0.0d, (double) 'a', (double) 100, font63);
        java.awt.Graphics2D graphics2D65 = null;
        java.awt.geom.Rectangle2D rectangle2D66 = null;
        java.awt.geom.Rectangle2D rectangle2D67 = null;
        markerAxisBand64.draw(graphics2D65, rectangle2D66, rectangle2D67, (double) 12, (double) 12);
        numberAxis35.setMarkerBand(markerAxisBand64);
        xYPlot32.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) numberAxis35);
        org.jfree.chart.renderer.category.BarRenderer barRenderer73 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator74 = barRenderer73.getBaseToolTipGenerator();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator77 = barRenderer73.getToolTipGenerator((int) (byte) 100, 0);
        java.awt.Color color79 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        int int80 = color79.getRed();
        barRenderer73.setSeriesPaint(11, (java.awt.Paint) color79, true);
        xYPlot32.setRangeCrosshairPaint((java.awt.Paint) color79);
        java.awt.Graphics2D graphics2D84 = null;
        org.jfree.chart.util.Size2D size2D87 = new org.jfree.chart.util.Size2D((double) 0.0f, (double) 1L);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor90 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Rectangle2D rectangle2D91 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D87, (double) (byte) 100, (double) 10, rectangleAnchor90);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo93 = null;
        org.jfree.chart.plot.CrosshairState crosshairState94 = null;
        boolean boolean95 = xYPlot32.render(graphics2D84, rectangle2D91, (int) 'a', plotRenderingInfo93, crosshairState94);
        piePlot5.drawBackgroundImage(graphics2D12, rectangle2D91);
        try {
            lineRenderer3D0.drawDomainGridline(graphics2D2, categoryPlot3, rectangle2D91, (double) 1546329600000L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.0d + "'", double1 == 8.0d);
        org.junit.Assert.assertNotNull(rotation6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(dateRange17);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "hi!" + "'", str25.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(dateRange29);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertNotNull(dateRange37);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNull(str49);
        org.junit.Assert.assertNotNull(dateRange50);
        org.junit.Assert.assertNotNull(range54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(obj58);
        org.junit.Assert.assertNotNull(font63);
        org.junit.Assert.assertNull(categoryToolTipGenerator74);
        org.junit.Assert.assertNull(categoryToolTipGenerator77);
        org.junit.Assert.assertNotNull(color79);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 0 + "'", int80 == 0);
        org.junit.Assert.assertNotNull(rectangleAnchor90);
        org.junit.Assert.assertNotNull(rectangle2D91);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.color.ColorSpace colorSpace4 = color3.getColorSpace();
        boolean boolean5 = statisticalLineAndShapeRenderer2.equals((java.lang.Object) colorSpace4);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = statisticalLineAndShapeRenderer2.getDrawingSupplier();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(colorSpace4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(drawingSupplier6);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getHorizontalAlignment();
        java.lang.String str2 = horizontalAlignment1.toString();
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HorizontalAlignment.CENTER" + "'", str2.equals("HorizontalAlignment.CENTER"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.util.Rotation rotation3 = piePlot2.getDirection();
        org.jfree.chart.plot.Plot plot4 = piePlot2.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        piePlot2.datasetChanged(datasetChangeEvent5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        piePlot2.drawBackgroundImage(graphics2D7, rectangle2D8);
        java.awt.Paint paint10 = piePlot2.getBaseSectionOutlinePaint();
        java.awt.Paint paint11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot2.setBaseSectionPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart13.setBackgroundImageAlpha((float) (byte) 10);
        org.jfree.chart.event.ChartProgressListener chartProgressListener16 = null;
        jFreeChart13.removeProgressListener(chartProgressListener16);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer18 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean19 = jFreeChart13.equals((java.lang.Object) lineAndShapeRenderer18);
        org.jfree.chart.title.TextTitle textTitle20 = jFreeChart13.getTitle();
        java.awt.Font font21 = textTitle20.getFont();
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(textTitle20);
        org.junit.Assert.assertNotNull(font21);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        java.awt.Shape shape5 = null;
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape12 = null;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color14 = java.awt.Color.black;
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("", "hi!", "hi!", "", true, shape5, false, (java.awt.Paint) color7, false, paint9, stroke10, true, shape12, stroke13, (java.awt.Paint) color14);
        java.awt.Stroke stroke16 = legendItem15.getLineStroke();
        legendItem15.setSeriesIndex((int) (short) 0);
        org.jfree.data.general.Dataset dataset19 = legendItem15.getDataset();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(dataset19);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        org.jfree.data.time.TimePeriod timePeriod1 = null;
        org.jfree.data.gantt.Task task2 = new org.jfree.data.gantt.Task("hi!", timePeriod1);
        org.jfree.data.time.TimePeriod timePeriod4 = null;
        org.jfree.data.gantt.Task task5 = new org.jfree.data.gantt.Task("hi!", timePeriod4);
        java.lang.Object obj6 = null;
        boolean boolean7 = task5.equals(obj6);
        org.jfree.data.time.TimePeriod timePeriod9 = null;
        org.jfree.data.gantt.Task task10 = new org.jfree.data.gantt.Task("hi!", timePeriod9);
        java.lang.Object obj11 = null;
        boolean boolean12 = task10.equals(obj11);
        task10.setPercentComplete((java.lang.Double) 90.0d);
        task5.removeSubtask(task10);
        java.lang.String str16 = task5.getDescription();
        task2.removeSubtask(task5);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        long long20 = year19.getLastMillisecond();
        org.jfree.data.gantt.Task task21 = new org.jfree.data.gantt.Task("AxisLocation.TOP_OR_LEFT", (org.jfree.data.time.TimePeriod) year19);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer22 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Paint paint23 = ganttRenderer22.getCompletePaint();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier24 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint25 = defaultDrawingSupplier24.getNextFillPaint();
        java.awt.Stroke stroke26 = defaultDrawingSupplier24.getNextStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker27 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) year19, paint23, stroke26);
        task5.setDuration((org.jfree.data.time.TimePeriod) year19);
        java.util.Calendar calendar29 = null;
        try {
            year19.peg(calendar29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1577865599999L + "'", long20 == 1577865599999L);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(stroke26);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setDrawOutlines(true);
        boolean boolean5 = lineAndShapeRenderer0.getItemLineVisible(500, 9);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.util.Rotation rotation4 = piePlot3.getDirection();
        org.jfree.chart.plot.Plot plot5 = piePlot3.getParent();
        org.jfree.chart.plot.Plot plot6 = piePlot3.getRootPlot();
        java.awt.Color color7 = java.awt.Color.MAGENTA;
        piePlot3.setOutlinePaint((java.awt.Paint) color7);
        columnArrangement0.add((org.jfree.chart.block.Block) textTitle1, (java.lang.Object) color7);
        boolean boolean10 = textTitle1.getExpandToFitSpace();
        textTitle1.setHeight(1.05d);
        org.junit.Assert.assertNotNull(rotation4);
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertNotNull(plot6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.lang.String str2 = year0.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = piePlot1.getDirection();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator3 = piePlot1.getURLGenerator();
        piePlot1.setCircular(true);
        org.junit.Assert.assertNotNull(rotation2);
        org.junit.Assert.assertNull(pieURLGenerator3);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextOutlinePaint();
        java.awt.Stroke stroke2 = defaultDrawingSupplier0.getNextStroke();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list1 = taskSeriesCollection0.getRowKeys();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        try {
            java.lang.Number number5 = taskSeriesCollection0.getPercentComplete(0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange3, 0.0d);
        org.jfree.data.Range range7 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange3, (double) '#');
        numberAxis1.setDefaultAutoRange((org.jfree.data.Range) dateRange3);
        boolean boolean9 = numberAxis1.isNegativeArrowVisible();
        boolean boolean10 = numberAxis1.isTickMarksVisible();
        java.lang.Object obj11 = numberAxis1.clone();
        java.awt.Shape shape17 = null;
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Paint paint21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke22 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape24 = null;
        java.awt.Stroke stroke25 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color26 = java.awt.Color.black;
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("", "hi!", "hi!", "", true, shape17, false, (java.awt.Paint) color19, false, paint21, stroke22, true, shape24, stroke25, (java.awt.Paint) color26);
        java.lang.Number[] numberArray35 = new java.lang.Number[] { (short) 1, 100.0f, 2, (short) -1, (-1.0f) };
        java.lang.Number[] numberArray41 = new java.lang.Number[] { (short) 1, 100.0f, 2, (short) -1, (-1.0f) };
        java.lang.Number[][] numberArray42 = new java.lang.Number[][] { numberArray35, numberArray41 };
        org.jfree.data.category.CategoryDataset categoryDataset43 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray42);
        legendItem27.setDataset((org.jfree.data.general.Dataset) categoryDataset43);
        boolean boolean45 = numberAxis1.equals((java.lang.Object) legendItem27);
        int int46 = legendItem27.getSeriesIndex();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(dateRange3);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(numberArray41);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(categoryDataset43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(11);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        float float1 = categoryAxis3D0.getMaximumCategoryLabelWidthRatio();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        org.jfree.chart.util.Rotation rotation5 = piePlot4.getDirection();
        org.jfree.chart.plot.Plot plot6 = piePlot4.getParent();
        org.jfree.chart.plot.Plot plot7 = piePlot4.getRootPlot();
        java.awt.Color color8 = java.awt.Color.MAGENTA;
        piePlot4.setOutlinePaint((java.awt.Paint) color8);
        java.awt.Stroke stroke10 = piePlot4.getOutlineStroke();
        piePlot4.setOutlineVisible(true);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str16 = numberAxis15.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange17 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange17, 0.0d);
        org.jfree.data.Range range21 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange17, (double) '#');
        numberAxis15.setDefaultAutoRange((org.jfree.data.Range) dateRange17);
        boolean boolean23 = numberAxis15.isNegativeArrowVisible();
        boolean boolean24 = numberAxis15.isTickMarksVisible();
        java.lang.String str25 = numberAxis15.getLabel();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D27 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean28 = numberAxis3D27.isInverted();
        org.jfree.data.time.DateRange dateRange29 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis3D27.setRangeWithMargins((org.jfree.data.Range) dateRange29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) numberAxis15, (org.jfree.chart.axis.ValueAxis) numberAxis3D27, xYItemRenderer31);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray33 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot32.setRenderers(xYItemRendererArray33);
        int int35 = xYPlot32.getSeriesCount();
        org.jfree.chart.axis.NumberAxis numberAxis38 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double39 = numberAxis38.getFixedAutoRange();
        java.text.NumberFormat numberFormat40 = numberAxis38.getNumberFormatOverride();
        java.awt.Paint paint41 = numberAxis38.getAxisLinePaint();
        java.lang.String str42 = numberAxis38.getLabelToolTip();
        xYPlot32.setDomainAxis((int) '#', (org.jfree.chart.axis.ValueAxis) numberAxis38, true);
        java.awt.Paint paint45 = xYPlot32.getRangeZeroBaselinePaint();
        boolean boolean46 = xYPlot32.isRangeGridlinesVisible();
        java.awt.Graphics2D graphics2D47 = null;
        org.jfree.data.general.PieDataset pieDataset49 = null;
        org.jfree.chart.plot.PiePlot piePlot50 = new org.jfree.chart.plot.PiePlot(pieDataset49);
        org.jfree.chart.util.Rotation rotation51 = piePlot50.getDirection();
        org.jfree.chart.plot.Plot plot52 = piePlot50.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent53 = null;
        piePlot50.datasetChanged(datasetChangeEvent53);
        java.awt.Graphics2D graphics2D55 = null;
        java.awt.geom.Rectangle2D rectangle2D56 = null;
        piePlot50.drawBackgroundImage(graphics2D55, rectangle2D56);
        java.awt.Paint paint58 = piePlot50.getBaseSectionOutlinePaint();
        java.awt.Paint paint59 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot50.setBaseSectionPaint(paint59);
        org.jfree.chart.JFreeChart jFreeChart61 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot50);
        jFreeChart61.setTitle("({0}, {1}) = {3} - {4}");
        org.jfree.chart.title.TextTitle textTitle64 = jFreeChart61.getTitle();
        org.jfree.chart.title.TextTitle textTitle65 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment66 = textTitle65.getHorizontalAlignment();
        textTitle65.setExpandToFitSpace(true);
        jFreeChart61.removeSubtitle((org.jfree.chart.title.Title) textTitle65);
        org.jfree.chart.title.TextTitle textTitle70 = new org.jfree.chart.title.TextTitle();
        textTitle70.setNotify(false);
        jFreeChart61.removeSubtitle((org.jfree.chart.title.Title) textTitle70);
        java.awt.geom.Rectangle2D rectangle2D74 = textTitle70.getBounds();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo76 = null;
        org.jfree.chart.plot.CrosshairState crosshairState77 = null;
        boolean boolean78 = xYPlot32.render(graphics2D47, rectangle2D74, 255, plotRenderingInfo76, crosshairState77);
        org.jfree.chart.util.RectangleEdge rectangleEdge79 = null;
        org.jfree.chart.axis.AxisSpace axisSpace80 = new org.jfree.chart.axis.AxisSpace();
        double double81 = axisSpace80.getRight();
        axisSpace80.setLeft((double) 0L);
        try {
            org.jfree.chart.axis.AxisSpace axisSpace84 = categoryAxis3D0.reserveSpace(graphics2D2, (org.jfree.chart.plot.Plot) piePlot4, rectangle2D74, rectangleEdge79, axisSpace80);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
        org.junit.Assert.assertNotNull(rotation5);
        org.junit.Assert.assertNull(plot6);
        org.junit.Assert.assertNotNull(plot7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(dateRange17);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "hi!" + "'", str25.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(dateRange29);
        org.junit.Assert.assertNotNull(xYItemRendererArray33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNull(numberFormat40);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(rotation51);
        org.junit.Assert.assertNull(plot52);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertNotNull(textTitle64);
        org.junit.Assert.assertNotNull(horizontalAlignment66);
        org.junit.Assert.assertNotNull(rectangle2D74);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.0d + "'", double81 == 0.0d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator1, false);
        boolean boolean4 = barRenderer0.getBaseCreateEntities();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        barRenderer0.setSeriesStroke((int) (short) 100, stroke6, false);
        java.lang.Boolean boolean10 = barRenderer0.getSeriesVisible((int) (byte) -1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = barRenderer0.getBaseItemLabelGenerator();
        barRenderer0.setAutoPopulateSeriesOutlinePaint(false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(boolean10);
        org.junit.Assert.assertNull(categoryItemLabelGenerator11);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.cursorLeft((double) (-1L));
        axisState0.cursorDown((double) (byte) 100);
        axisState0.cursorUp((double) (-459));
        java.util.List list7 = null;
        axisState0.setTicks(list7);
        axisState0.cursorDown((double) (-1.0f));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        int int2 = spreadsheetDate1.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.chart.ChartColor chartColor8 = new org.jfree.chart.ChartColor((int) (short) 0, (int) (byte) 100, (int) '#');
        boolean boolean9 = spreadsheetDate4.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate12 = spreadsheetDate4.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.chart.ChartColor chartColor18 = new org.jfree.chart.ChartColor((int) (short) 0, (int) (byte) 100, (int) '#');
        boolean boolean19 = spreadsheetDate14.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate22 = spreadsheetDate14.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SerialDate serialDate24 = serialDate22.getPreviousDayOfWeek(6);
        boolean boolean25 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate11, serialDate24);
        java.lang.String str26 = spreadsheetDate1.toString();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "9-April-1900" + "'", str26.equals("9-April-1900"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str4 = numberAxis3.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange5 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange5, 0.0d);
        org.jfree.data.Range range9 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange5, (double) '#');
        numberAxis3.setDefaultAutoRange((org.jfree.data.Range) dateRange5);
        boolean boolean11 = numberAxis3.isNegativeArrowVisible();
        boolean boolean12 = numberAxis3.isTickMarksVisible();
        java.lang.Object obj13 = numberAxis3.clone();
        java.awt.Font font18 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand19 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis3, (double) 11, 0.0d, (double) 'a', (double) 100, font18);
        java.awt.Paint paint20 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.text.TextBlock textBlock21 = org.jfree.chart.text.TextUtilities.createTextBlock("NO_CHANGE", font18, paint20);
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment23 = textTitle22.getHorizontalAlignment();
        java.util.List list32 = null;
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem33 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 1L, (java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.05d, (java.lang.Number) 5, (java.lang.Number) (-1), (java.lang.Number) 100.0d, (java.lang.Number) 0L, list32);
        boolean boolean34 = horizontalAlignment23.equals((java.lang.Object) 1.0f);
        textBlock21.setLineAlignment(horizontalAlignment23);
        textTitle0.setTextAlignment(horizontalAlignment23);
        org.jfree.chart.util.VerticalAlignment verticalAlignment37 = org.jfree.chart.util.VerticalAlignment.TOP;
        java.lang.String str38 = verticalAlignment37.toString();
        org.jfree.chart.block.ColumnArrangement columnArrangement41 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment23, verticalAlignment37, 0.0d, (double) 1L);
        java.lang.String str42 = horizontalAlignment23.toString();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(dateRange5);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(textBlock21);
        org.junit.Assert.assertNotNull(horizontalAlignment23);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(verticalAlignment37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "VerticalAlignment.TOP" + "'", str38.equals("VerticalAlignment.TOP"));
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "HorizontalAlignment.CENTER" + "'", str42.equals("HorizontalAlignment.CENTER"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        java.awt.Shape shape6 = null;
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Paint paint10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape13 = null;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color15 = java.awt.Color.black;
        org.jfree.chart.LegendItem legendItem16 = new org.jfree.chart.LegendItem("", "hi!", "hi!", "", true, shape6, false, (java.awt.Paint) color8, false, paint10, stroke11, true, shape13, stroke14, (java.awt.Paint) color15);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean19 = numberAxis18.getAutoRangeStickyZero();
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        numberAxis18.setTickMarkStroke(stroke20);
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 12, (java.awt.Paint) color8, stroke20);
        org.jfree.data.time.TimePeriod timePeriod24 = null;
        org.jfree.data.gantt.Task task25 = new org.jfree.data.gantt.Task("hi!", timePeriod24);
        java.lang.Object obj26 = null;
        boolean boolean27 = task25.equals(obj26);
        org.jfree.data.time.TimePeriod timePeriod29 = null;
        org.jfree.data.gantt.Task task30 = new org.jfree.data.gantt.Task("hi!", timePeriod29);
        java.lang.Object obj31 = null;
        boolean boolean32 = task30.equals(obj31);
        task30.setPercentComplete((java.lang.Double) 90.0d);
        task25.removeSubtask(task30);
        boolean boolean36 = categoryMarker22.equals((java.lang.Object) task30);
        org.jfree.data.KeyedObjects2D keyedObjects2D37 = new org.jfree.data.KeyedObjects2D();
        keyedObjects2D37.removeColumn((java.lang.Comparable) 100.0f);
        org.jfree.data.general.PieDataset pieDataset40 = null;
        org.jfree.chart.plot.PiePlot piePlot41 = new org.jfree.chart.plot.PiePlot(pieDataset40);
        org.jfree.chart.util.Rotation rotation42 = piePlot41.getDirection();
        org.jfree.chart.event.PlotChangeListener plotChangeListener43 = null;
        piePlot41.removeChangeListener(plotChangeListener43);
        piePlot41.setLabelLinksVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = null;
        piePlot41.handleClick(15, 1, plotRenderingInfo49);
        org.jfree.data.general.PieDataset pieDataset51 = null;
        org.jfree.chart.plot.PiePlot piePlot52 = new org.jfree.chart.plot.PiePlot(pieDataset51);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator53 = null;
        piePlot52.setToolTipGenerator(pieToolTipGenerator53);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod57 = new org.jfree.data.time.SimpleTimePeriod((long) 10, (long) 'a');
        java.awt.Stroke stroke58 = piePlot52.getSectionOutlineStroke((java.lang.Comparable) simpleTimePeriod57);
        java.util.Date date59 = simpleTimePeriod57.getEnd();
        keyedObjects2D37.setObject((java.lang.Object) 15, (java.lang.Comparable) simpleTimePeriod57, (java.lang.Comparable) (byte) 0);
        task30.setDuration((org.jfree.data.time.TimePeriod) simpleTimePeriod57);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod65 = new org.jfree.data.time.SimpleTimePeriod((long) 10, (long) 'a');
        java.util.Date date66 = simpleTimePeriod65.getEnd();
        org.jfree.data.time.Month month67 = new org.jfree.data.time.Month(date66);
        boolean boolean68 = task30.equals((java.lang.Object) date66);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(rotation42);
        org.junit.Assert.assertNull(stroke58);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNotNull(date66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.util.Rotation rotation3 = piePlot2.getDirection();
        org.jfree.chart.plot.Plot plot4 = piePlot2.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        piePlot2.datasetChanged(datasetChangeEvent5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        piePlot2.drawBackgroundImage(graphics2D7, rectangle2D8);
        java.awt.Paint paint10 = piePlot2.getBaseSectionOutlinePaint();
        java.awt.Paint paint11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot2.setBaseSectionPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart13.setTitle("({0}, {1}) = {3} - {4}");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo18 = null;
        try {
            jFreeChart13.handleClick(10, (-459), chartRenderingInfo18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange3, 0.0d);
        org.jfree.data.Range range7 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange3, (double) '#');
        numberAxis1.setDefaultAutoRange((org.jfree.data.Range) dateRange3);
        double double10 = dateRange3.constrain((double) 23640L);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(dateRange3);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setDrawOutlines(true);
        lineAndShapeRenderer0.setUseFillPaint(true);
        java.lang.Boolean boolean6 = lineAndShapeRenderer0.getSeriesShapesVisible(2);
        lineAndShapeRenderer0.setSeriesLinesVisible((int) 'a', (java.lang.Boolean) false);
        boolean boolean10 = lineAndShapeRenderer0.getBaseLinesVisible();
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        java.awt.Paint paint1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        barRenderer2.setBaseToolTipGenerator(categoryToolTipGenerator3, false);
        boolean boolean6 = barRenderer2.getBaseCreateEntities();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        barRenderer2.setSeriesStroke((int) (short) 100, stroke8, false);
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker(0.0d, paint1, stroke8);
        java.awt.Paint paint12 = valueMarker11.getPaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = valueMarker11.getLabelAnchor();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double16 = numberAxis15.getFixedAutoRange();
        java.text.NumberFormat numberFormat17 = numberAxis15.getNumberFormatOverride();
        java.awt.Paint paint18 = numberAxis15.getAxisLinePaint();
        valueMarker11.setOutlinePaint(paint18);
        valueMarker11.setLabel("TextAnchor.CENTER_RIGHT");
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = valueMarker11.getLabelOffset();
        double double23 = rectangleInsets22.getLeft();
        double double25 = rectangleInsets22.trimHeight((double) 100.0f);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNull(numberFormat17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 3.0d + "'", double23 == 3.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 94.0d + "'", double25 == 94.0d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator2 = null;
        barRenderer1.setBaseToolTipGenerator(categoryToolTipGenerator2, false);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        org.jfree.chart.util.Rotation rotation8 = piePlot7.getDirection();
        org.jfree.chart.plot.Plot plot9 = piePlot7.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent10 = null;
        piePlot7.datasetChanged(datasetChangeEvent10);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        piePlot7.drawBackgroundImage(graphics2D12, rectangle2D13);
        java.awt.Paint paint15 = piePlot7.getBaseSectionOutlinePaint();
        java.awt.Paint paint16 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot7.setBaseSectionPaint(paint16);
        barRenderer1.setSeriesItemLabelPaint((int) (byte) 0, paint16);
        boolean boolean19 = barRenderer1.getAutoPopulateSeriesShape();
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator21 = new org.jfree.chart.urls.StandardCategoryURLGenerator("RectangleEdge.LEFT");
        barRenderer1.setBaseURLGenerator((org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator21);
        lineRenderer3D0.setBaseURLGenerator((org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator21, true);
        org.junit.Assert.assertNotNull(rotation8);
        org.junit.Assert.assertNull(plot9);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.chart.ChartColor chartColor5 = new org.jfree.chart.ChartColor((int) (short) 0, (int) (byte) 100, (int) '#');
        boolean boolean6 = spreadsheetDate1.equals((java.lang.Object) (short) 0);
        int int7 = spreadsheetDate1.getDayOfWeek();
        int int8 = spreadsheetDate1.toSerial();
        int int9 = spreadsheetDate1.toSerial();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        java.util.List list8 = null;
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem9 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 1L, (java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.05d, (java.lang.Number) 5, (java.lang.Number) (-1), (java.lang.Number) 100.0d, (java.lang.Number) 0L, list8);
        java.lang.Number number10 = boxAndWhiskerItem9.getMean();
        java.lang.Number number11 = boxAndWhiskerItem9.getMaxRegularValue();
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 1L + "'", number10.equals(1L));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (-1) + "'", number11.equals((-1)));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, 0.0d);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange4, (double) '#');
        numberAxis2.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        boolean boolean10 = numberAxis2.isNegativeArrowVisible();
        boolean boolean11 = numberAxis2.isTickMarksVisible();
        java.lang.String str12 = numberAxis2.getLabel();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean15 = numberAxis3D14.isInverted();
        org.jfree.data.time.DateRange dateRange16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis3D14.setRangeWithMargins((org.jfree.data.Range) dateRange16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, xYItemRenderer18);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray20 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot19.setRenderers(xYItemRendererArray20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        xYPlot19.zoomRangeAxes((double) (-1L), plotRenderingInfo23, point2D24);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        xYPlot19.setDataset(xYDataset26);
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str32 = numberAxis31.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange33 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint35 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange33, 0.0d);
        org.jfree.data.Range range37 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange33, (double) '#');
        numberAxis31.setDefaultAutoRange((org.jfree.data.Range) dateRange33);
        boolean boolean39 = numberAxis31.isNegativeArrowVisible();
        boolean boolean40 = numberAxis31.isTickMarksVisible();
        java.lang.String str41 = numberAxis31.getLabel();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D43 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean44 = numberAxis3D43.isInverted();
        org.jfree.data.time.DateRange dateRange45 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis3D43.setRangeWithMargins((org.jfree.data.Range) dateRange45);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset29, (org.jfree.chart.axis.ValueAxis) numberAxis31, (org.jfree.chart.axis.ValueAxis) numberAxis3D43, xYItemRenderer47);
        java.awt.Paint paint49 = xYPlot48.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation51 = xYPlot48.getRangeAxisLocation(1969);
        xYPlot19.setDomainAxisLocation(1, axisLocation51, false);
        xYPlot19.setDomainCrosshairVisible(true);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateRange16);
        org.junit.Assert.assertNotNull(xYItemRendererArray20);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertNotNull(dateRange33);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "hi!" + "'", str41.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(dateRange45);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(axisLocation51);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 11);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape2, "RectangleEdge.LEFT", "NO_CHANGE");
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity8 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) 8.0d, shape2, "({0}, {1}) = {2}", "SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str9 = categoryLabelEntity8.toString();
        java.lang.String str10 = categoryLabelEntity8.toString();
        java.lang.String str11 = categoryLabelEntity8.toString();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "CategoryLabelEntity: category=8.0, tooltip=({0}, {1}) = {2}, url=SerialDate.weekInMonthToString(): invalid code." + "'", str9.equals("CategoryLabelEntity: category=8.0, tooltip=({0}, {1}) = {2}, url=SerialDate.weekInMonthToString(): invalid code."));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "CategoryLabelEntity: category=8.0, tooltip=({0}, {1}) = {2}, url=SerialDate.weekInMonthToString(): invalid code." + "'", str10.equals("CategoryLabelEntity: category=8.0, tooltip=({0}, {1}) = {2}, url=SerialDate.weekInMonthToString(): invalid code."));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "CategoryLabelEntity: category=8.0, tooltip=({0}, {1}) = {2}, url=SerialDate.weekInMonthToString(): invalid code." + "'", str11.equals("CategoryLabelEntity: category=8.0, tooltip=({0}, {1}) = {2}, url=SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("http://www.jfree.org/jfreechart/index.html");
        java.awt.Font font2 = categoryAxis3D1.getLabelFont();
        org.junit.Assert.assertNotNull(font2);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange0, 0.0d);
        org.jfree.data.Range range4 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange0, 0.4d);
        org.junit.Assert.assertNotNull(dateRange0);
        org.junit.Assert.assertNotNull(range4);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("http://www.jfree.org/jfreechart/index.html");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str7 = numberAxis6.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange8 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange8, 0.0d);
        org.jfree.data.Range range12 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange8, (double) '#');
        numberAxis6.setDefaultAutoRange((org.jfree.data.Range) dateRange8);
        boolean boolean14 = numberAxis6.isNegativeArrowVisible();
        boolean boolean15 = numberAxis6.isTickMarksVisible();
        java.lang.String str16 = numberAxis6.getLabel();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D18 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean19 = numberAxis3D18.isInverted();
        org.jfree.data.time.DateRange dateRange20 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis3D18.setRangeWithMargins((org.jfree.data.Range) dateRange20);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis3D18, xYItemRenderer22);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray24 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot23.setRenderers(xYItemRendererArray24);
        int int26 = xYPlot23.getSeriesCount();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double30 = numberAxis29.getFixedAutoRange();
        java.text.NumberFormat numberFormat31 = numberAxis29.getNumberFormatOverride();
        java.awt.Paint paint32 = numberAxis29.getAxisLinePaint();
        java.lang.String str33 = numberAxis29.getLabelToolTip();
        xYPlot23.setDomainAxis((int) '#', (org.jfree.chart.axis.ValueAxis) numberAxis29, true);
        java.awt.Paint paint36 = xYPlot23.getRangeZeroBaselinePaint();
        boolean boolean37 = xYPlot23.isRangeGridlinesVisible();
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.data.general.PieDataset pieDataset40 = null;
        org.jfree.chart.plot.PiePlot piePlot41 = new org.jfree.chart.plot.PiePlot(pieDataset40);
        org.jfree.chart.util.Rotation rotation42 = piePlot41.getDirection();
        org.jfree.chart.plot.Plot plot43 = piePlot41.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent44 = null;
        piePlot41.datasetChanged(datasetChangeEvent44);
        java.awt.Graphics2D graphics2D46 = null;
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        piePlot41.drawBackgroundImage(graphics2D46, rectangle2D47);
        java.awt.Paint paint49 = piePlot41.getBaseSectionOutlinePaint();
        java.awt.Paint paint50 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot41.setBaseSectionPaint(paint50);
        org.jfree.chart.JFreeChart jFreeChart52 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot41);
        jFreeChart52.setTitle("({0}, {1}) = {3} - {4}");
        org.jfree.chart.title.TextTitle textTitle55 = jFreeChart52.getTitle();
        org.jfree.chart.title.TextTitle textTitle56 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment57 = textTitle56.getHorizontalAlignment();
        textTitle56.setExpandToFitSpace(true);
        jFreeChart52.removeSubtitle((org.jfree.chart.title.Title) textTitle56);
        org.jfree.chart.title.TextTitle textTitle61 = new org.jfree.chart.title.TextTitle();
        textTitle61.setNotify(false);
        jFreeChart52.removeSubtitle((org.jfree.chart.title.Title) textTitle61);
        java.awt.geom.Rectangle2D rectangle2D65 = textTitle61.getBounds();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo67 = null;
        org.jfree.chart.plot.CrosshairState crosshairState68 = null;
        boolean boolean69 = xYPlot23.render(graphics2D38, rectangle2D65, 255, plotRenderingInfo67, crosshairState68);
        org.jfree.chart.util.Size2D size2D72 = new org.jfree.chart.util.Size2D((double) 0.0f, (double) 1L);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor75 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Rectangle2D rectangle2D76 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D72, (double) (byte) 100, (double) 10, rectangleAnchor75);
        org.jfree.chart.util.RectangleEdge rectangleEdge77 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo78 = null;
        try {
            org.jfree.chart.axis.AxisState axisState79 = categoryAxis3D1.draw(graphics2D2, (double) (-1.0f), rectangle2D65, rectangle2D76, rectangleEdge77, plotRenderingInfo78);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(dateRange8);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateRange20);
        org.junit.Assert.assertNotNull(xYItemRendererArray24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNull(numberFormat31);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(rotation42);
        org.junit.Assert.assertNull(plot43);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNotNull(textTitle55);
        org.junit.Assert.assertNotNull(horizontalAlignment57);
        org.junit.Assert.assertNotNull(rectangle2D65);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor75);
        org.junit.Assert.assertNotNull(rectangle2D76);
        org.junit.Assert.assertNotNull(rectangleEdge77);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.getAutoRangeStickyZero();
        java.awt.Stroke stroke3 = numberAxis1.getAxisLineStroke();
        boolean boolean4 = numberAxis1.getAutoRangeIncludesZero();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.lang.Comparable comparable1 = null;
        try {
            java.lang.Number number3 = defaultKeyedValues2D0.getValue(comparable1, (java.lang.Comparable) 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowKey' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        try {
            java.awt.Color color1 = java.awt.Color.decode("ERROR : Relative To String");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"ERROR : Relative To String\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 11);
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape3, "RectangleEdge.LEFT", "NO_CHANGE");
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) 8.0d, shape3, "({0}, {1}) = {2}", "SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str10 = categoryLabelEntity9.toString();
        java.lang.String str11 = categoryLabelEntity9.toString();
        boolean boolean12 = plotOrientation0.equals((java.lang.Object) categoryLabelEntity9);
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "CategoryLabelEntity: category=8.0, tooltip=({0}, {1}) = {2}, url=SerialDate.weekInMonthToString(): invalid code." + "'", str10.equals("CategoryLabelEntity: category=8.0, tooltip=({0}, {1}) = {2}, url=SerialDate.weekInMonthToString(): invalid code."));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "CategoryLabelEntity: category=8.0, tooltip=({0}, {1}) = {2}, url=SerialDate.weekInMonthToString(): invalid code." + "'", str11.equals("CategoryLabelEntity: category=8.0, tooltip=({0}, {1}) = {2}, url=SerialDate.weekInMonthToString(): invalid code."));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.util.Rotation rotation4 = piePlot3.getDirection();
        org.jfree.chart.plot.Plot plot5 = piePlot3.getParent();
        org.jfree.chart.plot.Plot plot6 = piePlot3.getRootPlot();
        java.awt.Color color7 = java.awt.Color.MAGENTA;
        piePlot3.setOutlinePaint((java.awt.Paint) color7);
        columnArrangement0.add((org.jfree.chart.block.Block) textTitle1, (java.lang.Object) color7);
        java.lang.Object obj10 = null;
        boolean boolean11 = columnArrangement0.equals(obj10);
        org.junit.Assert.assertNotNull(rotation4);
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertNotNull(plot6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.util.Rotation rotation3 = piePlot2.getDirection();
        org.jfree.chart.plot.Plot plot4 = piePlot2.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        piePlot2.datasetChanged(datasetChangeEvent5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        piePlot2.drawBackgroundImage(graphics2D7, rectangle2D8);
        java.awt.Paint paint10 = piePlot2.getBaseSectionOutlinePaint();
        java.awt.Paint paint11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot2.setBaseSectionPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot2);
        boolean boolean14 = jFreeChart13.isBorderVisible();
        org.jfree.chart.title.LegendTitle legendTitle16 = jFreeChart13.getLegend(1);
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(legendTitle16);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = piePlot1.getDirection();
        org.jfree.chart.plot.Plot plot3 = piePlot1.getParent();
        org.jfree.chart.plot.Plot plot4 = piePlot1.getRootPlot();
        java.awt.Color color5 = java.awt.Color.MAGENTA;
        piePlot1.setOutlinePaint((java.awt.Paint) color5);
        int int7 = piePlot1.getBackgroundImageAlignment();
        java.awt.Paint paint8 = piePlot1.getOutlinePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = piePlot1.getLegendItems();
        java.lang.Object obj10 = legendItemCollection9.clone();
        org.junit.Assert.assertNotNull(rotation2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(plot4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(legendItemCollection9);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        int int1 = keyedObjects0.getItemCount();
        java.lang.Object obj3 = keyedObjects0.getObject((java.lang.Comparable) (short) -1);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean6 = numberAxis5.getAutoRangeStickyZero();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        numberAxis5.setTickMarkStroke(stroke7);
        numberAxis5.setTickMarkInsideLength(0.0f);
        numberAxis5.setAutoRangeMinimumSize((double) 3, false);
        boolean boolean14 = keyedObjects0.equals((java.lang.Object) numberAxis5);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection15 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list16 = taskSeriesCollection15.getRowKeys();
        int int18 = taskSeriesCollection15.indexOf((java.lang.Comparable) "({0}, {1}) = {2}");
        int int19 = taskSeriesCollection15.getColumnCount();
        boolean boolean20 = numberAxis5.hasListener((java.util.EventListener) taskSeriesCollection15);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.data.time.DateRange dateRange22 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = rectangleConstraint21.toRangeHeight((org.jfree.data.Range) dateRange22);
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str26 = numberAxis25.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange27 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint29 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange27, 0.0d);
        org.jfree.data.Range range31 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange27, (double) '#');
        numberAxis25.setDefaultAutoRange((org.jfree.data.Range) dateRange27);
        org.jfree.data.Range range35 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange27, 0.0d, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint36 = rectangleConstraint23.toRangeHeight(range35);
        numberAxis5.setRangeWithMargins(range35);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint21);
        org.junit.Assert.assertNotNull(dateRange22);
        org.junit.Assert.assertNotNull(rectangleConstraint23);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNotNull(dateRange27);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertNotNull(rectangleConstraint36);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        keyedObjects2D0.removeColumn((java.lang.Comparable) 100.0f);
        org.jfree.data.time.TimePeriod timePeriod4 = null;
        org.jfree.data.gantt.Task task5 = new org.jfree.data.gantt.Task("hi!", timePeriod4);
        org.jfree.data.time.TimePeriod timePeriod7 = null;
        org.jfree.data.gantt.Task task8 = new org.jfree.data.gantt.Task("hi!", timePeriod7);
        java.lang.Object obj9 = null;
        boolean boolean10 = task8.equals(obj9);
        org.jfree.data.time.TimePeriod timePeriod12 = null;
        org.jfree.data.gantt.Task task13 = new org.jfree.data.gantt.Task("hi!", timePeriod12);
        java.lang.Object obj14 = null;
        boolean boolean15 = task13.equals(obj14);
        task13.setPercentComplete((java.lang.Double) 90.0d);
        task8.removeSubtask(task13);
        java.lang.String str19 = task8.getDescription();
        task5.removeSubtask(task8);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        long long23 = year22.getLastMillisecond();
        org.jfree.data.gantt.Task task24 = new org.jfree.data.gantt.Task("AxisLocation.TOP_OR_LEFT", (org.jfree.data.time.TimePeriod) year22);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer25 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Paint paint26 = ganttRenderer25.getCompletePaint();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier27 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint28 = defaultDrawingSupplier27.getNextFillPaint();
        java.awt.Stroke stroke29 = defaultDrawingSupplier27.getNextStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker30 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) year22, paint26, stroke29);
        task8.setDuration((org.jfree.data.time.TimePeriod) year22);
        int int32 = keyedObjects2D0.getColumnIndex((java.lang.Comparable) year22);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577865599999L + "'", long23 == 1577865599999L);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list1 = taskSeriesCollection0.getRowKeys();
        int int3 = taskSeriesCollection0.indexOf((java.lang.Comparable) "({0}, {1}) = {2}");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.chart.ChartColor chartColor9 = new org.jfree.chart.ChartColor((int) (short) 0, (int) (byte) 100, (int) '#');
        boolean boolean10 = spreadsheetDate5.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate13 = spreadsheetDate5.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.chart.ChartColor chartColor19 = new org.jfree.chart.ChartColor((int) (short) 0, (int) (byte) 100, (int) '#');
        boolean boolean20 = spreadsheetDate15.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate23 = spreadsheetDate15.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.time.SerialDate serialDate24 = spreadsheetDate12.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.gantt.TaskSeries taskSeries25 = taskSeriesCollection0.getSeries((java.lang.Comparable) spreadsheetDate22);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNull(taskSeries25);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setSeriesCreateEntities((int) (short) 1, (java.lang.Boolean) false, false);
        lineRenderer3D0.setYOffset(1.0d);
        java.lang.Boolean boolean8 = lineRenderer3D0.getSeriesVisible(0);
        org.junit.Assert.assertNull(boolean8);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) true);
        int int3 = keyToGroupMap1.getKeyCount((java.lang.Comparable) 0.05d);
        java.util.List list4 = keyToGroupMap1.getGroups();
        java.util.List list5 = keyToGroupMap1.getGroups();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((long) 10, (long) 'a');
        java.util.Date date9 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
        int int11 = month10.getYearValue();
        org.jfree.data.time.Year year12 = month10.getYear();
        int int13 = keyToGroupMap1.getKeyCount((java.lang.Comparable) month10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1969 + "'", int11 == 1969);
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = piePlot1.getDirection();
        org.jfree.chart.plot.Plot plot3 = piePlot1.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        piePlot1.datasetChanged(datasetChangeEvent4);
        java.awt.Stroke stroke6 = null;
        piePlot1.setLabelOutlineStroke(stroke6);
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray34 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[][] numberArray40 = new java.lang.Number[][] { numberArray14, numberArray19, numberArray24, numberArray29, numberArray34, numberArray39 };
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray40);
        org.jfree.data.general.PieDataset pieDataset43 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset41, (int) (short) 1);
        piePlot1.setDataset(pieDataset43);
        org.jfree.data.general.PieDataset pieDataset48 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset43, (java.lang.Comparable) "", 90.0d, (int) (byte) 1);
        double double49 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset43);
        org.jfree.chart.plot.PiePlot piePlot50 = new org.jfree.chart.plot.PiePlot(pieDataset43);
        org.jfree.chart.plot.RingPlot ringPlot51 = new org.jfree.chart.plot.RingPlot(pieDataset43);
        org.junit.Assert.assertNotNull(rotation2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(pieDataset43);
        org.junit.Assert.assertNotNull(pieDataset48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.lang.Object obj1 = defaultKeyedValues2D0.clone();
        int int2 = defaultKeyedValues2D0.getRowCount();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.LegendItem legendItem3 = stackedAreaRenderer0.getLegendItem((int) 'a', 0);
        java.awt.Shape shape5 = null;
        stackedAreaRenderer0.setSeriesShape((int) '4', shape5, true);
        java.awt.Shape shape10 = stackedAreaRenderer0.getItemShape(1, 15);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity11 = new org.jfree.chart.entity.LegendItemEntity(shape10);
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic2 = new org.jfree.chart.title.LegendGraphic(shape0, (java.awt.Paint) color1);
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        org.jfree.chart.util.Rotation rotation5 = piePlot4.getDirection();
        org.jfree.chart.plot.Plot plot6 = piePlot4.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        piePlot4.datasetChanged(datasetChangeEvent7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        piePlot4.drawBackgroundImage(graphics2D9, rectangle2D10);
        java.awt.Shape shape17 = null;
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Paint paint21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke22 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape24 = null;
        java.awt.Stroke stroke25 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color26 = java.awt.Color.black;
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("", "hi!", "hi!", "", true, shape17, false, (java.awt.Paint) color19, false, paint21, stroke22, true, shape24, stroke25, (java.awt.Paint) color26);
        java.awt.Stroke stroke28 = legendItem27.getLineStroke();
        piePlot4.setBaseSectionOutlineStroke(stroke28);
        legendGraphic2.setOutlineStroke(stroke28);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor31 = legendGraphic2.getShapeLocation();
        boolean boolean32 = legendGraphic2.isShapeVisible();
        java.awt.Shape shape33 = legendGraphic2.getShape();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D38 = new org.jfree.chart.renderer.category.BarRenderer3D();
        java.awt.Shape shape42 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 2, (float) 4);
        barRenderer3D38.setSeriesShape((int) (short) 1, shape42, false);
        org.jfree.chart.axis.NumberAxis numberAxis46 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean47 = numberAxis46.getAutoRangeStickyZero();
        java.awt.Stroke stroke48 = numberAxis46.getAxisLineStroke();
        org.jfree.data.general.PieDataset pieDataset49 = null;
        org.jfree.chart.plot.PiePlot piePlot50 = new org.jfree.chart.plot.PiePlot(pieDataset49);
        org.jfree.chart.util.Rotation rotation51 = piePlot50.getDirection();
        org.jfree.chart.plot.Plot plot52 = piePlot50.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent53 = null;
        piePlot50.datasetChanged(datasetChangeEvent53);
        java.awt.Graphics2D graphics2D55 = null;
        java.awt.geom.Rectangle2D rectangle2D56 = null;
        piePlot50.drawBackgroundImage(graphics2D55, rectangle2D56);
        java.awt.Paint paint58 = piePlot50.getBaseSectionOutlinePaint();
        java.awt.Paint paint59 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot50.setBaseSectionPaint(paint59);
        org.jfree.chart.LegendItem legendItem61 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "TextAnchor.CENTER_RIGHT", "ChartEntity: tooltip = ", shape42, stroke48, paint59);
        legendGraphic2.setFillPaint(paint59);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rotation5);
        org.junit.Assert.assertNull(plot6);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(rectangleAnchor31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(rotation51);
        org.junit.Assert.assertNull(plot52);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertNotNull(paint59);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        java.awt.Paint paint1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        barRenderer2.setBaseToolTipGenerator(categoryToolTipGenerator3, false);
        boolean boolean6 = barRenderer2.getBaseCreateEntities();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        barRenderer2.setSeriesStroke((int) (short) 100, stroke8, false);
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker(0.0d, paint1, stroke8);
        java.awt.Paint paint12 = valueMarker11.getPaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = valueMarker11.getLabelAnchor();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = valueMarker11.getLabelAnchor();
        valueMarker11.setValue((double) 5);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        boolean boolean1 = boxAndWhiskerRenderer0.getBaseItemLabelsVisible();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer3 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.LegendItem legendItem6 = stackedAreaRenderer3.getLegendItem((int) 'a', 0);
        java.awt.Shape shape8 = null;
        stackedAreaRenderer3.setSeriesShape((int) '4', shape8, true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator11 = null;
        stackedAreaRenderer3.setBaseURLGenerator(categoryURLGenerator11);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = stackedAreaRenderer3.getNegativeItemLabelPosition(100, (int) (short) 0);
        boxAndWhiskerRenderer0.setSeriesPositiveItemLabelPosition((int) '#', itemLabelPosition15);
        java.lang.Boolean boolean18 = boxAndWhiskerRenderer0.getSeriesCreateEntities(12);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(legendItem6);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertNull(boolean18);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D1 = new org.jfree.chart.renderer.category.BarRenderer3D();
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 2, (float) 4);
        barRenderer3D1.setSeriesShape((int) (short) 1, shape5, false);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer9 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.LegendItem legendItem12 = stackedAreaRenderer9.getLegendItem((int) 'a', 0);
        java.awt.Shape shape14 = null;
        stackedAreaRenderer9.setSeriesShape((int) '4', shape14, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = stackedAreaRenderer9.getSeriesPositiveItemLabelPosition((int) (byte) 1);
        barRenderer3D1.setSeriesPositiveItemLabelPosition((int) '#', itemLabelPosition18);
        org.jfree.chart.text.TextLine textLine21 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.text.TextFragment textFragment22 = textLine21.getFirstTextFragment();
        java.awt.Font font23 = textFragment22.getFont();
        java.awt.Font font24 = textFragment22.getFont();
        barRenderer3D1.setBaseItemLabelFont(font24, true);
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer27 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        boxAndWhiskerRenderer27.setFillBox(true);
        double double30 = boxAndWhiskerRenderer27.getItemMargin();
        java.awt.Stroke stroke33 = boxAndWhiskerRenderer27.getItemOutlineStroke((int) (short) 10, 3);
        org.jfree.chart.text.TextLine textLine37 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.text.TextFragment textFragment38 = textLine37.getFirstTextFragment();
        java.awt.Font font39 = textFragment38.getFont();
        java.awt.Color color40 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.block.LabelBlock labelBlock41 = new org.jfree.chart.block.LabelBlock("hi!", font39, (java.awt.Paint) color40);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer42 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Paint paint43 = ganttRenderer42.getCompletePaint();
        org.jfree.chart.block.LabelBlock labelBlock44 = new org.jfree.chart.block.LabelBlock("({0}, {1}) = {3} - {4}", font39, paint43);
        boxAndWhiskerRenderer27.setArtifactPaint(paint43);
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean47 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge46);
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge46);
        boolean boolean49 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge46);
        boolean boolean50 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge46);
        org.jfree.chart.title.TextTitle textTitle51 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment52 = textTitle51.getHorizontalAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment53 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset54 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list55 = defaultStatisticalCategoryDataset54.getColumnKeys();
        java.lang.Number number56 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset54);
        boolean boolean57 = verticalAlignment53.equals((java.lang.Object) number56);
        org.jfree.chart.util.UnitType unitType58 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets63 = new org.jfree.chart.util.RectangleInsets(unitType58, (double) 3, 0.0d, (double) 0.5f, (double) 100.0f);
        double double65 = rectangleInsets63.calculateLeftOutset((double) 3);
        double double66 = rectangleInsets63.getLeft();
        org.jfree.chart.title.TextTitle textTitle67 = new org.jfree.chart.title.TextTitle("ChartChangeEventType.GENERAL", font24, paint43, rectangleEdge46, horizontalAlignment52, verticalAlignment53, rectangleInsets63);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNull(legendItem12);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(textFragment22);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.2d + "'", double30 == 0.2d);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(textFragment38);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(rectangleEdge46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(rectangleEdge48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(horizontalAlignment52);
        org.junit.Assert.assertNotNull(verticalAlignment53);
        org.junit.Assert.assertNotNull(list55);
        org.junit.Assert.assertTrue("'" + number56 + "' != '" + 0.0d + "'", number56.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(unitType58);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + (-0.0d) + "'", double65 == (-0.0d));
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        java.awt.Paint paint1 = null;
        java.awt.Stroke stroke2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str6 = numberAxis5.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange7 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange7, 0.0d);
        org.jfree.data.Range range11 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange7, (double) '#');
        numberAxis5.setDefaultAutoRange((org.jfree.data.Range) dateRange7);
        boolean boolean13 = numberAxis5.isNegativeArrowVisible();
        boolean boolean14 = numberAxis5.isTickMarksVisible();
        java.lang.Object obj15 = numberAxis5.clone();
        java.awt.Font font20 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis5, (double) 11, 0.0d, (double) 'a', (double) 100, font20);
        java.awt.Paint paint22 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.text.TextBlock textBlock23 = org.jfree.chart.text.TextUtilities.createTextBlock("NO_CHANGE", font20, paint22);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str27 = numberAxis26.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange28 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange28, 0.0d);
        org.jfree.data.Range range32 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange28, (double) '#');
        numberAxis26.setDefaultAutoRange((org.jfree.data.Range) dateRange28);
        boolean boolean34 = numberAxis26.isNegativeArrowVisible();
        boolean boolean35 = numberAxis26.isTickMarksVisible();
        java.lang.String str36 = numberAxis26.getLabel();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D38 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean39 = numberAxis3D38.isInverted();
        org.jfree.data.time.DateRange dateRange40 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis3D38.setRangeWithMargins((org.jfree.data.Range) dateRange40);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = null;
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot(xYDataset24, (org.jfree.chart.axis.ValueAxis) numberAxis26, (org.jfree.chart.axis.ValueAxis) numberAxis3D38, xYItemRenderer42);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray44 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot43.setRenderers(xYItemRendererArray44);
        xYPlot43.clearRangeAxes();
        java.awt.Stroke stroke47 = xYPlot43.getRangeZeroBaselineStroke();
        try {
            org.jfree.chart.plot.ValueMarker valueMarker49 = new org.jfree.chart.plot.ValueMarker((double) (-1), paint1, stroke2, paint22, stroke47, (float) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(dateRange7);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(textBlock23);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(dateRange28);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(dateRange40);
        org.junit.Assert.assertNotNull(xYItemRendererArray44);
        org.junit.Assert.assertNotNull(stroke47);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        java.lang.String str0 = org.jfree.chart.ui.Licences.GPL;
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = piePlot1.getDirection();
        org.jfree.chart.plot.Plot plot3 = piePlot1.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        piePlot1.datasetChanged(datasetChangeEvent4);
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        barRenderer6.setBaseToolTipGenerator(categoryToolTipGenerator7, false);
        boolean boolean10 = barRenderer6.getBaseCreateEntities();
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        barRenderer6.setSeriesStroke((int) (short) 100, stroke12, false);
        piePlot1.setLabelOutlineStroke(stroke12);
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D16 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D16.setSeriesCreateEntities((int) (short) 1, (java.lang.Boolean) false, false);
        boolean boolean22 = lineRenderer3D16.equals((java.lang.Object) false);
        java.awt.Paint paint23 = lineRenderer3D16.getBasePaint();
        piePlot1.setLabelShadowPaint(paint23);
        org.junit.Assert.assertNotNull(rotation2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        ganttRenderer0.setStartPercent((double) 100.0f);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor3 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.text.TextAnchor textAnchor8 = null;
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        java.awt.Shape shape11 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D5, (float) 1, (float) 0, textAnchor8, (double) 100L, textAnchor10);
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor3, textAnchor10, textAnchor12, (double) (byte) 100);
        ganttRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition14);
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator19 = new org.jfree.chart.urls.StandardCategoryURLGenerator("VerticalAlignment.TOP", "RectangleEdge.LEFT", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        ganttRenderer0.setBaseURLGenerator((org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator19);
        org.junit.Assert.assertNotNull(itemLabelAnchor3);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertNull(shape11);
        org.junit.Assert.assertNotNull(textAnchor12);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        int int1 = keyedObjects0.getItemCount();
        java.lang.Object obj3 = keyedObjects0.getObject((java.lang.Comparable) (short) -1);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean6 = numberAxis5.getAutoRangeStickyZero();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        numberAxis5.setTickMarkStroke(stroke7);
        numberAxis5.setTickMarkInsideLength(0.0f);
        numberAxis5.setAutoRangeMinimumSize((double) 3, false);
        boolean boolean14 = keyedObjects0.equals((java.lang.Object) numberAxis5);
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot(pieDataset15);
        org.jfree.chart.util.Rotation rotation17 = piePlot16.getDirection();
        org.jfree.chart.event.PlotChangeListener plotChangeListener18 = null;
        piePlot16.removeChangeListener(plotChangeListener18);
        piePlot16.setLabelLinksVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        piePlot16.handleClick(15, 1, plotRenderingInfo24);
        boolean boolean26 = numberAxis5.equals((java.lang.Object) 1);
        numberAxis5.setAutoRange(false);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rotation17);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.util.List list1 = defaultKeyedValues2D0.getColumnKeys();
        java.util.List list2 = defaultKeyedValues2D0.getColumnKeys();
        java.lang.Object obj3 = defaultKeyedValues2D0.clone();
        try {
            java.lang.Number number6 = defaultKeyedValues2D0.getValue((java.lang.Comparable) "AxisLocation.TOP_OR_LEFT", (java.lang.Comparable) 10L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: 10");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.util.Rotation rotation4 = piePlot3.getDirection();
        org.jfree.chart.plot.Plot plot5 = piePlot3.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = null;
        piePlot3.datasetChanged(datasetChangeEvent6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        piePlot3.drawBackgroundImage(graphics2D8, rectangle2D9);
        java.awt.Paint paint11 = piePlot3.getBaseSectionOutlinePaint();
        java.awt.Paint paint12 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot3.setBaseSectionPaint(paint12);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot3);
        jFreeChart14.setBackgroundImageAlpha((float) (byte) 10);
        int int17 = jFreeChart14.getBackgroundImageAlignment();
        int int18 = jFreeChart14.getSubtitleCount();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent21 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) licences0, jFreeChart14, (int) (short) 100, 15);
        org.junit.Assert.assertNotNull(licences0);
        org.junit.Assert.assertNotNull(rotation4);
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 15 + "'", int17 == 15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange3, 0.0d);
        org.jfree.data.Range range7 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange3, (double) '#');
        numberAxis1.setDefaultAutoRange((org.jfree.data.Range) dateRange3);
        boolean boolean9 = numberAxis1.isNegativeArrowVisible();
        boolean boolean10 = numberAxis1.isTickMarksVisible();
        java.lang.Object obj11 = numberAxis1.clone();
        java.awt.Shape shape17 = null;
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Paint paint21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke22 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape24 = null;
        java.awt.Stroke stroke25 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color26 = java.awt.Color.black;
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("", "hi!", "hi!", "", true, shape17, false, (java.awt.Paint) color19, false, paint21, stroke22, true, shape24, stroke25, (java.awt.Paint) color26);
        java.lang.Number[] numberArray35 = new java.lang.Number[] { (short) 1, 100.0f, 2, (short) -1, (-1.0f) };
        java.lang.Number[] numberArray41 = new java.lang.Number[] { (short) 1, 100.0f, 2, (short) -1, (-1.0f) };
        java.lang.Number[][] numberArray42 = new java.lang.Number[][] { numberArray35, numberArray41 };
        org.jfree.data.category.CategoryDataset categoryDataset43 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray42);
        legendItem27.setDataset((org.jfree.data.general.Dataset) categoryDataset43);
        boolean boolean45 = numberAxis1.equals((java.lang.Object) legendItem27);
        java.text.NumberFormat numberFormat46 = null;
        numberAxis1.setNumberFormatOverride(numberFormat46);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(dateRange3);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(numberArray41);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(categoryDataset43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 10, (long) 'a');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        java.util.Date date5 = month4.getStart();
        long long6 = month4.getMiddleMillisecond();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean8 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge7);
        org.jfree.data.KeyedObject keyedObject9 = new org.jfree.data.KeyedObject((java.lang.Comparable) month4, (java.lang.Object) rectangleEdge7);
        java.lang.Object obj10 = keyedObject9.clone();
        java.lang.Object obj11 = keyedObject9.clone();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1310400001L) + "'", long6 == (-1310400001L));
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.util.Rotation rotation4 = piePlot3.getDirection();
        org.jfree.chart.plot.Plot plot5 = piePlot3.getParent();
        org.jfree.chart.plot.Plot plot6 = piePlot3.getRootPlot();
        java.awt.Color color7 = java.awt.Color.MAGENTA;
        piePlot3.setOutlinePaint((java.awt.Paint) color7);
        columnArrangement0.add((org.jfree.chart.block.Block) textTitle1, (java.lang.Object) color7);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection10 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent11 = null;
        taskSeriesCollection10.seriesChanged(seriesChangeEvent11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.next();
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer15 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0, (org.jfree.data.general.Dataset) taskSeriesCollection10, (java.lang.Comparable) year13);
        try {
            java.lang.Number number19 = taskSeriesCollection10.getPercentComplete((java.lang.Comparable) (byte) -1, (java.lang.Comparable) 2.0f, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(rotation4);
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertNotNull(plot6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) true);
        int int3 = keyToGroupMap1.getKeyCount((java.lang.Comparable) 0.05d);
        java.util.List list4 = keyToGroupMap1.getGroups();
        java.lang.Comparable comparable5 = null;
        try {
            java.lang.Comparable comparable6 = keyToGroupMap1.getGroup(comparable5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(list4);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.DEFAULT_ITEM_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D8 = new org.jfree.chart.renderer.category.BarRenderer3D();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 2, (float) 4);
        barRenderer3D8.setSeriesShape((int) (short) 1, shape12, false);
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean17 = numberAxis16.getAutoRangeStickyZero();
        java.awt.Stroke stroke18 = numberAxis16.getAxisLineStroke();
        org.jfree.data.general.PieDataset pieDataset19 = null;
        org.jfree.chart.plot.PiePlot piePlot20 = new org.jfree.chart.plot.PiePlot(pieDataset19);
        org.jfree.chart.util.Rotation rotation21 = piePlot20.getDirection();
        org.jfree.chart.plot.Plot plot22 = piePlot20.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent23 = null;
        piePlot20.datasetChanged(datasetChangeEvent23);
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        piePlot20.drawBackgroundImage(graphics2D25, rectangle2D26);
        java.awt.Paint paint28 = piePlot20.getBaseSectionOutlinePaint();
        java.awt.Paint paint29 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot20.setBaseSectionPaint(paint29);
        org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "TextAnchor.CENTER_RIGHT", "ChartEntity: tooltip = ", shape12, stroke18, paint29);
        java.awt.Shape shape32 = org.jfree.chart.util.ShapeUtilities.clone(shape12);
        java.awt.Shape shape38 = null;
        java.awt.Color color40 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Paint paint42 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke43 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape45 = null;
        java.awt.Stroke stroke46 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color47 = java.awt.Color.black;
        org.jfree.chart.LegendItem legendItem48 = new org.jfree.chart.LegendItem("", "hi!", "hi!", "", true, shape38, false, (java.awt.Paint) color40, false, paint42, stroke43, true, shape45, stroke46, (java.awt.Paint) color47);
        java.awt.Color color49 = java.awt.Color.MAGENTA;
        try {
            org.jfree.chart.LegendItem legendItem50 = new org.jfree.chart.LegendItem(attributedString0, "Multiple Pie Plot", "SortOrder.ASCENDING", "HorizontalAlignment.CENTER", shape32, stroke43, (java.awt.Paint) color49);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(rotation21);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(color49);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (byte) 10);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        keyedObjects2D0.removeColumn((java.lang.Comparable) 100.0f);
        java.lang.Object obj3 = keyedObjects2D0.clone();
        try {
            java.lang.Object obj6 = keyedObjects2D0.getObject(2958465, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2958465, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        java.awt.Shape shape5 = null;
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape12 = null;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color14 = java.awt.Color.black;
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("", "hi!", "hi!", "", true, shape5, false, (java.awt.Paint) color7, false, paint9, stroke10, true, shape12, stroke13, (java.awt.Paint) color14);
        java.lang.Number[] numberArray23 = new java.lang.Number[] { (short) 1, 100.0f, 2, (short) -1, (-1.0f) };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { (short) 1, 100.0f, 2, (short) -1, (-1.0f) };
        java.lang.Number[][] numberArray30 = new java.lang.Number[][] { numberArray23, numberArray29 };
        org.jfree.data.category.CategoryDataset categoryDataset31 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray30);
        legendItem15.setDataset((org.jfree.data.general.Dataset) categoryDataset31);
        legendItem15.setSeriesIndex((int) (byte) 10);
        java.awt.Stroke stroke35 = legendItem15.getOutlineStroke();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(categoryDataset31);
        org.junit.Assert.assertNotNull(stroke35);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.data.time.DateRange dateRange1 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = rectangleConstraint0.toRangeHeight((org.jfree.data.Range) dateRange1);
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str5 = numberAxis4.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, 0.0d);
        org.jfree.data.Range range10 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange6, (double) '#');
        numberAxis4.setDefaultAutoRange((org.jfree.data.Range) dateRange6);
        org.jfree.data.Range range14 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange6, 0.0d, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint2.toRangeHeight(range14);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = rectangleConstraint2.toFixedHeight((double) 4);
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(dateRange1);
        org.junit.Assert.assertNotNull(rectangleConstraint2);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(rectangleConstraint17);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange3, 0.0d);
        org.jfree.data.Range range7 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange3, (double) '#');
        numberAxis1.setDefaultAutoRange((org.jfree.data.Range) dateRange3);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer9.setDrawOutlines(true);
        lineAndShapeRenderer9.setUseFillPaint(true);
        java.lang.Boolean boolean15 = lineAndShapeRenderer9.getSeriesShapesVisible(2);
        java.awt.Paint paint17 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        lineAndShapeRenderer9.setSeriesPaint((int) (byte) 10, paint17, true);
        boolean boolean20 = numberAxis1.equals((java.lang.Object) (byte) 10);
        numberAxis1.setAutoRange(false);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(dateRange3);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(boolean15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        int int1 = keyedObjects0.getItemCount();
        java.lang.Object obj3 = keyedObjects0.getObject((java.lang.Comparable) (short) -1);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean6 = numberAxis5.getAutoRangeStickyZero();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        numberAxis5.setTickMarkStroke(stroke7);
        numberAxis5.setTickMarkInsideLength(0.0f);
        numberAxis5.setAutoRangeMinimumSize((double) 3, false);
        boolean boolean14 = keyedObjects0.equals((java.lang.Object) numberAxis5);
        keyedObjects0.setObject((java.lang.Comparable) (short) 100, (java.lang.Object) 3.0d);
        java.lang.Object obj18 = keyedObjects0.clone();
        int int20 = keyedObjects0.getIndex((java.lang.Comparable) "AxisLocation.TOP_OR_LEFT");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.util.Rotation rotation3 = piePlot2.getDirection();
        org.jfree.chart.plot.Plot plot4 = piePlot2.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        piePlot2.datasetChanged(datasetChangeEvent5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        piePlot2.drawBackgroundImage(graphics2D7, rectangle2D8);
        java.awt.Paint paint10 = piePlot2.getBaseSectionOutlinePaint();
        java.awt.Paint paint11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot2.setBaseSectionPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart13.setTitle("({0}, {1}) = {3} - {4}");
        java.lang.Object obj16 = jFreeChart13.clone();
        java.awt.RenderingHints renderingHints17 = jFreeChart13.getRenderingHints();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent18 = null;
        try {
            jFreeChart13.plotChanged(plotChangeEvent18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(renderingHints17);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        org.jfree.chart.entity.EntityCollection entityCollection0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo(entityCollection0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = chartRenderingInfo1.getPlotInfo();
        int int3 = plotRenderingInfo2.getSubplotCount();
        org.junit.Assert.assertNotNull(plotRenderingInfo2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        keyedObjects2D0.removeColumn((java.lang.Comparable) 100.0f);
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        org.jfree.chart.util.Rotation rotation5 = piePlot4.getDirection();
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        piePlot4.removeChangeListener(plotChangeListener6);
        piePlot4.setLabelLinksVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        piePlot4.handleClick(15, 1, plotRenderingInfo12);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator16 = null;
        piePlot15.setToolTipGenerator(pieToolTipGenerator16);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((long) 10, (long) 'a');
        java.awt.Stroke stroke21 = piePlot15.getSectionOutlineStroke((java.lang.Comparable) simpleTimePeriod20);
        java.util.Date date22 = simpleTimePeriod20.getEnd();
        keyedObjects2D0.setObject((java.lang.Object) 15, (java.lang.Comparable) simpleTimePeriod20, (java.lang.Comparable) (byte) 0);
        java.util.Date date25 = simpleTimePeriod20.getEnd();
        org.junit.Assert.assertNotNull(rotation5);
        org.junit.Assert.assertNull(stroke21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(date25);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        int int1 = defaultStatisticalCategoryDataset0.getColumnCount();
        java.lang.Comparable comparable2 = null;
        int int3 = defaultStatisticalCategoryDataset0.getRowIndex(comparable2);
        java.lang.Object obj4 = defaultStatisticalCategoryDataset0.clone();
        java.util.List list5 = defaultStatisticalCategoryDataset0.getColumnKeys();
        double double7 = defaultStatisticalCategoryDataset0.getRangeLowerBound(true);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = lineAndShapeRenderer0.getToolTipGenerator(2, 1);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        org.jfree.chart.util.Rotation rotation6 = piePlot5.getDirection();
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        piePlot5.removeChangeListener(plotChangeListener7);
        piePlot5.setLabelLinksVisible(false);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.color.ColorSpace colorSpace12 = color11.getColorSpace();
        piePlot5.setLabelLinkPaint((java.awt.Paint) color11);
        lineAndShapeRenderer0.setBaseFillPaint((java.awt.Paint) color11);
        lineAndShapeRenderer0.setDrawOutlines(false);
        java.awt.Paint paint18 = lineAndShapeRenderer0.getSeriesItemLabelPaint((int) (short) 10);
        org.junit.Assert.assertNull(categoryToolTipGenerator3);
        org.junit.Assert.assertNotNull(rotation6);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(colorSpace12);
        org.junit.Assert.assertNull(paint18);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, 0.0d);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange4, (double) '#');
        numberAxis2.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        boolean boolean10 = numberAxis2.isNegativeArrowVisible();
        boolean boolean11 = numberAxis2.isTickMarksVisible();
        java.lang.String str12 = numberAxis2.getLabel();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean15 = numberAxis3D14.isInverted();
        org.jfree.data.time.DateRange dateRange16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis3D14.setRangeWithMargins((org.jfree.data.Range) dateRange16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, xYItemRenderer18);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str23 = numberAxis22.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange24 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange24, 0.0d);
        org.jfree.data.Range range28 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange24, (double) '#');
        numberAxis22.setDefaultAutoRange((org.jfree.data.Range) dateRange24);
        boolean boolean30 = numberAxis22.isNegativeArrowVisible();
        boolean boolean31 = numberAxis22.isTickMarksVisible();
        numberAxis22.setFixedAutoRange((double) 1);
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str36 = numberAxis35.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange37 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint39 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange37, 0.0d);
        org.jfree.data.Range range41 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange37, (double) '#');
        numberAxis35.setDefaultAutoRange((org.jfree.data.Range) dateRange37);
        boolean boolean43 = numberAxis35.isNegativeArrowVisible();
        boolean boolean44 = numberAxis35.isTickMarksVisible();
        java.lang.Object obj45 = numberAxis35.clone();
        java.awt.Font font50 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand51 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis35, (double) 11, 0.0d, (double) 'a', (double) 100, font50);
        java.awt.Graphics2D graphics2D52 = null;
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        markerAxisBand51.draw(graphics2D52, rectangle2D53, rectangle2D54, (double) 12, (double) 12);
        numberAxis22.setMarkerBand(markerAxisBand51);
        xYPlot19.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) numberAxis22);
        xYPlot19.setDomainGridlinesVisible(true);
        xYPlot19.clearDomainMarkers();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateRange16);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(dateRange24);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertNotNull(dateRange37);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(obj45);
        org.junit.Assert.assertNotNull(font50);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic2 = new org.jfree.chart.title.LegendGraphic(shape0, (java.awt.Paint) color1);
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        org.jfree.chart.util.Rotation rotation5 = piePlot4.getDirection();
        org.jfree.chart.plot.Plot plot6 = piePlot4.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        piePlot4.datasetChanged(datasetChangeEvent7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        piePlot4.drawBackgroundImage(graphics2D9, rectangle2D10);
        java.awt.Shape shape17 = null;
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Paint paint21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke22 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape24 = null;
        java.awt.Stroke stroke25 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color26 = java.awt.Color.black;
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("", "hi!", "hi!", "", true, shape17, false, (java.awt.Paint) color19, false, paint21, stroke22, true, shape24, stroke25, (java.awt.Paint) color26);
        java.awt.Stroke stroke28 = legendItem27.getLineStroke();
        piePlot4.setBaseSectionOutlineStroke(stroke28);
        legendGraphic2.setOutlineStroke(stroke28);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor31 = legendGraphic2.getShapeLocation();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor32 = legendGraphic2.getShapeAnchor();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rotation5);
        org.junit.Assert.assertNull(plot6);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(rectangleAnchor31);
        org.junit.Assert.assertNotNull(rectangleAnchor32);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = piePlot1.getDirection();
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot1.removeChangeListener(plotChangeListener3);
        piePlot1.setLabelLinksVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        piePlot1.handleClick(15, 1, plotRenderingInfo9);
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        org.jfree.chart.util.Rotation rotation13 = piePlot12.getDirection();
        org.jfree.chart.plot.Plot plot14 = piePlot12.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent15 = null;
        piePlot12.datasetChanged(datasetChangeEvent15);
        java.awt.Stroke stroke17 = null;
        piePlot12.setLabelOutlineStroke(stroke17);
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray30 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray35 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray40 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray45 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray50 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[][] numberArray51 = new java.lang.Number[][] { numberArray25, numberArray30, numberArray35, numberArray40, numberArray45, numberArray50 };
        org.jfree.data.category.CategoryDataset categoryDataset52 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray51);
        org.jfree.data.general.PieDataset pieDataset54 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset52, (int) (short) 1);
        piePlot12.setDataset(pieDataset54);
        org.jfree.data.general.PieDataset pieDataset59 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset54, (java.lang.Comparable) "", 90.0d, (int) (byte) 1);
        double double60 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset54);
        org.jfree.chart.plot.PiePlot piePlot61 = new org.jfree.chart.plot.PiePlot(pieDataset54);
        piePlot1.setDataset(pieDataset54);
        java.text.DateFormat dateFormat65 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit66 = new org.jfree.chart.axis.DateTickUnit(0, 0, dateFormat65);
        org.jfree.data.general.PieDataset pieDataset69 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset54, (java.lang.Comparable) 0, (double) 10, 0);
        boolean boolean70 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset54);
        org.jfree.chart.plot.RingPlot ringPlot71 = new org.jfree.chart.plot.RingPlot(pieDataset54);
        ringPlot71.setOuterSeparatorExtension(0.0d);
        ringPlot71.setIgnoreZeroValues(false);
        org.junit.Assert.assertNotNull(rotation2);
        org.junit.Assert.assertNotNull(rotation13);
        org.junit.Assert.assertNull(plot14);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(categoryDataset52);
        org.junit.Assert.assertNotNull(pieDataset54);
        org.junit.Assert.assertNotNull(pieDataset59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNotNull(pieDataset69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.chart.ChartColor chartColor5 = new org.jfree.chart.ChartColor((int) (short) 0, (int) (byte) 100, (int) '#');
        boolean boolean6 = spreadsheetDate1.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate9 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate8);
        int int10 = spreadsheetDate1.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9 + "'", int10 == 9);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        java.awt.geom.GeneralPath generalPath0 = null;
        java.awt.geom.GeneralPath generalPath1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(generalPath0, generalPath1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        minMaxCategoryRenderer0.setBaseCreateEntities(false, true);
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.util.Rotation rotation7 = piePlot6.getDirection();
        org.jfree.chart.plot.Plot plot8 = piePlot6.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent9 = null;
        piePlot6.datasetChanged(datasetChangeEvent9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        piePlot6.drawBackgroundImage(graphics2D11, rectangle2D12);
        java.awt.Paint paint14 = piePlot6.getBaseSectionOutlinePaint();
        java.awt.Paint paint15 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot6.setBaseSectionPaint(paint15);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot6);
        jFreeChart17.setTitle("({0}, {1}) = {3} - {4}");
        org.jfree.chart.title.TextTitle textTitle20 = jFreeChart17.getTitle();
        java.awt.Stroke stroke21 = jFreeChart17.getBorderStroke();
        jFreeChart17.setAntiAlias(true);
        org.jfree.chart.ui.Library library28 = new org.jfree.chart.ui.Library("hi!", "hi!", "hi!", "");
        java.awt.Paint paint29 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        boolean boolean30 = library28.equals((java.lang.Object) paint29);
        jFreeChart17.setBorderPaint(paint29);
        minMaxCategoryRenderer0.setGroupPaint(paint29);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator35 = minMaxCategoryRenderer0.getItemLabelGenerator((int) (short) 100, (int) (short) 0);
        java.awt.Shape shape36 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Color color37 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic38 = new org.jfree.chart.title.LegendGraphic(shape36, (java.awt.Paint) color37);
        minMaxCategoryRenderer0.setBaseShape(shape36);
        org.junit.Assert.assertNotNull(rotation7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(textTitle20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator35);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(color37);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setDrawOutlines(true);
        lineAndShapeRenderer0.setUseFillPaint(true);
        java.lang.Boolean boolean6 = lineAndShapeRenderer0.getSeriesShapesVisible(2);
        java.awt.Paint paint8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        lineAndShapeRenderer0.setSeriesPaint((int) (byte) 10, paint8, true);
        double double11 = lineAndShapeRenderer0.getItemLabelAnchorOffset();
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 2.0d + "'", double11 == 2.0d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getFixedAutoRange();
        java.text.NumberFormat numberFormat4 = numberAxis2.getNumberFormatOverride();
        boolean boolean5 = numberAxis2.isVerticalTickLabels();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, polarItemRenderer6);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.util.Rotation rotation10 = piePlot9.getDirection();
        org.jfree.chart.plot.Plot plot11 = piePlot9.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = null;
        piePlot9.datasetChanged(datasetChangeEvent12);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        piePlot9.drawBackgroundImage(graphics2D14, rectangle2D15);
        java.awt.Paint paint17 = piePlot9.getBaseSectionOutlinePaint();
        java.awt.Paint paint18 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot9.setBaseSectionPaint(paint18);
        polarPlot7.setAngleGridlinePaint(paint18);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D22 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean23 = numberAxis3D22.isTickMarksVisible();
        org.jfree.chart.plot.Plot plot24 = numberAxis3D22.getPlot();
        org.jfree.data.Range range25 = polarPlot7.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D22);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        polarPlot7.setDataset(xYDataset26);
        boolean boolean28 = polarPlot7.isDomainZoomable();
        java.awt.Font font29 = polarPlot7.getAngleLabelFont();
        boolean boolean30 = polarPlot7.isRadiusGridlinesVisible();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNull(numberFormat4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rotation10);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(plot24);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        java.awt.Font font0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange0, 0.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = rectangleConstraint2.toUnconstrainedHeight();
        org.jfree.data.Range range4 = rectangleConstraint2.getHeightRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = rectangleConstraint2.toFixedHeight((double) 500);
        org.junit.Assert.assertNotNull(dateRange0);
        org.junit.Assert.assertNotNull(rectangleConstraint3);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNotNull(rectangleConstraint6);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.chart.ChartColor chartColor5 = new org.jfree.chart.ChartColor((int) (short) 0, (int) (byte) 100, (int) '#');
        boolean boolean6 = spreadsheetDate1.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate9 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate8);
        int int10 = spreadsheetDate1.getDayOfWeek();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = null;
        taskSeriesCollection0.seriesChanged(seriesChangeEvent1);
        int int4 = taskSeriesCollection0.getColumnIndex((java.lang.Comparable) "9-April-1900");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 10, (long) 'a');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        java.util.Date date5 = month4.getStart();
        long long6 = month4.getMiddleMillisecond();
        long long7 = month4.getLastMillisecond();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1310400001L) + "'", long6 == (-1310400001L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 28799999L + "'", long7 == 28799999L);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "({0}, {1}) = {3} - {4}", "", image3, "hi!", "hi!", "({0}, {1}) = {3} - {4}");
        java.util.List list8 = projectInfo7.getContributors();
        java.awt.Image image12 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo16 = new org.jfree.chart.ui.ProjectInfo("", "({0}, {1}) = {3} - {4}", "", image12, "hi!", "hi!", "({0}, {1}) = {3} - {4}");
        java.awt.Image image17 = null;
        projectInfo16.setLogo(image17);
        projectInfo7.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo16);
        projectInfo7.setVersion("SortOrder.ASCENDING");
        org.junit.Assert.assertNull(list8);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity3 = new org.jfree.chart.entity.TickLabelEntity(shape0, "", "hi!");
        java.lang.String str4 = tickLabelEntity3.getShapeCoords();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0" + "'", str4.equals("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setDrawOutlines(true);
        lineAndShapeRenderer0.setUseFillPaint(true);
        java.lang.Boolean boolean6 = lineAndShapeRenderer0.getSeriesShapesVisible(2);
        lineAndShapeRenderer0.setSeriesVisible((int) ' ', (java.lang.Boolean) false, true);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double14 = numberAxis13.getFixedAutoRange();
        java.text.NumberFormat numberFormat15 = numberAxis13.getNumberFormatOverride();
        boolean boolean16 = numberAxis13.isVerticalTickLabels();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer17 = null;
        org.jfree.chart.plot.PolarPlot polarPlot18 = new org.jfree.chart.plot.PolarPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) numberAxis13, polarItemRenderer17);
        org.jfree.data.general.PieDataset pieDataset19 = null;
        org.jfree.chart.plot.PiePlot piePlot20 = new org.jfree.chart.plot.PiePlot(pieDataset19);
        org.jfree.chart.util.Rotation rotation21 = piePlot20.getDirection();
        org.jfree.chart.plot.Plot plot22 = piePlot20.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent23 = null;
        piePlot20.datasetChanged(datasetChangeEvent23);
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        piePlot20.drawBackgroundImage(graphics2D25, rectangle2D26);
        java.awt.Paint paint28 = piePlot20.getBaseSectionOutlinePaint();
        java.awt.Paint paint29 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot20.setBaseSectionPaint(paint29);
        polarPlot18.setAngleGridlinePaint(paint29);
        boolean boolean32 = lineAndShapeRenderer0.equals((java.lang.Object) polarPlot18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        org.jfree.data.xy.XYDataset xYDataset35 = null;
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str38 = numberAxis37.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange39 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint41 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange39, 0.0d);
        org.jfree.data.Range range43 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange39, (double) '#');
        numberAxis37.setDefaultAutoRange((org.jfree.data.Range) dateRange39);
        boolean boolean45 = numberAxis37.isNegativeArrowVisible();
        boolean boolean46 = numberAxis37.isTickMarksVisible();
        java.lang.String str47 = numberAxis37.getLabel();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D49 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean50 = numberAxis3D49.isInverted();
        org.jfree.data.time.DateRange dateRange51 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis3D49.setRangeWithMargins((org.jfree.data.Range) dateRange51);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer53 = null;
        org.jfree.chart.plot.XYPlot xYPlot54 = new org.jfree.chart.plot.XYPlot(xYDataset35, (org.jfree.chart.axis.ValueAxis) numberAxis37, (org.jfree.chart.axis.ValueAxis) numberAxis3D49, xYItemRenderer53);
        java.awt.Paint paint55 = xYPlot54.getDomainGridlinePaint();
        xYPlot54.setRangeCrosshairVisible(true);
        java.awt.geom.Point2D point2D58 = xYPlot54.getQuadrantOrigin();
        polarPlot18.zoomRangeAxes((double) 10.0f, plotRenderingInfo34, point2D58);
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNull(numberFormat15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rotation21);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertNotNull(dateRange39);
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "hi!" + "'", str47.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(dateRange51);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertNotNull(point2D58);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setSeriesCreateEntities((int) (short) 1, (java.lang.Boolean) false, false);
        boolean boolean6 = lineRenderer3D0.equals((java.lang.Object) false);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str12 = numberAxis11.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange13 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange13, 0.0d);
        org.jfree.data.Range range17 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange13, (double) '#');
        numberAxis11.setDefaultAutoRange((org.jfree.data.Range) dateRange13);
        boolean boolean19 = numberAxis11.isNegativeArrowVisible();
        boolean boolean20 = numberAxis11.isTickMarksVisible();
        java.lang.String str21 = numberAxis11.getLabel();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D23 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean24 = numberAxis3D23.isInverted();
        org.jfree.data.time.DateRange dateRange25 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis3D23.setRangeWithMargins((org.jfree.data.Range) dateRange25);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) numberAxis11, (org.jfree.chart.axis.ValueAxis) numberAxis3D23, xYItemRenderer27);
        org.jfree.chart.util.Size2D size2D31 = new org.jfree.chart.util.Size2D((double) 0.0f, (double) 1L);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor34 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Rectangle2D rectangle2D35 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D31, (double) (byte) 100, (double) 10, rectangleAnchor34);
        java.awt.Shape shape39 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D35, (double) 1, (float) (byte) 0, (float) '4');
        try {
            lineRenderer3D0.drawRangeGridline(graphics2D7, categoryPlot8, (org.jfree.chart.axis.ValueAxis) numberAxis11, rectangle2D35, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(dateRange13);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(dateRange25);
        org.junit.Assert.assertNotNull(rectangleAnchor34);
        org.junit.Assert.assertNotNull(rectangle2D35);
        org.junit.Assert.assertNotNull(shape39);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.START;
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 2, (float) 4);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape3, "");
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity8 = new org.jfree.chart.entity.TickLabelEntity(shape3, "RectangleEdge.LEFT", "RectangleEdge.LEFT");
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape3, 1.0E-8d, 0.0f, (float) 100L);
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray36 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray41 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[][] numberArray47 = new java.lang.Number[][] { numberArray21, numberArray26, numberArray31, numberArray36, numberArray41, numberArray46 };
        org.jfree.data.category.CategoryDataset categoryDataset48 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray47);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod51 = new org.jfree.data.time.SimpleTimePeriod((long) 10, (long) 'a');
        java.lang.Comparable comparable52 = null;
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity53 = new org.jfree.chart.entity.CategoryItemEntity(shape12, "({0}, {1}) = {3} - {4}", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", categoryDataset48, (java.lang.Comparable) 10, comparable52);
        categoryItemEntity53.setColumnKey((java.lang.Comparable) 100.0d);
        boolean boolean56 = categoryAnchor0.equals((java.lang.Object) categoryItemEntity53);
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray36);
        org.junit.Assert.assertNotNull(numberArray41);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray47);
        org.junit.Assert.assertNotNull(categoryDataset48);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.END;
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange3, 0.0d);
        org.jfree.data.Range range7 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange3, (double) '#');
        numberAxis1.setDefaultAutoRange((org.jfree.data.Range) dateRange3);
        boolean boolean9 = numberAxis1.isNegativeArrowVisible();
        boolean boolean10 = numberAxis1.isTickMarksVisible();
        java.lang.Object obj11 = numberAxis1.clone();
        java.lang.Object obj12 = numberAxis1.clone();
        java.awt.Shape shape13 = numberAxis1.getRightArrow();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(dateRange3);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(shape13);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint2 = statisticalBarRenderer0.lookupSeriesPaint((-1));
        java.awt.Paint paint3 = statisticalBarRenderer0.getErrorIndicatorPaint();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (byte) -1);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getFixedAutoRange();
        java.text.NumberFormat numberFormat4 = numberAxis2.getNumberFormatOverride();
        boolean boolean5 = numberAxis2.isVerticalTickLabels();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, polarItemRenderer6);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.util.Rotation rotation10 = piePlot9.getDirection();
        org.jfree.chart.plot.Plot plot11 = piePlot9.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = null;
        piePlot9.datasetChanged(datasetChangeEvent12);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        piePlot9.drawBackgroundImage(graphics2D14, rectangle2D15);
        java.awt.Paint paint17 = piePlot9.getBaseSectionOutlinePaint();
        java.awt.Paint paint18 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot9.setBaseSectionPaint(paint18);
        polarPlot7.setAngleGridlinePaint(paint18);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D22 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean23 = numberAxis3D22.isTickMarksVisible();
        org.jfree.chart.plot.Plot plot24 = numberAxis3D22.getPlot();
        org.jfree.data.Range range25 = polarPlot7.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D22);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        polarPlot7.setDataset(xYDataset26);
        polarPlot7.zoom(32.0d);
        java.awt.Paint paint30 = polarPlot7.getRadiusGridlinePaint();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNull(numberFormat4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rotation10);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(plot24);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertNotNull(paint30);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getFixedAutoRange();
        java.text.NumberFormat numberFormat4 = numberAxis2.getNumberFormatOverride();
        boolean boolean5 = numberAxis2.isVerticalTickLabels();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, polarItemRenderer6);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean10 = numberAxis9.getAutoRangeStickyZero();
        polarPlot7.setAxis((org.jfree.chart.axis.ValueAxis) numberAxis9);
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = polarPlot7.getOrientation();
        org.jfree.data.KeyedObjects keyedObjects13 = new org.jfree.data.KeyedObjects();
        int int14 = keyedObjects13.getItemCount();
        boolean boolean15 = plotOrientation12.equals((java.lang.Object) keyedObjects13);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNull(numberFormat4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(plotOrientation12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateBottomOutset((double) (-1L));
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.TOP;
        boolean boolean4 = rectangleInsets0.equals((java.lang.Object) rectangleAnchor3);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor5 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        boolean boolean8 = textAnchor6.equals((java.lang.Object) 'a');
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType10 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition12 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor3, textBlockAnchor5, textAnchor6, (double) (-2208960000000L), categoryLabelWidthType10, (float) 3);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor13 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.text.TextAnchor textAnchor18 = null;
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        java.awt.Shape shape21 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D15, (float) 1, (float) 0, textAnchor18, (double) 100L, textAnchor20);
        java.lang.String str22 = textAnchor20.toString();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType24 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition26 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor3, textBlockAnchor13, textAnchor20, 0.0d, categoryLabelWidthType24, (float) (short) 100);
        java.lang.String str27 = textAnchor20.toString();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor5);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(categoryLabelWidthType10);
        org.junit.Assert.assertNotNull(textBlockAnchor13);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNull(shape21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "TextAnchor.CENTER_RIGHT" + "'", str22.equals("TextAnchor.CENTER_RIGHT"));
        org.junit.Assert.assertNotNull(categoryLabelWidthType24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "TextAnchor.CENTER_RIGHT" + "'", str27.equals("TextAnchor.CENTER_RIGHT"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        java.awt.Shape shape5 = null;
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape12 = null;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color14 = java.awt.Color.black;
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("", "hi!", "hi!", "", true, shape5, false, (java.awt.Paint) color7, false, paint9, stroke10, true, shape12, stroke13, (java.awt.Paint) color14);
        java.awt.Stroke stroke16 = legendItem15.getLineStroke();
        legendItem15.setSeriesIndex((int) (short) 0);
        int int19 = legendItem15.getSeriesIndex();
        boolean boolean20 = legendItem15.isLineVisible();
        java.awt.Stroke stroke21 = legendItem15.getOutlineStroke();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(stroke21);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 2, (float) 4);
        barRenderer3D0.setSeriesShape((int) (short) 1, shape4, false);
        java.lang.Boolean boolean8 = barRenderer3D0.getSeriesVisible(0);
        java.awt.Paint paint9 = barRenderer3D0.getBaseFillPaint();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(boolean8);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("");
        java.lang.String str2 = textFragment1.getText();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        try {
            float float5 = textFragment1.calculateBaselineOffset(graphics2D3, textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, 0.0d);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange4, (double) '#');
        numberAxis2.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        boolean boolean10 = numberAxis2.isNegativeArrowVisible();
        boolean boolean11 = numberAxis2.isTickMarksVisible();
        java.lang.String str12 = numberAxis2.getLabel();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean15 = numberAxis3D14.isInverted();
        org.jfree.data.time.DateRange dateRange16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis3D14.setRangeWithMargins((org.jfree.data.Range) dateRange16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, xYItemRenderer18);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray20 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot19.setRenderers(xYItemRendererArray20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        xYPlot19.zoomRangeAxes((double) (-1L), plotRenderingInfo23, point2D24);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        xYPlot19.setDataset(xYDataset26);
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str32 = numberAxis31.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange33 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint35 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange33, 0.0d);
        org.jfree.data.Range range37 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange33, (double) '#');
        numberAxis31.setDefaultAutoRange((org.jfree.data.Range) dateRange33);
        boolean boolean39 = numberAxis31.isNegativeArrowVisible();
        boolean boolean40 = numberAxis31.isTickMarksVisible();
        java.lang.String str41 = numberAxis31.getLabel();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D43 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean44 = numberAxis3D43.isInverted();
        org.jfree.data.time.DateRange dateRange45 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis3D43.setRangeWithMargins((org.jfree.data.Range) dateRange45);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset29, (org.jfree.chart.axis.ValueAxis) numberAxis31, (org.jfree.chart.axis.ValueAxis) numberAxis3D43, xYItemRenderer47);
        java.awt.Paint paint49 = xYPlot48.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation51 = xYPlot48.getRangeAxisLocation(1969);
        xYPlot19.setDomainAxisLocation(1, axisLocation51, false);
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D54 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D54.setSeriesCreateEntities((int) (short) 1, (java.lang.Boolean) false, false);
        boolean boolean60 = lineRenderer3D54.equals((java.lang.Object) false);
        java.awt.Graphics2D graphics2D61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = null;
        org.jfree.chart.axis.NumberAxis numberAxis64 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean65 = numberAxis64.getAutoRangeStickyZero();
        java.awt.Stroke stroke66 = numberAxis64.getAxisLineStroke();
        org.jfree.data.time.Year year68 = new org.jfree.data.time.Year();
        long long69 = year68.getLastMillisecond();
        org.jfree.data.gantt.Task task70 = new org.jfree.data.gantt.Task("AxisLocation.TOP_OR_LEFT", (org.jfree.data.time.TimePeriod) year68);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer71 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Paint paint72 = ganttRenderer71.getCompletePaint();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier73 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint74 = defaultDrawingSupplier73.getNextFillPaint();
        java.awt.Stroke stroke75 = defaultDrawingSupplier73.getNextStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker76 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) year68, paint72, stroke75);
        java.awt.geom.Rectangle2D rectangle2D77 = null;
        lineRenderer3D54.drawRangeMarker(graphics2D61, categoryPlot62, (org.jfree.chart.axis.ValueAxis) numberAxis64, (org.jfree.chart.plot.Marker) categoryMarker76, rectangle2D77);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType79 = categoryMarker76.getLabelOffsetType();
        org.jfree.chart.util.Layer layer80 = null;
        xYPlot19.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker76, layer80);
        org.jfree.chart.axis.AxisLocation axisLocation82 = xYPlot19.getDomainAxisLocation();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateRange16);
        org.junit.Assert.assertNotNull(xYItemRendererArray20);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertNotNull(dateRange33);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "hi!" + "'", str41.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(dateRange45);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(axisLocation51);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertNotNull(stroke66);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 1577865599999L + "'", long69 == 1577865599999L);
        org.junit.Assert.assertNotNull(paint72);
        org.junit.Assert.assertNotNull(paint74);
        org.junit.Assert.assertNotNull(stroke75);
        org.junit.Assert.assertNotNull(lengthAdjustmentType79);
        org.junit.Assert.assertNotNull(axisLocation82);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getFixedAutoRange();
        java.text.NumberFormat numberFormat4 = numberAxis2.getNumberFormatOverride();
        boolean boolean5 = numberAxis2.isVerticalTickLabels();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, polarItemRenderer6);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.util.Rotation rotation10 = piePlot9.getDirection();
        org.jfree.chart.plot.Plot plot11 = piePlot9.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = null;
        piePlot9.datasetChanged(datasetChangeEvent12);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        piePlot9.drawBackgroundImage(graphics2D14, rectangle2D15);
        java.awt.Paint paint17 = piePlot9.getBaseSectionOutlinePaint();
        java.awt.Paint paint18 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot9.setBaseSectionPaint(paint18);
        polarPlot7.setAngleGridlinePaint(paint18);
        java.awt.Paint paint21 = polarPlot7.getAngleLabelPaint();
        java.awt.Stroke stroke22 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.title.TextTitle textTitle23 = new org.jfree.chart.title.TextTitle();
        textTitle23.setNotify(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double28 = rectangleInsets26.calculateBottomOutset((double) (-1L));
        org.jfree.chart.util.RectangleAnchor rectangleAnchor29 = org.jfree.chart.util.RectangleAnchor.TOP;
        boolean boolean30 = rectangleInsets26.equals((java.lang.Object) rectangleAnchor29);
        textTitle23.setPadding(rectangleInsets26);
        org.jfree.chart.block.LineBorder lineBorder32 = new org.jfree.chart.block.LineBorder(paint21, stroke22, rectangleInsets26);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNull(numberFormat4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rotation10);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = piePlot1.getDirection();
        org.jfree.chart.plot.Plot plot3 = piePlot1.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        piePlot1.datasetChanged(datasetChangeEvent4);
        java.awt.Stroke stroke6 = null;
        piePlot1.setLabelOutlineStroke(stroke6);
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray34 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[][] numberArray40 = new java.lang.Number[][] { numberArray14, numberArray19, numberArray24, numberArray29, numberArray34, numberArray39 };
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray40);
        org.jfree.data.general.PieDataset pieDataset43 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset41, (int) (short) 1);
        piePlot1.setDataset(pieDataset43);
        org.jfree.data.general.PieDataset pieDataset48 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset43, (java.lang.Comparable) "", 90.0d, (int) (byte) 1);
        double double49 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset43);
        org.jfree.chart.plot.PiePlot piePlot50 = new org.jfree.chart.plot.PiePlot(pieDataset43);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D52 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.general.PieDataset pieDataset53 = null;
        org.jfree.chart.plot.PiePlot piePlot54 = new org.jfree.chart.plot.PiePlot(pieDataset53);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator55 = null;
        piePlot54.setToolTipGenerator(pieToolTipGenerator55);
        numberAxis3D52.setPlot((org.jfree.chart.plot.Plot) piePlot54);
        org.jfree.chart.block.ColumnArrangement columnArrangement58 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.title.TextTitle textTitle59 = new org.jfree.chart.title.TextTitle();
        org.jfree.data.general.PieDataset pieDataset60 = null;
        org.jfree.chart.plot.PiePlot piePlot61 = new org.jfree.chart.plot.PiePlot(pieDataset60);
        org.jfree.chart.util.Rotation rotation62 = piePlot61.getDirection();
        org.jfree.chart.plot.Plot plot63 = piePlot61.getParent();
        org.jfree.chart.plot.Plot plot64 = piePlot61.getRootPlot();
        java.awt.Color color65 = java.awt.Color.MAGENTA;
        piePlot61.setOutlinePaint((java.awt.Paint) color65);
        columnArrangement58.add((org.jfree.chart.block.Block) textTitle59, (java.lang.Object) color65);
        piePlot54.setBackgroundPaint((java.awt.Paint) color65);
        piePlot50.setBackgroundPaint((java.awt.Paint) color65);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor70 = null;
        try {
            piePlot50.setLabelDistributor(abstractPieLabelDistributor70);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'distributor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rotation2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(pieDataset43);
        org.junit.Assert.assertNotNull(pieDataset48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(rotation62);
        org.junit.Assert.assertNull(plot63);
        org.junit.Assert.assertNotNull(plot64);
        org.junit.Assert.assertNotNull(color65);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.zoomRange(0.0d, 10.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis0.setTickMarkPosition(dateTickMarkPosition4);
        java.lang.String str6 = dateTickMarkPosition4.toString();
        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DateTickMarkPosition.START" + "'", str6.equals("DateTickMarkPosition.START"));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setDrawOutlines(true);
        lineAndShapeRenderer0.setUseFillPaint(true);
        java.lang.Boolean boolean6 = lineAndShapeRenderer0.getSeriesShapesVisible(2);
        java.awt.Paint paint8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        lineAndShapeRenderer0.setSeriesPaint((int) (byte) 10, paint8, true);
        int int11 = lineAndShapeRenderer0.getPassCount();
        java.awt.Paint paint13 = lineAndShapeRenderer0.getSeriesFillPaint(9999);
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
        org.junit.Assert.assertNull(paint13);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("PlotOrientation.VERTICAL");
        categoryAxis3D1.removeCategoryLabelToolTip((java.lang.Comparable) 10);
        java.lang.String str5 = categoryAxis3D1.getCategoryLabelToolTip((java.lang.Comparable) "TextBlockAnchor.CENTER_RIGHT");
        java.lang.String str6 = categoryAxis3D1.getLabel();
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PlotOrientation.VERTICAL" + "'", str6.equals("PlotOrientation.VERTICAL"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        dateAxis2.zoomRange(0.0d, 10.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = dateAxis2.getTickUnit();
        java.text.DateFormat dateFormat9 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = new org.jfree.chart.axis.DateTickUnit(0, 0, dateFormat9);
        dateAxis2.setTickUnit(dateTickUnit10);
        try {
            java.lang.Number number12 = defaultCategoryDataset0.getValue((java.lang.Comparable) 1.0d, (java.lang.Comparable) dateTickUnit10);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: DateTickUnit[YEAR, 0]");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit6);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getFixedAutoRange();
        java.text.NumberFormat numberFormat3 = numberAxis1.getNumberFormatOverride();
        boolean boolean4 = numberAxis1.isVerticalTickLabels();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent5 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNull(numberFormat3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = piePlot1.getDirection();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator3 = piePlot1.getURLGenerator();
        piePlot1.setMaximumLabelWidth((double) (short) 100);
        double double7 = piePlot1.getExplodePercent((java.lang.Comparable) 10.0f);
        java.awt.Paint paint8 = piePlot1.getLabelPaint();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier9 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint10 = defaultDrawingSupplier9.getNextOutlinePaint();
        piePlot1.setLabelShadowPaint(paint10);
        org.junit.Assert.assertNotNull(rotation2);
        org.junit.Assert.assertNull(pieURLGenerator3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(1577865599999L, (long) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires end >= start.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "ChartChangeEventType.DATASET_UPDATED");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.chart.ChartColor chartColor7 = new org.jfree.chart.ChartColor((int) (short) 0, (int) (byte) 100, (int) '#');
        boolean boolean8 = spreadsheetDate3.equals((java.lang.Object) (short) 0);
        int int9 = spreadsheetDate3.getDayOfWeek();
        categoryMarker1.setKey((java.lang.Comparable) spreadsheetDate3);
        float float11 = categoryMarker1.getAlpha();
        java.lang.String str12 = categoryMarker1.getLabel();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 1.0f + "'", float11 == 1.0f);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.util.Rotation rotation4 = piePlot3.getDirection();
        org.jfree.chart.plot.Plot plot5 = piePlot3.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = null;
        piePlot3.datasetChanged(datasetChangeEvent6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        piePlot3.drawBackgroundImage(graphics2D8, rectangle2D9);
        java.awt.Paint paint11 = piePlot3.getBaseSectionOutlinePaint();
        java.awt.Paint paint12 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot3.setBaseSectionPaint(paint12);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot3);
        jFreeChart14.setTitle("({0}, {1}) = {3} - {4}");
        org.jfree.chart.title.TextTitle textTitle17 = jFreeChart14.getTitle();
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment19 = textTitle18.getHorizontalAlignment();
        textTitle18.setExpandToFitSpace(true);
        jFreeChart14.removeSubtitle((org.jfree.chart.title.Title) textTitle18);
        org.jfree.chart.title.TextTitle textTitle23 = new org.jfree.chart.title.TextTitle();
        textTitle23.setNotify(false);
        jFreeChart14.removeSubtitle((org.jfree.chart.title.Title) textTitle23);
        java.awt.geom.Rectangle2D rectangle2D27 = textTitle23.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean29 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge28);
        java.awt.geom.Rectangle2D rectangle2D30 = axisSpace0.reserved(rectangle2D27, rectangleEdge28);
        org.junit.Assert.assertNotNull(rotation4);
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(textTitle17);
        org.junit.Assert.assertNotNull(horizontalAlignment19);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(rectangle2D30);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.zoomRange((double) 1.0f, (double) (byte) 10);
        boolean boolean5 = numberAxis1.isPositiveArrowVisible();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator10 = null;
        piePlot9.setToolTipGenerator(pieToolTipGenerator10);
        numberAxis3D7.setPlot((org.jfree.chart.plot.Plot) piePlot9);
        org.jfree.chart.block.ColumnArrangement columnArrangement13 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle();
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot(pieDataset15);
        org.jfree.chart.util.Rotation rotation17 = piePlot16.getDirection();
        org.jfree.chart.plot.Plot plot18 = piePlot16.getParent();
        org.jfree.chart.plot.Plot plot19 = piePlot16.getRootPlot();
        java.awt.Color color20 = java.awt.Color.MAGENTA;
        piePlot16.setOutlinePaint((java.awt.Paint) color20);
        columnArrangement13.add((org.jfree.chart.block.Block) textTitle14, (java.lang.Object) color20);
        piePlot9.setBackgroundPaint((java.awt.Paint) color20);
        org.jfree.data.general.PieDataset pieDataset25 = null;
        org.jfree.chart.plot.PiePlot piePlot26 = new org.jfree.chart.plot.PiePlot(pieDataset25);
        org.jfree.chart.util.Rotation rotation27 = piePlot26.getDirection();
        org.jfree.chart.plot.Plot plot28 = piePlot26.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent29 = null;
        piePlot26.datasetChanged(datasetChangeEvent29);
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        piePlot26.drawBackgroundImage(graphics2D31, rectangle2D32);
        java.awt.Paint paint34 = piePlot26.getBaseSectionOutlinePaint();
        java.awt.Paint paint35 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot26.setBaseSectionPaint(paint35);
        org.jfree.chart.JFreeChart jFreeChart37 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot26);
        jFreeChart37.setTitle("({0}, {1}) = {3} - {4}");
        org.jfree.chart.title.TextTitle textTitle40 = jFreeChart37.getTitle();
        java.awt.Stroke stroke41 = jFreeChart37.getBorderStroke();
        piePlot9.setBaseSectionOutlineStroke(stroke41);
        boolean boolean43 = piePlot9.isSubplot();
        boolean boolean44 = numberAxis1.hasListener((java.util.EventListener) piePlot9);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent45 = null;
        piePlot9.notifyListeners(plotChangeEvent45);
        piePlot9.setLabelGap((double) 3600000L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rotation17);
        org.junit.Assert.assertNull(plot18);
        org.junit.Assert.assertNotNull(plot19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(rotation27);
        org.junit.Assert.assertNull(plot28);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(textTitle40);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.zoomRange(0.0d, 10.0d);
        java.util.Date date5 = dateAxis1.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        dateAxis7.zoomRange(0.0d, 10.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit11 = dateAxis7.getTickUnit();
        dateAxis6.setTickUnit(dateTickUnit11, false, true);
        dateAxis1.setTickUnit(dateTickUnit11, true, true);
        org.jfree.chart.axis.DateTickUnit dateTickUnit18 = dateAxis1.getTickUnit();
        dateAxis0.setTickUnit(dateTickUnit18, true, true);
        org.jfree.chart.axis.Timeline timeline22 = null;
        dateAxis0.setTimeline(timeline22);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(dateTickUnit11);
        org.junit.Assert.assertNotNull(dateTickUnit18);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.util.Rotation rotation4 = piePlot3.getDirection();
        org.jfree.chart.plot.Plot plot5 = piePlot3.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = null;
        piePlot3.datasetChanged(datasetChangeEvent6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        piePlot3.drawBackgroundImage(graphics2D8, rectangle2D9);
        java.awt.Paint paint11 = piePlot3.getBaseSectionOutlinePaint();
        java.awt.Paint paint12 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot3.setBaseSectionPaint(paint12);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot3);
        jFreeChart14.setTitle("({0}, {1}) = {3} - {4}");
        org.jfree.chart.title.TextTitle textTitle17 = jFreeChart14.getTitle();
        java.awt.Stroke stroke18 = jFreeChart14.getBorderStroke();
        jFreeChart14.setAntiAlias(true);
        org.jfree.chart.ui.Library library25 = new org.jfree.chart.ui.Library("hi!", "hi!", "hi!", "");
        java.awt.Paint paint26 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        boolean boolean27 = library25.equals((java.lang.Object) paint26);
        jFreeChart14.setBorderPaint(paint26);
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        jFreeChart14.setBorderPaint((java.awt.Paint) color29);
        org.jfree.data.general.PieDataset pieDataset31 = null;
        org.jfree.chart.plot.PiePlot piePlot32 = new org.jfree.chart.plot.PiePlot(pieDataset31);
        org.jfree.chart.util.Rotation rotation33 = piePlot32.getDirection();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator34 = piePlot32.getURLGenerator();
        piePlot32.setMaximumLabelWidth((double) (short) 100);
        org.jfree.chart.axis.NumberAxis numberAxis38 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean39 = numberAxis38.getAutoRangeStickyZero();
        java.awt.Stroke stroke40 = numberAxis38.getAxisLineStroke();
        piePlot32.setOutlineStroke(stroke40);
        org.jfree.chart.plot.ValueMarker valueMarker42 = new org.jfree.chart.plot.ValueMarker((double) 0.5f, (java.awt.Paint) color29, stroke40);
        valueMarker42.setValue((double) 1577865599999L);
        org.junit.Assert.assertNotNull(rotation4);
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(textTitle17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(rotation33);
        org.junit.Assert.assertNull(pieURLGenerator34);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(stroke40);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list1 = defaultStatisticalCategoryDataset0.getColumnKeys();
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        java.util.List list3 = defaultStatisticalCategoryDataset0.getRowKeys();
        org.jfree.data.general.PieDataset pieDataset5 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, (java.lang.Comparable) (short) 10);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.next();
        org.jfree.data.general.PieDataset pieDataset8 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, (java.lang.Comparable) regularTimePeriod7);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0.0d + "'", number2.equals(0.0d));
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNotNull(pieDataset5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(pieDataset8);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        org.jfree.chart.entity.EntityCollection entityCollection0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo(entityCollection0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = chartRenderingInfo1.getPlotInfo();
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = null;
        barRenderer7.setBaseToolTipGenerator(categoryToolTipGenerator8, false);
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        org.jfree.chart.util.Rotation rotation14 = piePlot13.getDirection();
        org.jfree.chart.plot.Plot plot15 = piePlot13.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent16 = null;
        piePlot13.datasetChanged(datasetChangeEvent16);
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        piePlot13.drawBackgroundImage(graphics2D18, rectangle2D19);
        java.awt.Paint paint21 = piePlot13.getBaseSectionOutlinePaint();
        java.awt.Paint paint22 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot13.setBaseSectionPaint(paint22);
        barRenderer7.setSeriesItemLabelPaint((int) (byte) 0, paint22);
        java.awt.Paint paint26 = barRenderer7.lookupSeriesPaint(0);
        org.jfree.chart.block.BlockBorder blockBorder27 = new org.jfree.chart.block.BlockBorder((double) 100.0f, (double) 100.0f, (double) 'a', 0.0d, paint26);
        boolean boolean28 = chartRenderingInfo1.equals((java.lang.Object) paint26);
        org.junit.Assert.assertNotNull(plotRenderingInfo2);
        org.junit.Assert.assertNotNull(rotation14);
        org.junit.Assert.assertNull(plot15);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, 0.0d);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange4, (double) '#');
        numberAxis2.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        boolean boolean10 = numberAxis2.isNegativeArrowVisible();
        boolean boolean11 = numberAxis2.isTickMarksVisible();
        java.lang.String str12 = numberAxis2.getLabel();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean15 = numberAxis3D14.isInverted();
        org.jfree.data.time.DateRange dateRange16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis3D14.setRangeWithMargins((org.jfree.data.Range) dateRange16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, xYItemRenderer18);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray20 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot19.setRenderers(xYItemRendererArray20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        xYPlot19.zoomRangeAxes((double) (-1L), plotRenderingInfo23, point2D24);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        xYPlot19.setDataset(xYDataset26);
        xYPlot19.configureDomainAxes();
        org.jfree.chart.axis.AxisSpace axisSpace29 = new org.jfree.chart.axis.AxisSpace();
        double double30 = axisSpace29.getRight();
        xYPlot19.setFixedDomainAxisSpace(axisSpace29);
        double double32 = axisSpace29.getTop();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateRange16);
        org.junit.Assert.assertNotNull(xYItemRendererArray20);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        org.jfree.chart.renderer.category.AreaRenderer areaRenderer0 = new org.jfree.chart.renderer.category.AreaRenderer();
        java.awt.Paint paint2 = areaRenderer0.getSeriesItemLabelPaint((-1));
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = null;
        areaRenderer0.setSeriesItemLabelGenerator((int) '4', categoryItemLabelGenerator4, false);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator8 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("({0}, {1}) = {2}");
        areaRenderer0.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator8);
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange14 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange14, 0.0d);
        org.jfree.data.Range range18 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange14, (double) '#');
        numberAxis12.setDefaultAutoRange((org.jfree.data.Range) dateRange14);
        boolean boolean20 = numberAxis12.isNegativeArrowVisible();
        boolean boolean21 = numberAxis12.isTickMarksVisible();
        java.lang.String str22 = numberAxis12.getLabel();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D24 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean25 = numberAxis3D24.isInverted();
        org.jfree.data.time.DateRange dateRange26 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis3D24.setRangeWithMargins((org.jfree.data.Range) dateRange26);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) numberAxis12, (org.jfree.chart.axis.ValueAxis) numberAxis3D24, xYItemRenderer28);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray30 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot29.setRenderers(xYItemRendererArray30);
        int int32 = xYPlot29.getSeriesCount();
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double36 = numberAxis35.getFixedAutoRange();
        java.text.NumberFormat numberFormat37 = numberAxis35.getNumberFormatOverride();
        java.awt.Paint paint38 = numberAxis35.getAxisLinePaint();
        java.lang.String str39 = numberAxis35.getLabelToolTip();
        xYPlot29.setDomainAxis((int) '#', (org.jfree.chart.axis.ValueAxis) numberAxis35, true);
        java.awt.Paint paint42 = xYPlot29.getRangeZeroBaselinePaint();
        java.awt.Stroke stroke43 = xYPlot29.getRangeCrosshairStroke();
        areaRenderer0.setBaseOutlineStroke(stroke43);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator46 = null;
        areaRenderer0.setSeriesItemLabelGenerator((int) (short) 10, categoryItemLabelGenerator46);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator48 = areaRenderer0.getBaseItemLabelGenerator();
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(dateRange14);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "hi!" + "'", str22.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dateRange26);
        org.junit.Assert.assertNotNull(xYItemRendererArray30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNull(numberFormat37);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNull(categoryItemLabelGenerator48);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "({0}, {1}) = {3} - {4}", "", image3, "hi!", "hi!", "({0}, {1}) = {3} - {4}");
        projectInfo7.setInfo("RectangleEdge.LEFT");
        projectInfo7.setVersion("ChartChangeEventType.GENERAL");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D13 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator16 = null;
        piePlot15.setToolTipGenerator(pieToolTipGenerator16);
        numberAxis3D13.setPlot((org.jfree.chart.plot.Plot) piePlot15);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str22 = numberAxis21.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange23 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint25 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange23, 0.0d);
        org.jfree.data.Range range27 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange23, (double) '#');
        numberAxis21.setDefaultAutoRange((org.jfree.data.Range) dateRange23);
        boolean boolean29 = numberAxis21.isNegativeArrowVisible();
        boolean boolean30 = numberAxis21.isTickMarksVisible();
        java.lang.Object obj31 = numberAxis21.clone();
        numberAxis21.setAutoRangeIncludesZero(true);
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str36 = numberAxis35.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange37 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint39 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange37, 0.0d);
        org.jfree.data.Range range41 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange37, (double) '#');
        numberAxis35.setDefaultAutoRange((org.jfree.data.Range) dateRange37);
        boolean boolean43 = numberAxis35.isNegativeArrowVisible();
        boolean boolean44 = numberAxis35.isTickMarksVisible();
        java.lang.Object obj45 = numberAxis35.clone();
        java.awt.Font font50 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand51 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis35, (double) 11, 0.0d, (double) 'a', (double) 100, font50);
        numberAxis21.setTickLabelFont(font50);
        org.jfree.data.general.PieDataset pieDataset53 = null;
        org.jfree.chart.plot.PiePlot piePlot54 = new org.jfree.chart.plot.PiePlot(pieDataset53);
        org.jfree.chart.util.Rotation rotation55 = piePlot54.getDirection();
        org.jfree.chart.plot.Plot plot56 = piePlot54.getParent();
        org.jfree.chart.plot.Plot plot57 = piePlot54.getRootPlot();
        org.jfree.chart.JFreeChart jFreeChart59 = new org.jfree.chart.JFreeChart("PlotOrientation.VERTICAL", font50, (org.jfree.chart.plot.Plot) piePlot54, false);
        piePlot15.setNoDataMessageFont(font50);
        boolean boolean61 = projectInfo7.equals((java.lang.Object) piePlot15);
        org.jfree.chart.util.Rotation rotation62 = piePlot15.getDirection();
        piePlot15.setOutlineVisible(true);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNotNull(dateRange23);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertNotNull(dateRange37);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(obj45);
        org.junit.Assert.assertNotNull(font50);
        org.junit.Assert.assertNotNull(rotation55);
        org.junit.Assert.assertNull(plot56);
        org.junit.Assert.assertNotNull(plot57);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(rotation62);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list1 = defaultStatisticalCategoryDataset0.getColumnKeys();
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getLastMillisecond();
        org.jfree.data.gantt.Task task9 = new org.jfree.data.gantt.Task("AxisLocation.TOP_OR_LEFT", (org.jfree.data.time.TimePeriod) year7);
        defaultStatisticalCategoryDataset0.add((double) 10, (double) 10, (java.lang.Comparable) 12.0d, (java.lang.Comparable) "AxisLocation.TOP_OR_LEFT");
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        dateAxis11.zoomRange(0.0d, 10.0d);
        java.util.Date date15 = dateAxis11.getMinimumDate();
        try {
            org.jfree.data.general.PieDataset pieDataset16 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, (java.lang.Comparable) date15);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0.0d + "'", number2.equals(0.0d));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertNotNull(date15);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Color color1 = java.awt.Color.blue;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.color.ColorSpace colorSpace3 = color2.getColorSpace();
        float[] floatArray4 = null;
        float[] floatArray5 = color1.getComponents(colorSpace3, floatArray4);
        float[] floatArray12 = new float[] { 3, (byte) -1, 10L };
        float[] floatArray13 = java.awt.Color.RGBtoHSB((int) (short) -1, 2, (int) (short) -1, floatArray12);
        try {
            float[] floatArray14 = color0.getComponents(colorSpace3, floatArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(colorSpace3);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getFixedAutoRange();
        java.text.NumberFormat numberFormat4 = numberAxis2.getNumberFormatOverride();
        boolean boolean5 = numberAxis2.isVerticalTickLabels();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, polarItemRenderer6);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.util.Rotation rotation10 = piePlot9.getDirection();
        org.jfree.chart.plot.Plot plot11 = piePlot9.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = null;
        piePlot9.datasetChanged(datasetChangeEvent12);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        piePlot9.drawBackgroundImage(graphics2D14, rectangle2D15);
        java.awt.Paint paint17 = piePlot9.getBaseSectionOutlinePaint();
        java.awt.Paint paint18 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot9.setBaseSectionPaint(paint18);
        polarPlot7.setAngleGridlinePaint(paint18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        polarPlot7.zoomRangeAxes((double) 1577865599999L, 0.0d, plotRenderingInfo23, point2D24);
        org.jfree.chart.axis.ValueAxis valueAxis26 = polarPlot7.getAxis();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNull(numberFormat4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rotation10);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(valueAxis26);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.zoomRange(0.0d, 10.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis0.setTickMarkPosition(dateTickMarkPosition4);
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = dateAxis0.getTickUnit();
        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
        org.junit.Assert.assertNotNull(dateTickUnit6);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        java.lang.Number number1 = null;
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection8 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list9 = taskSeriesCollection8.getRowKeys();
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem10 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 0.2d, number1, (java.lang.Number) (-2208960000000L), (java.lang.Number) 100.0f, (java.lang.Number) 2.0f, (java.lang.Number) 1.0d, (java.lang.Number) 10, (java.lang.Number) 10.0d, list9);
        java.util.Collection collection11 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list9);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(collection11);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, 0.0d);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange4, (double) '#');
        numberAxis2.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        boolean boolean10 = numberAxis2.isNegativeArrowVisible();
        boolean boolean11 = numberAxis2.isTickMarksVisible();
        java.lang.String str12 = numberAxis2.getLabel();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean15 = numberAxis3D14.isInverted();
        org.jfree.data.time.DateRange dateRange16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis3D14.setRangeWithMargins((org.jfree.data.Range) dateRange16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, xYItemRenderer18);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str23 = numberAxis22.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange24 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange24, 0.0d);
        org.jfree.data.Range range28 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange24, (double) '#');
        numberAxis22.setDefaultAutoRange((org.jfree.data.Range) dateRange24);
        boolean boolean30 = numberAxis22.isNegativeArrowVisible();
        boolean boolean31 = numberAxis22.isTickMarksVisible();
        numberAxis22.setFixedAutoRange((double) 1);
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str36 = numberAxis35.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange37 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint39 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange37, 0.0d);
        org.jfree.data.Range range41 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange37, (double) '#');
        numberAxis35.setDefaultAutoRange((org.jfree.data.Range) dateRange37);
        boolean boolean43 = numberAxis35.isNegativeArrowVisible();
        boolean boolean44 = numberAxis35.isTickMarksVisible();
        java.lang.Object obj45 = numberAxis35.clone();
        java.awt.Font font50 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand51 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis35, (double) 11, 0.0d, (double) 'a', (double) 100, font50);
        java.awt.Graphics2D graphics2D52 = null;
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        markerAxisBand51.draw(graphics2D52, rectangle2D53, rectangle2D54, (double) 12, (double) 12);
        numberAxis22.setMarkerBand(markerAxisBand51);
        xYPlot19.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) numberAxis22);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder60 = xYPlot19.getSeriesRenderingOrder();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer61 = null;
        xYPlot19.setRenderer(xYItemRenderer61);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent63 = null;
        xYPlot19.datasetChanged(datasetChangeEvent63);
        org.jfree.chart.axis.AxisLocation axisLocation66 = xYPlot19.getDomainAxisLocation((int) '4');
        org.jfree.chart.util.Layer layer68 = null;
        java.util.Collection collection69 = xYPlot19.getDomainMarkers((int) (short) 100, layer68);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateRange16);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(dateRange24);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertNotNull(dateRange37);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(obj45);
        org.junit.Assert.assertNotNull(font50);
        org.junit.Assert.assertNotNull(seriesRenderingOrder60);
        org.junit.Assert.assertNotNull(axisLocation66);
        org.junit.Assert.assertNull(collection69);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = piePlot1.getDirection();
        org.jfree.chart.plot.Plot plot3 = piePlot1.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        piePlot1.datasetChanged(datasetChangeEvent4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        piePlot1.drawBackgroundImage(graphics2D6, rectangle2D7);
        boolean boolean9 = piePlot1.getSectionOutlinesVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        piePlot1.setInsets(rectangleInsets10, true);
        java.awt.Paint paint13 = piePlot1.getNoDataMessagePaint();
        boolean boolean14 = piePlot1.getIgnoreZeroValues();
        org.junit.Assert.assertNotNull(rotation2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, 0.0d);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange4, (double) '#');
        numberAxis2.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        boolean boolean10 = numberAxis2.isNegativeArrowVisible();
        boolean boolean11 = numberAxis2.isTickMarksVisible();
        java.lang.String str12 = numberAxis2.getLabel();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean15 = numberAxis3D14.isInverted();
        org.jfree.data.time.DateRange dateRange16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis3D14.setRangeWithMargins((org.jfree.data.Range) dateRange16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, xYItemRenderer18);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str23 = numberAxis22.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange24 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange24, 0.0d);
        org.jfree.data.Range range28 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange24, (double) '#');
        numberAxis22.setDefaultAutoRange((org.jfree.data.Range) dateRange24);
        boolean boolean30 = numberAxis22.isNegativeArrowVisible();
        boolean boolean31 = numberAxis22.isTickMarksVisible();
        numberAxis22.setFixedAutoRange((double) 1);
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str36 = numberAxis35.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange37 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint39 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange37, 0.0d);
        org.jfree.data.Range range41 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange37, (double) '#');
        numberAxis35.setDefaultAutoRange((org.jfree.data.Range) dateRange37);
        boolean boolean43 = numberAxis35.isNegativeArrowVisible();
        boolean boolean44 = numberAxis35.isTickMarksVisible();
        java.lang.Object obj45 = numberAxis35.clone();
        java.awt.Font font50 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand51 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis35, (double) 11, 0.0d, (double) 'a', (double) 100, font50);
        java.awt.Graphics2D graphics2D52 = null;
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        markerAxisBand51.draw(graphics2D52, rectangle2D53, rectangle2D54, (double) 12, (double) 12);
        numberAxis22.setMarkerBand(markerAxisBand51);
        xYPlot19.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) numberAxis22);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder60 = xYPlot19.getSeriesRenderingOrder();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer61 = null;
        xYPlot19.setRenderer(xYItemRenderer61);
        xYPlot19.clearDomainMarkers();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent64 = null;
        xYPlot19.datasetChanged(datasetChangeEvent64);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier66 = xYPlot19.getDrawingSupplier();
        org.jfree.chart.axis.AxisLocation axisLocation68 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        java.lang.Object obj69 = null;
        boolean boolean70 = axisLocation68.equals(obj69);
        java.awt.Color color71 = java.awt.Color.CYAN;
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder72 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        boolean boolean73 = color71.equals((java.lang.Object) datasetRenderingOrder72);
        boolean boolean74 = axisLocation68.equals((java.lang.Object) boolean73);
        xYPlot19.setRangeAxisLocation(1969, axisLocation68, false);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateRange16);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(dateRange24);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertNotNull(dateRange37);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(obj45);
        org.junit.Assert.assertNotNull(font50);
        org.junit.Assert.assertNotNull(seriesRenderingOrder60);
        org.junit.Assert.assertNotNull(drawingSupplier66);
        org.junit.Assert.assertNotNull(axisLocation68);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(color71);
        org.junit.Assert.assertNotNull(datasetRenderingOrder72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getFixedAutoRange();
        java.text.NumberFormat numberFormat3 = numberAxis1.getNumberFormatOverride();
        java.awt.Paint paint4 = numberAxis1.getAxisLinePaint();
        java.lang.String str5 = numberAxis1.getLabelToolTip();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = numberAxis1.getLabelInsets();
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.util.Rotation rotation10 = piePlot9.getDirection();
        org.jfree.chart.plot.Plot plot11 = piePlot9.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = null;
        piePlot9.datasetChanged(datasetChangeEvent12);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        piePlot9.drawBackgroundImage(graphics2D14, rectangle2D15);
        java.awt.Paint paint17 = piePlot9.getBaseSectionOutlinePaint();
        java.awt.Paint paint18 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot9.setBaseSectionPaint(paint18);
        java.awt.Color color20 = java.awt.Color.red;
        piePlot9.setNoDataMessagePaint((java.awt.Paint) color20);
        org.jfree.data.general.PieDataset pieDataset22 = null;
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot(pieDataset22);
        org.jfree.chart.util.Rotation rotation24 = piePlot23.getDirection();
        org.jfree.chart.plot.Plot plot25 = piePlot23.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent26 = null;
        piePlot23.datasetChanged(datasetChangeEvent26);
        java.awt.Stroke stroke29 = piePlot23.getSectionOutlineStroke((java.lang.Comparable) (short) 100);
        java.awt.Paint paint30 = piePlot23.getNoDataMessagePaint();
        piePlot9.setLabelBackgroundPaint(paint30);
        org.jfree.chart.renderer.category.BarRenderer barRenderer32 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer32.setMaximumBarWidth(8.0d);
        java.awt.Shape shape41 = null;
        java.awt.Color color43 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Paint paint45 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke46 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape48 = null;
        java.awt.Stroke stroke49 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color50 = java.awt.Color.black;
        org.jfree.chart.LegendItem legendItem51 = new org.jfree.chart.LegendItem("", "hi!", "hi!", "", true, shape41, false, (java.awt.Paint) color43, false, paint45, stroke46, true, shape48, stroke49, (java.awt.Paint) color50);
        barRenderer32.setSeriesStroke(2, stroke49);
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer53 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        boolean boolean54 = boxAndWhiskerRenderer53.getBaseItemLabelsVisible();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer56 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.LegendItem legendItem59 = stackedAreaRenderer56.getLegendItem((int) 'a', 0);
        java.awt.Shape shape61 = null;
        stackedAreaRenderer56.setSeriesShape((int) '4', shape61, true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator64 = null;
        stackedAreaRenderer56.setBaseURLGenerator(categoryURLGenerator64);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition68 = stackedAreaRenderer56.getNegativeItemLabelPosition(100, (int) (short) 0);
        boxAndWhiskerRenderer53.setSeriesPositiveItemLabelPosition((int) '#', itemLabelPosition68);
        org.jfree.chart.axis.NumberAxis numberAxis73 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str74 = numberAxis73.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange75 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint77 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange75, 0.0d);
        org.jfree.data.Range range79 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange75, (double) '#');
        numberAxis73.setDefaultAutoRange((org.jfree.data.Range) dateRange75);
        boolean boolean81 = numberAxis73.isNegativeArrowVisible();
        boolean boolean82 = numberAxis73.isTickMarksVisible();
        java.lang.Object obj83 = numberAxis73.clone();
        java.awt.Font font88 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand89 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis73, (double) 11, 0.0d, (double) 'a', (double) 100, font88);
        java.awt.Paint paint90 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.text.TextBlock textBlock91 = org.jfree.chart.text.TextUtilities.createTextBlock("NO_CHANGE", font88, paint90);
        boxAndWhiskerRenderer53.setSeriesOutlinePaint(3, paint90);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier93 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke94 = defaultDrawingSupplier93.getNextOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker96 = new org.jfree.chart.plot.ValueMarker((double) 10L, paint30, stroke49, paint90, stroke94, (float) 1L);
        numberAxis1.setTickMarkPaint(paint30);
        boolean boolean98 = numberAxis1.isPositiveArrowVisible();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNull(numberFormat3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(rotation10);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(rotation24);
        org.junit.Assert.assertNull(plot25);
        org.junit.Assert.assertNull(stroke29);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNull(legendItem59);
        org.junit.Assert.assertNotNull(itemLabelPosition68);
        org.junit.Assert.assertNull(str74);
        org.junit.Assert.assertNotNull(dateRange75);
        org.junit.Assert.assertNotNull(range79);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
        org.junit.Assert.assertNotNull(obj83);
        org.junit.Assert.assertNotNull(font88);
        org.junit.Assert.assertNotNull(paint90);
        org.junit.Assert.assertNotNull(textBlock91);
        org.junit.Assert.assertNotNull(stroke94);
        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + false + "'", boolean98 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list1 = taskSeriesCollection0.getRowKeys();
        int int3 = taskSeriesCollection0.indexOf((java.lang.Comparable) "({0}, {1}) = {2}");
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double6 = numberAxis5.getFixedAutoRange();
        java.text.NumberFormat numberFormat7 = numberAxis5.getNumberFormatOverride();
        java.awt.Paint paint8 = numberAxis5.getAxisLinePaint();
        java.lang.String str9 = numberAxis5.getLabelToolTip();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit10 = numberAxis5.getTickUnit();
        int int11 = taskSeriesCollection0.indexOf((java.lang.Comparable) numberTickUnit10);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.zoomRange(0.0d, 10.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit16 = dateAxis12.getTickUnit();
        java.text.DateFormat dateFormat19 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit20 = new org.jfree.chart.axis.DateTickUnit(0, 0, dateFormat19);
        dateAxis12.setTickUnit(dateTickUnit20);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition22 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis12.setTickMarkPosition(dateTickMarkPosition22);
        java.util.Date date24 = dateAxis12.getMinimumDate();
        try {
            java.lang.Number number26 = taskSeriesCollection0.getValue((java.lang.Comparable) date24, (java.lang.Comparable) "HorizontalAlignment.CENTER");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(numberTickUnit10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(dateTickUnit16);
        org.junit.Assert.assertNotNull(dateTickMarkPosition22);
        org.junit.Assert.assertNotNull(date24);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, 0.0d);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange4, (double) '#');
        numberAxis2.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        boolean boolean10 = numberAxis2.isNegativeArrowVisible();
        boolean boolean11 = numberAxis2.isTickMarksVisible();
        java.lang.String str12 = numberAxis2.getLabel();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean15 = numberAxis3D14.isInverted();
        org.jfree.data.time.DateRange dateRange16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis3D14.setRangeWithMargins((org.jfree.data.Range) dateRange16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, xYItemRenderer18);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray20 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot19.setRenderers(xYItemRendererArray20);
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        xYPlot19.setDataset((int) (byte) 1, xYDataset23);
        org.jfree.chart.LegendItemCollection legendItemCollection25 = xYPlot19.getLegendItems();
        org.jfree.chart.axis.AxisLocation axisLocation26 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot19.setDomainAxisLocation(axisLocation26);
        xYPlot19.clearDomainMarkers();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateRange16);
        org.junit.Assert.assertNotNull(xYItemRendererArray20);
        org.junit.Assert.assertNotNull(legendItemCollection25);
        org.junit.Assert.assertNotNull(axisLocation26);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange3, 0.0d);
        org.jfree.data.Range range7 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange3, (double) '#');
        numberAxis1.setDefaultAutoRange((org.jfree.data.Range) dateRange3);
        boolean boolean9 = numberAxis1.isNegativeArrowVisible();
        boolean boolean10 = numberAxis1.isTickMarksVisible();
        org.jfree.chart.plot.Plot plot11 = null;
        numberAxis1.setPlot(plot11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        org.jfree.chart.util.Rotation rotation15 = piePlot14.getDirection();
        org.jfree.chart.plot.Plot plot16 = piePlot14.getParent();
        org.jfree.chart.plot.Plot plot17 = piePlot14.getRootPlot();
        java.awt.Color color18 = java.awt.Color.MAGENTA;
        piePlot14.setOutlinePaint((java.awt.Paint) color18);
        int int20 = piePlot14.getBackgroundImageAlignment();
        java.awt.Paint paint21 = piePlot14.getOutlinePaint();
        boolean boolean22 = numberAxis1.hasListener((java.util.EventListener) piePlot14);
        java.awt.Paint paint24 = null;
        piePlot14.setSectionPaint((java.lang.Comparable) (byte) 0, paint24);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(dateRange3);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(rotation15);
        org.junit.Assert.assertNull(plot16);
        org.junit.Assert.assertNotNull(plot17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 15 + "'", int20 == 15);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        java.lang.String[] strArray2 = new java.lang.String[] { "SerialDate.weekInMonthToString(): invalid code.", "VerticalAlignment.TOP" };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (short) 1, 100.0f, 2, (short) -1, (-1.0f) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { (short) 1, 100.0f, 2, (short) -1, (-1.0f) };
        java.lang.Number[][] numberArray17 = new java.lang.Number[][] { numberArray10, numberArray16 };
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray17);
        java.lang.Number[][] numberArray19 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset20 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray2, numberArray17, numberArray19);
        java.util.List list21 = defaultIntervalCategoryDataset20.getRowKeys();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(categoryDataset18);
        org.junit.Assert.assertNotNull(list21);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, 0.0d);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange4, (double) '#');
        numberAxis2.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        boolean boolean10 = numberAxis2.isNegativeArrowVisible();
        boolean boolean11 = numberAxis2.isTickMarksVisible();
        java.lang.String str12 = numberAxis2.getLabel();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean15 = numberAxis3D14.isInverted();
        org.jfree.data.time.DateRange dateRange16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis3D14.setRangeWithMargins((org.jfree.data.Range) dateRange16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, xYItemRenderer18);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray20 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot19.setRenderers(xYItemRendererArray20);
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        xYPlot19.setDataset((int) (byte) 1, xYDataset23);
        org.jfree.chart.JFreeChart jFreeChart25 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot19);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateRange16);
        org.junit.Assert.assertNotNull(xYItemRendererArray20);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator2 = null;
        piePlot1.setToolTipGenerator(pieToolTipGenerator2);
        org.jfree.chart.LegendItemCollection legendItemCollection4 = piePlot1.getLegendItems();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double7 = rectangleInsets5.calculateBottomOutset((double) (-1L));
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.TOP;
        boolean boolean9 = rectangleInsets5.equals((java.lang.Object) rectangleAnchor8);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor11 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        boolean boolean13 = textAnchor11.equals((java.lang.Object) 'a');
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType15 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition17 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor8, textBlockAnchor10, textAnchor11, (double) (-2208960000000L), categoryLabelWidthType15, (float) 3);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor18 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.text.TextAnchor textAnchor23 = null;
        org.jfree.chart.text.TextAnchor textAnchor25 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        java.awt.Shape shape26 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D20, (float) 1, (float) 0, textAnchor23, (double) 100L, textAnchor25);
        java.lang.String str27 = textAnchor25.toString();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType29 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition31 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor8, textBlockAnchor18, textAnchor25, 0.0d, categoryLabelWidthType29, (float) (short) 100);
        org.jfree.chart.text.TextAnchor textAnchor32 = categoryLabelPosition31.getRotationAnchor();
        boolean boolean33 = legendItemCollection4.equals((java.lang.Object) categoryLabelPosition31);
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType34 = org.jfree.chart.renderer.AreaRendererEndType.LEVEL;
        boolean boolean35 = legendItemCollection4.equals((java.lang.Object) areaRendererEndType34);
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
        org.junit.Assert.assertNotNull(textAnchor11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(categoryLabelWidthType15);
        org.junit.Assert.assertNotNull(textBlockAnchor18);
        org.junit.Assert.assertNotNull(textAnchor25);
        org.junit.Assert.assertNull(shape26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "TextAnchor.CENTER_RIGHT" + "'", str27.equals("TextAnchor.CENTER_RIGHT"));
        org.junit.Assert.assertNotNull(categoryLabelWidthType29);
        org.junit.Assert.assertNotNull(textAnchor32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(areaRendererEndType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.util.Rotation rotation3 = piePlot2.getDirection();
        org.jfree.chart.plot.Plot plot4 = piePlot2.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        piePlot2.datasetChanged(datasetChangeEvent5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        piePlot2.drawBackgroundImage(graphics2D7, rectangle2D8);
        java.awt.Paint paint10 = piePlot2.getBaseSectionOutlinePaint();
        java.awt.Paint paint11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot2.setBaseSectionPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.event.ChartProgressListener chartProgressListener14 = null;
        jFreeChart13.removeProgressListener(chartProgressListener14);
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setMaximumBarWidth(8.0d);
        java.awt.Shape shape9 = null;
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape16 = null;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color18 = java.awt.Color.black;
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("", "hi!", "hi!", "", true, shape9, false, (java.awt.Paint) color11, false, paint13, stroke14, true, shape16, stroke17, (java.awt.Paint) color18);
        barRenderer0.setSeriesStroke(2, stroke17);
        double double21 = barRenderer0.getItemLabelAnchorOffset();
        barRenderer0.setBaseSeriesVisible(false, false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent25 = null;
        barRenderer0.notifyListeners(rendererChangeEvent25);
        java.awt.Paint paint28 = barRenderer0.lookupSeriesPaint(6);
        java.lang.Boolean boolean30 = barRenderer0.getSeriesItemLabelsVisible(0);
        double double31 = barRenderer0.getItemMargin();
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 2.0d + "'", double21 == 2.0d);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNull(boolean30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.2d + "'", double31 == 0.2d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        java.awt.Paint paint0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = null;
        ganttRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator1, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = ganttRenderer0.getLegendItemURLGenerator();
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer1 = new org.jfree.chart.text.G2TextMeasurer(graphics2D0);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = lineAndShapeRenderer0.getToolTipGenerator(2, 1);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        org.jfree.chart.util.Rotation rotation6 = piePlot5.getDirection();
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        piePlot5.removeChangeListener(plotChangeListener7);
        piePlot5.setLabelLinksVisible(false);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.color.ColorSpace colorSpace12 = color11.getColorSpace();
        piePlot5.setLabelLinkPaint((java.awt.Paint) color11);
        lineAndShapeRenderer0.setBaseFillPaint((java.awt.Paint) color11);
        lineAndShapeRenderer0.setDrawOutlines(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer17 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator18 = barRenderer17.getBaseToolTipGenerator();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator20 = null;
        barRenderer17.setSeriesURLGenerator(0, categoryURLGenerator20, false);
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator24 = new org.jfree.chart.urls.StandardCategoryURLGenerator("RectangleEdge.LEFT");
        barRenderer17.setBaseURLGenerator((org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator24);
        lineAndShapeRenderer0.setBaseURLGenerator((org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator24);
        org.junit.Assert.assertNull(categoryToolTipGenerator3);
        org.junit.Assert.assertNotNull(rotation6);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(colorSpace12);
        org.junit.Assert.assertNull(categoryToolTipGenerator18);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.text.TextLine textLine2 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.text.TextFragment textFragment3 = textLine2.getFirstTextFragment();
        org.jfree.chart.text.TextFragment textFragment4 = textLine2.getFirstTextFragment();
        boolean boolean5 = axisLocation0.equals((java.lang.Object) textFragment4);
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(textFragment3);
        org.junit.Assert.assertNotNull(textFragment4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 2, (float) 4);
        org.jfree.chart.entity.ChartEntity chartEntity4 = new org.jfree.chart.entity.ChartEntity(shape2, "");
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity7 = new org.jfree.chart.entity.TickLabelEntity(shape2, "RectangleEdge.LEFT", "RectangleEdge.LEFT");
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape2, 1.0E-8d, 0.0f, (float) 100L);
        java.lang.Number[] numberArray20 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray30 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray35 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray40 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray45 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[][] numberArray46 = new java.lang.Number[][] { numberArray20, numberArray25, numberArray30, numberArray35, numberArray40, numberArray45 };
        org.jfree.data.category.CategoryDataset categoryDataset47 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray46);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod50 = new org.jfree.data.time.SimpleTimePeriod((long) 10, (long) 'a');
        java.lang.Comparable comparable51 = null;
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity52 = new org.jfree.chart.entity.CategoryItemEntity(shape11, "({0}, {1}) = {3} - {4}", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", categoryDataset47, (java.lang.Comparable) 10, comparable51);
        org.jfree.chart.axis.DateAxis dateAxis53 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis54 = new org.jfree.chart.axis.DateAxis();
        dateAxis54.zoomRange(0.0d, 10.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit58 = dateAxis54.getTickUnit();
        dateAxis53.setTickUnit(dateTickUnit58, false, true);
        categoryItemEntity52.setRowKey((java.lang.Comparable) dateTickUnit58);
        int int63 = dateTickUnit58.getRollUnit();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertNotNull(dateTickUnit58);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 2 + "'", int63 == 2);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.util.Rotation rotation3 = piePlot2.getDirection();
        org.jfree.chart.plot.Plot plot4 = piePlot2.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        piePlot2.datasetChanged(datasetChangeEvent5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        piePlot2.drawBackgroundImage(graphics2D7, rectangle2D8);
        java.awt.Paint paint10 = piePlot2.getBaseSectionOutlinePaint();
        java.awt.Paint paint11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot2.setBaseSectionPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart13.setTitle("({0}, {1}) = {3} - {4}");
        org.jfree.chart.title.TextTitle textTitle16 = jFreeChart13.getTitle();
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment18 = textTitle17.getHorizontalAlignment();
        textTitle17.setExpandToFitSpace(true);
        jFreeChart13.removeSubtitle((org.jfree.chart.title.Title) textTitle17);
        boolean boolean22 = jFreeChart13.isNotify();
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(textTitle16);
        org.junit.Assert.assertNotNull(horizontalAlignment18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        java.awt.Shape shape5 = null;
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape12 = null;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color14 = java.awt.Color.black;
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("", "hi!", "hi!", "", true, shape5, false, (java.awt.Paint) color7, false, paint9, stroke10, true, shape12, stroke13, (java.awt.Paint) color14);
        int int16 = legendItem15.getDatasetIndex();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer17 = legendItem15.getFillPaintTransformer();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(gradientPaintTransformer17);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.util.Rotation rotation3 = piePlot2.getDirection();
        org.jfree.chart.plot.Plot plot4 = piePlot2.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        piePlot2.datasetChanged(datasetChangeEvent5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        piePlot2.drawBackgroundImage(graphics2D7, rectangle2D8);
        java.awt.Paint paint10 = piePlot2.getBaseSectionOutlinePaint();
        java.awt.Paint paint11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot2.setBaseSectionPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot2);
        boolean boolean14 = jFreeChart13.isBorderVisible();
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment16 = textTitle15.getHorizontalAlignment();
        jFreeChart13.addSubtitle((org.jfree.chart.title.Title) textTitle15);
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double20 = numberAxis19.getFixedAutoRange();
        java.text.NumberFormat numberFormat21 = numberAxis19.getNumberFormatOverride();
        numberAxis19.setAutoTickUnitSelection(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = numberAxis19.getTickLabelInsets();
        textTitle15.setPadding(rectangleInsets24);
        java.lang.Object obj26 = textTitle15.clone();
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment16);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNull(numberFormat21);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(obj26);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setNotify(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double5 = rectangleInsets3.calculateBottomOutset((double) (-1L));
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.TOP;
        boolean boolean7 = rectangleInsets3.equals((java.lang.Object) rectangleAnchor6);
        textTitle0.setPadding(rectangleInsets3);
        java.lang.String str9 = textTitle0.getID();
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        double double0 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_X_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 12.0d + "'", double0 == 12.0d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.zoomRange(0.0d, 10.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis0.getTickUnit();
        java.lang.Object obj5 = dateAxis0.clone();
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator1, false);
        boolean boolean4 = barRenderer0.getBaseCreateEntities();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        barRenderer0.setSeriesStroke((int) (short) 100, stroke6, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = barRenderer0.getBasePositiveItemLabelPosition();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.lang.Object obj1 = shapeList0.clone();
        java.lang.Object obj2 = null;
        boolean boolean3 = shapeList0.equals(obj2);
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray20 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray30 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray35 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[][] numberArray36 = new java.lang.Number[][] { numberArray10, numberArray15, numberArray20, numberArray25, numberArray30, numberArray35 };
        org.jfree.data.category.CategoryDataset categoryDataset37 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray36);
        boolean boolean38 = shapeList0.equals((java.lang.Object) "hi!");
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(numberArray36);
        org.junit.Assert.assertNotNull(categoryDataset37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.util.Rotation rotation4 = piePlot3.getDirection();
        org.jfree.chart.plot.Plot plot5 = piePlot3.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = null;
        piePlot3.datasetChanged(datasetChangeEvent6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        piePlot3.drawBackgroundImage(graphics2D8, rectangle2D9);
        java.awt.Paint paint11 = piePlot3.getBaseSectionOutlinePaint();
        java.awt.Paint paint12 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot3.setBaseSectionPaint(paint12);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot3);
        jFreeChart14.setTitle("({0}, {1}) = {3} - {4}");
        org.jfree.chart.title.TextTitle textTitle17 = jFreeChart14.getTitle();
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment19 = textTitle18.getHorizontalAlignment();
        textTitle18.setExpandToFitSpace(true);
        jFreeChart14.removeSubtitle((org.jfree.chart.title.Title) textTitle18);
        java.awt.Color color23 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        jFreeChart14.setBackgroundPaint((java.awt.Paint) color23);
        java.awt.Color color25 = color23.darker();
        float[] floatArray32 = new float[] { 3, (byte) -1, 10L };
        float[] floatArray33 = java.awt.Color.RGBtoHSB((int) (short) -1, 2, (int) (short) -1, floatArray32);
        float[] floatArray34 = color23.getRGBColorComponents(floatArray33);
        float[] floatArray35 = color0.getRGBColorComponents(floatArray33);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(rotation4);
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(textTitle17);
        org.junit.Assert.assertNotNull(horizontalAlignment19);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertNotNull(floatArray35);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        org.jfree.chart.util.Rotation rotation5 = piePlot4.getDirection();
        org.jfree.chart.plot.Plot plot6 = piePlot4.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        piePlot4.datasetChanged(datasetChangeEvent7);
        java.awt.Stroke stroke9 = null;
        piePlot4.setLabelOutlineStroke(stroke9);
        java.lang.Number[] numberArray17 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray22 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray27 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray37 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray42 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[][] numberArray43 = new java.lang.Number[][] { numberArray17, numberArray22, numberArray27, numberArray32, numberArray37, numberArray42 };
        org.jfree.data.category.CategoryDataset categoryDataset44 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray43);
        org.jfree.data.general.PieDataset pieDataset46 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset44, (int) (short) 1);
        piePlot4.setDataset(pieDataset46);
        org.jfree.data.general.PieDataset pieDataset51 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset46, (java.lang.Comparable) "", 90.0d, (int) (byte) 1);
        double double52 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset46);
        org.jfree.chart.plot.PiePlot piePlot53 = new org.jfree.chart.plot.PiePlot(pieDataset46);
        java.awt.Paint paint54 = piePlot53.getBaseSectionPaint();
        statisticalLineAndShapeRenderer2.setErrorIndicatorPaint(paint54);
        org.jfree.chart.LegendItemCollection legendItemCollection56 = statisticalLineAndShapeRenderer2.getLegendItems();
        org.junit.Assert.assertNotNull(rotation5);
        org.junit.Assert.assertNull(plot6);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray37);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(categoryDataset44);
        org.junit.Assert.assertNotNull(pieDataset46);
        org.junit.Assert.assertNotNull(pieDataset51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNotNull(legendItemCollection56);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setTranslateY((double) 28799999L);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, 0.0d);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange4, (double) '#');
        numberAxis2.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        boolean boolean10 = numberAxis2.isNegativeArrowVisible();
        boolean boolean11 = numberAxis2.isTickMarksVisible();
        java.lang.String str12 = numberAxis2.getLabel();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean15 = numberAxis3D14.isInverted();
        org.jfree.data.time.DateRange dateRange16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis3D14.setRangeWithMargins((org.jfree.data.Range) dateRange16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, xYItemRenderer18);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray20 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot19.setRenderers(xYItemRendererArray20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        xYPlot19.zoomRangeAxes((double) (-1L), plotRenderingInfo23, point2D24);
        xYPlot19.setDomainCrosshairValue(4.0d, true);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateRange16);
        org.junit.Assert.assertNotNull(xYItemRendererArray20);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = piePlot1.getDirection();
        org.jfree.chart.plot.Plot plot3 = piePlot1.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        piePlot1.datasetChanged(datasetChangeEvent4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        piePlot1.drawBackgroundImage(graphics2D6, rectangle2D7);
        boolean boolean9 = piePlot1.getSectionOutlinesVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        piePlot1.setInsets(rectangleInsets10, true);
        piePlot1.setBackgroundAlpha((float) 11);
        org.junit.Assert.assertNotNull(rotation2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(rectangleInsets10);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "({0}, {1}) = {3} - {4}", "", image3, "hi!", "hi!", "({0}, {1}) = {3} - {4}");
        java.awt.Image image8 = null;
        projectInfo7.setLogo(image8);
        projectInfo7.setCopyright("");
        java.awt.Image image15 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo19 = new org.jfree.chart.ui.ProjectInfo("", "({0}, {1}) = {3} - {4}", "", image15, "hi!", "hi!", "({0}, {1}) = {3} - {4}");
        projectInfo19.setInfo("RectangleEdge.LEFT");
        java.awt.Image image22 = projectInfo19.getLogo();
        java.lang.String str23 = projectInfo19.getCopyright();
        projectInfo19.setCopyright("http://www.jfree.org/jfreechart/index.html");
        projectInfo7.addLibrary((org.jfree.chart.ui.Library) projectInfo19);
        org.junit.Assert.assertNull(image22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        java.lang.String[] strArray2 = new java.lang.String[] { "SerialDate.weekInMonthToString(): invalid code.", "VerticalAlignment.TOP" };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (short) 1, 100.0f, 2, (short) -1, (-1.0f) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { (short) 1, 100.0f, 2, (short) -1, (-1.0f) };
        java.lang.Number[][] numberArray17 = new java.lang.Number[][] { numberArray10, numberArray16 };
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray17);
        java.lang.Number[][] numberArray19 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset20 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray2, numberArray17, numberArray19);
        try {
            java.lang.Number number23 = defaultIntervalCategoryDataset20.getValue((int) (short) 0, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset.getValue(): category index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(categoryDataset18);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
        java.lang.Object obj1 = datasetGroup0.clone();
        java.lang.String str2 = datasetGroup0.getID();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "NOID" + "'", str2.equals("NOID"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        java.lang.String[] strArray2 = new java.lang.String[] { "SerialDate.weekInMonthToString(): invalid code.", "VerticalAlignment.TOP" };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (short) 1, 100.0f, 2, (short) -1, (-1.0f) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { (short) 1, 100.0f, 2, (short) -1, (-1.0f) };
        java.lang.Number[][] numberArray17 = new java.lang.Number[][] { numberArray10, numberArray16 };
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray17);
        java.lang.Number[][] numberArray19 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset20 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray2, numberArray17, numberArray19);
        int int21 = defaultIntervalCategoryDataset20.getSeriesCount();
        org.jfree.data.general.PieDataset pieDataset23 = null;
        org.jfree.chart.plot.PiePlot piePlot24 = new org.jfree.chart.plot.PiePlot(pieDataset23);
        org.jfree.chart.util.Rotation rotation25 = piePlot24.getDirection();
        org.jfree.chart.plot.Plot plot26 = piePlot24.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent27 = null;
        piePlot24.datasetChanged(datasetChangeEvent27);
        java.awt.Graphics2D graphics2D29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        piePlot24.drawBackgroundImage(graphics2D29, rectangle2D30);
        java.awt.Paint paint32 = piePlot24.getBaseSectionOutlinePaint();
        java.awt.Paint paint33 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot24.setBaseSectionPaint(paint33);
        org.jfree.chart.JFreeChart jFreeChart35 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot24);
        jFreeChart35.setBackgroundImageAlpha((float) (byte) 10);
        int int38 = jFreeChart35.getBackgroundImageAlignment();
        boolean boolean39 = defaultIntervalCategoryDataset20.hasListener((java.util.EventListener) jFreeChart35);
        try {
            int int41 = defaultIntervalCategoryDataset20.getSeriesIndex((java.lang.Comparable) "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(categoryDataset18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2 + "'", int21 == 2);
        org.junit.Assert.assertNotNull(rotation25);
        org.junit.Assert.assertNull(plot26);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 15 + "'", int38 == 15);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D1.setRenderAsPercentages(true);
        stackedBarRenderer3D1.setRenderAsPercentages(false);
        boolean boolean7 = stackedBarRenderer3D1.equals((java.lang.Object) 100L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        double double1 = axisSpace0.getRight();
        axisSpace0.setLeft((double) 0L);
        boolean boolean5 = axisSpace0.equals((java.lang.Object) 10.0d);
        java.lang.Object obj6 = axisSpace0.clone();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer2 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        boxAndWhiskerRenderer2.setFillBox(true);
        double double5 = boxAndWhiskerRenderer2.getItemMargin();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        org.jfree.chart.util.Rotation rotation9 = piePlot8.getDirection();
        org.jfree.chart.plot.Plot plot10 = piePlot8.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent11 = null;
        piePlot8.datasetChanged(datasetChangeEvent11);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        piePlot8.drawBackgroundImage(graphics2D13, rectangle2D14);
        java.awt.Paint paint16 = piePlot8.getBaseSectionOutlinePaint();
        java.awt.Paint paint17 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot8.setBaseSectionPaint(paint17);
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot8);
        jFreeChart19.setTitle("({0}, {1}) = {3} - {4}");
        org.jfree.chart.title.TextTitle textTitle22 = jFreeChart19.getTitle();
        java.awt.Stroke stroke23 = jFreeChart19.getBorderStroke();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent26 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) double5, jFreeChart19, 2, 15);
        waferMapPlot1.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart19);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent28 = null;
        waferMapPlot1.rendererChanged(rendererChangeEvent28);
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer30 = null;
        waferMapPlot1.setRenderer(waferMapRenderer30);
        java.awt.Graphics2D graphics2D32 = null;
        org.jfree.chart.util.Size2D size2D35 = new org.jfree.chart.util.Size2D((double) 0.0f, (double) 1L);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor38 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Rectangle2D rectangle2D39 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D35, (double) (byte) 100, (double) 10, rectangleAnchor38);
        java.awt.geom.Point2D point2D40 = null;
        org.jfree.chart.plot.PlotState plotState41 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = null;
        waferMapPlot1.draw(graphics2D32, rectangle2D39, point2D40, plotState41, plotRenderingInfo42);
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        try {
            boolean boolean45 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D39, rectangle2D44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertNotNull(rotation9);
        org.junit.Assert.assertNull(plot10);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(textTitle22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(rectangleAnchor38);
        org.junit.Assert.assertNotNull(rectangle2D39);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator1, false);
        boolean boolean4 = barRenderer0.getBaseCreateEntities();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        barRenderer0.setSeriesStroke((int) (short) 100, stroke6, false);
        barRenderer0.setSeriesVisibleInLegend(0, (java.lang.Boolean) false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getFixedAutoRange();
        java.text.NumberFormat numberFormat4 = numberAxis2.getNumberFormatOverride();
        boolean boolean5 = numberAxis2.isVerticalTickLabels();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, polarItemRenderer6);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.util.Rotation rotation10 = piePlot9.getDirection();
        org.jfree.chart.plot.Plot plot11 = piePlot9.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = null;
        piePlot9.datasetChanged(datasetChangeEvent12);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        piePlot9.drawBackgroundImage(graphics2D14, rectangle2D15);
        java.awt.Paint paint17 = piePlot9.getBaseSectionOutlinePaint();
        java.awt.Paint paint18 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot9.setBaseSectionPaint(paint18);
        polarPlot7.setAngleGridlinePaint(paint18);
        boolean boolean21 = polarPlot7.isDomainZoomable();
        org.jfree.chart.LegendItemCollection legendItemCollection22 = polarPlot7.getLegendItems();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNull(numberFormat4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rotation10);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(legendItemCollection22);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, 0.0d);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange4, (double) '#');
        numberAxis2.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        boolean boolean10 = numberAxis2.isNegativeArrowVisible();
        boolean boolean11 = numberAxis2.isTickMarksVisible();
        java.lang.String str12 = numberAxis2.getLabel();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean15 = numberAxis3D14.isInverted();
        org.jfree.data.time.DateRange dateRange16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis3D14.setRangeWithMargins((org.jfree.data.Range) dateRange16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, xYItemRenderer18);
        java.awt.Paint paint20 = xYPlot19.getDomainGridlinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = xYPlot19.getDomainAxisEdge();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateRange16);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(rectangleEdge21);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, 0.0d);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange4, (double) '#');
        numberAxis2.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        boolean boolean10 = numberAxis2.isNegativeArrowVisible();
        boolean boolean11 = numberAxis2.isTickMarksVisible();
        java.lang.String str12 = numberAxis2.getLabel();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean15 = numberAxis3D14.isInverted();
        org.jfree.data.time.DateRange dateRange16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis3D14.setRangeWithMargins((org.jfree.data.Range) dateRange16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, xYItemRenderer18);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray20 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot19.setRenderers(xYItemRendererArray20);
        xYPlot19.clearRangeAxes();
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        org.jfree.chart.plot.CrosshairState crosshairState27 = null;
        boolean boolean28 = xYPlot19.render(graphics2D23, rectangle2D24, (int) (byte) 1, plotRenderingInfo26, crosshairState27);
        org.jfree.data.general.PieDataset pieDataset30 = null;
        org.jfree.chart.plot.PiePlot piePlot31 = new org.jfree.chart.plot.PiePlot(pieDataset30);
        org.jfree.chart.util.Rotation rotation32 = piePlot31.getDirection();
        org.jfree.chart.plot.Plot plot33 = piePlot31.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent34 = null;
        piePlot31.datasetChanged(datasetChangeEvent34);
        java.awt.Graphics2D graphics2D36 = null;
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        piePlot31.drawBackgroundImage(graphics2D36, rectangle2D37);
        java.awt.Paint paint39 = piePlot31.getBaseSectionOutlinePaint();
        java.awt.Paint paint40 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot31.setBaseSectionPaint(paint40);
        org.jfree.chart.JFreeChart jFreeChart42 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot31);
        jFreeChart42.setTitle("({0}, {1}) = {3} - {4}");
        org.jfree.chart.title.TextTitle textTitle45 = jFreeChart42.getTitle();
        java.awt.Stroke stroke46 = jFreeChart42.getBorderStroke();
        jFreeChart42.setAntiAlias(true);
        xYPlot19.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart42);
        org.jfree.chart.event.ChartChangeListener chartChangeListener50 = null;
        try {
            jFreeChart42.removeChangeListener(chartChangeListener50);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateRange16);
        org.junit.Assert.assertNotNull(xYItemRendererArray20);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(rotation32);
        org.junit.Assert.assertNull(plot33);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(textTitle45);
        org.junit.Assert.assertNotNull(stroke46);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.END;
        org.junit.Assert.assertNotNull(categoryAnchor0);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getFixedAutoRange();
        java.text.NumberFormat numberFormat4 = numberAxis2.getNumberFormatOverride();
        boolean boolean5 = numberAxis2.isVerticalTickLabels();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, polarItemRenderer6);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.util.Rotation rotation10 = piePlot9.getDirection();
        org.jfree.chart.plot.Plot plot11 = piePlot9.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = null;
        piePlot9.datasetChanged(datasetChangeEvent12);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        piePlot9.drawBackgroundImage(graphics2D14, rectangle2D15);
        java.awt.Paint paint17 = piePlot9.getBaseSectionOutlinePaint();
        java.awt.Paint paint18 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot9.setBaseSectionPaint(paint18);
        polarPlot7.setAngleGridlinePaint(paint18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        polarPlot7.zoomRangeAxes((double) 1577865599999L, 0.0d, plotRenderingInfo23, point2D24);
        java.awt.Paint paint26 = polarPlot7.getAngleLabelPaint();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNull(numberFormat4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rotation10);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange3, 0.0d);
        org.jfree.data.Range range7 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange3, (double) '#');
        numberAxis1.setDefaultAutoRange((org.jfree.data.Range) dateRange3);
        numberAxis1.setFixedAutoRange((double) (-1.0f));
        java.awt.Shape shape11 = numberAxis1.getLeftArrow();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(dateRange3);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(shape11);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange3, 0.0d);
        org.jfree.data.Range range7 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange3, (double) '#');
        numberAxis1.setDefaultAutoRange((org.jfree.data.Range) dateRange3);
        java.lang.String str9 = dateRange3.toString();
        org.jfree.data.Range range11 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange3, (double) (short) 0);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(dateRange3);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str9.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertNotNull(range11);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = piePlot1.getDirection();
        org.jfree.chart.plot.Plot plot3 = piePlot1.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        piePlot1.datasetChanged(datasetChangeEvent4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        piePlot1.drawBackgroundImage(graphics2D6, rectangle2D7);
        java.awt.Paint paint9 = piePlot1.getBaseSectionOutlinePaint();
        java.awt.Paint paint10 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot1.setBaseSectionPaint(paint10);
        piePlot1.setStartAngle((double) (short) 0);
        piePlot1.setIgnoreZeroValues(false);
        java.awt.Paint paint16 = piePlot1.getNoDataMessagePaint();
        org.junit.Assert.assertNotNull(rotation2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.util.Rotation rotation3 = piePlot2.getDirection();
        org.jfree.chart.plot.Plot plot4 = piePlot2.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        piePlot2.datasetChanged(datasetChangeEvent5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        piePlot2.drawBackgroundImage(graphics2D7, rectangle2D8);
        java.awt.Paint paint10 = piePlot2.getBaseSectionOutlinePaint();
        java.awt.Paint paint11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot2.setBaseSectionPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart13.setTitle("({0}, {1}) = {3} - {4}");
        org.jfree.chart.title.TextTitle textTitle16 = jFreeChart13.getTitle();
        jFreeChart13.fireChartChanged();
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(textTitle16);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("ThreadContext");
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        int int1 = defaultStatisticalCategoryDataset0.getColumnCount();
        java.lang.Comparable comparable2 = null;
        int int3 = defaultStatisticalCategoryDataset0.getRowIndex(comparable2);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        java.awt.Paint paint5 = multiplePiePlot4.getAggregatedItemsPaint();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.getAutoRangeStickyZero();
        org.jfree.chart.axis.TickUnitSource tickUnitSource3 = numberAxis1.getStandardTickUnits();
        numberAxis1.setTickMarkInsideLength((float) 0);
        java.text.NumberFormat numberFormat6 = null;
        numberAxis1.setNumberFormatOverride(numberFormat6);
        org.jfree.chart.util.UnitType unitType8 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets(unitType8, (double) 3, 0.0d, (double) 0.5f, (double) 100.0f);
        numberAxis1.setLabelInsets(rectangleInsets13);
        double double15 = rectangleInsets13.getRight();
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder17 = new org.jfree.chart.block.BlockBorder(rectangleInsets13, (java.awt.Paint) color16);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(tickUnitSource3);
        org.junit.Assert.assertNotNull(unitType8);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 100.0d + "'", double15 == 100.0d);
        org.junit.Assert.assertNotNull(color16);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        java.awt.Shape shape5 = null;
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape12 = null;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color14 = java.awt.Color.black;
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("", "hi!", "hi!", "", true, shape5, false, (java.awt.Paint) color7, false, paint9, stroke10, true, shape12, stroke13, (java.awt.Paint) color14);
        java.lang.Number[] numberArray23 = new java.lang.Number[] { (short) 1, 100.0f, 2, (short) -1, (-1.0f) };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { (short) 1, 100.0f, 2, (short) -1, (-1.0f) };
        java.lang.Number[][] numberArray30 = new java.lang.Number[][] { numberArray23, numberArray29 };
        org.jfree.data.category.CategoryDataset categoryDataset31 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray30);
        legendItem15.setDataset((org.jfree.data.general.Dataset) categoryDataset31);
        boolean boolean33 = legendItem15.isShapeOutlineVisible();
        java.awt.Paint paint34 = legendItem15.getFillPaint();
        legendItem15.setDatasetIndex(3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(categoryDataset31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(paint34);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = piePlot1.getDirection();
        org.jfree.chart.plot.Plot plot3 = piePlot1.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        piePlot1.datasetChanged(datasetChangeEvent4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        piePlot1.drawBackgroundImage(graphics2D6, rectangle2D7);
        java.awt.Paint paint9 = piePlot1.getBaseSectionOutlinePaint();
        java.awt.Paint paint10 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot1.setBaseSectionPaint(paint10);
        boolean boolean12 = piePlot1.getIgnoreZeroValues();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod((long) 10, (long) 'a');
        java.util.Date date16 = simpleTimePeriod15.getEnd();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date16);
        java.util.Date date18 = month17.getStart();
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double21 = numberAxis20.getFixedAutoRange();
        java.awt.Stroke stroke22 = numberAxis20.getTickMarkStroke();
        piePlot1.setSectionOutlineStroke((java.lang.Comparable) month17, stroke22);
        boolean boolean24 = piePlot1.isCircular();
        org.junit.Assert.assertNotNull(rotation2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, 0.0d);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange4, (double) '#');
        numberAxis2.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        boolean boolean10 = numberAxis2.isNegativeArrowVisible();
        boolean boolean11 = numberAxis2.isTickMarksVisible();
        java.lang.Object obj12 = numberAxis2.clone();
        java.awt.Font font17 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand18 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis2, (double) 11, 0.0d, (double) 'a', (double) 100, font17);
        java.awt.Paint paint19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.text.TextBlock textBlock20 = org.jfree.chart.text.TextUtilities.createTextBlock("NO_CHANGE", font17, paint19);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = textBlock20.getLineAlignment();
        org.jfree.chart.text.TextLine textLine24 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.text.TextFragment textFragment25 = textLine24.getFirstTextFragment();
        java.awt.Font font26 = textFragment25.getFont();
        java.awt.Color color27 = java.awt.Color.black;
        textBlock20.addLine("", font26, (java.awt.Paint) color27);
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double34 = rectangleInsets32.calculateBottomOutset((double) (-1L));
        org.jfree.chart.util.RectangleAnchor rectangleAnchor35 = org.jfree.chart.util.RectangleAnchor.TOP;
        boolean boolean36 = rectangleInsets32.equals((java.lang.Object) rectangleAnchor35);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor37 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor38 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        boolean boolean40 = textAnchor38.equals((java.lang.Object) 'a');
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType42 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition44 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor35, textBlockAnchor37, textAnchor38, (double) (-2208960000000L), categoryLabelWidthType42, (float) 3);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor45 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Graphics2D graphics2D47 = null;
        org.jfree.chart.text.TextAnchor textAnchor50 = null;
        org.jfree.chart.text.TextAnchor textAnchor52 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        java.awt.Shape shape53 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D47, (float) 1, (float) 0, textAnchor50, (double) 100L, textAnchor52);
        java.lang.String str54 = textAnchor52.toString();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType56 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition58 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor35, textBlockAnchor45, textAnchor52, 0.0d, categoryLabelWidthType56, (float) (short) 100);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor59 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition60 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor35, textBlockAnchor59);
        try {
            java.awt.Shape shape64 = textBlock20.calculateBounds(graphics2D29, 0.0f, (float) (byte) 0, textBlockAnchor59, 0.0f, (float) (short) 100, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(textBlock20);
        org.junit.Assert.assertNotNull(horizontalAlignment21);
        org.junit.Assert.assertNotNull(textFragment25);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor37);
        org.junit.Assert.assertNotNull(textAnchor38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(categoryLabelWidthType42);
        org.junit.Assert.assertNotNull(textBlockAnchor45);
        org.junit.Assert.assertNotNull(textAnchor52);
        org.junit.Assert.assertNull(shape53);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "TextAnchor.CENTER_RIGHT" + "'", str54.equals("TextAnchor.CENTER_RIGHT"));
        org.junit.Assert.assertNotNull(categoryLabelWidthType56);
        org.junit.Assert.assertNotNull(textBlockAnchor59);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = piePlot1.getDirection();
        org.jfree.chart.plot.Plot plot3 = piePlot1.getParent();
        org.jfree.chart.plot.Plot plot4 = piePlot1.getRootPlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator5 = piePlot1.getLegendLabelGenerator();
        piePlot1.setMaximumLabelWidth((-1.0d));
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator8 = null;
        piePlot1.setLabelGenerator(pieSectionLabelGenerator8);
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer10 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        boxAndWhiskerRenderer10.setAutoPopulateSeriesShape(true);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod((long) 10, (long) 'a');
        java.util.Date date16 = simpleTimePeriod15.getEnd();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date16);
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone18;
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date16, timeZone18);
        boolean boolean21 = boxAndWhiskerRenderer10.equals((java.lang.Object) date16);
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType22 = org.jfree.chart.renderer.AreaRendererEndType.LEVEL;
        float[] floatArray29 = new float[] { 3, (byte) -1, 10L };
        float[] floatArray30 = java.awt.Color.RGBtoHSB((int) (short) -1, 2, (int) (short) -1, floatArray29);
        boolean boolean31 = areaRendererEndType22.equals((java.lang.Object) (short) -1);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D33 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.general.PieDataset pieDataset34 = null;
        org.jfree.chart.plot.PiePlot piePlot35 = new org.jfree.chart.plot.PiePlot(pieDataset34);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator36 = null;
        piePlot35.setToolTipGenerator(pieToolTipGenerator36);
        numberAxis3D33.setPlot((org.jfree.chart.plot.Plot) piePlot35);
        org.jfree.chart.block.ColumnArrangement columnArrangement39 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.title.TextTitle textTitle40 = new org.jfree.chart.title.TextTitle();
        org.jfree.data.general.PieDataset pieDataset41 = null;
        org.jfree.chart.plot.PiePlot piePlot42 = new org.jfree.chart.plot.PiePlot(pieDataset41);
        org.jfree.chart.util.Rotation rotation43 = piePlot42.getDirection();
        org.jfree.chart.plot.Plot plot44 = piePlot42.getParent();
        org.jfree.chart.plot.Plot plot45 = piePlot42.getRootPlot();
        java.awt.Color color46 = java.awt.Color.MAGENTA;
        piePlot42.setOutlinePaint((java.awt.Paint) color46);
        columnArrangement39.add((org.jfree.chart.block.Block) textTitle40, (java.lang.Object) color46);
        piePlot35.setBackgroundPaint((java.awt.Paint) color46);
        org.jfree.data.general.PieDataset pieDataset51 = null;
        org.jfree.chart.plot.PiePlot piePlot52 = new org.jfree.chart.plot.PiePlot(pieDataset51);
        org.jfree.chart.util.Rotation rotation53 = piePlot52.getDirection();
        org.jfree.chart.plot.Plot plot54 = piePlot52.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent55 = null;
        piePlot52.datasetChanged(datasetChangeEvent55);
        java.awt.Graphics2D graphics2D57 = null;
        java.awt.geom.Rectangle2D rectangle2D58 = null;
        piePlot52.drawBackgroundImage(graphics2D57, rectangle2D58);
        java.awt.Paint paint60 = piePlot52.getBaseSectionOutlinePaint();
        java.awt.Paint paint61 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot52.setBaseSectionPaint(paint61);
        org.jfree.chart.JFreeChart jFreeChart63 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot52);
        jFreeChart63.setTitle("({0}, {1}) = {3} - {4}");
        org.jfree.chart.title.TextTitle textTitle66 = jFreeChart63.getTitle();
        java.awt.Stroke stroke67 = jFreeChart63.getBorderStroke();
        piePlot35.setBaseSectionOutlineStroke(stroke67);
        boolean boolean69 = areaRendererEndType22.equals((java.lang.Object) stroke67);
        piePlot1.setSectionOutlineStroke((java.lang.Comparable) date16, stroke67);
        org.junit.Assert.assertNotNull(rotation2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(plot4);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator5);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(areaRendererEndType22);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(rotation43);
        org.junit.Assert.assertNull(plot44);
        org.junit.Assert.assertNotNull(plot45);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(rotation53);
        org.junit.Assert.assertNull(plot54);
        org.junit.Assert.assertNotNull(paint60);
        org.junit.Assert.assertNotNull(paint61);
        org.junit.Assert.assertNotNull(textTitle66);
        org.junit.Assert.assertNotNull(stroke67);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list1 = axisCollection0.getAxesAtLeft();
        java.util.List list2 = axisCollection0.getAxesAtLeft();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list1 = taskSeriesCollection0.getRowKeys();
        int int3 = taskSeriesCollection0.indexOf((java.lang.Comparable) "({0}, {1}) = {2}");
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double6 = numberAxis5.getFixedAutoRange();
        java.text.NumberFormat numberFormat7 = numberAxis5.getNumberFormatOverride();
        java.awt.Paint paint8 = numberAxis5.getAxisLinePaint();
        java.lang.String str9 = numberAxis5.getLabelToolTip();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit10 = numberAxis5.getTickUnit();
        int int11 = taskSeriesCollection0.indexOf((java.lang.Comparable) numberTickUnit10);
        int int12 = taskSeriesCollection0.getColumnCount();
        try {
            org.jfree.data.gantt.TaskSeries taskSeries14 = taskSeriesCollection0.getSeries((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(numberTickUnit10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        int int1 = defaultStatisticalCategoryDataset0.getColumnCount();
        java.lang.Comparable comparable2 = null;
        int int3 = defaultStatisticalCategoryDataset0.getRowIndex(comparable2);
        java.lang.Number number4 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        java.lang.Object obj5 = defaultStatisticalCategoryDataset0.clone();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        org.jfree.chart.util.Rotation rotation9 = piePlot8.getDirection();
        org.jfree.chart.plot.Plot plot10 = piePlot8.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent11 = null;
        piePlot8.datasetChanged(datasetChangeEvent11);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        piePlot8.drawBackgroundImage(graphics2D13, rectangle2D14);
        java.awt.Paint paint16 = piePlot8.getBaseSectionOutlinePaint();
        java.awt.Paint paint17 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot8.setBaseSectionPaint(paint17);
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot8);
        jFreeChart19.setTitle("({0}, {1}) = {3} - {4}");
        org.jfree.chart.text.TextLine textLine23 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.text.TextFragment textFragment24 = textLine23.getFirstTextFragment();
        java.awt.Font font25 = textFragment24.getFont();
        boolean boolean26 = jFreeChart19.equals((java.lang.Object) textFragment24);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent27 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) defaultStatisticalCategoryDataset0, jFreeChart19);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertEquals((double) number4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(rotation9);
        org.junit.Assert.assertNull(plot10);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(textFragment24);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator0 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        org.jfree.chart.entity.EntityCollection entityCollection0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo(entityCollection0);
        java.awt.Paint paint3 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        barRenderer4.setBaseToolTipGenerator(categoryToolTipGenerator5, false);
        boolean boolean8 = barRenderer4.getBaseCreateEntities();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        barRenderer4.setSeriesStroke((int) (short) 100, stroke10, false);
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker(0.0d, paint3, stroke10);
        java.awt.Paint paint14 = valueMarker13.getPaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = valueMarker13.getLabelAnchor();
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double18 = numberAxis17.getFixedAutoRange();
        java.text.NumberFormat numberFormat19 = numberAxis17.getNumberFormatOverride();
        java.awt.Paint paint20 = numberAxis17.getAxisLinePaint();
        valueMarker13.setOutlinePaint(paint20);
        boolean boolean22 = chartRenderingInfo1.equals((java.lang.Object) paint20);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNull(numberFormat19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list1 = taskSeriesCollection0.getRowKeys();
        int int3 = taskSeriesCollection0.indexOf((java.lang.Comparable) "({0}, {1}) = {2}");
        int int4 = taskSeriesCollection0.getColumnCount();
        try {
            java.lang.Number number8 = taskSeriesCollection0.getPercentComplete(1, 10, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setDrawOutlines(true);
        boolean boolean3 = lineAndShapeRenderer0.getBaseLinesVisible();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        org.jfree.chart.util.Rotation rotation6 = piePlot5.getDirection();
        org.jfree.chart.plot.Plot plot7 = piePlot5.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        piePlot5.datasetChanged(datasetChangeEvent8);
        java.awt.Stroke stroke11 = piePlot5.getSectionOutlineStroke((java.lang.Comparable) (short) 100);
        java.awt.Paint paint12 = piePlot5.getNoDataMessagePaint();
        lineAndShapeRenderer0.setBasePaint(paint12, false);
        boolean boolean15 = lineAndShapeRenderer0.getBaseShapesFilled();
        java.lang.Object obj16 = null;
        boolean boolean17 = lineAndShapeRenderer0.equals(obj16);
        try {
            lineAndShapeRenderer0.setSeriesLinesVisible((-1), (java.lang.Boolean) false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(rotation6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getHorizontalAlignment();
        java.util.List list10 = null;
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem11 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 1L, (java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.05d, (java.lang.Number) 5, (java.lang.Number) (-1), (java.lang.Number) 100.0d, (java.lang.Number) 0L, list10);
        boolean boolean12 = horizontalAlignment1.equals((java.lang.Object) 1.0f);
        org.jfree.chart.util.VerticalAlignment verticalAlignment13 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement16 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment1, verticalAlignment13, (double) 2, (double) 15);
        org.jfree.chart.util.VerticalAlignment verticalAlignment17 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.FlowArrangement flowArrangement20 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment1, verticalAlignment17, (-399.0d), (double) 1);
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(verticalAlignment13);
        org.junit.Assert.assertNotNull(verticalAlignment17);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = piePlot1.getDirection();
        org.jfree.chart.plot.Plot plot3 = piePlot1.getParent();
        org.jfree.chart.plot.Plot plot4 = piePlot1.getRootPlot();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart(plot4);
        java.lang.Object obj6 = jFreeChart5.getTextAntiAlias();
        org.junit.Assert.assertNotNull(rotation2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(plot4);
        org.junit.Assert.assertNull(obj6);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test265");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        double double2 = stackedBarRenderer3D1.getYOffset();
        boolean boolean3 = stackedBarRenderer3D1.getRenderAsPercentages();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer4.setDrawOutlines(true);
        lineAndShapeRenderer4.setUseFillPaint(true);
        java.lang.Boolean boolean10 = lineAndShapeRenderer4.getSeriesShapesVisible(2);
        lineAndShapeRenderer4.setSeriesVisible((int) ' ', (java.lang.Boolean) false, true);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double18 = numberAxis17.getFixedAutoRange();
        java.text.NumberFormat numberFormat19 = numberAxis17.getNumberFormatOverride();
        boolean boolean20 = numberAxis17.isVerticalTickLabels();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer21 = null;
        org.jfree.chart.plot.PolarPlot polarPlot22 = new org.jfree.chart.plot.PolarPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) numberAxis17, polarItemRenderer21);
        org.jfree.data.general.PieDataset pieDataset23 = null;
        org.jfree.chart.plot.PiePlot piePlot24 = new org.jfree.chart.plot.PiePlot(pieDataset23);
        org.jfree.chart.util.Rotation rotation25 = piePlot24.getDirection();
        org.jfree.chart.plot.Plot plot26 = piePlot24.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent27 = null;
        piePlot24.datasetChanged(datasetChangeEvent27);
        java.awt.Graphics2D graphics2D29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        piePlot24.drawBackgroundImage(graphics2D29, rectangle2D30);
        java.awt.Paint paint32 = piePlot24.getBaseSectionOutlinePaint();
        java.awt.Paint paint33 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot24.setBaseSectionPaint(paint33);
        polarPlot22.setAngleGridlinePaint(paint33);
        boolean boolean36 = lineAndShapeRenderer4.equals((java.lang.Object) polarPlot22);
        org.jfree.chart.plot.PlotOrientation plotOrientation37 = polarPlot22.getOrientation();
        boolean boolean38 = stackedBarRenderer3D1.equals((java.lang.Object) plotOrientation37);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.0d + "'", double2 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(boolean10);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNull(numberFormat19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(rotation25);
        org.junit.Assert.assertNull(plot26);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(plotOrientation37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.util.Rotation rotation3 = piePlot2.getDirection();
        org.jfree.chart.plot.Plot plot4 = piePlot2.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        piePlot2.datasetChanged(datasetChangeEvent5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        piePlot2.drawBackgroundImage(graphics2D7, rectangle2D8);
        java.awt.Paint paint10 = piePlot2.getBaseSectionOutlinePaint();
        java.awt.Paint paint11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot2.setBaseSectionPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart13.setBackgroundImageAlpha((float) (byte) 10);
        org.jfree.chart.event.ChartProgressListener chartProgressListener16 = null;
        jFreeChart13.removeProgressListener(chartProgressListener16);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer18 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean19 = jFreeChart13.equals((java.lang.Object) lineAndShapeRenderer18);
        java.awt.Shape shape20 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        lineAndShapeRenderer18.setBaseShape(shape20, true);
        lineAndShapeRenderer18.setSeriesVisible((int) '4', (java.lang.Boolean) false);
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(shape20);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test267");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState1 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo0);
        categoryItemRendererState1.setBarWidth((double) 23640L);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test268");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        int int1 = defaultStatisticalCategoryDataset0.getColumnCount();
        java.lang.Comparable comparable2 = null;
        int int3 = defaultStatisticalCategoryDataset0.getRowIndex(comparable2);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        java.lang.Comparable comparable5 = multiplePiePlot4.getAggregatedItemsKey();
        java.lang.String str6 = multiplePiePlot4.getPlotType();
        multiplePiePlot4.setAggregatedItemsKey((java.lang.Comparable) 0.25d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + "Other" + "'", comparable5.equals("Other"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Multiple Pie Plot" + "'", str6.equals("Multiple Pie Plot"));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        int int1 = keyedObjects0.getItemCount();
        java.lang.Comparable comparable3 = keyedObjects0.getKey((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNull(comparable3);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        java.util.List list8 = null;
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem9 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 1L, (java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.05d, (java.lang.Number) 5, (java.lang.Number) (-1), (java.lang.Number) 100.0d, (java.lang.Number) 0L, list8);
        java.lang.Number number10 = boxAndWhiskerItem9.getMean();
        java.lang.Number number11 = boxAndWhiskerItem9.getQ1();
        java.lang.Number number12 = boxAndWhiskerItem9.getQ3();
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 1L + "'", number10.equals(1L));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 1L + "'", number11.equals(1L));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 0.05d + "'", number12.equals(0.05d));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, 0.0d);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange4, (double) '#');
        numberAxis2.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        boolean boolean10 = numberAxis2.isNegativeArrowVisible();
        boolean boolean11 = numberAxis2.isTickMarksVisible();
        java.lang.String str12 = numberAxis2.getLabel();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean15 = numberAxis3D14.isInverted();
        org.jfree.data.time.DateRange dateRange16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis3D14.setRangeWithMargins((org.jfree.data.Range) dateRange16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, xYItemRenderer18);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str23 = numberAxis22.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange24 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange24, 0.0d);
        org.jfree.data.Range range28 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange24, (double) '#');
        numberAxis22.setDefaultAutoRange((org.jfree.data.Range) dateRange24);
        boolean boolean30 = numberAxis22.isNegativeArrowVisible();
        boolean boolean31 = numberAxis22.isTickMarksVisible();
        numberAxis22.setFixedAutoRange((double) 1);
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str36 = numberAxis35.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange37 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint39 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange37, 0.0d);
        org.jfree.data.Range range41 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange37, (double) '#');
        numberAxis35.setDefaultAutoRange((org.jfree.data.Range) dateRange37);
        boolean boolean43 = numberAxis35.isNegativeArrowVisible();
        boolean boolean44 = numberAxis35.isTickMarksVisible();
        java.lang.Object obj45 = numberAxis35.clone();
        java.awt.Font font50 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand51 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis35, (double) 11, 0.0d, (double) 'a', (double) 100, font50);
        java.awt.Graphics2D graphics2D52 = null;
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        markerAxisBand51.draw(graphics2D52, rectangle2D53, rectangle2D54, (double) 12, (double) 12);
        numberAxis22.setMarkerBand(markerAxisBand51);
        xYPlot19.setDomainAxis(11, (org.jfree.chart.axis.ValueAxis) numberAxis22);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder60 = xYPlot19.getSeriesRenderingOrder();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer61 = null;
        xYPlot19.setRenderer(xYItemRenderer61);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent63 = null;
        xYPlot19.datasetChanged(datasetChangeEvent63);
        org.jfree.data.xy.XYDataset xYDataset65 = null;
        int int66 = xYPlot19.indexOf(xYDataset65);
        boolean boolean67 = xYPlot19.isDomainCrosshairVisible();
        org.jfree.chart.plot.PlotOrientation plotOrientation68 = xYPlot19.getOrientation();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateRange16);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(dateRange24);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertNotNull(dateRange37);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(obj45);
        org.junit.Assert.assertNotNull(font50);
        org.junit.Assert.assertNotNull(seriesRenderingOrder60);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(plotOrientation68);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, 0.0d);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange4, (double) '#');
        numberAxis2.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        boolean boolean10 = numberAxis2.isNegativeArrowVisible();
        boolean boolean11 = numberAxis2.isTickMarksVisible();
        java.lang.String str12 = numberAxis2.getLabel();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean15 = numberAxis3D14.isInverted();
        org.jfree.data.time.DateRange dateRange16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis3D14.setRangeWithMargins((org.jfree.data.Range) dateRange16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, xYItemRenderer18);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray20 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot19.setRenderers(xYItemRendererArray20);
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        xYPlot19.setDataset((int) (byte) 1, xYDataset23);
        org.jfree.chart.LegendItemCollection legendItemCollection25 = xYPlot19.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis27 = xYPlot19.getDomainAxis((int) 'a');
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateRange16);
        org.junit.Assert.assertNotNull(xYItemRendererArray20);
        org.junit.Assert.assertNotNull(legendItemCollection25);
        org.junit.Assert.assertNull(valueAxis27);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test273");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 11);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape2, "RectangleEdge.LEFT", "NO_CHANGE");
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity8 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) 8.0d, shape2, "({0}, {1}) = {2}", "SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str9 = categoryLabelEntity8.toString();
        java.lang.String str10 = categoryLabelEntity8.toString();
        java.lang.String str11 = categoryLabelEntity8.toString();
        java.lang.Comparable comparable12 = categoryLabelEntity8.getKey();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "CategoryLabelEntity: category=8.0, tooltip=({0}, {1}) = {2}, url=SerialDate.weekInMonthToString(): invalid code." + "'", str9.equals("CategoryLabelEntity: category=8.0, tooltip=({0}, {1}) = {2}, url=SerialDate.weekInMonthToString(): invalid code."));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "CategoryLabelEntity: category=8.0, tooltip=({0}, {1}) = {2}, url=SerialDate.weekInMonthToString(): invalid code." + "'", str10.equals("CategoryLabelEntity: category=8.0, tooltip=({0}, {1}) = {2}, url=SerialDate.weekInMonthToString(): invalid code."));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "CategoryLabelEntity: category=8.0, tooltip=({0}, {1}) = {2}, url=SerialDate.weekInMonthToString(): invalid code." + "'", str11.equals("CategoryLabelEntity: category=8.0, tooltip=({0}, {1}) = {2}, url=SerialDate.weekInMonthToString(): invalid code."));
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + 8.0d + "'", comparable12.equals(8.0d));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test274");
        java.lang.String[] strArray2 = new java.lang.String[] { "SerialDate.weekInMonthToString(): invalid code.", "VerticalAlignment.TOP" };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (short) 1, 100.0f, 2, (short) -1, (-1.0f) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { (short) 1, 100.0f, 2, (short) -1, (-1.0f) };
        java.lang.Number[][] numberArray17 = new java.lang.Number[][] { numberArray10, numberArray16 };
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray17);
        java.lang.Number[][] numberArray19 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset20 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray2, numberArray17, numberArray19);
        int int21 = defaultIntervalCategoryDataset20.getSeriesCount();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.chart.ChartColor chartColor28 = new org.jfree.chart.ChartColor((int) (short) 0, (int) (byte) 100, (int) '#');
        boolean boolean29 = spreadsheetDate24.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate32 = spreadsheetDate24.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate31);
        try {
            defaultIntervalCategoryDataset20.setStartValue((int) (short) 100, (java.lang.Comparable) spreadsheetDate31, (java.lang.Number) 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset.setValue: series outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(categoryDataset18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2 + "'", int21 == 2);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(serialDate32);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setDrawOutlines(true);
        lineAndShapeRenderer0.setUseFillPaint(true);
        java.awt.Paint paint7 = lineAndShapeRenderer0.getItemPaint((int) (short) -1, (int) '4');
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double11 = numberAxis10.getFixedAutoRange();
        java.text.NumberFormat numberFormat12 = numberAxis10.getNumberFormatOverride();
        boolean boolean13 = numberAxis10.isVerticalTickLabels();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer14 = null;
        org.jfree.chart.plot.PolarPlot polarPlot15 = new org.jfree.chart.plot.PolarPlot(xYDataset8, (org.jfree.chart.axis.ValueAxis) numberAxis10, polarItemRenderer14);
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot(pieDataset16);
        org.jfree.chart.util.Rotation rotation18 = piePlot17.getDirection();
        org.jfree.chart.plot.Plot plot19 = piePlot17.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent20 = null;
        piePlot17.datasetChanged(datasetChangeEvent20);
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        piePlot17.drawBackgroundImage(graphics2D22, rectangle2D23);
        java.awt.Paint paint25 = piePlot17.getBaseSectionOutlinePaint();
        java.awt.Paint paint26 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot17.setBaseSectionPaint(paint26);
        polarPlot15.setAngleGridlinePaint(paint26);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D30 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean31 = numberAxis3D30.isTickMarksVisible();
        org.jfree.chart.plot.Plot plot32 = numberAxis3D30.getPlot();
        org.jfree.data.Range range33 = polarPlot15.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D30);
        java.awt.Paint paint34 = null;
        polarPlot15.setAngleGridlinePaint(paint34);
        java.awt.Color color36 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.color.ColorSpace colorSpace37 = color36.getColorSpace();
        polarPlot15.setRadiusGridlinePaint((java.awt.Paint) color36);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color36);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNull(numberFormat12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(rotation18);
        org.junit.Assert.assertNull(plot19);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNull(plot32);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(colorSpace37);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double4 = numberAxis3.getFixedAutoRange();
        java.text.NumberFormat numberFormat5 = numberAxis3.getNumberFormatOverride();
        boolean boolean6 = numberAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3, polarItemRenderer7);
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        org.jfree.chart.util.Rotation rotation11 = piePlot10.getDirection();
        org.jfree.chart.plot.Plot plot12 = piePlot10.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent13 = null;
        piePlot10.datasetChanged(datasetChangeEvent13);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        piePlot10.drawBackgroundImage(graphics2D15, rectangle2D16);
        java.awt.Paint paint18 = piePlot10.getBaseSectionOutlinePaint();
        java.awt.Paint paint19 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot10.setBaseSectionPaint(paint19);
        polarPlot8.setAngleGridlinePaint(paint19);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D23 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean24 = numberAxis3D23.isTickMarksVisible();
        org.jfree.chart.plot.Plot plot25 = numberAxis3D23.getPlot();
        org.jfree.data.Range range26 = polarPlot8.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D23);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        polarPlot8.setDataset(xYDataset27);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D29 = new org.jfree.chart.renderer.category.BarRenderer3D();
        java.awt.Shape shape33 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 2, (float) 4);
        barRenderer3D29.setSeriesShape((int) (short) 1, shape33, false);
        double double36 = barRenderer3D29.getItemLabelAnchorOffset();
        boolean boolean38 = barRenderer3D29.isSeriesVisible(10);
        java.awt.Paint paint39 = barRenderer3D29.getWallPaint();
        polarPlot8.setAngleGridlinePaint(paint39);
        org.jfree.data.xy.XYDataset xYDataset41 = null;
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str44 = numberAxis43.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange45 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint47 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange45, 0.0d);
        org.jfree.data.Range range49 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange45, (double) '#');
        numberAxis43.setDefaultAutoRange((org.jfree.data.Range) dateRange45);
        boolean boolean51 = numberAxis43.isNegativeArrowVisible();
        boolean boolean52 = numberAxis43.isTickMarksVisible();
        java.lang.String str53 = numberAxis43.getLabel();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D55 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean56 = numberAxis3D55.isInverted();
        org.jfree.data.time.DateRange dateRange57 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis3D55.setRangeWithMargins((org.jfree.data.Range) dateRange57);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer59 = null;
        org.jfree.chart.plot.XYPlot xYPlot60 = new org.jfree.chart.plot.XYPlot(xYDataset41, (org.jfree.chart.axis.ValueAxis) numberAxis43, (org.jfree.chart.axis.ValueAxis) numberAxis3D55, xYItemRenderer59);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray61 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot60.setRenderers(xYItemRendererArray61);
        int int63 = xYPlot60.getSeriesCount();
        org.jfree.chart.axis.NumberAxis numberAxis66 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double67 = numberAxis66.getFixedAutoRange();
        java.text.NumberFormat numberFormat68 = numberAxis66.getNumberFormatOverride();
        java.awt.Paint paint69 = numberAxis66.getAxisLinePaint();
        java.lang.String str70 = numberAxis66.getLabelToolTip();
        xYPlot60.setDomainAxis((int) '#', (org.jfree.chart.axis.ValueAxis) numberAxis66, true);
        java.awt.Paint paint73 = xYPlot60.getRangeZeroBaselinePaint();
        java.awt.Stroke stroke74 = xYPlot60.getRangeCrosshairStroke();
        org.jfree.chart.plot.ValueMarker valueMarker75 = new org.jfree.chart.plot.ValueMarker((double) (-1310400001L), paint39, stroke74);
        java.awt.Paint paint76 = valueMarker75.getLabelPaint();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNull(numberFormat5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rotation11);
        org.junit.Assert.assertNull(plot12);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(plot25);
        org.junit.Assert.assertNull(range26);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 2.0d + "'", double36 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertNotNull(dateRange45);
        org.junit.Assert.assertNotNull(range49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "hi!" + "'", str53.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(dateRange57);
        org.junit.Assert.assertNotNull(xYItemRendererArray61);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertNull(numberFormat68);
        org.junit.Assert.assertNotNull(paint69);
        org.junit.Assert.assertNull(str70);
        org.junit.Assert.assertNotNull(paint73);
        org.junit.Assert.assertNotNull(stroke74);
        org.junit.Assert.assertNotNull(paint76);
    }
}

