import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, (float) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_LOWER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.lang.Class class0 = null;
        try {
            boolean boolean1 = org.jfree.chart.util.SerialUtilities.isSerializable(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.util.TimeZone timeZone0 = null;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone0;
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("hi!", "");
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = piePlot1.getDirection();
        try {
            piePlot1.setBackgroundImageAlpha((float) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rotation2);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset0);
        org.junit.Assert.assertNull(number1);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        double double0 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_Y_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 8.0d + "'", double0 == 8.0d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        java.awt.Shape shape0 = null;
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape0, (double) (-1.0f), (float) '#', (float) (short) 0);
        org.junit.Assert.assertNull(shape4);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        double double0 = org.jfree.chart.renderer.category.LevelRenderer.DEFAULT_ITEM_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("");
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int int0 = org.jfree.data.time.SerialDate.LAST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        boolean boolean0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        java.awt.Color color0 = java.awt.Color.magenta;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.chart.block.Arrangement arrangement0 = null;
        org.jfree.data.general.Dataset dataset1 = null;
        try {
            org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer3 = new org.jfree.chart.title.LegendItemBlockContainer(arrangement0, dataset1, (java.lang.Comparable) 0.05d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        int int0 = org.jfree.chart.axis.DateTickUnit.HOUR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        int int0 = org.jfree.chart.axis.DateTickUnit.SECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(2, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        java.util.Date date0 = null;
        java.util.Date date1 = null;
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(date0, date1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        java.awt.Font font1 = null;
        try {
            org.jfree.chart.text.TextFragment textFragment2 = new org.jfree.chart.text.TextFragment("hi!", font1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = null;
        java.awt.Stroke stroke5 = null;
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        try {
            org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem(attributedString0, "hi!", "", "hi!", shape4, stroke5, (java.awt.Paint) color6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_START_ANGLE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 90.0d + "'", double0 == 90.0d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        java.awt.Paint paint0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        java.lang.Comparable[] comparableArray6 = new java.lang.Comparable[] { (byte) 0, 1.0f, (-1.0f), 0.05d, 0.0f, 5 };
        java.lang.Comparable[] comparableArray12 = new java.lang.Comparable[] { (short) -1, (-1.0f), (-1L), 1, '4' };
        double[][] doubleArray13 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset14 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray6, comparableArray12, doubleArray13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray6);
        org.junit.Assert.assertNotNull(comparableArray12);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        java.awt.geom.Arc2D arc2D0 = null;
        java.awt.geom.Arc2D arc2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(arc2D0, arc2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.chart.ChartColor chartColor4 = new org.jfree.chart.ChartColor((int) (short) 0, (int) (byte) 100, (int) '#');
        java.awt.Stroke stroke5 = null;
        try {
            org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, (java.awt.Paint) chartColor4, stroke5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        java.awt.Font font1 = null;
        org.jfree.chart.ChartColor chartColor5 = new org.jfree.chart.ChartColor((int) (short) 0, (int) (byte) 100, (int) '#');
        try {
            org.jfree.chart.text.TextFragment textFragment7 = new org.jfree.chart.text.TextFragment("hi!", font1, (java.awt.Paint) chartColor5, (float) 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = new org.jfree.chart.axis.CategoryLabelPositions();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions0, categoryLabelPosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'top' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        try {
            textLine1.draw(graphics2D2, 1.0f, (float) (-1), textAnchor5, (float) (short) -1, (float) (byte) 0, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor5);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        java.lang.Comparable comparable0 = null;
        java.awt.Color color1 = java.awt.Color.black;
        java.awt.Stroke stroke2 = null;
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker(comparable0, (java.awt.Paint) color1, stroke2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Paint paint1 = org.jfree.chart.util.SerialUtilities.readPaint(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        try {
            textTitle0.setVerticalAlignment(verticalAlignment1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'alignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator2 = null;
        piePlot1.setToolTipGenerator(pieToolTipGenerator2);
        org.jfree.chart.LegendItemCollection legendItemCollection4 = piePlot1.getLegendItems();
        try {
            org.jfree.chart.LegendItem legendItem6 = legendItemCollection4.get((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection4);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, (float) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        try {
            org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange(1.0d, (double) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (1.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition0 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition3 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = new org.jfree.chart.axis.CategoryLabelPositions(categoryLabelPosition0, categoryLabelPosition1, categoryLabelPosition2, categoryLabelPosition3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'top' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Font font1 = null;
        try {
            barRenderer0.setBaseItemLabelFont(font1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        java.lang.Comparable comparable0 = null;
        java.awt.Paint paint1 = null;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker(comparable0, paint1, stroke2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        java.awt.Font font1 = null;
        org.jfree.chart.ChartColor chartColor5 = new org.jfree.chart.ChartColor((int) (short) 0, (int) (byte) 100, (int) '#');
        try {
            org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("hi!", font1, (java.awt.Paint) chartColor5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 0.0f, (double) 1L);
        double double3 = size2D2.height;
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, 0.0d);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange4, (double) '#');
        numberAxis2.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType10 = null;
        org.jfree.data.time.DateRange dateRange12 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.data.time.DateRange dateRange13 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange12);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType14 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = new org.jfree.chart.block.RectangleConstraint((double) 'a', (org.jfree.data.Range) dateRange4, lengthConstraintType10, (double) (-1L), (org.jfree.data.Range) dateRange13, lengthConstraintType14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'widthType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(dateRange12);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        java.lang.String str0 = org.jfree.chart.labels.IntervalCategoryToolTipGenerator.DEFAULT_TOOL_TIP_FORMAT_STRING;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "({0}, {1}) = {3} - {4}" + "'", str0.equals("({0}, {1}) = {3} - {4}"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("hi!", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator1, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator4, true);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.text.TextFragment textFragment2 = textLine1.getFirstTextFragment();
        java.awt.Paint paint3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        boolean boolean4 = textLine1.equals((java.lang.Object) paint3);
        org.junit.Assert.assertNotNull(textFragment2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        int int0 = org.jfree.chart.axis.DateTickUnit.MINUTE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray32);
        org.jfree.data.general.PieDataset pieDataset35 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset33, (int) (short) 1);
        java.lang.Comparable comparable36 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset39 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset35, comparable36, (double) 100L, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(pieDataset35);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 100, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.data.time.TimePeriod timePeriod1 = null;
        org.jfree.data.gantt.Task task2 = new org.jfree.data.gantt.Task("hi!", timePeriod1);
        java.lang.Object obj3 = null;
        boolean boolean4 = task2.equals(obj3);
        try {
            org.jfree.data.gantt.Task task6 = task2.getSubtask((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = piePlot1.getDirection();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator3 = piePlot1.getURLGenerator();
        float float4 = piePlot1.getForegroundAlpha();
        org.junit.Assert.assertNotNull(rotation2);
        org.junit.Assert.assertNull(pieURLGenerator3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator2 = null;
        piePlot1.setToolTipGenerator(pieToolTipGenerator2);
        org.jfree.chart.LegendItemCollection legendItemCollection4 = piePlot1.getLegendItems();
        try {
            org.jfree.chart.LegendItem legendItem6 = legendItemCollection4.get(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection4);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (byte) 100, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor4 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.text.TextAnchor textAnchor9 = null;
        org.jfree.chart.text.TextAnchor textAnchor11 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        java.awt.Shape shape12 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D6, (float) 1, (float) 0, textAnchor9, (double) 100L, textAnchor11);
        org.jfree.chart.text.TextAnchor textAnchor13 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor4, textAnchor11, textAnchor13, (double) (byte) 100);
        try {
            java.awt.geom.Rectangle2D rectangle2D16 = org.jfree.chart.text.TextUtilities.drawAlignedString("", graphics2D1, (float) (byte) 1, (float) 0, textAnchor11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelAnchor4);
        org.junit.Assert.assertNotNull(textAnchor11);
        org.junit.Assert.assertNull(shape12);
        org.junit.Assert.assertNotNull(textAnchor13);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState3 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo2);
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double9 = numberAxis8.getFixedAutoRange();
        java.text.NumberFormat numberFormat10 = numberAxis8.getNumberFormatOverride();
        java.lang.Number[] numberArray17 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray22 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray27 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray37 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray42 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[][] numberArray43 = new java.lang.Number[][] { numberArray17, numberArray22, numberArray27, numberArray32, numberArray37, numberArray42 };
        org.jfree.data.category.CategoryDataset categoryDataset44 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray43);
        try {
            statisticalBarRenderer0.drawItem(graphics2D1, categoryItemRendererState3, rectangle2D4, categoryPlot5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryDataset44, (int) (byte) 0, 0, 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires StatisticalCategoryDataset.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNull(numberFormat10);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray37);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(categoryDataset44);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator1, false);
        barRenderer0.setSeriesVisible(0, (java.lang.Boolean) false, false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        java.util.TimeZone timeZone0 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.junit.Assert.assertNull(timeZone0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        int int0 = org.jfree.chart.axis.DateTickUnit.YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            rectangleInsets0.trim(rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator1, false);
        boolean boolean4 = barRenderer0.getBaseCreateEntities();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState7 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo6);
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange14 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange14, 0.0d);
        org.jfree.data.Range range18 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange14, (double) '#');
        numberAxis12.setDefaultAutoRange((org.jfree.data.Range) dateRange14);
        boolean boolean20 = numberAxis12.isNegativeArrowVisible();
        java.lang.Number[] numberArray27 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray37 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray42 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray47 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray52 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[][] numberArray53 = new java.lang.Number[][] { numberArray27, numberArray32, numberArray37, numberArray42, numberArray47, numberArray52 };
        org.jfree.data.category.CategoryDataset categoryDataset54 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray53);
        try {
            barRenderer0.drawItem(graphics2D5, categoryItemRendererState7, rectangle2D8, categoryPlot9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryDataset54, (int) '#', 4, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 6");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(dateRange14);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray37);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(numberArray47);
        org.junit.Assert.assertNotNull(numberArray52);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(categoryDataset54);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("hi!");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) (short) 0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        java.awt.Paint paint0 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.util.Rotation rotation3 = piePlot2.getDirection();
        org.jfree.chart.plot.Plot plot4 = piePlot2.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        piePlot2.datasetChanged(datasetChangeEvent5);
        java.awt.Stroke stroke8 = piePlot2.getSectionOutlineStroke((java.lang.Comparable) (short) 100);
        java.awt.Paint paint9 = piePlot2.getNoDataMessagePaint();
        boolean boolean10 = org.jfree.chart.util.PaintUtilities.equal(paint0, paint9);
        org.junit.Assert.assertNotNull(paint0);
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNull(stroke8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        try {
            java.lang.Comparable comparable2 = defaultKeyedValues2D0.getColumnKey(15);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 15, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = piePlot1.getDirection();
        org.jfree.chart.plot.Plot plot3 = piePlot1.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        piePlot1.datasetChanged(datasetChangeEvent4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        piePlot1.drawBackgroundImage(graphics2D6, rectangle2D7);
        boolean boolean9 = piePlot1.getSectionOutlinesVisible();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent10 = null;
        piePlot1.datasetChanged(datasetChangeEvent10);
        org.junit.Assert.assertNotNull(rotation2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        java.lang.ClassLoader classLoader0 = null;
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D2 = rectangleInsets0.createInsetRectangle(rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        java.awt.Color color2 = java.awt.Color.getColor("", 0);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        java.text.DateFormat dateFormat1 = null;
        try {
            org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator2 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("hi!", dateFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.LegendItem legendItem3 = stackedAreaRenderer0.getLegendItem((int) 'a', 0);
        java.awt.Shape shape5 = null;
        stackedAreaRenderer0.setSeriesShape((int) '4', shape5, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = stackedAreaRenderer0.getSeriesPositiveItemLabelPosition((int) (byte) 1);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState12 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo11);
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double18 = numberAxis17.getFixedAutoRange();
        java.text.NumberFormat numberFormat19 = numberAxis17.getNumberFormatOverride();
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray36 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray41 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray51 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[][] numberArray52 = new java.lang.Number[][] { numberArray26, numberArray31, numberArray36, numberArray41, numberArray46, numberArray51 };
        org.jfree.data.category.CategoryDataset categoryDataset53 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray52);
        org.jfree.data.general.PieDataset pieDataset55 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset53, (int) (short) 1);
        try {
            stackedAreaRenderer0.drawItem(graphics2D10, categoryItemRendererState12, rectangle2D13, categoryPlot14, categoryAxis15, (org.jfree.chart.axis.ValueAxis) numberAxis17, categoryDataset53, 0, (int) (byte) 100, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 4");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNull(numberFormat19);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray36);
        org.junit.Assert.assertNotNull(numberArray41);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(numberArray52);
        org.junit.Assert.assertNotNull(categoryDataset53);
        org.junit.Assert.assertNotNull(pieDataset55);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod6 = new org.jfree.data.time.SimpleTimePeriod((long) 10, (long) 'a');
        java.lang.Comparable[] comparableArray8 = new java.lang.Comparable[] { (byte) 100, 0.2d, 10.0f, 0, 10, (-1L) };
        java.lang.Comparable[] comparableArray9 = new java.lang.Comparable[] {};
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray36 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray41 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[][] numberArray42 = new java.lang.Number[][] { numberArray16, numberArray21, numberArray26, numberArray31, numberArray36, numberArray41 };
        org.jfree.data.category.CategoryDataset categoryDataset43 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray42);
        java.lang.Number[] numberArray50 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray55 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray60 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray65 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray70 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray75 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[][] numberArray76 = new java.lang.Number[][] { numberArray50, numberArray55, numberArray60, numberArray65, numberArray70, numberArray75 };
        org.jfree.data.category.CategoryDataset categoryDataset77 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray76);
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset78 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray8, comparableArray9, numberArray42, numberArray76);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of category keys does not match the number of categories in the data.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray8);
        org.junit.Assert.assertNotNull(comparableArray9);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray36);
        org.junit.Assert.assertNotNull(numberArray41);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(categoryDataset43);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(numberArray55);
        org.junit.Assert.assertNotNull(numberArray60);
        org.junit.Assert.assertNotNull(numberArray65);
        org.junit.Assert.assertNotNull(numberArray70);
        org.junit.Assert.assertNotNull(numberArray75);
        org.junit.Assert.assertNotNull(numberArray76);
        org.junit.Assert.assertNotNull(categoryDataset77);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.POSITIVE;
        org.junit.Assert.assertNotNull(rangeType0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Month month1 = new org.jfree.data.time.Month(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("({0}, {1}) = {3} - {4}", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator1, false);
        boolean boolean4 = barRenderer0.getBaseCreateEntities();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        barRenderer0.setSeriesStroke((int) (short) 100, stroke6, false);
        java.lang.Boolean boolean10 = barRenderer0.getSeriesVisible((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = null;
        barRenderer0.setSeriesURLGenerator(100, categoryURLGenerator12);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator14 = null;
        try {
            barRenderer0.setLegendItemLabelGenerator(categorySeriesLabelGenerator14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'generator' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(boolean10);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator2 = null;
        piePlot1.setToolTipGenerator(pieToolTipGenerator2);
        org.jfree.chart.LegendItemCollection legendItemCollection4 = piePlot1.getLegendItems();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.geom.Point2D point2D7 = null;
        org.jfree.chart.plot.PlotState plotState8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        try {
            piePlot1.draw(graphics2D5, rectangle2D6, point2D7, plotState8, plotRenderingInfo9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection4);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        java.awt.Color color0 = java.awt.Color.pink;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        double double1 = boxAndWhiskerRenderer0.getItemMargin();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 1.0f, 100.0f, 15 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f, 100.0f, 15 };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 1.0f, 100.0f, 15 };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 1.0f, 100.0f, 15 };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { 1.0f, 100.0f, 15 };
        java.lang.Number[][] numberArray20 = new java.lang.Number[][] { numberArray3, numberArray7, numberArray11, numberArray15, numberArray19 };
        java.lang.Number[] numberArray23 = new java.lang.Number[] { 0.2d, 0.05d };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.2d, 0.05d };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { 0.2d, 0.05d };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 0.2d, 0.05d };
        java.lang.Number[] numberArray35 = new java.lang.Number[] { 0.2d, 0.05d };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { 0.2d, 0.05d };
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] { numberArray23, numberArray26, numberArray29, numberArray32, numberArray35, numberArray38 };
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset40 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray20, numberArray39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset: the number of series in the start value dataset does not match the number of series in the end value dataset.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        int int0 = org.jfree.data.time.SerialDate.SUNDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.text.TextFragment textFragment2 = textLine1.getFirstTextFragment();
        java.awt.Graphics2D graphics2D3 = null;
        try {
            org.jfree.chart.util.Size2D size2D4 = textLine1.calculateDimensions(graphics2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textFragment2);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) true);
        int int3 = keyToGroupMap1.getKeyCount((java.lang.Comparable) 0.05d);
        java.util.List list4 = keyToGroupMap1.getGroups();
        try {
            java.util.Collection collection5 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list4);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(list4);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState3 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo2);
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double9 = numberAxis8.getFixedAutoRange();
        boolean boolean10 = numberAxis8.isAxisLineVisible();
        java.lang.Number[] numberArray17 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray22 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray27 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray37 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray42 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[][] numberArray43 = new java.lang.Number[][] { numberArray17, numberArray22, numberArray27, numberArray32, numberArray37, numberArray42 };
        org.jfree.data.category.CategoryDataset categoryDataset44 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray43);
        org.jfree.data.general.PieDataset pieDataset46 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset44, (int) (short) 1);
        try {
            stackedAreaRenderer0.drawItem(graphics2D1, categoryItemRendererState3, rectangle2D4, categoryPlot5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryDataset44, (int) 'a', (int) (byte) 10, 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 6");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray37);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(categoryDataset44);
        org.junit.Assert.assertNotNull(pieDataset46);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator1 = null;
        try {
            lineAndShapeRenderer0.setLegendItemLabelGenerator(categorySeriesLabelGenerator1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'generator' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        javax.swing.Icon icon1 = null;
        try {
            minMaxCategoryRenderer0.setMaxIcon(icon1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'icon' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState3 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo2);
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean9 = numberAxis8.getAutoRangeStickyZero();
        org.jfree.chart.axis.TickUnitSource tickUnitSource10 = numberAxis8.getStandardTickUnits();
        numberAxis8.setTickMarkInsideLength((float) 0);
        java.lang.Number[] numberArray19 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray34 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray44 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[][] numberArray45 = new java.lang.Number[][] { numberArray19, numberArray24, numberArray29, numberArray34, numberArray39, numberArray44 };
        org.jfree.data.category.CategoryDataset categoryDataset46 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray45);
        org.jfree.data.general.PieDataset pieDataset48 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset46, (int) (short) 1);
        try {
            boxAndWhiskerRenderer0.drawVerticalItem(graphics2D1, categoryItemRendererState3, rectangle2D4, categoryPlot5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryDataset46, (int) (short) 100, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.category.DefaultCategoryDataset cannot be cast to org.jfree.data.statistics.BoxAndWhiskerCategoryDataset");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(tickUnitSource10);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(categoryDataset46);
        org.junit.Assert.assertNotNull(pieDataset48);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setDrawOutlines(true);
        boolean boolean3 = lineAndShapeRenderer0.getBaseLinesVisible();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        org.jfree.chart.util.Rotation rotation6 = piePlot5.getDirection();
        org.jfree.chart.plot.Plot plot7 = piePlot5.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        piePlot5.datasetChanged(datasetChangeEvent8);
        java.awt.Stroke stroke11 = piePlot5.getSectionOutlineStroke((java.lang.Comparable) (short) 100);
        java.awt.Paint paint12 = piePlot5.getNoDataMessagePaint();
        lineAndShapeRenderer0.setBasePaint(paint12, false);
        lineAndShapeRenderer0.setSeriesLinesVisible((int) (short) 10, false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(rotation6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.geom.Point2D point2D1 = org.jfree.chart.util.SerialUtilities.readPoint2D(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setNotify(false);
        java.lang.String str3 = textTitle0.getToolTipText();
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = piePlot1.getDirection();
        org.jfree.chart.plot.Plot plot3 = piePlot1.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        piePlot1.datasetChanged(datasetChangeEvent4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        piePlot1.drawBackgroundImage(graphics2D6, rectangle2D7);
        boolean boolean9 = piePlot1.getSectionOutlinesVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        piePlot1.setInsets(rectangleInsets10, true);
        float float13 = piePlot1.getBackgroundAlpha();
        org.junit.Assert.assertNotNull(rotation2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 1.0f + "'", float13 == 1.0f);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        java.util.Date date0 = null;
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.text.TextAnchor textAnchor6 = null;
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        java.awt.Shape shape9 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D3, (float) 1, (float) 0, textAnchor6, (double) 100L, textAnchor8);
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        boolean boolean12 = textAnchor10.equals((java.lang.Object) 'a');
        try {
            org.jfree.chart.axis.DateTick dateTick14 = new org.jfree.chart.axis.DateTick(date0, "", textAnchor8, textAnchor10, (double) 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNull(shape9);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        java.text.AttributedString attributedString0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeAttributedString(attributedString0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        java.text.DateFormat dateFormat1 = null;
        try {
            org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator2 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("({0}, {1}) = {3} - {4}", dateFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = rectangleInsets0.createOutsetRectangle(rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(unitType1);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        try {
            keyedObjects2D0.removeColumn((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 0.0f, (double) 1L);
        size2D2.setWidth((double) 0.0f);
        double double5 = size2D2.getHeight();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.lang.Comparable comparable1 = null;
        try {
            defaultKeyedValues2D0.removeValue(comparable1, (java.lang.Comparable) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.getAutoRangeStickyZero();
        org.jfree.chart.axis.TickUnitSource tickUnitSource3 = numberAxis1.getStandardTickUnits();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = null;
        try {
            numberAxis1.setTickUnit(numberTickUnit4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(tickUnitSource3);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        java.awt.Font font0 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 2, (float) 4);
        org.jfree.chart.entity.ChartEntity chartEntity4 = new org.jfree.chart.entity.ChartEntity(shape2, "");
        chartEntity4.setToolTipText("");
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateBottomOutset((double) (-1L));
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType4 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType5 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = rectangleInsets0.createAdjustedRectangle(rectangle2D3, lengthAdjustmentType4, lengthAdjustmentType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = null;
        try {
            org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'type' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        java.lang.Comparable comparable0 = null;
        java.awt.Shape shape1 = null;
        try {
            org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity4 = new org.jfree.chart.entity.CategoryLabelEntity(comparable0, shape1, "hi!", "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test135() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test135");
//        long long0 = org.jfree.chart.axis.SegmentedTimeline.FIRST_MONDAY_AFTER_1900;
//        org.junit.Assert.assertTrue("'" + long0 + "' != '" + (-2208960000000L) + "'", long0 == (-2208960000000L));
//    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.util.Rotation rotation3 = piePlot2.getDirection();
        org.jfree.chart.plot.Plot plot4 = piePlot2.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        piePlot2.datasetChanged(datasetChangeEvent5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        piePlot2.drawBackgroundImage(graphics2D7, rectangle2D8);
        java.awt.Paint paint10 = piePlot2.getBaseSectionOutlinePaint();
        java.awt.Paint paint11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot2.setBaseSectionPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart13.setTitle("({0}, {1}) = {3} - {4}");
        org.jfree.chart.title.TextTitle textTitle16 = jFreeChart13.getTitle();
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo19 = null;
        try {
            jFreeChart13.draw(graphics2D17, rectangle2D18, chartRenderingInfo19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(textTitle16);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.LegendItem legendItem3 = stackedAreaRenderer0.getLegendItem((int) 'a', 0);
        java.awt.Shape shape5 = null;
        stackedAreaRenderer0.setSeriesShape((int) '4', shape5, true);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState10 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo9);
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean16 = numberAxis15.getAutoRangeStickyZero();
        java.lang.Number[] numberArray23 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray28 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray43 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray48 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[][] numberArray49 = new java.lang.Number[][] { numberArray23, numberArray28, numberArray33, numberArray38, numberArray43, numberArray48 };
        org.jfree.data.category.CategoryDataset categoryDataset50 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray49);
        org.jfree.data.general.PieDataset pieDataset52 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset50, (int) (short) 1);
        org.jfree.data.Range range53 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset50);
        try {
            stackedAreaRenderer0.drawItem(graphics2D8, categoryItemRendererState10, rectangle2D11, categoryPlot12, categoryAxis13, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryDataset50, (int) (short) 100, (int) (short) -1, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 6");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(numberArray48);
        org.junit.Assert.assertNotNull(numberArray49);
        org.junit.Assert.assertNotNull(categoryDataset50);
        org.junit.Assert.assertNotNull(pieDataset52);
        org.junit.Assert.assertNotNull(range53);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.chart.plot.Marker marker0 = null;
        try {
            org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = new org.jfree.chart.event.MarkerChangeEvent(marker0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.getAutoRangeStickyZero();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = null;
        try {
            numberAxis1.setTickUnit(numberTickUnit3, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        java.lang.String str2 = plotOrientation1.toString();
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge3 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PlotOrientation.VERTICAL" + "'", str2.equals("PlotOrientation.VERTICAL"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.lang.Object obj1 = defaultKeyedValues2D0.clone();
        try {
            defaultKeyedValues2D0.removeRow((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("hi!", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = barRenderer0.getBaseToolTipGenerator();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator4 = barRenderer0.getToolTipGenerator((int) (byte) 100, 0);
        boolean boolean5 = barRenderer0.getAutoPopulateSeriesPaint();
        double double6 = barRenderer0.getUpperClip();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = null;
        try {
            barRenderer0.setPlot(categoryPlot7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator1);
        org.junit.Assert.assertNull(categoryToolTipGenerator4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.data.time.DateRange dateRange1 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange0);
        double double3 = dateRange0.constrain((double) 0.0f);
        org.junit.Assert.assertNotNull(dateRange0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        java.awt.Color color0 = java.awt.Color.LIGHT_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        java.awt.Font font0 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        int int0 = org.jfree.data.time.SerialDate.WEDNESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = piePlot1.getDirection();
        org.jfree.chart.plot.Plot plot3 = piePlot1.getParent();
        org.jfree.chart.plot.Plot plot4 = piePlot1.getRootPlot();
        java.awt.Color color5 = java.awt.Color.MAGENTA;
        piePlot1.setOutlinePaint((java.awt.Paint) color5);
        double double7 = piePlot1.getStartAngle();
        org.junit.Assert.assertNotNull(rotation2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(plot4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 90.0d + "'", double7 == 90.0d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.ASCENDING;
        java.lang.String str1 = sortOrder0.toString();
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SortOrder.ASCENDING" + "'", str1.equals("SortOrder.ASCENDING"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.util.Rotation rotation3 = piePlot2.getDirection();
        org.jfree.chart.plot.Plot plot4 = piePlot2.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        piePlot2.datasetChanged(datasetChangeEvent5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        piePlot2.drawBackgroundImage(graphics2D7, rectangle2D8);
        java.awt.Paint paint10 = piePlot2.getBaseSectionOutlinePaint();
        java.awt.Paint paint11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot2.setBaseSectionPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart13.setBackgroundImageAlpha((float) (byte) 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType17 = rectangleInsets16.getUnitType();
        try {
            jFreeChart13.setTextAntiAlias((java.lang.Object) unitType17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: UnitType.ABSOLUTE incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(unitType17);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        java.awt.Shape shape5 = null;
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape12 = null;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color14 = java.awt.Color.black;
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("", "hi!", "hi!", "", true, shape5, false, (java.awt.Paint) color7, false, paint9, stroke10, true, shape12, stroke13, (java.awt.Paint) color14);
        java.awt.Stroke stroke16 = legendItem15.getLineStroke();
        legendItem15.setSeriesIndex((int) (short) 0);
        legendItem15.setSeriesKey((java.lang.Comparable) (-1.0f));
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        org.jfree.chart.block.LineBorder lineBorder1 = new org.jfree.chart.block.LineBorder();
        boolean boolean2 = datasetRenderingOrder0.equals((java.lang.Object) lineBorder1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.util.Rotation rotation3 = piePlot2.getDirection();
        org.jfree.chart.plot.Plot plot4 = piePlot2.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        piePlot2.datasetChanged(datasetChangeEvent5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        piePlot2.drawBackgroundImage(graphics2D7, rectangle2D8);
        java.awt.Paint paint10 = piePlot2.getBaseSectionOutlinePaint();
        java.awt.Paint paint11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot2.setBaseSectionPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo16 = null;
        try {
            jFreeChart13.handleClick(11, (int) (byte) 10, chartRenderingInfo16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator1, false);
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.util.Rotation rotation7 = piePlot6.getDirection();
        org.jfree.chart.plot.Plot plot8 = piePlot6.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent9 = null;
        piePlot6.datasetChanged(datasetChangeEvent9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        piePlot6.drawBackgroundImage(graphics2D11, rectangle2D12);
        java.awt.Paint paint14 = piePlot6.getBaseSectionOutlinePaint();
        java.awt.Paint paint15 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot6.setBaseSectionPaint(paint15);
        barRenderer0.setSeriesItemLabelPaint((int) (byte) 0, paint15);
        boolean boolean18 = barRenderer0.getAutoPopulateSeriesShape();
        java.awt.Shape shape24 = null;
        java.awt.Color color26 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Paint paint28 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke29 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape31 = null;
        java.awt.Stroke stroke32 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color33 = java.awt.Color.black;
        org.jfree.chart.LegendItem legendItem34 = new org.jfree.chart.LegendItem("", "hi!", "hi!", "", true, shape24, false, (java.awt.Paint) color26, false, paint28, stroke29, true, shape31, stroke32, (java.awt.Paint) color33);
        barRenderer0.setBaseOutlineStroke(stroke29, false);
        java.awt.Font font38 = barRenderer0.getSeriesItemLabelFont(4);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor40 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        java.awt.Graphics2D graphics2D42 = null;
        org.jfree.chart.text.TextAnchor textAnchor45 = null;
        org.jfree.chart.text.TextAnchor textAnchor47 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        java.awt.Shape shape48 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D42, (float) 1, (float) 0, textAnchor45, (double) 100L, textAnchor47);
        org.jfree.chart.text.TextAnchor textAnchor49 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition51 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor40, textAnchor47, textAnchor49, (double) (byte) 100);
        barRenderer0.setSeriesPositiveItemLabelPosition(100, itemLabelPosition51, false);
        org.junit.Assert.assertNotNull(rotation7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNull(font38);
        org.junit.Assert.assertNotNull(itemLabelAnchor40);
        org.junit.Assert.assertNotNull(textAnchor47);
        org.junit.Assert.assertNull(shape48);
        org.junit.Assert.assertNotNull(textAnchor49);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        java.lang.String str2 = unitType1.toString();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UnitType.ABSOLUTE" + "'", str2.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.util.Rotation rotation3 = piePlot2.getDirection();
        org.jfree.chart.plot.Plot plot4 = piePlot2.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        piePlot2.datasetChanged(datasetChangeEvent5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        piePlot2.drawBackgroundImage(graphics2D7, rectangle2D8);
        java.awt.Paint paint10 = piePlot2.getBaseSectionOutlinePaint();
        java.awt.Paint paint11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot2.setBaseSectionPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart13.setBackgroundImageAlpha((float) (byte) 10);
        org.jfree.chart.event.ChartChangeListener chartChangeListener16 = null;
        try {
            jFreeChart13.removeChangeListener(chartChangeListener16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = piePlot1.getDirection();
        org.jfree.chart.plot.Plot plot3 = piePlot1.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        piePlot1.datasetChanged(datasetChangeEvent4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        piePlot1.drawBackgroundImage(graphics2D6, rectangle2D7);
        java.awt.Paint paint9 = piePlot1.getBaseSectionOutlinePaint();
        java.awt.Paint paint11 = piePlot1.getSectionPaint((java.lang.Comparable) 10);
        int int12 = piePlot1.getBackgroundImageAlignment();
        org.junit.Assert.assertNotNull(rotation2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 15 + "'", int12 == 15);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.util.Rotation rotation3 = piePlot2.getDirection();
        org.jfree.chart.plot.Plot plot4 = piePlot2.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        piePlot2.datasetChanged(datasetChangeEvent5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        piePlot2.drawBackgroundImage(graphics2D7, rectangle2D8);
        java.awt.Paint paint10 = piePlot2.getBaseSectionOutlinePaint();
        java.awt.Paint paint11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot2.setBaseSectionPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart13.setTitle("({0}, {1}) = {3} - {4}");
        java.lang.Object obj16 = jFreeChart13.clone();
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        java.awt.geom.Point2D point2D19 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = null;
        try {
            jFreeChart13.draw(graphics2D17, rectangle2D18, point2D19, chartRenderingInfo20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.lang.Object obj1 = defaultKeyedValues2D0.clone();
        try {
            defaultKeyedValues2D0.removeColumn((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.util.Rotation rotation3 = piePlot2.getDirection();
        org.jfree.chart.plot.Plot plot4 = piePlot2.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        piePlot2.datasetChanged(datasetChangeEvent5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        piePlot2.drawBackgroundImage(graphics2D7, rectangle2D8);
        java.awt.Paint paint10 = piePlot2.getBaseSectionOutlinePaint();
        java.awt.Paint paint11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot2.setBaseSectionPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart13.setTitle("({0}, {1}) = {3} - {4}");
        org.jfree.chart.title.TextTitle textTitle16 = jFreeChart13.getTitle();
        org.jfree.chart.event.ChartChangeListener chartChangeListener17 = null;
        try {
            jFreeChart13.removeChangeListener(chartChangeListener17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(textTitle16);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = piePlot1.getDirection();
        org.jfree.chart.plot.Plot plot3 = piePlot1.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        piePlot1.datasetChanged(datasetChangeEvent4);
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        barRenderer6.setBaseToolTipGenerator(categoryToolTipGenerator7, false);
        boolean boolean10 = barRenderer6.getBaseCreateEntities();
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        barRenderer6.setSeriesStroke((int) (short) 100, stroke12, false);
        piePlot1.setLabelOutlineStroke(stroke12);
        java.io.ObjectOutputStream objectOutputStream16 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeStroke(stroke12, objectOutputStream16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rotation2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        java.lang.Comparable[] comparableArray4 = new java.lang.Comparable[] { (-1), 100L, (byte) 0, 0.0d };
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        java.lang.Comparable[] comparableArray8 = new java.lang.Comparable[] { year5, 8.0d, (-1.0d) };
        java.lang.Number[] numberArray9 = new java.lang.Number[] {};
        java.lang.Number[] numberArray10 = new java.lang.Number[] {};
        java.lang.Number[] numberArray11 = new java.lang.Number[] {};
        java.lang.Number[] numberArray12 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray13 = new java.lang.Number[][] { numberArray9, numberArray10, numberArray11, numberArray12 };
        java.lang.Number[] numberArray20 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray30 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray35 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray40 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray45 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[][] numberArray46 = new java.lang.Number[][] { numberArray20, numberArray25, numberArray30, numberArray35, numberArray40, numberArray45 };
        org.jfree.data.category.CategoryDataset categoryDataset47 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray46);
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset48 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray4, comparableArray8, numberArray13, numberArray46);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset: the number of series in the start value dataset does not match the number of series in the end value dataset.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray4);
        org.junit.Assert.assertNotNull(comparableArray8);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(categoryDataset47);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("PlotOrientation.VERTICAL", "");
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.util.Rotation rotation3 = piePlot2.getDirection();
        org.jfree.chart.plot.Plot plot4 = piePlot2.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        piePlot2.datasetChanged(datasetChangeEvent5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        piePlot2.drawBackgroundImage(graphics2D7, rectangle2D8);
        java.awt.Paint paint10 = piePlot2.getBaseSectionOutlinePaint();
        java.awt.Paint paint11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot2.setBaseSectionPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart13.setTitle("({0}, {1}) = {3} - {4}");
        java.lang.Object obj16 = jFreeChart13.clone();
        jFreeChart13.fireChartChanged();
        boolean boolean18 = jFreeChart13.getAntiAlias();
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setDrawOutlines(true);
        boolean boolean3 = lineAndShapeRenderer0.getBaseLinesVisible();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        org.jfree.chart.util.Rotation rotation6 = piePlot5.getDirection();
        org.jfree.chart.plot.Plot plot7 = piePlot5.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        piePlot5.datasetChanged(datasetChangeEvent8);
        java.awt.Stroke stroke11 = piePlot5.getSectionOutlineStroke((java.lang.Comparable) (short) 100);
        java.awt.Paint paint12 = piePlot5.getNoDataMessagePaint();
        lineAndShapeRenderer0.setBasePaint(paint12, false);
        int int15 = lineAndShapeRenderer0.getColumnCount();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(rotation6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) true);
        int int3 = keyToGroupMap1.getKeyCount((java.lang.Comparable) 0.05d);
        java.util.List list4 = keyToGroupMap1.getGroups();
        java.lang.Comparable comparable5 = null;
        int int6 = keyToGroupMap1.getGroupIndex(comparable5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator2 = null;
        piePlot1.setToolTipGenerator(pieToolTipGenerator2);
        org.jfree.chart.LegendItemCollection legendItemCollection4 = piePlot1.getLegendItems();
        java.lang.Object obj5 = legendItemCollection4.clone();
        boolean boolean7 = legendItemCollection4.equals((java.lang.Object) "UnitType.ABSOLUTE");
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange0, 0.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = rectangleConstraint2.toUnconstrainedHeight();
        org.jfree.data.Range range4 = rectangleConstraint2.getHeightRange();
        org.jfree.data.Range range5 = rectangleConstraint2.getWidthRange();
        org.jfree.data.Range range6 = rectangleConstraint2.getWidthRange();
        org.junit.Assert.assertNotNull(dateRange0);
        org.junit.Assert.assertNotNull(rectangleConstraint3);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(range6);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator1 = new org.jfree.chart.urls.StandardCategoryURLGenerator("RectangleEdge.LEFT");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset2 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        int int3 = defaultStatisticalCategoryDataset2.getColumnCount();
        java.lang.Comparable comparable4 = null;
        int int5 = defaultStatisticalCategoryDataset2.getRowIndex(comparable4);
        java.lang.Object obj6 = defaultStatisticalCategoryDataset2.clone();
        try {
            java.lang.String str9 = standardCategoryURLGenerator1.generateURL((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset2, (int) (short) 1, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = barRenderer0.getBaseToolTipGenerator();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator4 = barRenderer0.getToolTipGenerator((int) (byte) 100, 0);
        int int5 = barRenderer0.getRowCount();
        org.junit.Assert.assertNull(categoryToolTipGenerator1);
        org.junit.Assert.assertNull(categoryToolTipGenerator4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = barRenderer0.getBaseToolTipGenerator();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator4 = barRenderer0.getToolTipGenerator((int) (byte) 100, 0);
        boolean boolean5 = barRenderer0.getAutoPopulateSeriesPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = null;
        barRenderer0.setSeriesNegativeItemLabelPosition((int) (byte) 100, itemLabelPosition7, false);
        barRenderer0.setBaseSeriesVisible(false);
        org.jfree.chart.LegendItem legendItem14 = barRenderer0.getLegendItem((int) (short) 10, (int) (short) 100);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = barRenderer0.getBaseToolTipGenerator();
        org.junit.Assert.assertNull(categoryToolTipGenerator1);
        org.junit.Assert.assertNull(categoryToolTipGenerator4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(legendItem14);
        org.junit.Assert.assertNull(categoryToolTipGenerator15);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator1 = new org.jfree.chart.urls.StandardCategoryURLGenerator("SortOrder.ASCENDING");
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        java.lang.ClassLoader classLoader0 = null;
        try {
            java.util.ResourceBundle.clearCache(classLoader0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        java.lang.Object obj0 = null;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.util.Rotation rotation4 = piePlot3.getDirection();
        org.jfree.chart.plot.Plot plot5 = piePlot3.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = null;
        piePlot3.datasetChanged(datasetChangeEvent6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        piePlot3.drawBackgroundImage(graphics2D8, rectangle2D9);
        java.awt.Paint paint11 = piePlot3.getBaseSectionOutlinePaint();
        java.awt.Paint paint12 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot3.setBaseSectionPaint(paint12);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot3);
        jFreeChart14.setTitle("({0}, {1}) = {3} - {4}");
        java.lang.Object obj17 = jFreeChart14.clone();
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent18 = new org.jfree.chart.event.ChartChangeEvent(obj0, jFreeChart14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rotation4);
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(obj17);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.HOUR_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 3600000L + "'", long0 == 3600000L);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = barRenderer0.getBaseToolTipGenerator();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator4 = barRenderer0.getToolTipGenerator((int) (byte) 100, 0);
        boolean boolean5 = barRenderer0.getAutoPopulateSeriesPaint();
        double double6 = barRenderer0.getUpperClip();
        double double7 = barRenderer0.getMaximumBarWidth();
        org.junit.Assert.assertNull(categoryToolTipGenerator1);
        org.junit.Assert.assertNull(categoryToolTipGenerator4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = piePlot1.getDirection();
        org.jfree.chart.plot.Plot plot3 = piePlot1.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        piePlot1.datasetChanged(datasetChangeEvent4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        piePlot1.drawBackgroundImage(graphics2D6, rectangle2D7);
        java.awt.Paint paint9 = piePlot1.getBaseSectionOutlinePaint();
        java.awt.Paint paint10 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot1.setBaseSectionPaint(paint10);
        piePlot1.setStartAngle((double) (short) 0);
        org.jfree.chart.util.Rotation rotation14 = piePlot1.getDirection();
        java.awt.Paint paint15 = piePlot1.getBaseSectionOutlinePaint();
        org.junit.Assert.assertNotNull(rotation2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rotation14);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        java.lang.ClassLoader classLoader0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
        org.junit.Assert.assertNull(classLoader0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemVisible(1, 15);
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer5.setMaximumBarWidth(8.0d);
        java.awt.Shape shape14 = null;
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Paint paint18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape21 = null;
        java.awt.Stroke stroke22 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color23 = java.awt.Color.black;
        org.jfree.chart.LegendItem legendItem24 = new org.jfree.chart.LegendItem("", "hi!", "hi!", "", true, shape14, false, (java.awt.Paint) color16, false, paint18, stroke19, true, shape21, stroke22, (java.awt.Paint) color23);
        barRenderer5.setSeriesStroke(2, stroke22);
        try {
            lineAndShapeRenderer0.setSeriesStroke((int) (short) -1, stroke22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color23);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            barRenderer3D0.drawDomainGridline(graphics2D1, categoryPlot2, rectangle2D3, (double) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "({0}, {1}) = {3} - {4}", "", image3, "hi!", "hi!", "({0}, {1}) = {3} - {4}");
        java.awt.Image image8 = null;
        projectInfo7.setLogo(image8);
        projectInfo7.addOptionalLibrary("UnitType.ABSOLUTE");
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "({0}, {1}) = {3} - {4}", "", image3, "hi!", "hi!", "({0}, {1}) = {3} - {4}");
        projectInfo7.setInfo("RectangleEdge.LEFT");
        projectInfo7.setCopyright("");
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getUpperMargin();
        try {
            numberAxis1.zoomRange((double) '#', (double) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (35.0) <= upper (2.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateBottomOutset((double) (-1L));
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.TOP;
        boolean boolean4 = rectangleInsets0.equals((java.lang.Object) rectangleAnchor3);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor5 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        boolean boolean8 = textAnchor6.equals((java.lang.Object) 'a');
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType10 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition12 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor3, textBlockAnchor5, textAnchor6, (double) (-2208960000000L), categoryLabelWidthType10, (float) 3);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor13 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.text.TextAnchor textAnchor18 = null;
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        java.awt.Shape shape21 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D15, (float) 1, (float) 0, textAnchor18, (double) 100L, textAnchor20);
        java.lang.String str22 = textAnchor20.toString();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType24 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition26 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor3, textBlockAnchor13, textAnchor20, 0.0d, categoryLabelWidthType24, (float) (short) 100);
        org.jfree.chart.text.TextAnchor textAnchor27 = categoryLabelPosition26.getRotationAnchor();
        float float28 = categoryLabelPosition26.getWidthRatio();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor5);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(categoryLabelWidthType10);
        org.junit.Assert.assertNotNull(textBlockAnchor13);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNull(shape21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "TextAnchor.CENTER_RIGHT" + "'", str22.equals("TextAnchor.CENTER_RIGHT"));
        org.junit.Assert.assertNotNull(categoryLabelWidthType24);
        org.junit.Assert.assertNotNull(textAnchor27);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 100.0f + "'", float28 == 100.0f);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = barRenderer0.getBaseToolTipGenerator();
        barRenderer0.setBase((double) 0);
        org.junit.Assert.assertNull(categoryToolTipGenerator1);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.LegendItem legendItem3 = stackedAreaRenderer0.getLegendItem((int) 'a', 0);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = null;
        stackedAreaRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator4, true);
        boolean boolean8 = stackedAreaRenderer0.equals((java.lang.Object) 10.0f);
        stackedAreaRenderer0.setSeriesVisibleInLegend(2, (java.lang.Boolean) false, true);
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(4);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-459) + "'", int1 == (-459));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.text.TextFragment textFragment4 = textLine3.getFirstTextFragment();
        java.awt.Font font5 = textFragment4.getFont();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.block.LabelBlock labelBlock7 = new org.jfree.chart.block.LabelBlock("hi!", font5, (java.awt.Paint) color6);
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("PlotOrientation.VERTICAL", font5);
        org.junit.Assert.assertNotNull(textFragment4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator2 = null;
        piePlot1.setToolTipGenerator(pieToolTipGenerator2);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod6 = new org.jfree.data.time.SimpleTimePeriod((long) 10, (long) 'a');
        java.awt.Stroke stroke7 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) simpleTimePeriod6);
        java.util.Date date8 = simpleTimePeriod6.getEnd();
        java.util.TimeZone timeZone9 = null;
        try {
            org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date8, timeZone9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(stroke7);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint2 = statisticalBarRenderer0.lookupSeriesPaint((-1));
        org.jfree.chart.event.RendererChangeListener rendererChangeListener3 = null;
        try {
            statisticalBarRenderer0.removeChangeListener(rendererChangeListener3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator1 = null;
        barRenderer3D0.setLegendItemURLGenerator(categorySeriesLabelGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState5 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo4);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str11 = numberAxis10.getLabelToolTip();
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray23 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray28 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray43 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[][] numberArray44 = new java.lang.Number[][] { numberArray18, numberArray23, numberArray28, numberArray33, numberArray38, numberArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray44);
        org.jfree.data.general.PieDataset pieDataset47 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset45, (int) (short) 1);
        org.jfree.data.Range range48 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset45);
        try {
            barRenderer3D0.drawItem(graphics2D3, categoryItemRendererState5, rectangle2D6, categoryPlot7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) numberAxis10, categoryDataset45, (int) 'a', 2, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 6");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNotNull(pieDataset47);
        org.junit.Assert.assertNotNull(range48);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.lang.String str2 = rectangleEdge1.toString();
        try {
            double double3 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D0, rectangleEdge1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RectangleEdge.LEFT" + "'", str2.equals("RectangleEdge.LEFT"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.chart.axis.SegmentedTimeline.FIRST_MONDAY_AFTER_1900 = (byte) 1;
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setMaximumBarWidth(8.0d);
        java.awt.Shape shape9 = null;
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape16 = null;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color18 = java.awt.Color.black;
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("", "hi!", "hi!", "", true, shape9, false, (java.awt.Paint) color11, false, paint13, stroke14, true, shape16, stroke17, (java.awt.Paint) color18);
        barRenderer0.setSeriesStroke(2, stroke17);
        double double21 = barRenderer0.getUpperClip();
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            rectangleInsets0.trim(rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) true);
        int int3 = keyToGroupMap1.getKeyCount((java.lang.Comparable) 0.05d);
        java.util.List list4 = keyToGroupMap1.getGroups();
        int int6 = keyToGroupMap1.getKeyCount((java.lang.Comparable) "NO_CHANGE");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.Comparable[] comparableArray6 = new java.lang.Comparable[] { 10, 10, 100, 100, 0.0f };
        java.lang.Comparable[] comparableArray7 = new java.lang.Comparable[] {};
        double[] doubleArray14 = new double[] { (byte) 10, (-1), 0.2d, 15, 2.0d, 12 };
        double[] doubleArray21 = new double[] { (byte) 10, (-1), 0.2d, 15, 2.0d, 12 };
        double[] doubleArray28 = new double[] { (byte) 10, (-1), 0.2d, 15, 2.0d, 12 };
        double[][] doubleArray29 = new double[][] { doubleArray14, doubleArray21, doubleArray28 };
        try {
            org.jfree.data.category.CategoryDataset categoryDataset30 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray6, comparableArray7, doubleArray29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Duplicate items in 'rowKeys'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray6);
        org.junit.Assert.assertNotNull(comparableArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = piePlot1.getDirection();
        org.jfree.chart.plot.Plot plot3 = piePlot1.getParent();
        try {
            boolean boolean4 = plot3.isSubplot();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rotation2);
        org.junit.Assert.assertNull(plot3);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod3 = new org.jfree.data.time.SimpleTimePeriod((long) 10, (long) 'a');
        try {
            keyedObjects0.removeValue((java.lang.Comparable) simpleTimePeriod3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 2, (float) 4);
        org.jfree.chart.entity.ChartEntity chartEntity4 = new org.jfree.chart.entity.ChartEntity(shape2, "");
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity7 = new org.jfree.chart.entity.TickLabelEntity(shape2, "RectangleEdge.LEFT", "RectangleEdge.LEFT");
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape2, 1.0E-8d, 0.0f, (float) 100L);
        java.io.ObjectOutputStream objectOutputStream12 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeShape(shape2, objectOutputStream12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape11);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        java.awt.geom.Ellipse2D ellipse2D0 = null;
        java.awt.geom.Ellipse2D ellipse2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(ellipse2D0, ellipse2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator1, false);
        boolean boolean4 = barRenderer0.getBaseCreateEntities();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        barRenderer0.setSeriesStroke((int) (short) 100, stroke6, false);
        org.jfree.data.KeyToGroupMap keyToGroupMap9 = new org.jfree.data.KeyToGroupMap();
        boolean boolean10 = barRenderer0.equals((java.lang.Object) keyToGroupMap9);
        int int12 = keyToGroupMap9.getKeyCount((java.lang.Comparable) 3600000L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        java.lang.Object obj1 = strokeList0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, 10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setXOffset((double) 3600000L);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            lineRenderer3D0.drawOutline(graphics2D3, categoryPlot4, rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Paint paint1 = null;
        try {
            numberAxis0.setAxisLinePaint(paint1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        org.jfree.chart.LegendItem legendItem3 = boxAndWhiskerRenderer0.getLegendItem(15, (int) '#');
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState6 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo5);
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean12 = numberAxis11.getAutoRangeStickyZero();
        org.jfree.chart.axis.TickUnitSource tickUnitSource13 = numberAxis11.getStandardTickUnits();
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        try {
            boxAndWhiskerRenderer0.drawItem(graphics2D4, categoryItemRendererState6, rectangle2D7, categoryPlot8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis11, categoryDataset14, (int) (short) 1, (-459), (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: BoxAndWhiskerRenderer.drawItem() : the data should be of type BoxAndWhiskerCategoryDataset only.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(tickUnitSource13);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double1 = barRenderer3D0.getXOffset();
        double double2 = barRenderer3D0.getYOffset();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 12.0d + "'", double1 == 12.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.0d + "'", double2 == 8.0d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = piePlot1.getDirection();
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot1.removeChangeListener(plotChangeListener3);
        piePlot1.setLabelLinksVisible(false);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.color.ColorSpace colorSpace8 = color7.getColorSpace();
        piePlot1.setLabelLinkPaint((java.awt.Paint) color7);
        java.awt.Shape shape15 = null;
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Paint paint19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape22 = null;
        java.awt.Stroke stroke23 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color24 = java.awt.Color.black;
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("", "hi!", "hi!", "", true, shape15, false, (java.awt.Paint) color17, false, paint19, stroke20, true, shape22, stroke23, (java.awt.Paint) color24);
        piePlot1.setBaseSectionPaint(paint19);
        org.junit.Assert.assertNotNull(rotation2);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(colorSpace8);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(color24);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.util.Rotation rotation4 = piePlot3.getDirection();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        piePlot3.removeChangeListener(plotChangeListener5);
        piePlot3.setLabelLinksVisible(false);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.color.ColorSpace colorSpace10 = color9.getColorSpace();
        piePlot3.setLabelLinkPaint((java.awt.Paint) color9);
        java.awt.Stroke stroke12 = null;
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        org.jfree.chart.util.Rotation rotation15 = piePlot14.getDirection();
        org.jfree.chart.plot.Plot plot16 = piePlot14.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent17 = null;
        piePlot14.datasetChanged(datasetChangeEvent17);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        piePlot14.drawBackgroundImage(graphics2D19, rectangle2D20);
        java.awt.Paint paint22 = piePlot14.getBaseSectionOutlinePaint();
        java.awt.Paint paint23 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot14.setBaseSectionPaint(paint23);
        java.awt.Color color25 = java.awt.Color.red;
        piePlot14.setNoDataMessagePaint((java.awt.Paint) color25);
        java.awt.Shape shape32 = null;
        java.awt.Color color34 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Paint paint36 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke37 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape39 = null;
        java.awt.Stroke stroke40 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color41 = java.awt.Color.black;
        org.jfree.chart.LegendItem legendItem42 = new org.jfree.chart.LegendItem("", "hi!", "hi!", "", true, shape32, false, (java.awt.Paint) color34, false, paint36, stroke37, true, shape39, stroke40, (java.awt.Paint) color41);
        try {
            org.jfree.chart.plot.IntervalMarker intervalMarker44 = new org.jfree.chart.plot.IntervalMarker((double) 0L, 0.05d, (java.awt.Paint) color9, stroke12, (java.awt.Paint) color25, stroke40, (float) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rotation4);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(colorSpace10);
        org.junit.Assert.assertNotNull(rotation15);
        org.junit.Assert.assertNull(plot16);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(color41);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setMaximumBarWidth(8.0d);
        java.awt.Shape shape9 = null;
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape16 = null;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color18 = java.awt.Color.black;
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("", "hi!", "hi!", "", true, shape9, false, (java.awt.Paint) color11, false, paint13, stroke14, true, shape16, stroke17, (java.awt.Paint) color18);
        barRenderer0.setSeriesStroke(2, stroke17);
        double double21 = barRenderer0.getItemLabelAnchorOffset();
        barRenderer0.setBaseSeriesVisible(false, false);
        java.awt.Paint paint27 = barRenderer0.getItemLabelPaint(5, 10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer28 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator29 = barRenderer28.getBaseToolTipGenerator();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator32 = barRenderer28.getToolTipGenerator((int) (byte) 100, 0);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer33 = barRenderer28.getGradientPaintTransformer();
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer33);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 2.0d + "'", double21 == 2.0d);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNull(categoryToolTipGenerator29);
        org.junit.Assert.assertNull(categoryToolTipGenerator32);
        org.junit.Assert.assertNotNull(gradientPaintTransformer33);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState4 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo3);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean10 = numberAxis9.getAutoRangeStickyZero();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset11 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        try {
            stackedBarRenderer3D1.drawItem(graphics2D2, categoryItemRendererState4, rectangle2D5, categoryPlot6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis9, (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset11, (int) (short) 0, 6, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        minMaxCategoryRenderer0.setBaseCreateEntities(false, true);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState6 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo5);
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str12 = numberAxis11.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange13 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange13, 0.0d);
        org.jfree.data.Range range17 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange13, (double) '#');
        numberAxis11.setDefaultAutoRange((org.jfree.data.Range) dateRange13);
        boolean boolean19 = numberAxis11.isNegativeArrowVisible();
        boolean boolean20 = numberAxis11.isTickMarksVisible();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset21 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        int int22 = defaultStatisticalCategoryDataset21.getColumnCount();
        java.lang.Comparable comparable23 = null;
        int int24 = defaultStatisticalCategoryDataset21.getRowIndex(comparable23);
        try {
            minMaxCategoryRenderer0.drawItem(graphics2D4, categoryItemRendererState6, rectangle2D7, categoryPlot8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis11, (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset21, 0, 10, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(dateRange13);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.util.Rotation rotation4 = piePlot3.getDirection();
        org.jfree.chart.plot.Plot plot5 = piePlot3.getParent();
        org.jfree.chart.plot.Plot plot6 = piePlot3.getRootPlot();
        java.awt.Color color7 = java.awt.Color.MAGENTA;
        piePlot3.setOutlinePaint((java.awt.Paint) color7);
        columnArrangement0.add((org.jfree.chart.block.Block) textTitle1, (java.lang.Object) color7);
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        org.jfree.chart.util.Rotation rotation13 = piePlot12.getDirection();
        org.jfree.chart.plot.Plot plot14 = piePlot12.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent15 = null;
        piePlot12.datasetChanged(datasetChangeEvent15);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        piePlot12.drawBackgroundImage(graphics2D17, rectangle2D18);
        java.awt.Paint paint20 = piePlot12.getBaseSectionOutlinePaint();
        java.awt.Paint paint21 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot12.setBaseSectionPaint(paint21);
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot12);
        jFreeChart23.setTitle("({0}, {1}) = {3} - {4}");
        org.jfree.chart.title.TextTitle textTitle26 = jFreeChart23.getTitle();
        org.jfree.chart.title.TextTitle textTitle27 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment28 = textTitle27.getHorizontalAlignment();
        textTitle27.setExpandToFitSpace(true);
        jFreeChart23.removeSubtitle((org.jfree.chart.title.Title) textTitle27);
        org.jfree.chart.renderer.category.BarRenderer barRenderer32 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator33 = barRenderer32.getBaseToolTipGenerator();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator36 = barRenderer32.getToolTipGenerator((int) (byte) 100, 0);
        boolean boolean37 = barRenderer32.getAutoPopulateSeriesPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition39 = null;
        barRenderer32.setSeriesNegativeItemLabelPosition((int) (byte) 100, itemLabelPosition39, false);
        barRenderer32.setBaseSeriesVisible(false);
        org.jfree.chart.LegendItem legendItem46 = barRenderer32.getLegendItem((int) (short) 10, (int) (short) 100);
        columnArrangement0.add((org.jfree.chart.block.Block) textTitle27, (java.lang.Object) (short) 10);
        org.junit.Assert.assertNotNull(rotation4);
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertNotNull(plot6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(rotation13);
        org.junit.Assert.assertNull(plot14);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(textTitle26);
        org.junit.Assert.assertNotNull(horizontalAlignment28);
        org.junit.Assert.assertNull(categoryToolTipGenerator33);
        org.junit.Assert.assertNull(categoryToolTipGenerator36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNull(legendItem46);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange3, 0.0d);
        org.jfree.data.Range range7 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange3, (double) '#');
        numberAxis1.setDefaultAutoRange((org.jfree.data.Range) dateRange3);
        java.lang.String str9 = dateRange3.toString();
        boolean boolean11 = dateRange3.contains((double) (-1.0f));
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(dateRange3);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str9.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabelToolTip();
        org.jfree.data.Range range3 = null;
        try {
            numberAxis1.setRange(range3, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateBottomOutset((double) (-1L));
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.TOP;
        boolean boolean4 = rectangleInsets0.equals((java.lang.Object) rectangleAnchor3);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor5 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        boolean boolean8 = textAnchor6.equals((java.lang.Object) 'a');
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType10 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition12 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor3, textBlockAnchor5, textAnchor6, (double) (-2208960000000L), categoryLabelWidthType10, (float) 3);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor13 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.text.TextAnchor textAnchor18 = null;
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        java.awt.Shape shape21 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D15, (float) 1, (float) 0, textAnchor18, (double) 100L, textAnchor20);
        java.lang.String str22 = textAnchor20.toString();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType24 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition26 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor3, textBlockAnchor13, textAnchor20, 0.0d, categoryLabelWidthType24, (float) (short) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double29 = rectangleInsets27.calculateBottomOutset((double) (-1L));
        org.jfree.chart.util.RectangleAnchor rectangleAnchor30 = org.jfree.chart.util.RectangleAnchor.TOP;
        boolean boolean31 = rectangleInsets27.equals((java.lang.Object) rectangleAnchor30);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor32 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor33 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        boolean boolean35 = textAnchor33.equals((java.lang.Object) 'a');
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType37 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition39 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor30, textBlockAnchor32, textAnchor33, (double) (-2208960000000L), categoryLabelWidthType37, (float) 3);
        org.jfree.chart.text.TextAnchor textAnchor40 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double44 = rectangleInsets42.calculateBottomOutset((double) (-1L));
        org.jfree.chart.util.RectangleAnchor rectangleAnchor45 = org.jfree.chart.util.RectangleAnchor.TOP;
        boolean boolean46 = rectangleInsets42.equals((java.lang.Object) rectangleAnchor45);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor47 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor48 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        boolean boolean50 = textAnchor48.equals((java.lang.Object) 'a');
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType52 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition54 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor45, textBlockAnchor47, textAnchor48, (double) (-2208960000000L), categoryLabelWidthType52, (float) 3);
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition56 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor3, textBlockAnchor32, textAnchor40, (double) (-1.0f), categoryLabelWidthType52, (float) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rotationAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor5);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(categoryLabelWidthType10);
        org.junit.Assert.assertNotNull(textBlockAnchor13);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNull(shape21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "TextAnchor.CENTER_RIGHT" + "'", str22.equals("TextAnchor.CENTER_RIGHT"));
        org.junit.Assert.assertNotNull(categoryLabelWidthType24);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor32);
        org.junit.Assert.assertNotNull(textAnchor33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(categoryLabelWidthType37);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor47);
        org.junit.Assert.assertNotNull(textAnchor48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(categoryLabelWidthType52);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 0, (double) 'a');
        org.junit.Assert.assertNotNull(verticalAlignment1);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("SortOrder.ASCENDING", graphics2D1, (float) (byte) -1, (float) 1, textAnchor4, (double) ' ', textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier1 = ganttRenderer0.getDrawingSupplier();
        org.junit.Assert.assertNull(drawingSupplier1);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.util.Rotation rotation3 = piePlot2.getDirection();
        org.jfree.chart.plot.Plot plot4 = piePlot2.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        piePlot2.datasetChanged(datasetChangeEvent5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        piePlot2.drawBackgroundImage(graphics2D7, rectangle2D8);
        java.awt.Paint paint10 = piePlot2.getBaseSectionOutlinePaint();
        java.awt.Paint paint11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot2.setBaseSectionPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart13.setBackgroundImageAlpha((float) (byte) 10);
        org.jfree.chart.event.ChartChangeListener chartChangeListener16 = null;
        try {
            jFreeChart13.addChangeListener(chartChangeListener16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (100) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.util.Rotation rotation3 = piePlot2.getDirection();
        org.jfree.chart.plot.Plot plot4 = piePlot2.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        piePlot2.datasetChanged(datasetChangeEvent5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        piePlot2.drawBackgroundImage(graphics2D7, rectangle2D8);
        java.awt.Paint paint10 = piePlot2.getBaseSectionOutlinePaint();
        java.awt.Paint paint11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot2.setBaseSectionPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart13.setTitle("({0}, {1}) = {3} - {4}");
        java.lang.Object obj16 = jFreeChart13.clone();
        jFreeChart13.fireChartChanged();
        org.jfree.chart.event.ChartChangeListener chartChangeListener18 = null;
        try {
            jFreeChart13.addChangeListener(chartChangeListener18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        try {
            org.jfree.chart.axis.AxisState axisState8 = numberAxis3D1.draw(graphics2D2, 1.0E-8d, rectangle2D4, rectangle2D5, rectangleEdge6, plotRenderingInfo7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean2 = numberAxis3D1.isTickMarksVisible();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        boolean boolean4 = numberAxis3D1.isAutoRange();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) '#', (int) (short) -1, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange3, 0.0d);
        org.jfree.data.Range range7 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange3, (double) '#');
        numberAxis1.setDefaultAutoRange((org.jfree.data.Range) dateRange3);
        boolean boolean9 = numberAxis1.isNegativeArrowVisible();
        boolean boolean10 = numberAxis1.isTickMarksVisible();
        java.lang.Object obj11 = numberAxis1.clone();
        numberAxis1.setFixedDimension((double) (byte) 0);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(dateRange3);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        shapeList0.clear();
        java.awt.Shape shape3 = shapeList0.getShape(2);
        org.junit.Assert.assertNull(shape3);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = piePlot1.getDirection();
        org.jfree.chart.plot.Plot plot3 = piePlot1.getParent();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot1.getLegendLabelToolTipGenerator();
        org.junit.Assert.assertNotNull(rotation2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNull(pieSectionLabelGenerator4);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        keyedObjects2D0.removeColumn((java.lang.Comparable) 100.0f);
        java.util.List list3 = keyedObjects2D0.getRowKeys();
        try {
            keyedObjects2D0.removeRow(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list3);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        java.lang.String str1 = licences0.getGPL();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        java.awt.Font font1 = null;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.util.Rotation rotation4 = piePlot3.getDirection();
        org.jfree.chart.plot.Plot plot5 = piePlot3.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = null;
        piePlot3.datasetChanged(datasetChangeEvent6);
        java.awt.Stroke stroke9 = piePlot3.getSectionOutlineStroke((java.lang.Comparable) (short) 100);
        java.awt.Paint paint10 = piePlot3.getNoDataMessagePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.lang.String str12 = rectangleEdge11.toString();
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment14 = textTitle13.getHorizontalAlignment();
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment16 = textTitle15.getHorizontalAlignment();
        java.util.List list25 = null;
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem26 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 1L, (java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.05d, (java.lang.Number) 5, (java.lang.Number) (-1), (java.lang.Number) 100.0d, (java.lang.Number) 0L, list25);
        boolean boolean27 = horizontalAlignment16.equals((java.lang.Object) 1.0f);
        textTitle13.setHorizontalAlignment(horizontalAlignment16);
        org.jfree.chart.util.VerticalAlignment verticalAlignment29 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.renderer.category.BarRenderer barRenderer34 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator35 = null;
        barRenderer34.setBaseToolTipGenerator(categoryToolTipGenerator35, false);
        org.jfree.data.general.PieDataset pieDataset39 = null;
        org.jfree.chart.plot.PiePlot piePlot40 = new org.jfree.chart.plot.PiePlot(pieDataset39);
        org.jfree.chart.util.Rotation rotation41 = piePlot40.getDirection();
        org.jfree.chart.plot.Plot plot42 = piePlot40.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent43 = null;
        piePlot40.datasetChanged(datasetChangeEvent43);
        java.awt.Graphics2D graphics2D45 = null;
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        piePlot40.drawBackgroundImage(graphics2D45, rectangle2D46);
        java.awt.Paint paint48 = piePlot40.getBaseSectionOutlinePaint();
        java.awt.Paint paint49 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot40.setBaseSectionPaint(paint49);
        barRenderer34.setSeriesItemLabelPaint((int) (byte) 0, paint49);
        java.awt.Paint paint53 = barRenderer34.lookupSeriesPaint(0);
        org.jfree.chart.block.BlockBorder blockBorder54 = new org.jfree.chart.block.BlockBorder((double) 100.0f, (double) 100.0f, (double) 'a', 0.0d, paint53);
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = blockBorder54.getInsets();
        try {
            org.jfree.chart.title.TextTitle textTitle56 = new org.jfree.chart.title.TextTitle("NO_CHANGE", font1, paint10, rectangleEdge11, horizontalAlignment16, verticalAlignment29, rectangleInsets55);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'font' argument.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rotation4);
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertNull(stroke9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "RectangleEdge.LEFT" + "'", str12.equals("RectangleEdge.LEFT"));
        org.junit.Assert.assertNotNull(horizontalAlignment14);
        org.junit.Assert.assertNotNull(horizontalAlignment16);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(verticalAlignment29);
        org.junit.Assert.assertNotNull(rotation41);
        org.junit.Assert.assertNull(plot42);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(paint53);
        org.junit.Assert.assertNotNull(rectangleInsets55);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor4 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.text.TextAnchor textAnchor9 = null;
        org.jfree.chart.text.TextAnchor textAnchor11 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        java.awt.Shape shape12 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D6, (float) 1, (float) 0, textAnchor9, (double) 100L, textAnchor11);
        org.jfree.chart.text.TextAnchor textAnchor13 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor4, textAnchor11, textAnchor13, (double) (byte) 100);
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("({0}, {1}) = {3} - {4}", graphics2D1, 1.0f, (float) 100L, textAnchor11, (double) 15, (float) (short) 10, 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelAnchor4);
        org.junit.Assert.assertNotNull(textAnchor11);
        org.junit.Assert.assertNull(shape12);
        org.junit.Assert.assertNotNull(textAnchor13);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        java.awt.Shape shape5 = null;
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape12 = null;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color14 = java.awt.Color.black;
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("", "hi!", "hi!", "", true, shape5, false, (java.awt.Paint) color7, false, paint9, stroke10, true, shape12, stroke13, (java.awt.Paint) color14);
        java.awt.Stroke stroke16 = legendItem15.getLineStroke();
        legendItem15.setSeriesIndex((int) (short) 0);
        int int19 = legendItem15.getDatasetIndex();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.util.Rotation rotation3 = piePlot2.getDirection();
        org.jfree.chart.plot.Plot plot4 = piePlot2.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        piePlot2.datasetChanged(datasetChangeEvent5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        piePlot2.drawBackgroundImage(graphics2D7, rectangle2D8);
        java.awt.Paint paint10 = piePlot2.getBaseSectionOutlinePaint();
        java.awt.Paint paint11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot2.setBaseSectionPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart13.setTitle("({0}, {1}) = {3} - {4}");
        org.jfree.chart.title.TextTitle textTitle16 = jFreeChart13.getTitle();
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment18 = textTitle17.getHorizontalAlignment();
        textTitle17.setExpandToFitSpace(true);
        jFreeChart13.removeSubtitle((org.jfree.chart.title.Title) textTitle17);
        jFreeChart13.setBackgroundImageAlignment(0);
        org.jfree.chart.title.LegendTitle legendTitle24 = null;
        try {
            jFreeChart13.addLegend(legendTitle24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'subtitle' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(textTitle16);
        org.junit.Assert.assertNotNull(horizontalAlignment18);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = piePlot1.getDirection();
        org.jfree.chart.plot.Plot plot3 = piePlot1.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        piePlot1.datasetChanged(datasetChangeEvent4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        piePlot1.drawBackgroundImage(graphics2D6, rectangle2D7);
        boolean boolean9 = piePlot1.getSectionOutlinesVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        piePlot1.setInsets(rectangleInsets10, true);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.Point2D point2D15 = null;
        org.jfree.chart.plot.PlotState plotState16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        try {
            piePlot1.draw(graphics2D13, rectangle2D14, point2D15, plotState16, plotRenderingInfo17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rotation2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(rectangleInsets10);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.chart.ChartColor chartColor6 = new org.jfree.chart.ChartColor((int) (short) 0, (int) (byte) 100, (int) '#');
        boolean boolean7 = spreadsheetDate2.equals((java.lang.Object) (short) 0);
        int int8 = spreadsheetDate2.getDayOfWeek();
        try {
            org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(12, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        shapeList0.clear();
        java.lang.Object obj2 = shapeList0.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        java.awt.Color color0 = java.awt.Color.yellow;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        boxAndWhiskerRenderer0.setFillBox(true);
        double double3 = boxAndWhiskerRenderer0.getItemMargin();
        org.jfree.chart.LegendItem legendItem6 = boxAndWhiskerRenderer0.getLegendItem((int) (short) 10, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNull(legendItem6);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setVersion("SerialDate.weekInMonthToString(): invalid code.");
        org.junit.Assert.assertNotNull(projectInfo0);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            double double1 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = barRenderer0.getBaseToolTipGenerator();
        java.awt.Paint paint2 = barRenderer0.getBaseItemLabelPaint();
        org.junit.Assert.assertNull(categoryToolTipGenerator1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        boxAndWhiskerRenderer0.setFillBox(true);
        org.jfree.chart.LegendItem legendItem5 = boxAndWhiskerRenderer0.getLegendItem(15, 0);
        org.junit.Assert.assertNull(legendItem5);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = piePlot1.getDirection();
        org.jfree.chart.plot.Plot plot3 = piePlot1.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        piePlot1.datasetChanged(datasetChangeEvent4);
        java.awt.Stroke stroke6 = null;
        piePlot1.setLabelOutlineStroke(stroke6);
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray34 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[][] numberArray40 = new java.lang.Number[][] { numberArray14, numberArray19, numberArray24, numberArray29, numberArray34, numberArray39 };
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray40);
        org.jfree.data.general.PieDataset pieDataset43 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset41, (int) (short) 1);
        piePlot1.setDataset(pieDataset43);
        org.jfree.data.general.PieDataset pieDataset48 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset43, (java.lang.Comparable) "", 90.0d, (int) (byte) 1);
        double double49 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset43);
        double double50 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset43);
        org.junit.Assert.assertNotNull(rotation2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(pieDataset43);
        org.junit.Assert.assertNotNull(pieDataset48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = piePlot1.getDirection();
        org.jfree.chart.plot.Plot plot3 = piePlot1.getParent();
        org.jfree.chart.plot.Plot plot4 = piePlot1.getRootPlot();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart(plot4);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = null;
        try {
            java.awt.image.BufferedImage bufferedImage10 = jFreeChart5.createBufferedImage(0, (int) '#', 10, chartRenderingInfo9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (0) and height (35) must be > 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rotation2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(plot4);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator2 = null;
        piePlot1.setToolTipGenerator(pieToolTipGenerator2);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = piePlot1.getURLGenerator();
        org.junit.Assert.assertNull(pieURLGenerator4);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle();
        textTitle2.setNotify(false);
        java.lang.Class<?> wildcardClass5 = textTitle2.getClass();
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle();
        textTitle6.setNotify(false);
        java.lang.Class<?> wildcardClass9 = textTitle6.getClass();
        java.lang.Object obj10 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("VerticalAlignment.TOP", (java.lang.Class) wildcardClass5, (java.lang.Class) wildcardClass9);
        java.io.InputStream inputStream11 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("({0}, {1}) = {3} - {4}", (java.lang.Class) wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNull(obj10);
        org.junit.Assert.assertNull(inputStream11);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        int int1 = defaultStatisticalCategoryDataset0.getColumnCount();
        try {
            java.lang.Number number4 = defaultStatisticalCategoryDataset0.getValue(10, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        double double0 = org.jfree.chart.axis.DateAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE_IN_MILLISECONDS;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.0d + "'", double0 == 2.0d);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = barRenderer0.getBaseToolTipGenerator();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = null;
        barRenderer0.setSeriesURLGenerator(0, categoryURLGenerator3, false);
        java.awt.Font font7 = barRenderer0.getSeriesItemLabelFont((int) '4');
        org.junit.Assert.assertNull(categoryToolTipGenerator1);
        org.junit.Assert.assertNull(font7);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        java.awt.Graphics2D graphics2D0 = null;
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 6);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D3 = new org.jfree.chart.renderer.category.BarRenderer3D();
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 2, (float) 4);
        barRenderer3D3.setSeriesShape((int) (short) 1, shape7, false);
        boolean boolean10 = org.jfree.chart.util.ShapeUtilities.equal(shape2, shape7);
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 6);
        boolean boolean13 = org.jfree.chart.util.ShapeUtilities.equal(shape7, shape12);
        try {
            org.jfree.chart.util.ShapeUtilities.drawRotatedShape(graphics2D0, shape7, (double) 2, (float) (short) -1, (float) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit0 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        org.junit.Assert.assertNotNull(numberTickUnit0);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        boxAndWhiskerRenderer0.setFillBox(true);
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 6);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D5 = new org.jfree.chart.renderer.category.BarRenderer3D();
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 2, (float) 4);
        barRenderer3D5.setSeriesShape((int) (short) 1, shape9, false);
        boolean boolean12 = org.jfree.chart.util.ShapeUtilities.equal(shape4, shape9);
        boxAndWhiskerRenderer0.setBaseShape(shape4);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = piePlot1.getDirection();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator3 = piePlot1.getURLGenerator();
        piePlot1.setMaximumLabelWidth((double) (short) 100);
        java.awt.Paint paint6 = piePlot1.getLabelPaint();
        org.junit.Assert.assertNotNull(rotation2);
        org.junit.Assert.assertNull(pieURLGenerator3);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState6 = stackedBarRenderer3D0.initialise(graphics2D1, rectangle2D2, categoryPlot3, 6, plotRenderingInfo5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.chart.ChartColor chartColor5 = new org.jfree.chart.ChartColor((int) (short) 0, (int) (byte) 100, (int) '#');
        boolean boolean6 = spreadsheetDate1.equals((java.lang.Object) (short) 0);
        int int7 = spreadsheetDate1.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate8 = null;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.chart.ChartColor chartColor14 = new org.jfree.chart.ChartColor((int) (short) 0, (int) (byte) 100, (int) '#');
        boolean boolean15 = spreadsheetDate10.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate18 = spreadsheetDate10.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate17);
        try {
            boolean boolean19 = spreadsheetDate1.isInRange(serialDate8, serialDate18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(serialDate18);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        try {
            java.lang.Number number4 = taskSeriesCollection0.getEndValue((java.lang.Comparable) (byte) -1, (java.lang.Comparable) 10L, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = piePlot1.getDirection();
        org.jfree.chart.plot.Plot plot3 = piePlot1.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        piePlot1.datasetChanged(datasetChangeEvent4);
        double double6 = piePlot1.getLabelGap();
        org.junit.Assert.assertNotNull(rotation2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = piePlot1.getDirection();
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot1.removeChangeListener(plotChangeListener3);
        piePlot1.setLabelLinksVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        piePlot1.handleClick(15, 1, plotRenderingInfo9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        piePlot1.drawBackgroundImage(graphics2D11, rectangle2D12);
        java.lang.Number[] numberArray20 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray30 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray35 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray40 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray45 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[][] numberArray46 = new java.lang.Number[][] { numberArray20, numberArray25, numberArray30, numberArray35, numberArray40, numberArray45 };
        org.jfree.data.category.CategoryDataset categoryDataset47 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray46);
        org.jfree.data.general.PieDataset pieDataset49 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset47, (int) (short) 1);
        piePlot1.setDataset(pieDataset49);
        org.junit.Assert.assertNotNull(rotation2);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertNotNull(pieDataset49);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.lang.Object obj1 = defaultKeyedValues2D0.clone();
        java.lang.Comparable comparable2 = null;
        try {
            int int3 = defaultKeyedValues2D0.getRowIndex(comparable2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition0 = new org.jfree.chart.labels.ItemLabelPosition();
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = piePlot1.getDirection();
        org.jfree.chart.plot.Plot plot3 = piePlot1.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        piePlot1.datasetChanged(datasetChangeEvent4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        piePlot1.drawBackgroundImage(graphics2D6, rectangle2D7);
        java.awt.Paint paint9 = piePlot1.getBackgroundPaint();
        org.junit.Assert.assertNotNull(rotation2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.lang.Object obj1 = shapeList0.clone();
        java.lang.Object obj2 = null;
        boolean boolean3 = shapeList0.equals(obj2);
        java.awt.Shape shape5 = shapeList0.getShape(0);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(shape5);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = barRenderer0.getBaseToolTipGenerator();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = null;
        barRenderer0.setSeriesURLGenerator(0, categoryURLGenerator3, false);
        barRenderer0.setBaseSeriesVisible(true);
        org.junit.Assert.assertNull(categoryToolTipGenerator1);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        java.awt.Paint paint0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePaint(paint0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_UPPER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2958465 + "'", int0 == 2958465);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        barRenderer4.setBaseToolTipGenerator(categoryToolTipGenerator5, false);
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        org.jfree.chart.util.Rotation rotation11 = piePlot10.getDirection();
        org.jfree.chart.plot.Plot plot12 = piePlot10.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent13 = null;
        piePlot10.datasetChanged(datasetChangeEvent13);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        piePlot10.drawBackgroundImage(graphics2D15, rectangle2D16);
        java.awt.Paint paint18 = piePlot10.getBaseSectionOutlinePaint();
        java.awt.Paint paint19 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot10.setBaseSectionPaint(paint19);
        barRenderer4.setSeriesItemLabelPaint((int) (byte) 0, paint19);
        java.awt.Paint paint23 = barRenderer4.lookupSeriesPaint(0);
        org.jfree.chart.block.BlockBorder blockBorder24 = new org.jfree.chart.block.BlockBorder((double) 100.0f, (double) 100.0f, (double) 'a', 0.0d, paint23);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = blockBorder24.getInsets();
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D27 = rectangleInsets25.createOutsetRectangle(rectangle2D26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rotation11);
        org.junit.Assert.assertNull(plot12);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(rectangleInsets25);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.getAutoRangeStickyZero();
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        numberAxis1.setTickMarkStroke(stroke3);
        numberAxis1.setAutoRangeIncludesZero(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(0, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange0, 0.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = rectangleConstraint2.toUnconstrainedHeight();
        org.jfree.data.Range range4 = rectangleConstraint2.getHeightRange();
        org.jfree.data.Range range5 = rectangleConstraint2.getWidthRange();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange9 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange9, 0.0d);
        org.jfree.data.Range range13 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange9, (double) '#');
        numberAxis7.setDefaultAutoRange((org.jfree.data.Range) dateRange9);
        boolean boolean15 = numberAxis7.isNegativeArrowVisible();
        org.jfree.data.time.DateRange dateRange16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis7.setRangeWithMargins((org.jfree.data.Range) dateRange16);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = rectangleConstraint2.toRangeWidth((org.jfree.data.Range) dateRange16);
        org.junit.Assert.assertNotNull(dateRange0);
        org.junit.Assert.assertNotNull(rectangleConstraint3);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(dateRange9);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateRange16);
        org.junit.Assert.assertNotNull(rectangleConstraint18);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = piePlot1.getDirection();
        org.jfree.chart.plot.Plot plot3 = piePlot1.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        piePlot1.datasetChanged(datasetChangeEvent4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        piePlot1.drawBackgroundImage(graphics2D6, rectangle2D7);
        java.awt.Paint paint9 = piePlot1.getBaseSectionOutlinePaint();
        java.awt.Paint paint10 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot1.setBaseSectionPaint(paint10);
        java.awt.Color color12 = java.awt.Color.red;
        piePlot1.setNoDataMessagePaint((java.awt.Paint) color12);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator14 = piePlot1.getURLGenerator();
        java.awt.Paint paint16 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) 15);
        org.junit.Assert.assertNotNull(rotation2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNull(pieURLGenerator14);
        org.junit.Assert.assertNull(paint16);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.util.Rotation rotation3 = piePlot2.getDirection();
        org.jfree.chart.plot.Plot plot4 = piePlot2.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        piePlot2.datasetChanged(datasetChangeEvent5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        piePlot2.drawBackgroundImage(graphics2D7, rectangle2D8);
        java.awt.Paint paint10 = piePlot2.getBaseSectionOutlinePaint();
        java.awt.Paint paint11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot2.setBaseSectionPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart13.setTitle("({0}, {1}) = {3} - {4}");
        org.jfree.chart.title.TextTitle textTitle16 = jFreeChart13.getTitle();
        java.awt.Graphics2D graphics2D17 = null;
        try {
            org.jfree.chart.util.Size2D size2D18 = textTitle16.arrange(graphics2D17);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(textTitle16);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange3, 0.0d);
        org.jfree.data.Range range7 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange3, (double) '#');
        numberAxis1.setDefaultAutoRange((org.jfree.data.Range) dateRange3);
        boolean boolean9 = numberAxis1.isNegativeArrowVisible();
        org.jfree.data.time.DateRange dateRange10 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis1.setRangeWithMargins((org.jfree.data.Range) dateRange10);
        org.jfree.data.Range range12 = numberAxis1.getDefaultAutoRange();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(dateRange3);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateRange10);
        org.junit.Assert.assertNotNull(range12);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getFixedAutoRange();
        java.text.NumberFormat numberFormat3 = numberAxis1.getNumberFormatOverride();
        java.awt.Paint paint4 = numberAxis1.getAxisLinePaint();
        java.lang.String str5 = numberAxis1.getLabelToolTip();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit6 = numberAxis1.getTickUnit();
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle();
        textTitle7.setNotify(false);
        java.lang.Class<?> wildcardClass10 = textTitle7.getClass();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = textTitle7.getPosition();
        boolean boolean12 = numberTickUnit6.equals((java.lang.Object) textTitle7);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNull(numberFormat3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(numberTickUnit6);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange3, 0.0d);
        org.jfree.data.Range range7 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange3, (double) '#');
        numberAxis1.setDefaultAutoRange((org.jfree.data.Range) dateRange3);
        org.jfree.data.Range range11 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange3, 0.0d, (double) (byte) -1);
        java.util.Date date12 = dateRange3.getUpperDate();
        org.jfree.data.Range range14 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange3, 0.0d);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(dateRange3);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(range14);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D1 = new org.jfree.chart.renderer.category.BarRenderer3D();
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 2, (float) 4);
        barRenderer3D1.setSeriesShape((int) (short) 1, shape5, false);
        try {
            org.jfree.chart.util.ShapeUtilities.drawRotatedShape(graphics2D0, shape5, 3.0d, (float) (-1L), (float) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list1 = taskSeriesCollection0.getRowKeys();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.util.Rotation rotation4 = piePlot3.getDirection();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = piePlot3.getURLGenerator();
        java.lang.Object obj6 = piePlot3.clone();
        boolean boolean7 = taskSeriesCollection0.equals(obj6);
        try {
            java.lang.Number number11 = taskSeriesCollection0.getEndValue((int) '#', (int) (byte) 10, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(rotation4);
        org.junit.Assert.assertNull(pieURLGenerator5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.util.Rotation rotation3 = piePlot2.getDirection();
        org.jfree.chart.plot.Plot plot4 = piePlot2.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        piePlot2.datasetChanged(datasetChangeEvent5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        piePlot2.drawBackgroundImage(graphics2D7, rectangle2D8);
        java.awt.Paint paint10 = piePlot2.getBaseSectionOutlinePaint();
        java.awt.Paint paint11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot2.setBaseSectionPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart13.setBackgroundImageAlpha((float) (byte) 10);
        org.jfree.chart.event.ChartProgressListener chartProgressListener16 = null;
        jFreeChart13.removeProgressListener(chartProgressListener16);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer18 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean19 = jFreeChart13.equals((java.lang.Object) lineAndShapeRenderer18);
        org.jfree.chart.title.LegendTitle legendTitle20 = null;
        try {
            jFreeChart13.addLegend(legendTitle20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'subtitle' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange3, 0.0d);
        org.jfree.data.Range range7 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange3, (double) '#');
        numberAxis1.setDefaultAutoRange((org.jfree.data.Range) dateRange3);
        boolean boolean9 = numberAxis1.isNegativeArrowVisible();
        boolean boolean10 = numberAxis1.isTickMarksVisible();
        org.jfree.chart.plot.Plot plot11 = null;
        numberAxis1.setPlot(plot11);
        numberAxis1.setLabel("PlotOrientation.VERTICAL");
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(dateRange3);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 2, (float) 4);
        org.jfree.chart.entity.ChartEntity chartEntity4 = new org.jfree.chart.entity.ChartEntity(shape2, "");
        java.lang.Object obj5 = chartEntity4.clone();
        java.awt.Shape shape6 = chartEntity4.getArea();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, 0.0d);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange4, (double) '#');
        numberAxis2.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        boolean boolean10 = numberAxis2.isNegativeArrowVisible();
        boolean boolean11 = numberAxis2.isTickMarksVisible();
        java.lang.Object obj12 = numberAxis2.clone();
        java.awt.Font font17 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand18 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis2, (double) 11, 0.0d, (double) 'a', (double) 100, font17);
        java.awt.Paint paint19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.text.TextBlock textBlock20 = org.jfree.chart.text.TextUtilities.createTextBlock("NO_CHANGE", font17, paint19);
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment22 = textTitle21.getHorizontalAlignment();
        java.util.List list31 = null;
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem32 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 1L, (java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.05d, (java.lang.Number) 5, (java.lang.Number) (-1), (java.lang.Number) 100.0d, (java.lang.Number) 0L, list31);
        boolean boolean33 = horizontalAlignment22.equals((java.lang.Object) 1.0f);
        textBlock20.setLineAlignment(horizontalAlignment22);
        org.jfree.chart.text.TextLine textLine36 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.text.TextFragment textFragment37 = textLine36.getFirstTextFragment();
        textBlock20.addLine(textLine36);
        java.awt.Graphics2D graphics2D39 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double44 = rectangleInsets42.calculateBottomOutset((double) (-1L));
        org.jfree.chart.util.RectangleAnchor rectangleAnchor45 = org.jfree.chart.util.RectangleAnchor.TOP;
        boolean boolean46 = rectangleInsets42.equals((java.lang.Object) rectangleAnchor45);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor47 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor48 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        boolean boolean50 = textAnchor48.equals((java.lang.Object) 'a');
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType52 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition54 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor45, textBlockAnchor47, textAnchor48, (double) (-2208960000000L), categoryLabelWidthType52, (float) 3);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor55 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Graphics2D graphics2D57 = null;
        org.jfree.chart.text.TextAnchor textAnchor60 = null;
        org.jfree.chart.text.TextAnchor textAnchor62 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        java.awt.Shape shape63 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D57, (float) 1, (float) 0, textAnchor60, (double) 100L, textAnchor62);
        java.lang.String str64 = textAnchor62.toString();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType66 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition68 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor45, textBlockAnchor55, textAnchor62, 0.0d, categoryLabelWidthType66, (float) (short) 100);
        try {
            java.awt.Shape shape72 = textBlock20.calculateBounds(graphics2D39, 0.0f, 0.0f, textBlockAnchor55, (float) 2958465, (float) 2958465, (double) (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(textBlock20);
        org.junit.Assert.assertNotNull(horizontalAlignment22);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(textFragment37);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor47);
        org.junit.Assert.assertNotNull(textAnchor48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(categoryLabelWidthType52);
        org.junit.Assert.assertNotNull(textBlockAnchor55);
        org.junit.Assert.assertNotNull(textAnchor62);
        org.junit.Assert.assertNull(shape63);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "TextAnchor.CENTER_RIGHT" + "'", str64.equals("TextAnchor.CENTER_RIGHT"));
        org.junit.Assert.assertNotNull(categoryLabelWidthType66);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        java.awt.Color color0 = java.awt.Color.GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = piePlot1.getDirection();
        org.jfree.chart.plot.Plot plot3 = piePlot1.getParent();
        org.jfree.chart.plot.Plot plot4 = piePlot1.getRootPlot();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.util.Rotation rotation7 = piePlot6.getDirection();
        org.jfree.chart.plot.Plot plot8 = piePlot6.getParent();
        org.jfree.chart.plot.Plot plot9 = piePlot6.getRootPlot();
        java.awt.Color color10 = java.awt.Color.MAGENTA;
        piePlot6.setOutlinePaint((java.awt.Paint) color10);
        piePlot1.setLabelLinkPaint((java.awt.Paint) color10);
        java.awt.Paint paint13 = piePlot1.getLabelLinkPaint();
        org.junit.Assert.assertNotNull(rotation2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(plot4);
        org.junit.Assert.assertNotNull(rotation7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = lineBorder0.getInsets();
        org.junit.Assert.assertNotNull(rectangleInsets1);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.text.DateFormat dateFormat3 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = new org.jfree.chart.axis.DateTickUnit(0, 0, dateFormat3);
        try {
            keyedObjects0.removeValue((java.lang.Comparable) dateTickUnit4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setDrawOutlines(true);
        lineAndShapeRenderer0.setUseFillPaint(true);
        java.lang.Boolean boolean6 = lineAndShapeRenderer0.getSeriesShapesVisible(2);
        lineAndShapeRenderer0.setSeriesVisible((int) ' ', (java.lang.Boolean) false, true);
        lineAndShapeRenderer0.setSeriesVisible(2, (java.lang.Boolean) true);
        org.junit.Assert.assertNull(boolean6);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = year0.getFirstMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Shape shape1 = org.jfree.chart.util.SerialUtilities.readShape(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        java.awt.Paint paint0 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Last" + "'", str1.equals("Last"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("SortOrder.ASCENDING");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.util.Rotation rotation3 = piePlot2.getDirection();
        org.jfree.chart.plot.Plot plot4 = piePlot2.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        piePlot2.datasetChanged(datasetChangeEvent5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        piePlot2.drawBackgroundImage(graphics2D7, rectangle2D8);
        java.awt.Paint paint10 = piePlot2.getBaseSectionOutlinePaint();
        java.awt.Paint paint11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot2.setBaseSectionPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart13.setTitle("({0}, {1}) = {3} - {4}");
        org.jfree.chart.title.TextTitle textTitle16 = jFreeChart13.getTitle();
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment18 = textTitle17.getHorizontalAlignment();
        textTitle17.setExpandToFitSpace(true);
        jFreeChart13.removeSubtitle((org.jfree.chart.title.Title) textTitle17);
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle();
        textTitle22.setNotify(false);
        jFreeChart13.removeSubtitle((org.jfree.chart.title.Title) textTitle22);
        java.lang.Object obj26 = textTitle22.clone();
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(textTitle16);
        org.junit.Assert.assertNotNull(horizontalAlignment18);
        org.junit.Assert.assertNotNull(obj26);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.lang.String str1 = chartChangeEventType0.toString();
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str1.equals("ChartChangeEventType.GENERAL"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = null;
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange3, 0.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = rectangleConstraint5.toUnconstrainedHeight();
        try {
            org.jfree.chart.util.Size2D size2D7 = columnArrangement0.arrange(blockContainer1, graphics2D2, rectangleConstraint5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateRange3);
        org.junit.Assert.assertNotNull(rectangleConstraint6);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        java.lang.Object obj1 = null;
        boolean boolean2 = axisLocation0.equals(obj1);
        java.lang.String str3 = axisLocation0.toString();
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "AxisLocation.TOP_OR_LEFT" + "'", str3.equals("AxisLocation.TOP_OR_LEFT"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator4 = null;
        piePlot3.setToolTipGenerator(pieToolTipGenerator4);
        numberAxis3D1.setPlot((org.jfree.chart.plot.Plot) piePlot3);
        org.jfree.chart.block.ColumnArrangement columnArrangement7 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle();
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        org.jfree.chart.util.Rotation rotation11 = piePlot10.getDirection();
        org.jfree.chart.plot.Plot plot12 = piePlot10.getParent();
        org.jfree.chart.plot.Plot plot13 = piePlot10.getRootPlot();
        java.awt.Color color14 = java.awt.Color.MAGENTA;
        piePlot10.setOutlinePaint((java.awt.Paint) color14);
        columnArrangement7.add((org.jfree.chart.block.Block) textTitle8, (java.lang.Object) color14);
        piePlot3.setBackgroundPaint((java.awt.Paint) color14);
        org.jfree.data.general.PieDataset pieDataset19 = null;
        org.jfree.chart.plot.PiePlot piePlot20 = new org.jfree.chart.plot.PiePlot(pieDataset19);
        org.jfree.chart.util.Rotation rotation21 = piePlot20.getDirection();
        org.jfree.chart.plot.Plot plot22 = piePlot20.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent23 = null;
        piePlot20.datasetChanged(datasetChangeEvent23);
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        piePlot20.drawBackgroundImage(graphics2D25, rectangle2D26);
        java.awt.Paint paint28 = piePlot20.getBaseSectionOutlinePaint();
        java.awt.Paint paint29 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot20.setBaseSectionPaint(paint29);
        org.jfree.chart.JFreeChart jFreeChart31 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot20);
        jFreeChart31.setTitle("({0}, {1}) = {3} - {4}");
        org.jfree.chart.title.TextTitle textTitle34 = jFreeChart31.getTitle();
        java.awt.Stroke stroke35 = jFreeChart31.getBorderStroke();
        piePlot3.setBaseSectionOutlineStroke(stroke35);
        java.lang.String str37 = piePlot3.getNoDataMessage();
        org.junit.Assert.assertNotNull(rotation11);
        org.junit.Assert.assertNull(plot12);
        org.junit.Assert.assertNotNull(plot13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(rotation21);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(textTitle34);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNull(str37);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (4) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 2, (float) 4);
        org.jfree.chart.entity.ChartEntity chartEntity4 = new org.jfree.chart.entity.ChartEntity(shape2, "");
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        chartEntity4.setArea(shape5);
        java.lang.String str7 = chartEntity4.toString();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ChartEntity: tooltip = " + "'", str7.equals("ChartEntity: tooltip = "));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("SortOrder.ASCENDING");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator1 = null;
        barRenderer3D0.setLegendItemURLGenerator(categorySeriesLabelGenerator1);
        org.jfree.chart.LegendItem legendItem5 = barRenderer3D0.getLegendItem((int) (short) 1, 6);
        org.junit.Assert.assertNull(legendItem5);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        float float0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.5f + "'", float0 == 0.5f);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        int int0 = org.jfree.data.time.SerialDate.FOURTH_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.util.Rotation rotation3 = piePlot2.getDirection();
        org.jfree.chart.plot.Plot plot4 = piePlot2.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        piePlot2.datasetChanged(datasetChangeEvent5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        piePlot2.drawBackgroundImage(graphics2D7, rectangle2D8);
        java.awt.Paint paint10 = piePlot2.getBaseSectionOutlinePaint();
        java.awt.Paint paint11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot2.setBaseSectionPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart13.setTitle("({0}, {1}) = {3} - {4}");
        org.jfree.chart.title.TextTitle textTitle16 = jFreeChart13.getTitle();
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment18 = textTitle17.getHorizontalAlignment();
        textTitle17.setExpandToFitSpace(true);
        jFreeChart13.removeSubtitle((org.jfree.chart.title.Title) textTitle17);
        org.jfree.chart.event.ChartChangeListener chartChangeListener22 = null;
        try {
            jFreeChart13.addChangeListener(chartChangeListener22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(textTitle16);
        org.junit.Assert.assertNotNull(horizontalAlignment18);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.time.TimePeriod timePeriod1 = null;
        org.jfree.data.gantt.Task task2 = new org.jfree.data.gantt.Task("hi!", timePeriod1);
        java.lang.Object obj3 = null;
        boolean boolean4 = task2.equals(obj3);
        org.jfree.data.time.TimePeriod timePeriod6 = null;
        org.jfree.data.gantt.Task task7 = new org.jfree.data.gantt.Task("hi!", timePeriod6);
        java.lang.Object obj8 = null;
        boolean boolean9 = task7.equals(obj8);
        task7.setPercentComplete((java.lang.Double) 90.0d);
        task2.removeSubtask(task7);
        java.lang.Object obj13 = task2.clone();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, 0.0d);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange4, (double) '#');
        numberAxis2.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        boolean boolean10 = numberAxis2.isNegativeArrowVisible();
        boolean boolean11 = numberAxis2.isTickMarksVisible();
        java.lang.Object obj12 = numberAxis2.clone();
        java.awt.Font font17 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand18 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis2, (double) 11, 0.0d, (double) 'a', (double) 100, font17);
        boxAndWhiskerRenderer0.setBaseItemLabelFont(font17);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(font17);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = barRenderer0.getBaseToolTipGenerator();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator4 = barRenderer0.getToolTipGenerator((int) (byte) 100, 0);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer5 = barRenderer0.getGradientPaintTransformer();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        org.jfree.chart.util.Rotation rotation9 = piePlot8.getDirection();
        org.jfree.chart.plot.Plot plot10 = piePlot8.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent11 = null;
        piePlot8.datasetChanged(datasetChangeEvent11);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        piePlot8.drawBackgroundImage(graphics2D13, rectangle2D14);
        java.awt.Paint paint16 = piePlot8.getBaseSectionOutlinePaint();
        java.awt.Paint paint17 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot8.setBaseSectionPaint(paint17);
        boolean boolean19 = piePlot8.getIgnoreZeroValues();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod((long) 10, (long) 'a');
        java.util.Date date23 = simpleTimePeriod22.getEnd();
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date23);
        java.util.Date date25 = month24.getStart();
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double28 = numberAxis27.getFixedAutoRange();
        java.awt.Stroke stroke29 = numberAxis27.getTickMarkStroke();
        piePlot8.setSectionOutlineStroke((java.lang.Comparable) month24, stroke29);
        barRenderer0.setSeriesStroke(0, stroke29);
        org.junit.Assert.assertNull(categoryToolTipGenerator1);
        org.junit.Assert.assertNull(categoryToolTipGenerator4);
        org.junit.Assert.assertNotNull(gradientPaintTransformer5);
        org.junit.Assert.assertNotNull(rotation9);
        org.junit.Assert.assertNull(plot10);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(stroke29);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("SerialDate.weekInMonthToString(): invalid code.", graphics2D1, (float) (short) 10, 0.0f, (double) (short) 0, (float) (byte) 1, (float) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        barRenderer4.setBaseToolTipGenerator(categoryToolTipGenerator5, false);
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        org.jfree.chart.util.Rotation rotation11 = piePlot10.getDirection();
        org.jfree.chart.plot.Plot plot12 = piePlot10.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent13 = null;
        piePlot10.datasetChanged(datasetChangeEvent13);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        piePlot10.drawBackgroundImage(graphics2D15, rectangle2D16);
        java.awt.Paint paint18 = piePlot10.getBaseSectionOutlinePaint();
        java.awt.Paint paint19 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot10.setBaseSectionPaint(paint19);
        barRenderer4.setSeriesItemLabelPaint((int) (byte) 0, paint19);
        java.awt.Paint paint23 = barRenderer4.lookupSeriesPaint(0);
        org.jfree.chart.block.BlockBorder blockBorder24 = new org.jfree.chart.block.BlockBorder((double) 100.0f, (double) 100.0f, (double) 'a', 0.0d, paint23);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = blockBorder24.getInsets();
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        try {
            blockBorder24.draw(graphics2D26, rectangle2D27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rotation11);
        org.junit.Assert.assertNull(plot12);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(rectangleInsets25);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getFixedAutoRange();
        java.text.NumberFormat numberFormat3 = numberAxis1.getNumberFormatOverride();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator8 = null;
        piePlot7.setToolTipGenerator(pieToolTipGenerator8);
        numberAxis3D5.setPlot((org.jfree.chart.plot.Plot) piePlot7);
        numberAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot7);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator12 = piePlot7.getURLGenerator();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNull(numberFormat3);
        org.junit.Assert.assertNull(pieURLGenerator12);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D0.setAutoPopulateSeriesPaint(false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        keyedObjects2D0.removeColumn((java.lang.Comparable) 100.0f);
        java.util.List list3 = keyedObjects2D0.getRowKeys();
        java.lang.Comparable comparable4 = null;
        keyedObjects2D0.removeObject(comparable4, (java.lang.Comparable) 10);
        try {
            java.lang.Comparable comparable8 = keyedObjects2D0.getColumnKey(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list3);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.LegendItem legendItem3 = stackedAreaRenderer0.getLegendItem((int) 'a', 0);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = null;
        stackedAreaRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator4, true);
        boolean boolean8 = stackedAreaRenderer0.isSeriesVisibleInLegend(0);
        org.jfree.chart.LegendItem legendItem11 = stackedAreaRenderer0.getLegendItem(1, (int) ' ');
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(legendItem11);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        try {
            java.awt.geom.Point2D point2D2 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.zoomRange(0.0d, 10.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis0.setTickMarkPosition(dateTickMarkPosition4);
        try {
            dateAxis0.setRangeAboutValue(32.0d, (-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (32.5) <= upper (31.5).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list1 = defaultStatisticalCategoryDataset0.getColumnKeys();
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        int int3 = defaultStatisticalCategoryDataset0.getRowCount();
        try {
            java.lang.Comparable comparable5 = defaultStatisticalCategoryDataset0.getRowKey((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0.0d + "'", number2.equals(0.0d));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = piePlot1.getDirection();
        org.jfree.chart.plot.Plot plot3 = piePlot1.getParent();
        org.jfree.chart.plot.Plot plot4 = piePlot1.getRootPlot();
        java.awt.Color color5 = java.awt.Color.MAGENTA;
        piePlot1.setOutlinePaint((java.awt.Paint) color5);
        java.awt.Stroke stroke7 = piePlot1.getOutlineStroke();
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.awt.geom.Point2D point2D10 = null;
        org.jfree.chart.plot.PlotState plotState11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        try {
            piePlot1.draw(graphics2D8, rectangle2D9, point2D10, plotState11, plotRenderingInfo12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rotation2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(plot4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        barRenderer4.setBaseToolTipGenerator(categoryToolTipGenerator5, false);
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        org.jfree.chart.util.Rotation rotation11 = piePlot10.getDirection();
        org.jfree.chart.plot.Plot plot12 = piePlot10.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent13 = null;
        piePlot10.datasetChanged(datasetChangeEvent13);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        piePlot10.drawBackgroundImage(graphics2D15, rectangle2D16);
        java.awt.Paint paint18 = piePlot10.getBaseSectionOutlinePaint();
        java.awt.Paint paint19 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot10.setBaseSectionPaint(paint19);
        barRenderer4.setSeriesItemLabelPaint((int) (byte) 0, paint19);
        java.awt.Paint paint23 = barRenderer4.lookupSeriesPaint(0);
        org.jfree.chart.block.BlockBorder blockBorder24 = new org.jfree.chart.block.BlockBorder((double) 100.0f, (double) 100.0f, (double) 'a', 0.0d, paint23);
        org.jfree.chart.renderer.category.BarRenderer barRenderer25 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator26 = barRenderer25.getBaseToolTipGenerator();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator29 = barRenderer25.getToolTipGenerator((int) (byte) 100, 0);
        java.awt.Color color31 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        int int32 = color31.getRed();
        barRenderer25.setSeriesPaint(11, (java.awt.Paint) color31, true);
        boolean boolean35 = blockBorder24.equals((java.lang.Object) color31);
        org.junit.Assert.assertNotNull(rotation11);
        org.junit.Assert.assertNull(plot12);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNull(categoryToolTipGenerator26);
        org.junit.Assert.assertNull(categoryToolTipGenerator29);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange3, 0.0d);
        org.jfree.data.Range range7 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange3, (double) '#');
        numberAxis1.setDefaultAutoRange((org.jfree.data.Range) dateRange3);
        boolean boolean9 = numberAxis1.isNegativeArrowVisible();
        boolean boolean10 = numberAxis1.isTickMarksVisible();
        java.lang.Object obj11 = numberAxis1.clone();
        numberAxis1.setAutoRangeIncludesZero(true);
        try {
            numberAxis1.setRangeWithMargins((double) 1577865599999L, (double) 2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (1.577865599999E12) <= upper (2958465.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(dateRange3);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = piePlot1.getDirection();
        org.jfree.chart.plot.Plot plot3 = piePlot1.getParent();
        org.jfree.chart.plot.Plot plot4 = piePlot1.getRootPlot();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart(plot4);
        float float6 = plot4.getForegroundAlpha();
        org.junit.Assert.assertNotNull(rotation2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(plot4);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        java.lang.String[] strArray2 = new java.lang.String[] { "SerialDate.weekInMonthToString(): invalid code.", "VerticalAlignment.TOP" };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (short) 1, 100.0f, 2, (short) -1, (-1.0f) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { (short) 1, 100.0f, 2, (short) -1, (-1.0f) };
        java.lang.Number[][] numberArray17 = new java.lang.Number[][] { numberArray10, numberArray16 };
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray17);
        java.lang.Number[][] numberArray19 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset20 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray2, numberArray17, numberArray19);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        long long22 = year21.getLastMillisecond();
        try {
            java.lang.Number number24 = defaultIntervalCategoryDataset20.getValue((java.lang.Comparable) year21, (java.lang.Comparable) 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(categoryDataset18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577865599999L + "'", long22 == 1577865599999L);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        int int1 = defaultStatisticalCategoryDataset0.getColumnCount();
        try {
            java.lang.Comparable comparable3 = defaultStatisticalCategoryDataset0.getColumnKey((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        java.awt.Paint paint1 = numberAxis3D0.getTickMarkPaint();
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list1 = taskSeriesCollection0.getRowKeys();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.util.Rotation rotation4 = piePlot3.getDirection();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = piePlot3.getURLGenerator();
        java.lang.Object obj6 = piePlot3.clone();
        boolean boolean7 = taskSeriesCollection0.equals(obj6);
        try {
            java.lang.Comparable comparable9 = taskSeriesCollection0.getSeriesKey((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(rotation4);
        org.junit.Assert.assertNull(pieURLGenerator5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator1 = null;
        barRenderer3D0.setLegendItemURLGenerator(categorySeriesLabelGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState5 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo4);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D8 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double11 = numberAxis10.getFixedAutoRange();
        boolean boolean12 = numberAxis10.isAxisLineVisible();
        double double13 = numberAxis10.getLabelAngle();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection14 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list15 = taskSeriesCollection14.getRowKeys();
        try {
            barRenderer3D0.drawItem(graphics2D3, categoryItemRendererState5, rectangle2D6, categoryPlot7, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D8, (org.jfree.chart.axis.ValueAxis) numberAxis10, (org.jfree.data.category.CategoryDataset) taskSeriesCollection14, (int) 'a', (int) (short) 10, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(list15);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setBaseLinesVisible(true);
        boolean boolean3 = lineAndShapeRenderer0.getBaseItemLabelsVisible();
        int int4 = lineAndShapeRenderer0.getPassCount();
        boolean boolean5 = lineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) (short) 1);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list1 = taskSeriesCollection0.getRowKeys();
        int int3 = taskSeriesCollection0.indexOf((java.lang.Comparable) "({0}, {1}) = {2}");
        int int4 = taskSeriesCollection0.getColumnCount();
        try {
            java.lang.Number number7 = taskSeriesCollection0.getPercentComplete((java.lang.Comparable) "", (java.lang.Comparable) "SerialDate.weekInMonthToString(): invalid code.");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "({0}, {1}) = {3} - {4}", "", image3, "hi!", "hi!", "({0}, {1}) = {3} - {4}");
        java.awt.Image image8 = null;
        projectInfo7.setLogo(image8);
        java.lang.String str10 = projectInfo7.getInfo();
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "({0}, {1}) = {3} - {4}", "", image3, "hi!", "hi!", "({0}, {1}) = {3} - {4}");
        java.util.List list8 = projectInfo7.getContributors();
        org.jfree.chart.ui.Library library9 = null;
        try {
            projectInfo7.addLibrary(library9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(list8);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator1, false);
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.util.Rotation rotation7 = piePlot6.getDirection();
        org.jfree.chart.plot.Plot plot8 = piePlot6.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent9 = null;
        piePlot6.datasetChanged(datasetChangeEvent9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        piePlot6.drawBackgroundImage(graphics2D11, rectangle2D12);
        java.awt.Paint paint14 = piePlot6.getBaseSectionOutlinePaint();
        java.awt.Paint paint15 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot6.setBaseSectionPaint(paint15);
        barRenderer0.setSeriesItemLabelPaint((int) (byte) 0, paint15);
        boolean boolean18 = barRenderer0.getAutoPopulateSeriesShape();
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator20 = new org.jfree.chart.urls.StandardCategoryURLGenerator("RectangleEdge.LEFT");
        barRenderer0.setBaseURLGenerator((org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator20);
        java.lang.Number[] numberArray28 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray43 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray48 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray28, numberArray33, numberArray38, numberArray43, numberArray48, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray54);
        try {
            java.lang.String str58 = standardCategoryURLGenerator20.generateURL(categoryDataset55, (int) (byte) 0, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 4");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(rotation7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(numberArray48);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("", "");
        java.lang.String str3 = contributor2.getName();
        java.lang.String str4 = contributor2.getEmail();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            rectangleInsets0.trim(rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.zoomRange(0.0d, 10.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis0.setTickMarkPosition(dateTickMarkPosition4);
        java.lang.Object obj6 = dateAxis0.clone();
        java.util.Date date7 = null;
        try {
            dateAxis0.setMaximumDate(date7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'maximumDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.chart.ChartColor chartColor5 = new org.jfree.chart.ChartColor((int) (short) 0, (int) (byte) 100, (int) '#');
        boolean boolean6 = spreadsheetDate1.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate9 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(100);
        int int12 = spreadsheetDate11.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.chart.ChartColor chartColor18 = new org.jfree.chart.ChartColor((int) (short) 0, (int) (byte) 100, (int) '#');
        boolean boolean19 = spreadsheetDate14.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate22 = spreadsheetDate14.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.chart.ChartColor chartColor28 = new org.jfree.chart.ChartColor((int) (short) 0, (int) (byte) 100, (int) '#');
        boolean boolean29 = spreadsheetDate24.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate32 = spreadsheetDate24.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SerialDate serialDate34 = serialDate32.getPreviousDayOfWeek(6);
        boolean boolean35 = spreadsheetDate11.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate21, serialDate34);
        boolean boolean36 = spreadsheetDate8.isOn(serialDate34);
        try {
            org.jfree.data.time.SerialDate serialDate38 = serialDate34.getNearestDayOfWeek((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        java.util.List list8 = null;
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem9 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 1L, (java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.05d, (java.lang.Number) 5, (java.lang.Number) (-1), (java.lang.Number) 100.0d, (java.lang.Number) 0L, list8);
        java.lang.Number number10 = boxAndWhiskerItem9.getMinOutlier();
        java.lang.Number number11 = boxAndWhiskerItem9.getMinRegularValue();
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 100.0d + "'", number10.equals(100.0d));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 5 + "'", number11.equals(5));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.util.Rotation rotation3 = piePlot2.getDirection();
        org.jfree.chart.plot.Plot plot4 = piePlot2.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        piePlot2.datasetChanged(datasetChangeEvent5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        piePlot2.drawBackgroundImage(graphics2D7, rectangle2D8);
        java.awt.Paint paint10 = piePlot2.getBaseSectionOutlinePaint();
        java.awt.Paint paint11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot2.setBaseSectionPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart13.setTitle("({0}, {1}) = {3} - {4}");
        java.lang.Object obj16 = jFreeChart13.clone();
        jFreeChart13.fireChartChanged();
        jFreeChart13.setNotify(false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo23 = null;
        java.awt.image.BufferedImage bufferedImage24 = jFreeChart13.createBufferedImage((int) (byte) 10, 100, 12, chartRenderingInfo23);
        try {
            org.jfree.chart.title.Title title26 = jFreeChart13.getSubtitle(6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(bufferedImage24);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        java.awt.Paint paint1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        barRenderer2.setBaseToolTipGenerator(categoryToolTipGenerator3, false);
        boolean boolean6 = barRenderer2.getBaseCreateEntities();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        barRenderer2.setSeriesStroke((int) (short) 100, stroke8, false);
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker(0.0d, paint1, stroke8);
        java.awt.Paint paint12 = valueMarker11.getPaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = valueMarker11.getLabelAnchor();
        float float14 = valueMarker11.getAlpha();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 1.0f + "'", float14 == 1.0f);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.ASCENDING;
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer1.setMaximumBarWidth(8.0d);
        java.awt.Shape shape10 = null;
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Paint paint14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape17 = null;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color19 = java.awt.Color.black;
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("", "hi!", "hi!", "", true, shape10, false, (java.awt.Paint) color12, false, paint14, stroke15, true, shape17, stroke18, (java.awt.Paint) color19);
        barRenderer1.setSeriesStroke(2, stroke18);
        double double22 = barRenderer1.getItemLabelAnchorOffset();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition25 = barRenderer1.getNegativeItemLabelPosition(5, 6);
        boolean boolean26 = sortOrder0.equals((java.lang.Object) 5);
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 2.0d + "'", double22 == 2.0d);
        org.junit.Assert.assertNotNull(itemLabelPosition25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.LegendItem legendItem3 = stackedAreaRenderer0.getLegendItem((int) 'a', 0);
        java.awt.Shape shape5 = null;
        stackedAreaRenderer0.setSeriesShape((int) '4', shape5, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = stackedAreaRenderer0.getSeriesPositiveItemLabelPosition((int) (byte) 1);
        boolean boolean10 = stackedAreaRenderer0.getRenderAsPercentages();
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        java.lang.String str0 = org.jfree.chart.labels.StandardCategoryToolTipGenerator.DEFAULT_TOOL_TIP_FORMAT_STRING;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "({0}, {1}) = {2}" + "'", str0.equals("({0}, {1}) = {2}"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.LegendItem legendItem3 = stackedAreaRenderer0.getLegendItem((int) 'a', 0);
        java.awt.Paint paint4 = null;
        try {
            stackedAreaRenderer0.setBaseOutlinePaint(paint4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(legendItem3);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_90;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions0, categoryLabelPosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'top' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(0, (int) '#', (int) (byte) 10);
        java.awt.image.ColorModel colorModel4 = null;
        java.awt.Rectangle rectangle5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.geom.AffineTransform affineTransform7 = null;
        java.awt.RenderingHints renderingHints8 = null;
        java.awt.PaintContext paintContext9 = chartColor3.createContext(colorModel4, rectangle5, rectangle2D6, affineTransform7, renderingHints8);
        org.junit.Assert.assertNotNull(paintContext9);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange3, 0.0d);
        org.jfree.data.Range range7 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange3, (double) '#');
        numberAxis1.setDefaultAutoRange((org.jfree.data.Range) dateRange3);
        boolean boolean9 = numberAxis1.isNegativeArrowVisible();
        numberAxis1.setTickMarksVisible(true);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(dateRange3);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = piePlot1.getDirection();
        org.jfree.chart.plot.Plot plot3 = piePlot1.getParent();
        org.jfree.chart.plot.Plot plot4 = piePlot1.getRootPlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator5 = piePlot1.getLegendLabelGenerator();
        piePlot1.setCircular(true);
        org.junit.Assert.assertNotNull(rotation2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(plot4);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator5);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        int int3 = lineAndShapeRenderer2.getPassCount();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        boolean boolean1 = boxAndWhiskerRenderer0.getBaseItemLabelsVisible();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState7 = boxAndWhiskerRenderer0.initialise(graphics2D2, rectangle2D3, categoryPlot4, 5, plotRenderingInfo6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        java.awt.Paint paint0 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_WALL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        int int1 = keyedObjects0.getItemCount();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod((long) 10, (long) 'a');
        java.util.Date date5 = simpleTimePeriod4.getEnd();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date5);
        java.util.Date date7 = month6.getStart();
        long long8 = month6.getMiddleMillisecond();
        int int9 = keyedObjects0.getIndex((java.lang.Comparable) month6);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1310400001L) + "'", long8 == (-1310400001L));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list1 = defaultStatisticalCategoryDataset0.getColumnKeys();
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0.0d + "'", number2.equals(0.0d));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = piePlot1.getDirection();
        org.jfree.chart.plot.Plot plot3 = piePlot1.getParent();
        org.jfree.chart.plot.Plot plot4 = piePlot1.getRootPlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator5 = piePlot1.getLegendLabelGenerator();
        piePlot1.setForegroundAlpha((float) 10);
        org.junit.Assert.assertNotNull(rotation2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(plot4);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator5);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = barRenderer0.getBaseToolTipGenerator();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator4 = barRenderer0.getToolTipGenerator((int) (byte) 100, 0);
        boolean boolean5 = barRenderer0.getAutoPopulateSeriesPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = null;
        barRenderer0.setSeriesNegativeItemLabelPosition((int) (byte) 100, itemLabelPosition7, false);
        barRenderer0.setBaseSeriesVisible(false);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState17 = barRenderer0.initialise(graphics2D12, rectangle2D13, categoryPlot14, (int) (short) 0, plotRenderingInfo16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator1);
        org.junit.Assert.assertNull(categoryToolTipGenerator4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator2 = barRenderer3D0.getSeriesToolTipGenerator((int) ' ');
        org.junit.Assert.assertNull(categoryToolTipGenerator2);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_MINIMUM_ARC_ANGLE_TO_DRAW;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-5d + "'", double0 == 1.0E-5d);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D1.setRenderAsPercentages(true);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState9 = stackedBarRenderer3D1.initialise(graphics2D4, rectangle2D5, categoryPlot6, (int) '#', plotRenderingInfo8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        int int1 = legendItemCollection0.getItemCount();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator4 = null;
        piePlot3.setToolTipGenerator(pieToolTipGenerator4);
        org.jfree.chart.LegendItemCollection legendItemCollection6 = piePlot3.getLegendItems();
        java.lang.Object obj7 = legendItemCollection6.clone();
        legendItemCollection0.addAll(legendItemCollection6);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(legendItemCollection6);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.time.TimePeriod timePeriod1 = null;
        org.jfree.data.gantt.Task task2 = new org.jfree.data.gantt.Task("hi!", timePeriod1);
        java.lang.Object obj3 = null;
        boolean boolean4 = task2.equals(obj3);
        org.jfree.data.time.TimePeriod timePeriod6 = null;
        org.jfree.data.gantt.Task task7 = new org.jfree.data.gantt.Task("hi!", timePeriod6);
        java.lang.Object obj8 = null;
        boolean boolean9 = task7.equals(obj8);
        task7.setPercentComplete((java.lang.Double) 90.0d);
        task2.removeSubtask(task7);
        java.lang.String str13 = task2.getDescription();
        java.lang.Object obj14 = task2.clone();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.zoomRange(0.0d, 10.0d);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str6 = numberAxis5.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange7 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange7, 0.0d);
        org.jfree.data.Range range11 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange7, (double) '#');
        numberAxis5.setDefaultAutoRange((org.jfree.data.Range) dateRange7);
        org.jfree.data.Range range15 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange7, 0.0d, (double) (byte) -1);
        java.util.Date date16 = dateRange7.getUpperDate();
        org.jfree.chart.text.TextAnchor textAnchor18 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.text.TextAnchor textAnchor23 = null;
        org.jfree.chart.text.TextAnchor textAnchor25 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        java.awt.Shape shape26 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D20, (float) 1, (float) 0, textAnchor23, (double) 100L, textAnchor25);
        java.lang.String str27 = textAnchor25.toString();
        org.jfree.chart.axis.DateTick dateTick29 = new org.jfree.chart.axis.DateTick(date16, "TextAnchor.CENTER_RIGHT", textAnchor18, textAnchor25, (double) (-1.0f));
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean32 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge31);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge31);
        try {
            double double34 = dateAxis0.dateToJava2D(date16, rectangle2D30, rectangleEdge33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(dateRange7);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(textAnchor18);
        org.junit.Assert.assertNotNull(textAnchor25);
        org.junit.Assert.assertNull(shape26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "TextAnchor.CENTER_RIGHT" + "'", str27.equals("TextAnchor.CENTER_RIGHT"));
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(rectangleEdge33);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange3, 0.0d);
        org.jfree.data.Range range7 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange3, (double) '#');
        numberAxis1.setDefaultAutoRange((org.jfree.data.Range) dateRange3);
        boolean boolean9 = numberAxis1.isNegativeArrowVisible();
        boolean boolean10 = numberAxis1.isTickMarksVisible();
        java.lang.Object obj11 = numberAxis1.clone();
        numberAxis1.setAutoRangeIncludesZero(true);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        org.jfree.chart.util.Rotation rotation16 = piePlot15.getDirection();
        org.jfree.chart.plot.Plot plot17 = piePlot15.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent18 = null;
        piePlot15.datasetChanged(datasetChangeEvent18);
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        piePlot15.drawBackgroundImage(graphics2D20, rectangle2D21);
        java.awt.Paint paint23 = piePlot15.getBaseSectionOutlinePaint();
        numberAxis1.setLabelPaint(paint23);
        numberAxis1.setFixedAutoRange((double) (-459));
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(dateRange3);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(rotation16);
        org.junit.Assert.assertNull(plot17);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        java.awt.Shape shape5 = null;
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape12 = null;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color14 = java.awt.Color.black;
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("", "hi!", "hi!", "", true, shape5, false, (java.awt.Paint) color7, false, paint9, stroke10, true, shape12, stroke13, (java.awt.Paint) color14);
        java.lang.Number[] numberArray23 = new java.lang.Number[] { (short) 1, 100.0f, 2, (short) -1, (-1.0f) };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { (short) 1, 100.0f, 2, (short) -1, (-1.0f) };
        java.lang.Number[][] numberArray30 = new java.lang.Number[][] { numberArray23, numberArray29 };
        org.jfree.data.category.CategoryDataset categoryDataset31 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray30);
        legendItem15.setDataset((org.jfree.data.general.Dataset) categoryDataset31);
        legendItem15.setSeriesIndex((int) (byte) 10);
        legendItem15.setDatasetIndex((int) (short) 1);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(categoryDataset31);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("hi!", "({0}, {1}) = {3} - {4}", "", "({0}, {1}) = {3} - {4}");
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer1 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean2 = textAnchor0.equals((java.lang.Object) intervalBarRenderer1);
        intervalBarRenderer1.setBaseItemLabelsVisible(false, false);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.cursorLeft((double) (byte) 0);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_45;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list1 = taskSeriesCollection0.getRowKeys();
        int int3 = taskSeriesCollection0.indexOf((java.lang.Comparable) "({0}, {1}) = {2}");
        int int4 = taskSeriesCollection0.getColumnCount();
        try {
            java.lang.Comparable comparable6 = taskSeriesCollection0.getSeriesKey((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str4 = numberAxis3.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange5 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange5, 0.0d);
        org.jfree.data.Range range9 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange5, (double) '#');
        numberAxis3.setDefaultAutoRange((org.jfree.data.Range) dateRange5);
        boolean boolean11 = numberAxis3.isNegativeArrowVisible();
        boolean boolean12 = numberAxis3.isTickMarksVisible();
        java.lang.Object obj13 = numberAxis3.clone();
        numberAxis3.setAutoRangeIncludesZero(true);
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot(pieDataset16);
        org.jfree.chart.util.Rotation rotation18 = piePlot17.getDirection();
        org.jfree.chart.plot.Plot plot19 = piePlot17.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent20 = null;
        piePlot17.datasetChanged(datasetChangeEvent20);
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        piePlot17.drawBackgroundImage(graphics2D22, rectangle2D23);
        java.awt.Paint paint25 = piePlot17.getBaseSectionOutlinePaint();
        numberAxis3.setLabelPaint(paint25);
        try {
            barRenderer0.setSeriesOutlinePaint((int) (byte) -1, paint25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(dateRange5);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(rotation18);
        org.junit.Assert.assertNull(plot19);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        int int0 = org.jfree.data.time.SerialDate.THURSDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.Axis axis1 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        try {
            axisCollection0.add(axis1, rectangleEdge2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge2);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        int int3 = java.awt.Color.HSBtoRGB((float) (-1), (float) 15, (float) (-459));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-2234650) + "'", int3 == (-2234650));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.time.TimePeriod timePeriod1 = null;
        org.jfree.data.gantt.Task task2 = new org.jfree.data.gantt.Task("hi!", timePeriod1);
        org.jfree.data.time.TimePeriod timePeriod4 = null;
        org.jfree.data.gantt.Task task5 = new org.jfree.data.gantt.Task("hi!", timePeriod4);
        java.lang.Object obj6 = null;
        boolean boolean7 = task5.equals(obj6);
        org.jfree.data.time.TimePeriod timePeriod9 = null;
        org.jfree.data.gantt.Task task10 = new org.jfree.data.gantt.Task("hi!", timePeriod9);
        java.lang.Object obj11 = null;
        boolean boolean12 = task10.equals(obj11);
        task10.setPercentComplete((java.lang.Double) 90.0d);
        task5.removeSubtask(task10);
        java.lang.String str16 = task5.getDescription();
        task2.removeSubtask(task5);
        org.jfree.data.gantt.Task task18 = null;
        task5.removeSubtask(task18);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        java.lang.String[] strArray2 = new java.lang.String[] { "SerialDate.weekInMonthToString(): invalid code.", "VerticalAlignment.TOP" };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (short) 1, 100.0f, 2, (short) -1, (-1.0f) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { (short) 1, 100.0f, 2, (short) -1, (-1.0f) };
        java.lang.Number[][] numberArray17 = new java.lang.Number[][] { numberArray10, numberArray16 };
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray17);
        java.lang.Number[][] numberArray19 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset20 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray2, numberArray17, numberArray19);
        try {
            int int21 = defaultIntervalCategoryDataset20.getColumnCount();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(categoryDataset18);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle();
        textTitle3.setNotify(false);
        java.lang.Class<?> wildcardClass6 = textTitle3.getClass();
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle();
        textTitle7.setNotify(false);
        java.lang.Class<?> wildcardClass10 = textTitle7.getClass();
        java.lang.Object obj11 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("VerticalAlignment.TOP", (java.lang.Class) wildcardClass6, (java.lang.Class) wildcardClass10);
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle();
        textTitle13.setNotify(false);
        java.lang.Class<?> wildcardClass16 = textTitle13.getClass();
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle();
        textTitle17.setNotify(false);
        java.lang.Class<?> wildcardClass20 = textTitle17.getClass();
        java.lang.Object obj21 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("VerticalAlignment.TOP", (java.lang.Class) wildcardClass16, (java.lang.Class) wildcardClass20);
        java.lang.Object obj22 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ChartChangeEventType.GENERAL", (java.lang.Class) wildcardClass6, (java.lang.Class) wildcardClass16);
        org.jfree.chart.title.TextTitle textTitle23 = new org.jfree.chart.title.TextTitle();
        textTitle23.setNotify(false);
        java.lang.Class<?> wildcardClass26 = textTitle23.getClass();
        java.lang.Object obj27 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("({0}, {1}) = {3} - {4}", (java.lang.Class) wildcardClass6, (java.lang.Class) wildcardClass26);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNull(obj21);
        org.junit.Assert.assertNull(obj22);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNull(obj27);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange3, 0.0d);
        org.jfree.data.Range range7 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange3, (double) '#');
        numberAxis1.setDefaultAutoRange((org.jfree.data.Range) dateRange3);
        boolean boolean9 = numberAxis1.isNegativeArrowVisible();
        boolean boolean10 = numberAxis1.isTickMarksVisible();
        numberAxis1.setFixedAutoRange((double) 1);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str15 = numberAxis14.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange16, 0.0d);
        org.jfree.data.Range range20 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange16, (double) '#');
        numberAxis14.setDefaultAutoRange((org.jfree.data.Range) dateRange16);
        boolean boolean22 = numberAxis14.isNegativeArrowVisible();
        boolean boolean23 = numberAxis14.isTickMarksVisible();
        java.lang.Object obj24 = numberAxis14.clone();
        java.awt.Font font29 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand30 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis14, (double) 11, 0.0d, (double) 'a', (double) 100, font29);
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        markerAxisBand30.draw(graphics2D31, rectangle2D32, rectangle2D33, (double) 12, (double) 12);
        numberAxis1.setMarkerBand(markerAxisBand30);
        org.jfree.chart.renderer.category.BarRenderer barRenderer38 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator39 = barRenderer38.getBaseToolTipGenerator();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator41 = null;
        barRenderer38.setSeriesURLGenerator(0, categoryURLGenerator41, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition45 = barRenderer38.getSeriesPositiveItemLabelPosition(0);
        boolean boolean46 = markerAxisBand30.equals((java.lang.Object) itemLabelPosition45);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer47 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.LegendItem legendItem50 = stackedAreaRenderer47.getLegendItem((int) 'a', 0);
        java.awt.Shape shape52 = null;
        stackedAreaRenderer47.setSeriesShape((int) '4', shape52, true);
        java.awt.Shape shape57 = stackedAreaRenderer47.getItemShape(1, 15);
        boolean boolean58 = markerAxisBand30.equals((java.lang.Object) 1);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(dateRange3);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(dateRange16);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNull(categoryToolTipGenerator39);
        org.junit.Assert.assertNotNull(itemLabelPosition45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNull(legendItem50);
        org.junit.Assert.assertNotNull(shape57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 2, (float) 4);
        org.jfree.chart.entity.ChartEntity chartEntity4 = new org.jfree.chart.entity.ChartEntity(shape2, "");
        java.lang.Object obj5 = chartEntity4.clone();
        java.lang.String str6 = chartEntity4.getURLText();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange3, 0.0d);
        org.jfree.data.Range range7 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange3, (double) '#');
        numberAxis1.setDefaultAutoRange((org.jfree.data.Range) dateRange3);
        boolean boolean9 = numberAxis1.isNegativeArrowVisible();
        org.jfree.data.time.DateRange dateRange10 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis1.setRangeWithMargins((org.jfree.data.Range) dateRange10);
        java.awt.Font font12 = null;
        try {
            numberAxis1.setLabelFont(font12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(dateRange3);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateRange10);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.ColumnArrangement columnArrangement1 = new org.jfree.chart.block.ColumnArrangement();
        blockContainer0.setArrangement((org.jfree.chart.block.Arrangement) columnArrangement1);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list1 = taskSeriesCollection0.getRowKeys();
        try {
            java.lang.Number number5 = taskSeriesCollection0.getPercentComplete(0, 6, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.25d + "'", double0 == 0.25d);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Paint paint1 = ganttRenderer0.getCompletePaint();
        ganttRenderer0.setEndPercent(1.0E-8d);
        org.jfree.data.KeyToGroupMap keyToGroupMap5 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) true);
        java.util.List list6 = keyToGroupMap5.getGroups();
        boolean boolean7 = ganttRenderer0.equals((java.lang.Object) keyToGroupMap5);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double15 = numberAxis14.getUpperMargin();
        double double16 = numberAxis14.getUpperMargin();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset17 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list18 = defaultStatisticalCategoryDataset17.getColumnKeys();
        java.lang.Number number19 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset17);
        int int20 = defaultStatisticalCategoryDataset17.getRowCount();
        try {
            ganttRenderer0.drawItem(graphics2D8, categoryItemRendererState9, rectangle2D10, categoryPlot11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) numberAxis14, (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset17, (-459), 11, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.05d + "'", double15 == 0.05d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.05d + "'", double16 == 0.05d);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 0.0d + "'", number19.equals(0.0d));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.util.Rotation rotation4 = piePlot3.getDirection();
        org.jfree.chart.plot.Plot plot5 = piePlot3.getParent();
        org.jfree.chart.plot.Plot plot6 = piePlot3.getRootPlot();
        java.awt.Color color7 = java.awt.Color.MAGENTA;
        piePlot3.setOutlinePaint((java.awt.Paint) color7);
        columnArrangement0.add((org.jfree.chart.block.Block) textTitle1, (java.lang.Object) color7);
        textTitle1.setPadding((double) (-1L), 3.0d, (double) 1577865599999L, (double) (short) -1);
        org.junit.Assert.assertNotNull(rotation4);
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertNotNull(plot6);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.Point2D point2D4 = null;
        org.jfree.chart.plot.PlotState plotState5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        try {
            waferMapPlot1.draw(graphics2D2, rectangle2D3, point2D4, plotState5, plotRenderingInfo6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        java.awt.Shape shape5 = null;
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape12 = null;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color14 = java.awt.Color.black;
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("", "hi!", "hi!", "", true, shape5, false, (java.awt.Paint) color7, false, paint9, stroke10, true, shape12, stroke13, (java.awt.Paint) color14);
        java.awt.Stroke stroke16 = legendItem15.getLineStroke();
        legendItem15.setSeriesIndex((int) (short) 0);
        int int19 = legendItem15.getSeriesIndex();
        java.lang.String str20 = legendItem15.getDescription();
        boolean boolean21 = legendItem15.isShapeVisible();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 10, (long) 'a');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str6 = numberAxis5.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange7 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange7, 0.0d);
        org.jfree.data.Range range11 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange7, (double) '#');
        numberAxis5.setDefaultAutoRange((org.jfree.data.Range) dateRange7);
        org.jfree.data.Range range15 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange7, 0.0d, (double) (byte) -1);
        java.util.Date date16 = dateRange7.getUpperDate();
        org.jfree.chart.text.TextAnchor textAnchor18 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.text.TextAnchor textAnchor23 = null;
        org.jfree.chart.text.TextAnchor textAnchor25 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        java.awt.Shape shape26 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D20, (float) 1, (float) 0, textAnchor23, (double) 100L, textAnchor25);
        java.lang.String str27 = textAnchor25.toString();
        org.jfree.chart.axis.DateTick dateTick29 = new org.jfree.chart.axis.DateTick(date16, "TextAnchor.CENTER_RIGHT", textAnchor18, textAnchor25, (double) (-1.0f));
        try {
            org.jfree.data.time.DateRange dateRange30 = new org.jfree.data.time.DateRange(date3, date16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (97.0) <= upper (1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(dateRange7);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(textAnchor18);
        org.junit.Assert.assertNotNull(textAnchor25);
        org.junit.Assert.assertNull(shape26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "TextAnchor.CENTER_RIGHT" + "'", str27.equals("TextAnchor.CENTER_RIGHT"));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        double double4 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator9 = null;
        piePlot8.setToolTipGenerator(pieToolTipGenerator9);
        numberAxis3D6.setPlot((org.jfree.chart.plot.Plot) piePlot8);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str15 = numberAxis14.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange16, 0.0d);
        org.jfree.data.Range range20 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange16, (double) '#');
        numberAxis14.setDefaultAutoRange((org.jfree.data.Range) dateRange16);
        boolean boolean22 = numberAxis14.isNegativeArrowVisible();
        boolean boolean23 = numberAxis14.isTickMarksVisible();
        java.lang.Object obj24 = numberAxis14.clone();
        numberAxis14.setAutoRangeIncludesZero(true);
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str29 = numberAxis28.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange30 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint32 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange30, 0.0d);
        org.jfree.data.Range range34 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange30, (double) '#');
        numberAxis28.setDefaultAutoRange((org.jfree.data.Range) dateRange30);
        boolean boolean36 = numberAxis28.isNegativeArrowVisible();
        boolean boolean37 = numberAxis28.isTickMarksVisible();
        java.lang.Object obj38 = numberAxis28.clone();
        java.awt.Font font43 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand44 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis28, (double) 11, 0.0d, (double) 'a', (double) 100, font43);
        numberAxis14.setTickLabelFont(font43);
        org.jfree.data.general.PieDataset pieDataset46 = null;
        org.jfree.chart.plot.PiePlot piePlot47 = new org.jfree.chart.plot.PiePlot(pieDataset46);
        org.jfree.chart.util.Rotation rotation48 = piePlot47.getDirection();
        org.jfree.chart.plot.Plot plot49 = piePlot47.getParent();
        org.jfree.chart.plot.Plot plot50 = piePlot47.getRootPlot();
        org.jfree.chart.JFreeChart jFreeChart52 = new org.jfree.chart.JFreeChart("PlotOrientation.VERTICAL", font43, (org.jfree.chart.plot.Plot) piePlot47, false);
        piePlot8.setNoDataMessageFont(font43);
        numberAxis2.setTickLabelFont(font43);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier55 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint56 = defaultDrawingSupplier55.getNextOutlinePaint();
        org.jfree.chart.text.TextMeasurer textMeasurer58 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock59 = org.jfree.chart.text.TextUtilities.createTextBlock("TextAnchor.CENTER_RIGHT", font43, paint56, (float) 15, textMeasurer58);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(dateRange16);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(dateRange30);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertNotNull(rotation48);
        org.junit.Assert.assertNull(plot49);
        org.junit.Assert.assertNotNull(plot50);
        org.junit.Assert.assertNotNull(paint56);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getFixedAutoRange();
        java.text.NumberFormat numberFormat3 = numberAxis1.getNumberFormatOverride();
        boolean boolean4 = numberAxis1.isVerticalTickLabels();
        numberAxis1.setPositiveArrowVisible(false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNull(numberFormat3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator1, false);
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.util.Rotation rotation7 = piePlot6.getDirection();
        org.jfree.chart.plot.Plot plot8 = piePlot6.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent9 = null;
        piePlot6.datasetChanged(datasetChangeEvent9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        piePlot6.drawBackgroundImage(graphics2D11, rectangle2D12);
        java.awt.Paint paint14 = piePlot6.getBaseSectionOutlinePaint();
        java.awt.Paint paint15 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot6.setBaseSectionPaint(paint15);
        barRenderer0.setSeriesItemLabelPaint((int) (byte) 0, paint15);
        boolean boolean18 = barRenderer0.getAutoPopulateSeriesShape();
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator22 = new org.jfree.chart.urls.StandardCategoryURLGenerator("VerticalAlignment.TOP", "RectangleEdge.LEFT", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        barRenderer0.setBaseURLGenerator((org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator22);
        barRenderer0.setAutoPopulateSeriesOutlineStroke(false);
        org.junit.Assert.assertNotNull(rotation7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 0.0f, (double) 1L);
        double double3 = size2D2.width;
        size2D2.setWidth((double) (-459));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        java.awt.Shape shape5 = null;
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape12 = null;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color14 = java.awt.Color.black;
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("", "hi!", "hi!", "", true, shape5, false, (java.awt.Paint) color7, false, paint9, stroke10, true, shape12, stroke13, (java.awt.Paint) color14);
        java.awt.Stroke stroke16 = legendItem15.getLineStroke();
        legendItem15.setSeriesIndex((int) (short) 0);
        java.awt.Paint paint19 = legendItem15.getFillPaint();
        java.lang.String str20 = legendItem15.getLabel();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 11);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.color.ColorSpace colorSpace7 = color6.getColorSpace();
        java.awt.Shape shape13 = null;
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape20 = null;
        java.awt.Stroke stroke21 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color22 = java.awt.Color.black;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("", "hi!", "hi!", "", true, shape13, false, (java.awt.Paint) color15, false, paint17, stroke18, true, shape20, stroke21, (java.awt.Paint) color22);
        org.jfree.data.general.PieDataset pieDataset24 = null;
        org.jfree.chart.plot.PiePlot piePlot25 = new org.jfree.chart.plot.PiePlot(pieDataset24);
        org.jfree.chart.util.Rotation rotation26 = piePlot25.getDirection();
        org.jfree.chart.plot.Plot plot27 = piePlot25.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent28 = null;
        piePlot25.datasetChanged(datasetChangeEvent28);
        java.awt.Stroke stroke31 = piePlot25.getSectionOutlineStroke((java.lang.Comparable) (short) 100);
        java.awt.Paint paint32 = piePlot25.getNoDataMessagePaint();
        try {
            org.jfree.chart.LegendItem legendItem33 = new org.jfree.chart.LegendItem(attributedString0, "ChartChangeEventType.GENERAL", "UnitType.ABSOLUTE", "CategoryLabelWidthType.CATEGORY", shape5, (java.awt.Paint) color6, stroke21, paint32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(colorSpace7);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(rotation26);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertNull(stroke31);
        org.junit.Assert.assertNotNull(paint32);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        barRenderer2.setBaseToolTipGenerator(categoryToolTipGenerator3, false);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        org.jfree.chart.util.Rotation rotation9 = piePlot8.getDirection();
        org.jfree.chart.plot.Plot plot10 = piePlot8.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent11 = null;
        piePlot8.datasetChanged(datasetChangeEvent11);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        piePlot8.drawBackgroundImage(graphics2D13, rectangle2D14);
        java.awt.Paint paint16 = piePlot8.getBaseSectionOutlinePaint();
        java.awt.Paint paint17 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot8.setBaseSectionPaint(paint17);
        barRenderer2.setSeriesItemLabelPaint((int) (byte) 0, paint17);
        boolean boolean20 = unitType1.equals((java.lang.Object) barRenderer2);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertNotNull(rotation9);
        org.junit.Assert.assertNull(plot10);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange3, 0.0d);
        org.jfree.data.Range range7 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange3, (double) '#');
        numberAxis1.setDefaultAutoRange((org.jfree.data.Range) dateRange3);
        org.jfree.data.Range range11 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange3, 0.0d, (double) (byte) -1);
        java.awt.Shape shape17 = null;
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Paint paint21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke22 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape24 = null;
        java.awt.Stroke stroke25 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color26 = java.awt.Color.black;
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("", "hi!", "hi!", "", true, shape17, false, (java.awt.Paint) color19, false, paint21, stroke22, true, shape24, stroke25, (java.awt.Paint) color26);
        java.awt.Stroke stroke28 = legendItem27.getLineStroke();
        legendItem27.setSeriesIndex((int) (short) 0);
        int int31 = legendItem27.getSeriesIndex();
        java.lang.String str32 = legendItem27.getDescription();
        boolean boolean33 = range11.equals((java.lang.Object) str32);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(dateRange3);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "hi!" + "'", str32.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle();
        textTitle2.setNotify(false);
        java.lang.Class<?> wildcardClass5 = textTitle2.getClass();
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle();
        textTitle6.setNotify(false);
        java.lang.Class<?> wildcardClass9 = textTitle6.getClass();
        java.lang.Object obj10 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("VerticalAlignment.TOP", (java.lang.Class) wildcardClass5, (java.lang.Class) wildcardClass9);
        boolean boolean11 = org.jfree.chart.util.SerialUtilities.isSerializable((java.lang.Class) wildcardClass9);
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle();
        textTitle14.setNotify(false);
        java.lang.Class<?> wildcardClass17 = textTitle14.getClass();
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle();
        textTitle18.setNotify(false);
        java.lang.Class<?> wildcardClass21 = textTitle18.getClass();
        java.lang.Object obj22 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("VerticalAlignment.TOP", (java.lang.Class) wildcardClass17, (java.lang.Class) wildcardClass21);
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle();
        textTitle24.setNotify(false);
        java.lang.Class<?> wildcardClass27 = textTitle24.getClass();
        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle();
        textTitle28.setNotify(false);
        java.lang.Class<?> wildcardClass31 = textTitle28.getClass();
        java.lang.Object obj32 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("VerticalAlignment.TOP", (java.lang.Class) wildcardClass27, (java.lang.Class) wildcardClass31);
        java.lang.Object obj33 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ChartChangeEventType.GENERAL", (java.lang.Class) wildcardClass17, (java.lang.Class) wildcardClass27);
        java.lang.Object obj34 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("PlotOrientation.VERTICAL", (java.lang.Class) wildcardClass9, (java.lang.Class) wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNull(obj10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNull(obj22);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertNull(obj32);
        org.junit.Assert.assertNull(obj33);
        org.junit.Assert.assertNull(obj34);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.chart.ChartColor chartColor5 = new org.jfree.chart.ChartColor((int) (short) 0, (int) (byte) 100, (int) '#');
        boolean boolean6 = spreadsheetDate1.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate9 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double12 = rectangleInsets10.calculateBottomOutset((double) (-1L));
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = org.jfree.chart.util.RectangleAnchor.TOP;
        boolean boolean14 = rectangleInsets10.equals((java.lang.Object) rectangleAnchor13);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor15 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor16 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        boolean boolean18 = textAnchor16.equals((java.lang.Object) 'a');
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType20 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition22 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor13, textBlockAnchor15, textAnchor16, (double) (-2208960000000L), categoryLabelWidthType20, (float) 3);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor23 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.text.TextAnchor textAnchor28 = null;
        org.jfree.chart.text.TextAnchor textAnchor30 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        java.awt.Shape shape31 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D25, (float) 1, (float) 0, textAnchor28, (double) 100L, textAnchor30);
        java.lang.String str32 = textAnchor30.toString();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType34 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition36 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor13, textBlockAnchor23, textAnchor30, 0.0d, categoryLabelWidthType34, (float) (short) 100);
        try {
            int int37 = spreadsheetDate1.compareTo((java.lang.Object) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Short cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor15);
        org.junit.Assert.assertNotNull(textAnchor16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(categoryLabelWidthType20);
        org.junit.Assert.assertNotNull(textBlockAnchor23);
        org.junit.Assert.assertNotNull(textAnchor30);
        org.junit.Assert.assertNull(shape31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "TextAnchor.CENTER_RIGHT" + "'", str32.equals("TextAnchor.CENTER_RIGHT"));
        org.junit.Assert.assertNotNull(categoryLabelWidthType34);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getFixedAutoRange();
        boolean boolean3 = numberAxis1.isAxisLineVisible();
        numberAxis1.setNegativeArrowVisible(false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100, 0, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.lang.Object obj1 = defaultKeyedValues2D0.clone();
        java.lang.Object obj2 = defaultKeyedValues2D0.clone();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange3, 0.0d);
        org.jfree.data.Range range7 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange3, (double) '#');
        numberAxis1.setDefaultAutoRange((org.jfree.data.Range) dateRange3);
        boolean boolean9 = numberAxis1.isNegativeArrowVisible();
        boolean boolean10 = numberAxis1.isTickMarksVisible();
        java.lang.Object obj11 = numberAxis1.clone();
        numberAxis1.setAutoRangeIncludesZero(true);
        double double14 = numberAxis1.getLowerBound();
        java.lang.Object obj15 = numberAxis1.clone();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(dateRange3);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Paint paint1 = ganttRenderer0.getCompletePaint();
        ganttRenderer0.setEndPercent(1.0E-8d);
        org.jfree.data.KeyToGroupMap keyToGroupMap5 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) true);
        java.util.List list6 = keyToGroupMap5.getGroups();
        boolean boolean7 = ganttRenderer0.equals((java.lang.Object) keyToGroupMap5);
        double double8 = ganttRenderer0.getEndPercent();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0E-8d + "'", double8 == 1.0E-8d);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getHorizontalAlignment();
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = textTitle2.getHorizontalAlignment();
        java.util.List list12 = null;
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem13 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 1L, (java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.05d, (java.lang.Number) 5, (java.lang.Number) (-1), (java.lang.Number) 100.0d, (java.lang.Number) 0L, list12);
        boolean boolean14 = horizontalAlignment3.equals((java.lang.Object) 1.0f);
        textTitle0.setHorizontalAlignment(horizontalAlignment3);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = org.jfree.chart.block.RectangleConstraint.NONE;
        try {
            org.jfree.chart.util.Size2D size2D18 = textTitle0.arrange(graphics2D16, rectangleConstraint17);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint17);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        java.awt.Shape shape5 = null;
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape12 = null;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color14 = java.awt.Color.black;
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("", "hi!", "hi!", "", true, shape5, false, (java.awt.Paint) color7, false, paint9, stroke10, true, shape12, stroke13, (java.awt.Paint) color14);
        java.awt.Stroke stroke16 = legendItem15.getLineStroke();
        legendItem15.setSeriesIndex((int) (short) 0);
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray30 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray35 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray40 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray45 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray50 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[][] numberArray51 = new java.lang.Number[][] { numberArray25, numberArray30, numberArray35, numberArray40, numberArray45, numberArray50 };
        org.jfree.data.category.CategoryDataset categoryDataset52 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray51);
        org.jfree.data.general.PieDataset pieDataset54 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset52, (int) (short) 1);
        legendItem15.setDataset((org.jfree.data.general.Dataset) categoryDataset52);
        boolean boolean56 = legendItem15.isShapeOutlineVisible();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(categoryDataset52);
        org.junit.Assert.assertNotNull(pieDataset54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        try {
            java.awt.Color color1 = java.awt.Color.decode("({0}, {1}) = {2}");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"({0}, {1}) = {2}\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.lang.Comparable comparable1 = null;
        try {
            defaultKeyedValues2D0.removeRow(comparable1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        long long3 = year2.getLastMillisecond();
        org.jfree.data.gantt.Task task4 = new org.jfree.data.gantt.Task("AxisLocation.TOP_OR_LEFT", (org.jfree.data.time.TimePeriod) year2);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer5 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Paint paint6 = ganttRenderer5.getCompletePaint();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier7 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint8 = defaultDrawingSupplier7.getNextFillPaint();
        java.awt.Stroke stroke9 = defaultDrawingSupplier7.getNextStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) year2, paint6, stroke9);
        java.awt.Stroke stroke11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer13.setMaximumBarWidth(8.0d);
        java.awt.Shape shape22 = null;
        java.awt.Color color24 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Paint paint26 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke27 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape29 = null;
        java.awt.Stroke stroke30 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color31 = java.awt.Color.black;
        org.jfree.chart.LegendItem legendItem32 = new org.jfree.chart.LegendItem("", "hi!", "hi!", "", true, shape22, false, (java.awt.Paint) color24, false, paint26, stroke27, true, shape29, stroke30, (java.awt.Paint) color31);
        barRenderer13.setSeriesStroke(2, stroke30);
        try {
            org.jfree.chart.plot.ValueMarker valueMarker35 = new org.jfree.chart.plot.ValueMarker((double) 0L, paint6, stroke11, paint12, stroke30, (float) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(color31);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange0, 0.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = rectangleConstraint2.toUnconstrainedHeight();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, 0.0d);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange4, (double) '#');
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = rectangleConstraint2.toRangeWidth(range8);
        double double10 = rectangleConstraint2.getHeight();
        org.junit.Assert.assertNotNull(dateRange0);
        org.junit.Assert.assertNotNull(rectangleConstraint3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(rectangleConstraint9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        int int1 = defaultStatisticalCategoryDataset0.getColumnCount();
        java.lang.Comparable comparable2 = null;
        int int3 = defaultStatisticalCategoryDataset0.getRowIndex(comparable2);
        java.lang.Object obj4 = defaultStatisticalCategoryDataset0.clone();
        java.util.List list5 = defaultStatisticalCategoryDataset0.getColumnKeys();
        org.jfree.data.general.PieDataset pieDataset7 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, (java.lang.Comparable) 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(pieDataset7);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange3, 0.0d);
        org.jfree.data.Range range7 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange3, (double) '#');
        numberAxis1.setDefaultAutoRange((org.jfree.data.Range) dateRange3);
        boolean boolean9 = numberAxis1.isNegativeArrowVisible();
        boolean boolean10 = numberAxis1.isTickMarksVisible();
        java.lang.Object obj11 = numberAxis1.clone();
        java.awt.Font font16 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand17 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis1, (double) 11, 0.0d, (double) 'a', (double) 100, font16);
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str21 = numberAxis20.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange22 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint24 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange22, 0.0d);
        org.jfree.data.Range range26 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange22, (double) '#');
        numberAxis20.setDefaultAutoRange((org.jfree.data.Range) dateRange22);
        boolean boolean28 = numberAxis20.isNegativeArrowVisible();
        boolean boolean29 = numberAxis20.isTickMarksVisible();
        java.lang.Object obj30 = numberAxis20.clone();
        numberAxis20.setAutoRangeIncludesZero(true);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str35 = numberAxis34.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange36 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint38 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange36, 0.0d);
        org.jfree.data.Range range40 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange36, (double) '#');
        numberAxis34.setDefaultAutoRange((org.jfree.data.Range) dateRange36);
        boolean boolean42 = numberAxis34.isNegativeArrowVisible();
        boolean boolean43 = numberAxis34.isTickMarksVisible();
        java.lang.Object obj44 = numberAxis34.clone();
        java.awt.Font font49 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand50 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis34, (double) 11, 0.0d, (double) 'a', (double) 100, font49);
        numberAxis20.setTickLabelFont(font49);
        org.jfree.data.general.PieDataset pieDataset52 = null;
        org.jfree.chart.plot.PiePlot piePlot53 = new org.jfree.chart.plot.PiePlot(pieDataset52);
        org.jfree.chart.util.Rotation rotation54 = piePlot53.getDirection();
        org.jfree.chart.plot.Plot plot55 = piePlot53.getParent();
        org.jfree.chart.plot.Plot plot56 = piePlot53.getRootPlot();
        org.jfree.chart.JFreeChart jFreeChart58 = new org.jfree.chart.JFreeChart("PlotOrientation.VERTICAL", font49, (org.jfree.chart.plot.Plot) piePlot53, false);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent61 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) 'a', jFreeChart58, 100, 0);
        try {
            org.jfree.chart.plot.XYPlot xYPlot62 = jFreeChart58.getXYPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PiePlot cannot be cast to org.jfree.chart.plot.XYPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(dateRange3);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(dateRange22);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertNotNull(dateRange36);
        org.junit.Assert.assertNotNull(range40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(obj44);
        org.junit.Assert.assertNotNull(font49);
        org.junit.Assert.assertNotNull(rotation54);
        org.junit.Assert.assertNull(plot55);
        org.junit.Assert.assertNotNull(plot56);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.zoomRange(0.0d, 10.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis0.setTickMarkPosition(dateTickMarkPosition4);
        java.lang.Object obj6 = dateAxis0.clone();
        java.text.DateFormat dateFormat9 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = new org.jfree.chart.axis.DateTickUnit(0, 0, dateFormat9);
        try {
            java.util.Date date11 = dateAxis0.calculateHighestVisibleTickValue(dateTickUnit10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        int int2 = spreadsheetDate1.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.chart.ChartColor chartColor8 = new org.jfree.chart.ChartColor((int) (short) 0, (int) (byte) 100, (int) '#');
        boolean boolean9 = spreadsheetDate4.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate12 = spreadsheetDate4.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.chart.ChartColor chartColor18 = new org.jfree.chart.ChartColor((int) (short) 0, (int) (byte) 100, (int) '#');
        boolean boolean19 = spreadsheetDate14.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate22 = spreadsheetDate14.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SerialDate serialDate24 = serialDate22.getPreviousDayOfWeek(6);
        boolean boolean25 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate11, serialDate24);
        try {
            org.jfree.data.time.SerialDate serialDate27 = spreadsheetDate1.getNearestDayOfWeek((-2234650));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setDrawOutlines(true);
        lineAndShapeRenderer0.setUseFillPaint(true);
        java.lang.Boolean boolean6 = lineAndShapeRenderer0.getSeriesShapesVisible(2);
        lineAndShapeRenderer0.setSeriesVisible((int) ' ', (java.lang.Boolean) false, true);
        boolean boolean11 = lineAndShapeRenderer0.getAutoPopulateSeriesPaint();
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        stackedAreaRenderer0.setSeriesVisibleInLegend((int) (byte) 1, (java.lang.Boolean) false);
        java.lang.Object obj4 = stackedAreaRenderer0.clone();
        java.awt.Stroke stroke6 = stackedAreaRenderer0.lookupSeriesStroke((-2234650));
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer1.setDrawOutlines(true);
        lineAndShapeRenderer1.setUseFillPaint(true);
        boolean boolean6 = chartChangeEventType0.equals((java.lang.Object) lineAndShapeRenderer1);
        int int7 = lineAndShapeRenderer1.getPassCount();
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, 0.0d);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange4, (double) '#');
        numberAxis2.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        boolean boolean10 = numberAxis2.isNegativeArrowVisible();
        boolean boolean11 = numberAxis2.isTickMarksVisible();
        java.lang.Object obj12 = numberAxis2.clone();
        numberAxis2.setAutoRangeIncludesZero(true);
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str17 = numberAxis16.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange18 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange18, 0.0d);
        org.jfree.data.Range range22 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange18, (double) '#');
        numberAxis16.setDefaultAutoRange((org.jfree.data.Range) dateRange18);
        boolean boolean24 = numberAxis16.isNegativeArrowVisible();
        boolean boolean25 = numberAxis16.isTickMarksVisible();
        java.lang.Object obj26 = numberAxis16.clone();
        java.awt.Font font31 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand32 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis16, (double) 11, 0.0d, (double) 'a', (double) 100, font31);
        numberAxis2.setTickLabelFont(font31);
        org.jfree.data.general.PieDataset pieDataset34 = null;
        org.jfree.chart.plot.PiePlot piePlot35 = new org.jfree.chart.plot.PiePlot(pieDataset34);
        org.jfree.chart.util.Rotation rotation36 = piePlot35.getDirection();
        org.jfree.chart.plot.Plot plot37 = piePlot35.getParent();
        org.jfree.chart.plot.Plot plot38 = piePlot35.getRootPlot();
        org.jfree.chart.JFreeChart jFreeChart40 = new org.jfree.chart.JFreeChart("PlotOrientation.VERTICAL", font31, (org.jfree.chart.plot.Plot) piePlot35, false);
        jFreeChart40.setTitle("UnitType.ABSOLUTE");
        float float43 = jFreeChart40.getBackgroundImageAlpha();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(dateRange18);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(rotation36);
        org.junit.Assert.assertNull(plot37);
        org.junit.Assert.assertNotNull(plot38);
        org.junit.Assert.assertTrue("'" + float43 + "' != '" + 0.5f + "'", float43 == 0.5f);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = piePlot1.getDirection();
        org.jfree.chart.plot.Plot plot3 = piePlot1.getParent();
        org.jfree.chart.plot.Plot plot4 = piePlot1.getRootPlot();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.util.Rotation rotation7 = piePlot6.getDirection();
        org.jfree.chart.plot.Plot plot8 = piePlot6.getParent();
        org.jfree.chart.plot.Plot plot9 = piePlot6.getRootPlot();
        java.awt.Color color10 = java.awt.Color.MAGENTA;
        piePlot6.setOutlinePaint((java.awt.Paint) color10);
        piePlot1.setLabelLinkPaint((java.awt.Paint) color10);
        float[] floatArray17 = new float[] { 4, 3, 4, 11 };
        float[] floatArray18 = color10.getRGBColorComponents(floatArray17);
        float[] floatArray25 = new float[] { 3, (byte) -1, 10L };
        float[] floatArray26 = java.awt.Color.RGBtoHSB((int) (short) -1, 2, (int) (short) -1, floatArray25);
        try {
            float[] floatArray27 = color10.getComponents(floatArray25);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(rotation2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(plot4);
        org.junit.Assert.assertNotNull(rotation7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray26);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator1, false);
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.util.Rotation rotation7 = piePlot6.getDirection();
        org.jfree.chart.plot.Plot plot8 = piePlot6.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent9 = null;
        piePlot6.datasetChanged(datasetChangeEvent9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        piePlot6.drawBackgroundImage(graphics2D11, rectangle2D12);
        java.awt.Paint paint14 = piePlot6.getBaseSectionOutlinePaint();
        java.awt.Paint paint15 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot6.setBaseSectionPaint(paint15);
        barRenderer0.setSeriesItemLabelPaint((int) (byte) 0, paint15);
        boolean boolean18 = barRenderer0.getAutoPopulateSeriesShape();
        barRenderer0.setAutoPopulateSeriesFillPaint(true);
        org.junit.Assert.assertNotNull(rotation7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        try {
            org.jfree.chart.axis.AxisState axisState8 = numberAxis3D1.draw(graphics2D2, (double) (-2234650), rectangle2D4, rectangle2D5, rectangleEdge6, plotRenderingInfo7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge6);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = piePlot1.getDirection();
        float float3 = piePlot1.getBackgroundImageAlpha();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        piePlot1.datasetChanged(datasetChangeEvent4);
        org.junit.Assert.assertNotNull(rotation2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.5f + "'", float3 == 0.5f);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(true);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.RendererState rendererState1 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo0);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (byte) 0);
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        org.jfree.chart.util.Rotation rotation5 = piePlot4.getDirection();
        org.jfree.chart.plot.Plot plot6 = piePlot4.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        piePlot4.datasetChanged(datasetChangeEvent7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        piePlot4.drawBackgroundImage(graphics2D9, rectangle2D10);
        java.awt.Paint paint12 = piePlot4.getBaseSectionOutlinePaint();
        java.awt.Paint paint13 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot4.setBaseSectionPaint(paint13);
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot4);
        jFreeChart15.setTitle("({0}, {1}) = {3} - {4}");
        org.jfree.chart.title.TextTitle textTitle18 = jFreeChart15.getTitle();
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment20 = textTitle19.getHorizontalAlignment();
        textTitle19.setExpandToFitSpace(true);
        jFreeChart15.removeSubtitle((org.jfree.chart.title.Title) textTitle19);
        java.awt.Color color24 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        jFreeChart15.setBackgroundPaint((java.awt.Paint) color24);
        java.awt.Color color26 = color24.darker();
        float[] floatArray33 = new float[] { 3, (byte) -1, 10L };
        float[] floatArray34 = java.awt.Color.RGBtoHSB((int) (short) -1, 2, (int) (short) -1, floatArray33);
        float[] floatArray35 = color24.getRGBColorComponents(floatArray34);
        int int36 = objectList1.indexOf((java.lang.Object) floatArray34);
        org.junit.Assert.assertNotNull(rotation5);
        org.junit.Assert.assertNull(plot6);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(textTitle18);
        org.junit.Assert.assertNotNull(horizontalAlignment20);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray32);
        java.lang.String[] strArray36 = new java.lang.String[] { "SerialDate.weekInMonthToString(): invalid code.", "VerticalAlignment.TOP" };
        java.lang.Number[] numberArray44 = new java.lang.Number[] { (short) 1, 100.0f, 2, (short) -1, (-1.0f) };
        java.lang.Number[] numberArray50 = new java.lang.Number[] { (short) 1, 100.0f, 2, (short) -1, (-1.0f) };
        java.lang.Number[][] numberArray51 = new java.lang.Number[][] { numberArray44, numberArray50 };
        org.jfree.data.category.CategoryDataset categoryDataset52 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray51);
        java.lang.Number[][] numberArray53 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset54 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray36, numberArray51, numberArray53);
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset55 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray32, numberArray53);
        java.util.List list56 = defaultIntervalCategoryDataset55.getRowKeys();
        try {
            java.lang.Number number59 = defaultIntervalCategoryDataset55.getValue((java.lang.Comparable) '4', (java.lang.Comparable) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(strArray36);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(categoryDataset52);
        org.junit.Assert.assertNotNull(list56);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list1 = defaultStatisticalCategoryDataset0.getColumnKeys();
        try {
            java.lang.Number number4 = defaultStatisticalCategoryDataset0.getValue((int) '4', (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        int int0 = org.jfree.data.time.SerialDate.FRIDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.zoomRange((double) 1.0f, (double) (byte) 10);
        java.awt.Paint paint5 = numberAxis1.getTickMarkPaint();
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setXOffset((double) 3600000L);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean7 = numberAxis3D6.isInverted();
        numberAxis3D6.setLabelToolTip("VerticalAlignment.TOP");
        numberAxis3D6.setTickMarkOutsideLength((float) (byte) 1);
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        try {
            lineRenderer3D0.drawRangeGridline(graphics2D3, categoryPlot4, (org.jfree.chart.axis.ValueAxis) numberAxis3D6, rectangle2D12, (double) 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = piePlot1.getDirection();
        org.jfree.chart.plot.Plot plot3 = piePlot1.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        piePlot1.datasetChanged(datasetChangeEvent4);
        java.awt.Stroke stroke7 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) (short) 100);
        java.awt.Paint paint8 = piePlot1.getNoDataMessagePaint();
        org.jfree.data.general.PieDataset pieDataset9 = piePlot1.getDataset();
        piePlot1.setLabelLinkMargin(1.0d);
        org.junit.Assert.assertNotNull(rotation2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNull(stroke7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(pieDataset9);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.chart.ChartColor chartColor5 = new org.jfree.chart.ChartColor((int) (short) 0, (int) (byte) 100, (int) '#');
        boolean boolean6 = spreadsheetDate1.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate9 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(100);
        int int12 = spreadsheetDate11.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.chart.ChartColor chartColor18 = new org.jfree.chart.ChartColor((int) (short) 0, (int) (byte) 100, (int) '#');
        boolean boolean19 = spreadsheetDate14.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate22 = spreadsheetDate14.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.chart.ChartColor chartColor28 = new org.jfree.chart.ChartColor((int) (short) 0, (int) (byte) 100, (int) '#');
        boolean boolean29 = spreadsheetDate24.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate32 = spreadsheetDate24.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SerialDate serialDate34 = serialDate32.getPreviousDayOfWeek(6);
        boolean boolean35 = spreadsheetDate11.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate21, serialDate34);
        boolean boolean36 = spreadsheetDate8.isOn(serialDate34);
        org.jfree.data.time.SerialDate serialDate37 = null;
        try {
            boolean boolean38 = spreadsheetDate8.isOnOrAfter(serialDate37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        boolean boolean1 = boxAndWhiskerRenderer0.getBaseItemLabelsVisible();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer3 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.LegendItem legendItem6 = stackedAreaRenderer3.getLegendItem((int) 'a', 0);
        java.awt.Shape shape8 = null;
        stackedAreaRenderer3.setSeriesShape((int) '4', shape8, true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator11 = null;
        stackedAreaRenderer3.setBaseURLGenerator(categoryURLGenerator11);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = stackedAreaRenderer3.getNegativeItemLabelPosition(100, (int) (short) 0);
        boxAndWhiskerRenderer0.setSeriesPositiveItemLabelPosition((int) '#', itemLabelPosition15);
        java.awt.Paint paint18 = boxAndWhiskerRenderer0.lookupSeriesPaint((int) '#');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(legendItem6);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, (-1.0d), 0.05d, 0.05d };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray32);
        org.jfree.data.general.PieDataset pieDataset35 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset33, (int) (short) 1);
        org.jfree.data.Range range37 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset33, (double) (short) 1);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(pieDataset35);
        org.junit.Assert.assertNotNull(range37);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 2, (float) 4);
        org.jfree.chart.entity.ChartEntity chartEntity4 = new org.jfree.chart.entity.ChartEntity(shape2, "");
        java.io.ObjectOutputStream objectOutputStream5 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeShape(shape2, objectOutputStream5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = lineAndShapeRenderer0.getToolTipGenerator(2, 1);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        org.jfree.chart.util.Rotation rotation6 = piePlot5.getDirection();
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        piePlot5.removeChangeListener(plotChangeListener7);
        piePlot5.setLabelLinksVisible(false);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.color.ColorSpace colorSpace12 = color11.getColorSpace();
        piePlot5.setLabelLinkPaint((java.awt.Paint) color11);
        lineAndShapeRenderer0.setBaseFillPaint((java.awt.Paint) color11);
        java.lang.Object obj15 = lineAndShapeRenderer0.clone();
        org.junit.Assert.assertNull(categoryToolTipGenerator3);
        org.junit.Assert.assertNotNull(rotation6);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(colorSpace12);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = piePlot1.getDirection();
        org.jfree.chart.plot.Plot plot3 = piePlot1.getParent();
        org.jfree.chart.plot.Plot plot4 = piePlot1.getRootPlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator5 = piePlot1.getLegendLabelGenerator();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator6 = null;
        piePlot1.setToolTipGenerator(pieToolTipGenerator6);
        java.awt.Stroke stroke9 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) 1.0f);
        org.junit.Assert.assertNotNull(rotation2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(plot4);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator5);
        org.junit.Assert.assertNull(stroke9);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D1, (float) 6, 0.0f, (double) (-1), 0.5f, (float) 15);
        org.junit.Assert.assertNull(shape7);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        java.lang.Double double0 = org.jfree.chart.renderer.AbstractRenderer.ZERO;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.0d + "'", double0.equals(0.0d));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = piePlot1.getDirection();
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot1.removeChangeListener(plotChangeListener3);
        piePlot1.setLabelLinksVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        piePlot1.handleClick(15, 1, plotRenderingInfo9);
        java.awt.Paint paint11 = null;
        piePlot1.setShadowPaint(paint11);
        org.junit.Assert.assertNotNull(rotation2);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        java.lang.String str1 = chartChangeEventType0.toString();
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str1.equals("ChartChangeEventType.DATASET_UPDATED"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabelToolTip();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, 0.0d);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange4, (double) '#');
        numberAxis2.setDefaultAutoRange((org.jfree.data.Range) dateRange4);
        boolean boolean10 = numberAxis2.isNegativeArrowVisible();
        boolean boolean11 = numberAxis2.isTickMarksVisible();
        java.lang.String str12 = numberAxis2.getLabel();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        boolean boolean15 = numberAxis3D14.isInverted();
        org.jfree.data.time.DateRange dateRange16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis3D14.setRangeWithMargins((org.jfree.data.Range) dateRange16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, xYItemRenderer18);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray20 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot19.setRenderers(xYItemRendererArray20);
        int int22 = xYPlot19.getSeriesCount();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation23 = null;
        try {
            boolean boolean24 = xYPlot19.removeAnnotation(xYAnnotation23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateRange16);
        org.junit.Assert.assertNotNull(xYItemRendererArray20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        ganttRenderer0.setStartPercent((double) 100.0f);
        ganttRenderer0.setEndPercent(0.0d);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = piePlot1.getDirection();
        org.jfree.chart.plot.Plot plot3 = piePlot1.getParent();
        org.jfree.chart.plot.Plot plot4 = piePlot1.getRootPlot();
        java.awt.Color color5 = java.awt.Color.MAGENTA;
        piePlot1.setOutlinePaint((java.awt.Paint) color5);
        int int7 = piePlot1.getBackgroundImageAlignment();
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.util.Rotation rotation10 = piePlot9.getDirection();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator11 = piePlot9.getURLGenerator();
        piePlot9.setMaximumLabelWidth((double) (short) 100);
        double double15 = piePlot9.getExplodePercent((java.lang.Comparable) 10.0f);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator16 = piePlot9.getLegendLabelGenerator();
        piePlot1.setLegendLabelGenerator(pieSectionLabelGenerator16);
        try {
            double double18 = piePlot1.getMaximumExplodePercent();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rotation2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(plot4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
        org.junit.Assert.assertNotNull(rotation10);
        org.junit.Assert.assertNull(pieURLGenerator11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator16);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            blockBorder0.draw(graphics2D1, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        double[] doubleArray1 = new double[] { 4.0d };
        double[][] doubleArray2 = new double[][] { doubleArray1 };
        double[] doubleArray5 = new double[] { 0.5f, (-1310400001L) };
        double[] doubleArray8 = new double[] { 0.5f, (-1310400001L) };
        double[] doubleArray11 = new double[] { 0.5f, (-1310400001L) };
        double[] doubleArray14 = new double[] { 0.5f, (-1310400001L) };
        double[][] doubleArray15 = new double[][] { doubleArray5, doubleArray8, doubleArray11, doubleArray14 };
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset16 = new org.jfree.data.category.DefaultIntervalCategoryDataset(doubleArray2, doubleArray15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset: the number of series in the start value dataset does not match the number of series in the end value dataset.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.zoomRange(0.0d, 10.0d);
        java.util.Date date4 = dateAxis0.getMinimumDate();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.AxisState axisState6 = new org.jfree.chart.axis.AxisState();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean9 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge8);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge8);
        boolean boolean11 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge8);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge8);
        try {
            java.util.List list13 = dateAxis0.refreshTicks(graphics2D5, axisState6, rectangle2D7, rectangleEdge8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(rectangleEdge12);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = piePlot1.getDirection();
        org.jfree.chart.plot.Plot plot3 = piePlot1.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        piePlot1.datasetChanged(datasetChangeEvent4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        piePlot1.drawBackgroundImage(graphics2D6, rectangle2D7);
        java.awt.Paint paint9 = piePlot1.getBaseSectionOutlinePaint();
        java.awt.Paint paint10 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot1.setBaseSectionPaint(paint10);
        piePlot1.setStartAngle((double) (short) 0);
        org.jfree.chart.util.Rotation rotation14 = piePlot1.getDirection();
        org.jfree.chart.plot.Plot plot15 = piePlot1.getRootPlot();
        org.junit.Assert.assertNotNull(rotation2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rotation14);
        org.junit.Assert.assertNotNull(plot15);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.util.Rotation rotation3 = piePlot2.getDirection();
        org.jfree.chart.plot.Plot plot4 = piePlot2.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        piePlot2.datasetChanged(datasetChangeEvent5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        piePlot2.drawBackgroundImage(graphics2D7, rectangle2D8);
        java.awt.Paint paint10 = piePlot2.getBaseSectionOutlinePaint();
        java.awt.Paint paint11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot2.setBaseSectionPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart13.setBackgroundImageAlpha((float) (byte) 10);
        org.jfree.chart.event.ChartProgressListener chartProgressListener16 = null;
        jFreeChart13.removeProgressListener(chartProgressListener16);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer18 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean19 = jFreeChart13.equals((java.lang.Object) lineAndShapeRenderer18);
        java.awt.Paint paint20 = lineAndShapeRenderer18.getBasePaint();
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.THREAD_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }
}

