import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis3D1.setMarkerBand(markerAxisBand2);
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str5 = dateRange4.toString();
        boolean boolean8 = dateRange4.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = rectangleConstraint10.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint10.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range14 = rectangleConstraint10.getWidthRange();
        numberAxis3D1.setRangeWithMargins(range14, true, true);
        boolean boolean18 = numberAxis3D1.isTickLabelsVisible();
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str20 = xYPlot19.getPlotType();
        boolean boolean21 = xYPlot19.isRangeZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation22 = xYPlot19.getRangeAxisLocation();
        boolean boolean23 = numberAxis3D1.equals((java.lang.Object) xYPlot19);
        java.lang.Number[] numberArray27 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { 0L };
        java.lang.Number[][] numberArray34 = new java.lang.Number[][] { numberArray27, numberArray29, numberArray31, numberArray33 };
        org.jfree.data.category.CategoryDataset categoryDataset35 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("VerticalAlignment.BOTTOM", "XY Plot", numberArray34);
        org.jfree.data.Range range37 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset35, false);
        org.jfree.data.Range range39 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset35, (double) ' ');
        numberAxis3D1.setRange(range39);
        numberAxis3D1.setAxisLineVisible(false);
        numberAxis3D1.setLabelToolTip("Pie Plot");
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str5.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint11);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "XY Plot" + "'", str20.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(categoryDataset35);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertNotNull(range39);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font1 = ringPlot0.getNoDataMessageFont();
        boolean boolean3 = ringPlot0.equals((java.lang.Object) (byte) 1);
        org.jfree.data.general.PieDataset pieDataset4 = ringPlot0.getDataset();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator5 = null;
        ringPlot0.setToolTipGenerator(pieToolTipGenerator5);
        try {
            java.lang.Object obj7 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) pieToolTipGenerator5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'object' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(pieDataset4);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("VerticalAlignment.BOTTOM", "hi!", "RectangleAnchor.TOP", "Rotation.ANTICLOCKWISE", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        java.lang.String str6 = basicProjectInfo5.getCopyright();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Rotation.ANTICLOCKWISE" + "'", str6.equals("Rotation.ANTICLOCKWISE"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace1, false);
        java.awt.Paint paint4 = xYPlot0.getOutlinePaint();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint6 = defaultDrawingSupplier5.getNextFillPaint();
        java.awt.Stroke stroke7 = defaultDrawingSupplier5.getNextOutlineStroke();
        xYPlot0.setDomainCrosshairStroke(stroke7);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder9 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        xYPlot0.setRenderer(0, xYItemRenderer11);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(seriesRenderingOrder9);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset0);
        org.junit.Assert.assertNull(number1);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font3 = ringPlot2.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("ThreadContext", font3);
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        piePlot5.setLabelGap(0.0d);
        piePlot5.setCircular(true);
        java.awt.Shape shape10 = piePlot5.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("ThreadContext", font3, (org.jfree.chart.plot.Plot) piePlot5, false);
        jFreeChart12.setBorderVisible(true);
        boolean boolean15 = jFreeChart12.isBorderVisible();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = categoryPlot21.getDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot21.getDomainAxis((-1));
        org.jfree.chart.util.Layer layer26 = null;
        java.util.Collection collection27 = categoryPlot21.getRangeMarkers((int) ' ', layer26);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor28 = categoryPlot21.getDomainGridlinePosition();
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(categoryAxis22);
        org.junit.Assert.assertNull(categoryAxis24);
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertNotNull(categoryAnchor28);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.Plot plot1 = ringPlot0.getRootPlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor2 = ringPlot0.getLabelDistributor();
        ringPlot0.setBackgroundImageAlignment((int) '#');
        org.junit.Assert.assertNotNull(plot1);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor2);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = xYPlot0.getRendererForDataset(xYDataset1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        xYPlot0.setDomainAxis(valueAxis3);
        java.awt.Color color5 = java.awt.Color.BLACK;
        float[] floatArray15 = new float[] { 0L, (short) 100, 10.0f, (short) 100, 0.0f, 1L };
        float[] floatArray16 = java.awt.Color.RGBtoHSB((int) (byte) -1, (int) '#', (int) ' ', floatArray15);
        float[] floatArray17 = color5.getRGBColorComponents(floatArray15);
        xYPlot0.setDomainGridlinePaint((java.awt.Paint) color5);
        org.jfree.chart.axis.ValueAxis valueAxis20 = xYPlot0.getRangeAxisForDataset(0);
        boolean boolean21 = xYPlot0.isRangeZoomable();
        xYPlot0.setDomainCrosshairLockedOnData(false);
        java.awt.Color color25 = java.awt.Color.BLUE;
        java.awt.Stroke stroke26 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint) color25, stroke26);
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str30 = xYPlot29.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        xYPlot29.setDataset(0, xYDataset32);
        java.lang.Class<?> wildcardClass34 = xYPlot29.getClass();
        java.net.URL uRL35 = org.jfree.chart.util.ObjectUtilities.getResource("Multiple Pie Plot", (java.lang.Class) wildcardClass34);
        java.util.EventListener[] eventListenerArray36 = valueMarker27.getListeners((java.lang.Class) wildcardClass34);
        org.jfree.chart.text.TextAnchor textAnchor37 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        valueMarker27.setLabelTextAnchor(textAnchor37);
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker27);
        int int40 = xYPlot0.getBackgroundImageAlignment();
        org.junit.Assert.assertNull(xYItemRenderer2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNull(valueAxis20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "XY Plot" + "'", str30.equals("XY Plot"));
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNull(uRL35);
        org.junit.Assert.assertNotNull(eventListenerArray36);
        org.junit.Assert.assertNotNull(textAnchor37);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 15 + "'", int40 == 15);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.util.List list1 = projectInfo0.getContributors();
        projectInfo0.setLicenceText("Rotation.ANTICLOCKWISE");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot();
        piePlot3.setLabelGap(0.0d);
        piePlot3.setCircular(true);
        org.jfree.chart.plot.RingPlot ringPlot10 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font11 = ringPlot10.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle("ThreadContext", font11);
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot();
        piePlot13.setLabelGap(0.0d);
        piePlot13.setCircular(true);
        java.awt.Shape shape18 = piePlot13.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("ThreadContext", font11, (org.jfree.chart.plot.Plot) piePlot13, false);
        float float21 = jFreeChart20.getBackgroundImageAlpha();
        org.jfree.chart.title.LegendTitle legendTitle23 = jFreeChart20.getLegend((int) ' ');
        java.awt.Stroke stroke24 = jFreeChart20.getBorderStroke();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo28 = null;
        java.awt.image.BufferedImage bufferedImage29 = jFreeChart20.createBufferedImage((int) '4', (int) (byte) 100, (int) (byte) 1, chartRenderingInfo28);
        piePlot3.setBackgroundImage((java.awt.Image) bufferedImage29);
        org.jfree.chart.ui.ProjectInfo projectInfo34 = new org.jfree.chart.ui.ProjectInfo("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=-1.0]", "TextAnchor.BOTTOM_RIGHT", "Pie Plot", (java.awt.Image) bufferedImage29, "", "", "TextAnchor.BOTTOM_RIGHT");
        projectInfo34.setLicenceText("");
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.5f + "'", float21 == 0.5f);
        org.junit.Assert.assertNull(legendTitle23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(bufferedImage29);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = categoryPlot21.getDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot21.getDomainAxis((-1));
        org.jfree.chart.util.Layer layer26 = null;
        java.util.Collection collection27 = categoryPlot21.getRangeMarkers((int) ' ', layer26);
        org.jfree.data.category.CategoryDataset categoryDataset28 = categoryPlot21.getDataset();
        categoryPlot21.clearDomainMarkers((-32640));
        org.jfree.chart.LegendItemCollection legendItemCollection31 = categoryPlot21.getLegendItems();
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(categoryAxis22);
        org.junit.Assert.assertNull(categoryAxis24);
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertNull(categoryDataset28);
        org.junit.Assert.assertNotNull(legendItemCollection31);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setLabelGap(0.0d);
        piePlot0.setCircular(true);
        java.awt.Shape shape5 = piePlot0.getLegendItemShape();
        org.jfree.chart.entity.ChartEntity chartEntity8 = new org.jfree.chart.entity.ChartEntity(shape5, "hi!", "Multiple Pie Plot");
        java.lang.String str9 = chartEntity8.getToolTipText();
        java.lang.Object obj10 = chartEntity8.clone();
        java.lang.String str11 = chartEntity8.getToolTipText();
        java.awt.Shape shape12 = null;
        try {
            chartEntity8.setArea(shape12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = xYPlot0.getRendererForDataset(xYDataset1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        xYPlot0.setDomainAxis(valueAxis3);
        java.awt.Paint paint5 = xYPlot0.getRangeCrosshairPaint();
        java.lang.String str6 = xYPlot0.getPlotType();
        org.jfree.chart.plot.RingPlot ringPlot9 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font10 = ringPlot9.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("ThreadContext", font10);
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot();
        piePlot12.setLabelGap(0.0d);
        piePlot12.setCircular(true);
        java.awt.Shape shape17 = piePlot12.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("ThreadContext", font10, (org.jfree.chart.plot.Plot) piePlot12, false);
        jFreeChart19.clearSubtitles();
        int int21 = jFreeChart19.getSubtitleCount();
        xYPlot0.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart19);
        org.jfree.chart.title.Title title23 = null;
        jFreeChart19.removeSubtitle(title23);
        int int25 = jFreeChart19.getBackgroundImageAlignment();
        org.junit.Assert.assertNull(xYItemRenderer2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "XY Plot" + "'", str6.equals("XY Plot"));
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 15 + "'", int25 == 15);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis3D1.setMarkerBand(markerAxisBand2);
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str5 = dateRange4.toString();
        boolean boolean8 = dateRange4.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = rectangleConstraint10.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint10.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range14 = rectangleConstraint10.getWidthRange();
        numberAxis3D1.setRangeWithMargins(range14, true, true);
        boolean boolean18 = numberAxis3D1.isTickLabelsVisible();
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str20 = xYPlot19.getPlotType();
        boolean boolean21 = xYPlot19.isRangeZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation22 = xYPlot19.getRangeAxisLocation();
        boolean boolean23 = numberAxis3D1.equals((java.lang.Object) xYPlot19);
        java.lang.Number[] numberArray27 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { 0L };
        java.lang.Number[][] numberArray34 = new java.lang.Number[][] { numberArray27, numberArray29, numberArray31, numberArray33 };
        org.jfree.data.category.CategoryDataset categoryDataset35 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("VerticalAlignment.BOTTOM", "XY Plot", numberArray34);
        org.jfree.data.Range range37 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset35, false);
        org.jfree.data.Range range39 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset35, (double) ' ');
        numberAxis3D1.setRange(range39);
        java.awt.Paint paint41 = numberAxis3D1.getLabelPaint();
        numberAxis3D1.setLabel("Category Plot");
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str5.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint11);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "XY Plot" + "'", str20.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(categoryDataset35);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertNotNull(paint41);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font2 = ringPlot1.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("ThreadContext", font2);
        java.awt.Color color4 = java.awt.Color.BLACK;
        textTitle3.setPaint((java.awt.Paint) color4);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = textTitle3.getTextAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.ColumnArrangement columnArrangement10 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment6, verticalAlignment7, (double) 0.5f, (double) (-165));
        org.jfree.chart.block.BlockContainer blockContainer11 = new org.jfree.chart.block.BlockContainer();
        blockContainer11.clear();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.data.time.DateRange dateRange14 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str15 = dateRange14.toString();
        boolean boolean18 = dateRange14.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange14, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = rectangleConstraint20.toUnconstrainedWidth();
        org.jfree.data.Range range22 = rectangleConstraint20.getWidthRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint24 = rectangleConstraint20.toFixedHeight(1.0E-5d);
        org.jfree.chart.util.Size2D size2D25 = columnArrangement10.arrange(blockContainer11, graphics2D13, rectangleConstraint24);
        columnArrangement10.clear();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertNotNull(verticalAlignment7);
        org.junit.Assert.assertNotNull(dateRange14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str15.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint21);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(rectangleConstraint24);
        org.junit.Assert.assertNotNull(size2D25);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement0.clear();
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font3 = ringPlot2.getNoDataMessageFont();
        boolean boolean5 = ringPlot2.equals((java.lang.Object) (byte) 1);
        org.jfree.data.general.PieDataset pieDataset6 = ringPlot2.getDataset();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator7 = null;
        ringPlot2.setToolTipGenerator(pieToolTipGenerator7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot2);
        org.jfree.chart.block.BlockContainer blockContainer10 = legendTitle9.getItemContainer();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.LEFT;
        legendTitle9.setLegendItemGraphicLocation(rectangleAnchor11);
        boolean boolean13 = columnArrangement0.equals((java.lang.Object) rectangleAnchor11);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(pieDataset6);
        org.junit.Assert.assertNotNull(blockContainer10);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        categoryAxis3D1.setCategoryMargin(0.08d);
        double double4 = categoryAxis3D1.getUpperMargin();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font3 = ringPlot2.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("ThreadContext", font3);
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        piePlot5.setLabelGap(0.0d);
        piePlot5.setCircular(true);
        java.awt.Shape shape10 = piePlot5.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("ThreadContext", font3, (org.jfree.chart.plot.Plot) piePlot5, false);
        float float13 = jFreeChart12.getBackgroundImageAlpha();
        org.jfree.chart.title.LegendTitle legendTitle15 = jFreeChart12.getLegend((int) ' ');
        java.awt.Stroke stroke16 = jFreeChart12.getBorderStroke();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = null;
        java.awt.image.BufferedImage bufferedImage21 = jFreeChart12.createBufferedImage((int) '4', (int) (byte) 100, (int) (byte) 1, chartRenderingInfo20);
        org.jfree.chart.event.ChartProgressListener chartProgressListener22 = null;
        jFreeChart12.addProgressListener(chartProgressListener22);
        try {
            org.jfree.chart.plot.CategoryPlot categoryPlot24 = jFreeChart12.getCategoryPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PiePlot cannot be cast to org.jfree.chart.plot.CategoryPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.5f + "'", float13 == 0.5f);
        org.junit.Assert.assertNull(legendTitle15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(bufferedImage21);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        boolean boolean2 = ringPlot1.getIgnoreZeroValues();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        piePlot5.setLabelGap(0.0d);
        piePlot5.setCircular(true);
        double double10 = piePlot5.getShadowYOffset();
        java.awt.Font font11 = piePlot5.getLabelFont();
        piePlot5.setIgnoreNullValues(true);
        boolean boolean14 = piePlot5.getSectionOutlinesVisible();
        java.awt.Stroke stroke16 = piePlot5.getSectionOutlineStroke((java.lang.Comparable) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        org.jfree.chart.plot.PiePlotState piePlotState19 = ringPlot1.initialise(graphics2D3, rectangle2D4, piePlot5, (java.lang.Integer) (-1), plotRenderingInfo18);
        piePlotState19.setPieCenterX(1.0d);
        java.awt.geom.Rectangle2D rectangle2D22 = piePlotState19.getPieArea();
        double double23 = piePlotState19.getPieCenterY();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(stroke16);
        org.junit.Assert.assertNotNull(piePlotState19);
        org.junit.Assert.assertNull(rectangle2D22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        java.awt.Font font2 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=-1.0]", font2);
        java.awt.Paint paint4 = null;
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer8 = new org.jfree.chart.text.G2TextMeasurer(graphics2D7);
        try {
            org.jfree.chart.text.TextBlock textBlock9 = org.jfree.chart.text.TextUtilities.createTextBlock("PlotOrientation.VERTICAL", font2, paint4, (float) '4', 1, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setLabelGap(0.0d);
        piePlot0.setCircular(true);
        double double5 = piePlot0.getShadowYOffset();
        java.awt.Font font6 = piePlot0.getLabelFont();
        double double7 = piePlot0.getShadowYOffset();
        java.awt.Color color8 = java.awt.Color.blue;
        piePlot0.setOutlinePaint((java.awt.Paint) color8);
        java.awt.Color color10 = java.awt.Color.BLACK;
        int int11 = color10.getRGB();
        piePlot0.setOutlinePaint((java.awt.Paint) color10);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-16777216) + "'", int11 == (-16777216));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Shape shape2 = numberAxis3D1.getDownArrow();
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        java.lang.String str1 = plotOrientation0.toString();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        java.lang.String str3 = chartChangeEventType2.toString();
        java.lang.Object obj4 = null;
        boolean boolean5 = chartChangeEventType2.equals(obj4);
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources6 = new org.jfree.chart.resources.JFreeChartResources();
        boolean boolean7 = chartChangeEventType2.equals((java.lang.Object) jFreeChartResources6);
        java.lang.Object[][] objArray8 = jFreeChartResources6.getContents();
        boolean boolean9 = plotOrientation0.equals((java.lang.Object) objArray8);
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PlotOrientation.VERTICAL" + "'", str1.equals("PlotOrientation.VERTICAL"));
        org.junit.Assert.assertNotNull(chartChangeEventType2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str3.equals("ChartChangeEventType.DATASET_UPDATED"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.lang.String str2 = multiplePiePlot1.getPlotType();
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font5 = ringPlot4.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("ThreadContext", font5);
        java.awt.Color color7 = java.awt.Color.BLACK;
        textTitle6.setPaint((java.awt.Paint) color7);
        multiplePiePlot1.setAggregatedItemsPaint((java.awt.Paint) color7);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = multiplePiePlot1.getLegendItems();
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot1);
        java.awt.Font font12 = legendTitle11.getItemFont();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Multiple Pie Plot" + "'", str2.equals("Multiple Pie Plot"));
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(font12);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.lang.String str2 = multiplePiePlot1.getPlotType();
        multiplePiePlot1.setAggregatedItemsKey((java.lang.Comparable) 0.5f);
        org.jfree.chart.LegendItemCollection legendItemCollection5 = multiplePiePlot1.getLegendItems();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Multiple Pie Plot" + "'", str2.equals("Multiple Pie Plot"));
        org.junit.Assert.assertNotNull(legendItemCollection5);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font3 = ringPlot2.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("ThreadContext", font3);
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        piePlot5.setLabelGap(0.0d);
        piePlot5.setCircular(true);
        java.awt.Shape shape10 = piePlot5.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("ThreadContext", font3, (org.jfree.chart.plot.Plot) piePlot5, false);
        jFreeChart12.setBorderVisible(true);
        org.jfree.chart.title.TextTitle textTitle15 = jFreeChart12.getTitle();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(textTitle15);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        categoryPlot21.setDomainAxis(categoryAxis22);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent24 = null;
        categoryPlot21.datasetChanged(datasetChangeEvent24);
        org.jfree.chart.util.Layer layer27 = null;
        java.util.Collection collection28 = categoryPlot21.getDomainMarkers((int) 'a', layer27);
        categoryPlot21.configureDomainAxes();
        java.lang.String str30 = categoryPlot21.getPlotType();
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = categoryPlot21.getDomainAxisEdge(4);
        categoryPlot21.mapDatasetToRangeAxis(15, (int) '#');
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(collection28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Category Plot" + "'", str30.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangleEdge32);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str1 = xYPlot0.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        xYPlot0.setDataset(0, xYDataset3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = xYPlot0.getRangeAxisForDataset(0);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot7.getRendererForDataset(xYDataset8);
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        xYPlot7.setDomainAxis(valueAxis10);
        xYPlot7.clearRangeMarkers();
        java.awt.Stroke stroke13 = xYPlot7.getDomainGridlineStroke();
        xYPlot0.setDomainGridlineStroke(stroke13);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "XY Plot" + "'", str1.equals("XY Plot"));
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setTranslateY((double) (short) 0);
        blockParams0.setGenerateEntities(false);
        blockParams0.setTranslateY(1.0d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = xYPlot0.getRendererForDataset(xYDataset1);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.util.List list5 = null;
        xYPlot0.drawDomainTickBands(graphics2D3, rectangle2D4, list5);
        xYPlot0.zoom(0.0d);
        java.awt.Color color10 = java.awt.Color.BLUE;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint) color10, stroke11);
        java.awt.Font font13 = valueMarker12.getLabelFont();
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker12);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = xYPlot0.getFixedLegendItems();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.util.Size2D size2D17 = new org.jfree.chart.util.Size2D();
        size2D17.height = 10L;
        size2D17.setHeight(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D25 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D17, 0.05d, (double) 1, rectangleAnchor24);
        org.jfree.chart.plot.RingPlot ringPlot28 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font29 = ringPlot28.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle30 = new org.jfree.chart.title.TextTitle("ThreadContext", font29);
        org.jfree.chart.plot.PiePlot piePlot31 = new org.jfree.chart.plot.PiePlot();
        piePlot31.setLabelGap(0.0d);
        piePlot31.setCircular(true);
        java.awt.Shape shape36 = piePlot31.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart38 = new org.jfree.chart.JFreeChart("ThreadContext", font29, (org.jfree.chart.plot.Plot) piePlot31, false);
        float float39 = jFreeChart38.getBackgroundImageAlpha();
        org.jfree.chart.title.LegendTitle legendTitle41 = jFreeChart38.getLegend((int) ' ');
        int int42 = jFreeChart38.getBackgroundImageAlignment();
        org.jfree.chart.title.LegendTitle legendTitle44 = jFreeChart38.getLegend((-165));
        java.awt.Stroke stroke45 = jFreeChart38.getBorderStroke();
        java.util.List list46 = jFreeChart38.getSubtitles();
        xYPlot0.drawDomainTickBands(graphics2D16, rectangle2D25, list46);
        java.awt.Paint paint48 = xYPlot0.getRangeTickBandPaint();
        org.junit.Assert.assertNull(xYItemRenderer2);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNull(legendItemCollection15);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertTrue("'" + float39 + "' != '" + 0.5f + "'", float39 == 0.5f);
        org.junit.Assert.assertNull(legendTitle41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 15 + "'", int42 == 15);
        org.junit.Assert.assertNull(legendTitle44);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(list46);
        org.junit.Assert.assertNull(paint48);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        numberAxis3D3.setUpperMargin(0.0d);
        numberAxis3D3.setAutoRangeStickyZero(true);
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 0L };
        java.lang.Number[][] numberArray10 = new java.lang.Number[][] { numberArray3, numberArray5, numberArray7, numberArray9 };
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("VerticalAlignment.BOTTOM", "XY Plot", numberArray10);
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset11, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D16 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand17 = null;
        numberAxis3D16.setMarkerBand(markerAxisBand17);
        numberAxis3D16.zoomRange(0.0d, (double) (short) 1);
        org.jfree.data.time.DateRange dateRange22 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str23 = dateRange22.toString();
        boolean boolean26 = dateRange22.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint28 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange22, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint29 = rectangleConstraint28.toUnconstrainedWidth();
        org.jfree.data.Range range30 = rectangleConstraint28.getWidthRange();
        numberAxis3D16.setDefaultAutoRange(range30);
        numberAxis3D16.resizeRange((double) 0, 0.0d);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis14, (org.jfree.chart.axis.ValueAxis) numberAxis3D16, categoryItemRenderer35);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot37 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset11);
        java.lang.Number number38 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset11);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNotNull(dateRange22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str23.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint29);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertTrue("'" + number38 + "' != '" + 0.0d + "'", number38.equals(0.0d));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis3D1.setMarkerBand(markerAxisBand2);
        numberAxis3D1.zoomRange(0.0d, (double) (short) 1);
        numberAxis3D1.setNegativeArrowVisible(false);
        numberAxis3D1.setLabel("Multiple Pie Plot");
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        java.awt.Paint paint0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace1, false);
        java.awt.Paint paint4 = xYPlot0.getOutlinePaint();
        org.jfree.chart.ui.ProjectInfo projectInfo5 = org.jfree.chart.JFreeChart.INFO;
        boolean boolean6 = xYPlot0.equals((java.lang.Object) projectInfo5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        xYPlot7.setFixedRangeAxisSpace(axisSpace8, false);
        java.awt.Paint paint11 = xYPlot7.getOutlinePaint();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier12 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint13 = defaultDrawingSupplier12.getNextFillPaint();
        java.awt.Stroke stroke14 = defaultDrawingSupplier12.getNextOutlineStroke();
        xYPlot7.setDomainCrosshairStroke(stroke14);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder16 = xYPlot7.getSeriesRenderingOrder();
        java.util.List list17 = xYPlot7.getAnnotations();
        projectInfo5.setContributors(list17);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(projectInfo5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(seriesRenderingOrder16);
        org.junit.Assert.assertNotNull(list17);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("TextBlockAnchor.BOTTOM_CENTER", font2);
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=-1.0]", font2);
        org.jfree.chart.block.BlockFrame blockFrame5 = textTitle4.getFrame();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(blockFrame5);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace1, false);
        java.awt.Paint paint4 = xYPlot0.getOutlinePaint();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint6 = defaultDrawingSupplier5.getNextFillPaint();
        java.awt.Stroke stroke7 = defaultDrawingSupplier5.getNextOutlineStroke();
        xYPlot0.setDomainCrosshairStroke(stroke7);
        boolean boolean9 = xYPlot0.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = categoryPlot21.getDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot21.getDomainAxis((-1));
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str26 = xYPlot25.getPlotType();
        boolean boolean27 = xYPlot25.isRangeZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation28 = xYPlot25.getRangeAxisLocation();
        categoryPlot21.setDomainAxisLocation(axisLocation28);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        categoryPlot21.setRenderer(categoryItemRenderer30);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        java.awt.geom.Point2D point2D34 = null;
        categoryPlot21.zoomDomainAxes((double) 10.0f, plotRenderingInfo33, point2D34);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = null;
        java.awt.geom.Point2D point2D38 = null;
        categoryPlot21.zoomDomainAxes((double) 0.0f, plotRenderingInfo37, point2D38);
        java.awt.Paint paint40 = categoryPlot21.getDomainGridlinePaint();
        java.awt.Stroke stroke41 = categoryPlot21.getDomainGridlineStroke();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray42 = null;
        try {
            categoryPlot21.setDomainAxes(categoryAxisArray42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(categoryAxis22);
        org.junit.Assert.assertNull(categoryAxis24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "XY Plot" + "'", str26.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(stroke41);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int2 = color1.getRGB();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo3 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo3.setName("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        boolean boolean6 = color1.equals((java.lang.Object) basicProjectInfo3);
        polarPlot0.setAngleGridlinePaint((java.awt.Paint) color1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { 0L };
        java.lang.Number[][] numberArray20 = new java.lang.Number[][] { numberArray13, numberArray15, numberArray17, numberArray19 };
        org.jfree.data.category.CategoryDataset categoryDataset21 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("VerticalAlignment.BOTTOM", "XY Plot", numberArray20);
        org.jfree.data.Range range22 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset21);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D28 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand29 = null;
        numberAxis3D28.setMarkerBand(markerAxisBand29);
        org.jfree.data.time.DateRange dateRange31 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str32 = dateRange31.toString();
        boolean boolean35 = dateRange31.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint37 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange31, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint38 = rectangleConstraint37.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint40 = rectangleConstraint37.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range41 = rectangleConstraint37.getWidthRange();
        numberAxis3D28.setRangeWithMargins(range41, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset25, categoryAxis26, (org.jfree.chart.axis.ValueAxis) numberAxis3D28, categoryItemRenderer45);
        numberAxis3D28.setUpperMargin(0.0d);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer49 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D24, (org.jfree.chart.axis.ValueAxis) numberAxis3D28, categoryItemRenderer49);
        java.awt.Graphics2D graphics2D51 = null;
        org.jfree.chart.axis.AxisState axisState52 = null;
        org.jfree.chart.util.Size2D size2D53 = new org.jfree.chart.util.Size2D();
        size2D53.height = 10L;
        size2D53.setHeight(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor60 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D61 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D53, 0.05d, (double) 1, rectangleAnchor60);
        org.jfree.chart.util.RectangleEdge rectangleEdge62 = null;
        java.util.List list63 = categoryAxis3D24.refreshTicks(graphics2D51, axisState52, rectangle2D61, rectangleEdge62);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor64 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.geom.Point2D point2D65 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D61, rectangleAnchor64);
        try {
            polarPlot0.zoomRangeAxes((double) 100.0f, plotRenderingInfo9, point2D65, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-32640) + "'", int2 == (-32640));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(categoryDataset21);
        org.junit.Assert.assertNull(range22);
        org.junit.Assert.assertNotNull(dateRange31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str32.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint38);
        org.junit.Assert.assertNotNull(rectangleConstraint40);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(rectangleAnchor60);
        org.junit.Assert.assertNotNull(rectangle2D61);
        org.junit.Assert.assertNotNull(list63);
        org.junit.Assert.assertNotNull(rectangleAnchor64);
        org.junit.Assert.assertNotNull(point2D65);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setLabelGap(0.0d);
        java.awt.Paint paint4 = piePlot0.getSectionPaint((java.lang.Comparable) (byte) 100);
        java.lang.Object obj5 = piePlot0.clone();
        double double7 = piePlot0.getExplodePercent((java.lang.Comparable) 0.0d);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        piePlot0.handleClick((-16777216), (int) (short) -1, plotRenderingInfo10);
        piePlot0.setPieIndex((int) (byte) -1);
        piePlot0.setPieIndex(4);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = categoryPlot21.getDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot21.getDomainAxis((-1));
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str26 = xYPlot25.getPlotType();
        boolean boolean27 = xYPlot25.isRangeZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation28 = xYPlot25.getRangeAxisLocation();
        categoryPlot21.setDomainAxisLocation(axisLocation28);
        org.jfree.chart.axis.AxisSpace axisSpace30 = null;
        categoryPlot21.setFixedDomainAxisSpace(axisSpace30);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D33 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand34 = null;
        numberAxis3D33.setMarkerBand(markerAxisBand34);
        java.awt.Shape shape36 = numberAxis3D33.getRightArrow();
        numberAxis3D33.setVisible(false);
        org.jfree.data.Range range39 = categoryPlot21.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D33);
        java.awt.Paint paint40 = categoryPlot21.getRangeGridlinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = categoryPlot21.getAxisOffset();
        double double42 = rectangleInsets41.getTop();
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(categoryAxis22);
        org.junit.Assert.assertNull(categoryAxis24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "XY Plot" + "'", str26.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNull(range39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 4.0d + "'", double42 == 4.0d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setSectionDepth((double) 'a');
        java.awt.Shape shape3 = ringPlot0.getLegendItemShape();
        java.lang.String str4 = ringPlot0.getPlotType();
        org.jfree.chart.util.Rotation rotation5 = ringPlot0.getDirection();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = ringPlot0.getLabelPadding();
        org.jfree.chart.plot.RingPlot ringPlot9 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font10 = ringPlot9.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("ThreadContext", font10);
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot();
        piePlot12.setLabelGap(0.0d);
        piePlot12.setCircular(true);
        java.awt.Shape shape17 = piePlot12.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("ThreadContext", font10, (org.jfree.chart.plot.Plot) piePlot12, false);
        float float20 = jFreeChart19.getBackgroundImageAlpha();
        org.jfree.chart.title.LegendTitle legendTitle22 = jFreeChart19.getLegend((int) ' ');
        int int23 = jFreeChart19.getBackgroundImageAlignment();
        org.jfree.chart.title.LegendTitle legendTitle25 = jFreeChart19.getLegend((-165));
        java.awt.Stroke stroke26 = jFreeChart19.getBorderStroke();
        ringPlot0.setSeparatorStroke(stroke26);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Pie Plot" + "'", str4.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(rotation5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 0.5f + "'", float20 == 0.5f);
        org.junit.Assert.assertNull(legendTitle22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 15 + "'", int23 == 15);
        org.junit.Assert.assertNull(legendTitle25);
        org.junit.Assert.assertNotNull(stroke26);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        boolean boolean2 = ringPlot1.getIgnoreZeroValues();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        piePlot5.setLabelGap(0.0d);
        piePlot5.setCircular(true);
        double double10 = piePlot5.getShadowYOffset();
        java.awt.Font font11 = piePlot5.getLabelFont();
        piePlot5.setIgnoreNullValues(true);
        boolean boolean14 = piePlot5.getSectionOutlinesVisible();
        java.awt.Stroke stroke16 = piePlot5.getSectionOutlineStroke((java.lang.Comparable) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        org.jfree.chart.plot.PiePlotState piePlotState19 = ringPlot1.initialise(graphics2D3, rectangle2D4, piePlot5, (java.lang.Integer) (-1), plotRenderingInfo18);
        piePlotState19.setPieCenterX(1.0d);
        java.awt.geom.Rectangle2D rectangle2D22 = piePlotState19.getPieArea();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = piePlotState19.getInfo();
        double double24 = piePlotState19.getTotal();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(stroke16);
        org.junit.Assert.assertNotNull(piePlotState19);
        org.junit.Assert.assertNull(rectangle2D22);
        org.junit.Assert.assertNull(plotRenderingInfo23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str1 = xYPlot0.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        xYPlot0.setDataset(0, xYDataset3);
        java.lang.Class<?> wildcardClass5 = xYPlot0.getClass();
        xYPlot0.setRangeZeroBaselineVisible(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        xYPlot0.zoomRangeAxes((double) 1, (double) (-165), plotRenderingInfo10, point2D11);
        java.awt.Paint paint13 = xYPlot0.getDomainCrosshairPaint();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "XY Plot" + "'", str1.equals("XY Plot"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setSectionDepth((double) 'a');
        java.awt.Shape shape3 = ringPlot0.getLegendItemShape();
        java.lang.String str4 = ringPlot0.getPlotType();
        org.jfree.chart.util.Rotation rotation5 = ringPlot0.getDirection();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = ringPlot0.getLabelPadding();
        double double8 = rectangleInsets6.calculateTopOutset((double) (short) 0);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Pie Plot" + "'", str4.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(rotation5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.0d + "'", double8 == 2.0d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = categoryPlot21.getDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot21.getDomainAxis((-1));
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str26 = xYPlot25.getPlotType();
        boolean boolean27 = xYPlot25.isRangeZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation28 = xYPlot25.getRangeAxisLocation();
        categoryPlot21.setDomainAxisLocation(axisLocation28);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        categoryPlot21.setRenderer(categoryItemRenderer30);
        categoryPlot21.setRangeCrosshairLockedOnData(true);
        java.awt.Color color35 = java.awt.Color.BLUE;
        java.awt.Stroke stroke36 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker37 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint) color35, stroke36);
        categoryPlot21.setOutlineStroke(stroke36);
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = categoryPlot21.getDomainAxis(100);
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(categoryAxis22);
        org.junit.Assert.assertNull(categoryAxis24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "XY Plot" + "'", str26.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNull(categoryAxis40);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        piePlot1.setLabelGap(0.0d);
        piePlot1.setCircular(true);
        double double6 = piePlot1.getShadowYOffset();
        java.awt.Font font7 = piePlot1.getLabelFont();
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.text.TextFragment textFragment10 = new org.jfree.chart.text.TextFragment("TextBlockAnchor.BOTTOM_CENTER", font7, (java.awt.Paint) color8, 0.0f);
        java.awt.Font font11 = textFragment10.getFont();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(font11);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        boolean boolean2 = ringPlot1.getIgnoreZeroValues();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        piePlot5.setLabelGap(0.0d);
        piePlot5.setCircular(true);
        double double10 = piePlot5.getShadowYOffset();
        java.awt.Font font11 = piePlot5.getLabelFont();
        piePlot5.setIgnoreNullValues(true);
        boolean boolean14 = piePlot5.getSectionOutlinesVisible();
        java.awt.Stroke stroke16 = piePlot5.getSectionOutlineStroke((java.lang.Comparable) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        org.jfree.chart.plot.PiePlotState piePlotState19 = ringPlot1.initialise(graphics2D3, rectangle2D4, piePlot5, (java.lang.Integer) (-1), plotRenderingInfo18);
        piePlotState19.setPieCenterX(1.0d);
        piePlotState19.setTotal((double) 10.0f);
        double double24 = piePlotState19.getPieWRadius();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(stroke16);
        org.junit.Assert.assertNotNull(piePlotState19);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        java.lang.Object obj1 = size2D0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace2 = null;
        xYPlot1.setFixedRangeAxisSpace(axisSpace2, false);
        java.awt.Paint paint5 = xYPlot1.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) xYPlot1);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int8 = color7.getRGB();
        xYPlot1.setRangeZeroBaselinePaint((java.awt.Paint) color7);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis3D14.setMarkerBand(markerAxisBand15);
        org.jfree.data.time.DateRange dateRange17 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str18 = dateRange17.toString();
        boolean boolean21 = dateRange17.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange17, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint24 = rectangleConstraint23.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = rectangleConstraint23.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range27 = rectangleConstraint23.getWidthRange();
        numberAxis3D14.setRangeWithMargins(range27, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, categoryItemRenderer31);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = categoryPlot32.getDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = categoryPlot32.getDomainAxis((-1));
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str37 = xYPlot36.getPlotType();
        boolean boolean38 = xYPlot36.isRangeZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation39 = xYPlot36.getRangeAxisLocation();
        categoryPlot32.setDomainAxisLocation(axisLocation39);
        org.jfree.chart.axis.AxisSpace axisSpace41 = null;
        categoryPlot32.setFixedDomainAxisSpace(axisSpace41);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D44 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand45 = null;
        numberAxis3D44.setMarkerBand(markerAxisBand45);
        java.awt.Shape shape47 = numberAxis3D44.getRightArrow();
        numberAxis3D44.setVisible(false);
        org.jfree.data.Range range50 = categoryPlot32.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D44);
        numberAxis3D44.setRange((double) 0L, (double) 10L);
        org.jfree.data.RangeType rangeType54 = numberAxis3D44.getRangeType();
        xYPlot1.setRangeAxis((int) (byte) 1, (org.jfree.chart.axis.ValueAxis) numberAxis3D44);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-32640) + "'", int8 == (-32640));
        org.junit.Assert.assertNotNull(dateRange17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str18.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint24);
        org.junit.Assert.assertNotNull(rectangleConstraint26);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertNull(categoryAxis33);
        org.junit.Assert.assertNull(categoryAxis35);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "XY Plot" + "'", str37.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertNotNull(shape47);
        org.junit.Assert.assertNull(range50);
        org.junit.Assert.assertNotNull(rangeType54);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setSectionDepth((double) 'a');
        java.awt.Shape shape3 = ringPlot0.getLegendItemShape();
        ringPlot0.setBackgroundImageAlignment((int) (short) -1);
        boolean boolean6 = ringPlot0.getLabelLinksVisible();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke2 = ringPlot1.getLabelLinkStroke();
        double double3 = ringPlot1.getOuterSeparatorExtension();
        java.awt.Stroke stroke4 = ringPlot1.getBaseSectionOutlineStroke();
        double double5 = ringPlot1.getLabelGap();
        int int6 = objectList0.indexOf((java.lang.Object) ringPlot1);
        boolean boolean7 = ringPlot1.getSectionOutlinesVisible();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.025d + "'", double5 == 0.025d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setLabelGap(0.0d);
        piePlot0.setCircular(true);
        java.awt.Shape shape5 = piePlot0.getLegendItemShape();
        org.jfree.chart.entity.ChartEntity chartEntity8 = new org.jfree.chart.entity.ChartEntity(shape5, "hi!", "Multiple Pie Plot");
        java.lang.String str9 = chartEntity8.getToolTipText();
        java.lang.Object obj10 = chartEntity8.clone();
        java.lang.Object obj11 = chartEntity8.clone();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder((double) 0, 4.0d, (double) '#', (double) (short) -1, (java.awt.Paint) color4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = blockBorder5.getInsets();
        double double8 = rectangleInsets6.extendHeight((double) '4');
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 87.0d + "'", double8 == 87.0d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        polarPlot0.setAngleTickUnit((org.jfree.chart.axis.TickUnit) dateTickUnit1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.lang.Number[] numberArray8 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray12 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 0L };
        java.lang.Number[][] numberArray15 = new java.lang.Number[][] { numberArray8, numberArray10, numberArray12, numberArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("VerticalAlignment.BOTTOM", "XY Plot", numberArray15);
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset16);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D19 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D23 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand24 = null;
        numberAxis3D23.setMarkerBand(markerAxisBand24);
        org.jfree.data.time.DateRange dateRange26 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str27 = dateRange26.toString();
        boolean boolean30 = dateRange26.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint32 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange26, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint33 = rectangleConstraint32.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint35 = rectangleConstraint32.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range36 = rectangleConstraint32.getWidthRange();
        numberAxis3D23.setRangeWithMargins(range36, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, (org.jfree.chart.axis.ValueAxis) numberAxis3D23, categoryItemRenderer40);
        numberAxis3D23.setUpperMargin(0.0d);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D19, (org.jfree.chart.axis.ValueAxis) numberAxis3D23, categoryItemRenderer44);
        java.awt.Graphics2D graphics2D46 = null;
        org.jfree.chart.axis.AxisState axisState47 = null;
        org.jfree.chart.util.Size2D size2D48 = new org.jfree.chart.util.Size2D();
        size2D48.height = 10L;
        size2D48.setHeight(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor55 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D56 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D48, 0.05d, (double) 1, rectangleAnchor55);
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = null;
        java.util.List list58 = categoryAxis3D19.refreshTicks(graphics2D46, axisState47, rectangle2D56, rectangleEdge57);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor59 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.geom.Point2D point2D60 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D56, rectangleAnchor59);
        try {
            polarPlot0.zoomRangeAxes((double) 4, plotRenderingInfo4, point2D60);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNotNull(dateRange26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str27.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint33);
        org.junit.Assert.assertNotNull(rectangleConstraint35);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertNotNull(rectangleAnchor55);
        org.junit.Assert.assertNotNull(rectangle2D56);
        org.junit.Assert.assertNotNull(list58);
        org.junit.Assert.assertNotNull(rectangleAnchor59);
        org.junit.Assert.assertNotNull(point2D60);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = categoryPlot21.getDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot21.getDomainAxis((-1));
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str26 = xYPlot25.getPlotType();
        boolean boolean27 = xYPlot25.isRangeZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation28 = xYPlot25.getRangeAxisLocation();
        categoryPlot21.setDomainAxisLocation(axisLocation28);
        org.jfree.chart.axis.AxisSpace axisSpace30 = null;
        categoryPlot21.setFixedDomainAxisSpace(axisSpace30);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D33 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand34 = null;
        numberAxis3D33.setMarkerBand(markerAxisBand34);
        java.awt.Shape shape36 = numberAxis3D33.getRightArrow();
        numberAxis3D33.setVisible(false);
        org.jfree.data.Range range39 = categoryPlot21.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D33);
        java.awt.Graphics2D graphics2D40 = null;
        org.jfree.chart.plot.XYPlot xYPlot41 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str42 = xYPlot41.getPlotType();
        xYPlot41.mapDatasetToRangeAxis((int) (short) -1, 0);
        org.jfree.chart.block.LineBorder lineBorder46 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = lineBorder46.getInsets();
        double double49 = rectangleInsets47.calculateRightInset((double) 0.5f);
        xYPlot41.setInsets(rectangleInsets47, true);
        java.awt.geom.Rectangle2D rectangle2D52 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean54 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge53);
        org.jfree.chart.axis.AxisSpace axisSpace55 = null;
        org.jfree.chart.axis.AxisSpace axisSpace56 = numberAxis3D33.reserveSpace(graphics2D40, (org.jfree.chart.plot.Plot) xYPlot41, rectangle2D52, rectangleEdge53, axisSpace55);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit57 = numberAxis3D33.getTickUnit();
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(categoryAxis22);
        org.junit.Assert.assertNull(categoryAxis24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "XY Plot" + "'", str26.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNull(range39);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "XY Plot" + "'", str42.equals("XY Plot"));
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 1.0d + "'", double49 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleEdge53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(axisSpace56);
        org.junit.Assert.assertNotNull(numberTickUnit57);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("ThreadContext", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        java.lang.String str0 = org.jfree.chart.ui.Licences.LGPL;
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setSectionDepth((double) 'a');
        java.awt.Shape shape3 = ringPlot0.getLegendItemShape();
        ringPlot0.setBackgroundImageAlignment((int) (short) -1);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent6 = null;
        ringPlot0.notifyListeners(plotChangeEvent6);
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font2 = ringPlot1.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("ThreadContext", font2);
        textTitle3.setURLText("hi!");
        double double6 = textTitle3.getContentXOffset();
        double double7 = textTitle3.getContentXOffset();
        textTitle3.setToolTipText("RectangleAnchor.TOP");
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = xYPlot10.getRendererForDataset(xYDataset11);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.util.List list15 = null;
        xYPlot10.drawDomainTickBands(graphics2D13, rectangle2D14, list15);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray18 = new org.jfree.chart.axis.ValueAxis[] { valueAxis17 };
        xYPlot10.setRangeAxes(valueAxisArray18);
        boolean boolean20 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) textTitle3, (java.lang.Object) xYPlot10);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D24 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = null;
        numberAxis3D24.setMarkerBand(markerAxisBand25);
        org.jfree.data.time.DateRange dateRange27 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str28 = dateRange27.toString();
        boolean boolean31 = dateRange27.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint33 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange27, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint34 = rectangleConstraint33.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint36 = rectangleConstraint33.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range37 = rectangleConstraint33.getWidthRange();
        numberAxis3D24.setRangeWithMargins(range37, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, (org.jfree.chart.axis.ValueAxis) numberAxis3D24, categoryItemRenderer41);
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = categoryPlot42.getDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = categoryPlot42.getDomainAxis((-1));
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str47 = xYPlot46.getPlotType();
        boolean boolean48 = xYPlot46.isRangeZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation49 = xYPlot46.getRangeAxisLocation();
        categoryPlot42.setDomainAxisLocation(axisLocation49);
        org.jfree.chart.axis.AxisSpace axisSpace51 = null;
        categoryPlot42.setFixedDomainAxisSpace(axisSpace51);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D54 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand55 = null;
        numberAxis3D54.setMarkerBand(markerAxisBand55);
        java.awt.Shape shape57 = numberAxis3D54.getRightArrow();
        numberAxis3D54.setVisible(false);
        org.jfree.data.Range range60 = categoryPlot42.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D54);
        java.awt.Graphics2D graphics2D61 = null;
        org.jfree.chart.plot.XYPlot xYPlot62 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str63 = xYPlot62.getPlotType();
        xYPlot62.mapDatasetToRangeAxis((int) (short) -1, 0);
        org.jfree.chart.block.LineBorder lineBorder67 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets68 = lineBorder67.getInsets();
        double double70 = rectangleInsets68.calculateRightInset((double) 0.5f);
        xYPlot62.setInsets(rectangleInsets68, true);
        java.awt.geom.Rectangle2D rectangle2D73 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge74 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean75 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge74);
        org.jfree.chart.axis.AxisSpace axisSpace76 = null;
        org.jfree.chart.axis.AxisSpace axisSpace77 = numberAxis3D54.reserveSpace(graphics2D61, (org.jfree.chart.plot.Plot) xYPlot62, rectangle2D73, rectangleEdge74, axisSpace76);
        xYPlot10.setFixedRangeAxisSpace(axisSpace76, true);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNull(xYItemRenderer12);
        org.junit.Assert.assertNotNull(valueAxisArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateRange27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str28.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint34);
        org.junit.Assert.assertNotNull(rectangleConstraint36);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertNull(categoryAxis43);
        org.junit.Assert.assertNull(categoryAxis45);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "XY Plot" + "'", str47.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(axisLocation49);
        org.junit.Assert.assertNotNull(shape57);
        org.junit.Assert.assertNull(range60);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "XY Plot" + "'", str63.equals("XY Plot"));
        org.junit.Assert.assertNotNull(rectangleInsets68);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 1.0d + "'", double70 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleEdge74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(axisSpace77);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = xYPlot0.getRendererForDataset(xYDataset1);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.util.List list5 = null;
        xYPlot0.drawDomainTickBands(graphics2D3, rectangle2D4, list5);
        xYPlot0.zoom(0.0d);
        java.awt.Color color10 = java.awt.Color.BLUE;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint) color10, stroke11);
        java.awt.Font font13 = valueMarker12.getLabelFont();
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker12);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = valueMarker12.getLabelOffset();
        float float16 = valueMarker12.getAlpha();
        org.junit.Assert.assertNull(xYItemRenderer2);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 1.0f + "'", float16 == 1.0f);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis3D1.setMarkerBand(markerAxisBand2);
        numberAxis3D1.zoomRange(0.0d, (double) (short) 1);
        numberAxis3D1.setNegativeArrowVisible(false);
        double double9 = numberAxis3D1.getUpperBound();
        boolean boolean10 = numberAxis3D1.isVisible();
        numberAxis3D1.setAutoRangeIncludesZero(false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str1 = xYPlot0.getPlotType();
        boolean boolean2 = xYPlot0.isDomainZeroBaselineVisible();
        java.awt.Paint paint3 = xYPlot0.getRangeCrosshairPaint();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "XY Plot" + "'", str1.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        polarPlot0.setAngleTickUnit((org.jfree.chart.axis.TickUnit) dateTickUnit1);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        polarPlot0.setRenderer(polarItemRenderer3);
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray12 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0L };
        java.lang.Number[][] numberArray17 = new java.lang.Number[][] { numberArray10, numberArray12, numberArray14, numberArray16 };
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("VerticalAlignment.BOTTOM", "XY Plot", numberArray17);
        org.jfree.data.Range range19 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D21 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D25 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand26 = null;
        numberAxis3D25.setMarkerBand(markerAxisBand26);
        org.jfree.data.time.DateRange dateRange28 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str29 = dateRange28.toString();
        boolean boolean32 = dateRange28.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint34 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange28, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint35 = rectangleConstraint34.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint37 = rectangleConstraint34.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range38 = rectangleConstraint34.getWidthRange();
        numberAxis3D25.setRangeWithMargins(range38, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, (org.jfree.chart.axis.ValueAxis) numberAxis3D25, categoryItemRenderer42);
        numberAxis3D25.setUpperMargin(0.0d);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer46 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D21, (org.jfree.chart.axis.ValueAxis) numberAxis3D25, categoryItemRenderer46);
        java.awt.Graphics2D graphics2D48 = null;
        org.jfree.chart.axis.AxisState axisState49 = null;
        org.jfree.chart.util.Size2D size2D50 = new org.jfree.chart.util.Size2D();
        size2D50.height = 10L;
        size2D50.setHeight(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor57 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D58 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D50, 0.05d, (double) 1, rectangleAnchor57);
        org.jfree.chart.util.RectangleEdge rectangleEdge59 = null;
        java.util.List list60 = categoryAxis3D21.refreshTicks(graphics2D48, axisState49, rectangle2D58, rectangleEdge59);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor61 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.geom.Point2D point2D62 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D58, rectangleAnchor61);
        try {
            java.awt.Point point63 = polarPlot0.translateValueThetaRadiusToJava2D((double) 4, 0.08d, rectangle2D58);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(categoryDataset18);
        org.junit.Assert.assertNull(range19);
        org.junit.Assert.assertNotNull(dateRange28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str29.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint35);
        org.junit.Assert.assertNotNull(rectangleConstraint37);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(rectangleAnchor57);
        org.junit.Assert.assertNotNull(rectangle2D58);
        org.junit.Assert.assertNotNull(list60);
        org.junit.Assert.assertNotNull(rectangleAnchor61);
        org.junit.Assert.assertNotNull(point2D62);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.lang.Object obj1 = piePlot0.clone();
        boolean boolean2 = piePlot0.isOutlineVisible();
        piePlot0.setIgnoreNullValues(false);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace1, false);
        java.awt.Paint paint4 = xYPlot0.getOutlinePaint();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint6 = defaultDrawingSupplier5.getNextFillPaint();
        java.awt.Stroke stroke7 = defaultDrawingSupplier5.getNextOutlineStroke();
        xYPlot0.setDomainCrosshairStroke(stroke7);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder9 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot10.setFixedRangeAxisSpace(axisSpace11, false);
        java.awt.Paint paint14 = xYPlot10.getOutlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation16 = xYPlot10.getRangeAxisLocation((-16777216));
        xYPlot0.setDomainAxisLocation(axisLocation16, false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(seriesRenderingOrder9);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(axisLocation16);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        java.awt.Color color0 = java.awt.Color.magenta;
        java.awt.Font font3 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("TextBlockAnchor.BOTTOM_CENTER", font3);
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=-1.0]", font3);
        java.lang.String str6 = textTitle5.getURLText();
        boolean boolean7 = color0.equals((java.lang.Object) str6);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        categoryPlot21.setDomainAxis(categoryAxis22);
        java.util.List list24 = categoryPlot21.getCategories();
        org.jfree.chart.LegendItemCollection legendItemCollection25 = categoryPlot21.getFixedLegendItems();
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(list24);
        org.junit.Assert.assertNull(legendItemCollection25);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font3 = ringPlot2.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("ThreadContext", font3);
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        piePlot5.setLabelGap(0.0d);
        piePlot5.setCircular(true);
        java.awt.Shape shape10 = piePlot5.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("ThreadContext", font3, (org.jfree.chart.plot.Plot) piePlot5, false);
        org.jfree.chart.plot.Plot plot13 = piePlot5.getParent();
        piePlot5.setShadowYOffset((double) 100);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNull(plot13);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str4 = dateRange3.toString();
        boolean boolean7 = dateRange3.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange3, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = rectangleConstraint9.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = rectangleConstraint9.toFixedWidth((double) 0.0f);
        org.jfree.chart.util.Size2D size2D13 = columnArrangement0.arrange(blockContainer1, graphics2D2, rectangleConstraint12);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.plot.RingPlot ringPlot17 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font18 = ringPlot17.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("ThreadContext", font18);
        org.jfree.chart.plot.PiePlot piePlot20 = new org.jfree.chart.plot.PiePlot();
        piePlot20.setLabelGap(0.0d);
        piePlot20.setCircular(true);
        java.awt.Shape shape25 = piePlot20.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("ThreadContext", font18, (org.jfree.chart.plot.Plot) piePlot20, false);
        jFreeChart27.setBorderVisible(false);
        java.awt.RenderingHints renderingHints30 = jFreeChart27.getRenderingHints();
        org.jfree.chart.title.TextTitle textTitle31 = jFreeChart27.getTitle();
        java.lang.Number[] numberArray35 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray37 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray41 = new java.lang.Number[] { 0L };
        java.lang.Number[][] numberArray42 = new java.lang.Number[][] { numberArray35, numberArray37, numberArray39, numberArray41 };
        org.jfree.data.category.CategoryDataset categoryDataset43 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("VerticalAlignment.BOTTOM", "XY Plot", numberArray42);
        org.jfree.data.Range range44 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset43);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D46 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset47 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D50 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand51 = null;
        numberAxis3D50.setMarkerBand(markerAxisBand51);
        org.jfree.data.time.DateRange dateRange53 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str54 = dateRange53.toString();
        boolean boolean57 = dateRange53.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint59 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange53, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint60 = rectangleConstraint59.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint62 = rectangleConstraint59.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range63 = rectangleConstraint59.getWidthRange();
        numberAxis3D50.setRangeWithMargins(range63, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer67 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot68 = new org.jfree.chart.plot.CategoryPlot(categoryDataset47, categoryAxis48, (org.jfree.chart.axis.ValueAxis) numberAxis3D50, categoryItemRenderer67);
        numberAxis3D50.setUpperMargin(0.0d);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer71 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot72 = new org.jfree.chart.plot.CategoryPlot(categoryDataset43, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D46, (org.jfree.chart.axis.ValueAxis) numberAxis3D50, categoryItemRenderer71);
        java.awt.Graphics2D graphics2D73 = null;
        org.jfree.chart.axis.AxisState axisState74 = null;
        org.jfree.chart.util.Size2D size2D75 = new org.jfree.chart.util.Size2D();
        size2D75.height = 10L;
        size2D75.setHeight(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor82 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D83 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D75, 0.05d, (double) 1, rectangleAnchor82);
        org.jfree.chart.util.RectangleEdge rectangleEdge84 = null;
        java.util.List list85 = categoryAxis3D46.refreshTicks(graphics2D73, axisState74, rectangle2D83, rectangleEdge84);
        textTitle31.setBounds(rectangle2D83);
        java.lang.Object obj87 = null;
        try {
            java.lang.Object obj88 = blockContainer1.draw(graphics2D14, rectangle2D83, obj87);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateRange3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str4.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint10);
        org.junit.Assert.assertNotNull(rectangleConstraint12);
        org.junit.Assert.assertNotNull(size2D13);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(renderingHints30);
        org.junit.Assert.assertNotNull(textTitle31);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(numberArray37);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray41);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(categoryDataset43);
        org.junit.Assert.assertNull(range44);
        org.junit.Assert.assertNotNull(dateRange53);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str54.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint60);
        org.junit.Assert.assertNotNull(rectangleConstraint62);
        org.junit.Assert.assertNotNull(range63);
        org.junit.Assert.assertNotNull(rectangleAnchor82);
        org.junit.Assert.assertNotNull(rectangle2D83);
        org.junit.Assert.assertNotNull(list85);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = xYPlot0.getRendererForDataset(xYDataset1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        xYPlot0.setDomainAxis(valueAxis3);
        java.awt.Paint paint5 = xYPlot0.getRangeCrosshairPaint();
        java.lang.String str6 = xYPlot0.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset8 = xYPlot0.getDataset((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis10 = xYPlot0.getDomainAxis((int) (byte) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = xYPlot0.getDomainAxisEdge();
        xYPlot0.setDomainGridlinesVisible(true);
        org.junit.Assert.assertNull(xYItemRenderer2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "XY Plot" + "'", str6.equals("XY Plot"));
        org.junit.Assert.assertNull(xYDataset8);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(rectangleEdge11);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer1 = new org.jfree.chart.text.G2TextMeasurer(graphics2D0);
        try {
            float float5 = g2TextMeasurer1.getStringWidth("Range[0.0,0.0]", (-32640), 15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font3 = ringPlot2.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("ThreadContext", font3);
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        piePlot5.setLabelGap(0.0d);
        piePlot5.setCircular(true);
        java.awt.Shape shape10 = piePlot5.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("ThreadContext", font3, (org.jfree.chart.plot.Plot) piePlot5, false);
        float float13 = jFreeChart12.getBackgroundImageAlpha();
        org.jfree.chart.title.LegendTitle legendTitle15 = jFreeChart12.getLegend((int) ' ');
        int int16 = jFreeChart12.getBackgroundImageAlignment();
        org.jfree.chart.title.LegendTitle legendTitle18 = jFreeChart12.getLegend((-165));
        java.awt.Stroke stroke19 = jFreeChart12.getBorderStroke();
        java.util.List list20 = jFreeChart12.getSubtitles();
        boolean boolean22 = jFreeChart12.equals((java.lang.Object) false);
        java.awt.RenderingHints renderingHints23 = jFreeChart12.getRenderingHints();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.5f + "'", float13 == 0.5f);
        org.junit.Assert.assertNull(legendTitle15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 15 + "'", int16 == 15);
        org.junit.Assert.assertNull(legendTitle18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(renderingHints23);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str1 = xYPlot0.getPlotType();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = xYPlot2.getRendererForDataset(xYDataset3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        xYPlot2.setDomainAxis(valueAxis5);
        java.awt.Color color7 = java.awt.Color.BLACK;
        float[] floatArray17 = new float[] { 0L, (short) 100, 10.0f, (short) 100, 0.0f, 1L };
        float[] floatArray18 = java.awt.Color.RGBtoHSB((int) (byte) -1, (int) '#', (int) ' ', floatArray17);
        float[] floatArray19 = color7.getRGBColorComponents(floatArray17);
        xYPlot2.setDomainGridlinePaint((java.awt.Paint) color7);
        org.jfree.chart.axis.ValueAxis valueAxis22 = xYPlot2.getRangeAxisForDataset(0);
        boolean boolean23 = xYPlot2.isRangeZoomable();
        xYPlot2.setDomainCrosshairLockedOnData(false);
        java.awt.Color color27 = java.awt.Color.BLUE;
        java.awt.Stroke stroke28 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker29 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint) color27, stroke28);
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str32 = xYPlot31.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        xYPlot31.setDataset(0, xYDataset34);
        java.lang.Class<?> wildcardClass36 = xYPlot31.getClass();
        java.net.URL uRL37 = org.jfree.chart.util.ObjectUtilities.getResource("Multiple Pie Plot", (java.lang.Class) wildcardClass36);
        java.util.EventListener[] eventListenerArray38 = valueMarker29.getListeners((java.lang.Class) wildcardClass36);
        org.jfree.chart.text.TextAnchor textAnchor39 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        valueMarker29.setLabelTextAnchor(textAnchor39);
        xYPlot2.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker29);
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker29);
        java.lang.String str43 = valueMarker29.getLabel();
        java.awt.Paint paint44 = valueMarker29.getLabelPaint();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "XY Plot" + "'", str1.equals("XY Plot"));
        org.junit.Assert.assertNull(xYItemRenderer4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNull(valueAxis22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "XY Plot" + "'", str32.equals("XY Plot"));
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNull(uRL37);
        org.junit.Assert.assertNotNull(eventListenerArray38);
        org.junit.Assert.assertNotNull(textAnchor39);
        org.junit.Assert.assertNull(str43);
        org.junit.Assert.assertNotNull(paint44);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str1 = xYPlot0.getPlotType();
        boolean boolean2 = xYPlot0.isDomainZeroBaselineVisible();
        org.jfree.chart.util.Layer layer3 = null;
        java.util.Collection collection4 = xYPlot0.getDomainMarkers(layer3);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "XY Plot" + "'", str1.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(collection4);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str1 = xYPlot0.getPlotType();
        java.awt.Paint paint2 = xYPlot0.getRangeCrosshairPaint();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "XY Plot" + "'", str1.equals("XY Plot"));
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str3 = xYPlot2.getPlotType();
        xYPlot2.mapDatasetToRangeAxis((int) (short) -1, 0);
        org.jfree.chart.block.LineBorder lineBorder7 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = lineBorder7.getInsets();
        double double10 = rectangleInsets8.calculateRightInset((double) 0.5f);
        xYPlot2.setInsets(rectangleInsets8, true);
        org.jfree.chart.util.UnitType unitType13 = rectangleInsets8.getUnitType();
        valueMarker1.setLabelOffset(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "XY Plot" + "'", str3.equals("XY Plot"));
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(unitType13);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
        blockContainer1.clear();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str5 = dateRange4.toString();
        boolean boolean8 = dateRange4.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = rectangleConstraint10.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint10.toFixedWidth((double) 0.0f);
        org.jfree.chart.util.Size2D size2D14 = flowArrangement0.arrange(blockContainer1, graphics2D3, rectangleConstraint10);
        blockContainer1.setHeight((double) (-1));
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str5.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint11);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(size2D14);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=-1.0]", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        java.awt.Paint paint2 = paintMap0.getPaint((java.lang.Comparable) "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        org.junit.Assert.assertNull(paint2);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.lang.String str2 = multiplePiePlot1.getPlotType();
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font5 = ringPlot4.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("ThreadContext", font5);
        java.awt.Color color7 = java.awt.Color.BLACK;
        textTitle6.setPaint((java.awt.Paint) color7);
        multiplePiePlot1.setAggregatedItemsPaint((java.awt.Paint) color7);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = multiplePiePlot1.getLegendItems();
        multiplePiePlot1.setLimit(0.0d);
        org.jfree.data.category.CategoryDataset categoryDataset13 = multiplePiePlot1.getDataset();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Multiple Pie Plot" + "'", str2.equals("Multiple Pie Plot"));
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertNull(categoryDataset13);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double1 = rectangleInsets0.getBottom();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        float float22 = numberAxis3D3.getTickMarkInsideLength();
        numberAxis3D3.resizeRange(0.08d);
        numberAxis3D3.setRange((double) 0, (double) 255);
        numberAxis3D3.setAutoRangeStickyZero(true);
        boolean boolean30 = numberAxis3D3.isVisible();
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.0f + "'", float22 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setLabelGap(100.0d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("", "{0}");
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = xYPlot0.getRendererForDataset(xYDataset1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        xYPlot0.setDomainAxis(valueAxis3);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder10 = new org.jfree.chart.block.BlockBorder((double) 0, 4.0d, (double) '#', (double) (short) -1, (java.awt.Paint) color9);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = blockBorder10.getInsets();
        xYPlot0.setAxisOffset(rectangleInsets11);
        org.junit.Assert.assertNull(xYItemRenderer2);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(rectangleInsets11);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "ChartChangeEventType.DATASET_UPDATED", "ThreadContext", "VerticalAlignment.BOTTOM", "ChartChangeEventType.DATASET_UPDATED");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand8 = null;
        numberAxis3D7.setMarkerBand(markerAxisBand8);
        org.jfree.data.time.DateRange dateRange10 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str11 = dateRange10.toString();
        boolean boolean14 = dateRange10.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange10, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = rectangleConstraint16.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = rectangleConstraint16.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range20 = rectangleConstraint16.getWidthRange();
        numberAxis3D7.setRangeWithMargins(range20, true, true);
        boolean boolean24 = numberAxis3D7.isTickLabelsVisible();
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str26 = xYPlot25.getPlotType();
        boolean boolean27 = xYPlot25.isRangeZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation28 = xYPlot25.getRangeAxisLocation();
        boolean boolean29 = numberAxis3D7.equals((java.lang.Object) xYPlot25);
        boolean boolean30 = basicProjectInfo5.equals((java.lang.Object) numberAxis3D7);
        org.junit.Assert.assertNotNull(dateRange10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str11.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint17);
        org.junit.Assert.assertNotNull(rectangleConstraint19);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "XY Plot" + "'", str26.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setLabelGap(0.0d);
        java.awt.Paint paint4 = piePlot0.getSectionPaint((java.lang.Comparable) (byte) 100);
        java.lang.Object obj5 = piePlot0.clone();
        double double7 = piePlot0.getExplodePercent((java.lang.Comparable) 0.0d);
        java.awt.Paint paint8 = piePlot0.getShadowPaint();
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        categoryPlot21.setDomainAxis(categoryAxis22);
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace26 = null;
        xYPlot25.setFixedRangeAxisSpace(axisSpace26, false);
        java.awt.Paint paint29 = xYPlot25.getOutlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation31 = xYPlot25.getRangeAxisLocation((-16777216));
        categoryPlot21.setRangeAxisLocation((int) (short) 100, axisLocation31);
        org.jfree.chart.axis.AxisLocation axisLocation34 = null;
        categoryPlot21.setRangeAxisLocation((int) (byte) 10, axisLocation34);
        java.awt.Stroke stroke36 = categoryPlot21.getDomainGridlineStroke();
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNotNull(stroke36);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        java.awt.Color color1 = java.awt.Color.BLUE;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint) color1, stroke2);
        java.awt.Font font4 = valueMarker3.getLabelFont();
        java.awt.Color color6 = java.awt.Color.BLUE;
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint) color6, stroke7);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str11 = xYPlot10.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        xYPlot10.setDataset(0, xYDataset13);
        java.lang.Class<?> wildcardClass15 = xYPlot10.getClass();
        java.net.URL uRL16 = org.jfree.chart.util.ObjectUtilities.getResource("Multiple Pie Plot", (java.lang.Class) wildcardClass15);
        java.util.EventListener[] eventListenerArray17 = valueMarker8.getListeners((java.lang.Class) wildcardClass15);
        java.awt.Paint paint18 = valueMarker8.getLabelPaint();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType19 = valueMarker8.getLabelOffsetType();
        valueMarker3.setLabelOffsetType(lengthAdjustmentType19);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "XY Plot" + "'", str11.equals("XY Plot"));
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNull(uRL16);
        org.junit.Assert.assertNotNull(eventListenerArray17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(lengthAdjustmentType19);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = xYPlot0.getRendererForDataset(xYDataset1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        xYPlot0.setDomainAxis(valueAxis3);
        java.awt.Color color5 = java.awt.Color.BLACK;
        float[] floatArray15 = new float[] { 0L, (short) 100, 10.0f, (short) 100, 0.0f, 1L };
        float[] floatArray16 = java.awt.Color.RGBtoHSB((int) (byte) -1, (int) '#', (int) ' ', floatArray15);
        float[] floatArray17 = color5.getRGBColorComponents(floatArray15);
        xYPlot0.setDomainGridlinePaint((java.awt.Paint) color5);
        org.jfree.chart.axis.ValueAxis valueAxis20 = xYPlot0.getRangeAxisForDataset(0);
        java.lang.Object obj21 = xYPlot0.clone();
        java.awt.Paint paint22 = xYPlot0.getRangeZeroBaselinePaint();
        org.jfree.chart.plot.RingPlot ringPlot24 = new org.jfree.chart.plot.RingPlot();
        ringPlot24.setSectionDepth((double) 'a');
        java.awt.Shape shape27 = ringPlot24.getLegendItemShape();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator28 = ringPlot24.getLegendLabelGenerator();
        org.jfree.chart.plot.RingPlot ringPlot31 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font32 = ringPlot31.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle33 = new org.jfree.chart.title.TextTitle("ThreadContext", font32);
        java.awt.Color color34 = java.awt.Color.BLACK;
        textTitle33.setPaint((java.awt.Paint) color34);
        java.awt.Font font36 = textTitle33.getFont();
        org.jfree.chart.plot.RingPlot ringPlot37 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font38 = ringPlot37.getNoDataMessageFont();
        boolean boolean40 = ringPlot37.equals((java.lang.Object) (byte) 1);
        org.jfree.data.general.PieDataset pieDataset41 = ringPlot37.getDataset();
        java.awt.Color color42 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        float[] floatArray52 = new float[] { 0L, (short) 100, 10.0f, (short) 100, 0.0f, 1L };
        float[] floatArray53 = java.awt.Color.RGBtoHSB((int) (byte) -1, (int) '#', (int) ' ', floatArray52);
        float[] floatArray54 = color42.getComponents(floatArray53);
        ringPlot37.setLabelPaint((java.awt.Paint) color42);
        org.jfree.chart.text.TextFragment textFragment56 = new org.jfree.chart.text.TextFragment("Pie Plot", font36, (java.awt.Paint) color42);
        ringPlot24.setLabelBackgroundPaint((java.awt.Paint) color42);
        xYPlot0.setQuadrantPaint((int) (byte) 1, (java.awt.Paint) color42);
        java.util.List list59 = xYPlot0.getAnnotations();
        xYPlot0.clearDomainMarkers(0);
        org.junit.Assert.assertNull(xYItemRenderer2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNull(valueAxis20);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator28);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(font38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNull(pieDataset41);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(floatArray52);
        org.junit.Assert.assertNotNull(floatArray53);
        org.junit.Assert.assertNotNull(floatArray54);
        org.junit.Assert.assertNotNull(list59);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-165));
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand7 = null;
        numberAxis3D6.setMarkerBand(markerAxisBand7);
        org.jfree.data.time.DateRange dateRange9 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str10 = dateRange9.toString();
        boolean boolean13 = dateRange9.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange9, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = rectangleConstraint15.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = rectangleConstraint15.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range19 = rectangleConstraint15.getWidthRange();
        numberAxis3D6.setRangeWithMargins(range19, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) numberAxis3D6, categoryItemRenderer23);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = categoryPlot24.getDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = categoryPlot24.getDomainAxis((-1));
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str29 = xYPlot28.getPlotType();
        boolean boolean30 = xYPlot28.isRangeZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation31 = xYPlot28.getRangeAxisLocation();
        categoryPlot24.setDomainAxisLocation(axisLocation31);
        org.jfree.chart.axis.AxisSpace axisSpace33 = null;
        categoryPlot24.setFixedDomainAxisSpace(axisSpace33);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D36 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand37 = null;
        numberAxis3D36.setMarkerBand(markerAxisBand37);
        java.awt.Shape shape39 = numberAxis3D36.getRightArrow();
        numberAxis3D36.setVisible(false);
        org.jfree.data.Range range42 = categoryPlot24.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D36);
        java.awt.Graphics2D graphics2D43 = null;
        org.jfree.chart.plot.XYPlot xYPlot44 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str45 = xYPlot44.getPlotType();
        xYPlot44.mapDatasetToRangeAxis((int) (short) -1, 0);
        org.jfree.chart.block.LineBorder lineBorder49 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = lineBorder49.getInsets();
        double double52 = rectangleInsets50.calculateRightInset((double) 0.5f);
        xYPlot44.setInsets(rectangleInsets50, true);
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean57 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge56);
        org.jfree.chart.axis.AxisSpace axisSpace58 = null;
        org.jfree.chart.axis.AxisSpace axisSpace59 = numberAxis3D36.reserveSpace(graphics2D43, (org.jfree.chart.plot.Plot) xYPlot44, rectangle2D55, rectangleEdge56, axisSpace58);
        xYPlot0.setFixedDomainAxisSpace(axisSpace58);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(dateRange9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str10.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint16);
        org.junit.Assert.assertNotNull(rectangleConstraint18);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNull(categoryAxis25);
        org.junit.Assert.assertNull(categoryAxis27);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "XY Plot" + "'", str29.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNull(range42);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "XY Plot" + "'", str45.equals("XY Plot"));
        org.junit.Assert.assertNotNull(rectangleInsets50);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 1.0d + "'", double52 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleEdge56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(axisSpace59);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int1 = color0.getRGB();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo2 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo2.setName("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        boolean boolean5 = color0.equals((java.lang.Object) basicProjectInfo2);
        java.lang.String str6 = basicProjectInfo2.getName();
        basicProjectInfo2.setName("UnitType.ABSOLUTE");
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-32640) + "'", int1 == (-32640));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str6.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 0L };
        java.lang.Number[][] numberArray10 = new java.lang.Number[][] { numberArray3, numberArray5, numberArray7, numberArray9 };
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("VerticalAlignment.BOTTOM", "XY Plot", numberArray10);
        org.jfree.data.Range range12 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D14 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D18 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand19 = null;
        numberAxis3D18.setMarkerBand(markerAxisBand19);
        org.jfree.data.time.DateRange dateRange21 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str22 = dateRange21.toString();
        boolean boolean25 = dateRange21.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint27 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange21, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint28 = rectangleConstraint27.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = rectangleConstraint27.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range31 = rectangleConstraint27.getWidthRange();
        numberAxis3D18.setRangeWithMargins(range31, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, (org.jfree.chart.axis.ValueAxis) numberAxis3D18, categoryItemRenderer35);
        numberAxis3D18.setUpperMargin(0.0d);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D14, (org.jfree.chart.axis.ValueAxis) numberAxis3D18, categoryItemRenderer39);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions41 = categoryAxis3D14.getCategoryLabelPositions();
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertNotNull(dateRange21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str22.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint28);
        org.junit.Assert.assertNotNull(rectangleConstraint30);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNotNull(categoryLabelPositions41);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = categoryPlot21.getDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot21.getDomainAxis((-1));
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str26 = xYPlot25.getPlotType();
        boolean boolean27 = xYPlot25.isRangeZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation28 = xYPlot25.getRangeAxisLocation();
        categoryPlot21.setDomainAxisLocation(axisLocation28);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        categoryPlot21.setRenderer(categoryItemRenderer30);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        java.awt.geom.Point2D point2D34 = null;
        categoryPlot21.zoomDomainAxes((double) 10.0f, plotRenderingInfo33, point2D34);
        java.awt.Stroke stroke36 = categoryPlot21.getRangeCrosshairStroke();
        categoryPlot21.clearRangeMarkers((int) ' ');
        int int39 = categoryPlot21.getDomainAxisCount();
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(categoryAxis22);
        org.junit.Assert.assertNull(categoryAxis24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "XY Plot" + "'", str26.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font2 = ringPlot1.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("ThreadContext", font2);
        java.awt.Color color4 = java.awt.Color.BLACK;
        textTitle3.setPaint((java.awt.Paint) color4);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = textTitle3.getTextAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.ColumnArrangement columnArrangement10 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment6, verticalAlignment7, (double) 0.5f, (double) (-165));
        org.jfree.chart.block.BlockContainer blockContainer11 = new org.jfree.chart.block.BlockContainer();
        blockContainer11.clear();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.data.time.DateRange dateRange14 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str15 = dateRange14.toString();
        boolean boolean18 = dateRange14.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange14, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = rectangleConstraint20.toUnconstrainedWidth();
        org.jfree.data.Range range22 = rectangleConstraint20.getWidthRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint24 = rectangleConstraint20.toFixedHeight(1.0E-5d);
        org.jfree.chart.util.Size2D size2D25 = columnArrangement10.arrange(blockContainer11, graphics2D13, rectangleConstraint24);
        java.lang.Number[] numberArray29 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray35 = new java.lang.Number[] { 0L };
        java.lang.Number[][] numberArray36 = new java.lang.Number[][] { numberArray29, numberArray31, numberArray33, numberArray35 };
        org.jfree.data.category.CategoryDataset categoryDataset37 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("VerticalAlignment.BOTTOM", "XY Plot", numberArray36);
        org.jfree.data.Range range39 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset37, false);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset37, (double) ' ');
        org.jfree.data.Range range43 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset37, true);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint44 = rectangleConstraint24.toRangeHeight(range43);
        java.lang.String str45 = range43.toString();
        double double46 = range43.getCentralValue();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertNotNull(verticalAlignment7);
        org.junit.Assert.assertNotNull(dateRange14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str15.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint21);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(rectangleConstraint24);
        org.junit.Assert.assertNotNull(size2D25);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(numberArray36);
        org.junit.Assert.assertNotNull(categoryDataset37);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertNotNull(rectangleConstraint44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "Range[0.0,0.0]" + "'", str45.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        multiplePiePlot1.setLimit((double) 2.0f);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.RendererState rendererState1 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = xYPlot0.getRendererForDataset(xYDataset1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        xYPlot0.setRenderer((int) ' ', xYItemRenderer4, false);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot7.getRendererForDataset(xYDataset8);
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        xYPlot7.setDomainAxis(valueAxis10);
        java.awt.Color color12 = java.awt.Color.BLACK;
        float[] floatArray22 = new float[] { 0L, (short) 100, 10.0f, (short) 100, 0.0f, 1L };
        float[] floatArray23 = java.awt.Color.RGBtoHSB((int) (byte) -1, (int) '#', (int) ' ', floatArray22);
        float[] floatArray24 = color12.getRGBColorComponents(floatArray22);
        xYPlot7.setDomainGridlinePaint((java.awt.Paint) color12);
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        xYPlot7.setOutlinePaint((java.awt.Paint) color26);
        org.jfree.chart.plot.PiePlot piePlot28 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier29 = piePlot28.getDrawingSupplier();
        xYPlot7.setDrawingSupplier(drawingSupplier29);
        java.awt.Paint paint31 = xYPlot7.getNoDataMessagePaint();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent32 = null;
        xYPlot7.datasetChanged(datasetChangeEvent32);
        java.awt.Color color34 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int35 = color34.getRGB();
        xYPlot7.setRangeCrosshairPaint((java.awt.Paint) color34);
        xYPlot0.setDomainCrosshairPaint((java.awt.Paint) color34);
        org.junit.Assert.assertNull(xYItemRenderer2);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(drawingSupplier29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-32640) + "'", int35 == (-32640));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis3D1.setMarkerBand(markerAxisBand2);
        java.awt.Shape shape4 = numberAxis3D1.getRightArrow();
        org.jfree.data.Range range5 = numberAxis3D1.getRange();
        org.jfree.data.Range range7 = org.jfree.data.Range.expandToInclude(range5, 100.0d);
        double double8 = range5.getUpperBound();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier1 = piePlot0.getDrawingSupplier();
        org.jfree.chart.plot.Plot plot2 = piePlot0.getParent();
        java.awt.Color color4 = java.awt.Color.BLUE;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint) color4, stroke5);
        piePlot0.setLabelShadowPaint((java.awt.Paint) color4);
        org.junit.Assert.assertNotNull(drawingSupplier1);
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font2 = ringPlot1.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("ThreadContext", font2);
        java.awt.Color color4 = java.awt.Color.BLACK;
        textTitle3.setPaint((java.awt.Paint) color4);
        java.awt.Font font6 = textTitle3.getFont();
        textTitle3.setWidth(0.0d);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = textTitle3.getHorizontalAlignment();
        java.lang.String str10 = textTitle3.getToolTipText();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent11 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle3);
        double double12 = textTitle3.getWidth();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = categoryPlot21.getDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot21.getDomainAxis((-1));
        org.jfree.chart.util.Layer layer26 = null;
        java.util.Collection collection27 = categoryPlot21.getRangeMarkers((int) ' ', layer26);
        java.awt.Color color28 = java.awt.Color.BLACK;
        categoryPlot21.setRangeGridlinePaint((java.awt.Paint) color28);
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        categoryPlot21.setDomainAxis(0, categoryAxis31);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = categoryPlot21.getDomainAxisEdge();
        java.lang.String str34 = rectangleEdge33.toString();
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(categoryAxis22);
        org.junit.Assert.assertNull(categoryAxis24);
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "RectangleEdge.BOTTOM" + "'", str34.equals("RectangleEdge.BOTTOM"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int2 = color1.getRGB();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo3 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo3.setName("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        boolean boolean6 = color1.equals((java.lang.Object) basicProjectInfo3);
        polarPlot0.setAngleGridlinePaint((java.awt.Paint) color1);
        polarPlot0.addCornerTextItem("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=-1.0]");
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-32640) + "'", int2 == (-32640));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxis((int) '#');
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str4 = xYPlot3.getPlotType();
        org.jfree.chart.axis.ValueAxis valueAxis5 = xYPlot3.getRangeAxis();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot7 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset6);
        java.lang.String str8 = multiplePiePlot7.getPlotType();
        java.lang.String str9 = multiplePiePlot7.getPlotType();
        boolean boolean10 = xYPlot3.equals((java.lang.Object) str9);
        java.awt.Stroke stroke11 = xYPlot3.getDomainCrosshairStroke();
        xYPlot0.setRangeZeroBaselineStroke(stroke11);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "XY Plot" + "'", str4.equals("XY Plot"));
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Multiple Pie Plot" + "'", str8.equals("Multiple Pie Plot"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Multiple Pie Plot" + "'", str9.equals("Multiple Pie Plot"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setLabelGap(0.0d);
        piePlot0.setCircular(true);
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        ringPlot5.setSectionDepth((double) 'a');
        java.awt.Shape shape8 = ringPlot5.getLegendItemShape();
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape8);
        piePlot0.setLegendItemShape(shape8);
        java.awt.Paint paint11 = piePlot0.getLabelShadowPaint();
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = xYPlot0.getRendererForDataset(xYDataset1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        xYPlot0.setDomainAxis(valueAxis3);
        java.awt.Color color5 = java.awt.Color.BLACK;
        float[] floatArray15 = new float[] { 0L, (short) 100, 10.0f, (short) 100, 0.0f, 1L };
        float[] floatArray16 = java.awt.Color.RGBtoHSB((int) (byte) -1, (int) '#', (int) ' ', floatArray15);
        float[] floatArray17 = color5.getRGBColorComponents(floatArray15);
        xYPlot0.setDomainGridlinePaint((java.awt.Paint) color5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        xYPlot0.zoomDomainAxes(0.0d, plotRenderingInfo20, point2D21);
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D26 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand27 = null;
        numberAxis3D26.setMarkerBand(markerAxisBand27);
        org.jfree.data.time.DateRange dateRange29 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str30 = dateRange29.toString();
        boolean boolean33 = dateRange29.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint35 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange29, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint36 = rectangleConstraint35.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint38 = rectangleConstraint35.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range39 = rectangleConstraint35.getWidthRange();
        numberAxis3D26.setRangeWithMargins(range39, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer43 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, (org.jfree.chart.axis.ValueAxis) numberAxis3D26, categoryItemRenderer43);
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = categoryPlot44.getDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = categoryPlot44.getDomainAxis((-1));
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str49 = xYPlot48.getPlotType();
        boolean boolean50 = xYPlot48.isRangeZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation51 = xYPlot48.getRangeAxisLocation();
        categoryPlot44.setDomainAxisLocation(axisLocation51);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D54 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand55 = null;
        numberAxis3D54.setMarkerBand(markerAxisBand55);
        numberAxis3D54.zoomRange(0.0d, (double) (short) 1);
        org.jfree.data.time.DateRange dateRange60 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str61 = dateRange60.toString();
        boolean boolean64 = dateRange60.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint66 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange60, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint67 = rectangleConstraint66.toUnconstrainedWidth();
        org.jfree.data.Range range68 = rectangleConstraint66.getWidthRange();
        numberAxis3D54.setDefaultAutoRange(range68);
        numberAxis3D54.resizeRange((double) 0, 0.0d);
        categoryPlot44.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D54);
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D54);
        org.junit.Assert.assertNull(xYItemRenderer2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(dateRange29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str30.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint36);
        org.junit.Assert.assertNotNull(rectangleConstraint38);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertNull(categoryAxis45);
        org.junit.Assert.assertNull(categoryAxis47);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "XY Plot" + "'", str49.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(axisLocation51);
        org.junit.Assert.assertNotNull(dateRange60);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str61.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint67);
        org.junit.Assert.assertNotNull(range68);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.NONE;
        java.awt.Color color2 = java.awt.Color.BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint) color2, stroke3);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str7 = xYPlot6.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        xYPlot6.setDataset(0, xYDataset9);
        java.lang.Class<?> wildcardClass11 = xYPlot6.getClass();
        java.net.URL uRL12 = org.jfree.chart.util.ObjectUtilities.getResource("Multiple Pie Plot", (java.lang.Class) wildcardClass11);
        java.util.EventListener[] eventListenerArray13 = valueMarker4.getListeners((java.lang.Class) wildcardClass11);
        org.jfree.chart.plot.RingPlot ringPlot14 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.Plot plot15 = ringPlot14.getRootPlot();
        valueMarker4.addChangeListener((org.jfree.chart.event.MarkerChangeListener) ringPlot14);
        boolean boolean17 = lengthConstraintType0.equals((java.lang.Object) ringPlot14);
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.plot.PiePlot piePlot20 = new org.jfree.chart.plot.PiePlot();
        piePlot20.setLabelGap(0.0d);
        piePlot20.setCircular(true);
        java.awt.Shape shape25 = piePlot20.getLegendItemShape();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        org.jfree.chart.plot.PiePlotState piePlotState28 = ringPlot14.initialise(graphics2D18, rectangle2D19, piePlot20, (java.lang.Integer) 100, plotRenderingInfo27);
        piePlotState28.setPieWRadius((double) (-165));
        double double31 = piePlotState28.getPieCenterY();
        org.junit.Assert.assertNotNull(lengthConstraintType0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "XY Plot" + "'", str7.equals("XY Plot"));
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNull(uRL12);
        org.junit.Assert.assertNotNull(eventListenerArray13);
        org.junit.Assert.assertNotNull(plot15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(piePlotState28);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        double double2 = piePlot1.getShadowXOffset();
        java.awt.Font font3 = piePlot1.getLabelFont();
        java.awt.Color color4 = java.awt.Color.cyan;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", font3, (java.awt.Paint) color4);
        java.util.List list6 = textBlock5.getLines();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        try {
            textBlock5.draw(graphics2D7, 0.0f, (float) (short) 1, textBlockAnchor10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font1 = ringPlot0.getNoDataMessageFont();
        boolean boolean3 = ringPlot0.equals((java.lang.Object) (byte) 1);
        org.jfree.data.general.PieDataset pieDataset4 = ringPlot0.getDataset();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator5 = null;
        ringPlot0.setToolTipGenerator(pieToolTipGenerator5);
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0);
        org.jfree.chart.text.TextFragment textFragment9 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Font font10 = textFragment9.getFont();
        legendTitle7.setItemFont(font10);
        java.awt.Color color12 = java.awt.Color.pink;
        legendTitle7.setItemPaint((java.awt.Paint) color12);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(pieDataset4);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(color12);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace2 = null;
        xYPlot1.setFixedRangeAxisSpace(axisSpace2, false);
        java.awt.Paint paint5 = xYPlot1.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) xYPlot1);
        float float7 = xYPlot1.getBackgroundAlpha();
        int int8 = xYPlot1.getSeriesCount();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        xYPlot1.setRenderer(xYItemRenderer9);
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace13 = null;
        xYPlot12.setFixedRangeAxisSpace(axisSpace13, false);
        java.awt.Paint paint16 = xYPlot12.getOutlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation18 = xYPlot12.getRangeAxisLocation((-16777216));
        xYPlot1.setRangeAxisLocation(0, axisLocation18, false);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(axisLocation18);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 0L };
        java.lang.Number[][] numberArray10 = new java.lang.Number[][] { numberArray3, numberArray5, numberArray7, numberArray9 };
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("VerticalAlignment.BOTTOM", "XY Plot", numberArray10);
        org.jfree.data.Range range12 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset11);
        boolean boolean15 = range12.intersects(1.0E-8d, 0.025d);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = xYPlot0.getRendererForDataset(xYDataset1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        xYPlot0.setDomainAxis(valueAxis3);
        java.awt.Color color5 = java.awt.Color.BLACK;
        float[] floatArray15 = new float[] { 0L, (short) 100, 10.0f, (short) 100, 0.0f, 1L };
        float[] floatArray16 = java.awt.Color.RGBtoHSB((int) (byte) -1, (int) '#', (int) ' ', floatArray15);
        float[] floatArray17 = color5.getRGBColorComponents(floatArray15);
        xYPlot0.setDomainGridlinePaint((java.awt.Paint) color5);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        xYPlot0.setOutlinePaint((java.awt.Paint) color19);
        java.awt.Stroke stroke21 = xYPlot0.getDomainCrosshairStroke();
        org.junit.Assert.assertNull(xYItemRenderer2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke21);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        double double2 = piePlot1.getShadowXOffset();
        java.awt.Font font3 = piePlot1.getLabelFont();
        java.awt.Color color4 = java.awt.Color.cyan;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", font3, (java.awt.Paint) color4);
        org.jfree.chart.text.TextLine textLine6 = textBlock5.getLastLine();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNotNull(textLine6);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str4 = xYPlot3.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        xYPlot3.setDataset(0, xYDataset6);
        java.lang.Class<?> wildcardClass8 = xYPlot3.getClass();
        java.net.URL uRL9 = org.jfree.chart.util.ObjectUtilities.getResource("Multiple Pie Plot", (java.lang.Class) wildcardClass8);
        java.io.InputStream inputStream10 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass8);
        java.io.InputStream inputStream11 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("TextAnchor.BOTTOM_RIGHT", (java.lang.Class) wildcardClass8);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "XY Plot" + "'", str4.equals("XY Plot"));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(uRL9);
        org.junit.Assert.assertNotNull(inputStream10);
        org.junit.Assert.assertNull(inputStream11);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = lineBorder0.getInsets();
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources2 = new org.jfree.chart.resources.JFreeChartResources();
        boolean boolean3 = lineBorder0.equals((java.lang.Object) jFreeChartResources2);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font5 = ringPlot4.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("ThreadContext", font5);
        java.awt.Color color7 = java.awt.Color.BLACK;
        textTitle6.setPaint((java.awt.Paint) color7);
        java.awt.Font font9 = textTitle6.getFont();
        org.jfree.chart.plot.RingPlot ringPlot10 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font11 = ringPlot10.getNoDataMessageFont();
        boolean boolean13 = ringPlot10.equals((java.lang.Object) (byte) 1);
        org.jfree.data.general.PieDataset pieDataset14 = ringPlot10.getDataset();
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        float[] floatArray25 = new float[] { 0L, (short) 100, 10.0f, (short) 100, 0.0f, 1L };
        float[] floatArray26 = java.awt.Color.RGBtoHSB((int) (byte) -1, (int) '#', (int) ' ', floatArray25);
        float[] floatArray27 = color15.getComponents(floatArray26);
        ringPlot10.setLabelPaint((java.awt.Paint) color15);
        org.jfree.chart.text.TextFragment textFragment29 = new org.jfree.chart.text.TextFragment("Pie Plot", font9, (java.awt.Paint) color15);
        java.awt.Graphics2D graphics2D31 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer32 = new org.jfree.chart.text.G2TextMeasurer(graphics2D31);
        try {
            org.jfree.chart.text.TextBlock textBlock33 = org.jfree.chart.text.TextUtilities.createTextBlock("UnitType.ABSOLUTE", font1, (java.awt.Paint) color15, (float) '#', (org.jfree.chart.text.TextMeasurer) g2TextMeasurer32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(pieDataset14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(floatArray27);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        polarPlot0.setAngleTickUnit((org.jfree.chart.axis.TickUnit) dateTickUnit1);
        java.awt.Font font3 = polarPlot0.getAngleLabelFont();
        polarPlot0.setAngleGridlinesVisible(false);
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        float float22 = numberAxis3D3.getTickMarkInsideLength();
        java.text.NumberFormat numberFormat23 = numberAxis3D3.getNumberFormatOverride();
        org.jfree.data.time.DateRange dateRange24 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str25 = dateRange24.toString();
        boolean boolean28 = dateRange24.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange24, (double) (byte) -1);
        numberAxis3D3.setRange((org.jfree.data.Range) dateRange24);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D33 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand34 = null;
        numberAxis3D33.setMarkerBand(markerAxisBand34);
        org.jfree.data.time.DateRange dateRange36 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str37 = dateRange36.toString();
        boolean boolean40 = dateRange36.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint42 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange36, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint43 = rectangleConstraint42.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint45 = rectangleConstraint42.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range46 = rectangleConstraint42.getWidthRange();
        numberAxis3D33.setRangeWithMargins(range46, true, true);
        numberAxis3D3.setRange(range46, false, true);
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.0f + "'", float22 == 0.0f);
        org.junit.Assert.assertNull(numberFormat23);
        org.junit.Assert.assertNotNull(dateRange24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str25.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(dateRange36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str37.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint43);
        org.junit.Assert.assertNotNull(rectangleConstraint45);
        org.junit.Assert.assertNotNull(range46);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font3 = ringPlot2.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("ThreadContext", font3);
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        piePlot5.setLabelGap(0.0d);
        piePlot5.setCircular(true);
        java.awt.Shape shape10 = piePlot5.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("ThreadContext", font3, (org.jfree.chart.plot.Plot) piePlot5, false);
        float float13 = jFreeChart12.getBackgroundImageAlpha();
        org.jfree.chart.title.LegendTitle legendTitle15 = jFreeChart12.getLegend((int) ' ');
        int int16 = jFreeChart12.getBackgroundImageAlignment();
        org.jfree.chart.title.LegendTitle legendTitle18 = jFreeChart12.getLegend((-165));
        jFreeChart12.setTextAntiAlias(false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo23 = null;
        try {
            jFreeChart12.handleClick((int) (byte) 0, (int) (byte) -1, chartRenderingInfo23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.5f + "'", float13 == 0.5f);
        org.junit.Assert.assertNull(legendTitle15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 15 + "'", int16 == 15);
        org.junit.Assert.assertNull(legendTitle18);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("TextBlockAnchor.BOTTOM_CENTER", graphics2D1, (float) 2, (float) (byte) 1, (double) (byte) 100, (float) 10, (float) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement0.clear();
        columnArrangement0.clear();
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setLabelGap(0.0d);
        java.awt.Paint paint3 = piePlot0.getBaseSectionOutlinePaint();
        java.awt.Font font4 = piePlot0.getLabelFont();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        java.awt.Color color2 = java.awt.Color.getColor("TextBlockAnchor.BOTTOM_CENTER", (int) (byte) 1);
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot();
        piePlot3.setLabelGap(0.0d);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        piePlot3.setBackgroundPaint((java.awt.Paint) color6);
        double double8 = piePlot3.getMinimumArcAngleToDraw();
        java.awt.Paint paint9 = piePlot3.getNoDataMessagePaint();
        boolean boolean10 = color2.equals((java.lang.Object) paint9);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0E-5d + "'", double8 == 1.0E-5d);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.NONE;
        java.awt.Color color2 = java.awt.Color.BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint) color2, stroke3);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str7 = xYPlot6.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        xYPlot6.setDataset(0, xYDataset9);
        java.lang.Class<?> wildcardClass11 = xYPlot6.getClass();
        java.net.URL uRL12 = org.jfree.chart.util.ObjectUtilities.getResource("Multiple Pie Plot", (java.lang.Class) wildcardClass11);
        java.util.EventListener[] eventListenerArray13 = valueMarker4.getListeners((java.lang.Class) wildcardClass11);
        org.jfree.chart.plot.RingPlot ringPlot14 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.Plot plot15 = ringPlot14.getRootPlot();
        valueMarker4.addChangeListener((org.jfree.chart.event.MarkerChangeListener) ringPlot14);
        boolean boolean17 = lengthConstraintType0.equals((java.lang.Object) ringPlot14);
        ringPlot14.setSeparatorsVisible(true);
        org.junit.Assert.assertNotNull(lengthConstraintType0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "XY Plot" + "'", str7.equals("XY Plot"));
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNull(uRL12);
        org.junit.Assert.assertNotNull(eventListenerArray13);
        org.junit.Assert.assertNotNull(plot15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        categoryPlot21.setDomainAxis(categoryAxis22);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent24 = null;
        categoryPlot21.datasetChanged(datasetChangeEvent24);
        org.jfree.chart.util.Layer layer27 = null;
        java.util.Collection collection28 = categoryPlot21.getDomainMarkers((int) 'a', layer27);
        org.jfree.chart.util.Layer layer29 = null;
        java.util.Collection collection30 = categoryPlot21.getRangeMarkers(layer29);
        boolean boolean31 = categoryPlot21.isDomainZoomable();
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(collection28);
        org.junit.Assert.assertNull(collection30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke1 = ringPlot0.getLabelLinkStroke();
        double double2 = ringPlot0.getShadowXOffset();
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = xYPlot3.getRendererForDataset(xYDataset4);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        xYPlot3.setDomainAxis(valueAxis6);
        java.awt.Color color8 = java.awt.Color.BLACK;
        float[] floatArray18 = new float[] { 0L, (short) 100, 10.0f, (short) 100, 0.0f, 1L };
        float[] floatArray19 = java.awt.Color.RGBtoHSB((int) (byte) -1, (int) '#', (int) ' ', floatArray18);
        float[] floatArray20 = color8.getRGBColorComponents(floatArray18);
        xYPlot3.setDomainGridlinePaint((java.awt.Paint) color8);
        ringPlot0.setShadowPaint((java.awt.Paint) color8);
        ringPlot0.setInnerSeparatorExtension(0.4d);
        boolean boolean25 = ringPlot0.getIgnoreNullValues();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        java.awt.Color color1 = java.awt.Color.LIGHT_GRAY;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = xYPlot2.getRendererForDataset(xYDataset3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        xYPlot2.setDomainAxis(valueAxis5);
        java.awt.Color color7 = java.awt.Color.BLACK;
        float[] floatArray17 = new float[] { 0L, (short) 100, 10.0f, (short) 100, 0.0f, 1L };
        float[] floatArray18 = java.awt.Color.RGBtoHSB((int) (byte) -1, (int) '#', (int) ' ', floatArray17);
        float[] floatArray19 = color7.getRGBColorComponents(floatArray17);
        xYPlot2.setDomainGridlinePaint((java.awt.Paint) color7);
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        xYPlot2.setOutlinePaint((java.awt.Paint) color21);
        java.awt.Color color25 = java.awt.Color.BLUE;
        java.awt.Stroke stroke26 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint) color25, stroke26);
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str30 = xYPlot29.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        xYPlot29.setDataset(0, xYDataset32);
        java.lang.Class<?> wildcardClass34 = xYPlot29.getClass();
        java.net.URL uRL35 = org.jfree.chart.util.ObjectUtilities.getResource("Multiple Pie Plot", (java.lang.Class) wildcardClass34);
        java.util.EventListener[] eventListenerArray36 = valueMarker27.getListeners((java.lang.Class) wildcardClass34);
        org.jfree.chart.util.Layer layer37 = null;
        xYPlot2.addRangeMarker((int) ' ', (org.jfree.chart.plot.Marker) valueMarker27, layer37);
        org.jfree.chart.plot.RingPlot ringPlot41 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font42 = ringPlot41.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle43 = new org.jfree.chart.title.TextTitle("ThreadContext", font42);
        org.jfree.chart.plot.PiePlot piePlot44 = new org.jfree.chart.plot.PiePlot();
        piePlot44.setLabelGap(0.0d);
        piePlot44.setCircular(true);
        java.awt.Shape shape49 = piePlot44.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart51 = new org.jfree.chart.JFreeChart("ThreadContext", font42, (org.jfree.chart.plot.Plot) piePlot44, false);
        jFreeChart51.clearSubtitles();
        java.awt.Stroke stroke53 = jFreeChart51.getBorderStroke();
        valueMarker27.setOutlineStroke(stroke53);
        java.awt.Paint paint55 = null;
        org.jfree.data.category.CategoryDataset categoryDataset56 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D59 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand60 = null;
        numberAxis3D59.setMarkerBand(markerAxisBand60);
        org.jfree.data.time.DateRange dateRange62 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str63 = dateRange62.toString();
        boolean boolean66 = dateRange62.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint68 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange62, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint69 = rectangleConstraint68.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint71 = rectangleConstraint68.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range72 = rectangleConstraint68.getWidthRange();
        numberAxis3D59.setRangeWithMargins(range72, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer76 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot77 = new org.jfree.chart.plot.CategoryPlot(categoryDataset56, categoryAxis57, (org.jfree.chart.axis.ValueAxis) numberAxis3D59, categoryItemRenderer76);
        org.jfree.chart.axis.CategoryAxis categoryAxis78 = categoryPlot77.getDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis80 = categoryPlot77.getDomainAxis((-1));
        org.jfree.chart.plot.XYPlot xYPlot81 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str82 = xYPlot81.getPlotType();
        boolean boolean83 = xYPlot81.isRangeZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation84 = xYPlot81.getRangeAxisLocation();
        categoryPlot77.setDomainAxisLocation(axisLocation84);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer86 = null;
        categoryPlot77.setRenderer(categoryItemRenderer86);
        categoryPlot77.setRangeCrosshairLockedOnData(true);
        java.awt.Color color91 = java.awt.Color.BLUE;
        java.awt.Stroke stroke92 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker93 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint) color91, stroke92);
        categoryPlot77.setOutlineStroke(stroke92);
        try {
            org.jfree.chart.plot.ValueMarker valueMarker96 = new org.jfree.chart.plot.ValueMarker((double) (byte) -1, (java.awt.Paint) color1, stroke53, paint55, stroke92, (float) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(xYItemRenderer4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "XY Plot" + "'", str30.equals("XY Plot"));
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNull(uRL35);
        org.junit.Assert.assertNotNull(eventListenerArray36);
        org.junit.Assert.assertNotNull(font42);
        org.junit.Assert.assertNotNull(shape49);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(dateRange62);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str63.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint69);
        org.junit.Assert.assertNotNull(rectangleConstraint71);
        org.junit.Assert.assertNotNull(range72);
        org.junit.Assert.assertNull(categoryAxis78);
        org.junit.Assert.assertNull(categoryAxis80);
        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "XY Plot" + "'", str82.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
        org.junit.Assert.assertNotNull(axisLocation84);
        org.junit.Assert.assertNotNull(color91);
        org.junit.Assert.assertNotNull(stroke92);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = categoryPlot21.getDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot21.getDomainAxis((-1));
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str26 = xYPlot25.getPlotType();
        boolean boolean27 = xYPlot25.isRangeZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation28 = xYPlot25.getRangeAxisLocation();
        categoryPlot21.setDomainAxisLocation(axisLocation28);
        org.jfree.chart.axis.AxisSpace axisSpace30 = null;
        categoryPlot21.setFixedDomainAxisSpace(axisSpace30);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D33 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand34 = null;
        numberAxis3D33.setMarkerBand(markerAxisBand34);
        java.awt.Shape shape36 = numberAxis3D33.getRightArrow();
        numberAxis3D33.setVisible(false);
        org.jfree.data.Range range39 = categoryPlot21.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D33);
        numberAxis3D33.setRange((double) 0L, (double) 10L);
        org.jfree.data.RangeType rangeType43 = numberAxis3D33.getRangeType();
        java.awt.Shape shape44 = numberAxis3D33.getLeftArrow();
        numberAxis3D33.setLabelAngle(1.0E-5d);
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(categoryAxis22);
        org.junit.Assert.assertNull(categoryAxis24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "XY Plot" + "'", str26.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNull(range39);
        org.junit.Assert.assertNotNull(rangeType43);
        org.junit.Assert.assertNotNull(shape44);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font2 = ringPlot1.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("ThreadContext", font2);
        java.awt.Color color4 = java.awt.Color.BLACK;
        textTitle3.setPaint((java.awt.Paint) color4);
        java.awt.Font font6 = textTitle3.getFont();
        java.awt.Paint paint7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        textTitle3.setBackgroundPaint(paint7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        textTitle3.setMargin(rectangleInsets9);
        double double11 = rectangleInsets9.getLeft();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = categoryPlot21.getDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot21.getDomainAxis((-1));
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str26 = xYPlot25.getPlotType();
        boolean boolean27 = xYPlot25.isRangeZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation28 = xYPlot25.getRangeAxisLocation();
        categoryPlot21.setDomainAxisLocation(axisLocation28);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        categoryPlot21.setRenderer(categoryItemRenderer30);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        java.awt.geom.Point2D point2D34 = null;
        categoryPlot21.zoomDomainAxes((double) 10.0f, plotRenderingInfo33, point2D34);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = null;
        java.awt.geom.Point2D point2D38 = null;
        categoryPlot21.zoomDomainAxes((double) 0.0f, plotRenderingInfo37, point2D38);
        categoryPlot21.setDomainGridlinesVisible(true);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation42 = null;
        try {
            boolean boolean43 = categoryPlot21.removeAnnotation(categoryAnnotation42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(categoryAxis22);
        org.junit.Assert.assertNull(categoryAxis24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "XY Plot" + "'", str26.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(axisLocation28);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        double double2 = piePlot1.getShadowXOffset();
        java.awt.Font font3 = piePlot1.getLabelFont();
        java.awt.Color color4 = java.awt.Color.cyan;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", font3, (java.awt.Paint) color4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        boolean boolean14 = textBlock5.equals((java.lang.Object) rectangleConstraint12);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor18 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        try {
            java.awt.Shape shape22 = textBlock5.calculateBounds(graphics2D15, (float) 15, (float) (short) -1, textBlockAnchor18, 0.0f, (float) 1L, (double) 500);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor18);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0");
        categoryAxis3D1.setUpperMargin((double) '#');
        categoryAxis3D1.setCategoryLabelPositionOffset(255);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font1 = ringPlot0.getNoDataMessageFont();
        boolean boolean3 = ringPlot0.equals((java.lang.Object) (byte) 1);
        org.jfree.data.general.PieDataset pieDataset4 = ringPlot0.getDataset();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator5 = null;
        ringPlot0.setToolTipGenerator(pieToolTipGenerator5);
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0);
        org.jfree.chart.block.BlockContainer blockContainer8 = legendTitle7.getItemContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = legendTitle7.getLegendItemGraphicPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        legendTitle7.setItemLabelPadding(rectangleInsets10);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(pieDataset4);
        org.junit.Assert.assertNotNull(blockContainer8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
        blockContainer1.clear();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str5 = dateRange4.toString();
        boolean boolean8 = dateRange4.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = rectangleConstraint10.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint10.toFixedWidth((double) 0.0f);
        org.jfree.chart.util.Size2D size2D14 = flowArrangement0.arrange(blockContainer1, graphics2D3, rectangleConstraint10);
        java.awt.geom.Rectangle2D rectangle2D15 = blockContainer1.getBounds();
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str5.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint11);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(size2D14);
        org.junit.Assert.assertNotNull(rectangle2D15);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = categoryPlot21.getDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot21.getDomainAxis((-1));
        org.jfree.chart.util.Layer layer26 = null;
        java.util.Collection collection27 = categoryPlot21.getRangeMarkers((int) ' ', layer26);
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D31 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand32 = null;
        numberAxis3D31.setMarkerBand(markerAxisBand32);
        org.jfree.data.time.DateRange dateRange34 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str35 = dateRange34.toString();
        boolean boolean38 = dateRange34.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint40 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange34, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint41 = rectangleConstraint40.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint43 = rectangleConstraint40.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range44 = rectangleConstraint40.getWidthRange();
        numberAxis3D31.setRangeWithMargins(range44, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer48 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, (org.jfree.chart.axis.ValueAxis) numberAxis3D31, categoryItemRenderer48);
        org.jfree.data.Range range50 = categoryPlot21.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D31);
        double double51 = categoryPlot21.getRangeCrosshairValue();
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(categoryAxis22);
        org.junit.Assert.assertNull(categoryAxis24);
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertNotNull(dateRange34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str35.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint41);
        org.junit.Assert.assertNotNull(rectangleConstraint43);
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertNull(range50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace1, false);
        java.awt.Paint paint4 = xYPlot0.getOutlinePaint();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint6 = defaultDrawingSupplier5.getNextFillPaint();
        java.awt.Stroke stroke7 = defaultDrawingSupplier5.getNextOutlineStroke();
        xYPlot0.setDomainCrosshairStroke(stroke7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = xYPlot9.getRendererForDataset(xYDataset10);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.util.List list14 = null;
        xYPlot9.drawDomainTickBands(graphics2D12, rectangle2D13, list14);
        xYPlot9.zoom(0.0d);
        java.awt.Color color19 = java.awt.Color.BLUE;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint) color19, stroke20);
        java.awt.Font font22 = valueMarker21.getLabelFont();
        xYPlot9.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker21);
        java.awt.Font font24 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        valueMarker21.setLabelFont(font24);
        try {
            boolean boolean26 = xYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(xYItemRenderer11);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(font24);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font1 = ringPlot0.getNoDataMessageFont();
        boolean boolean3 = ringPlot0.equals((java.lang.Object) (byte) 1);
        ringPlot0.setMinimumArcAngleToDraw((double) (byte) 10);
        boolean boolean6 = ringPlot0.getLabelLinksVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = ringPlot0.getLegendItems();
        ringPlot0.setSectionDepth(87.0d);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(legendItemCollection7);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = xYPlot0.getRendererForDataset(xYDataset1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        xYPlot0.setDomainAxis(valueAxis3);
        java.awt.Color color5 = java.awt.Color.BLACK;
        float[] floatArray15 = new float[] { 0L, (short) 100, 10.0f, (short) 100, 0.0f, 1L };
        float[] floatArray16 = java.awt.Color.RGBtoHSB((int) (byte) -1, (int) '#', (int) ' ', floatArray15);
        float[] floatArray17 = color5.getRGBColorComponents(floatArray15);
        xYPlot0.setDomainGridlinePaint((java.awt.Paint) color5);
        org.jfree.chart.axis.ValueAxis valueAxis20 = xYPlot0.getRangeAxisForDataset(0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        xYPlot0.zoomRangeAxes(10.0d, (double) '4', plotRenderingInfo23, point2D24);
        java.awt.Stroke stroke26 = null;
        try {
            xYPlot0.setDomainGridlineStroke(stroke26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNull(valueAxis20);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font2 = ringPlot1.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("ThreadContext", font2);
        java.awt.Color color4 = java.awt.Color.BLACK;
        textTitle3.setPaint((java.awt.Paint) color4);
        java.awt.Font font6 = textTitle3.getFont();
        textTitle3.setWidth(0.0d);
        textTitle3.setURLText("TextBlockAnchor.BOTTOM_CENTER");
        org.jfree.chart.util.VerticalAlignment verticalAlignment11 = textTitle3.getVerticalAlignment();
        java.lang.String str12 = verticalAlignment11.toString();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(verticalAlignment11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "VerticalAlignment.CENTER" + "'", str12.equals("VerticalAlignment.CENTER"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("RectangleEdge.BOTTOM", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = xYPlot0.getRendererForDataset(xYDataset1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        xYPlot0.setDomainAxis(valueAxis3);
        java.awt.Paint paint5 = xYPlot0.getRangeCrosshairPaint();
        java.lang.String str6 = xYPlot0.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset8 = xYPlot0.getDataset((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis10 = xYPlot0.getDomainAxis((int) (byte) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = xYPlot0.getDomainAxisEdge();
        java.lang.String str12 = xYPlot0.getPlotType();
        org.junit.Assert.assertNull(xYItemRenderer2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "XY Plot" + "'", str6.equals("XY Plot"));
        org.junit.Assert.assertNull(xYDataset8);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "XY Plot" + "'", str12.equals("XY Plot"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        piePlot1.setLabelGap(0.0d);
        piePlot1.setCircular(true);
        java.awt.Paint paint6 = piePlot1.getLabelShadowPaint();
        boolean boolean7 = basicProjectInfo0.equals((java.lang.Object) piePlot1);
        piePlot1.setCircular(true);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator10 = piePlot1.getToolTipGenerator();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator11 = null;
        piePlot1.setLegendLabelURLGenerator(pieURLGenerator11);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent13 = null;
        piePlot1.markerChanged(markerChangeEvent13);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(pieToolTipGenerator10);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.lang.String str2 = multiplePiePlot1.getPlotType();
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font5 = ringPlot4.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("ThreadContext", font5);
        java.awt.Color color7 = java.awt.Color.BLACK;
        textTitle6.setPaint((java.awt.Paint) color7);
        multiplePiePlot1.setAggregatedItemsPaint((java.awt.Paint) color7);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = multiplePiePlot1.getLegendItems();
        multiplePiePlot1.setLimit(0.0d);
        org.jfree.chart.JFreeChart jFreeChart13 = multiplePiePlot1.getPieChart();
        java.awt.Paint paint14 = jFreeChart13.getBackgroundPaint();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Multiple Pie Plot" + "'", str2.equals("Multiple Pie Plot"));
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(jFreeChart13);
        org.junit.Assert.assertNull(paint14);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        java.awt.Color color1 = java.awt.Color.BLUE;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint) color1, stroke2);
        int int4 = color1.getGreen();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = xYPlot0.getRendererForDataset(xYDataset1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        xYPlot0.setDomainAxis(valueAxis3);
        java.awt.Paint paint5 = xYPlot0.getRangeCrosshairPaint();
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str8 = xYPlot7.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        xYPlot7.setDataset(0, xYDataset10);
        java.lang.Class<?> wildcardClass12 = xYPlot7.getClass();
        org.jfree.chart.plot.RingPlot ringPlot15 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font16 = ringPlot15.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle("ThreadContext", font16);
        org.jfree.chart.plot.PiePlot piePlot18 = new org.jfree.chart.plot.PiePlot();
        piePlot18.setLabelGap(0.0d);
        piePlot18.setCircular(true);
        java.awt.Shape shape23 = piePlot18.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart25 = new org.jfree.chart.JFreeChart("ThreadContext", font16, (org.jfree.chart.plot.Plot) piePlot18, false);
        jFreeChart25.clearSubtitles();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType27 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYPlot7, jFreeChart25, chartChangeEventType27);
        org.jfree.chart.axis.AxisLocation axisLocation30 = xYPlot7.getDomainAxisLocation((int) (short) 1);
        xYPlot0.setRangeAxisLocation((int) (byte) 10, axisLocation30, false);
        java.awt.Paint paint33 = xYPlot0.getRangeZeroBaselinePaint();
        org.junit.Assert.assertNull(xYItemRenderer2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "XY Plot" + "'", str8.equals("XY Plot"));
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertNotNull(paint33);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.NONE;
        java.awt.Color color2 = java.awt.Color.BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint) color2, stroke3);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str7 = xYPlot6.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        xYPlot6.setDataset(0, xYDataset9);
        java.lang.Class<?> wildcardClass11 = xYPlot6.getClass();
        java.net.URL uRL12 = org.jfree.chart.util.ObjectUtilities.getResource("Multiple Pie Plot", (java.lang.Class) wildcardClass11);
        java.util.EventListener[] eventListenerArray13 = valueMarker4.getListeners((java.lang.Class) wildcardClass11);
        org.jfree.chart.plot.RingPlot ringPlot14 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.Plot plot15 = ringPlot14.getRootPlot();
        valueMarker4.addChangeListener((org.jfree.chart.event.MarkerChangeListener) ringPlot14);
        boolean boolean17 = lengthConstraintType0.equals((java.lang.Object) ringPlot14);
        double double18 = ringPlot14.getInnerSeparatorExtension();
        org.junit.Assert.assertNotNull(lengthConstraintType0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "XY Plot" + "'", str7.equals("XY Plot"));
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNull(uRL12);
        org.junit.Assert.assertNotNull(eventListenerArray13);
        org.junit.Assert.assertNotNull(plot15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.2d + "'", double18 == 0.2d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("TextBlockAnchor.BOTTOM_CENTER");
        numberAxis3D1.resizeRange(4.0d, 0.4d);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = numberAxis3D1.getTickLabelInsets();
        org.junit.Assert.assertNotNull(rectangleInsets5);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis3D1.setMarkerBand(markerAxisBand2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = numberAxis3D1.getTickLabelInsets();
        boolean boolean5 = numberAxis3D1.isVisible();
        numberAxis3D1.setTickMarkInsideLength((float) (short) -1);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setLabelGap(0.0d);
        piePlot0.setCircular(true);
        java.awt.Shape shape5 = piePlot0.getLegendItemShape();
        org.jfree.chart.entity.ChartEntity chartEntity8 = new org.jfree.chart.entity.ChartEntity(shape5, "hi!", "Multiple Pie Plot");
        java.lang.String str9 = chartEntity8.getToolTipText();
        java.lang.Object obj10 = chartEntity8.clone();
        java.lang.String str11 = chartEntity8.getToolTipText();
        java.lang.String str12 = chartEntity8.getShapeType();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "poly" + "'", str12.equals("poly"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.addCornerTextItem("TextBlockAnchor.TOP_LEFT");
        java.awt.Paint paint3 = polarPlot0.getRadiusGridlinePaint();
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        polarPlot0.setAngleGridlinePaint((java.awt.Paint) color4);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType6 = org.jfree.chart.block.LengthConstraintType.NONE;
        java.awt.Color color8 = java.awt.Color.BLUE;
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint) color8, stroke9);
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str13 = xYPlot12.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        xYPlot12.setDataset(0, xYDataset15);
        java.lang.Class<?> wildcardClass17 = xYPlot12.getClass();
        java.net.URL uRL18 = org.jfree.chart.util.ObjectUtilities.getResource("Multiple Pie Plot", (java.lang.Class) wildcardClass17);
        java.util.EventListener[] eventListenerArray19 = valueMarker10.getListeners((java.lang.Class) wildcardClass17);
        org.jfree.chart.plot.RingPlot ringPlot20 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.Plot plot21 = ringPlot20.getRootPlot();
        valueMarker10.addChangeListener((org.jfree.chart.event.MarkerChangeListener) ringPlot20);
        boolean boolean23 = lengthConstraintType6.equals((java.lang.Object) ringPlot20);
        java.awt.Graphics2D graphics2D24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.plot.PiePlot piePlot26 = new org.jfree.chart.plot.PiePlot();
        piePlot26.setLabelGap(0.0d);
        piePlot26.setCircular(true);
        java.awt.Shape shape31 = piePlot26.getLegendItemShape();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        org.jfree.chart.plot.PiePlotState piePlotState34 = ringPlot20.initialise(graphics2D24, rectangle2D25, piePlot26, (java.lang.Integer) 100, plotRenderingInfo33);
        boolean boolean35 = polarPlot0.equals((java.lang.Object) rectangle2D25);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(lengthConstraintType6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "XY Plot" + "'", str13.equals("XY Plot"));
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNull(uRL18);
        org.junit.Assert.assertNotNull(eventListenerArray19);
        org.junit.Assert.assertNotNull(plot21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(piePlotState34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke1 = ringPlot0.getLabelLinkStroke();
        double double2 = ringPlot0.getOuterSeparatorExtension();
        java.awt.Stroke stroke3 = ringPlot0.getBaseSectionOutlineStroke();
        double double4 = ringPlot0.getLabelGap();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        ringPlot0.setSectionPaint((java.lang.Comparable) 10, (java.awt.Paint) color6);
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 10, jFreeChart8);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.025d + "'", double4 == 0.025d);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis3D1.setMarkerBand(markerAxisBand2);
        numberAxis3D1.zoomRange(0.0d, (double) (short) 1);
        org.jfree.data.time.DateRange dateRange7 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str8 = dateRange7.toString();
        boolean boolean11 = dateRange7.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange7, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = rectangleConstraint13.toUnconstrainedWidth();
        org.jfree.data.Range range15 = rectangleConstraint13.getWidthRange();
        numberAxis3D1.setDefaultAutoRange(range15);
        numberAxis3D1.resizeRange((double) (byte) 100, (double) 15);
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D23 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand24 = null;
        numberAxis3D23.setMarkerBand(markerAxisBand24);
        org.jfree.data.time.DateRange dateRange26 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str27 = dateRange26.toString();
        boolean boolean30 = dateRange26.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint32 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange26, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint33 = rectangleConstraint32.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint35 = rectangleConstraint32.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range36 = rectangleConstraint32.getWidthRange();
        numberAxis3D23.setRangeWithMargins(range36, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, (org.jfree.chart.axis.ValueAxis) numberAxis3D23, categoryItemRenderer40);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = categoryPlot41.getDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = categoryPlot41.getDomainAxis((-1));
        org.jfree.chart.plot.XYPlot xYPlot45 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str46 = xYPlot45.getPlotType();
        boolean boolean47 = xYPlot45.isRangeZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation48 = xYPlot45.getRangeAxisLocation();
        categoryPlot41.setDomainAxisLocation(axisLocation48);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer50 = null;
        categoryPlot41.setRenderer(categoryItemRenderer50);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo53 = null;
        java.awt.geom.Point2D point2D54 = null;
        categoryPlot41.zoomDomainAxes((double) 10.0f, plotRenderingInfo53, point2D54);
        java.awt.Stroke stroke56 = categoryPlot41.getRangeCrosshairStroke();
        numberAxis3D1.setAxisLineStroke(stroke56);
        org.junit.Assert.assertNotNull(dateRange7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str8.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint14);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNotNull(dateRange26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str27.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint33);
        org.junit.Assert.assertNotNull(rectangleConstraint35);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertNull(categoryAxis42);
        org.junit.Assert.assertNull(categoryAxis44);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "XY Plot" + "'", str46.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(axisLocation48);
        org.junit.Assert.assertNotNull(stroke56);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) textBlockAnchor0, jFreeChart1, (int) (byte) 10, (int) (byte) 100);
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font8 = ringPlot7.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("ThreadContext", font8);
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot();
        piePlot10.setLabelGap(0.0d);
        piePlot10.setCircular(true);
        java.awt.Shape shape15 = piePlot10.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("ThreadContext", font8, (org.jfree.chart.plot.Plot) piePlot10, false);
        float float18 = jFreeChart17.getBackgroundImageAlpha();
        chartProgressEvent4.setChart(jFreeChart17);
        java.util.List list20 = jFreeChart17.getSubtitles();
        java.awt.Image image21 = jFreeChart17.getBackgroundImage();
        org.jfree.chart.event.ChartProgressListener chartProgressListener22 = null;
        jFreeChart17.addProgressListener(chartProgressListener22);
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.5f + "'", float18 == 0.5f);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertNull(image21);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font1 = ringPlot0.getNoDataMessageFont();
        boolean boolean3 = ringPlot0.equals((java.lang.Object) (byte) 1);
        org.jfree.data.general.PieDataset pieDataset4 = ringPlot0.getDataset();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator5 = null;
        ringPlot0.setToolTipGenerator(pieToolTipGenerator5);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator7 = ringPlot0.getLegendLabelURLGenerator();
        org.jfree.chart.plot.RingPlot ringPlot9 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font10 = ringPlot9.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("ThreadContext", font10);
        java.awt.Color color12 = java.awt.Color.BLACK;
        textTitle11.setPaint((java.awt.Paint) color12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets();
        double double15 = rectangleInsets14.getBottom();
        double double17 = rectangleInsets14.trimWidth((double) 1.0f);
        textTitle11.setPadding(rectangleInsets14);
        ringPlot0.setLabelPadding(rectangleInsets14);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(pieDataset4);
        org.junit.Assert.assertNull(pieURLGenerator7);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-1.0d) + "'", double17 == (-1.0d));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font3 = ringPlot2.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("ThreadContext", font3);
        java.awt.Color color5 = java.awt.Color.red;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.util.RectangleEdge.TOP;
        boolean boolean7 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge6);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment8 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment9 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.LineBorder lineBorder10 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = lineBorder10.getInsets();
        double double13 = rectangleInsets11.calculateRightInset((double) 0.5f);
        double double15 = rectangleInsets11.calculateRightOutset((double) (-165));
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("", font3, (java.awt.Paint) color5, rectangleEdge6, horizontalAlignment8, verticalAlignment9, rectangleInsets11);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(horizontalAlignment8);
        org.junit.Assert.assertNotNull(verticalAlignment9);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str1 = xYPlot0.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        xYPlot0.setDataset(0, xYDataset3);
        java.lang.Class<?> wildcardClass5 = xYPlot0.getClass();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        xYPlot0.setRenderer(xYItemRenderer6);
        boolean boolean8 = xYPlot0.isDomainCrosshairLockedOnData();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "XY Plot" + "'", str1.equals("XY Plot"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setLabelGap(0.0d);
        piePlot0.setCircular(true);
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        ringPlot5.setSectionDepth((double) 'a');
        java.awt.Shape shape8 = ringPlot5.getLegendItemShape();
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape8);
        piePlot0.setLegendItemShape(shape8);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape8, "Multiple Pie Plot", "RectangleAnchor.TOP");
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 0L };
        java.lang.Number[][] numberArray10 = new java.lang.Number[][] { numberArray3, numberArray5, numberArray7, numberArray9 };
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("VerticalAlignment.BOTTOM", "XY Plot", numberArray10);
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset11, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D16 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand17 = null;
        numberAxis3D16.setMarkerBand(markerAxisBand17);
        numberAxis3D16.zoomRange(0.0d, (double) (short) 1);
        org.jfree.data.time.DateRange dateRange22 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str23 = dateRange22.toString();
        boolean boolean26 = dateRange22.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint28 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange22, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint29 = rectangleConstraint28.toUnconstrainedWidth();
        org.jfree.data.Range range30 = rectangleConstraint28.getWidthRange();
        numberAxis3D16.setDefaultAutoRange(range30);
        numberAxis3D16.resizeRange((double) 0, 0.0d);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis14, (org.jfree.chart.axis.ValueAxis) numberAxis3D16, categoryItemRenderer35);
        java.text.NumberFormat numberFormat37 = numberAxis3D16.getNumberFormatOverride();
        numberAxis3D16.setAutoRangeIncludesZero(false);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNotNull(dateRange22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str23.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint29);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNull(numberFormat37);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        numberAxis3D1.setVerticalTickLabels(false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("HorizontalAlignment.CENTER");
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 0L };
        java.lang.Number[][] numberArray10 = new java.lang.Number[][] { numberArray3, numberArray5, numberArray7, numberArray9 };
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("VerticalAlignment.BOTTOM", "XY Plot", numberArray10);
        org.jfree.data.Range range12 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset11);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint(range12, 100.0d);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
        org.junit.Assert.assertNotNull(range12);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str1 = xYPlot0.getPlotType();
        boolean boolean2 = xYPlot0.isRangeZoomable();
        xYPlot0.clearRangeAxes();
        java.awt.Paint paint4 = xYPlot0.getRangeTickBandPaint();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "XY Plot" + "'", str1.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(paint4);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int2 = color1.getRGB();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo3 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo3.setName("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        boolean boolean6 = color1.equals((java.lang.Object) basicProjectInfo3);
        polarPlot0.setAngleGridlinePaint((java.awt.Paint) color1);
        java.awt.Stroke stroke8 = polarPlot0.getRadiusGridlineStroke();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-32640) + "'", int2 == (-32640));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font2 = ringPlot1.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("ThreadContext", font2);
        java.awt.Color color4 = java.awt.Color.BLACK;
        textTitle3.setPaint((java.awt.Paint) color4);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = textTitle3.getTextAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.ColumnArrangement columnArrangement10 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment6, verticalAlignment7, (double) 0.5f, (double) (-165));
        org.jfree.chart.block.BlockContainer blockContainer11 = new org.jfree.chart.block.BlockContainer();
        blockContainer11.clear();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.data.time.DateRange dateRange14 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str15 = dateRange14.toString();
        boolean boolean18 = dateRange14.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange14, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = rectangleConstraint20.toUnconstrainedWidth();
        org.jfree.data.Range range22 = rectangleConstraint20.getWidthRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint24 = rectangleConstraint20.toFixedHeight(1.0E-5d);
        org.jfree.chart.util.Size2D size2D25 = columnArrangement10.arrange(blockContainer11, graphics2D13, rectangleConstraint24);
        java.lang.Number[] numberArray29 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray35 = new java.lang.Number[] { 0L };
        java.lang.Number[][] numberArray36 = new java.lang.Number[][] { numberArray29, numberArray31, numberArray33, numberArray35 };
        org.jfree.data.category.CategoryDataset categoryDataset37 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("VerticalAlignment.BOTTOM", "XY Plot", numberArray36);
        org.jfree.data.Range range39 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset37, false);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset37, (double) ' ');
        org.jfree.data.Range range43 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset37, true);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint44 = rectangleConstraint24.toRangeHeight(range43);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType45 = rectangleConstraint24.getWidthConstraintType();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType46 = rectangleConstraint24.getWidthConstraintType();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertNotNull(verticalAlignment7);
        org.junit.Assert.assertNotNull(dateRange14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str15.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint21);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(rectangleConstraint24);
        org.junit.Assert.assertNotNull(size2D25);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(numberArray36);
        org.junit.Assert.assertNotNull(categoryDataset37);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertNotNull(rectangleConstraint44);
        org.junit.Assert.assertNotNull(lengthConstraintType45);
        org.junit.Assert.assertNotNull(lengthConstraintType46);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        ringPlot1.setSectionDepth((double) 0L);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        java.awt.Color color1 = java.awt.Color.BLUE;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint) color1, stroke2);
        int int4 = color1.getBlue();
        int int5 = color1.getBlue();
        java.awt.color.ColorSpace colorSpace6 = null;
        float[] floatArray19 = new float[] { 0L, (short) 100, 10.0f, (short) 100, 0.0f, 1L };
        float[] floatArray20 = java.awt.Color.RGBtoHSB((int) (byte) -1, (int) '#', (int) ' ', floatArray19);
        float[] floatArray21 = java.awt.Color.RGBtoHSB((int) (short) 0, 0, (int) (short) 100, floatArray19);
        try {
            float[] floatArray22 = color1.getComponents(colorSpace6, floatArray19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 255 + "'", int4 == 255);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 255 + "'", int5 == 255);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = xYPlot0.getRendererForDataset(xYDataset1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        xYPlot0.setDomainAxis(valueAxis3);
        java.awt.Paint paint5 = xYPlot0.getRangeCrosshairPaint();
        java.awt.Paint paint6 = xYPlot0.getDomainCrosshairPaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes((double) 100L, plotRenderingInfo8, point2D9);
        org.junit.Assert.assertNull(xYItemRenderer2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font2 = ringPlot1.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("ThreadContext", font2);
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = xYPlot4.getRendererForDataset(xYDataset5);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        xYPlot4.setDomainAxis(valueAxis7);
        java.awt.Color color9 = java.awt.Color.BLACK;
        float[] floatArray19 = new float[] { 0L, (short) 100, 10.0f, (short) 100, 0.0f, 1L };
        float[] floatArray20 = java.awt.Color.RGBtoHSB((int) (byte) -1, (int) '#', (int) ' ', floatArray19);
        float[] floatArray21 = color9.getRGBColorComponents(floatArray19);
        xYPlot4.setDomainGridlinePaint((java.awt.Paint) color9);
        textTitle3.setPaint((java.awt.Paint) color9);
        boolean boolean24 = textTitle3.getNotify();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNull(xYItemRenderer6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        categoryPlot21.setDomainAxis(categoryAxis22);
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace26 = null;
        xYPlot25.setFixedRangeAxisSpace(axisSpace26, false);
        java.awt.Paint paint29 = xYPlot25.getOutlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation31 = xYPlot25.getRangeAxisLocation((-16777216));
        categoryPlot21.setRangeAxisLocation((int) (short) 100, axisLocation31);
        org.jfree.chart.util.SortOrder sortOrder33 = categoryPlot21.getRowRenderingOrder();
        categoryPlot21.setRangeCrosshairValue(0.0d, false);
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNotNull(sortOrder33);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = categoryPlot21.getDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot21.getDomainAxis((-1));
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str26 = xYPlot25.getPlotType();
        boolean boolean27 = xYPlot25.isRangeZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation28 = xYPlot25.getRangeAxisLocation();
        categoryPlot21.setDomainAxisLocation(axisLocation28);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        categoryPlot21.setRenderer(categoryItemRenderer30);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        java.awt.geom.Point2D point2D34 = null;
        categoryPlot21.zoomDomainAxes((double) 10.0f, plotRenderingInfo33, point2D34);
        boolean boolean36 = categoryPlot21.isRangeGridlinesVisible();
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(categoryAxis22);
        org.junit.Assert.assertNull(categoryAxis24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "XY Plot" + "'", str26.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        java.util.Locale locale1 = null;
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str4 = xYPlot3.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        xYPlot3.setDataset(0, xYDataset6);
        java.lang.Class<?> wildcardClass8 = xYPlot3.getClass();
        java.awt.Paint[] paintArray10 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.lang.Class<?> wildcardClass11 = paintArray10.getClass();
        java.net.URL uRL12 = org.jfree.chart.util.ObjectUtilities.getResource("ChartChangeEventType.DATASET_UPDATED", (java.lang.Class) wildcardClass11);
        java.lang.Object obj13 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Multiple Pie Plot", (java.lang.Class) wildcardClass8, (java.lang.Class) wildcardClass11);
        java.lang.ClassLoader classLoader14 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass8);
        try {
            java.util.ResourceBundle resourceBundle15 = java.util.ResourceBundle.getBundle("UnitType.ABSOLUTE", locale1, classLoader14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "XY Plot" + "'", str4.equals("XY Plot"));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(paintArray10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNull(uRL12);
        org.junit.Assert.assertNull(obj13);
        org.junit.Assert.assertNotNull(classLoader14);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace1, false);
        java.awt.Paint paint4 = xYPlot0.getOutlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation6 = xYPlot0.getRangeAxisLocation((-16777216));
        int int7 = xYPlot0.getDatasetCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str12 = xYPlot11.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        xYPlot11.setDataset(0, xYDataset14);
        java.lang.Class<?> wildcardClass16 = xYPlot11.getClass();
        org.jfree.chart.plot.RingPlot ringPlot19 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font20 = ringPlot19.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle("ThreadContext", font20);
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot();
        piePlot22.setLabelGap(0.0d);
        piePlot22.setCircular(true);
        java.awt.Shape shape27 = piePlot22.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart29 = new org.jfree.chart.JFreeChart("ThreadContext", font20, (org.jfree.chart.plot.Plot) piePlot22, false);
        jFreeChart29.clearSubtitles();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType31 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent32 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYPlot11, jFreeChart29, chartChangeEventType31);
        org.jfree.chart.axis.AxisLocation axisLocation34 = xYPlot11.getDomainAxisLocation((int) (short) 1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = null;
        java.lang.Number[] numberArray41 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray43 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray45 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray47 = new java.lang.Number[] { 0L };
        java.lang.Number[][] numberArray48 = new java.lang.Number[][] { numberArray41, numberArray43, numberArray45, numberArray47 };
        org.jfree.data.category.CategoryDataset categoryDataset49 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("VerticalAlignment.BOTTOM", "XY Plot", numberArray48);
        org.jfree.data.Range range50 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset49);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D52 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset53 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis54 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D56 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand57 = null;
        numberAxis3D56.setMarkerBand(markerAxisBand57);
        org.jfree.data.time.DateRange dateRange59 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str60 = dateRange59.toString();
        boolean boolean63 = dateRange59.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint65 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange59, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint66 = rectangleConstraint65.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint68 = rectangleConstraint65.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range69 = rectangleConstraint65.getWidthRange();
        numberAxis3D56.setRangeWithMargins(range69, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer73 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot74 = new org.jfree.chart.plot.CategoryPlot(categoryDataset53, categoryAxis54, (org.jfree.chart.axis.ValueAxis) numberAxis3D56, categoryItemRenderer73);
        numberAxis3D56.setUpperMargin(0.0d);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer77 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot78 = new org.jfree.chart.plot.CategoryPlot(categoryDataset49, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D52, (org.jfree.chart.axis.ValueAxis) numberAxis3D56, categoryItemRenderer77);
        java.awt.Graphics2D graphics2D79 = null;
        org.jfree.chart.axis.AxisState axisState80 = null;
        org.jfree.chart.util.Size2D size2D81 = new org.jfree.chart.util.Size2D();
        size2D81.height = 10L;
        size2D81.setHeight(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor88 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D89 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D81, 0.05d, (double) 1, rectangleAnchor88);
        org.jfree.chart.util.RectangleEdge rectangleEdge90 = null;
        java.util.List list91 = categoryAxis3D52.refreshTicks(graphics2D79, axisState80, rectangle2D89, rectangleEdge90);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor92 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.geom.Point2D point2D93 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D89, rectangleAnchor92);
        xYPlot11.zoomRangeAxes((double) ' ', (double) 100.0f, plotRenderingInfo37, point2D93);
        xYPlot0.zoomRangeAxes((double) '4', 0.0d, plotRenderingInfo10, point2D93);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "XY Plot" + "'", str12.equals("XY Plot"));
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertNotNull(numberArray41);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(numberArray47);
        org.junit.Assert.assertNotNull(numberArray48);
        org.junit.Assert.assertNotNull(categoryDataset49);
        org.junit.Assert.assertNull(range50);
        org.junit.Assert.assertNotNull(dateRange59);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str60.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint66);
        org.junit.Assert.assertNotNull(rectangleConstraint68);
        org.junit.Assert.assertNotNull(range69);
        org.junit.Assert.assertNotNull(rectangleAnchor88);
        org.junit.Assert.assertNotNull(rectangle2D89);
        org.junit.Assert.assertNotNull(list91);
        org.junit.Assert.assertNotNull(rectangleAnchor92);
        org.junit.Assert.assertNotNull(point2D93);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        double double2 = piePlot1.getShadowXOffset();
        java.awt.Font font3 = piePlot1.getLabelFont();
        java.awt.Color color4 = java.awt.Color.cyan;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", font3, (java.awt.Paint) color4);
        int int6 = color4.getBlue();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 255 + "'", int6 == 255);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font1 = ringPlot0.getNoDataMessageFont();
        boolean boolean3 = ringPlot0.equals((java.lang.Object) (byte) 1);
        org.jfree.data.general.PieDataset pieDataset4 = ringPlot0.getDataset();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator5 = null;
        ringPlot0.setToolTipGenerator(pieToolTipGenerator5);
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0);
        org.jfree.chart.text.TextFragment textFragment9 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Font font10 = textFragment9.getFont();
        legendTitle7.setItemFont(font10);
        java.awt.Color color12 = java.awt.Color.blue;
        legendTitle7.setItemPaint((java.awt.Paint) color12);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.lang.Object obj15 = null;
        boolean boolean16 = rectangleAnchor14.equals(obj15);
        legendTitle7.setLegendItemGraphicLocation(rectangleAnchor14);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(pieDataset4);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font1 = ringPlot0.getNoDataMessageFont();
        boolean boolean3 = ringPlot0.equals((java.lang.Object) (byte) 1);
        ringPlot0.setMinimumArcAngleToDraw((double) (byte) 10);
        boolean boolean6 = ringPlot0.getLabelLinksVisible();
        ringPlot0.setLabelGap((double) (-1));
        double double9 = ringPlot0.getShadowXOffset();
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot();
        piePlot11.setLabelGap(0.0d);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        piePlot11.setBackgroundPaint((java.awt.Paint) color14);
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        piePlot11.setSectionPaint((java.lang.Comparable) '4', paint17);
        ringPlot0.setSectionOutlinePaint((java.lang.Comparable) "VerticalAlignment.BOTTOM", paint17);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 4.0d + "'", double9 == 4.0d);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str1 = dateRange0.toString();
        boolean boolean4 = dateRange0.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange0, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = rectangleConstraint6.toUnconstrainedWidth();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType8 = rectangleConstraint7.getHeightConstraintType();
        org.junit.Assert.assertNotNull(dateRange0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str1.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint7);
        org.junit.Assert.assertNotNull(lengthConstraintType8);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int2 = color1.getRGB();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo3 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo3.setName("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        boolean boolean6 = color1.equals((java.lang.Object) basicProjectInfo3);
        polarPlot0.setAngleGridlinePaint((java.awt.Paint) color1);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer8 = polarPlot0.getRenderer();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) (-1), (java.awt.Paint) color10, stroke11);
        polarPlot0.setAngleGridlinePaint((java.awt.Paint) color10);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D17 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand18 = null;
        numberAxis3D17.setMarkerBand(markerAxisBand18);
        org.jfree.data.time.DateRange dateRange20 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str21 = dateRange20.toString();
        boolean boolean24 = dateRange20.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange20, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint27 = rectangleConstraint26.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint29 = rectangleConstraint26.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range30 = rectangleConstraint26.getWidthRange();
        numberAxis3D17.setRangeWithMargins(range30, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, (org.jfree.chart.axis.ValueAxis) numberAxis3D17, categoryItemRenderer34);
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = categoryPlot35.getDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = categoryPlot35.getDomainAxis((-1));
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str40 = xYPlot39.getPlotType();
        boolean boolean41 = xYPlot39.isRangeZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation42 = xYPlot39.getRangeAxisLocation();
        categoryPlot35.setDomainAxisLocation(axisLocation42);
        org.jfree.chart.axis.AxisSpace axisSpace44 = null;
        categoryPlot35.setFixedDomainAxisSpace(axisSpace44);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D47 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand48 = null;
        numberAxis3D47.setMarkerBand(markerAxisBand48);
        java.awt.Shape shape50 = numberAxis3D47.getRightArrow();
        numberAxis3D47.setVisible(false);
        org.jfree.data.Range range53 = categoryPlot35.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D47);
        java.awt.Paint paint54 = categoryPlot35.getRangeGridlinePaint();
        polarPlot0.setAngleGridlinePaint(paint54);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-32640) + "'", int2 == (-32640));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(polarItemRenderer8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(dateRange20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str21.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint27);
        org.junit.Assert.assertNotNull(rectangleConstraint29);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNull(categoryAxis36);
        org.junit.Assert.assertNull(categoryAxis38);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "XY Plot" + "'", str40.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(axisLocation42);
        org.junit.Assert.assertNotNull(shape50);
        org.junit.Assert.assertNull(range53);
        org.junit.Assert.assertNotNull(paint54);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setTranslateY((double) (short) 0);
        blockParams0.setTranslateY((double) 2);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.addCornerTextItem("TextBlockAnchor.TOP_LEFT");
        java.awt.Paint paint3 = polarPlot0.getRadiusGridlinePaint();
        java.lang.Object obj4 = polarPlot0.clone();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = xYPlot0.getRendererForDataset(xYDataset1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        xYPlot0.setDomainAxis(valueAxis3);
        java.awt.Color color5 = java.awt.Color.BLACK;
        float[] floatArray15 = new float[] { 0L, (short) 100, 10.0f, (short) 100, 0.0f, 1L };
        float[] floatArray16 = java.awt.Color.RGBtoHSB((int) (byte) -1, (int) '#', (int) ' ', floatArray15);
        float[] floatArray17 = color5.getRGBColorComponents(floatArray15);
        xYPlot0.setDomainGridlinePaint((java.awt.Paint) color5);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        xYPlot0.setOutlinePaint((java.awt.Paint) color19);
        org.jfree.chart.plot.PiePlot piePlot21 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier22 = piePlot21.getDrawingSupplier();
        xYPlot0.setDrawingSupplier(drawingSupplier22);
        org.jfree.chart.LegendItemCollection legendItemCollection24 = xYPlot0.getFixedLegendItems();
        java.awt.Color color26 = java.awt.Color.BLUE;
        java.awt.Stroke stroke27 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker28 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint) color26, stroke27);
        int int29 = color26.getBlue();
        int int30 = color26.getBlue();
        boolean boolean31 = xYPlot0.equals((java.lang.Object) int30);
        org.junit.Assert.assertNull(xYItemRenderer2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(drawingSupplier22);
        org.junit.Assert.assertNull(legendItemCollection24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 255 + "'", int29 == 255);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 255 + "'", int30 == 255);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        java.awt.Font font0 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font1 = ringPlot0.getNoDataMessageFont();
        boolean boolean3 = ringPlot0.equals((java.lang.Object) (byte) 1);
        org.jfree.data.general.PieDataset pieDataset4 = ringPlot0.getDataset();
        double double5 = ringPlot0.getOuterSeparatorExtension();
        java.awt.Paint paint6 = null;
        try {
            ringPlot0.setSeparatorPaint(paint6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(pieDataset4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = categoryPlot21.getDomainAxisForDataset((-165));
        org.jfree.chart.plot.RingPlot ringPlot24 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke25 = ringPlot24.getLabelLinkStroke();
        double double26 = ringPlot24.getOuterSeparatorExtension();
        java.awt.Stroke stroke27 = ringPlot24.getBaseSectionOutlineStroke();
        categoryPlot21.setRangeGridlineStroke(stroke27);
        java.lang.String str29 = categoryPlot21.getPlotType();
        java.lang.Number[] numberArray33 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray35 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray37 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 0L };
        java.lang.Number[][] numberArray40 = new java.lang.Number[][] { numberArray33, numberArray35, numberArray37, numberArray39 };
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("VerticalAlignment.BOTTOM", "XY Plot", numberArray40);
        org.jfree.data.Range range42 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset41);
        categoryPlot21.setDataset(categoryDataset41);
        org.jfree.chart.plot.CategoryMarker categoryMarker44 = null;
        try {
            categoryPlot21.addDomainMarker(categoryMarker44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(categoryAxis23);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.2d + "'", double26 == 0.2d);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Category Plot" + "'", str29.equals("Category Plot"));
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(numberArray37);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNull(range42);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = xYPlot0.getRendererForDataset(xYDataset1);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.util.List list5 = null;
        xYPlot0.drawDomainTickBands(graphics2D3, rectangle2D4, list5);
        xYPlot0.zoom(0.0d);
        java.awt.Color color10 = java.awt.Color.BLUE;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint) color10, stroke11);
        java.awt.Font font13 = valueMarker12.getLabelFont();
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker12);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent15 = null;
        xYPlot0.rendererChanged(rendererChangeEvent15);
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder22 = new org.jfree.chart.block.BlockBorder((double) 0, 4.0d, (double) '#', (double) (short) -1, (java.awt.Paint) color21);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = blockBorder22.getInsets();
        double double24 = rectangleInsets23.getBottom();
        xYPlot0.setInsets(rectangleInsets23, false);
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D30 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand31 = null;
        numberAxis3D30.setMarkerBand(markerAxisBand31);
        org.jfree.data.time.DateRange dateRange33 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str34 = dateRange33.toString();
        boolean boolean37 = dateRange33.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint39 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange33, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint40 = rectangleConstraint39.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint42 = rectangleConstraint39.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range43 = rectangleConstraint39.getWidthRange();
        numberAxis3D30.setRangeWithMargins(range43, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer47 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot48 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, (org.jfree.chart.axis.ValueAxis) numberAxis3D30, categoryItemRenderer47);
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = categoryPlot48.getDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = categoryPlot48.getDomainAxis((-1));
        org.jfree.chart.plot.XYPlot xYPlot52 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str53 = xYPlot52.getPlotType();
        boolean boolean54 = xYPlot52.isRangeZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation55 = xYPlot52.getRangeAxisLocation();
        categoryPlot48.setDomainAxisLocation(axisLocation55);
        org.jfree.chart.axis.AxisSpace axisSpace57 = null;
        categoryPlot48.setFixedDomainAxisSpace(axisSpace57);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D60 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand61 = null;
        numberAxis3D60.setMarkerBand(markerAxisBand61);
        java.awt.Shape shape63 = numberAxis3D60.getRightArrow();
        numberAxis3D60.setVisible(false);
        org.jfree.data.Range range66 = categoryPlot48.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D60);
        java.awt.Graphics2D graphics2D67 = null;
        org.jfree.chart.plot.XYPlot xYPlot68 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str69 = xYPlot68.getPlotType();
        xYPlot68.mapDatasetToRangeAxis((int) (short) -1, 0);
        org.jfree.chart.block.LineBorder lineBorder73 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets74 = lineBorder73.getInsets();
        double double76 = rectangleInsets74.calculateRightInset((double) 0.5f);
        xYPlot68.setInsets(rectangleInsets74, true);
        java.awt.geom.Rectangle2D rectangle2D79 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge80 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean81 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge80);
        org.jfree.chart.axis.AxisSpace axisSpace82 = null;
        org.jfree.chart.axis.AxisSpace axisSpace83 = numberAxis3D60.reserveSpace(graphics2D67, (org.jfree.chart.plot.Plot) xYPlot68, rectangle2D79, rectangleEdge80, axisSpace82);
        org.jfree.chart.axis.AxisLocation axisLocation85 = xYPlot68.getRangeAxisLocation(0);
        xYPlot0.setDomainAxisLocation(axisLocation85);
        org.junit.Assert.assertNull(xYItemRenderer2);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 35.0d + "'", double24 == 35.0d);
        org.junit.Assert.assertNotNull(dateRange33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str34.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint40);
        org.junit.Assert.assertNotNull(rectangleConstraint42);
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertNull(categoryAxis49);
        org.junit.Assert.assertNull(categoryAxis51);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "XY Plot" + "'", str53.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(axisLocation55);
        org.junit.Assert.assertNotNull(shape63);
        org.junit.Assert.assertNull(range66);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "XY Plot" + "'", str69.equals("XY Plot"));
        org.junit.Assert.assertNotNull(rectangleInsets74);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 1.0d + "'", double76 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleEdge80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(axisSpace83);
        org.junit.Assert.assertNotNull(axisLocation85);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke1 = ringPlot0.getLabelLinkStroke();
        double double2 = ringPlot0.getOuterSeparatorExtension();
        java.awt.Stroke stroke3 = ringPlot0.getBaseSectionOutlineStroke();
        double double4 = ringPlot0.getLabelGap();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor5 = ringPlot0.getLabelDistributor();
        abstractPieLabelDistributor5.clear();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.025d + "'", double4 == 0.025d);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor5);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier1 = piePlot0.getDrawingSupplier();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = piePlot0.getLegendItems();
        org.junit.Assert.assertNotNull(drawingSupplier1);
        org.junit.Assert.assertNotNull(legendItemCollection2);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = xYPlot0.getRendererForDataset(xYDataset1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        xYPlot0.setDomainAxis(valueAxis3);
        java.awt.Paint paint5 = xYPlot0.getRangeCrosshairPaint();
        java.lang.String str6 = xYPlot0.getPlotType();
        org.jfree.chart.plot.RingPlot ringPlot9 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font10 = ringPlot9.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("ThreadContext", font10);
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot();
        piePlot12.setLabelGap(0.0d);
        piePlot12.setCircular(true);
        java.awt.Shape shape17 = piePlot12.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("ThreadContext", font10, (org.jfree.chart.plot.Plot) piePlot12, false);
        jFreeChart19.clearSubtitles();
        int int21 = jFreeChart19.getSubtitleCount();
        xYPlot0.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart19);
        org.jfree.chart.ui.ProjectInfo projectInfo23 = org.jfree.chart.JFreeChart.INFO;
        java.util.List list24 = projectInfo23.getContributors();
        jFreeChart19.setSubtitles(list24);
        org.junit.Assert.assertNull(xYItemRenderer2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "XY Plot" + "'", str6.equals("XY Plot"));
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(projectInfo23);
        org.junit.Assert.assertNotNull(list24);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = categoryPlot21.getDomainAxisForDataset((-165));
        org.jfree.chart.plot.RingPlot ringPlot24 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke25 = ringPlot24.getLabelLinkStroke();
        double double26 = ringPlot24.getOuterSeparatorExtension();
        java.awt.Stroke stroke27 = ringPlot24.getBaseSectionOutlineStroke();
        categoryPlot21.setRangeGridlineStroke(stroke27);
        java.lang.String str29 = categoryPlot21.getPlotType();
        org.jfree.chart.plot.PiePlot piePlot30 = new org.jfree.chart.plot.PiePlot();
        piePlot30.setLabelGap(0.0d);
        piePlot30.setCircular(true);
        double double35 = piePlot30.getShadowYOffset();
        java.awt.Color color36 = java.awt.Color.BLACK;
        piePlot30.setBaseSectionPaint((java.awt.Paint) color36);
        categoryPlot21.setDomainGridlinePaint((java.awt.Paint) color36);
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(categoryAxis23);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.2d + "'", double26 == 0.2d);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Category Plot" + "'", str29.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 4.0d + "'", double35 == 4.0d);
        org.junit.Assert.assertNotNull(color36);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray27 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0L };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray25, numberArray27, numberArray29, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("VerticalAlignment.BOTTOM", "XY Plot", numberArray32);
        org.jfree.data.Range range35 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset33, false);
        java.lang.Number number36 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset33);
        categoryPlot21.setDataset(categoryDataset33);
        categoryPlot21.mapDatasetToRangeAxis((int) (byte) 100, 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = null;
        java.awt.geom.Point2D point2D43 = null;
        categoryPlot21.zoomDomainAxes((double) '#', plotRenderingInfo42, point2D43);
        org.jfree.chart.util.SortOrder sortOrder45 = categoryPlot21.getColumnRenderingOrder();
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertTrue("'" + number36 + "' != '" + 0.0d + "'", number36.equals(0.0d));
        org.junit.Assert.assertNotNull(sortOrder45);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str4 = dateRange3.toString();
        boolean boolean7 = dateRange3.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange3, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = rectangleConstraint9.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = rectangleConstraint9.toFixedWidth((double) 0.0f);
        org.jfree.chart.util.Size2D size2D13 = columnArrangement0.arrange(blockContainer1, graphics2D2, rectangleConstraint12);
        org.jfree.chart.util.Size2D size2D14 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.Size2D size2D15 = rectangleConstraint12.calculateConstrainedSize(size2D14);
        org.junit.Assert.assertNotNull(dateRange3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str4.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint10);
        org.junit.Assert.assertNotNull(rectangleConstraint12);
        org.junit.Assert.assertNotNull(size2D13);
        org.junit.Assert.assertNotNull(size2D15);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        java.awt.Paint paint0 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier1 = piePlot0.getDrawingSupplier();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = null;
        piePlot0.setLegendLabelURLGenerator(pieURLGenerator2);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor4 = piePlot0.getLabelDistributor();
        org.junit.Assert.assertNotNull(drawingSupplier1);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor4);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        categoryPlot21.setDomainAxis(categoryAxis22);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent24 = null;
        categoryPlot21.datasetChanged(datasetChangeEvent24);
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot21.getDomainAxisLocation((int) (byte) 1);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent28 = null;
        categoryPlot21.notifyListeners(plotChangeEvent28);
        org.jfree.data.general.DatasetGroup datasetGroup30 = categoryPlot21.getDatasetGroup();
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNull(datasetGroup30);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = categoryPlot21.getDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot21.getDomainAxis((-1));
        org.jfree.chart.util.Layer layer26 = null;
        java.util.Collection collection27 = categoryPlot21.getRangeMarkers((int) ' ', layer26);
        org.jfree.chart.util.Layer layer29 = null;
        java.util.Collection collection30 = categoryPlot21.getRangeMarkers(0, layer29);
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        try {
            categoryPlot21.drawBackground(graphics2D31, rectangle2D32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(categoryAxis22);
        org.junit.Assert.assertNull(categoryAxis24);
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertNull(collection30);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = categoryPlot21.getDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot21.getDomainAxis((-1));
        org.jfree.chart.util.Layer layer26 = null;
        java.util.Collection collection27 = categoryPlot21.getRangeMarkers((int) ' ', layer26);
        org.jfree.chart.axis.AxisLocation axisLocation29 = categoryPlot21.getRangeAxisLocation(1);
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(categoryAxis22);
        org.junit.Assert.assertNull(categoryAxis24);
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertNotNull(axisLocation29);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        java.awt.Font font0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font2 = ringPlot1.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("ThreadContext", font2);
        textTitle3.setURLText("hi!");
        double double6 = textTitle3.getContentXOffset();
        double double7 = textTitle3.getContentXOffset();
        textTitle3.setToolTipText("RectangleAnchor.TOP");
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = xYPlot10.getRendererForDataset(xYDataset11);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.util.List list15 = null;
        xYPlot10.drawDomainTickBands(graphics2D13, rectangle2D14, list15);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray18 = new org.jfree.chart.axis.ValueAxis[] { valueAxis17 };
        xYPlot10.setRangeAxes(valueAxisArray18);
        boolean boolean20 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) textTitle3, (java.lang.Object) xYPlot10);
        java.awt.Stroke stroke21 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot10.setRangeGridlineStroke(stroke21);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNull(xYItemRenderer12);
        org.junit.Assert.assertNotNull(valueAxisArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(stroke21);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("HorizontalAlignment.CENTER", "RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=-1.0]");
        java.lang.String str3 = contributor2.getEmail();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=-1.0]" + "'", str3.equals("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=-1.0]"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font1 = ringPlot0.getNoDataMessageFont();
        boolean boolean3 = ringPlot0.equals((java.lang.Object) (byte) 1);
        org.jfree.data.general.PieDataset pieDataset4 = ringPlot0.getDataset();
        ringPlot0.setLabelLinkMargin(0.0d);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(pieDataset4);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        double double1 = rotation0.getFactor();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis3D5.setMarkerBand(markerAxisBand6);
        org.jfree.data.time.DateRange dateRange8 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str9 = dateRange8.toString();
        boolean boolean12 = dateRange8.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange8, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint14.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = rectangleConstraint14.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range18 = rectangleConstraint14.getWidthRange();
        numberAxis3D5.setRangeWithMargins(range18, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, categoryItemRenderer22);
        float float24 = numberAxis3D5.getTickMarkInsideLength();
        numberAxis3D5.resizeRange(0.08d);
        numberAxis3D5.setRange((double) 0, (double) 255);
        boolean boolean30 = rotation0.equals((java.lang.Object) 0);
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(dateRange8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str9.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(rectangleConstraint17);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 0.0f + "'", float24 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font3 = ringPlot2.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("ThreadContext", font3);
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        piePlot5.setLabelGap(0.0d);
        piePlot5.setCircular(true);
        java.awt.Shape shape10 = piePlot5.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("ThreadContext", font3, (org.jfree.chart.plot.Plot) piePlot5, false);
        jFreeChart12.setBorderVisible(false);
        java.awt.RenderingHints renderingHints15 = jFreeChart12.getRenderingHints();
        float float16 = jFreeChart12.getBackgroundImageAlpha();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(renderingHints15);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 0.5f + "'", float16 == 0.5f);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        categoryPlot21.setDomainAxis(categoryAxis22);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent24 = null;
        categoryPlot21.datasetChanged(datasetChangeEvent24);
        org.jfree.chart.util.Layer layer27 = null;
        java.util.Collection collection28 = categoryPlot21.getDomainMarkers((int) 'a', layer27);
        org.jfree.chart.util.Layer layer29 = null;
        java.util.Collection collection30 = categoryPlot21.getRangeMarkers(layer29);
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D35 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand36 = null;
        numberAxis3D35.setMarkerBand(markerAxisBand36);
        org.jfree.data.time.DateRange dateRange38 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str39 = dateRange38.toString();
        boolean boolean42 = dateRange38.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint44 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange38, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint45 = rectangleConstraint44.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint47 = rectangleConstraint44.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range48 = rectangleConstraint44.getWidthRange();
        numberAxis3D35.setRangeWithMargins(range48, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer52 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, (org.jfree.chart.axis.ValueAxis) numberAxis3D35, categoryItemRenderer52);
        org.jfree.chart.axis.CategoryAxis categoryAxis54 = categoryPlot53.getDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis56 = categoryPlot53.getDomainAxis((-1));
        org.jfree.chart.plot.XYPlot xYPlot57 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str58 = xYPlot57.getPlotType();
        boolean boolean59 = xYPlot57.isRangeZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation60 = xYPlot57.getRangeAxisLocation();
        categoryPlot53.setDomainAxisLocation(axisLocation60);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer62 = null;
        categoryPlot53.setRenderer(categoryItemRenderer62);
        categoryPlot53.setRangeCrosshairLockedOnData(true);
        java.awt.Color color67 = java.awt.Color.BLUE;
        java.awt.Stroke stroke68 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker69 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint) color67, stroke68);
        categoryPlot53.setOutlineStroke(stroke68);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D73 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        categoryAxis3D73.setMaximumCategoryLabelWidthRatio((float) 'a');
        categoryPlot53.setDomainAxis(0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D73, false);
        categoryPlot21.setDomainAxis(0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D73, false);
        org.jfree.chart.util.Layer layer80 = null;
        java.util.Collection collection81 = categoryPlot21.getDomainMarkers(layer80);
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(collection28);
        org.junit.Assert.assertNull(collection30);
        org.junit.Assert.assertNotNull(dateRange38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str39.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint45);
        org.junit.Assert.assertNotNull(rectangleConstraint47);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertNull(categoryAxis54);
        org.junit.Assert.assertNull(categoryAxis56);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "XY Plot" + "'", str58.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(axisLocation60);
        org.junit.Assert.assertNotNull(color67);
        org.junit.Assert.assertNotNull(stroke68);
        org.junit.Assert.assertNull(collection81);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace1, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = xYPlot0.getRangeAxisEdge();
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand9 = null;
        numberAxis3D8.setMarkerBand(markerAxisBand9);
        org.jfree.data.time.DateRange dateRange11 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str12 = dateRange11.toString();
        boolean boolean15 = dateRange11.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange11, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = rectangleConstraint17.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = rectangleConstraint17.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range21 = rectangleConstraint17.getWidthRange();
        numberAxis3D8.setRangeWithMargins(range21, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis3D8, categoryItemRenderer25);
        float float27 = numberAxis3D8.getTickMarkInsideLength();
        boolean boolean28 = numberAxis3D8.isAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D30 = new org.jfree.chart.axis.NumberAxis3D("");
        double double31 = numberAxis3D30.getLabelAngle();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D33 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand34 = null;
        numberAxis3D33.setMarkerBand(markerAxisBand34);
        numberAxis3D33.zoomRange(0.0d, (double) (short) 1);
        org.jfree.data.time.DateRange dateRange39 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str40 = dateRange39.toString();
        boolean boolean43 = dateRange39.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint45 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange39, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint46 = rectangleConstraint45.toUnconstrainedWidth();
        org.jfree.data.Range range47 = rectangleConstraint45.getWidthRange();
        numberAxis3D33.setDefaultAutoRange(range47);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray49 = new org.jfree.chart.axis.ValueAxis[] { numberAxis3D8, numberAxis3D30, numberAxis3D33 };
        xYPlot0.setRangeAxes(valueAxisArray49);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(dateRange11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str12.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint18);
        org.junit.Assert.assertNotNull(rectangleConstraint20);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 0.0f + "'", float27 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(dateRange39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str40.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint46);
        org.junit.Assert.assertNotNull(range47);
        org.junit.Assert.assertNotNull(valueAxisArray49);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 0L };
        java.lang.Number[][] numberArray10 = new java.lang.Number[][] { numberArray3, numberArray5, numberArray7, numberArray9 };
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("VerticalAlignment.BOTTOM", "XY Plot", numberArray10);
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset11, false);
        org.jfree.data.Range range15 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset11, (double) ' ');
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot();
        double double17 = piePlot16.getShadowXOffset();
        boolean boolean18 = range15.equals((java.lang.Object) double17);
        double double20 = range15.constrain((double) (-1L));
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 4.0d + "'", double17 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 32.0d + "'", double20 == 32.0d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font3 = ringPlot2.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("ThreadContext", font3);
        java.awt.Color color5 = java.awt.Color.BLACK;
        textTitle4.setPaint((java.awt.Paint) color5);
        java.awt.Font font7 = textTitle4.getFont();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.text.TextLine textLine9 = new org.jfree.chart.text.TextLine("Pie Plot", font7, (java.awt.Paint) color8);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str1 = xYPlot0.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        xYPlot0.setDataset(0, xYDataset3);
        java.lang.Class<?> wildcardClass5 = xYPlot0.getClass();
        xYPlot0.setRangeZeroBaselineVisible(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        xYPlot0.zoomRangeAxes((double) 1, (double) (-165), plotRenderingInfo10, point2D11);
        double double13 = xYPlot0.getRangeCrosshairValue();
        xYPlot0.setRangeCrosshairVisible(false);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D19 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand20 = null;
        numberAxis3D19.setMarkerBand(markerAxisBand20);
        org.jfree.data.time.DateRange dateRange22 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str23 = dateRange22.toString();
        boolean boolean26 = dateRange22.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint28 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange22, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint29 = rectangleConstraint28.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint31 = rectangleConstraint28.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range32 = rectangleConstraint28.getWidthRange();
        numberAxis3D19.setRangeWithMargins(range32, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, (org.jfree.chart.axis.ValueAxis) numberAxis3D19, categoryItemRenderer36);
        java.awt.Stroke stroke38 = categoryPlot37.getRangeCrosshairStroke();
        xYPlot0.setRangeCrosshairStroke(stroke38);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "XY Plot" + "'", str1.equals("XY Plot"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(dateRange22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str23.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint29);
        org.junit.Assert.assertNotNull(rectangleConstraint31);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertNotNull(stroke38);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str1 = xYPlot0.getPlotType();
        boolean boolean2 = xYPlot0.isDomainZeroBaselineVisible();
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font5 = ringPlot4.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("ThreadContext", font5);
        java.awt.Color color7 = java.awt.Color.BLACK;
        textTitle6.setPaint((java.awt.Paint) color7);
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color7);
        xYPlot0.configureRangeAxes();
        xYPlot0.clearRangeAxes();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        xYPlot0.setRenderer((int) '#', xYItemRenderer13, false);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "XY Plot" + "'", str1.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
        blockContainer1.clear();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str5 = dateRange4.toString();
        boolean boolean8 = dateRange4.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = rectangleConstraint10.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint10.toFixedWidth((double) 0.0f);
        org.jfree.chart.util.Size2D size2D14 = flowArrangement0.arrange(blockContainer1, graphics2D3, rectangleConstraint10);
        flowArrangement0.clear();
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str5.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint11);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(size2D14);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxis((int) '#');
        boolean boolean3 = xYPlot0.isRangeGridlinesVisible();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation4 = null;
        try {
            xYPlot0.addAnnotation(xYAnnotation4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = categoryPlot21.getDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot21.getDomainAxis((-1));
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str26 = xYPlot25.getPlotType();
        boolean boolean27 = xYPlot25.isRangeZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation28 = xYPlot25.getRangeAxisLocation();
        categoryPlot21.setDomainAxisLocation(axisLocation28);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        categoryPlot21.setRenderer(categoryItemRenderer30);
        org.jfree.chart.util.Layer layer33 = null;
        java.util.Collection collection34 = categoryPlot21.getDomainMarkers((int) (byte) 100, layer33);
        java.lang.Object obj35 = categoryPlot21.clone();
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(categoryAxis22);
        org.junit.Assert.assertNull(categoryAxis24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "XY Plot" + "'", str26.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNull(collection34);
        org.junit.Assert.assertNotNull(obj35);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = categoryPlot21.getDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot21.getDomainAxis((-1));
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str26 = xYPlot25.getPlotType();
        boolean boolean27 = xYPlot25.isRangeZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation28 = xYPlot25.getRangeAxisLocation();
        categoryPlot21.setDomainAxisLocation(axisLocation28);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        categoryPlot21.setRenderer(categoryItemRenderer30);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        java.awt.geom.Point2D point2D34 = null;
        categoryPlot21.zoomDomainAxes((double) 10.0f, plotRenderingInfo33, point2D34);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = null;
        java.awt.geom.Point2D point2D38 = null;
        categoryPlot21.zoomDomainAxes((double) 0.0f, plotRenderingInfo37, point2D38);
        categoryPlot21.setAnchorValue(0.0d);
        org.jfree.data.category.CategoryDataset categoryDataset43 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D46 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand47 = null;
        numberAxis3D46.setMarkerBand(markerAxisBand47);
        org.jfree.data.time.DateRange dateRange49 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str50 = dateRange49.toString();
        boolean boolean53 = dateRange49.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint55 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange49, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint56 = rectangleConstraint55.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint58 = rectangleConstraint55.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range59 = rectangleConstraint55.getWidthRange();
        numberAxis3D46.setRangeWithMargins(range59, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer63 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot64 = new org.jfree.chart.plot.CategoryPlot(categoryDataset43, categoryAxis44, (org.jfree.chart.axis.ValueAxis) numberAxis3D46, categoryItemRenderer63);
        java.lang.Number[] numberArray68 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray70 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray72 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray74 = new java.lang.Number[] { 0L };
        java.lang.Number[][] numberArray75 = new java.lang.Number[][] { numberArray68, numberArray70, numberArray72, numberArray74 };
        org.jfree.data.category.CategoryDataset categoryDataset76 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("VerticalAlignment.BOTTOM", "XY Plot", numberArray75);
        org.jfree.data.Range range78 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset76, false);
        java.lang.Number number79 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset76);
        categoryPlot64.setDataset(categoryDataset76);
        org.jfree.data.Range range81 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset76);
        org.jfree.chart.axis.CategoryAxis categoryAxis82 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis83 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer84 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot85 = new org.jfree.chart.plot.CategoryPlot(categoryDataset76, categoryAxis82, valueAxis83, categoryItemRenderer84);
        categoryPlot21.setDomainAxis(0, categoryAxis82, false);
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(categoryAxis22);
        org.junit.Assert.assertNull(categoryAxis24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "XY Plot" + "'", str26.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNotNull(dateRange49);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str50.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint56);
        org.junit.Assert.assertNotNull(rectangleConstraint58);
        org.junit.Assert.assertNotNull(range59);
        org.junit.Assert.assertNotNull(numberArray68);
        org.junit.Assert.assertNotNull(numberArray70);
        org.junit.Assert.assertNotNull(numberArray72);
        org.junit.Assert.assertNotNull(numberArray74);
        org.junit.Assert.assertNotNull(numberArray75);
        org.junit.Assert.assertNotNull(categoryDataset76);
        org.junit.Assert.assertNotNull(range78);
        org.junit.Assert.assertTrue("'" + number79 + "' != '" + 0.0d + "'", number79.equals(0.0d));
        org.junit.Assert.assertNull(range81);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace2 = null;
        xYPlot1.setFixedRangeAxisSpace(axisSpace2, false);
        java.awt.Paint paint5 = xYPlot1.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) xYPlot1);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int8 = color7.getRGB();
        xYPlot1.setRangeZeroBaselinePaint((java.awt.Paint) color7);
        org.jfree.chart.axis.AxisLocation axisLocation11 = xYPlot1.getRangeAxisLocation((int) '4');
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = null;
        numberAxis3D15.setMarkerBand(markerAxisBand16);
        org.jfree.data.time.DateRange dateRange18 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str19 = dateRange18.toString();
        boolean boolean22 = dateRange18.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint24 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange18, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint25 = rectangleConstraint24.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint27 = rectangleConstraint24.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range28 = rectangleConstraint24.getWidthRange();
        numberAxis3D15.setRangeWithMargins(range28, true, true);
        numberAxis3D15.setAutoRangeMinimumSize((double) 10, false);
        numberAxis3D15.setFixedAutoRange(0.0d);
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer38 = null;
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) numberAxis3D15, valueAxis37, xYItemRenderer38);
        boolean boolean40 = numberAxis3D15.isPositiveArrowVisible();
        xYPlot1.setRangeAxis((int) 'a', (org.jfree.chart.axis.ValueAxis) numberAxis3D15, false);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-32640) + "'", int8 == (-32640));
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(dateRange18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str19.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint25);
        org.junit.Assert.assertNotNull(rectangleConstraint27);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis3D1.setMarkerBand(markerAxisBand2);
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str5 = dateRange4.toString();
        boolean boolean8 = dateRange4.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = rectangleConstraint10.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint10.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range14 = rectangleConstraint10.getWidthRange();
        numberAxis3D1.setRangeWithMargins(range14, true, true);
        numberAxis3D1.setVerticalTickLabels(false);
        org.jfree.chart.util.Size2D size2D21 = new org.jfree.chart.util.Size2D();
        size2D21.height = 10L;
        size2D21.setHeight(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor28 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D29 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D21, 0.05d, (double) 1, rectangleAnchor28);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean31 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge30);
        double double32 = numberAxis3D1.valueToJava2D(0.0d, rectangle2D29, rectangleEdge30);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str5.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint11);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(rectangleAnchor28);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font1 = ringPlot0.getNoDataMessageFont();
        ringPlot0.setIgnoreNullValues(false);
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setLabelGap(0.0d);
        piePlot0.setCircular(true);
        double double5 = piePlot0.getShadowYOffset();
        java.awt.Font font6 = piePlot0.getLabelFont();
        piePlot0.setIgnoreNullValues(true);
        boolean boolean9 = piePlot0.getSectionOutlinesVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = null;
        try {
            piePlot0.setLabelPadding(rectangleInsets10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'padding' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str1 = xYPlot0.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        xYPlot0.setDataset(0, xYDataset3);
        java.lang.Class<?> wildcardClass5 = xYPlot0.getClass();
        xYPlot0.setRangeZeroBaselineVisible(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        xYPlot0.zoomRangeAxes((double) 1, (double) (-165), plotRenderingInfo10, point2D11);
        double double13 = xYPlot0.getRangeCrosshairValue();
        xYPlot0.setRangeCrosshairVisible(false);
        xYPlot0.configureDomainAxes();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "XY Plot" + "'", str1.equals("XY Plot"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis3D2.setMarkerBand(markerAxisBand3);
        org.jfree.data.time.DateRange dateRange5 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str6 = dateRange5.toString();
        boolean boolean9 = dateRange5.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange5, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = rectangleConstraint11.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = rectangleConstraint11.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range15 = rectangleConstraint11.getWidthRange();
        numberAxis3D2.setRangeWithMargins(range15, true, true);
        numberAxis3D2.setAutoRangeMinimumSize((double) 10, false);
        numberAxis3D2.setFixedAutoRange(0.0d);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, valueAxis24, xYItemRenderer25);
        boolean boolean27 = numberAxis3D2.isPositiveArrowVisible();
        numberAxis3D2.resizeRange(2.0d, 32.0d);
        org.junit.Assert.assertNotNull(dateRange5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str6.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint12);
        org.junit.Assert.assertNotNull(rectangleConstraint14);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str1 = xYPlot0.getPlotType();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand5 = null;
        numberAxis3D4.setMarkerBand(markerAxisBand5);
        org.jfree.data.time.DateRange dateRange7 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str8 = dateRange7.toString();
        boolean boolean11 = dateRange7.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange7, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = rectangleConstraint13.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = rectangleConstraint13.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range17 = rectangleConstraint13.getWidthRange();
        numberAxis3D4.setRangeWithMargins(range17, true, true);
        numberAxis3D4.setAutoRangeMinimumSize((double) 10, false);
        numberAxis3D4.setFixedAutoRange(0.0d);
        xYPlot0.setRangeAxis((int) (byte) 1, (org.jfree.chart.axis.ValueAxis) numberAxis3D4);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "XY Plot" + "'", str1.equals("XY Plot"));
        org.junit.Assert.assertNotNull(dateRange7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str8.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint14);
        org.junit.Assert.assertNotNull(rectangleConstraint16);
        org.junit.Assert.assertNotNull(range17);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font3 = ringPlot2.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("ThreadContext", font3);
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        piePlot5.setLabelGap(0.0d);
        piePlot5.setCircular(true);
        java.awt.Shape shape10 = piePlot5.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("ThreadContext", font3, (org.jfree.chart.plot.Plot) piePlot5, false);
        jFreeChart12.clearSubtitles();
        int int14 = jFreeChart12.getSubtitleCount();
        int int15 = jFreeChart12.getSubtitleCount();
        org.jfree.chart.event.ChartChangeListener chartChangeListener16 = null;
        try {
            jFreeChart12.addChangeListener(chartChangeListener16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.Plot plot1 = ringPlot0.getRootPlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor2 = ringPlot0.getLabelDistributor();
        java.awt.Paint paint3 = ringPlot0.getBaseSectionOutlinePaint();
        org.junit.Assert.assertNotNull(plot1);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.lang.String str2 = multiplePiePlot1.getPlotType();
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font5 = ringPlot4.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("ThreadContext", font5);
        java.awt.Color color7 = java.awt.Color.BLACK;
        textTitle6.setPaint((java.awt.Paint) color7);
        multiplePiePlot1.setAggregatedItemsPaint((java.awt.Paint) color7);
        double double10 = multiplePiePlot1.getLimit();
        java.lang.String str11 = multiplePiePlot1.getPlotType();
        multiplePiePlot1.setAggregatedItemsKey((java.lang.Comparable) 1.0E-5d);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Multiple Pie Plot" + "'", str2.equals("Multiple Pie Plot"));
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Multiple Pie Plot" + "'", str11.equals("Multiple Pie Plot"));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke2 = ringPlot1.getLabelLinkStroke();
        double double3 = ringPlot1.getOuterSeparatorExtension();
        java.awt.Stroke stroke4 = ringPlot1.getBaseSectionOutlineStroke();
        double double5 = ringPlot1.getLabelGap();
        int int6 = objectList0.indexOf((java.lang.Object) ringPlot1);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str8 = xYPlot7.getPlotType();
        boolean boolean9 = xYPlot7.isRangeZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation10 = xYPlot7.getRangeAxisLocation();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        xYPlot7.setRangeCrosshairPaint((java.awt.Paint) color11);
        int int13 = objectList0.indexOf((java.lang.Object) xYPlot7);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.025d + "'", double5 == 0.025d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "XY Plot" + "'", str8.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = null;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        categoryPlot21.setDomainAxis(categoryAxis22);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent24 = null;
        categoryPlot21.datasetChanged(datasetChangeEvent24);
        org.jfree.chart.util.Layer layer27 = null;
        java.util.Collection collection28 = categoryPlot21.getDomainMarkers((int) 'a', layer27);
        org.jfree.chart.util.Layer layer29 = null;
        java.util.Collection collection30 = categoryPlot21.getRangeMarkers(layer29);
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D35 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand36 = null;
        numberAxis3D35.setMarkerBand(markerAxisBand36);
        org.jfree.data.time.DateRange dateRange38 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str39 = dateRange38.toString();
        boolean boolean42 = dateRange38.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint44 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange38, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint45 = rectangleConstraint44.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint47 = rectangleConstraint44.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range48 = rectangleConstraint44.getWidthRange();
        numberAxis3D35.setRangeWithMargins(range48, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer52 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, (org.jfree.chart.axis.ValueAxis) numberAxis3D35, categoryItemRenderer52);
        org.jfree.chart.axis.CategoryAxis categoryAxis54 = categoryPlot53.getDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis56 = categoryPlot53.getDomainAxis((-1));
        org.jfree.chart.plot.XYPlot xYPlot57 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str58 = xYPlot57.getPlotType();
        boolean boolean59 = xYPlot57.isRangeZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation60 = xYPlot57.getRangeAxisLocation();
        categoryPlot53.setDomainAxisLocation(axisLocation60);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer62 = null;
        categoryPlot53.setRenderer(categoryItemRenderer62);
        categoryPlot53.setRangeCrosshairLockedOnData(true);
        java.awt.Color color67 = java.awt.Color.BLUE;
        java.awt.Stroke stroke68 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker69 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint) color67, stroke68);
        categoryPlot53.setOutlineStroke(stroke68);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D73 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        categoryAxis3D73.setMaximumCategoryLabelWidthRatio((float) 'a');
        categoryPlot53.setDomainAxis(0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D73, false);
        categoryPlot21.setDomainAxis(0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D73, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo82 = null;
        try {
            categoryPlot21.handleClick((-1), (int) (byte) 0, plotRenderingInfo82);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(collection28);
        org.junit.Assert.assertNull(collection30);
        org.junit.Assert.assertNotNull(dateRange38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str39.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint45);
        org.junit.Assert.assertNotNull(rectangleConstraint47);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertNull(categoryAxis54);
        org.junit.Assert.assertNull(categoryAxis56);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "XY Plot" + "'", str58.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(axisLocation60);
        org.junit.Assert.assertNotNull(color67);
        org.junit.Assert.assertNotNull(stroke68);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font3 = ringPlot2.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("ThreadContext", font3);
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        piePlot5.setLabelGap(0.0d);
        piePlot5.setCircular(true);
        java.awt.Shape shape10 = piePlot5.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("ThreadContext", font3, (org.jfree.chart.plot.Plot) piePlot5, false);
        jFreeChart12.setBorderVisible(true);
        try {
            org.jfree.chart.plot.CategoryPlot categoryPlot15 = jFreeChart12.getCategoryPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PiePlot cannot be cast to org.jfree.chart.plot.CategoryPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = categoryPlot21.getDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot21.getDomainAxis((-1));
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str26 = xYPlot25.getPlotType();
        boolean boolean27 = xYPlot25.isRangeZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation28 = xYPlot25.getRangeAxisLocation();
        categoryPlot21.setDomainAxisLocation(axisLocation28);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        categoryPlot21.setRenderer(categoryItemRenderer30);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        java.awt.geom.Point2D point2D34 = null;
        categoryPlot21.zoomDomainAxes((double) 10.0f, plotRenderingInfo33, point2D34);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = null;
        java.awt.geom.Point2D point2D38 = null;
        categoryPlot21.zoomDomainAxes((double) 0.0f, plotRenderingInfo37, point2D38);
        java.awt.Paint paint40 = categoryPlot21.getDomainGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = categoryPlot21.getRenderer();
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(categoryAxis22);
        org.junit.Assert.assertNull(categoryAxis24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "XY Plot" + "'", str26.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNull(categoryItemRenderer41);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke1 = ringPlot0.getLabelLinkStroke();
        double double2 = ringPlot0.getOuterSeparatorExtension();
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font5 = ringPlot4.getNoDataMessageFont();
        boolean boolean7 = ringPlot4.equals((java.lang.Object) (byte) 1);
        org.jfree.data.general.PieDataset pieDataset8 = ringPlot4.getDataset();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        float[] floatArray19 = new float[] { 0L, (short) 100, 10.0f, (short) 100, 0.0f, 1L };
        float[] floatArray20 = java.awt.Color.RGBtoHSB((int) (byte) -1, (int) '#', (int) ' ', floatArray19);
        float[] floatArray21 = color9.getComponents(floatArray20);
        ringPlot4.setLabelPaint((java.awt.Paint) color9);
        ringPlot0.setSectionPaint((java.lang.Comparable) (-16777216), (java.awt.Paint) color9);
        double double24 = ringPlot0.getLabelLinkMargin();
        ringPlot0.setOuterSeparatorExtension(10.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double29 = rectangleInsets27.calculateTopInset((double) 0.5f);
        ringPlot0.setInsets(rectangleInsets27);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(pieDataset8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.025d + "'", double24 == 0.025d);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isRangeZoomable();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = polarPlot0.getLegendItems();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(legendItemCollection2);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = categoryPlot21.getDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot21.getDomainAxis((-1));
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str26 = xYPlot25.getPlotType();
        boolean boolean27 = xYPlot25.isRangeZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation28 = xYPlot25.getRangeAxisLocation();
        categoryPlot21.setDomainAxisLocation(axisLocation28);
        org.jfree.chart.axis.AxisSpace axisSpace30 = null;
        categoryPlot21.setFixedDomainAxisSpace(axisSpace30);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D33 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand34 = null;
        numberAxis3D33.setMarkerBand(markerAxisBand34);
        java.awt.Shape shape36 = numberAxis3D33.getRightArrow();
        numberAxis3D33.setVisible(false);
        org.jfree.data.Range range39 = categoryPlot21.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D33);
        java.awt.Paint paint40 = categoryPlot21.getRangeGridlinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = categoryPlot21.getAxisOffset();
        categoryPlot21.setDrawSharedDomainAxis(true);
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(categoryAxis22);
        org.junit.Assert.assertNull(categoryAxis24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "XY Plot" + "'", str26.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNull(range39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(rectangleInsets41);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font2 = ringPlot1.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("ThreadContext", font2);
        java.awt.Color color4 = java.awt.Color.BLACK;
        textTitle3.setPaint((java.awt.Paint) color4);
        java.awt.Font font6 = textTitle3.getFont();
        textTitle3.setWidth(0.0d);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = textTitle3.getHorizontalAlignment();
        java.lang.Object obj10 = textTitle3.clone();
        textTitle3.setNotify(false);
        java.lang.Object obj13 = null;
        boolean boolean14 = textTitle3.equals(obj13);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge0);
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertNotNull(rectangleEdge1);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font2 = ringPlot1.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("ThreadContext", font2);
        java.awt.Color color4 = java.awt.Color.BLACK;
        textTitle3.setPaint((java.awt.Paint) color4);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = textTitle3.getTextAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.ColumnArrangement columnArrangement10 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment6, verticalAlignment7, (double) 0.5f, (double) (-165));
        org.jfree.chart.block.BlockContainer blockContainer11 = new org.jfree.chart.block.BlockContainer();
        blockContainer11.clear();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.data.time.DateRange dateRange14 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str15 = dateRange14.toString();
        boolean boolean18 = dateRange14.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange14, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = rectangleConstraint20.toUnconstrainedWidth();
        org.jfree.data.Range range22 = rectangleConstraint20.getWidthRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint24 = rectangleConstraint20.toFixedHeight(1.0E-5d);
        org.jfree.chart.util.Size2D size2D25 = columnArrangement10.arrange(blockContainer11, graphics2D13, rectangleConstraint24);
        size2D25.setWidth((double) 500);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertNotNull(verticalAlignment7);
        org.junit.Assert.assertNotNull(dateRange14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str15.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint21);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(rectangleConstraint24);
        org.junit.Assert.assertNotNull(size2D25);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        polarPlot0.setAngleTickUnit((org.jfree.chart.axis.TickUnit) dateTickUnit1);
        java.awt.Font font3 = polarPlot0.getAngleLabelFont();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str5 = dateRange4.toString();
        boolean boolean8 = dateRange4.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = rectangleConstraint10.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint11.toFixedWidth(0.0d);
        boolean boolean14 = polarPlot0.equals((java.lang.Object) rectangleConstraint11);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D18 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand19 = null;
        numberAxis3D18.setMarkerBand(markerAxisBand19);
        org.jfree.data.time.DateRange dateRange21 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str22 = dateRange21.toString();
        boolean boolean25 = dateRange21.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint27 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange21, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint28 = rectangleConstraint27.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = rectangleConstraint27.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range31 = rectangleConstraint27.getWidthRange();
        numberAxis3D18.setRangeWithMargins(range31, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, (org.jfree.chart.axis.ValueAxis) numberAxis3D18, categoryItemRenderer35);
        numberAxis3D18.setUpperMargin(0.0d);
        double double39 = numberAxis3D18.getLabelAngle();
        org.jfree.data.Range range40 = numberAxis3D18.getRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint41 = rectangleConstraint11.toRangeWidth(range40);
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str5.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint11);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateRange21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str22.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint28);
        org.junit.Assert.assertNotNull(rectangleConstraint30);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(range40);
        org.junit.Assert.assertNotNull(rectangleConstraint41);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font2 = ringPlot1.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("ThreadContext", font2);
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = xYPlot4.getRendererForDataset(xYDataset5);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        xYPlot4.setDomainAxis(valueAxis7);
        java.awt.Color color9 = java.awt.Color.BLACK;
        float[] floatArray19 = new float[] { 0L, (short) 100, 10.0f, (short) 100, 0.0f, 1L };
        float[] floatArray20 = java.awt.Color.RGBtoHSB((int) (byte) -1, (int) '#', (int) ' ', floatArray19);
        float[] floatArray21 = color9.getRGBColorComponents(floatArray19);
        xYPlot4.setDomainGridlinePaint((java.awt.Paint) color9);
        textTitle3.setPaint((java.awt.Paint) color9);
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str25 = xYPlot24.getPlotType();
        boolean boolean26 = xYPlot24.isRangeZoomable();
        java.awt.Color color27 = java.awt.Color.MAGENTA;
        xYPlot24.setRangeZeroBaselinePaint((java.awt.Paint) color27);
        org.jfree.chart.plot.PiePlot piePlot30 = new org.jfree.chart.plot.PiePlot();
        piePlot30.setLabelGap(0.0d);
        piePlot30.setCircular(true);
        double double35 = piePlot30.getShadowYOffset();
        java.awt.Font font36 = piePlot30.getLabelFont();
        java.awt.Color color37 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.text.TextFragment textFragment39 = new org.jfree.chart.text.TextFragment("TextBlockAnchor.BOTTOM_CENTER", font36, (java.awt.Paint) color37, 0.0f);
        java.awt.Color color40 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        float[] floatArray50 = new float[] { 0L, (short) 100, 10.0f, (short) 100, 0.0f, 1L };
        float[] floatArray51 = java.awt.Color.RGBtoHSB((int) (byte) -1, (int) '#', (int) ' ', floatArray50);
        float[] floatArray52 = color40.getComponents(floatArray51);
        float[] floatArray53 = color37.getRGBComponents(floatArray52);
        float[] floatArray54 = color27.getComponents(floatArray53);
        float[] floatArray55 = color9.getColorComponents(floatArray53);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNull(xYItemRenderer6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "XY Plot" + "'", str25.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 4.0d + "'", double35 == 4.0d);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(floatArray50);
        org.junit.Assert.assertNotNull(floatArray51);
        org.junit.Assert.assertNotNull(floatArray52);
        org.junit.Assert.assertNotNull(floatArray53);
        org.junit.Assert.assertNotNull(floatArray54);
        org.junit.Assert.assertNotNull(floatArray55);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("ChartChangeEventType.DATASET_UPDATED", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str1 = xYPlot0.getPlotType();
        boolean boolean2 = xYPlot0.isDomainZeroBaselineVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = xYPlot0.getDomainAxisEdge((-32640));
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = xYPlot5.getRendererForDataset(xYDataset6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        xYPlot5.setDomainAxis(valueAxis8);
        java.awt.Paint paint10 = xYPlot5.getRangeCrosshairPaint();
        xYPlot0.setRangeCrosshairPaint(paint10);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = xYPlot0.getRangeAxisEdge();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "XY Plot" + "'", str1.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNull(xYItemRenderer7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleEdge12);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray27 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0L };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray25, numberArray27, numberArray29, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("VerticalAlignment.BOTTOM", "XY Plot", numberArray32);
        org.jfree.data.Range range35 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset33, false);
        java.lang.Number number36 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset33);
        categoryPlot21.setDataset(categoryDataset33);
        categoryPlot21.mapDatasetToRangeAxis((int) (byte) 100, 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = null;
        java.awt.geom.Point2D point2D43 = null;
        categoryPlot21.zoomDomainAxes((double) '#', plotRenderingInfo42, point2D43);
        boolean boolean45 = categoryPlot21.getDrawSharedDomainAxis();
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str47 = xYPlot46.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset49 = null;
        xYPlot46.setDataset(0, xYDataset49);
        xYPlot46.clearDomainMarkers();
        java.awt.Stroke stroke52 = xYPlot46.getDomainGridlineStroke();
        categoryPlot21.setRangeGridlineStroke(stroke52);
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertTrue("'" + number36 + "' != '" + 0.0d + "'", number36.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "XY Plot" + "'", str47.equals("XY Plot"));
        org.junit.Assert.assertNotNull(stroke52);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = xYPlot0.getRendererForDataset(xYDataset1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        xYPlot0.setDomainAxis(valueAxis3);
        java.awt.Paint paint5 = xYPlot0.getRangeCrosshairPaint();
        java.lang.String str6 = xYPlot0.getPlotType();
        java.awt.Paint paint7 = xYPlot0.getRangeZeroBaselinePaint();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor8 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.jfree.chart.JFreeChart jFreeChart9 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent12 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) textBlockAnchor8, jFreeChart9, (int) (byte) 10, (int) (byte) 100);
        org.jfree.chart.plot.RingPlot ringPlot15 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font16 = ringPlot15.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle("ThreadContext", font16);
        org.jfree.chart.plot.PiePlot piePlot18 = new org.jfree.chart.plot.PiePlot();
        piePlot18.setLabelGap(0.0d);
        piePlot18.setCircular(true);
        java.awt.Shape shape23 = piePlot18.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart25 = new org.jfree.chart.JFreeChart("ThreadContext", font16, (org.jfree.chart.plot.Plot) piePlot18, false);
        float float26 = jFreeChart25.getBackgroundImageAlpha();
        chartProgressEvent12.setChart(jFreeChart25);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent30 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) paint7, jFreeChart25, 0, 3);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo33 = null;
        java.awt.image.BufferedImage bufferedImage34 = jFreeChart25.createBufferedImage(500, (int) (short) 10, chartRenderingInfo33);
        org.junit.Assert.assertNull(xYItemRenderer2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "XY Plot" + "'", str6.equals("XY Plot"));
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlockAnchor8);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 0.5f + "'", float26 == 0.5f);
        org.junit.Assert.assertNotNull(bufferedImage34);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font3 = ringPlot2.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("ThreadContext", font3);
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        piePlot5.setLabelGap(0.0d);
        piePlot5.setCircular(true);
        java.awt.Shape shape10 = piePlot5.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("ThreadContext", font3, (org.jfree.chart.plot.Plot) piePlot5, false);
        jFreeChart12.clearSubtitles();
        java.awt.Stroke stroke14 = jFreeChart12.getBorderStroke();
        java.awt.Paint paint15 = jFreeChart12.getBorderPaint();
        jFreeChart12.removeLegend();
        java.util.List list17 = jFreeChart12.getSubtitles();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(list17);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("TextBlockAnchor.BOTTOM_CENTER");
        numberAxis3D1.setFixedAutoRange(100.0d);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font3 = ringPlot2.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("ThreadContext", font3);
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        piePlot5.setLabelGap(0.0d);
        piePlot5.setCircular(true);
        java.awt.Shape shape10 = piePlot5.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("ThreadContext", font3, (org.jfree.chart.plot.Plot) piePlot5, false);
        java.awt.Image image13 = null;
        jFreeChart12.setBackgroundImage(image13);
        jFreeChart12.setBackgroundImageAlignment((-1));
        jFreeChart12.setBorderVisible(true);
        org.jfree.chart.plot.RingPlot ringPlot19 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.Plot plot20 = ringPlot19.getRootPlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor21 = ringPlot19.getLabelDistributor();
        try {
            jFreeChart12.setTextAntiAlias((java.lang.Object) ringPlot19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: org.jfree.chart.plot.RingPlot@76d5dec8 incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(plot20);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor21);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = categoryPlot21.getDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot21.getDomainAxis((-1));
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str26 = xYPlot25.getPlotType();
        boolean boolean27 = xYPlot25.isRangeZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation28 = xYPlot25.getRangeAxisLocation();
        categoryPlot21.setDomainAxisLocation(axisLocation28);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D31 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand32 = null;
        numberAxis3D31.setMarkerBand(markerAxisBand32);
        numberAxis3D31.zoomRange(0.0d, (double) (short) 1);
        org.jfree.data.time.DateRange dateRange37 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str38 = dateRange37.toString();
        boolean boolean41 = dateRange37.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint43 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange37, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint44 = rectangleConstraint43.toUnconstrainedWidth();
        org.jfree.data.Range range45 = rectangleConstraint43.getWidthRange();
        numberAxis3D31.setDefaultAutoRange(range45);
        numberAxis3D31.resizeRange((double) 0, 0.0d);
        categoryPlot21.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D31);
        int int51 = categoryPlot21.getDatasetCount();
        java.awt.Paint paint52 = categoryPlot21.getRangeCrosshairPaint();
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(categoryAxis22);
        org.junit.Assert.assertNull(categoryAxis24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "XY Plot" + "'", str26.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNotNull(dateRange37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str38.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint44);
        org.junit.Assert.assertNotNull(range45);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
        org.junit.Assert.assertNotNull(paint52);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        double double0 = org.jfree.chart.axis.DateAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE_IN_MILLISECONDS;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.0d + "'", double0 == 2.0d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (-1), (java.awt.Paint) color1, stroke2);
        double double4 = valueMarker3.getValue();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.0d) + "'", double4 == (-1.0d));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        ringPlot1.setShadowYOffset((double) 100L);
        java.awt.Paint paint4 = ringPlot1.getLabelPaint();
        double double5 = ringPlot1.getInteriorGap();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.08d + "'", double5 == 0.08d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot(pieDataset1);
        boolean boolean3 = ringPlot2.getIgnoreZeroValues();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        piePlot6.setLabelGap(0.0d);
        piePlot6.setCircular(true);
        double double11 = piePlot6.getShadowYOffset();
        java.awt.Font font12 = piePlot6.getLabelFont();
        piePlot6.setIgnoreNullValues(true);
        boolean boolean15 = piePlot6.getSectionOutlinesVisible();
        java.awt.Stroke stroke17 = piePlot6.getSectionOutlineStroke((java.lang.Comparable) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        org.jfree.chart.plot.PiePlotState piePlotState20 = ringPlot2.initialise(graphics2D4, rectangle2D5, piePlot6, (java.lang.Integer) (-1), plotRenderingInfo19);
        java.awt.geom.Rectangle2D rectangle2D21 = piePlotState20.getPieArea();
        int int22 = objectList0.indexOf((java.lang.Object) piePlotState20);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(stroke17);
        org.junit.Assert.assertNotNull(piePlotState20);
        org.junit.Assert.assertNull(rectangle2D21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.addCornerTextItem("TextBlockAnchor.TOP_LEFT");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand5 = null;
        numberAxis3D4.setMarkerBand(markerAxisBand5);
        numberAxis3D4.zoomRange(0.0d, (double) (short) 1);
        org.jfree.data.Range range10 = polarPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D4);
        numberAxis3D4.setAutoRangeStickyZero(true);
        org.junit.Assert.assertNull(range10);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) textFragment1);
        java.lang.Object obj3 = chartChangeEvent2.getSource();
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = categoryPlot21.getDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot21.getDomainAxis((-1));
        org.jfree.chart.util.Layer layer26 = null;
        java.util.Collection collection27 = categoryPlot21.getRangeMarkers((int) ' ', layer26);
        java.awt.Color color28 = java.awt.Color.BLACK;
        categoryPlot21.setRangeGridlinePaint((java.awt.Paint) color28);
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D33 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand34 = null;
        numberAxis3D33.setMarkerBand(markerAxisBand34);
        org.jfree.data.time.DateRange dateRange36 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str37 = dateRange36.toString();
        boolean boolean40 = dateRange36.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint42 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange36, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint43 = rectangleConstraint42.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint45 = rectangleConstraint42.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range46 = rectangleConstraint42.getWidthRange();
        numberAxis3D33.setRangeWithMargins(range46, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer50 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, (org.jfree.chart.axis.ValueAxis) numberAxis3D33, categoryItemRenderer50);
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = null;
        categoryPlot51.setDomainAxis(categoryAxis52);
        org.jfree.chart.plot.XYPlot xYPlot55 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace56 = null;
        xYPlot55.setFixedRangeAxisSpace(axisSpace56, false);
        java.awt.Paint paint59 = xYPlot55.getOutlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation61 = xYPlot55.getRangeAxisLocation((-16777216));
        categoryPlot51.setRangeAxisLocation((int) (short) 100, axisLocation61);
        org.jfree.chart.util.SortOrder sortOrder63 = categoryPlot51.getRowRenderingOrder();
        categoryPlot21.setColumnRenderingOrder(sortOrder63);
        categoryPlot21.mapDatasetToRangeAxis(100, (int) (byte) -1);
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(categoryAxis22);
        org.junit.Assert.assertNull(categoryAxis24);
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(dateRange36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str37.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint43);
        org.junit.Assert.assertNotNull(rectangleConstraint45);
        org.junit.Assert.assertNotNull(range46);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertNotNull(axisLocation61);
        org.junit.Assert.assertNotNull(sortOrder63);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.clear();
        java.lang.Object obj2 = blockContainer0.clone();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font7 = ringPlot6.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("ThreadContext", font7);
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot();
        piePlot9.setLabelGap(0.0d);
        piePlot9.setCircular(true);
        java.awt.Shape shape14 = piePlot9.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("ThreadContext", font7, (org.jfree.chart.plot.Plot) piePlot9, false);
        jFreeChart16.setBorderVisible(false);
        java.awt.RenderingHints renderingHints19 = jFreeChart16.getRenderingHints();
        org.jfree.chart.title.TextTitle textTitle20 = jFreeChart16.getTitle();
        java.lang.Number[] numberArray24 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray28 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray30 = new java.lang.Number[] { 0L };
        java.lang.Number[][] numberArray31 = new java.lang.Number[][] { numberArray24, numberArray26, numberArray28, numberArray30 };
        org.jfree.data.category.CategoryDataset categoryDataset32 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("VerticalAlignment.BOTTOM", "XY Plot", numberArray31);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset32);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D35 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D39 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand40 = null;
        numberAxis3D39.setMarkerBand(markerAxisBand40);
        org.jfree.data.time.DateRange dateRange42 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str43 = dateRange42.toString();
        boolean boolean46 = dateRange42.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint48 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange42, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint49 = rectangleConstraint48.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint51 = rectangleConstraint48.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range52 = rectangleConstraint48.getWidthRange();
        numberAxis3D39.setRangeWithMargins(range52, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer56 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot57 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis37, (org.jfree.chart.axis.ValueAxis) numberAxis3D39, categoryItemRenderer56);
        numberAxis3D39.setUpperMargin(0.0d);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer60 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot61 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D35, (org.jfree.chart.axis.ValueAxis) numberAxis3D39, categoryItemRenderer60);
        java.awt.Graphics2D graphics2D62 = null;
        org.jfree.chart.axis.AxisState axisState63 = null;
        org.jfree.chart.util.Size2D size2D64 = new org.jfree.chart.util.Size2D();
        size2D64.height = 10L;
        size2D64.setHeight(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor71 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D72 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D64, 0.05d, (double) 1, rectangleAnchor71);
        org.jfree.chart.util.RectangleEdge rectangleEdge73 = null;
        java.util.List list74 = categoryAxis3D35.refreshTicks(graphics2D62, axisState63, rectangle2D72, rectangleEdge73);
        textTitle20.setBounds(rectangle2D72);
        org.jfree.chart.plot.RingPlot ringPlot77 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font78 = ringPlot77.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle79 = new org.jfree.chart.title.TextTitle("ThreadContext", font78);
        java.awt.Color color80 = java.awt.Color.BLACK;
        textTitle79.setPaint((java.awt.Paint) color80);
        java.awt.Font font82 = textTitle79.getFont();
        try {
            java.lang.Object obj83 = blockContainer0.draw(graphics2D3, rectangle2D72, (java.lang.Object) font82);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(renderingHints19);
        org.junit.Assert.assertNotNull(textTitle20);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(categoryDataset32);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertNotNull(dateRange42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str43.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint49);
        org.junit.Assert.assertNotNull(rectangleConstraint51);
        org.junit.Assert.assertNotNull(range52);
        org.junit.Assert.assertNotNull(rectangleAnchor71);
        org.junit.Assert.assertNotNull(rectangle2D72);
        org.junit.Assert.assertNotNull(list74);
        org.junit.Assert.assertNotNull(font78);
        org.junit.Assert.assertNotNull(color80);
        org.junit.Assert.assertNotNull(font82);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setLabelGap(0.0d);
        piePlot0.setCircular(true);
        java.awt.Shape shape5 = piePlot0.getLegendItemShape();
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape5, "{0}");
        chartEntity7.setURLText("PlotOrientation.VERTICAL");
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        java.awt.Color color2 = java.awt.Color.BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint) color2, stroke3);
        java.awt.Font font5 = valueMarker4.getLabelFont();
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        piePlot6.setLabelGap(0.0d);
        piePlot6.setCircular(true);
        double double11 = piePlot6.getShadowYOffset();
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("", font5, (org.jfree.chart.plot.Plot) piePlot6, true);
        org.jfree.chart.plot.RingPlot ringPlot15 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font16 = ringPlot15.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle("ThreadContext", font16);
        java.awt.Color color18 = java.awt.Color.BLACK;
        textTitle17.setPaint((java.awt.Paint) color18);
        java.awt.Font font20 = textTitle17.getFont();
        textTitle17.setWidth(0.0d);
        textTitle17.setURLText("TextBlockAnchor.BOTTOM_CENTER");
        jFreeChart13.setTitle(textTitle17);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(font20);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        java.awt.Color color1 = java.awt.Color.BLUE;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint) color1, stroke2);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str6 = xYPlot5.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        xYPlot5.setDataset(0, xYDataset8);
        java.lang.Class<?> wildcardClass10 = xYPlot5.getClass();
        java.net.URL uRL11 = org.jfree.chart.util.ObjectUtilities.getResource("Multiple Pie Plot", (java.lang.Class) wildcardClass10);
        java.util.EventListener[] eventListenerArray12 = valueMarker3.getListeners((java.lang.Class) wildcardClass10);
        float float13 = valueMarker3.getAlpha();
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str16 = xYPlot15.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        xYPlot15.setDataset(0, xYDataset18);
        java.lang.Class<?> wildcardClass20 = xYPlot15.getClass();
        java.awt.Paint[] paintArray22 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.lang.Class<?> wildcardClass23 = paintArray22.getClass();
        java.net.URL uRL24 = org.jfree.chart.util.ObjectUtilities.getResource("ChartChangeEventType.DATASET_UPDATED", (java.lang.Class) wildcardClass23);
        java.lang.Object obj25 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Multiple Pie Plot", (java.lang.Class) wildcardClass20, (java.lang.Class) wildcardClass23);
        try {
            java.util.EventListener[] eventListenerArray26 = valueMarker3.getListeners((java.lang.Class) wildcardClass23);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: [[Ljava.awt.Paint; cannot be cast to [Ljava.util.EventListener;");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "XY Plot" + "'", str6.equals("XY Plot"));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNull(uRL11);
        org.junit.Assert.assertNotNull(eventListenerArray12);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 1.0f + "'", float13 == 1.0f);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "XY Plot" + "'", str16.equals("XY Plot"));
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(paintArray22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNull(uRL24);
        org.junit.Assert.assertNull(obj25);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = xYPlot2.getRendererForDataset(xYDataset3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.util.List list7 = null;
        xYPlot2.drawDomainTickBands(graphics2D5, rectangle2D6, list7);
        xYPlot2.zoom(0.0d);
        java.awt.Color color12 = java.awt.Color.BLUE;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint) color12, stroke13);
        java.awt.Font font15 = valueMarker14.getLabelFont();
        xYPlot2.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker14);
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str19 = xYPlot18.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        xYPlot18.setDataset(0, xYDataset21);
        java.lang.Class<?> wildcardClass23 = xYPlot18.getClass();
        java.net.URL uRL24 = org.jfree.chart.util.ObjectUtilities.getResource("Multiple Pie Plot", (java.lang.Class) wildcardClass23);
        java.util.EventListener[] eventListenerArray25 = valueMarker14.getListeners((java.lang.Class) wildcardClass23);
        java.net.URL uRL26 = org.jfree.chart.util.ObjectUtilities.getResource("", (java.lang.Class) wildcardClass23);
        java.net.URL uRL27 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("TextBlockAnchor.BOTTOM_CENTER", (java.lang.Class) wildcardClass23);
        org.junit.Assert.assertNull(xYItemRenderer4);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "XY Plot" + "'", str19.equals("XY Plot"));
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNull(uRL24);
        org.junit.Assert.assertNotNull(eventListenerArray25);
        org.junit.Assert.assertNotNull(uRL26);
        org.junit.Assert.assertNull(uRL27);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextFillPaint();
        java.awt.Paint paint2 = defaultDrawingSupplier0.getNextPaint();
        java.awt.Paint paint3 = defaultDrawingSupplier0.getNextFillPaint();
        java.lang.Object obj4 = defaultDrawingSupplier0.clone();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis3D2.setMarkerBand(markerAxisBand3);
        org.jfree.data.time.DateRange dateRange5 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str6 = dateRange5.toString();
        boolean boolean9 = dateRange5.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange5, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = rectangleConstraint11.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = rectangleConstraint11.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range15 = rectangleConstraint11.getWidthRange();
        numberAxis3D2.setRangeWithMargins(range15, true, true);
        numberAxis3D2.setAutoRangeMinimumSize((double) 10, false);
        numberAxis3D2.setFixedAutoRange(0.0d);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, valueAxis24, xYItemRenderer25);
        xYPlot26.clearDomainMarkers((int) (short) 1);
        org.junit.Assert.assertNotNull(dateRange5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str6.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint12);
        org.junit.Assert.assertNotNull(rectangleConstraint14);
        org.junit.Assert.assertNotNull(range15);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace1, false);
        java.awt.Paint paint4 = xYPlot0.getOutlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation6 = xYPlot0.getRangeAxisLocation((-16777216));
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        org.jfree.chart.plot.CrosshairState crosshairState11 = null;
        boolean boolean12 = xYPlot0.render(graphics2D7, rectangle2D8, (int) (short) 10, plotRenderingInfo10, crosshairState11);
        java.lang.String str13 = xYPlot0.getNoDataMessage();
        java.awt.Paint paint14 = xYPlot0.getRangeGridlinePaint();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        categoryPlot21.setDomainAxis(categoryAxis22);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent24 = null;
        categoryPlot21.datasetChanged(datasetChangeEvent24);
        org.jfree.chart.util.Layer layer27 = null;
        java.util.Collection collection28 = categoryPlot21.getDomainMarkers((int) 'a', layer27);
        categoryPlot21.configureDomainAxes();
        categoryPlot21.configureRangeAxes();
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(collection28);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("ChartChangeEventType.DATASET_UPDATED", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = categoryPlot21.getDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot21.getDomainAxis((-1));
        categoryPlot21.clearDomainMarkers();
        categoryPlot21.setDomainGridlinesVisible(true);
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(categoryAxis22);
        org.junit.Assert.assertNull(categoryAxis24);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int1 = color0.getRGB();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo2 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo2.setName("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        boolean boolean5 = color0.equals((java.lang.Object) basicProjectInfo2);
        org.jfree.chart.ui.Library[] libraryArray6 = basicProjectInfo2.getLibraries();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-32640) + "'", int1 == (-32640));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(libraryArray6);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        piePlot1.setLabelGap(0.0d);
        piePlot1.setCircular(true);
        double double6 = piePlot1.getShadowYOffset();
        java.awt.Font font7 = piePlot1.getLabelFont();
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.text.TextFragment textFragment10 = new org.jfree.chart.text.TextFragment("TextBlockAnchor.BOTTOM_CENTER", font7, (java.awt.Paint) color8, 0.0f);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        float[] floatArray21 = new float[] { 0L, (short) 100, 10.0f, (short) 100, 0.0f, 1L };
        float[] floatArray22 = java.awt.Color.RGBtoHSB((int) (byte) -1, (int) '#', (int) ' ', floatArray21);
        float[] floatArray23 = color11.getComponents(floatArray22);
        float[] floatArray24 = color8.getRGBComponents(floatArray23);
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean26 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge25);
        boolean boolean27 = color8.equals((java.lang.Object) rectangleEdge25);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font4 = ringPlot3.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("ThreadContext", font4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        piePlot6.setLabelGap(0.0d);
        piePlot6.setCircular(true);
        java.awt.Shape shape11 = piePlot6.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("ThreadContext", font4, (org.jfree.chart.plot.Plot) piePlot6, false);
        float float14 = jFreeChart13.getBackgroundImageAlpha();
        org.jfree.chart.title.LegendTitle legendTitle16 = jFreeChart13.getLegend((int) ' ');
        java.awt.Stroke stroke17 = jFreeChart13.getBorderStroke();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo21 = null;
        java.awt.image.BufferedImage bufferedImage22 = jFreeChart13.createBufferedImage((int) '4', (int) (byte) 100, (int) (byte) 1, chartRenderingInfo21);
        projectInfo0.setLogo((java.awt.Image) bufferedImage22);
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.5f + "'", float14 == 0.5f);
        org.junit.Assert.assertNull(legendTitle16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(bufferedImage22);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font1 = ringPlot0.getNoDataMessageFont();
        boolean boolean3 = ringPlot0.equals((java.lang.Object) (byte) 1);
        org.jfree.data.general.PieDataset pieDataset4 = ringPlot0.getDataset();
        double double5 = ringPlot0.getOuterSeparatorExtension();
        java.awt.Stroke stroke6 = ringPlot0.getLabelLinkStroke();
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str8 = xYPlot7.getPlotType();
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot7.getRangeAxis();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset10);
        java.lang.String str12 = multiplePiePlot11.getPlotType();
        java.lang.String str13 = multiplePiePlot11.getPlotType();
        boolean boolean14 = xYPlot7.equals((java.lang.Object) str13);
        java.awt.Stroke stroke15 = xYPlot7.getDomainCrosshairStroke();
        ringPlot0.setLabelOutlineStroke(stroke15);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(pieDataset4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "XY Plot" + "'", str8.equals("XY Plot"));
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Multiple Pie Plot" + "'", str12.equals("Multiple Pie Plot"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Multiple Pie Plot" + "'", str13.equals("Multiple Pie Plot"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font1 = ringPlot0.getNoDataMessageFont();
        boolean boolean3 = ringPlot0.equals((java.lang.Object) (byte) 1);
        org.jfree.data.general.PieDataset pieDataset4 = ringPlot0.getDataset();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator5 = null;
        ringPlot0.setToolTipGenerator(pieToolTipGenerator5);
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0);
        org.jfree.chart.block.BlockContainer blockContainer8 = legendTitle7.getItemContainer();
        java.lang.Object obj9 = legendTitle7.clone();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(pieDataset4);
        org.junit.Assert.assertNotNull(blockContainer8);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        piePlot1.setLabelGap(0.0d);
        piePlot1.setCircular(true);
        java.awt.Paint paint6 = piePlot1.getLabelShadowPaint();
        boolean boolean7 = basicProjectInfo0.equals((java.lang.Object) piePlot1);
        piePlot1.setCircular(true);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator10 = piePlot1.getToolTipGenerator();
        java.lang.String str11 = piePlot1.getPlotType();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator12 = null;
        piePlot1.setLegendLabelURLGenerator(pieURLGenerator12);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(pieToolTipGenerator10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Pie Plot" + "'", str11.equals("Pie Plot"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = xYPlot0.getRendererForDataset(xYDataset1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        xYPlot0.setDomainAxis(valueAxis3);
        java.awt.Paint paint5 = xYPlot0.getRangeCrosshairPaint();
        java.lang.String str6 = xYPlot0.getPlotType();
        org.jfree.chart.plot.RingPlot ringPlot9 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font10 = ringPlot9.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("ThreadContext", font10);
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot();
        piePlot12.setLabelGap(0.0d);
        piePlot12.setCircular(true);
        java.awt.Shape shape17 = piePlot12.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("ThreadContext", font10, (org.jfree.chart.plot.Plot) piePlot12, false);
        jFreeChart19.clearSubtitles();
        int int21 = jFreeChart19.getSubtitleCount();
        xYPlot0.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Point2D point2D25 = null;
        xYPlot0.zoomDomainAxes((-1.0d), plotRenderingInfo24, point2D25);
        double double27 = xYPlot0.getRangeCrosshairValue();
        org.junit.Assert.assertNull(xYItemRenderer2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "XY Plot" + "'", str6.equals("XY Plot"));
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str2 = xYPlot1.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot1.setDataset(0, xYDataset4);
        java.lang.Class<?> wildcardClass6 = xYPlot1.getClass();
        java.awt.Paint[] paintArray8 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.lang.Class<?> wildcardClass9 = paintArray8.getClass();
        java.net.URL uRL10 = org.jfree.chart.util.ObjectUtilities.getResource("ChartChangeEventType.DATASET_UPDATED", (java.lang.Class) wildcardClass9);
        java.lang.Object obj11 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Multiple Pie Plot", (java.lang.Class) wildcardClass6, (java.lang.Class) wildcardClass9);
        java.lang.ClassLoader classLoader12 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass6);
        try {
            java.lang.Object obj13 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) wildcardClass6);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "XY Plot" + "'", str2.equals("XY Plot"));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(paintArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNull(uRL10);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNotNull(classLoader12);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis3D2.setMarkerBand(markerAxisBand3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = numberAxis3D2.getTickLabelInsets();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, polarItemRenderer6);
        org.junit.Assert.assertNotNull(rectangleInsets5);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis3D2.setMarkerBand(markerAxisBand3);
        org.jfree.data.time.DateRange dateRange5 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str6 = dateRange5.toString();
        boolean boolean9 = dateRange5.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange5, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = rectangleConstraint11.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = rectangleConstraint11.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range15 = rectangleConstraint11.getWidthRange();
        numberAxis3D2.setRangeWithMargins(range15, true, true);
        numberAxis3D2.setAutoRangeMinimumSize((double) 10, false);
        numberAxis3D2.setFixedAutoRange(0.0d);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, valueAxis24, xYItemRenderer25);
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = xYPlot27.getRendererForDataset(xYDataset28);
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        xYPlot27.setDomainAxis(valueAxis30);
        java.awt.Paint paint32 = xYPlot27.getRangeCrosshairPaint();
        java.lang.String str33 = xYPlot27.getPlotType();
        java.awt.Paint paint34 = xYPlot27.getRangeZeroBaselinePaint();
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray35 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot27.setRenderers(xYItemRendererArray35);
        xYPlot26.setRenderers(xYItemRendererArray35);
        org.junit.Assert.assertNotNull(dateRange5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str6.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint12);
        org.junit.Assert.assertNotNull(rectangleConstraint14);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNull(xYItemRenderer29);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "XY Plot" + "'", str33.equals("XY Plot"));
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(xYItemRendererArray35);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke1 = ringPlot0.getLabelLinkStroke();
        double double2 = ringPlot0.getOuterSeparatorExtension();
        java.awt.Stroke stroke3 = ringPlot0.getBaseSectionOutlineStroke();
        double double4 = ringPlot0.getLabelGap();
        org.jfree.chart.LegendItemCollection legendItemCollection5 = ringPlot0.getLegendItems();
        java.util.Iterator iterator6 = legendItemCollection5.iterator();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.025d + "'", double4 == 0.025d);
        org.junit.Assert.assertNotNull(legendItemCollection5);
        org.junit.Assert.assertNotNull(iterator6);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        float float22 = numberAxis3D3.getTickMarkInsideLength();
        numberAxis3D3.resizeRange(0.08d);
        numberAxis3D3.setRange((double) 0, (double) 255);
        numberAxis3D3.configure();
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.0f + "'", float22 == 0.0f);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextLine textLine2 = new org.jfree.chart.text.TextLine("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=-1.0]", font1);
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Font font5 = textFragment4.getFont();
        textLine2.addFragment(textFragment4);
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("hi!");
        textLine2.removeFragment(textFragment8);
        org.jfree.chart.text.TextFragment textFragment10 = textLine2.getFirstTextFragment();
        org.jfree.chart.text.TextFragment textFragment11 = textLine2.getLastTextFragment();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.text.TextAnchor textAnchor15 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        java.lang.String str16 = textAnchor15.toString();
        try {
            textLine2.draw(graphics2D12, (float) (byte) 0, (float) (short) -1, textAnchor15, (float) (byte) 10, (-1.0f), 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(textFragment10);
        org.junit.Assert.assertNotNull(textFragment11);
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "TextAnchor.BOTTOM_RIGHT" + "'", str16.equals("TextAnchor.BOTTOM_RIGHT"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = categoryPlot21.getDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot21.getDomainAxis((-1));
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str26 = xYPlot25.getPlotType();
        boolean boolean27 = xYPlot25.isRangeZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation28 = xYPlot25.getRangeAxisLocation();
        categoryPlot21.setDomainAxisLocation(axisLocation28);
        org.jfree.chart.axis.AxisSpace axisSpace30 = null;
        categoryPlot21.setFixedDomainAxisSpace(axisSpace30);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D33 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand34 = null;
        numberAxis3D33.setMarkerBand(markerAxisBand34);
        java.awt.Shape shape36 = numberAxis3D33.getRightArrow();
        numberAxis3D33.setVisible(false);
        org.jfree.data.Range range39 = categoryPlot21.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D33);
        double double40 = numberAxis3D33.getFixedAutoRange();
        double double41 = numberAxis3D33.getAutoRangeMinimumSize();
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(categoryAxis22);
        org.junit.Assert.assertNull(categoryAxis24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "XY Plot" + "'", str26.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNull(range39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 1.0E-8d + "'", double41 == 1.0E-8d);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.util.Size2D size2D3 = new org.jfree.chart.util.Size2D();
        size2D3.height = 10L;
        size2D3.setHeight(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D11 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D3, 0.05d, (double) 1, rectangleAnchor10);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = null;
        numberAxis3D15.setMarkerBand(markerAxisBand16);
        org.jfree.data.time.DateRange dateRange18 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str19 = dateRange18.toString();
        boolean boolean22 = dateRange18.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint24 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange18, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint25 = rectangleConstraint24.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint27 = rectangleConstraint24.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range28 = rectangleConstraint24.getWidthRange();
        numberAxis3D15.setRangeWithMargins(range28, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, (org.jfree.chart.axis.ValueAxis) numberAxis3D15, categoryItemRenderer32);
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = null;
        categoryPlot33.setDomainAxis(categoryAxis34);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent36 = null;
        categoryPlot33.datasetChanged(datasetChangeEvent36);
        org.jfree.chart.util.Layer layer39 = null;
        java.util.Collection collection40 = categoryPlot33.getDomainMarkers((int) 'a', layer39);
        categoryPlot33.configureDomainAxes();
        java.lang.String str42 = categoryPlot33.getPlotType();
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = categoryPlot33.getDomainAxisEdge(4);
        double double45 = categoryAxis3D0.getCategoryEnd((int) (byte) 1, (-1), rectangle2D11, rectangleEdge44);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertNotNull(dateRange18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str19.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint25);
        org.junit.Assert.assertNotNull(rectangleConstraint27);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertNull(collection40);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Category Plot" + "'", str42.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangleEdge44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.05d + "'", double45 == 0.05d);
    }
}

