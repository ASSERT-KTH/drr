import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.Range.shift(range0, (double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.lang.ClassLoader classLoader0 = null;
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.awt.Image image0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE;
        org.junit.Assert.assertNull(image0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        java.lang.Comparable comparable1 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, comparable1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = org.jfree.chart.text.TextUtilities.drawAlignedString("", graphics2D1, (float) '4', 0.0f, textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.lang.ClassLoader classLoader0 = null;
        try {
            java.util.ResourceBundle.clearCache(classLoader0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setLabelGap(0.0d);
        org.jfree.chart.util.Rotation rotation3 = null;
        try {
            piePlot0.setDirection(rotation3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'direction' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.awt.Font font1 = null;
        java.awt.Color color2 = java.awt.Color.magenta;
        try {
            org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", font1, (java.awt.Paint) color2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity1 = new org.jfree.chart.entity.ChartEntity(shape0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.JFreeChart jFreeChart2 = null;
        try {
            multiplePiePlot1.setPieChart(jFreeChart2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'pieChart' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.THREAD_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        java.lang.ClassLoader classLoader0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
        org.junit.Assert.assertNull(classLoader0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.awt.Color color0 = java.awt.Color.WHITE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.08d + "'", double0 == 0.08d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.lang.String str1 = textBlockAnchor0.toString();
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextBlockAnchor.BOTTOM_CENTER" + "'", str1.equals("TextBlockAnchor.BOTTOM_CENTER"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.junit.Assert.assertNotNull(date0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            piePlot0.drawOutline(graphics2D1, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ThreadContext", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        piePlot1.setLabelGap(0.0d);
        piePlot1.setCircular(true);
        java.awt.Paint paint6 = piePlot1.getLabelShadowPaint();
        boolean boolean7 = basicProjectInfo0.equals((java.lang.Object) piePlot1);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = null;
        try {
            piePlot1.setInsets(rectangleInsets8, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(true);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setSectionDepth((double) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = null;
        try {
            ringPlot0.setInsets(rectangleInsets3, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setLabelGap(0.0d);
        piePlot0.setCircular(true);
        java.awt.Shape shape5 = piePlot0.getLegendItemShape();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = null;
        try {
            piePlot0.setInsets(rectangleInsets6, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font2 = ringPlot1.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("ThreadContext", font2);
        java.awt.Color color4 = java.awt.Color.BLACK;
        textTitle3.setPaint((java.awt.Paint) color4);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = textTitle3.getTextAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = null;
        try {
            textTitle3.setPadding(rectangleInsets7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'padding' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) '4', (double) (-1), rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        java.lang.Object obj1 = legendItemCollection0.clone();
        try {
            org.jfree.chart.LegendItem legendItem3 = legendItemCollection0.get(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setLabelGap(0.0d);
        piePlot0.setCircular(true);
        double double5 = piePlot0.getShadowYOffset();
        java.awt.Font font6 = piePlot0.getLabelFont();
        org.jfree.chart.util.Rotation rotation7 = null;
        try {
            piePlot0.setDirection(rotation7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'direction' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(font6);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str1 = xYPlot0.getPlotType();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        try {
            xYPlot0.handleClick((int) (short) 10, (-32640), plotRenderingInfo4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "XY Plot" + "'", str1.equals("XY Plot"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("Multiple Pie Plot", "", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "XY Plot");
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        java.awt.color.ColorSpace colorSpace1 = null;
        float[] floatArray11 = new float[] { 0L, (short) 100, 10.0f, (short) 100, 0.0f, 1L };
        float[] floatArray12 = java.awt.Color.RGBtoHSB((int) (byte) -1, (int) '#', (int) ' ', floatArray11);
        try {
            float[] floatArray13 = color0.getComponents(colorSpace1, floatArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = xYPlot0.getRendererForDataset(xYDataset1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        xYPlot0.setDomainAxis(valueAxis3);
        org.jfree.chart.plot.Marker marker5 = null;
        try {
            xYPlot0.addDomainMarker(marker5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer2);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = xYPlot0.getRendererForDataset(xYDataset1);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.util.List list5 = null;
        xYPlot0.drawDomainTickBands(graphics2D3, rectangle2D4, list5);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder7 = null;
        try {
            xYPlot0.setSeriesRenderingOrder(seriesRenderingOrder7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer2);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = xYPlot0.getRendererForDataset(xYDataset1);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            xYPlot0.drawBackground(graphics2D3, rectangle2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer2);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        piePlot1.setLabelGap(0.0d);
        piePlot1.setCircular(true);
        java.awt.Paint paint6 = piePlot1.getLabelShadowPaint();
        boolean boolean7 = basicProjectInfo0.equals((java.lang.Object) piePlot1);
        piePlot1.setCircular(true);
        java.lang.Comparable comparable10 = null;
        try {
            piePlot1.setExplodePercent(comparable10, (double) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_MINIMUM_ARC_ANGLE_TO_DRAW;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-5d + "'", double0 == 1.0E-5d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor6 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("Multiple Pie Plot", graphics2D1, 10.0f, (float) 10, textAnchor4, 0.0d, textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        try {
            org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((-32640));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        java.awt.Paint paint0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str1 = xYPlot0.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        xYPlot0.setDataset(0, xYDataset3);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray5 = null;
        try {
            xYPlot0.setDomainAxes(valueAxisArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "XY Plot" + "'", str1.equals("XY Plot"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        try {
            java.awt.Color color1 = java.awt.Color.decode("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length string");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = xYPlot0.getRendererForDataset(xYDataset1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        xYPlot0.setDomainAxis(valueAxis3);
        java.awt.Color color5 = java.awt.Color.BLACK;
        float[] floatArray15 = new float[] { 0L, (short) 100, 10.0f, (short) 100, 0.0f, 1L };
        float[] floatArray16 = java.awt.Color.RGBtoHSB((int) (byte) -1, (int) '#', (int) ' ', floatArray15);
        float[] floatArray17 = color5.getRGBColorComponents(floatArray15);
        xYPlot0.setDomainGridlinePaint((java.awt.Paint) color5);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        xYPlot0.setOutlinePaint((java.awt.Paint) color19);
        java.lang.String str21 = xYPlot0.getPlotType();
        org.junit.Assert.assertNull(xYItemRenderer2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "XY Plot" + "'", str21.equals("XY Plot"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("XY Plot", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        java.awt.Color color3 = java.awt.Color.getHSBColor(1.0f, (float) (short) 100, 0.0f);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        boolean boolean0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getShadowXOffset();
        java.awt.Font font2 = piePlot0.getLabelFont();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            piePlot0.drawOutline(graphics2D3, rectangle2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
        org.junit.Assert.assertNotNull(font2);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test078");
//        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
//        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
//    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str1 = dateRange0.toString();
        boolean boolean4 = dateRange0.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange0, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = rectangleConstraint6.toUnconstrainedWidth();
        org.jfree.data.Range range8 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = rectangleConstraint6.toRangeWidth(range8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateRange0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str1.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint7);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str1 = dateRange0.toString();
        boolean boolean4 = dateRange0.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange0, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = rectangleConstraint6.toUnconstrainedWidth();
        org.jfree.data.Range range8 = rectangleConstraint6.getWidthRange();
        double double9 = range8.getLowerBound();
        org.junit.Assert.assertNotNull(dateRange0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str1.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint7);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("TextBlockAnchor.BOTTOM_CENTER", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "XY Plot", "XY Plot");
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str1 = xYPlot0.getPlotType();
        boolean boolean2 = xYPlot0.isDomainZeroBaselineVisible();
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font5 = ringPlot4.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("ThreadContext", font5);
        java.awt.Color color7 = java.awt.Color.BLACK;
        textTitle6.setPaint((java.awt.Paint) color7);
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color7);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        try {
            boolean boolean13 = xYPlot0.removeRangeMarker((int) '4', marker11, layer12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "XY Plot" + "'", str1.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = xYPlot0.getRendererForDataset(xYDataset1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        xYPlot0.setDomainAxis(valueAxis3);
        java.awt.Color color5 = java.awt.Color.BLACK;
        float[] floatArray15 = new float[] { 0L, (short) 100, 10.0f, (short) 100, 0.0f, 1L };
        float[] floatArray16 = java.awt.Color.RGBtoHSB((int) (byte) -1, (int) '#', (int) ' ', floatArray15);
        float[] floatArray17 = color5.getRGBColorComponents(floatArray15);
        xYPlot0.setDomainGridlinePaint((java.awt.Paint) color5);
        org.jfree.chart.plot.Marker marker19 = null;
        org.jfree.chart.util.Layer layer20 = null;
        try {
            boolean boolean21 = xYPlot0.removeDomainMarker(marker19, layer20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        java.awt.Color color0 = java.awt.Color.gray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font3 = ringPlot2.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("ThreadContext", font3);
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        piePlot5.setLabelGap(0.0d);
        piePlot5.setCircular(true);
        java.awt.Shape shape10 = piePlot5.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("ThreadContext", font3, (org.jfree.chart.plot.Plot) piePlot5, false);
        jFreeChart12.setBorderVisible(false);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        java.awt.geom.Point2D point2D17 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo18 = null;
        try {
            jFreeChart12.draw(graphics2D15, rectangle2D16, point2D17, chartRenderingInfo18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "hi!", "hi!", "");
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        java.lang.Object obj6 = piePlot5.clone();
        boolean boolean7 = basicProjectInfo4.equals((java.lang.Object) piePlot5);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = piePlot5.getLabelPadding();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int10 = color9.getRGB();
        piePlot5.setNoDataMessagePaint((java.awt.Paint) color9);
        piePlot5.setLabelLinksVisible(false);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-32640) + "'", int10 == (-32640));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.geom.Point2D point2D1 = null;
        try {
            xYPlot0.setQuadrantOrigin(point2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'origin' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font3 = ringPlot2.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("ThreadContext", font3);
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        piePlot5.setLabelGap(0.0d);
        piePlot5.setCircular(true);
        java.awt.Shape shape10 = piePlot5.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("ThreadContext", font3, (org.jfree.chart.plot.Plot) piePlot5, false);
        float float13 = jFreeChart12.getBackgroundImageAlpha();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent14 = null;
        try {
            jFreeChart12.plotChanged(plotChangeEvent14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.5f + "'", float13 == 0.5f);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font2 = ringPlot1.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("ThreadContext", font2);
        java.awt.Color color4 = java.awt.Color.BLACK;
        textTitle3.setPaint((java.awt.Paint) color4);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = textTitle3.getTextAlignment();
        double double7 = textTitle3.getContentYOffset();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("Multiple Pie Plot", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font2 = ringPlot1.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("ThreadContext", font2);
        java.awt.Color color4 = java.awt.Color.BLACK;
        textTitle3.setPaint((java.awt.Paint) color4);
        java.awt.Font font6 = textTitle3.getFont();
        java.awt.Paint paint7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        textTitle3.setBackgroundPaint(paint7);
        java.lang.String str9 = textTitle3.getID();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        java.awt.Color color0 = java.awt.Color.BLUE;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            blockBorder1.draw(graphics2D2, rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str1 = xYPlot0.getPlotType();
        boolean boolean2 = xYPlot0.isDomainZeroBaselineVisible();
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font5 = ringPlot4.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("ThreadContext", font5);
        java.awt.Color color7 = java.awt.Color.BLACK;
        textTitle6.setPaint((java.awt.Paint) color7);
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color7);
        java.awt.Paint paint10 = xYPlot0.getRangeTickBandPaint();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "XY Plot" + "'", str1.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(paint10);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("", "XY Plot", "Multiple Pie Plot", "");
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font3 = ringPlot2.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("ThreadContext", font3);
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        piePlot5.setLabelGap(0.0d);
        piePlot5.setCircular(true);
        java.awt.Shape shape10 = piePlot5.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("ThreadContext", font3, (org.jfree.chart.plot.Plot) piePlot5, false);
        org.jfree.chart.title.LegendTitle legendTitle13 = null;
        try {
            jFreeChart12.addLegend(legendTitle13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'subtitle' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setLabelGap(0.0d);
        piePlot0.setCircular(true);
        java.awt.Shape shape5 = piePlot0.getLegendItemShape();
        org.jfree.chart.entity.ChartEntity chartEntity8 = new org.jfree.chart.entity.ChartEntity(shape5, "hi!", "Multiple Pie Plot");
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator9 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator10 = null;
        try {
            java.lang.String str11 = chartEntity8.getImageMapAreaTag(toolTipTagFragmentGenerator9, uRLTagFragmentGenerator10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str1 = dateRange0.toString();
        boolean boolean4 = dateRange0.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange0, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = rectangleConstraint6.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = rectangleConstraint6.toFixedWidth((double) 0.0f);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType10 = rectangleConstraint9.getHeightConstraintType();
        org.junit.Assert.assertNotNull(dateRange0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str1.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint7);
        org.junit.Assert.assertNotNull(rectangleConstraint9);
        org.junit.Assert.assertNotNull(lengthConstraintType10);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        int int3 = java.awt.Color.HSBtoRGB((float) (byte) 100, (float) (byte) 10, (float) 10L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-165) + "'", int3 == (-165));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        int int1 = legendItemCollection0.getItemCount();
        try {
            org.jfree.chart.LegendItem legendItem3 = legendItemCollection0.get((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        java.awt.Font font1 = null;
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font4 = ringPlot3.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("ThreadContext", font4);
        java.awt.Color color6 = java.awt.Color.BLACK;
        textTitle5.setPaint((java.awt.Paint) color6);
        java.awt.Font font8 = textTitle5.getFont();
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        textTitle5.setBackgroundPaint(paint9);
        try {
            org.jfree.chart.text.TextFragment textFragment12 = new org.jfree.chart.text.TextFragment("", font1, paint9, (float) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = null;
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0, keyToGroupMap1);
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getShadowXOffset();
        java.awt.Font font2 = piePlot0.getLabelFont();
        piePlot0.setPieIndex((int) (short) 0);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        piePlot0.setOutlineStroke(stroke5);
        try {
            piePlot0.setInteriorGap((double) 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'percent' (1.0) argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font3 = ringPlot2.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("ThreadContext", font3);
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        piePlot5.setLabelGap(0.0d);
        piePlot5.setCircular(true);
        java.awt.Shape shape10 = piePlot5.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("ThreadContext", font3, (org.jfree.chart.plot.Plot) piePlot5, false);
        float float13 = jFreeChart12.getBackgroundImageAlpha();
        org.jfree.chart.event.ChartProgressListener chartProgressListener14 = null;
        jFreeChart12.addProgressListener(chartProgressListener14);
        org.jfree.chart.plot.RingPlot ringPlot18 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font19 = ringPlot18.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle("ThreadContext", font19);
        try {
            jFreeChart12.addSubtitle((-32640), (org.jfree.chart.title.Title) textTitle20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'index' argument is out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.5f + "'", float13 == 0.5f);
        org.junit.Assert.assertNotNull(font19);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("ThreadContext", graphics2D1, (double) (short) -1, (float) 1, (float) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = xYPlot0.getRendererForDataset(xYDataset1);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.util.List list5 = null;
        xYPlot0.drawDomainTickBands(graphics2D3, rectangle2D4, list5);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        xYPlot0.setRenderer(xYItemRenderer7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        try {
            xYPlot0.drawBackground(graphics2D9, rectangle2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer2);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        double double2 = piePlot1.getShadowXOffset();
        java.awt.Font font3 = piePlot1.getLabelFont();
        java.awt.Paint paint4 = null;
        org.jfree.chart.text.TextMeasurer textMeasurer6 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("TextBlockAnchor.BOTTOM_CENTER", font3, paint4, (float) 1, textMeasurer6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = xYPlot0.getRendererForDataset(xYDataset1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        xYPlot0.setDomainAxis(valueAxis3);
        java.awt.Color color5 = java.awt.Color.BLACK;
        float[] floatArray15 = new float[] { 0L, (short) 100, 10.0f, (short) 100, 0.0f, 1L };
        float[] floatArray16 = java.awt.Color.RGBtoHSB((int) (byte) -1, (int) '#', (int) ' ', floatArray15);
        float[] floatArray17 = color5.getRGBColorComponents(floatArray15);
        xYPlot0.setDomainGridlinePaint((java.awt.Paint) color5);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        xYPlot0.setOutlinePaint((java.awt.Paint) color19);
        org.jfree.chart.plot.PiePlot piePlot21 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier22 = piePlot21.getDrawingSupplier();
        xYPlot0.setDrawingSupplier(drawingSupplier22);
        org.jfree.chart.LegendItemCollection legendItemCollection24 = xYPlot0.getFixedLegendItems();
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        xYPlot0.drawAnnotations(graphics2D25, rectangle2D26, plotRenderingInfo27);
        org.junit.Assert.assertNull(xYItemRenderer2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(drawingSupplier22);
        org.junit.Assert.assertNull(legendItemCollection24);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str1 = xYPlot0.getPlotType();
        org.jfree.data.general.DatasetGroup datasetGroup2 = xYPlot0.getDatasetGroup();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = null;
        try {
            xYPlot0.setSeriesRenderingOrder(seriesRenderingOrder3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "XY Plot" + "'", str1.equals("XY Plot"));
        org.junit.Assert.assertNull(datasetGroup2);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_FINISHED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font3 = ringPlot2.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("ThreadContext", font3);
        java.awt.Color color5 = java.awt.Color.BLACK;
        textTitle4.setPaint((java.awt.Paint) color5);
        ringPlot0.setLabelOutlinePaint((java.awt.Paint) color5);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str1 = xYPlot0.getPlotType();
        boolean boolean2 = xYPlot0.isRangeZoomable();
        java.awt.Stroke stroke3 = null;
        try {
            xYPlot0.setDomainGridlineStroke(stroke3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "XY Plot" + "'", str1.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str1 = dateRange0.toString();
        boolean boolean4 = dateRange0.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange0, (double) (byte) -1);
        org.jfree.data.Range range7 = rectangleConstraint6.getHeightRange();
        org.junit.Assert.assertNotNull(dateRange0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str1.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(range7);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        double double0 = org.jfree.chart.plot.PiePlot.MAX_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.4d + "'", double0 == 0.4d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("ThreadContext");
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font2 = ringPlot1.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("ThreadContext", font2);
        java.awt.Color color4 = java.awt.Color.BLACK;
        textTitle3.setPaint((java.awt.Paint) color4);
        java.awt.Font font6 = textTitle3.getFont();
        double double7 = textTitle3.getContentYOffset();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        piePlot1.setLabelGap(0.0d);
        piePlot1.setCircular(true);
        java.awt.Paint paint6 = piePlot1.getLabelShadowPaint();
        boolean boolean7 = basicProjectInfo0.equals((java.lang.Object) piePlot1);
        basicProjectInfo0.addOptionalLibrary("hi!");
        java.lang.String str10 = basicProjectInfo0.getLicenceName();
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder((double) 0, 4.0d, (double) '#', (double) (short) -1, (java.awt.Paint) color4);
        java.awt.Paint paint6 = blockBorder5.getPaint();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setLabelGap(0.0d);
        piePlot0.setCircular(true);
        java.awt.Paint paint5 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        piePlot0.setLabelShadowPaint(paint5);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        java.awt.Color color2 = java.awt.Color.getColor("VerticalAlignment.BOTTOM", (int) '#');
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str1 = xYPlot0.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        xYPlot0.setDataset(0, xYDataset3);
        boolean boolean5 = xYPlot0.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        try {
            xYPlot0.setDomainAxisLocation((int) (byte) -1, axisLocation7, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "XY Plot" + "'", str1.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = xYPlot0.getRendererForDataset(xYDataset1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        xYPlot0.setDomainAxis(valueAxis3);
        java.awt.Paint paint5 = xYPlot0.getRangeCrosshairPaint();
        java.lang.String str6 = xYPlot0.getPlotType();
        org.jfree.chart.plot.RingPlot ringPlot9 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font10 = ringPlot9.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("ThreadContext", font10);
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot();
        piePlot12.setLabelGap(0.0d);
        piePlot12.setCircular(true);
        java.awt.Shape shape17 = piePlot12.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("ThreadContext", font10, (org.jfree.chart.plot.Plot) piePlot12, false);
        jFreeChart19.clearSubtitles();
        int int21 = jFreeChart19.getSubtitleCount();
        xYPlot0.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart19);
        java.awt.Stroke stroke23 = null;
        try {
            xYPlot0.setDomainZeroBaselineStroke(stroke23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "XY Plot" + "'", str6.equals("XY Plot"));
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier1 = piePlot0.getDrawingSupplier();
        java.lang.String str2 = piePlot0.getNoDataMessage();
        org.junit.Assert.assertNotNull(drawingSupplier1);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        java.awt.Color color1 = java.awt.Color.BLUE;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint) color1, stroke2);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str6 = xYPlot5.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        xYPlot5.setDataset(0, xYDataset8);
        java.lang.Class<?> wildcardClass10 = xYPlot5.getClass();
        java.net.URL uRL11 = org.jfree.chart.util.ObjectUtilities.getResource("Multiple Pie Plot", (java.lang.Class) wildcardClass10);
        java.util.EventListener[] eventListenerArray12 = valueMarker3.getListeners((java.lang.Class) wildcardClass10);
        org.jfree.chart.text.TextAnchor textAnchor13 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        valueMarker3.setLabelTextAnchor(textAnchor13);
        try {
            valueMarker3.setAlpha((float) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "XY Plot" + "'", str6.equals("XY Plot"));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNull(uRL11);
        org.junit.Assert.assertNotNull(eventListenerArray12);
        org.junit.Assert.assertNotNull(textAnchor13);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        java.awt.Color color0 = java.awt.Color.black;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            blockContainer0.draw(graphics2D1, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        java.awt.Color color0 = java.awt.Color.green;
        int int1 = color0.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis3D1.setMarkerBand(markerAxisBand2);
        try {
            numberAxis3D1.setAutoRangeMinimumSize((double) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = categoryPlot21.getDomainAxis();
        org.jfree.chart.plot.Marker marker24 = null;
        org.jfree.chart.util.Layer layer25 = null;
        try {
            boolean boolean26 = categoryPlot21.removeDomainMarker((int) ' ', marker24, layer25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(categoryAxis22);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis3D1.setMarkerBand(markerAxisBand2);
        numberAxis3D1.zoomRange(0.0d, (double) (short) 1);
        org.jfree.data.time.DateRange dateRange7 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str8 = dateRange7.toString();
        boolean boolean11 = dateRange7.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange7, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = rectangleConstraint13.toUnconstrainedWidth();
        org.jfree.data.Range range15 = rectangleConstraint13.getWidthRange();
        numberAxis3D1.setDefaultAutoRange(range15);
        numberAxis3D1.resizeRange((double) (byte) 100, (double) 15);
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = org.jfree.chart.util.RectangleEdge.TOP;
        try {
            double double23 = numberAxis3D1.lengthToJava2D(0.0d, rectangle2D21, rectangleEdge22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateRange7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str8.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint14);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNotNull(rectangleEdge22);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        float float0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.5f + "'", float0 == 0.5f);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("Pie Plot", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        java.awt.Color color1 = java.awt.Color.BLUE;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint) color1, stroke2);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str6 = xYPlot5.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        xYPlot5.setDataset(0, xYDataset8);
        java.lang.Class<?> wildcardClass10 = xYPlot5.getClass();
        java.net.URL uRL11 = org.jfree.chart.util.ObjectUtilities.getResource("Multiple Pie Plot", (java.lang.Class) wildcardClass10);
        java.util.EventListener[] eventListenerArray12 = valueMarker3.getListeners((java.lang.Class) wildcardClass10);
        org.jfree.chart.text.TextAnchor textAnchor13 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        valueMarker3.setLabelTextAnchor(textAnchor13);
        java.awt.Paint paint15 = valueMarker3.getLabelPaint();
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = xYPlot16.getRendererForDataset(xYDataset17);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        xYPlot16.setDomainAxis(valueAxis19);
        java.awt.Paint paint21 = xYPlot16.getRangeCrosshairPaint();
        java.lang.String str22 = xYPlot16.getPlotType();
        valueMarker3.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot16);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "XY Plot" + "'", str6.equals("XY Plot"));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNull(uRL11);
        org.junit.Assert.assertNotNull(eventListenerArray12);
        org.junit.Assert.assertNotNull(textAnchor13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(xYItemRenderer18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "XY Plot" + "'", str22.equals("XY Plot"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = xYPlot0.getRendererForDataset(xYDataset1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        xYPlot0.setDomainAxis(valueAxis3);
        java.awt.Paint paint5 = xYPlot0.getRangeCrosshairPaint();
        java.lang.String str6 = xYPlot0.getPlotType();
        java.awt.Color color8 = java.awt.Color.BLUE;
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint) color8, stroke9);
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str13 = xYPlot12.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        xYPlot12.setDataset(0, xYDataset15);
        java.lang.Class<?> wildcardClass17 = xYPlot12.getClass();
        java.net.URL uRL18 = org.jfree.chart.util.ObjectUtilities.getResource("Multiple Pie Plot", (java.lang.Class) wildcardClass17);
        java.util.EventListener[] eventListenerArray19 = valueMarker10.getListeners((java.lang.Class) wildcardClass17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        valueMarker10.setLabelTextAnchor(textAnchor20);
        java.awt.Paint paint22 = valueMarker10.getLabelPaint();
        org.jfree.chart.util.Layer layer23 = null;
        try {
            boolean boolean24 = xYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker10, layer23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "XY Plot" + "'", str6.equals("XY Plot"));
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "XY Plot" + "'", str13.equals("XY Plot"));
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNull(uRL18);
        org.junit.Assert.assertNotNull(eventListenerArray19);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, 0.2d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Color color1 = java.awt.Color.MAGENTA;
        piePlot0.setBackgroundPaint((java.awt.Paint) color1);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator3 = null;
        piePlot0.setURLGenerator(pieURLGenerator3);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = xYPlot0.getRendererForDataset(xYDataset1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        xYPlot0.setDomainAxis(valueAxis3);
        java.awt.Color color5 = java.awt.Color.BLACK;
        float[] floatArray15 = new float[] { 0L, (short) 100, 10.0f, (short) 100, 0.0f, 1L };
        float[] floatArray16 = java.awt.Color.RGBtoHSB((int) (byte) -1, (int) '#', (int) ' ', floatArray15);
        float[] floatArray17 = color5.getRGBColorComponents(floatArray15);
        xYPlot0.setDomainGridlinePaint((java.awt.Paint) color5);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        xYPlot0.setOutlinePaint((java.awt.Paint) color19);
        org.jfree.chart.plot.PiePlot piePlot21 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier22 = piePlot21.getDrawingSupplier();
        xYPlot0.setDrawingSupplier(drawingSupplier22);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray24 = null;
        try {
            xYPlot0.setDomainAxes(valueAxisArray24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(drawingSupplier22);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str1 = xYPlot0.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        xYPlot0.setDataset(0, xYDataset3);
        java.lang.Class<?> wildcardClass5 = xYPlot0.getClass();
        org.jfree.chart.plot.Plot plot6 = xYPlot0.getRootPlot();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "XY Plot" + "'", str1.equals("XY Plot"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(plot6);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "hi!", "hi!", "");
        java.lang.String str5 = basicProjectInfo4.getName();
        org.jfree.chart.ui.Library library6 = null;
        try {
            basicProjectInfo4.addOptionalLibrary(library6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Library must be given.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font2 = ringPlot1.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("ThreadContext", font2);
        java.awt.Color color4 = java.awt.Color.BLACK;
        textTitle3.setPaint((java.awt.Paint) color4);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = textTitle3.getTextAlignment();
        java.lang.String str7 = horizontalAlignment6.toString();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "HorizontalAlignment.CENTER" + "'", str7.equals("HorizontalAlignment.CENTER"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "hi!", "hi!", "");
        java.lang.String str5 = basicProjectInfo4.getName();
        java.lang.String str6 = basicProjectInfo4.getName();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font3 = ringPlot2.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("ThreadContext", font3);
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        piePlot5.setLabelGap(0.0d);
        piePlot5.setCircular(true);
        java.awt.Shape shape10 = piePlot5.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("ThreadContext", font3, (org.jfree.chart.plot.Plot) piePlot5, false);
        jFreeChart12.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = jFreeChart12.getPadding();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(rectangleInsets15);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        java.awt.Color color1 = java.awt.Color.BLUE;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint) color1, stroke2);
        java.awt.Font font4 = valueMarker3.getLabelFont();
        java.lang.Object obj5 = valueMarker3.clone();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = xYPlot0.getRendererForDataset(xYDataset1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        xYPlot0.setDomainAxis(valueAxis3);
        java.awt.Color color5 = java.awt.Color.BLACK;
        float[] floatArray15 = new float[] { 0L, (short) 100, 10.0f, (short) 100, 0.0f, 1L };
        float[] floatArray16 = java.awt.Color.RGBtoHSB((int) (byte) -1, (int) '#', (int) ' ', floatArray15);
        float[] floatArray17 = color5.getRGBColorComponents(floatArray15);
        xYPlot0.setDomainGridlinePaint((java.awt.Paint) color5);
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font22 = ringPlot21.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle23 = new org.jfree.chart.title.TextTitle("ThreadContext", font22);
        java.awt.Color color24 = java.awt.Color.BLACK;
        textTitle23.setPaint((java.awt.Paint) color24);
        try {
            xYPlot0.setQuadrantPaint((-1), (java.awt.Paint) color24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (-1) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(color24);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace1, false);
        java.awt.Paint paint4 = xYPlot0.getOutlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation6 = xYPlot0.getRangeAxisLocation((-16777216));
        org.jfree.data.xy.XYDataset xYDataset8 = xYPlot0.getDataset(3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNull(xYDataset8);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D1, (float) (byte) -1, (float) 'a', 0.2d, (float) 1, (float) (-16777216));
        org.junit.Assert.assertNull(shape7);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font2 = ringPlot1.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("ThreadContext", font2);
        java.awt.Color color4 = java.awt.Color.BLACK;
        textTitle3.setPaint((java.awt.Paint) color4);
        java.awt.Font font6 = textTitle3.getFont();
        textTitle3.setWidth(0.0d);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = textTitle3.getHorizontalAlignment();
        boolean boolean10 = textTitle3.getExpandToFitSpace();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str1 = xYPlot0.getPlotType();
        org.jfree.data.general.DatasetGroup datasetGroup2 = xYPlot0.getDatasetGroup();
        boolean boolean3 = xYPlot0.isRangeZeroBaselineVisible();
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = xYPlot0.getRangeMarkers((int) (byte) 1, layer5);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation7 = null;
        try {
            xYPlot0.addAnnotation(xYAnnotation7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "XY Plot" + "'", str1.equals("XY Plot"));
        org.junit.Assert.assertNull(datasetGroup2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(collection6);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) textBlockAnchor0, jFreeChart1, (int) (byte) 10, (int) (byte) 100);
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font8 = ringPlot7.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("ThreadContext", font8);
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot();
        piePlot10.setLabelGap(0.0d);
        piePlot10.setCircular(true);
        java.awt.Shape shape15 = piePlot10.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("ThreadContext", font8, (org.jfree.chart.plot.Plot) piePlot10, false);
        float float18 = jFreeChart17.getBackgroundImageAlpha();
        org.jfree.chart.title.LegendTitle legendTitle20 = jFreeChart17.getLegend((int) ' ');
        chartProgressEvent4.setChart(jFreeChart17);
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.5f + "'", float18 == 0.5f);
        org.junit.Assert.assertNull(legendTitle20);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str1 = xYPlot0.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        xYPlot0.setDataset(0, xYDataset3);
        java.lang.Class<?> wildcardClass5 = xYPlot0.getClass();
        java.awt.Paint paint6 = null;
        try {
            xYPlot0.setDomainGridlinePaint(paint6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "XY Plot" + "'", str1.equals("XY Plot"));
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) "ThreadContext", (double) ' ', 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        boolean boolean2 = ringPlot1.getIgnoreZeroValues();
        java.awt.Font font3 = ringPlot1.getLabelFont();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("XY Plot");
        java.awt.Graphics2D graphics2D2 = null;
        try {
            org.jfree.chart.util.Size2D size2D3 = textFragment1.calculateDimensions(graphics2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setLabelGap(0.0d);
        java.awt.Paint paint3 = piePlot0.getBaseSectionOutlinePaint();
        java.awt.Color color5 = java.awt.Color.BLUE;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint) color5, stroke6);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str10 = xYPlot9.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        xYPlot9.setDataset(0, xYDataset12);
        java.lang.Class<?> wildcardClass14 = xYPlot9.getClass();
        java.net.URL uRL15 = org.jfree.chart.util.ObjectUtilities.getResource("Multiple Pie Plot", (java.lang.Class) wildcardClass14);
        java.util.EventListener[] eventListenerArray16 = valueMarker7.getListeners((java.lang.Class) wildcardClass14);
        org.jfree.chart.text.TextAnchor textAnchor17 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        valueMarker7.setLabelTextAnchor(textAnchor17);
        java.awt.Paint paint19 = valueMarker7.getLabelPaint();
        piePlot0.setLabelOutlinePaint(paint19);
        java.awt.Paint paint21 = piePlot0.getOutlinePaint();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "XY Plot" + "'", str10.equals("XY Plot"));
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNull(uRL15);
        org.junit.Assert.assertNotNull(eventListenerArray16);
        org.junit.Assert.assertNotNull(textAnchor17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        piePlot1.setLabelGap(0.0d);
        piePlot1.setCircular(true);
        java.awt.Paint paint6 = piePlot1.getLabelShadowPaint();
        boolean boolean7 = basicProjectInfo0.equals((java.lang.Object) piePlot1);
        piePlot1.setCircular(true);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator10 = piePlot1.getToolTipGenerator();
        java.lang.String str11 = piePlot1.getPlotType();
        java.awt.Font font12 = piePlot1.getLabelFont();
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(pieToolTipGenerator10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Pie Plot" + "'", str11.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(font12);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = xYPlot0.getRendererForDataset(xYDataset1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        xYPlot0.setDomainAxis(valueAxis3);
        java.awt.Color color5 = java.awt.Color.BLACK;
        float[] floatArray15 = new float[] { 0L, (short) 100, 10.0f, (short) 100, 0.0f, 1L };
        float[] floatArray16 = java.awt.Color.RGBtoHSB((int) (byte) -1, (int) '#', (int) ' ', floatArray15);
        float[] floatArray17 = color5.getRGBColorComponents(floatArray15);
        xYPlot0.setDomainGridlinePaint((java.awt.Paint) color5);
        org.jfree.chart.axis.ValueAxis valueAxis20 = xYPlot0.getRangeAxisForDataset(0);
        boolean boolean21 = xYPlot0.isRangeZoomable();
        xYPlot0.setBackgroundImageAlignment((int) (byte) 100);
        org.junit.Assert.assertNull(xYItemRenderer2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNull(valueAxis20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font3 = ringPlot2.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("ThreadContext", font3);
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        piePlot5.setLabelGap(0.0d);
        piePlot5.setCircular(true);
        java.awt.Shape shape10 = piePlot5.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("ThreadContext", font3, (org.jfree.chart.plot.Plot) piePlot5, false);
        java.awt.Image image13 = null;
        jFreeChart12.setBackgroundImage(image13);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent15 = null;
        try {
            jFreeChart12.plotChanged(plotChangeEvent15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.lang.Object obj1 = null;
        boolean boolean2 = rectangleAnchor0.equals(obj1);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str1 = dateRange0.toString();
        boolean boolean4 = dateRange0.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange0, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = rectangleConstraint6.toUnconstrainedWidth();
        org.jfree.data.Range range8 = rectangleConstraint6.getWidthRange();
        org.jfree.data.Range range10 = org.jfree.data.Range.expandToInclude(range8, 0.2d);
        org.junit.Assert.assertNotNull(dateRange0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str1.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint7);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(range10);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str1 = xYPlot0.getPlotType();
        xYPlot0.mapDatasetToRangeAxis((int) (short) -1, 0);
        org.jfree.chart.block.LineBorder lineBorder5 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = lineBorder5.getInsets();
        double double8 = rectangleInsets6.calculateRightInset((double) 0.5f);
        xYPlot0.setInsets(rectangleInsets6, true);
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType12 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType13 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D14 = rectangleInsets6.createAdjustedRectangle(rectangle2D11, lengthAdjustmentType12, lengthAdjustmentType13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "XY Plot" + "'", str1.equals("XY Plot"));
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font3 = ringPlot2.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("ThreadContext", font3);
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        piePlot5.setLabelGap(0.0d);
        piePlot5.setCircular(true);
        org.jfree.chart.plot.RingPlot ringPlot10 = new org.jfree.chart.plot.RingPlot();
        ringPlot10.setSectionDepth((double) 'a');
        java.awt.Shape shape13 = ringPlot10.getLegendItemShape();
        org.jfree.chart.entity.ChartEntity chartEntity14 = new org.jfree.chart.entity.ChartEntity(shape13);
        piePlot5.setLegendItemShape(shape13);
        try {
            blockContainer0.add((org.jfree.chart.block.Block) textTitle4, (java.lang.Object) shape13);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.awt.geom.Ellipse2D$Double cannot be cast to org.jfree.chart.util.RectangleEdge");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(shape13);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        double double2 = piePlot1.getShadowXOffset();
        java.awt.Font font3 = piePlot1.getLabelFont();
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("Multiple Pie Plot", font3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        try {
            float float7 = textFragment4.calculateBaselineOffset(graphics2D5, textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        float float22 = numberAxis3D3.getTickMarkInsideLength();
        boolean boolean23 = numberAxis3D3.isAutoRange();
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.0f + "'", float22 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str1 = xYPlot0.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        xYPlot0.setDataset(xYDataset2);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "XY Plot" + "'", str1.equals("XY Plot"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        java.awt.Color color1 = java.awt.Color.BLUE;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint) color1, stroke2);
        java.awt.Font font4 = valueMarker3.getLabelFont();
        org.jfree.chart.event.MarkerChangeListener markerChangeListener5 = null;
        valueMarker3.addChangeListener(markerChangeListener5);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        java.awt.Font font0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str1 = dateRange0.toString();
        boolean boolean4 = dateRange0.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange0, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = rectangleConstraint6.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = rectangleConstraint6.toFixedWidth((double) 0.0f);
        java.lang.String str10 = rectangleConstraint9.toString();
        org.jfree.chart.plot.RingPlot ringPlot13 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font14 = ringPlot13.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle("ThreadContext", font14);
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot();
        piePlot16.setLabelGap(0.0d);
        piePlot16.setCircular(true);
        java.awt.Shape shape21 = piePlot16.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("ThreadContext", font14, (org.jfree.chart.plot.Plot) piePlot16, false);
        jFreeChart23.setBorderVisible(false);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent26 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) str10, jFreeChart23);
        org.junit.Assert.assertNotNull(dateRange0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str1.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint7);
        org.junit.Assert.assertNotNull(rectangleConstraint9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=-1.0]" + "'", str10.equals("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=-1.0]"));
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(shape21);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getShadowXOffset();
        java.awt.Font font2 = piePlot0.getLabelFont();
        piePlot0.setPieIndex((int) (short) 0);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = piePlot0.getLegendLabelURLGenerator();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNull(pieURLGenerator5);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = xYPlot0.getRendererForDataset(xYDataset1);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.util.List list5 = null;
        xYPlot0.drawDomainTickBands(graphics2D3, rectangle2D4, list5);
        xYPlot0.zoom(0.0d);
        java.awt.Color color10 = java.awt.Color.BLUE;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint) color10, stroke11);
        java.awt.Font font13 = valueMarker12.getLabelFont();
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker12);
        try {
            xYPlot0.setBackgroundImageAlpha((float) 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer2);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(font13);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font3 = ringPlot2.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("ThreadContext", font3);
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        piePlot5.setLabelGap(0.0d);
        piePlot5.setCircular(true);
        java.awt.Shape shape10 = piePlot5.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("ThreadContext", font3, (org.jfree.chart.plot.Plot) piePlot5, false);
        jFreeChart12.setBorderVisible(false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        try {
            java.awt.image.BufferedImage bufferedImage18 = jFreeChart12.createBufferedImage(2, 0, chartRenderingInfo17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (2) and height (0) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = categoryPlot21.getDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot21.getDomainAxis((-1));
        categoryPlot21.clearDomainMarkers();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation26 = null;
        try {
            categoryPlot21.addAnnotation(categoryAnnotation26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(categoryAxis22);
        org.junit.Assert.assertNull(categoryAxis24);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setLabelGap(0.0d);
        piePlot0.setCircular(true);
        double double5 = piePlot0.getShadowYOffset();
        java.awt.Font font6 = piePlot0.getLabelFont();
        java.awt.Font font7 = piePlot0.getLabelFont();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(font7);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = categoryPlot21.getDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot21.getDomainAxis((-1));
        org.jfree.chart.util.Layer layer26 = null;
        java.util.Collection collection27 = categoryPlot21.getRangeMarkers((int) ' ', layer26);
        org.jfree.chart.util.Layer layer29 = null;
        java.util.Collection collection30 = categoryPlot21.getRangeMarkers(0, layer29);
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = xYPlot31.getRendererForDataset(xYDataset32);
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        xYPlot31.setDomainAxis(valueAxis34);
        java.awt.Color color36 = java.awt.Color.BLACK;
        float[] floatArray46 = new float[] { 0L, (short) 100, 10.0f, (short) 100, 0.0f, 1L };
        float[] floatArray47 = java.awt.Color.RGBtoHSB((int) (byte) -1, (int) '#', (int) ' ', floatArray46);
        float[] floatArray48 = color36.getRGBColorComponents(floatArray46);
        xYPlot31.setDomainGridlinePaint((java.awt.Paint) color36);
        org.jfree.chart.axis.ValueAxis valueAxis51 = xYPlot31.getRangeAxisForDataset(0);
        boolean boolean52 = xYPlot31.isRangeZoomable();
        xYPlot31.setDomainCrosshairLockedOnData(false);
        java.awt.Color color56 = java.awt.Color.BLUE;
        java.awt.Stroke stroke57 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker58 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint) color56, stroke57);
        org.jfree.chart.plot.XYPlot xYPlot60 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str61 = xYPlot60.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset63 = null;
        xYPlot60.setDataset(0, xYDataset63);
        java.lang.Class<?> wildcardClass65 = xYPlot60.getClass();
        java.net.URL uRL66 = org.jfree.chart.util.ObjectUtilities.getResource("Multiple Pie Plot", (java.lang.Class) wildcardClass65);
        java.util.EventListener[] eventListenerArray67 = valueMarker58.getListeners((java.lang.Class) wildcardClass65);
        org.jfree.chart.text.TextAnchor textAnchor68 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        valueMarker58.setLabelTextAnchor(textAnchor68);
        xYPlot31.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker58);
        try {
            boolean boolean71 = categoryPlot21.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker58);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(categoryAxis22);
        org.junit.Assert.assertNull(categoryAxis24);
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertNull(collection30);
        org.junit.Assert.assertNull(xYItemRenderer33);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(floatArray46);
        org.junit.Assert.assertNotNull(floatArray47);
        org.junit.Assert.assertNotNull(floatArray48);
        org.junit.Assert.assertNull(valueAxis51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "XY Plot" + "'", str61.equals("XY Plot"));
        org.junit.Assert.assertNotNull(wildcardClass65);
        org.junit.Assert.assertNull(uRL66);
        org.junit.Assert.assertNotNull(eventListenerArray67);
        org.junit.Assert.assertNotNull(textAnchor68);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        try {
            java.lang.String str2 = jFreeChartResources0.getString("");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key ");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = categoryPlot21.getDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot21.getDomainAxis((-1));
        org.jfree.chart.util.Layer layer26 = null;
        java.util.Collection collection27 = categoryPlot21.getRangeMarkers((int) ' ', layer26);
        org.jfree.chart.util.Layer layer29 = null;
        java.util.Collection collection30 = categoryPlot21.getRangeMarkers(0, layer29);
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = xYPlot31.getRendererForDataset(xYDataset32);
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        xYPlot31.setDomainAxis(valueAxis34);
        java.awt.Color color36 = java.awt.Color.BLACK;
        float[] floatArray46 = new float[] { 0L, (short) 100, 10.0f, (short) 100, 0.0f, 1L };
        float[] floatArray47 = java.awt.Color.RGBtoHSB((int) (byte) -1, (int) '#', (int) ' ', floatArray46);
        float[] floatArray48 = color36.getRGBColorComponents(floatArray46);
        xYPlot31.setDomainGridlinePaint((java.awt.Paint) color36);
        org.jfree.chart.axis.ValueAxis valueAxis51 = xYPlot31.getRangeAxisForDataset(0);
        boolean boolean52 = xYPlot31.isRangeZoomable();
        xYPlot31.setDomainCrosshairLockedOnData(false);
        java.awt.Color color56 = java.awt.Color.BLUE;
        java.awt.Stroke stroke57 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker58 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint) color56, stroke57);
        org.jfree.chart.plot.XYPlot xYPlot60 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str61 = xYPlot60.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset63 = null;
        xYPlot60.setDataset(0, xYDataset63);
        java.lang.Class<?> wildcardClass65 = xYPlot60.getClass();
        java.net.URL uRL66 = org.jfree.chart.util.ObjectUtilities.getResource("Multiple Pie Plot", (java.lang.Class) wildcardClass65);
        java.util.EventListener[] eventListenerArray67 = valueMarker58.getListeners((java.lang.Class) wildcardClass65);
        org.jfree.chart.text.TextAnchor textAnchor68 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        valueMarker58.setLabelTextAnchor(textAnchor68);
        xYPlot31.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker58);
        org.jfree.chart.util.Layer layer71 = null;
        try {
            boolean boolean72 = categoryPlot21.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker58, layer71);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(categoryAxis22);
        org.junit.Assert.assertNull(categoryAxis24);
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertNull(collection30);
        org.junit.Assert.assertNull(xYItemRenderer33);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(floatArray46);
        org.junit.Assert.assertNotNull(floatArray47);
        org.junit.Assert.assertNotNull(floatArray48);
        org.junit.Assert.assertNull(valueAxis51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "XY Plot" + "'", str61.equals("XY Plot"));
        org.junit.Assert.assertNotNull(wildcardClass65);
        org.junit.Assert.assertNull(uRL66);
        org.junit.Assert.assertNotNull(eventListenerArray67);
        org.junit.Assert.assertNotNull(textAnchor68);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setLabelGap(0.0d);
        piePlot0.setCircular(true);
        java.awt.Shape shape5 = piePlot0.getLegendItemShape();
        org.jfree.chart.entity.ChartEntity chartEntity8 = new org.jfree.chart.entity.ChartEntity(shape5, "hi!", "Multiple Pie Plot");
        java.lang.String str9 = chartEntity8.getToolTipText();
        java.lang.String str10 = chartEntity8.getShapeCoords();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0" + "'", str10.equals("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0"));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font2 = ringPlot1.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("ThreadContext", font2);
        java.awt.Color color4 = java.awt.Color.BLACK;
        textTitle3.setPaint((java.awt.Paint) color4);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = textTitle3.getTextAlignment();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.data.time.DateRange dateRange8 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str9 = dateRange8.toString();
        boolean boolean12 = dateRange8.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange8, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint14.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = rectangleConstraint14.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range18 = rectangleConstraint14.getWidthRange();
        try {
            org.jfree.chart.util.Size2D size2D19 = textTitle3.arrange(graphics2D7, rectangleConstraint14);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertNotNull(dateRange8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str9.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(rectangleConstraint17);
        org.junit.Assert.assertNotNull(range18);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        java.awt.Color color0 = java.awt.Color.GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        ringPlot1.setShadowYOffset((double) 100L);
        java.awt.Stroke stroke4 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        ringPlot1.setBaseSectionOutlineStroke(stroke4);
        ringPlot1.setSeparatorsVisible(false);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo1 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo1.setName("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        boolean boolean4 = textAnchor0.equals((java.lang.Object) basicProjectInfo1);
        java.lang.String str5 = basicProjectInfo1.getCopyright();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font3 = ringPlot2.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("ThreadContext", font3);
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        piePlot5.setLabelGap(0.0d);
        piePlot5.setCircular(true);
        java.awt.Shape shape10 = piePlot5.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("ThreadContext", font3, (org.jfree.chart.plot.Plot) piePlot5, false);
        jFreeChart12.removeLegend();
        java.awt.Stroke stroke14 = null;
        jFreeChart12.setBorderStroke(stroke14);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        java.lang.String str1 = textBlockAnchor0.toString();
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextBlockAnchor.TOP_LEFT" + "'", str1.equals("TextBlockAnchor.TOP_LEFT"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font3 = ringPlot2.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("ThreadContext", font3);
        java.awt.Color color5 = java.awt.Color.BLACK;
        textTitle4.setPaint((java.awt.Paint) color5);
        java.awt.Font font7 = textTitle4.getFont();
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font9 = ringPlot8.getNoDataMessageFont();
        boolean boolean11 = ringPlot8.equals((java.lang.Object) (byte) 1);
        org.jfree.data.general.PieDataset pieDataset12 = ringPlot8.getDataset();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        float[] floatArray23 = new float[] { 0L, (short) 100, 10.0f, (short) 100, 0.0f, 1L };
        float[] floatArray24 = java.awt.Color.RGBtoHSB((int) (byte) -1, (int) '#', (int) ' ', floatArray23);
        float[] floatArray25 = color13.getComponents(floatArray24);
        ringPlot8.setLabelPaint((java.awt.Paint) color13);
        org.jfree.chart.text.TextFragment textFragment27 = new org.jfree.chart.text.TextFragment("Pie Plot", font7, (java.awt.Paint) color13);
        java.lang.String str28 = textFragment27.getText();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(pieDataset12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Pie Plot" + "'", str28.equals("Pie Plot"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("HorizontalAlignment.CENTER", graphics2D1, 0.0d, (float) (-32640), 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str1 = xYPlot0.getPlotType();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection3 = xYPlot0.getFixedLegendItems();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "XY Plot" + "'", str1.equals("XY Plot"));
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNull(legendItemCollection3);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font3 = ringPlot2.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("ThreadContext", font3);
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        piePlot5.setLabelGap(0.0d);
        piePlot5.setCircular(true);
        java.awt.Shape shape10 = piePlot5.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("ThreadContext", font3, (org.jfree.chart.plot.Plot) piePlot5, false);
        jFreeChart12.setBorderVisible(false);
        java.awt.RenderingHints renderingHints15 = jFreeChart12.getRenderingHints();
        org.jfree.chart.title.TextTitle textTitle16 = jFreeChart12.getTitle();
        java.awt.Color color17 = java.awt.Color.blue;
        textTitle16.setBackgroundPaint((java.awt.Paint) color17);
        double double19 = textTitle16.getContentYOffset();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(renderingHints15);
        org.junit.Assert.assertNotNull(textTitle16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis3D1.setMarkerBand(markerAxisBand2);
        numberAxis3D1.zoomRange(0.0d, (double) (short) 1);
        org.jfree.data.time.DateRange dateRange7 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str8 = dateRange7.toString();
        boolean boolean11 = dateRange7.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange7, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = rectangleConstraint13.toUnconstrainedWidth();
        org.jfree.data.Range range15 = rectangleConstraint13.getWidthRange();
        numberAxis3D1.setDefaultAutoRange(range15);
        numberAxis3D1.centerRange(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = numberAxis3D1.getLabelInsets();
        org.junit.Assert.assertNotNull(dateRange7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str8.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint14);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNotNull(rectangleInsets19);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str1 = xYPlot0.getPlotType();
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        double double3 = piePlot2.getShadowXOffset();
        java.awt.Font font4 = piePlot2.getLabelFont();
        piePlot2.setPieIndex((int) (short) 0);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        piePlot2.setOutlineStroke(stroke7);
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = xYPlot10.getRendererForDataset(xYDataset11);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        xYPlot10.setDomainAxis(valueAxis13);
        java.awt.Color color15 = java.awt.Color.BLACK;
        float[] floatArray25 = new float[] { 0L, (short) 100, 10.0f, (short) 100, 0.0f, 1L };
        float[] floatArray26 = java.awt.Color.RGBtoHSB((int) (byte) -1, (int) '#', (int) ' ', floatArray25);
        float[] floatArray27 = color15.getRGBColorComponents(floatArray25);
        xYPlot10.setDomainGridlinePaint((java.awt.Paint) color15);
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        xYPlot10.setOutlinePaint((java.awt.Paint) color29);
        java.awt.Color color33 = java.awt.Color.BLUE;
        java.awt.Stroke stroke34 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker35 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint) color33, stroke34);
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str38 = xYPlot37.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset40 = null;
        xYPlot37.setDataset(0, xYDataset40);
        java.lang.Class<?> wildcardClass42 = xYPlot37.getClass();
        java.net.URL uRL43 = org.jfree.chart.util.ObjectUtilities.getResource("Multiple Pie Plot", (java.lang.Class) wildcardClass42);
        java.util.EventListener[] eventListenerArray44 = valueMarker35.getListeners((java.lang.Class) wildcardClass42);
        org.jfree.chart.util.Layer layer45 = null;
        xYPlot10.addRangeMarker((int) ' ', (org.jfree.chart.plot.Marker) valueMarker35, layer45);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType47 = valueMarker35.getLabelOffsetType();
        org.jfree.chart.util.Layer layer48 = null;
        try {
            boolean boolean49 = xYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker35, layer48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "XY Plot" + "'", str1.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(xYItemRenderer12);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "XY Plot" + "'", str38.equals("XY Plot"));
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertNull(uRL43);
        org.junit.Assert.assertNotNull(eventListenerArray44);
        org.junit.Assert.assertNotNull(lengthAdjustmentType47);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font2 = ringPlot1.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("ThreadContext", font2);
        textTitle3.setURLText("hi!");
        textTitle3.setWidth((double) 10.0f);
        org.junit.Assert.assertNotNull(font2);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("Pie Plot", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font2 = ringPlot1.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("ThreadContext", font2);
        java.awt.Color color4 = java.awt.Color.BLACK;
        textTitle3.setPaint((java.awt.Paint) color4);
        double double6 = textTitle3.getWidth();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.lang.String str2 = multiplePiePlot1.getPlotType();
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font5 = ringPlot4.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("ThreadContext", font5);
        java.awt.Color color7 = java.awt.Color.BLACK;
        textTitle6.setPaint((java.awt.Paint) color7);
        multiplePiePlot1.setAggregatedItemsPaint((java.awt.Paint) color7);
        org.jfree.chart.util.TableOrder tableOrder10 = null;
        try {
            multiplePiePlot1.setDataExtractOrder(tableOrder10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Multiple Pie Plot" + "'", str2.equals("Multiple Pie Plot"));
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font3 = ringPlot2.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("ThreadContext", font3);
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        piePlot5.setLabelGap(0.0d);
        piePlot5.setCircular(true);
        java.awt.Shape shape10 = piePlot5.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("ThreadContext", font3, (org.jfree.chart.plot.Plot) piePlot5, false);
        float float13 = jFreeChart12.getBackgroundImageAlpha();
        org.jfree.chart.title.LegendTitle legendTitle15 = jFreeChart12.getLegend((int) ' ');
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo19 = null;
        try {
            java.awt.image.BufferedImage bufferedImage20 = jFreeChart12.createBufferedImage((int) '#', (int) (byte) 0, 500, chartRenderingInfo19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown image type 500");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.5f + "'", float13 == 0.5f);
        org.junit.Assert.assertNull(legendTitle15);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str1 = xYPlot0.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        xYPlot0.setDataset(0, xYDataset3);
        java.lang.Class<?> wildcardClass5 = xYPlot0.getClass();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setRangeZeroBaselineStroke(stroke6);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "XY Plot" + "'", str1.equals("XY Plot"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font2 = ringPlot1.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("ThreadContext", font2);
        textTitle3.setURLText("hi!");
        double double6 = textTitle3.getContentXOffset();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = textTitle3.getTextAlignment();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment7);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.lang.String str2 = multiplePiePlot1.getPlotType();
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font5 = ringPlot4.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("ThreadContext", font5);
        java.awt.Color color7 = java.awt.Color.BLACK;
        textTitle6.setPaint((java.awt.Paint) color7);
        multiplePiePlot1.setAggregatedItemsPaint((java.awt.Paint) color7);
        multiplePiePlot1.setLimit((double) 0L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Multiple Pie Plot" + "'", str2.equals("Multiple Pie Plot"));
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = categoryPlot21.getDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot21.getDomainAxis((-1));
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str26 = xYPlot25.getPlotType();
        boolean boolean27 = xYPlot25.isRangeZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation28 = xYPlot25.getRangeAxisLocation();
        categoryPlot21.setDomainAxisLocation(axisLocation28);
        categoryPlot21.clearRangeAxes();
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(categoryAxis22);
        org.junit.Assert.assertNull(categoryAxis24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "XY Plot" + "'", str26.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(axisLocation28);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        float float22 = numberAxis3D3.getTickMarkInsideLength();
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = org.jfree.chart.util.RectangleEdge.TOP;
        try {
            double double26 = numberAxis3D3.lengthToJava2D(100.0d, rectangle2D24, rectangleEdge25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.0f + "'", float22 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge25);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("ChartChangeEventType.DATASET_UPDATED", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        boolean boolean2 = jFreeChartResources0.containsKey("TextBlockAnchor.TOP_LEFT");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = xYPlot0.getRendererForDataset(xYDataset1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        xYPlot0.setDomainAxis(valueAxis3);
        java.awt.Color color5 = java.awt.Color.BLACK;
        float[] floatArray15 = new float[] { 0L, (short) 100, 10.0f, (short) 100, 0.0f, 1L };
        float[] floatArray16 = java.awt.Color.RGBtoHSB((int) (byte) -1, (int) '#', (int) ' ', floatArray15);
        float[] floatArray17 = color5.getRGBColorComponents(floatArray15);
        xYPlot0.setDomainGridlinePaint((java.awt.Paint) color5);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        try {
            xYPlot0.drawOutline(graphics2D19, rectangle2D20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("XY Plot");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        try {
            textFragment1.draw(graphics2D2, (float) 1, 1.0f, textAnchor5, (float) (byte) 10, (float) (short) 100, 10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor5);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setTranslateY((double) (short) 1);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = categoryPlot21.getDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot21.getDomainAxis((-1));
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str26 = xYPlot25.getPlotType();
        boolean boolean27 = xYPlot25.isRangeZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation28 = xYPlot25.getRangeAxisLocation();
        categoryPlot21.setDomainAxisLocation(axisLocation28);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D31 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand32 = null;
        numberAxis3D31.setMarkerBand(markerAxisBand32);
        numberAxis3D31.zoomRange(0.0d, (double) (short) 1);
        org.jfree.data.time.DateRange dateRange37 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str38 = dateRange37.toString();
        boolean boolean41 = dateRange37.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint43 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange37, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint44 = rectangleConstraint43.toUnconstrainedWidth();
        org.jfree.data.Range range45 = rectangleConstraint43.getWidthRange();
        numberAxis3D31.setDefaultAutoRange(range45);
        numberAxis3D31.resizeRange((double) 0, 0.0d);
        categoryPlot21.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D31);
        numberAxis3D31.setLowerMargin((double) (byte) 10);
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(categoryAxis22);
        org.junit.Assert.assertNull(categoryAxis24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "XY Plot" + "'", str26.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNotNull(dateRange37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str38.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint44);
        org.junit.Assert.assertNotNull(range45);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font3 = ringPlot2.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("ThreadContext", font3);
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        piePlot5.setLabelGap(0.0d);
        piePlot5.setCircular(true);
        java.awt.Shape shape10 = piePlot5.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("ThreadContext", font3, (org.jfree.chart.plot.Plot) piePlot5, false);
        float float13 = jFreeChart12.getBackgroundImageAlpha();
        org.jfree.chart.event.ChartProgressListener chartProgressListener14 = null;
        jFreeChart12.addProgressListener(chartProgressListener14);
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot();
        double double18 = piePlot17.getShadowXOffset();
        java.awt.Font font19 = piePlot17.getLabelFont();
        java.awt.Color color20 = java.awt.Color.cyan;
        org.jfree.chart.text.TextBlock textBlock21 = org.jfree.chart.text.TextUtilities.createTextBlock("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", font19, (java.awt.Paint) color20);
        java.util.List list22 = textBlock21.getLines();
        try {
            jFreeChart12.setSubtitles(list22);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.text.TextLine cannot be cast to org.jfree.chart.title.Title");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.5f + "'", float13 == 0.5f);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 4.0d + "'", double18 == 4.0d);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(textBlock21);
        org.junit.Assert.assertNotNull(list22);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) textBlockAnchor0, jFreeChart1, (int) (byte) 10, (int) (byte) 100);
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font8 = ringPlot7.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("ThreadContext", font8);
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot();
        piePlot10.setLabelGap(0.0d);
        piePlot10.setCircular(true);
        java.awt.Shape shape15 = piePlot10.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("ThreadContext", font8, (org.jfree.chart.plot.Plot) piePlot10, false);
        float float18 = jFreeChart17.getBackgroundImageAlpha();
        chartProgressEvent4.setChart(jFreeChart17);
        jFreeChart17.fireChartChanged();
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.5f + "'", float18 == 0.5f);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font3 = ringPlot2.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("ThreadContext", font3);
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        piePlot5.setLabelGap(0.0d);
        piePlot5.setCircular(true);
        java.awt.Shape shape10 = piePlot5.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("ThreadContext", font3, (org.jfree.chart.plot.Plot) piePlot5, false);
        jFreeChart12.setBorderVisible(false);
        java.awt.RenderingHints renderingHints15 = jFreeChart12.getRenderingHints();
        org.jfree.chart.title.TextTitle textTitle16 = jFreeChart12.getTitle();
        double double17 = textTitle16.getWidth();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(renderingHints15);
        org.junit.Assert.assertNotNull(textTitle16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        double double2 = numberAxis3D1.getLabelAngle();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = categoryPlot21.getDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot21.getDomainAxis((-1));
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str26 = xYPlot25.getPlotType();
        boolean boolean27 = xYPlot25.isRangeZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation28 = xYPlot25.getRangeAxisLocation();
        categoryPlot21.setDomainAxisLocation(axisLocation28);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        categoryPlot21.setRenderer(categoryItemRenderer30);
        categoryPlot21.setRangeCrosshairLockedOnData(true);
        java.awt.Color color35 = java.awt.Color.BLUE;
        java.awt.Stroke stroke36 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker37 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint) color35, stroke36);
        categoryPlot21.setOutlineStroke(stroke36);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation39 = null;
        try {
            categoryPlot21.addAnnotation(categoryAnnotation39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(categoryAxis22);
        org.junit.Assert.assertNull(categoryAxis24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "XY Plot" + "'", str26.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(stroke36);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.LEFT;
        try {
            java.awt.geom.Point2D point2D2 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_STARTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        categoryPlot21.setDomainAxis(categoryAxis22);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent24 = null;
        categoryPlot21.datasetChanged(datasetChangeEvent24);
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = xYPlot27.getRendererForDataset(xYDataset28);
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        xYPlot27.setDomainAxis(valueAxis30);
        java.awt.Color color32 = java.awt.Color.BLACK;
        float[] floatArray42 = new float[] { 0L, (short) 100, 10.0f, (short) 100, 0.0f, 1L };
        float[] floatArray43 = java.awt.Color.RGBtoHSB((int) (byte) -1, (int) '#', (int) ' ', floatArray42);
        float[] floatArray44 = color32.getRGBColorComponents(floatArray42);
        xYPlot27.setDomainGridlinePaint((java.awt.Paint) color32);
        java.awt.Color color46 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        xYPlot27.setOutlinePaint((java.awt.Paint) color46);
        java.awt.Color color50 = java.awt.Color.BLUE;
        java.awt.Stroke stroke51 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker52 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint) color50, stroke51);
        org.jfree.chart.plot.XYPlot xYPlot54 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str55 = xYPlot54.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset57 = null;
        xYPlot54.setDataset(0, xYDataset57);
        java.lang.Class<?> wildcardClass59 = xYPlot54.getClass();
        java.net.URL uRL60 = org.jfree.chart.util.ObjectUtilities.getResource("Multiple Pie Plot", (java.lang.Class) wildcardClass59);
        java.util.EventListener[] eventListenerArray61 = valueMarker52.getListeners((java.lang.Class) wildcardClass59);
        org.jfree.chart.util.Layer layer62 = null;
        xYPlot27.addRangeMarker((int) ' ', (org.jfree.chart.plot.Marker) valueMarker52, layer62);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType64 = valueMarker52.getLabelOffsetType();
        org.jfree.chart.util.Layer layer65 = null;
        try {
            boolean boolean66 = categoryPlot21.removeRangeMarker((int) (byte) 1, (org.jfree.chart.plot.Marker) valueMarker52, layer65);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(xYItemRenderer29);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(floatArray42);
        org.junit.Assert.assertNotNull(floatArray43);
        org.junit.Assert.assertNotNull(floatArray44);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "XY Plot" + "'", str55.equals("XY Plot"));
        org.junit.Assert.assertNotNull(wildcardClass59);
        org.junit.Assert.assertNull(uRL60);
        org.junit.Assert.assertNotNull(eventListenerArray61);
        org.junit.Assert.assertNotNull(lengthAdjustmentType64);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis3D1.setMarkerBand(markerAxisBand2);
        numberAxis3D1.zoomRange(0.0d, (double) (short) 1);
        org.jfree.data.time.DateRange dateRange7 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str8 = dateRange7.toString();
        boolean boolean11 = dateRange7.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange7, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = rectangleConstraint13.toUnconstrainedWidth();
        org.jfree.data.Range range15 = rectangleConstraint13.getWidthRange();
        numberAxis3D1.setDefaultAutoRange(range15);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit17 = null;
        try {
            numberAxis3D1.setTickUnit(numberTickUnit17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateRange7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str8.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint14);
        org.junit.Assert.assertNotNull(range15);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str1 = xYPlot0.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        xYPlot0.setDataset(0, xYDataset3);
        java.lang.Class<?> wildcardClass5 = xYPlot0.getClass();
        xYPlot0.setRangeZeroBaselineVisible(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        xYPlot0.zoomRangeAxes((double) 1, (double) (-165), plotRenderingInfo10, point2D11);
        double double13 = xYPlot0.getRangeCrosshairValue();
        int int14 = xYPlot0.getWeight();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "XY Plot" + "'", str1.equals("XY Plot"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str1 = xYPlot0.getPlotType();
        org.jfree.data.general.DatasetGroup datasetGroup2 = xYPlot0.getDatasetGroup();
        boolean boolean3 = xYPlot0.isRangeZeroBaselineVisible();
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = xYPlot0.getRangeMarkers((int) (byte) 1, layer5);
        boolean boolean7 = xYPlot0.isDomainZeroBaselineVisible();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "XY Plot" + "'", str1.equals("XY Plot"));
        org.junit.Assert.assertNull(datasetGroup2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str1 = xYPlot0.getPlotType();
        boolean boolean2 = xYPlot0.isDomainZeroBaselineVisible();
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font5 = ringPlot4.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("ThreadContext", font5);
        java.awt.Color color7 = java.awt.Color.BLACK;
        textTitle6.setPaint((java.awt.Paint) color7);
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color7);
        java.awt.geom.Point2D point2D10 = null;
        try {
            xYPlot0.setQuadrantOrigin(point2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'origin' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "XY Plot" + "'", str1.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace1, false);
        java.awt.Paint paint4 = xYPlot0.getOutlinePaint();
        xYPlot0.mapDatasetToDomainAxis((int) (byte) 100, (int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D12 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand13 = null;
        numberAxis3D12.setMarkerBand(markerAxisBand13);
        org.jfree.data.time.DateRange dateRange15 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str16 = dateRange15.toString();
        boolean boolean19 = dateRange15.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange15, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = rectangleConstraint21.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint24 = rectangleConstraint21.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range25 = rectangleConstraint21.getWidthRange();
        numberAxis3D12.setRangeWithMargins(range25, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) numberAxis3D12, categoryItemRenderer29);
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = categoryPlot30.getDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = categoryPlot30.getDomainAxis((-1));
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str35 = xYPlot34.getPlotType();
        boolean boolean36 = xYPlot34.isRangeZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation37 = xYPlot34.getRangeAxisLocation();
        categoryPlot30.setDomainAxisLocation(axisLocation37);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D40 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand41 = null;
        numberAxis3D40.setMarkerBand(markerAxisBand41);
        numberAxis3D40.zoomRange(0.0d, (double) (short) 1);
        org.jfree.data.time.DateRange dateRange46 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str47 = dateRange46.toString();
        boolean boolean50 = dateRange46.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint52 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange46, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint53 = rectangleConstraint52.toUnconstrainedWidth();
        org.jfree.data.Range range54 = rectangleConstraint52.getWidthRange();
        numberAxis3D40.setDefaultAutoRange(range54);
        numberAxis3D40.resizeRange((double) 0, 0.0d);
        categoryPlot30.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D40);
        try {
            xYPlot0.setRangeAxis((-16777216), (org.jfree.chart.axis.ValueAxis) numberAxis3D40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(dateRange15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str16.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint22);
        org.junit.Assert.assertNotNull(rectangleConstraint24);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNull(categoryAxis31);
        org.junit.Assert.assertNull(categoryAxis33);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "XY Plot" + "'", str35.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(dateRange46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str47.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint53);
        org.junit.Assert.assertNotNull(range54);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str1 = xYPlot0.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        xYPlot0.setDataset(0, xYDataset3);
        java.lang.Class<?> wildcardClass5 = xYPlot0.getClass();
        xYPlot0.setRangeZeroBaselineVisible(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        xYPlot0.zoomRangeAxes((double) 1, (double) (-165), plotRenderingInfo10, point2D11);
        double double13 = xYPlot0.getRangeCrosshairValue();
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D18 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand19 = null;
        numberAxis3D18.setMarkerBand(markerAxisBand19);
        org.jfree.data.time.DateRange dateRange21 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str22 = dateRange21.toString();
        boolean boolean25 = dateRange21.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint27 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange21, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint28 = rectangleConstraint27.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = rectangleConstraint27.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range31 = rectangleConstraint27.getWidthRange();
        numberAxis3D18.setRangeWithMargins(range31, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, (org.jfree.chart.axis.ValueAxis) numberAxis3D18, categoryItemRenderer35);
        numberAxis3D18.setUpperMargin(0.0d);
        try {
            xYPlot0.setDomainAxis((int) (byte) -1, (org.jfree.chart.axis.ValueAxis) numberAxis3D18, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "XY Plot" + "'", str1.equals("XY Plot"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(dateRange21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str22.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint28);
        org.junit.Assert.assertNotNull(rectangleConstraint30);
        org.junit.Assert.assertNotNull(range31);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextLine textLine2 = new org.jfree.chart.text.TextLine("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=-1.0]", font1);
        org.jfree.chart.text.TextFragment textFragment3 = null;
        textLine2.addFragment(textFragment3);
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setLabelGap(0.0d);
        piePlot0.setCircular(true);
        java.awt.Shape shape5 = piePlot0.getLegendItemShape();
        org.jfree.chart.entity.ChartEntity chartEntity8 = new org.jfree.chart.entity.ChartEntity(shape5, "hi!", "Multiple Pie Plot");
        chartEntity8.setToolTipText("Pie Plot");
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        piePlot1.setLabelGap(0.0d);
        piePlot1.setCircular(true);
        java.awt.Paint paint6 = piePlot1.getLabelShadowPaint();
        boolean boolean7 = basicProjectInfo0.equals((java.lang.Object) piePlot1);
        basicProjectInfo0.addOptionalLibrary("hi!");
        org.jfree.chart.ui.Library[] libraryArray10 = basicProjectInfo0.getOptionalLibraries();
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(libraryArray10);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        java.awt.Paint paint0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        java.lang.Comparable[] comparableArray0 = null;
        java.lang.Comparable[] comparableArray2 = new java.lang.Comparable[] { 0.025d };
        double[] doubleArray4 = new double[] { 100.0f };
        double[] doubleArray6 = new double[] { 100.0f };
        double[] doubleArray8 = new double[] { 100.0f };
        double[][] doubleArray9 = new double[][] { doubleArray4, doubleArray6, doubleArray8 };
        try {
            org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray0, comparableArray2, doubleArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowKeys' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        piePlot1.setLabelGap(0.0d);
        piePlot1.setCircular(true);
        java.awt.Paint paint6 = piePlot1.getLabelShadowPaint();
        boolean boolean7 = basicProjectInfo0.equals((java.lang.Object) piePlot1);
        piePlot1.setCircular(true);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator10 = piePlot1.getToolTipGenerator();
        piePlot1.setSectionOutlinesVisible(false);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(pieToolTipGenerator10);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis3D1.setMarkerBand(markerAxisBand2);
        numberAxis3D1.zoomRange(0.0d, (double) (short) 1);
        numberAxis3D1.setNegativeArrowVisible(false);
        org.jfree.data.Range range9 = null;
        try {
            numberAxis3D1.setRangeWithMargins(range9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis3D1.setMarkerBand(markerAxisBand2);
        numberAxis3D1.zoomRange(0.0d, (double) (short) 1);
        org.jfree.data.time.DateRange dateRange7 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str8 = dateRange7.toString();
        boolean boolean11 = dateRange7.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange7, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = rectangleConstraint13.toUnconstrainedWidth();
        org.jfree.data.Range range15 = rectangleConstraint13.getWidthRange();
        numberAxis3D1.setDefaultAutoRange(range15);
        numberAxis3D1.setTickMarkInsideLength(100.0f);
        numberAxis3D1.setUpperBound((-1.0d));
        org.junit.Assert.assertNotNull(dateRange7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str8.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint14);
        org.junit.Assert.assertNotNull(range15);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis3D1.setMarkerBand(markerAxisBand2);
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str5 = dateRange4.toString();
        boolean boolean8 = dateRange4.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = rectangleConstraint10.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint10.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range14 = rectangleConstraint10.getWidthRange();
        numberAxis3D1.setRangeWithMargins(range14, true, true);
        java.awt.Stroke stroke18 = numberAxis3D1.getTickMarkStroke();
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str5.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint11);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0", graphics2D1, (float) (-165), 0.5f, 0.0d, 10.0f, (float) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = categoryPlot21.getDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot21.getDomainAxis((-1));
        org.jfree.chart.util.Layer layer26 = null;
        java.util.Collection collection27 = categoryPlot21.getRangeMarkers((int) ' ', layer26);
        java.awt.Color color28 = java.awt.Color.BLACK;
        categoryPlot21.setRangeGridlinePaint((java.awt.Paint) color28);
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        categoryPlot21.setDomainAxis(0, categoryAxis31);
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str35 = xYPlot34.getPlotType();
        boolean boolean36 = xYPlot34.isRangeZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation37 = xYPlot34.getRangeAxisLocation();
        try {
            categoryPlot21.setDomainAxisLocation((-1), axisLocation37, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(categoryAxis22);
        org.junit.Assert.assertNull(categoryAxis24);
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "XY Plot" + "'", str35.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(axisLocation37);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            lineBorder0.draw(graphics2D1, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        java.util.ResourceBundle.clearCache();
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "hi!", "hi!", "");
        basicProjectInfo4.setVersion("Multiple Pie Plot");
        basicProjectInfo4.addOptionalLibrary("");
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setSectionDepth((double) 'a');
        java.awt.Shape shape3 = ringPlot0.getLegendItemShape();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = ringPlot0.getLegendLabelGenerator();
        ringPlot0.setSectionDepth(0.4d);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator4);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        java.awt.Color color1 = java.awt.Color.BLUE;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint) color1, stroke2);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str6 = xYPlot5.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        xYPlot5.setDataset(0, xYDataset8);
        java.lang.Class<?> wildcardClass10 = xYPlot5.getClass();
        java.net.URL uRL11 = org.jfree.chart.util.ObjectUtilities.getResource("Multiple Pie Plot", (java.lang.Class) wildcardClass10);
        java.util.EventListener[] eventListenerArray12 = valueMarker3.getListeners((java.lang.Class) wildcardClass10);
        org.jfree.chart.plot.RingPlot ringPlot13 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.Plot plot14 = ringPlot13.getRootPlot();
        valueMarker3.addChangeListener((org.jfree.chart.event.MarkerChangeListener) ringPlot13);
        org.jfree.chart.text.TextAnchor textAnchor16 = valueMarker3.getLabelTextAnchor();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "XY Plot" + "'", str6.equals("XY Plot"));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNull(uRL11);
        org.junit.Assert.assertNotNull(eventListenerArray12);
        org.junit.Assert.assertNotNull(plot14);
        org.junit.Assert.assertNotNull(textAnchor16);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis3D1.setMarkerBand(markerAxisBand2);
        java.awt.Shape shape4 = numberAxis3D1.getRightArrow();
        numberAxis3D1.setVisible(false);
        java.lang.String str7 = numberAxis3D1.getLabel();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockContainer0.getMargin();
        org.junit.Assert.assertNotNull(rectangleInsets1);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        java.util.TimeZone timeZone0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        java.lang.String str0 = org.jfree.chart.labels.StandardPieSectionLabelGenerator.DEFAULT_SECTION_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 0L };
        java.lang.Number[][] numberArray10 = new java.lang.Number[][] { numberArray3, numberArray5, numberArray7, numberArray9 };
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("VerticalAlignment.BOTTOM", "XY Plot", numberArray10);
        org.jfree.data.Range range12 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset11);
        java.lang.Number number13 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset11);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 0.0d + "'", number13.equals(0.0d));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = lineBorder0.getInsets();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            lineBorder0.draw(graphics2D2, rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        double double2 = piePlot1.getShadowXOffset();
        java.awt.Font font3 = piePlot1.getLabelFont();
        java.awt.Color color4 = java.awt.Color.cyan;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", font3, (java.awt.Paint) color4);
        java.util.List list6 = textBlock5.getLines();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        try {
            java.awt.Shape shape14 = textBlock5.calculateBounds(graphics2D7, 0.0f, (float) (-165), textBlockAnchor10, (float) (byte) -1, 0.0f, (double) 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font1 = ringPlot0.getNoDataMessageFont();
        boolean boolean3 = ringPlot0.equals((java.lang.Object) (byte) 1);
        ringPlot0.setMinimumArcAngleToDraw((double) (byte) 10);
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        boolean boolean7 = ringPlot0.equals((java.lang.Object) textAnchor6);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str1 = xYPlot0.getPlotType();
        boolean boolean2 = xYPlot0.isRangeZoomable();
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color3);
        org.jfree.chart.plot.Marker marker6 = null;
        org.jfree.chart.util.Layer layer7 = null;
        try {
            boolean boolean8 = xYPlot0.removeRangeMarker(2, marker6, layer7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "XY Plot" + "'", str1.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-165));
        java.awt.Color color3 = java.awt.Color.BLUE;
        xYPlot0.setRangeCrosshairPaint((java.awt.Paint) color3);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font1 = ringPlot0.getNoDataMessageFont();
        boolean boolean3 = ringPlot0.equals((java.lang.Object) (byte) 1);
        org.jfree.data.general.PieDataset pieDataset4 = ringPlot0.getDataset();
        double double5 = ringPlot0.getOuterSeparatorExtension();
        ringPlot0.setSimpleLabels(false);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = xYPlot8.getRendererForDataset(xYDataset9);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        xYPlot8.setDomainAxis(valueAxis11);
        java.awt.Color color13 = java.awt.Color.BLACK;
        float[] floatArray23 = new float[] { 0L, (short) 100, 10.0f, (short) 100, 0.0f, 1L };
        float[] floatArray24 = java.awt.Color.RGBtoHSB((int) (byte) -1, (int) '#', (int) ' ', floatArray23);
        float[] floatArray25 = color13.getRGBColorComponents(floatArray23);
        xYPlot8.setDomainGridlinePaint((java.awt.Paint) color13);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        xYPlot8.setOutlinePaint((java.awt.Paint) color27);
        java.awt.Color color31 = java.awt.Color.BLUE;
        java.awt.Stroke stroke32 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint) color31, stroke32);
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str36 = xYPlot35.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset38 = null;
        xYPlot35.setDataset(0, xYDataset38);
        java.lang.Class<?> wildcardClass40 = xYPlot35.getClass();
        java.net.URL uRL41 = org.jfree.chart.util.ObjectUtilities.getResource("Multiple Pie Plot", (java.lang.Class) wildcardClass40);
        java.util.EventListener[] eventListenerArray42 = valueMarker33.getListeners((java.lang.Class) wildcardClass40);
        org.jfree.chart.util.Layer layer43 = null;
        xYPlot8.addRangeMarker((int) ' ', (org.jfree.chart.plot.Marker) valueMarker33, layer43);
        org.jfree.chart.plot.RingPlot ringPlot47 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font48 = ringPlot47.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle49 = new org.jfree.chart.title.TextTitle("ThreadContext", font48);
        org.jfree.chart.plot.PiePlot piePlot50 = new org.jfree.chart.plot.PiePlot();
        piePlot50.setLabelGap(0.0d);
        piePlot50.setCircular(true);
        java.awt.Shape shape55 = piePlot50.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart57 = new org.jfree.chart.JFreeChart("ThreadContext", font48, (org.jfree.chart.plot.Plot) piePlot50, false);
        jFreeChart57.clearSubtitles();
        java.awt.Stroke stroke59 = jFreeChart57.getBorderStroke();
        valueMarker33.setOutlineStroke(stroke59);
        boolean boolean61 = ringPlot0.equals((java.lang.Object) stroke59);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(pieDataset4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertNull(xYItemRenderer10);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "XY Plot" + "'", str36.equals("XY Plot"));
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertNull(uRL41);
        org.junit.Assert.assertNotNull(eventListenerArray42);
        org.junit.Assert.assertNotNull(font48);
        org.junit.Assert.assertNotNull(shape55);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        java.awt.image.ColorModel colorModel1 = null;
        java.awt.Rectangle rectangle2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.AffineTransform affineTransform4 = null;
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font8 = ringPlot7.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("ThreadContext", font8);
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot();
        piePlot10.setLabelGap(0.0d);
        piePlot10.setCircular(true);
        java.awt.Shape shape15 = piePlot10.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("ThreadContext", font8, (org.jfree.chart.plot.Plot) piePlot10, false);
        jFreeChart17.setBorderVisible(false);
        java.awt.RenderingHints renderingHints20 = jFreeChart17.getRenderingHints();
        java.awt.PaintContext paintContext21 = color0.createContext(colorModel1, rectangle2, rectangle2D3, affineTransform4, renderingHints20);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(renderingHints20);
        org.junit.Assert.assertNotNull(paintContext21);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        java.awt.Paint paint1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = xYPlot2.getRendererForDataset(xYDataset3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        xYPlot2.setDomainAxis(valueAxis5);
        java.awt.Paint paint7 = xYPlot2.getRangeCrosshairPaint();
        java.lang.String str8 = xYPlot2.getPlotType();
        org.jfree.chart.plot.RingPlot ringPlot11 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font12 = ringPlot11.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("ThreadContext", font12);
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot();
        piePlot14.setLabelGap(0.0d);
        piePlot14.setCircular(true);
        java.awt.Shape shape19 = piePlot14.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("ThreadContext", font12, (org.jfree.chart.plot.Plot) piePlot14, false);
        jFreeChart21.clearSubtitles();
        int int23 = jFreeChart21.getSubtitleCount();
        xYPlot2.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart21);
        org.jfree.chart.title.Title title25 = null;
        jFreeChart21.removeSubtitle(title25);
        java.awt.Stroke stroke27 = jFreeChart21.getBorderStroke();
        try {
            org.jfree.chart.plot.ValueMarker valueMarker28 = new org.jfree.chart.plot.ValueMarker((double) (-165), paint1, stroke27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "XY Plot" + "'", str8.equals("XY Plot"));
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(stroke27);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = xYPlot0.getRendererForDataset(xYDataset1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        xYPlot0.setDomainAxis(valueAxis3);
        java.awt.Paint paint5 = xYPlot0.getRangeCrosshairPaint();
        java.lang.String str6 = xYPlot0.getPlotType();
        org.jfree.chart.plot.RingPlot ringPlot9 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font10 = ringPlot9.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("ThreadContext", font10);
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot();
        piePlot12.setLabelGap(0.0d);
        piePlot12.setCircular(true);
        java.awt.Shape shape17 = piePlot12.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("ThreadContext", font10, (org.jfree.chart.plot.Plot) piePlot12, false);
        jFreeChart19.clearSubtitles();
        int int21 = jFreeChart19.getSubtitleCount();
        xYPlot0.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart19);
        jFreeChart19.clearSubtitles();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo28 = null;
        try {
            java.awt.image.BufferedImage bufferedImage29 = jFreeChart19.createBufferedImage((-1), 100, (double) 500, 0.05d, chartRenderingInfo28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (-1) and height (100) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "XY Plot" + "'", str6.equals("XY Plot"));
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = xYPlot0.getRendererForDataset(xYDataset1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        xYPlot0.setDomainAxis(valueAxis3);
        java.awt.Paint paint5 = xYPlot0.getRangeCrosshairPaint();
        float float6 = xYPlot0.getBackgroundAlpha();
        org.junit.Assert.assertNull(xYItemRenderer2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder((double) 0, 4.0d, (double) '#', (double) (short) -1, (java.awt.Paint) color4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = blockBorder5.getInsets();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            rectangleInsets6.trim(rectangle2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str1 = xYPlot0.getPlotType();
        boolean boolean2 = xYPlot0.isRangeZoomable();
        int int3 = xYPlot0.getDatasetCount();
        java.awt.Color color4 = java.awt.Color.BLUE;
        xYPlot0.setRangeTickBandPaint((java.awt.Paint) color4);
        int int6 = color4.getGreen();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "XY Plot" + "'", str1.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str1 = xYPlot0.getPlotType();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxis();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset3);
        java.lang.String str5 = multiplePiePlot4.getPlotType();
        java.lang.String str6 = multiplePiePlot4.getPlotType();
        boolean boolean7 = xYPlot0.equals((java.lang.Object) str6);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = xYPlot8.getRendererForDataset(xYDataset9);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        xYPlot8.setDomainAxis(valueAxis11);
        java.awt.Color color13 = java.awt.Color.BLACK;
        float[] floatArray23 = new float[] { 0L, (short) 100, 10.0f, (short) 100, 0.0f, 1L };
        float[] floatArray24 = java.awt.Color.RGBtoHSB((int) (byte) -1, (int) '#', (int) ' ', floatArray23);
        float[] floatArray25 = color13.getRGBColorComponents(floatArray23);
        xYPlot8.setDomainGridlinePaint((java.awt.Paint) color13);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        xYPlot8.setOutlinePaint((java.awt.Paint) color27);
        org.jfree.chart.plot.PiePlot piePlot29 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier30 = piePlot29.getDrawingSupplier();
        xYPlot8.setDrawingSupplier(drawingSupplier30);
        org.jfree.chart.LegendItemCollection legendItemCollection32 = xYPlot8.getFixedLegendItems();
        java.awt.Stroke stroke33 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot8.setDomainGridlineStroke(stroke33);
        xYPlot0.setRangeCrosshairStroke(stroke33);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent36 = null;
        xYPlot0.markerChanged(markerChangeEvent36);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "XY Plot" + "'", str1.equals("XY Plot"));
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Multiple Pie Plot" + "'", str5.equals("Multiple Pie Plot"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Multiple Pie Plot" + "'", str6.equals("Multiple Pie Plot"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(xYItemRenderer10);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(drawingSupplier30);
        org.junit.Assert.assertNull(legendItemCollection32);
        org.junit.Assert.assertNotNull(stroke33);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            double double1 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        java.awt.Color color0 = java.awt.Color.BLACK;
        int int1 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font2 = ringPlot1.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("ThreadContext", font2);
        java.awt.Color color4 = java.awt.Color.BLACK;
        textTitle3.setPaint((java.awt.Paint) color4);
        java.awt.Font font6 = textTitle3.getFont();
        textTitle3.setWidth(0.0d);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = textTitle3.getHorizontalAlignment();
        java.lang.Object obj10 = textTitle3.clone();
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        try {
            textTitle3.setBounds(rectangle2D11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'bounds' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font3 = ringPlot2.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("ThreadContext", font3);
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        piePlot5.setLabelGap(0.0d);
        piePlot5.setCircular(true);
        java.awt.Shape shape10 = piePlot5.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("ThreadContext", font3, (org.jfree.chart.plot.Plot) piePlot5, false);
        jFreeChart12.setBorderVisible(false);
        jFreeChart12.removeLegend();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = categoryPlot21.getDomainAxisForDataset((-165));
        org.jfree.chart.plot.RingPlot ringPlot24 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke25 = ringPlot24.getLabelLinkStroke();
        double double26 = ringPlot24.getOuterSeparatorExtension();
        java.awt.Stroke stroke27 = ringPlot24.getBaseSectionOutlineStroke();
        categoryPlot21.setRangeGridlineStroke(stroke27);
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D33 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand34 = null;
        numberAxis3D33.setMarkerBand(markerAxisBand34);
        org.jfree.data.time.DateRange dateRange36 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str37 = dateRange36.toString();
        boolean boolean40 = dateRange36.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint42 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange36, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint43 = rectangleConstraint42.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint45 = rectangleConstraint42.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range46 = rectangleConstraint42.getWidthRange();
        numberAxis3D33.setRangeWithMargins(range46, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer50 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, (org.jfree.chart.axis.ValueAxis) numberAxis3D33, categoryItemRenderer50);
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = null;
        categoryPlot51.setDomainAxis(categoryAxis52);
        org.jfree.chart.plot.XYPlot xYPlot55 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace56 = null;
        xYPlot55.setFixedRangeAxisSpace(axisSpace56, false);
        java.awt.Paint paint59 = xYPlot55.getOutlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation61 = xYPlot55.getRangeAxisLocation((-16777216));
        categoryPlot51.setRangeAxisLocation((int) (short) 100, axisLocation61);
        try {
            categoryPlot21.setDomainAxisLocation((-16777216), axisLocation61, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(categoryAxis23);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.2d + "'", double26 == 0.2d);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(dateRange36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str37.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint43);
        org.junit.Assert.assertNotNull(rectangleConstraint45);
        org.junit.Assert.assertNotNull(range46);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertNotNull(axisLocation61);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        categoryPlot21.setDomainAxis(categoryAxis22);
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace26 = null;
        xYPlot25.setFixedRangeAxisSpace(axisSpace26, false);
        java.awt.Paint paint29 = xYPlot25.getOutlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation31 = xYPlot25.getRangeAxisLocation((-16777216));
        categoryPlot21.setRangeAxisLocation((int) (short) 100, axisLocation31);
        org.jfree.chart.axis.AxisLocation axisLocation34 = null;
        categoryPlot21.setRangeAxisLocation((int) (byte) 10, axisLocation34);
        org.jfree.chart.JFreeChart jFreeChart36 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot21);
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(axisLocation31);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setID("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=-1.0]");
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        size2D0.width = 10.0d;
        double double3 = size2D0.width;
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = xYPlot0.getRendererForDataset(xYDataset1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        xYPlot0.setDomainAxis(valueAxis3);
        java.awt.Color color5 = java.awt.Color.BLACK;
        float[] floatArray15 = new float[] { 0L, (short) 100, 10.0f, (short) 100, 0.0f, 1L };
        float[] floatArray16 = java.awt.Color.RGBtoHSB((int) (byte) -1, (int) '#', (int) ' ', floatArray15);
        float[] floatArray17 = color5.getRGBColorComponents(floatArray15);
        xYPlot0.setDomainGridlinePaint((java.awt.Paint) color5);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis20 = xYPlot0.getDomainAxisForDataset(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 2 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        java.awt.Color color1 = java.awt.Color.BLUE;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint) color1, stroke2);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str6 = xYPlot5.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        xYPlot5.setDataset(0, xYDataset8);
        java.lang.Class<?> wildcardClass10 = xYPlot5.getClass();
        java.net.URL uRL11 = org.jfree.chart.util.ObjectUtilities.getResource("Multiple Pie Plot", (java.lang.Class) wildcardClass10);
        java.util.EventListener[] eventListenerArray12 = valueMarker3.getListeners((java.lang.Class) wildcardClass10);
        java.lang.Object obj13 = valueMarker3.clone();
        java.awt.Paint paint14 = valueMarker3.getOutlinePaint();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "XY Plot" + "'", str6.equals("XY Plot"));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNull(uRL11);
        org.junit.Assert.assertNotNull(eventListenerArray12);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.Plot plot1 = ringPlot0.getRootPlot();
        org.jfree.data.general.PieDataset pieDataset2 = ringPlot0.getDataset();
        org.junit.Assert.assertNotNull(plot1);
        org.junit.Assert.assertNull(pieDataset2);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font3 = ringPlot2.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("ThreadContext", font3);
        textTitle4.setURLText("hi!");
        boolean boolean7 = lineBorder0.equals((java.lang.Object) "hi!");
        java.awt.Stroke stroke8 = lineBorder0.getStroke();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = categoryPlot21.getDomainAxisForDataset((-165));
        org.jfree.chart.plot.RingPlot ringPlot24 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke25 = ringPlot24.getLabelLinkStroke();
        double double26 = ringPlot24.getOuterSeparatorExtension();
        java.awt.Stroke stroke27 = ringPlot24.getBaseSectionOutlineStroke();
        categoryPlot21.setRangeGridlineStroke(stroke27);
        org.jfree.chart.axis.ValueAxis valueAxis30 = categoryPlot21.getRangeAxis(2);
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(categoryAxis23);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.2d + "'", double26 == 0.2d);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNull(valueAxis30);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = xYPlot0.getRendererForDataset(xYDataset1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        xYPlot0.setDomainAxis(valueAxis3);
        java.awt.Color color5 = java.awt.Color.BLACK;
        float[] floatArray15 = new float[] { 0L, (short) 100, 10.0f, (short) 100, 0.0f, 1L };
        float[] floatArray16 = java.awt.Color.RGBtoHSB((int) (byte) -1, (int) '#', (int) ' ', floatArray15);
        float[] floatArray17 = color5.getRGBColorComponents(floatArray15);
        xYPlot0.setDomainGridlinePaint((java.awt.Paint) color5);
        org.jfree.chart.axis.ValueAxis valueAxis20 = xYPlot0.getRangeAxisForDataset(0);
        boolean boolean21 = xYPlot0.isRangeZoomable();
        xYPlot0.setDomainCrosshairLockedOnData(false);
        java.awt.Color color25 = java.awt.Color.BLUE;
        java.awt.Stroke stroke26 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint) color25, stroke26);
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str30 = xYPlot29.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        xYPlot29.setDataset(0, xYDataset32);
        java.lang.Class<?> wildcardClass34 = xYPlot29.getClass();
        java.net.URL uRL35 = org.jfree.chart.util.ObjectUtilities.getResource("Multiple Pie Plot", (java.lang.Class) wildcardClass34);
        java.util.EventListener[] eventListenerArray36 = valueMarker27.getListeners((java.lang.Class) wildcardClass34);
        org.jfree.chart.text.TextAnchor textAnchor37 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        valueMarker27.setLabelTextAnchor(textAnchor37);
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker27);
        java.awt.Paint paint40 = xYPlot0.getDomainZeroBaselinePaint();
        org.junit.Assert.assertNull(xYItemRenderer2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNull(valueAxis20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "XY Plot" + "'", str30.equals("XY Plot"));
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNull(uRL35);
        org.junit.Assert.assertNotNull(eventListenerArray36);
        org.junit.Assert.assertNotNull(textAnchor37);
        org.junit.Assert.assertNotNull(paint40);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        boolean boolean2 = ringPlot1.getIgnoreZeroValues();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        piePlot5.setLabelGap(0.0d);
        piePlot5.setCircular(true);
        double double10 = piePlot5.getShadowYOffset();
        java.awt.Font font11 = piePlot5.getLabelFont();
        piePlot5.setIgnoreNullValues(true);
        boolean boolean14 = piePlot5.getSectionOutlinesVisible();
        java.awt.Stroke stroke16 = piePlot5.getSectionOutlineStroke((java.lang.Comparable) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        org.jfree.chart.plot.PiePlotState piePlotState19 = ringPlot1.initialise(graphics2D3, rectangle2D4, piePlot5, (java.lang.Integer) (-1), plotRenderingInfo18);
        java.awt.geom.Rectangle2D rectangle2D20 = piePlotState19.getExplodedPieArea();
        piePlotState19.setPieCenterX(0.4d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(stroke16);
        org.junit.Assert.assertNotNull(piePlotState19);
        org.junit.Assert.assertNull(rectangle2D20);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        int int1 = legendItemCollection0.getItemCount();
        try {
            org.jfree.chart.LegendItem legendItem3 = legendItemCollection0.get(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot();
        piePlot3.setLabelGap(0.0d);
        piePlot3.setCircular(true);
        org.jfree.chart.plot.RingPlot ringPlot10 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font11 = ringPlot10.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle("ThreadContext", font11);
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot();
        piePlot13.setLabelGap(0.0d);
        piePlot13.setCircular(true);
        java.awt.Shape shape18 = piePlot13.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("ThreadContext", font11, (org.jfree.chart.plot.Plot) piePlot13, false);
        float float21 = jFreeChart20.getBackgroundImageAlpha();
        org.jfree.chart.title.LegendTitle legendTitle23 = jFreeChart20.getLegend((int) ' ');
        java.awt.Stroke stroke24 = jFreeChart20.getBorderStroke();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo28 = null;
        java.awt.image.BufferedImage bufferedImage29 = jFreeChart20.createBufferedImage((int) '4', (int) (byte) 100, (int) (byte) 1, chartRenderingInfo28);
        piePlot3.setBackgroundImage((java.awt.Image) bufferedImage29);
        org.jfree.chart.ui.ProjectInfo projectInfo34 = new org.jfree.chart.ui.ProjectInfo("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=-1.0]", "TextAnchor.BOTTOM_RIGHT", "Pie Plot", (java.awt.Image) bufferedImage29, "", "", "TextAnchor.BOTTOM_RIGHT");
        java.awt.Image image35 = projectInfo34.getLogo();
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.5f + "'", float21 == 0.5f);
        org.junit.Assert.assertNull(legendTitle23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(bufferedImage29);
        org.junit.Assert.assertNotNull(image35);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("HorizontalAlignment.CENTER");
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        categoryPlot21.setDomainAxis(categoryAxis22);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent24 = null;
        categoryPlot21.datasetChanged(datasetChangeEvent24);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        int int27 = categoryPlot21.getIndexOf(categoryItemRenderer26);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        try {
            categoryPlot21.handleClick((int) '#', (int) (short) 1, plotRenderingInfo30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) (byte) 100, 10, (int) (byte) 1);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0L };
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] { numberArray5, numberArray7, numberArray9, numberArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("VerticalAlignment.BOTTOM", "XY Plot", numberArray12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_RIGHT", "", numberArray12);
        try {
            org.jfree.data.general.PieDataset pieDataset16 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset14, 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 15, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertNotNull(categoryDataset14);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setSectionDepth((double) 'a');
        java.awt.Shape shape3 = ringPlot0.getLegendItemShape();
        ringPlot0.setBackgroundImageAlignment((int) (short) -1);
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        ringPlot6.setSectionDepth((double) 'a');
        java.awt.Shape shape9 = ringPlot6.getLegendItemShape();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = ringPlot6.getLegendLabelGenerator();
        ringPlot0.setLegendLabelGenerator(pieSectionLabelGenerator10);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator10);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = categoryPlot21.getDomainAxisForDataset((-165));
        org.jfree.chart.plot.RingPlot ringPlot24 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke25 = ringPlot24.getLabelLinkStroke();
        double double26 = ringPlot24.getOuterSeparatorExtension();
        java.awt.Stroke stroke27 = ringPlot24.getBaseSectionOutlineStroke();
        categoryPlot21.setRangeGridlineStroke(stroke27);
        java.lang.String str29 = categoryPlot21.getPlotType();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation30 = null;
        try {
            categoryPlot21.addAnnotation(categoryAnnotation30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(categoryAxis23);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.2d + "'", double26 == 0.2d);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Category Plot" + "'", str29.equals("Category Plot"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        boolean boolean2 = ringPlot1.getIgnoreZeroValues();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        piePlot5.setLabelGap(0.0d);
        piePlot5.setCircular(true);
        double double10 = piePlot5.getShadowYOffset();
        java.awt.Font font11 = piePlot5.getLabelFont();
        piePlot5.setIgnoreNullValues(true);
        boolean boolean14 = piePlot5.getSectionOutlinesVisible();
        java.awt.Stroke stroke16 = piePlot5.getSectionOutlineStroke((java.lang.Comparable) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        org.jfree.chart.plot.PiePlotState piePlotState19 = ringPlot1.initialise(graphics2D3, rectangle2D4, piePlot5, (java.lang.Integer) (-1), plotRenderingInfo18);
        java.awt.geom.Rectangle2D rectangle2D20 = piePlotState19.getExplodedPieArea();
        double double21 = piePlotState19.getPieHRadius();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(stroke16);
        org.junit.Assert.assertNotNull(piePlotState19);
        org.junit.Assert.assertNull(rectangle2D20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
        java.lang.String str1 = licences0.getLGPL();
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        categoryPlot21.setDomainAxis(categoryAxis22);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent24 = null;
        categoryPlot21.datasetChanged(datasetChangeEvent24);
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot21.getDomainAxisLocation((int) (byte) 1);
        org.jfree.chart.plot.CategoryMarker categoryMarker28 = null;
        try {
            categoryPlot21.addDomainMarker(categoryMarker28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(axisLocation27);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        polarPlot0.setAngleTickUnit((org.jfree.chart.axis.TickUnit) dateTickUnit1);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        polarPlot0.setRenderer(polarItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.geom.Point2D point2D7 = null;
        org.jfree.chart.plot.PlotState plotState8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        try {
            polarPlot0.draw(graphics2D5, rectangle2D6, point2D7, plotState8, plotRenderingInfo9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit1);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        java.awt.Paint paint0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        int int1 = legendItemCollection0.getItemCount();
        try {
            org.jfree.chart.LegendItem legendItem3 = legendItemCollection0.get((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        java.lang.String str1 = rotation0.toString();
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Rotation.ANTICLOCKWISE" + "'", str1.equals("Rotation.ANTICLOCKWISE"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        java.awt.Color color1 = java.awt.Color.BLACK;
        java.awt.Color color2 = java.awt.Color.getColor("TextAnchor.BOTTOM_RIGHT", color1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int2 = color1.getRGB();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo3 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo3.setName("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        boolean boolean6 = color1.equals((java.lang.Object) basicProjectInfo3);
        polarPlot0.setAngleGridlinePaint((java.awt.Paint) color1);
        java.lang.Object obj8 = polarPlot0.clone();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        polarPlot0.zoomDomainAxes(10.0d, plotRenderingInfo10, point2D11);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-32640) + "'", int2 == (-32640));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis3D1.setMarkerBand(markerAxisBand2);
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str5 = dateRange4.toString();
        boolean boolean8 = dateRange4.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = rectangleConstraint10.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint10.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range14 = rectangleConstraint10.getWidthRange();
        numberAxis3D1.setRangeWithMargins(range14, true, true);
        java.awt.Stroke stroke18 = numberAxis3D1.getAxisLineStroke();
        org.jfree.data.time.DateRange dateRange19 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str20 = dateRange19.toString();
        boolean boolean23 = dateRange19.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint25 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange19, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = rectangleConstraint25.toUnconstrainedWidth();
        org.jfree.data.Range range27 = rectangleConstraint25.getWidthRange();
        numberAxis3D1.setDefaultAutoRange(range27);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str5.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint11);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(dateRange19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str20.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint26);
        org.junit.Assert.assertNotNull(range27);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double2 = dateRange0.constrain((double) (short) 10);
        org.junit.Assert.assertNotNull(dateRange0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        java.lang.Object obj1 = legendItemCollection0.clone();
        try {
            org.jfree.chart.LegendItem legendItem3 = legendItemCollection0.get((-32640));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -32640");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font3 = ringPlot2.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("ThreadContext", font3);
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        piePlot5.setLabelGap(0.0d);
        piePlot5.setCircular(true);
        java.awt.Shape shape10 = piePlot5.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("ThreadContext", font3, (org.jfree.chart.plot.Plot) piePlot5, false);
        float float13 = jFreeChart12.getBackgroundImageAlpha();
        org.jfree.chart.title.LegendTitle legendTitle15 = jFreeChart12.getLegend((int) ' ');
        java.awt.Stroke stroke16 = jFreeChart12.getBorderStroke();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = null;
        java.awt.image.BufferedImage bufferedImage21 = jFreeChart12.createBufferedImage((int) '4', (int) (byte) 100, (int) (byte) 1, chartRenderingInfo20);
        org.jfree.chart.event.ChartProgressListener chartProgressListener22 = null;
        jFreeChart12.addProgressListener(chartProgressListener22);
        try {
            org.jfree.chart.plot.XYPlot xYPlot24 = jFreeChart12.getXYPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PiePlot cannot be cast to org.jfree.chart.plot.XYPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.5f + "'", float13 == 0.5f);
        org.junit.Assert.assertNull(legendTitle15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(bufferedImage21);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setLabelGap(0.0d);
        piePlot0.setCircular(true);
        java.awt.Shape shape5 = piePlot0.getLegendItemShape();
        org.jfree.chart.entity.ChartEntity chartEntity8 = new org.jfree.chart.entity.ChartEntity(shape5, "hi!", "Multiple Pie Plot");
        java.lang.String str9 = chartEntity8.getToolTipText();
        java.awt.Shape shape10 = chartEntity8.getArea();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font2 = ringPlot1.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("ThreadContext", font2);
        org.jfree.chart.block.BlockFrame blockFrame4 = textTitle3.getFrame();
        org.jfree.chart.block.LineBorder lineBorder5 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = lineBorder5.getInsets();
        double double8 = rectangleInsets6.calculateRightInset((double) 0.5f);
        textTitle3.setPadding(rectangleInsets6);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        textTitle3.setPaint((java.awt.Paint) color10);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(blockFrame4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str1 = dateRange0.toString();
        boolean boolean4 = dateRange0.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange0, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = rectangleConstraint6.toUnconstrainedWidth();
        org.jfree.data.Range range8 = rectangleConstraint6.getWidthRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = rectangleConstraint6.toUnconstrainedWidth();
        double double10 = rectangleConstraint9.getWidth();
        org.junit.Assert.assertNotNull(dateRange0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str1.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint7);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(rectangleConstraint9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font2 = ringPlot1.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("ThreadContext", font2);
        java.awt.Color color4 = java.awt.Color.BLACK;
        textTitle3.setPaint((java.awt.Paint) color4);
        java.awt.Font font6 = textTitle3.getFont();
        java.awt.Paint paint7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        textTitle3.setBackgroundPaint(paint7);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand11 = null;
        numberAxis3D10.setMarkerBand(markerAxisBand11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = numberAxis3D10.getTickLabelInsets();
        textTitle3.setMargin(rectangleInsets13);
        org.jfree.chart.block.BlockFrame blockFrame15 = textTitle3.getFrame();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(blockFrame15);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        float float22 = numberAxis3D3.getTickMarkInsideLength();
        numberAxis3D3.setVisible(false);
        numberAxis3D3.setFixedDimension(4.0d);
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.0f + "'", float22 == 0.0f);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str1 = xYPlot0.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        xYPlot0.setDataset(0, xYDataset3);
        java.lang.Class<?> wildcardClass5 = xYPlot0.getClass();
        xYPlot0.setRangeZeroBaselineVisible(true);
        java.lang.String str8 = xYPlot0.getNoDataMessage();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        xYPlot0.zoomDomainAxes((double) 500, plotRenderingInfo10, point2D11, false);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "XY Plot" + "'", str1.equals("XY Plot"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        java.lang.String str4 = textAnchor3.toString();
        try {
            float float5 = textFragment1.calculateBaselineOffset(graphics2D2, textAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TextAnchor.BOTTOM_RIGHT" + "'", str4.equals("TextAnchor.BOTTOM_RIGHT"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setLabelGap(0.0d);
        piePlot0.setCircular(true);
        java.awt.Shape shape5 = piePlot0.getLegendItemShape();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = piePlot0.getLegendItems();
        org.jfree.chart.LegendItem legendItem7 = null;
        legendItemCollection6.add(legendItem7);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(legendItemCollection6);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation1);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font1 = ringPlot0.getNoDataMessageFont();
        boolean boolean3 = ringPlot0.equals((java.lang.Object) (byte) 1);
        ringPlot0.setMinimumArcAngleToDraw((double) (byte) 10);
        boolean boolean6 = ringPlot0.getSeparatorsVisible();
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        try {
            ringPlot0.drawBackground(graphics2D7, rectangle2D8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        ringPlot1.setDataset(pieDataset2);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.clear();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            java.lang.Object obj5 = blockContainer0.draw(graphics2D2, rectangle2D3, (java.lang.Object) "ChartChangeEventType.DATASET_UPDATED");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace2 = null;
        xYPlot1.setFixedRangeAxisSpace(axisSpace2, false);
        java.awt.Paint paint5 = xYPlot1.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) xYPlot1);
        float float7 = xYPlot1.getBackgroundAlpha();
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot();
        java.awt.Color color9 = java.awt.Color.MAGENTA;
        piePlot8.setBackgroundPaint((java.awt.Paint) color9);
        xYPlot1.setDomainCrosshairPaint((java.awt.Paint) color9);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 0L };
        java.lang.Number[][] numberArray10 = new java.lang.Number[][] { numberArray3, numberArray5, numberArray7, numberArray9 };
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("VerticalAlignment.BOTTOM", "XY Plot", numberArray10);
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset11, false);
        java.lang.Number number14 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset11);
        try {
            java.lang.Number number15 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 0.0d + "'", number14.equals(0.0d));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setLabelGap(0.0d);
        piePlot0.setCircular(true);
        java.awt.Shape shape5 = piePlot0.getLegendItemShape();
        org.jfree.chart.entity.ChartEntity chartEntity8 = new org.jfree.chart.entity.ChartEntity(shape5, "hi!", "Multiple Pie Plot");
        java.lang.String str9 = chartEntity8.getToolTipText();
        java.lang.Object obj10 = chartEntity8.clone();
        java.lang.String str11 = chartEntity8.getShapeType();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "poly" + "'", str11.equals("poly"));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        piePlot1.setLabelGap(0.0d);
        piePlot1.setCircular(true);
        java.awt.Paint paint6 = piePlot1.getLabelShadowPaint();
        boolean boolean7 = basicProjectInfo0.equals((java.lang.Object) piePlot1);
        basicProjectInfo0.addOptionalLibrary("TextBlockAnchor.TOP_LEFT");
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font2 = ringPlot1.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("ThreadContext", font2);
        java.awt.Color color4 = java.awt.Color.BLACK;
        textTitle3.setPaint((java.awt.Paint) color4);
        java.awt.Font font6 = textTitle3.getFont();
        textTitle3.setWidth(0.0d);
        textTitle3.setURLText("TextBlockAnchor.BOTTOM_CENTER");
        java.lang.Object obj11 = textTitle3.clone();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str1 = xYPlot0.getPlotType();
        boolean boolean2 = xYPlot0.isDomainZeroBaselineVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = xYPlot0.getDomainAxisEdge((-32640));
        boolean boolean5 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge4);
        boolean boolean6 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "XY Plot" + "'", str1.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        int int2 = categoryAxis3D1.getCategoryLabelPositionOffset();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = xYPlot0.getRendererForDataset(xYDataset1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        xYPlot0.setDomainAxis(valueAxis3);
        xYPlot0.clearRangeMarkers();
        java.awt.Stroke stroke6 = xYPlot0.getDomainGridlineStroke();
        xYPlot0.clearDomainMarkers((int) (byte) 100);
        java.awt.Color color11 = java.awt.Color.BLUE;
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint) color11, stroke12);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str16 = xYPlot15.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        xYPlot15.setDataset(0, xYDataset18);
        java.lang.Class<?> wildcardClass20 = xYPlot15.getClass();
        java.net.URL uRL21 = org.jfree.chart.util.ObjectUtilities.getResource("Multiple Pie Plot", (java.lang.Class) wildcardClass20);
        java.util.EventListener[] eventListenerArray22 = valueMarker13.getListeners((java.lang.Class) wildcardClass20);
        java.lang.Object obj23 = valueMarker13.clone();
        org.jfree.chart.util.Layer layer24 = null;
        try {
            boolean boolean25 = xYPlot0.removeDomainMarker(2, (org.jfree.chart.plot.Marker) valueMarker13, layer24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer2);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "XY Plot" + "'", str16.equals("XY Plot"));
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNull(uRL21);
        org.junit.Assert.assertNotNull(eventListenerArray22);
        org.junit.Assert.assertNotNull(obj23);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setTranslateY((double) (short) 0);
        blockParams0.setGenerateEntities(false);
        boolean boolean5 = blockParams0.getGenerateEntities();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace1, false);
        java.awt.Paint paint4 = xYPlot0.getOutlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation6 = xYPlot0.getRangeAxisLocation((-16777216));
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        org.jfree.chart.plot.CrosshairState crosshairState11 = null;
        boolean boolean12 = xYPlot0.render(graphics2D7, rectangle2D8, (int) (short) 10, plotRenderingInfo10, crosshairState11);
        xYPlot0.clearDomainMarkers((int) ' ');
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis3D1.setMarkerBand(markerAxisBand2);
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str5 = dateRange4.toString();
        boolean boolean8 = dateRange4.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = rectangleConstraint10.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint10.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range14 = rectangleConstraint10.getWidthRange();
        numberAxis3D1.setRangeWithMargins(range14, true, true);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit18 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis3D1.setTickUnit(numberTickUnit18, false, true);
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot();
        piePlot22.setLabelGap(0.0d);
        piePlot22.setCircular(true);
        java.awt.Shape shape27 = piePlot22.getLegendItemShape();
        org.jfree.chart.entity.ChartEntity chartEntity30 = new org.jfree.chart.entity.ChartEntity(shape27, "hi!", "Multiple Pie Plot");
        numberAxis3D1.setRightArrow(shape27);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str5.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint11);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(numberTickUnit18);
        org.junit.Assert.assertNotNull(shape27);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, 1.0E-5d, (double) (short) 1, (int) (short) 10, (java.lang.Comparable) "TextAnchor.BOTTOM_RIGHT");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot(pieDataset1);
        ringPlot2.setShadowYOffset((double) 100L);
        java.awt.Paint paint5 = ringPlot2.getLabelPaint();
        boolean boolean6 = textAnchor0.equals((java.lang.Object) ringPlot2);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font2 = ringPlot1.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("ThreadContext", font2);
        double double4 = textTitle3.getHeight();
        textTitle3.setPadding(100.0d, 0.0d, 0.4d, (double) 15);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        ringPlot1.setShadowYOffset((double) 100L);
        java.awt.Paint paint4 = ringPlot1.getLabelPaint();
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot6 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset5);
        java.lang.String str7 = multiplePiePlot6.getPlotType();
        java.lang.String str8 = multiplePiePlot6.getPlotType();
        boolean boolean9 = ringPlot1.equals((java.lang.Object) str8);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Multiple Pie Plot" + "'", str7.equals("Multiple Pie Plot"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Multiple Pie Plot" + "'", str8.equals("Multiple Pie Plot"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str1 = xYPlot0.getPlotType();
        boolean boolean2 = xYPlot0.isDomainZeroBaselineVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = xYPlot0.getDomainAxisEdge((-32640));
        org.jfree.chart.axis.ValueAxis valueAxis5 = xYPlot0.getRangeAxis();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "XY Plot" + "'", str1.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNull(valueAxis5);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font3 = ringPlot2.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("ThreadContext", font3);
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        piePlot5.setLabelGap(0.0d);
        piePlot5.setCircular(true);
        java.awt.Shape shape10 = piePlot5.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("ThreadContext", font3, (org.jfree.chart.plot.Plot) piePlot5, false);
        float float13 = jFreeChart12.getBackgroundImageAlpha();
        org.jfree.chart.title.LegendTitle legendTitle15 = jFreeChart12.getLegend((int) ' ');
        org.jfree.chart.event.ChartChangeListener chartChangeListener16 = null;
        try {
            jFreeChart12.addChangeListener(chartChangeListener16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.5f + "'", float13 == 0.5f);
        org.junit.Assert.assertNull(legendTitle15);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        double double2 = piePlot1.getShadowXOffset();
        java.awt.Font font3 = piePlot1.getLabelFont();
        java.awt.Color color5 = java.awt.Color.BLUE;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint) color5, stroke6);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str10 = xYPlot9.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        xYPlot9.setDataset(0, xYDataset12);
        java.lang.Class<?> wildcardClass14 = xYPlot9.getClass();
        java.net.URL uRL15 = org.jfree.chart.util.ObjectUtilities.getResource("Multiple Pie Plot", (java.lang.Class) wildcardClass14);
        java.util.EventListener[] eventListenerArray16 = valueMarker7.getListeners((java.lang.Class) wildcardClass14);
        java.awt.Paint paint17 = valueMarker7.getLabelPaint();
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str19 = xYPlot18.getPlotType();
        boolean boolean20 = xYPlot18.isRangeZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot18.getRangeAxisLocation();
        org.jfree.chart.LegendItemCollection legendItemCollection22 = xYPlot18.getLegendItems();
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = xYPlot18.getRangeAxisEdge(0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment25 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment26 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        java.lang.String str27 = verticalAlignment26.toString();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = new org.jfree.chart.util.RectangleInsets();
        double double29 = rectangleInsets28.getBottom();
        double double31 = rectangleInsets28.trimWidth((double) 1.0f);
        try {
            org.jfree.chart.title.TextTitle textTitle32 = new org.jfree.chart.title.TextTitle("Category Plot", font3, paint17, rectangleEdge24, horizontalAlignment25, verticalAlignment26, rectangleInsets28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'horizontalAlignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "XY Plot" + "'", str10.equals("XY Plot"));
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNull(uRL15);
        org.junit.Assert.assertNotNull(eventListenerArray16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "XY Plot" + "'", str19.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNotNull(legendItemCollection22);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertNotNull(verticalAlignment26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "VerticalAlignment.BOTTOM" + "'", str27.equals("VerticalAlignment.BOTTOM"));
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + (-1.0d) + "'", double31 == (-1.0d));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = xYPlot0.getRendererForDataset(xYDataset1);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.util.List list5 = null;
        xYPlot0.drawDomainTickBands(graphics2D3, rectangle2D4, list5);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        xYPlot0.setRenderer(xYItemRenderer7);
        xYPlot0.setDomainCrosshairLockedOnData(false);
        org.junit.Assert.assertNull(xYItemRenderer2);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis3D1.setMarkerBand(markerAxisBand2);
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str5 = dateRange4.toString();
        boolean boolean8 = dateRange4.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = rectangleConstraint10.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint10.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range14 = rectangleConstraint10.getWidthRange();
        numberAxis3D1.setRangeWithMargins(range14, true, true);
        boolean boolean18 = numberAxis3D1.isTickLabelsVisible();
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str20 = xYPlot19.getPlotType();
        boolean boolean21 = xYPlot19.isRangeZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation22 = xYPlot19.getRangeAxisLocation();
        boolean boolean23 = numberAxis3D1.equals((java.lang.Object) xYPlot19);
        java.lang.Number[] numberArray27 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { 0L };
        java.lang.Number[][] numberArray34 = new java.lang.Number[][] { numberArray27, numberArray29, numberArray31, numberArray33 };
        org.jfree.data.category.CategoryDataset categoryDataset35 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("VerticalAlignment.BOTTOM", "XY Plot", numberArray34);
        org.jfree.data.Range range37 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset35, false);
        org.jfree.data.Range range39 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset35, (double) ' ');
        numberAxis3D1.setRange(range39);
        java.awt.Paint paint41 = numberAxis3D1.getLabelPaint();
        java.awt.Graphics2D graphics2D42 = null;
        org.jfree.chart.axis.AxisState axisState43 = null;
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        org.jfree.chart.plot.XYPlot xYPlot45 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace46 = null;
        xYPlot45.setFixedRangeAxisSpace(axisSpace46, false);
        java.awt.Paint paint49 = xYPlot45.getOutlinePaint();
        xYPlot45.mapDatasetToDomainAxis((int) (byte) 100, (int) (short) -1);
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = xYPlot45.getDomainAxisEdge(4);
        try {
            java.util.List list55 = numberAxis3D1.refreshTicks(graphics2D42, axisState43, rectangle2D44, rectangleEdge54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str5.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint11);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "XY Plot" + "'", str20.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(categoryDataset35);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(rectangleEdge54);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double1 = rectangleInsets0.getBottom();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = rectangleInsets0.createOutsetRectangle(rectangle2D2, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        numberAxis3D3.setUpperBound((double) (byte) 0);
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = xYPlot0.getRendererForDataset(xYDataset1);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.util.List list5 = null;
        xYPlot0.drawDomainTickBands(graphics2D3, rectangle2D4, list5);
        xYPlot0.zoom(0.0d);
        java.awt.Color color10 = java.awt.Color.BLUE;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint) color10, stroke11);
        java.awt.Font font13 = valueMarker12.getLabelFont();
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker12);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent15 = null;
        xYPlot0.rendererChanged(rendererChangeEvent15);
        java.awt.Color color18 = java.awt.Color.BLUE;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint) color18, stroke19);
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str23 = xYPlot22.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        xYPlot22.setDataset(0, xYDataset25);
        java.lang.Class<?> wildcardClass27 = xYPlot22.getClass();
        java.net.URL uRL28 = org.jfree.chart.util.ObjectUtilities.getResource("Multiple Pie Plot", (java.lang.Class) wildcardClass27);
        java.util.EventListener[] eventListenerArray29 = valueMarker20.getListeners((java.lang.Class) wildcardClass27);
        org.jfree.chart.text.TextAnchor textAnchor30 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        valueMarker20.setLabelTextAnchor(textAnchor30);
        java.awt.Paint paint32 = valueMarker20.getLabelPaint();
        java.awt.Color color33 = java.awt.Color.MAGENTA;
        valueMarker20.setOutlinePaint((java.awt.Paint) color33);
        xYPlot0.setDomainCrosshairPaint((java.awt.Paint) color33);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = null;
        java.awt.geom.Point2D point2D38 = null;
        xYPlot0.zoomRangeAxes((double) 3, plotRenderingInfo37, point2D38);
        org.junit.Assert.assertNull(xYItemRenderer2);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "XY Plot" + "'", str23.equals("XY Plot"));
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNull(uRL28);
        org.junit.Assert.assertNotNull(eventListenerArray29);
        org.junit.Assert.assertNotNull(textAnchor30);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(color33);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.TOP" + "'", str1.equals("RectangleAnchor.TOP"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis3D1.setMarkerBand(markerAxisBand2);
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str5 = dateRange4.toString();
        boolean boolean8 = dateRange4.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = rectangleConstraint10.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint10.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range14 = rectangleConstraint10.getWidthRange();
        numberAxis3D1.setRangeWithMargins(range14, true, true);
        java.awt.Stroke stroke18 = numberAxis3D1.getAxisLineStroke();
        org.jfree.chart.axis.TickUnitSource tickUnitSource19 = numberAxis3D1.getStandardTickUnits();
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str5.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint11);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(tickUnitSource19);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font1 = ringPlot0.getNoDataMessageFont();
        double double2 = ringPlot0.getInnerSeparatorExtension();
        boolean boolean3 = ringPlot0.getIgnoreNullValues();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = categoryPlot21.getDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot21.getDomainAxis((-1));
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str26 = xYPlot25.getPlotType();
        boolean boolean27 = xYPlot25.isRangeZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation28 = xYPlot25.getRangeAxisLocation();
        categoryPlot21.setDomainAxisLocation(axisLocation28);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        categoryPlot21.setRenderer(categoryItemRenderer30);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        java.awt.geom.Point2D point2D34 = null;
        categoryPlot21.zoomDomainAxes((double) 10.0f, plotRenderingInfo33, point2D34);
        java.awt.Stroke stroke36 = categoryPlot21.getRangeCrosshairStroke();
        categoryPlot21.clearRangeMarkers((int) ' ');
        int int39 = categoryPlot21.getWeight();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D42 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        categoryAxis3D42.setMaximumCategoryLabelWidthRatio((float) 'a');
        try {
            categoryPlot21.setDomainAxis((-165), (org.jfree.chart.axis.CategoryAxis) categoryAxis3D42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(categoryAxis22);
        org.junit.Assert.assertNull(categoryAxis24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "XY Plot" + "'", str26.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace1, false);
        java.awt.Paint paint4 = xYPlot0.getOutlinePaint();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint6 = defaultDrawingSupplier5.getNextFillPaint();
        java.awt.Stroke stroke7 = defaultDrawingSupplier5.getNextOutlineStroke();
        xYPlot0.setDomainCrosshairStroke(stroke7);
        java.awt.Stroke stroke9 = xYPlot0.getRangeZeroBaselineStroke();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str1 = xYPlot0.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        xYPlot0.setDataset(0, xYDataset3);
        java.lang.Class<?> wildcardClass5 = xYPlot0.getClass();
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font9 = ringPlot8.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("ThreadContext", font9);
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot();
        piePlot11.setLabelGap(0.0d);
        piePlot11.setCircular(true);
        java.awt.Shape shape16 = piePlot11.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("ThreadContext", font9, (org.jfree.chart.plot.Plot) piePlot11, false);
        jFreeChart18.clearSubtitles();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType20 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent21 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYPlot0, jFreeChart18, chartChangeEventType20);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType22 = null;
        chartChangeEvent21.setType(chartChangeEventType22);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "XY Plot" + "'", str1.equals("XY Plot"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(shape16);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        java.text.NumberFormat numberFormat1 = null;
        java.text.NumberFormat numberFormat2 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("HorizontalAlignment.CENTER", numberFormat1, numberFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'numberFormat' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = xYPlot2.getRendererForDataset(xYDataset3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        xYPlot2.setDomainAxis(valueAxis5);
        java.awt.Color color7 = java.awt.Color.BLACK;
        float[] floatArray17 = new float[] { 0L, (short) 100, 10.0f, (short) 100, 0.0f, 1L };
        float[] floatArray18 = java.awt.Color.RGBtoHSB((int) (byte) -1, (int) '#', (int) ' ', floatArray17);
        float[] floatArray19 = color7.getRGBColorComponents(floatArray17);
        xYPlot2.setDomainGridlinePaint((java.awt.Paint) color7);
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        xYPlot2.setOutlinePaint((java.awt.Paint) color21);
        org.jfree.chart.text.TextMeasurer textMeasurer24 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock25 = org.jfree.chart.text.TextUtilities.createTextBlock("{0}", font1, (java.awt.Paint) color21, (float) (byte) 1, textMeasurer24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(xYItemRenderer4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(color21);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("HorizontalAlignment.CENTER", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.Plot plot1 = ringPlot0.getRootPlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor2 = ringPlot0.getLabelDistributor();
        double double3 = ringPlot0.getLabelGap();
        org.junit.Assert.assertNotNull(plot1);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.025d + "'", double3 == 0.025d);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        categoryPlot21.setDomainAxis(categoryAxis22);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent24 = null;
        categoryPlot21.datasetChanged(datasetChangeEvent24);
        org.jfree.chart.util.Layer layer27 = null;
        java.util.Collection collection28 = categoryPlot21.getDomainMarkers((int) 'a', layer27);
        categoryPlot21.setRangeCrosshairVisible(true);
        org.jfree.chart.plot.CategoryMarker categoryMarker31 = null;
        org.jfree.chart.util.Layer layer32 = null;
        try {
            categoryPlot21.addDomainMarker(categoryMarker31, layer32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(collection28);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        categoryAxis3D1.setMaximumCategoryLabelWidthRatio((float) 'a');
        java.lang.String str4 = categoryAxis3D1.getLabel();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        categoryPlot21.setDomainAxis(categoryAxis22);
        java.util.List list24 = categoryPlot21.getCategories();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent25 = null;
        categoryPlot21.datasetChanged(datasetChangeEvent25);
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(list24);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        float[] floatArray13 = new float[] { 0L, (short) 100, 10.0f, (short) 100, 0.0f, 1L };
        float[] floatArray14 = java.awt.Color.RGBtoHSB((int) (byte) -1, (int) '#', (int) ' ', floatArray13);
        float[] floatArray15 = color3.getComponents(floatArray14);
        float[] floatArray16 = java.awt.Color.RGBtoHSB(4, (int) (short) 1, 2, floatArray15);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace1, false);
        java.awt.Paint paint4 = xYPlot0.getOutlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation6 = xYPlot0.getRangeAxisLocation((-16777216));
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        org.jfree.chart.plot.CrosshairState crosshairState11 = null;
        boolean boolean12 = xYPlot0.render(graphics2D7, rectangle2D8, (int) (short) 10, plotRenderingInfo10, crosshairState11);
        float float13 = xYPlot0.getForegroundAlpha();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker((double) (-1), (java.awt.Paint) color16, stroke17);
        org.jfree.chart.util.Layer layer19 = null;
        try {
            boolean boolean20 = xYPlot0.removeDomainMarker((int) (short) 100, (org.jfree.chart.plot.Marker) valueMarker18, layer19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 1.0f + "'", float13 == 1.0f);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis3D1.setMarkerBand(markerAxisBand2);
        numberAxis3D1.zoomRange(0.0d, (double) (short) 1);
        org.jfree.data.time.DateRange dateRange7 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str8 = dateRange7.toString();
        boolean boolean11 = dateRange7.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange7, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = rectangleConstraint13.toUnconstrainedWidth();
        org.jfree.data.Range range15 = rectangleConstraint13.getWidthRange();
        numberAxis3D1.setDefaultAutoRange(range15);
        numberAxis3D1.centerRange(0.0d);
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace20 = null;
        xYPlot19.setFixedRangeAxisSpace(axisSpace20, false);
        java.awt.Paint paint23 = xYPlot19.getOutlinePaint();
        xYPlot19.mapDatasetToDomainAxis((int) (byte) 100, (int) (short) -1);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = xYPlot19.getDomainAxisEdge(4);
        numberAxis3D1.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot19);
        org.junit.Assert.assertNotNull(dateRange7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str8.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint14);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(rectangleEdge28);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis3D1.setMarkerBand(markerAxisBand2);
        numberAxis3D1.zoomRange(0.0d, (double) (short) 1);
        org.jfree.data.time.DateRange dateRange7 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str8 = dateRange7.toString();
        boolean boolean11 = dateRange7.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange7, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = rectangleConstraint13.toUnconstrainedWidth();
        org.jfree.data.Range range15 = rectangleConstraint13.getWidthRange();
        numberAxis3D1.setDefaultAutoRange(range15);
        numberAxis3D1.setLabel("Category Plot");
        org.junit.Assert.assertNotNull(dateRange7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str8.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint14);
        org.junit.Assert.assertNotNull(range15);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.Range range0 = null;
        org.jfree.data.time.DateRange dateRange1 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str2 = dateRange1.toString();
        boolean boolean5 = dateRange1.intersects(1.0d, (double) (short) 100);
        org.jfree.data.Range range6 = org.jfree.data.Range.combine(range0, (org.jfree.data.Range) dateRange1);
        org.junit.Assert.assertNotNull(dateRange1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str2.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(range6);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 0L };
        java.lang.Number[][] numberArray10 = new java.lang.Number[][] { numberArray3, numberArray5, numberArray7, numberArray9 };
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("VerticalAlignment.BOTTOM", "XY Plot", numberArray10);
        org.jfree.data.Range range12 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D14 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D18 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand19 = null;
        numberAxis3D18.setMarkerBand(markerAxisBand19);
        org.jfree.data.time.DateRange dateRange21 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str22 = dateRange21.toString();
        boolean boolean25 = dateRange21.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint27 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange21, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint28 = rectangleConstraint27.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = rectangleConstraint27.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range31 = rectangleConstraint27.getWidthRange();
        numberAxis3D18.setRangeWithMargins(range31, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, (org.jfree.chart.axis.ValueAxis) numberAxis3D18, categoryItemRenderer35);
        numberAxis3D18.setUpperMargin(0.0d);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D14, (org.jfree.chart.axis.ValueAxis) numberAxis3D18, categoryItemRenderer39);
        java.awt.Paint paint41 = numberAxis3D18.getLabelPaint();
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertNotNull(dateRange21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str22.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint28);
        org.junit.Assert.assertNotNull(rectangleConstraint30);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNotNull(paint41);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) textBlockAnchor0, jFreeChart1, (int) (byte) 10, (int) (byte) 100);
        chartProgressEvent4.setType(0);
        int int7 = chartProgressEvent4.getPercent();
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setLabelGap(0.0d);
        piePlot0.setCircular(true);
        java.awt.Shape shape5 = piePlot0.getLegendItemShape();
        org.jfree.chart.entity.ChartEntity chartEntity8 = new org.jfree.chart.entity.ChartEntity(shape5, "hi!", "Multiple Pie Plot");
        java.lang.String str9 = chartEntity8.getToolTipText();
        org.jfree.chart.plot.RingPlot ringPlot10 = new org.jfree.chart.plot.RingPlot();
        ringPlot10.setSectionDepth((double) 'a');
        java.awt.Shape shape13 = ringPlot10.getLegendItemShape();
        chartEntity8.setArea(shape13);
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator15 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator16 = null;
        try {
            java.lang.String str17 = chartEntity8.getImageMapAreaTag(toolTipTagFragmentGenerator15, uRLTagFragmentGenerator16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertNotNull(shape13);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) (byte) -1, (-1.0d));
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = categoryPlot21.getDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot21.getDomainAxis((-1));
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str26 = xYPlot25.getPlotType();
        boolean boolean27 = xYPlot25.isRangeZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation28 = xYPlot25.getRangeAxisLocation();
        categoryPlot21.setDomainAxisLocation(axisLocation28);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        categoryPlot21.setRenderer(categoryItemRenderer30);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        java.awt.geom.Point2D point2D34 = null;
        categoryPlot21.zoomDomainAxes((double) 10.0f, plotRenderingInfo33, point2D34);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = null;
        java.awt.geom.Point2D point2D38 = null;
        categoryPlot21.zoomDomainAxes((double) 0.0f, plotRenderingInfo37, point2D38);
        java.awt.Paint paint40 = categoryPlot21.getDomainGridlinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier41 = categoryPlot21.getDrawingSupplier();
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(categoryAxis22);
        org.junit.Assert.assertNull(categoryAxis24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "XY Plot" + "'", str26.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(drawingSupplier41);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str1 = xYPlot0.getPlotType();
        boolean boolean2 = xYPlot0.isDomainZeroBaselineVisible();
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font5 = ringPlot4.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("ThreadContext", font5);
        java.awt.Color color7 = java.awt.Color.BLACK;
        textTitle6.setPaint((java.awt.Paint) color7);
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color7);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder10 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.Layer layer14 = null;
        try {
            boolean boolean15 = xYPlot0.removeRangeMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) valueMarker13, layer14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "XY Plot" + "'", str1.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(datasetRenderingOrder10);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis3D1.setMarkerBand(markerAxisBand2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = numberAxis3D1.getTickLabelInsets();
        boolean boolean5 = numberAxis3D1.isAxisLineVisible();
        numberAxis3D1.setTickLabelsVisible(false);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = categoryPlot21.getDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot21.getDomainAxis((-1));
        org.jfree.chart.util.Layer layer26 = null;
        java.util.Collection collection27 = categoryPlot21.getRangeMarkers((int) ' ', layer26);
        java.awt.Color color28 = java.awt.Color.BLACK;
        categoryPlot21.setRangeGridlinePaint((java.awt.Paint) color28);
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        categoryPlot21.setDomainAxis(0, categoryAxis31);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = categoryPlot21.getDomainAxisEdge();
        int int34 = categoryPlot21.getRangeAxisCount();
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(categoryAxis22);
        org.junit.Assert.assertNull(categoryAxis24);
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        try {
            java.lang.Object obj2 = jFreeChartResources0.getObject("ThreadContext");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key ThreadContext");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font2 = ringPlot1.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("ThreadContext", font2);
        textTitle3.setURLText("hi!");
        double double6 = textTitle3.getContentXOffset();
        double double7 = textTitle3.getContentXOffset();
        textTitle3.setID("Pie Plot");
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        java.awt.Color color0 = java.awt.Color.green;
        float[] floatArray13 = new float[] { 0L, (short) 100, 10.0f, (short) 100, 0.0f, 1L };
        float[] floatArray14 = java.awt.Color.RGBtoHSB((int) (byte) -1, (int) '#', (int) ' ', floatArray13);
        float[] floatArray15 = java.awt.Color.RGBtoHSB((int) (short) 0, 0, (int) (short) 100, floatArray13);
        float[] floatArray16 = color0.getComponents(floatArray15);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "hi!", "hi!", "");
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        java.lang.Object obj6 = piePlot5.clone();
        boolean boolean7 = basicProjectInfo4.equals((java.lang.Object) piePlot5);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = piePlot5.getLabelPadding();
        java.awt.Paint paint9 = piePlot5.getBaseSectionPaint();
        java.awt.Color color10 = java.awt.Color.BLACK;
        piePlot5.setShadowPaint((java.awt.Paint) color10);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font3 = ringPlot2.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("ThreadContext", font3);
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        piePlot5.setLabelGap(0.0d);
        piePlot5.setCircular(true);
        java.awt.Shape shape10 = piePlot5.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("ThreadContext", font3, (org.jfree.chart.plot.Plot) piePlot5, false);
        org.jfree.chart.plot.Plot plot13 = piePlot5.getParent();
        java.awt.Paint paint14 = piePlot5.getLabelPaint();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNull(plot13);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font3 = ringPlot2.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("ThreadContext", font3);
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        piePlot5.setLabelGap(0.0d);
        piePlot5.setCircular(true);
        java.awt.Shape shape10 = piePlot5.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("ThreadContext", font3, (org.jfree.chart.plot.Plot) piePlot5, false);
        jFreeChart12.setBorderVisible(false);
        org.jfree.chart.title.LegendTitle legendTitle15 = jFreeChart12.getLegend();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNull(legendTitle15);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str4 = dateRange3.toString();
        boolean boolean7 = dateRange3.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange3, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = rectangleConstraint9.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = rectangleConstraint9.toFixedWidth((double) 0.0f);
        org.jfree.chart.util.Size2D size2D13 = columnArrangement0.arrange(blockContainer1, graphics2D2, rectangleConstraint12);
        double double14 = size2D13.getWidth();
        org.junit.Assert.assertNotNull(dateRange3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str4.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint10);
        org.junit.Assert.assertNotNull(rectangleConstraint12);
        org.junit.Assert.assertNotNull(size2D13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font1 = ringPlot0.getNoDataMessageFont();
        boolean boolean3 = ringPlot0.equals((java.lang.Object) (byte) 1);
        ringPlot0.setMinimumArcAngleToDraw((double) (byte) 10);
        boolean boolean6 = ringPlot0.getLabelLinksVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = ringPlot0.getLegendItems();
        java.awt.Paint paint8 = ringPlot0.getOutlinePaint();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str1 = xYPlot0.getPlotType();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand7 = null;
        numberAxis3D6.setMarkerBand(markerAxisBand7);
        org.jfree.data.time.DateRange dateRange9 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str10 = dateRange9.toString();
        boolean boolean13 = dateRange9.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange9, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = rectangleConstraint15.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = rectangleConstraint15.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range19 = rectangleConstraint15.getWidthRange();
        numberAxis3D6.setRangeWithMargins(range19, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) numberAxis3D6, categoryItemRenderer23);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = categoryPlot24.getDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = categoryPlot24.getDomainAxis((-1));
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str29 = xYPlot28.getPlotType();
        boolean boolean30 = xYPlot28.isRangeZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation31 = xYPlot28.getRangeAxisLocation();
        categoryPlot24.setDomainAxisLocation(axisLocation31);
        try {
            xYPlot0.setDomainAxisLocation((-1), axisLocation31, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "XY Plot" + "'", str1.equals("XY Plot"));
        org.junit.Assert.assertNotNull(dateRange9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str10.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint16);
        org.junit.Assert.assertNotNull(rectangleConstraint18);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNull(categoryAxis25);
        org.junit.Assert.assertNull(categoryAxis27);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "XY Plot" + "'", str29.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(axisLocation31);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(0);
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke3 = ringPlot2.getLabelLinkStroke();
        double double4 = ringPlot2.getOuterSeparatorExtension();
        java.awt.Stroke stroke5 = ringPlot2.getBaseSectionOutlineStroke();
        double double6 = ringPlot2.getLabelGap();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        ringPlot2.setSectionPaint((java.lang.Comparable) 10, (java.awt.Paint) color8);
        int int10 = objectList1.indexOf((java.lang.Object) color8);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.025d + "'", double6 == 0.025d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke1 = ringPlot0.getLabelLinkStroke();
        double double2 = ringPlot0.getOuterSeparatorExtension();
        java.awt.Stroke stroke3 = ringPlot0.getBaseSectionOutlineStroke();
        double double4 = ringPlot0.getLabelGap();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor5 = ringPlot0.getLabelDistributor();
        int int6 = abstractPieLabelDistributor5.getItemCount();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.025d + "'", double4 == 0.025d);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) textBlockAnchor0, jFreeChart1, (int) (byte) 10, (int) (byte) 100);
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font8 = ringPlot7.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("ThreadContext", font8);
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot();
        piePlot10.setLabelGap(0.0d);
        piePlot10.setCircular(true);
        java.awt.Shape shape15 = piePlot10.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("ThreadContext", font8, (org.jfree.chart.plot.Plot) piePlot10, false);
        float float18 = jFreeChart17.getBackgroundImageAlpha();
        chartProgressEvent4.setChart(jFreeChart17);
        java.util.List list20 = jFreeChart17.getSubtitles();
        jFreeChart17.clearSubtitles();
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.5f + "'", float18 == 0.5f);
        org.junit.Assert.assertNotNull(list20);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setLabelGap(0.0d);
        java.awt.Paint paint4 = piePlot0.getSectionPaint((java.lang.Comparable) (byte) 100);
        double double6 = piePlot0.getExplodePercent((java.lang.Comparable) (byte) 100);
        java.awt.Font font7 = piePlot0.getNoDataMessageFont();
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(font7);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        size2D0.height = 10L;
        size2D0.setHeight(0.0d);
        double double5 = size2D0.width;
        java.lang.Object obj6 = size2D0.clone();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Font font2 = textFragment1.getFont();
        java.awt.Font font3 = textFragment1.getFont();
        float float4 = textFragment1.getBaselineOffset();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis3D1.setMarkerBand(markerAxisBand2);
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str5 = dateRange4.toString();
        boolean boolean8 = dateRange4.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = rectangleConstraint10.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint10.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range14 = rectangleConstraint10.getWidthRange();
        numberAxis3D1.setRangeWithMargins(range14, true, true);
        numberAxis3D1.setAutoRangeMinimumSize((double) 10, false);
        numberAxis3D1.setAxisLineVisible(false);
        boolean boolean23 = numberAxis3D1.isVisible();
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str5.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint11);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = categoryPlot21.getDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot21.getDomainAxis((-1));
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str26 = xYPlot25.getPlotType();
        boolean boolean27 = xYPlot25.isRangeZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation28 = xYPlot25.getRangeAxisLocation();
        categoryPlot21.setDomainAxisLocation(axisLocation28);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        categoryPlot21.setRenderer(categoryItemRenderer30);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        java.awt.geom.Point2D point2D34 = null;
        categoryPlot21.zoomDomainAxes((double) 10.0f, plotRenderingInfo33, point2D34);
        java.awt.Stroke stroke36 = categoryPlot21.getRangeCrosshairStroke();
        categoryPlot21.clearRangeMarkers((int) ' ');
        categoryPlot21.setAnchorValue((double) 500, true);
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(categoryAxis22);
        org.junit.Assert.assertNull(categoryAxis24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "XY Plot" + "'", str26.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNotNull(stroke36);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        java.awt.Color color1 = java.awt.Color.BLUE;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint) color1, stroke2);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str6 = xYPlot5.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        xYPlot5.setDataset(0, xYDataset8);
        java.lang.Class<?> wildcardClass10 = xYPlot5.getClass();
        java.net.URL uRL11 = org.jfree.chart.util.ObjectUtilities.getResource("Multiple Pie Plot", (java.lang.Class) wildcardClass10);
        java.util.EventListener[] eventListenerArray12 = valueMarker3.getListeners((java.lang.Class) wildcardClass10);
        java.lang.Object obj13 = valueMarker3.clone();
        double double14 = valueMarker3.getValue();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "XY Plot" + "'", str6.equals("XY Plot"));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNull(uRL11);
        org.junit.Assert.assertNotNull(eventListenerArray12);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 10.0d + "'", double14 == 10.0d);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace2 = null;
        xYPlot1.setFixedRangeAxisSpace(axisSpace2, false);
        java.awt.Paint paint5 = xYPlot1.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) xYPlot1);
        float float7 = xYPlot1.getBackgroundAlpha();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder8 = xYPlot1.getSeriesRenderingOrder();
        java.util.List list9 = xYPlot1.getAnnotations();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertNotNull(seriesRenderingOrder8);
        org.junit.Assert.assertNotNull(list9);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str1 = xYPlot0.getPlotType();
        boolean boolean2 = xYPlot0.isDomainZeroBaselineVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = xYPlot0.getDomainAxisEdge((-32640));
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "XY Plot" + "'", str1.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(rectangleEdge5);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int2 = color1.getRGB();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo3 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo3.setName("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        boolean boolean6 = color1.equals((java.lang.Object) basicProjectInfo3);
        polarPlot0.setAngleGridlinePaint((java.awt.Paint) color1);
        java.lang.Object obj8 = polarPlot0.clone();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        try {
            polarPlot0.zoomRangeAxes((double) ' ', plotRenderingInfo10, point2D11, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-32640) + "'", int2 == (-32640));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str1 = dateRange0.toString();
        boolean boolean4 = dateRange0.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange0, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = rectangleConstraint6.toUnconstrainedWidth();
        org.jfree.data.Range range8 = rectangleConstraint6.getWidthRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = rectangleConstraint6.toFixedHeight(1.0E-5d);
        org.jfree.data.Range range11 = rectangleConstraint6.getHeightRange();
        org.junit.Assert.assertNotNull(dateRange0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str1.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint7);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(rectangleConstraint10);
        org.junit.Assert.assertNull(range11);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis3D1.setMarkerBand(markerAxisBand2);
        java.awt.Shape shape4 = numberAxis3D1.getRightArrow();
        org.jfree.data.Range range5 = numberAxis3D1.getRange();
        org.jfree.data.Range range7 = org.jfree.data.Range.expandToInclude(range5, 100.0d);
        double double8 = range5.getLength();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement0.clear();
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        size2D0.height = 10L;
        size2D0.setHeight(0.0d);
        size2D0.width = 'a';
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("Multiple Pie Plot");
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis3D1.setMarkerBand(markerAxisBand2);
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str5 = dateRange4.toString();
        boolean boolean8 = dateRange4.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = rectangleConstraint10.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint10.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range14 = rectangleConstraint10.getWidthRange();
        numberAxis3D1.setRangeWithMargins(range14, true, true);
        numberAxis3D1.setAutoRangeMinimumSize((double) 10, false);
        numberAxis3D1.setFixedAutoRange(0.0d);
        numberAxis3D1.setLowerBound((double) (short) -1);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str5.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint11);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(range14);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(0);
        java.lang.Object obj3 = objectList1.get(0);
        int int4 = objectList1.size();
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = xYPlot0.getRendererForDataset(xYDataset1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        xYPlot0.setDomainAxis(valueAxis3);
        java.awt.Color color5 = java.awt.Color.BLACK;
        float[] floatArray15 = new float[] { 0L, (short) 100, 10.0f, (short) 100, 0.0f, 1L };
        float[] floatArray16 = java.awt.Color.RGBtoHSB((int) (byte) -1, (int) '#', (int) ' ', floatArray15);
        float[] floatArray17 = color5.getRGBColorComponents(floatArray15);
        xYPlot0.setDomainGridlinePaint((java.awt.Paint) color5);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        xYPlot0.setOutlinePaint((java.awt.Paint) color19);
        org.jfree.chart.plot.PiePlot piePlot21 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier22 = piePlot21.getDrawingSupplier();
        xYPlot0.setDrawingSupplier(drawingSupplier22);
        org.jfree.chart.LegendItemCollection legendItemCollection24 = xYPlot0.getFixedLegendItems();
        org.jfree.chart.axis.AxisLocation axisLocation25 = null;
        try {
            xYPlot0.setRangeAxisLocation(axisLocation25, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(drawingSupplier22);
        org.junit.Assert.assertNull(legendItemCollection24);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis3D1.setMarkerBand(markerAxisBand2);
        java.awt.Shape shape4 = numberAxis3D1.getRightArrow();
        double double5 = numberAxis3D1.getFixedDimension();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = xYPlot0.getRendererForDataset(xYDataset1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        xYPlot0.setDomainAxis(valueAxis3);
        java.awt.Color color5 = java.awt.Color.BLACK;
        float[] floatArray15 = new float[] { 0L, (short) 100, 10.0f, (short) 100, 0.0f, 1L };
        float[] floatArray16 = java.awt.Color.RGBtoHSB((int) (byte) -1, (int) '#', (int) ' ', floatArray15);
        float[] floatArray17 = color5.getRGBColorComponents(floatArray15);
        xYPlot0.setDomainGridlinePaint((java.awt.Paint) color5);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        xYPlot0.setOutlinePaint((java.awt.Paint) color19);
        java.awt.Color color23 = java.awt.Color.BLUE;
        java.awt.Stroke stroke24 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint) color23, stroke24);
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str28 = xYPlot27.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        xYPlot27.setDataset(0, xYDataset30);
        java.lang.Class<?> wildcardClass32 = xYPlot27.getClass();
        java.net.URL uRL33 = org.jfree.chart.util.ObjectUtilities.getResource("Multiple Pie Plot", (java.lang.Class) wildcardClass32);
        java.util.EventListener[] eventListenerArray34 = valueMarker25.getListeners((java.lang.Class) wildcardClass32);
        org.jfree.chart.util.Layer layer35 = null;
        xYPlot0.addRangeMarker((int) ' ', (org.jfree.chart.plot.Marker) valueMarker25, layer35);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType37 = valueMarker25.getLabelOffsetType();
        valueMarker25.setLabel("");
        org.junit.Assert.assertNull(xYItemRenderer2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "XY Plot" + "'", str28.equals("XY Plot"));
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNull(uRL33);
        org.junit.Assert.assertNotNull(eventListenerArray34);
        org.junit.Assert.assertNotNull(lengthAdjustmentType37);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setLabelGap(0.0d);
        piePlot0.setCircular(true);
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font8 = ringPlot7.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("ThreadContext", font8);
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot();
        piePlot10.setLabelGap(0.0d);
        piePlot10.setCircular(true);
        java.awt.Shape shape15 = piePlot10.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("ThreadContext", font8, (org.jfree.chart.plot.Plot) piePlot10, false);
        float float18 = jFreeChart17.getBackgroundImageAlpha();
        org.jfree.chart.title.LegendTitle legendTitle20 = jFreeChart17.getLegend((int) ' ');
        java.awt.Stroke stroke21 = jFreeChart17.getBorderStroke();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo25 = null;
        java.awt.image.BufferedImage bufferedImage26 = jFreeChart17.createBufferedImage((int) '4', (int) (byte) 100, (int) (byte) 1, chartRenderingInfo25);
        piePlot0.setBackgroundImage((java.awt.Image) bufferedImage26);
        try {
            piePlot0.setBackgroundImageAlpha((-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.5f + "'", float18 == 0.5f);
        org.junit.Assert.assertNull(legendTitle20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(bufferedImage26);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font2 = ringPlot1.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("ThreadContext", font2);
        org.jfree.chart.block.BlockFrame blockFrame4 = textTitle3.getFrame();
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = textTitle3.getVerticalAlignment();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(blockFrame4);
        org.junit.Assert.assertNotNull(verticalAlignment5);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke1 = ringPlot0.getLabelLinkStroke();
        double double2 = ringPlot0.getOuterSeparatorExtension();
        java.awt.Stroke stroke3 = ringPlot0.getBaseSectionOutlineStroke();
        double double4 = ringPlot0.getLabelGap();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        ringPlot0.setSectionPaint((java.lang.Comparable) 10, (java.awt.Paint) color6);
        java.awt.Color color8 = color6.darker();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.025d + "'", double4 == 0.025d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) textBlockAnchor0, jFreeChart1, (int) (byte) 10, (int) (byte) 100);
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font8 = ringPlot7.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("ThreadContext", font8);
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot();
        piePlot10.setLabelGap(0.0d);
        piePlot10.setCircular(true);
        java.awt.Shape shape15 = piePlot10.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("ThreadContext", font8, (org.jfree.chart.plot.Plot) piePlot10, false);
        float float18 = jFreeChart17.getBackgroundImageAlpha();
        chartProgressEvent4.setChart(jFreeChart17);
        java.util.List list20 = jFreeChart17.getSubtitles();
        java.awt.Image image21 = jFreeChart17.getBackgroundImage();
        try {
            java.awt.image.BufferedImage bufferedImage24 = jFreeChart17.createBufferedImage((int) (byte) 0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (0) and height (-1) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.5f + "'", float18 == 0.5f);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertNull(image21);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis3D1.setMarkerBand(markerAxisBand2);
        numberAxis3D1.zoomRange(0.0d, (double) (short) 1);
        org.jfree.data.time.DateRange dateRange7 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str8 = dateRange7.toString();
        boolean boolean11 = dateRange7.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange7, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = rectangleConstraint13.toUnconstrainedWidth();
        org.jfree.data.Range range15 = rectangleConstraint13.getWidthRange();
        numberAxis3D1.setDefaultAutoRange(range15);
        numberAxis3D1.setTickMarkInsideLength(100.0f);
        numberAxis3D1.setFixedAutoRange(0.0d);
        org.junit.Assert.assertNotNull(dateRange7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str8.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint14);
        org.junit.Assert.assertNotNull(range15);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        boolean boolean2 = ringPlot1.getIgnoreZeroValues();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        piePlot5.setLabelGap(0.0d);
        piePlot5.setCircular(true);
        double double10 = piePlot5.getShadowYOffset();
        java.awt.Font font11 = piePlot5.getLabelFont();
        piePlot5.setIgnoreNullValues(true);
        boolean boolean14 = piePlot5.getSectionOutlinesVisible();
        java.awt.Stroke stroke16 = piePlot5.getSectionOutlineStroke((java.lang.Comparable) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        org.jfree.chart.plot.PiePlotState piePlotState19 = ringPlot1.initialise(graphics2D3, rectangle2D4, piePlot5, (java.lang.Integer) (-1), plotRenderingInfo18);
        piePlotState19.setPieCenterX(1.0d);
        piePlotState19.setTotal((double) 10.0f);
        double double24 = piePlotState19.getPieCenterY();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = piePlotState19.getInfo();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(stroke16);
        org.junit.Assert.assertNotNull(piePlotState19);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNull(plotRenderingInfo25);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = categoryPlot21.getDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot21.getDomainAxis((-1));
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str26 = xYPlot25.getPlotType();
        boolean boolean27 = xYPlot25.isRangeZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation28 = xYPlot25.getRangeAxisLocation();
        categoryPlot21.setDomainAxisLocation(axisLocation28);
        org.jfree.chart.axis.AxisSpace axisSpace30 = null;
        categoryPlot21.setFixedDomainAxisSpace(axisSpace30);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D33 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand34 = null;
        numberAxis3D33.setMarkerBand(markerAxisBand34);
        java.awt.Shape shape36 = numberAxis3D33.getRightArrow();
        numberAxis3D33.setVisible(false);
        org.jfree.data.Range range39 = categoryPlot21.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D33);
        java.awt.Paint paint40 = categoryPlot21.getRangeGridlinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = categoryPlot21.getAxisOffset();
        org.jfree.chart.plot.CategoryMarker categoryMarker42 = null;
        try {
            categoryPlot21.addDomainMarker(categoryMarker42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(categoryAxis22);
        org.junit.Assert.assertNull(categoryAxis24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "XY Plot" + "'", str26.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNull(range39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(rectangleInsets41);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        boolean boolean2 = ringPlot1.getIgnoreZeroValues();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        piePlot5.setLabelGap(0.0d);
        piePlot5.setCircular(true);
        double double10 = piePlot5.getShadowYOffset();
        java.awt.Font font11 = piePlot5.getLabelFont();
        piePlot5.setIgnoreNullValues(true);
        boolean boolean14 = piePlot5.getSectionOutlinesVisible();
        java.awt.Stroke stroke16 = piePlot5.getSectionOutlineStroke((java.lang.Comparable) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        org.jfree.chart.plot.PiePlotState piePlotState19 = ringPlot1.initialise(graphics2D3, rectangle2D4, piePlot5, (java.lang.Integer) (-1), plotRenderingInfo18);
        java.awt.Color color20 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        piePlot5.setLabelLinkPaint((java.awt.Paint) color20);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(stroke16);
        org.junit.Assert.assertNotNull(piePlotState19);
        org.junit.Assert.assertNotNull(color20);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("HorizontalAlignment.CENTER", "RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=-1.0]");
        java.lang.String str3 = contributor2.getName();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "HorizontalAlignment.CENTER" + "'", str3.equals("HorizontalAlignment.CENTER"));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis3D1.setMarkerBand(markerAxisBand2);
        numberAxis3D1.zoomRange(0.0d, (double) (short) 1);
        org.jfree.data.time.DateRange dateRange7 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str8 = dateRange7.toString();
        boolean boolean11 = dateRange7.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange7, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = rectangleConstraint13.toUnconstrainedWidth();
        org.jfree.data.Range range15 = rectangleConstraint13.getWidthRange();
        numberAxis3D1.setDefaultAutoRange(range15);
        numberAxis3D1.resizeRange((double) (byte) 100, (double) 15);
        java.awt.Shape shape20 = numberAxis3D1.getRightArrow();
        org.junit.Assert.assertNotNull(dateRange7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str8.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint14);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNotNull(shape20);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, 0.0d, 35.0d, (double) 15);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray27 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0L };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray25, numberArray27, numberArray29, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("VerticalAlignment.BOTTOM", "XY Plot", numberArray32);
        org.jfree.data.Range range35 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset33, false);
        java.lang.Number number36 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset33);
        categoryPlot21.setDataset(categoryDataset33);
        categoryPlot21.mapDatasetToRangeAxis((int) (byte) 100, 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = null;
        java.awt.geom.Point2D point2D43 = null;
        categoryPlot21.zoomDomainAxes((double) '#', plotRenderingInfo42, point2D43);
        categoryPlot21.zoom((double) (byte) -1);
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertTrue("'" + number36 + "' != '" + 0.0d + "'", number36.equals(0.0d));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = xYPlot0.getRendererForDataset(xYDataset1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        xYPlot0.setDomainAxis(valueAxis3);
        java.awt.Paint paint5 = xYPlot0.getRangeCrosshairPaint();
        java.lang.String str6 = xYPlot0.getPlotType();
        boolean boolean7 = xYPlot0.isDomainZeroBaselineVisible();
        org.junit.Assert.assertNull(xYItemRenderer2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "XY Plot" + "'", str6.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = categoryPlot21.getDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot21.getDomainAxis((-1));
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str26 = xYPlot25.getPlotType();
        boolean boolean27 = xYPlot25.isRangeZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation28 = xYPlot25.getRangeAxisLocation();
        categoryPlot21.setDomainAxisLocation(axisLocation28);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D31 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand32 = null;
        numberAxis3D31.setMarkerBand(markerAxisBand32);
        numberAxis3D31.zoomRange(0.0d, (double) (short) 1);
        org.jfree.data.time.DateRange dateRange37 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str38 = dateRange37.toString();
        boolean boolean41 = dateRange37.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint43 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange37, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint44 = rectangleConstraint43.toUnconstrainedWidth();
        org.jfree.data.Range range45 = rectangleConstraint43.getWidthRange();
        numberAxis3D31.setDefaultAutoRange(range45);
        numberAxis3D31.resizeRange((double) 0, 0.0d);
        categoryPlot21.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D31);
        java.awt.Paint paint51 = categoryPlot21.getRangeCrosshairPaint();
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(categoryAxis22);
        org.junit.Assert.assertNull(categoryAxis24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "XY Plot" + "'", str26.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNotNull(dateRange37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str38.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint44);
        org.junit.Assert.assertNotNull(range45);
        org.junit.Assert.assertNotNull(paint51);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0L };
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] { numberArray5, numberArray7, numberArray9, numberArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("VerticalAlignment.BOTTOM", "XY Plot", numberArray12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_RIGHT", "", numberArray12);
        java.lang.Number number15 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset14);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertNotNull(categoryDataset14);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 0.0d + "'", number15.equals(0.0d));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        categoryPlot21.setDomainAxis(categoryAxis22);
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace26 = null;
        xYPlot25.setFixedRangeAxisSpace(axisSpace26, false);
        java.awt.Paint paint29 = xYPlot25.getOutlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation31 = xYPlot25.getRangeAxisLocation((-16777216));
        categoryPlot21.setRangeAxisLocation((int) (short) 100, axisLocation31);
        org.jfree.data.category.CategoryDataset categoryDataset33 = categoryPlot21.getDataset();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        java.awt.geom.Point2D point2D36 = null;
        try {
            categoryPlot21.zoomRangeAxes((double) (-16777216), plotRenderingInfo35, point2D36, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNull(categoryDataset33);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace2 = null;
        xYPlot1.setFixedRangeAxisSpace(axisSpace2, false);
        java.awt.Paint paint5 = xYPlot1.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) xYPlot1);
        float float7 = xYPlot1.getBackgroundAlpha();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder8 = xYPlot1.getSeriesRenderingOrder();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D12 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand13 = null;
        numberAxis3D12.setMarkerBand(markerAxisBand13);
        org.jfree.data.time.DateRange dateRange15 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str16 = dateRange15.toString();
        boolean boolean19 = dateRange15.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange15, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = rectangleConstraint21.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint24 = rectangleConstraint21.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range25 = rectangleConstraint21.getWidthRange();
        numberAxis3D12.setRangeWithMargins(range25, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) numberAxis3D12, categoryItemRenderer29);
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = categoryPlot30.getDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = categoryPlot30.getDomainAxis((-1));
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str35 = xYPlot34.getPlotType();
        boolean boolean36 = xYPlot34.isRangeZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation37 = xYPlot34.getRangeAxisLocation();
        categoryPlot30.setDomainAxisLocation(axisLocation37);
        org.jfree.chart.axis.AxisSpace axisSpace39 = null;
        categoryPlot30.setFixedDomainAxisSpace(axisSpace39);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D42 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand43 = null;
        numberAxis3D42.setMarkerBand(markerAxisBand43);
        java.awt.Shape shape45 = numberAxis3D42.getRightArrow();
        numberAxis3D42.setVisible(false);
        org.jfree.data.Range range48 = categoryPlot30.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D42);
        java.awt.Graphics2D graphics2D49 = null;
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str51 = xYPlot50.getPlotType();
        xYPlot50.mapDatasetToRangeAxis((int) (short) -1, 0);
        org.jfree.chart.block.LineBorder lineBorder55 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets56 = lineBorder55.getInsets();
        double double58 = rectangleInsets56.calculateRightInset((double) 0.5f);
        xYPlot50.setInsets(rectangleInsets56, true);
        java.awt.geom.Rectangle2D rectangle2D61 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge62 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean63 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge62);
        org.jfree.chart.axis.AxisSpace axisSpace64 = null;
        org.jfree.chart.axis.AxisSpace axisSpace65 = numberAxis3D42.reserveSpace(graphics2D49, (org.jfree.chart.plot.Plot) xYPlot50, rectangle2D61, rectangleEdge62, axisSpace64);
        xYPlot1.setFixedRangeAxisSpace(axisSpace64);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertNotNull(seriesRenderingOrder8);
        org.junit.Assert.assertNotNull(dateRange15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str16.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint22);
        org.junit.Assert.assertNotNull(rectangleConstraint24);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNull(categoryAxis31);
        org.junit.Assert.assertNull(categoryAxis33);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "XY Plot" + "'", str35.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(shape45);
        org.junit.Assert.assertNull(range48);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "XY Plot" + "'", str51.equals("XY Plot"));
        org.junit.Assert.assertNotNull(rectangleInsets56);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 1.0d + "'", double58 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleEdge62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(axisSpace65);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke1 = ringPlot0.getLabelLinkStroke();
        ringPlot0.setInnerSeparatorExtension((double) (byte) 0);
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) textBlockAnchor0, jFreeChart1, (int) (byte) 10, (int) (byte) 100);
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font8 = ringPlot7.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("ThreadContext", font8);
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot();
        piePlot10.setLabelGap(0.0d);
        piePlot10.setCircular(true);
        java.awt.Shape shape15 = piePlot10.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("ThreadContext", font8, (org.jfree.chart.plot.Plot) piePlot10, false);
        float float18 = jFreeChart17.getBackgroundImageAlpha();
        chartProgressEvent4.setChart(jFreeChart17);
        java.util.List list20 = jFreeChart17.getSubtitles();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D22 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand23 = null;
        numberAxis3D22.setMarkerBand(markerAxisBand23);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = numberAxis3D22.getTickLabelInsets();
        org.jfree.chart.plot.RingPlot ringPlot26 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font27 = ringPlot26.getNoDataMessageFont();
        boolean boolean29 = ringPlot26.equals((java.lang.Object) (byte) 1);
        org.jfree.data.general.PieDataset pieDataset30 = ringPlot26.getDataset();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator31 = null;
        ringPlot26.setLabelGenerator(pieSectionLabelGenerator31);
        boolean boolean33 = rectangleInsets25.equals((java.lang.Object) pieSectionLabelGenerator31);
        jFreeChart17.setPadding(rectangleInsets25);
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.5f + "'", float18 == 0.5f);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(pieDataset30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        piePlot1.setLabelGap(0.0d);
        piePlot1.setCircular(true);
        java.awt.Paint paint6 = piePlot1.getLabelShadowPaint();
        boolean boolean7 = basicProjectInfo0.equals((java.lang.Object) piePlot1);
        java.lang.String str8 = basicProjectInfo0.getVersion();
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = xYPlot0.getRendererForDataset(xYDataset1);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.util.List list5 = null;
        xYPlot0.drawDomainTickBands(graphics2D3, rectangle2D4, list5);
        xYPlot0.zoom(0.0d);
        java.awt.Color color10 = java.awt.Color.BLUE;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint) color10, stroke11);
        java.awt.Font font13 = valueMarker12.getLabelFont();
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker12);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = valueMarker12.getLabelOffset();
        java.awt.Paint paint16 = valueMarker12.getOutlinePaint();
        org.junit.Assert.assertNull(xYItemRenderer2);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace1, false);
        java.awt.Paint paint4 = xYPlot0.getOutlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation6 = xYPlot0.getRangeAxisLocation((-16777216));
        int int7 = xYPlot0.getDatasetCount();
        boolean boolean8 = xYPlot0.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis3D1.setMarkerBand(markerAxisBand2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = numberAxis3D1.getTickLabelInsets();
        boolean boolean5 = numberAxis3D1.isVisible();
        boolean boolean6 = numberAxis3D1.isInverted();
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        java.lang.Comparable[] comparableArray3 = new java.lang.Comparable[] { 15, "hi!", 1.0E-8d };
        java.lang.Comparable[] comparableArray6 = new java.lang.Comparable[] { 1.0E-8d, '4' };
        double[] doubleArray12 = new double[] { (short) 10, '4', 500, 255, 1.0d };
        double[] doubleArray18 = new double[] { (short) 10, '4', 500, 255, 1.0d };
        double[] doubleArray24 = new double[] { (short) 10, '4', 500, 255, 1.0d };
        double[] doubleArray30 = new double[] { (short) 10, '4', 500, 255, 1.0d };
        double[][] doubleArray31 = new double[][] { doubleArray12, doubleArray18, doubleArray24, doubleArray30 };
        try {
            org.jfree.data.category.CategoryDataset categoryDataset32 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray3, comparableArray6, doubleArray31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of row keys does not match the number of rows in the data array.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray3);
        org.junit.Assert.assertNotNull(comparableArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int2 = color1.getRGB();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo3 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo3.setName("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        boolean boolean6 = color1.equals((java.lang.Object) basicProjectInfo3);
        polarPlot0.setAngleGridlinePaint((java.awt.Paint) color1);
        java.lang.Object obj8 = polarPlot0.clone();
        java.lang.Object obj9 = polarPlot0.clone();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        try {
            polarPlot0.zoomRangeAxes(1.0E-5d, (double) 'a', plotRenderingInfo12, point2D13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-32640) + "'", int2 == (-32640));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        java.awt.Color color0 = java.awt.Color.GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str1 = xYPlot0.getPlotType();
        org.jfree.data.general.DatasetGroup datasetGroup2 = xYPlot0.getDatasetGroup();
        boolean boolean3 = xYPlot0.isRangeZeroBaselineVisible();
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = xYPlot0.getRangeMarkers((int) (byte) 1, layer5);
        xYPlot0.mapDatasetToRangeAxis((-32640), (int) (byte) 10);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = xYPlot10.getRendererForDataset(xYDataset11);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        xYPlot10.setDomainAxis(valueAxis13);
        java.awt.Color color15 = java.awt.Color.BLACK;
        float[] floatArray25 = new float[] { 0L, (short) 100, 10.0f, (short) 100, 0.0f, 1L };
        float[] floatArray26 = java.awt.Color.RGBtoHSB((int) (byte) -1, (int) '#', (int) ' ', floatArray25);
        float[] floatArray27 = color15.getRGBColorComponents(floatArray25);
        xYPlot10.setDomainGridlinePaint((java.awt.Paint) color15);
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        xYPlot10.setOutlinePaint((java.awt.Paint) color29);
        java.awt.Color color33 = java.awt.Color.BLUE;
        java.awt.Stroke stroke34 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker35 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint) color33, stroke34);
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str38 = xYPlot37.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset40 = null;
        xYPlot37.setDataset(0, xYDataset40);
        java.lang.Class<?> wildcardClass42 = xYPlot37.getClass();
        java.net.URL uRL43 = org.jfree.chart.util.ObjectUtilities.getResource("Multiple Pie Plot", (java.lang.Class) wildcardClass42);
        java.util.EventListener[] eventListenerArray44 = valueMarker35.getListeners((java.lang.Class) wildcardClass42);
        org.jfree.chart.util.Layer layer45 = null;
        xYPlot10.addRangeMarker((int) ' ', (org.jfree.chart.plot.Marker) valueMarker35, layer45);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType47 = valueMarker35.getLabelOffsetType();
        try {
            boolean boolean48 = xYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "XY Plot" + "'", str1.equals("XY Plot"));
        org.junit.Assert.assertNull(datasetGroup2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertNull(xYItemRenderer12);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "XY Plot" + "'", str38.equals("XY Plot"));
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertNull(uRL43);
        org.junit.Assert.assertNotNull(eventListenerArray44);
        org.junit.Assert.assertNotNull(lengthAdjustmentType47);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("HorizontalAlignment.CENTER", graphics2D1, (float) (-16777216), (float) (-165), textAnchor4, 0.08d, (float) (-1), 0.5f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.BOTTOM_CENTER");
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("XY Plot", "TextBlockAnchor.BOTTOM_CENTER");
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        double double1 = blockParams0.getTranslateX();
        double double2 = blockParams0.getTranslateX();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
        blockContainer1.clear();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str5 = dateRange4.toString();
        boolean boolean8 = dateRange4.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = rectangleConstraint10.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint10.toFixedWidth((double) 0.0f);
        org.jfree.chart.util.Size2D size2D14 = flowArrangement0.arrange(blockContainer1, graphics2D3, rectangleConstraint10);
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        xYPlot16.setFixedRangeAxisSpace(axisSpace17, false);
        java.awt.Paint paint20 = xYPlot16.getOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) xYPlot16);
        float float22 = xYPlot16.getBackgroundAlpha();
        java.awt.Paint paint23 = xYPlot16.getRangeTickBandPaint();
        boolean boolean24 = flowArrangement0.equals((java.lang.Object) paint23);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str5.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint11);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(size2D14);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 1.0f + "'", float22 == 1.0f);
        org.junit.Assert.assertNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(xYDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("{0}", "TextBlockAnchor.BOTTOM_CENTER", "", "hi!");
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font3 = ringPlot2.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("ThreadContext", font3);
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        piePlot5.setLabelGap(0.0d);
        piePlot5.setCircular(true);
        java.awt.Shape shape10 = piePlot5.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("ThreadContext", font3, (org.jfree.chart.plot.Plot) piePlot5, false);
        float float13 = jFreeChart12.getBackgroundImageAlpha();
        org.jfree.chart.title.LegendTitle legendTitle15 = jFreeChart12.getLegend((int) ' ');
        int int16 = jFreeChart12.getBackgroundImageAlignment();
        org.jfree.chart.title.LegendTitle legendTitle18 = jFreeChart12.getLegend((-165));
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str21 = xYPlot20.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        xYPlot20.setDataset(0, xYDataset23);
        org.jfree.chart.axis.ValueAxis valueAxis26 = xYPlot20.getRangeAxisForDataset(0);
        boolean boolean27 = xYPlot20.isDomainCrosshairLockedOnData();
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = xYPlot29.getRendererForDataset(xYDataset30);
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        java.util.List list34 = null;
        xYPlot29.drawDomainTickBands(graphics2D32, rectangle2D33, list34);
        xYPlot29.zoom(0.0d);
        java.awt.Color color39 = java.awt.Color.BLUE;
        java.awt.Stroke stroke40 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker41 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint) color39, stroke40);
        java.awt.Font font42 = valueMarker41.getLabelFont();
        xYPlot29.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker41);
        org.jfree.chart.LegendItemCollection legendItemCollection44 = xYPlot29.getFixedLegendItems();
        java.awt.Graphics2D graphics2D45 = null;
        org.jfree.chart.util.Size2D size2D46 = new org.jfree.chart.util.Size2D();
        size2D46.height = 10L;
        size2D46.setHeight(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor53 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D54 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D46, 0.05d, (double) 1, rectangleAnchor53);
        org.jfree.chart.plot.RingPlot ringPlot57 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font58 = ringPlot57.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle59 = new org.jfree.chart.title.TextTitle("ThreadContext", font58);
        org.jfree.chart.plot.PiePlot piePlot60 = new org.jfree.chart.plot.PiePlot();
        piePlot60.setLabelGap(0.0d);
        piePlot60.setCircular(true);
        java.awt.Shape shape65 = piePlot60.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart67 = new org.jfree.chart.JFreeChart("ThreadContext", font58, (org.jfree.chart.plot.Plot) piePlot60, false);
        float float68 = jFreeChart67.getBackgroundImageAlpha();
        org.jfree.chart.title.LegendTitle legendTitle70 = jFreeChart67.getLegend((int) ' ');
        int int71 = jFreeChart67.getBackgroundImageAlignment();
        org.jfree.chart.title.LegendTitle legendTitle73 = jFreeChart67.getLegend((-165));
        java.awt.Stroke stroke74 = jFreeChart67.getBorderStroke();
        java.util.List list75 = jFreeChart67.getSubtitles();
        xYPlot29.drawDomainTickBands(graphics2D45, rectangle2D54, list75);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo78 = null;
        org.jfree.chart.plot.CrosshairState crosshairState79 = null;
        boolean boolean80 = xYPlot20.render(graphics2D28, rectangle2D54, (int) (short) -1, plotRenderingInfo78, crosshairState79);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo81 = null;
        try {
            jFreeChart12.draw(graphics2D19, rectangle2D54, chartRenderingInfo81);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.5f + "'", float13 == 0.5f);
        org.junit.Assert.assertNull(legendTitle15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 15 + "'", int16 == 15);
        org.junit.Assert.assertNull(legendTitle18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "XY Plot" + "'", str21.equals("XY Plot"));
        org.junit.Assert.assertNull(valueAxis26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNull(xYItemRenderer31);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(font42);
        org.junit.Assert.assertNull(legendItemCollection44);
        org.junit.Assert.assertNotNull(rectangleAnchor53);
        org.junit.Assert.assertNotNull(rectangle2D54);
        org.junit.Assert.assertNotNull(font58);
        org.junit.Assert.assertNotNull(shape65);
        org.junit.Assert.assertTrue("'" + float68 + "' != '" + 0.5f + "'", float68 == 0.5f);
        org.junit.Assert.assertNull(legendTitle70);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 15 + "'", int71 == 15);
        org.junit.Assert.assertNull(legendTitle73);
        org.junit.Assert.assertNotNull(stroke74);
        org.junit.Assert.assertNotNull(list75);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis3D1.setMarkerBand(markerAxisBand2);
        numberAxis3D1.zoomRange(0.0d, (double) (short) 1);
        org.jfree.data.time.DateRange dateRange7 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str8 = dateRange7.toString();
        boolean boolean11 = dateRange7.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange7, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = rectangleConstraint13.toUnconstrainedWidth();
        org.jfree.data.Range range15 = rectangleConstraint13.getWidthRange();
        numberAxis3D1.setDefaultAutoRange(range15);
        double double17 = numberAxis3D1.getLowerBound();
        numberAxis3D1.configure();
        org.junit.Assert.assertNotNull(dateRange7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str8.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint14);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "hi!", "hi!", "");
        java.lang.String str5 = basicProjectInfo4.getName();
        org.jfree.chart.ui.Library[] libraryArray6 = basicProjectInfo4.getLibraries();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo11 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "hi!", "hi!", "");
        basicProjectInfo11.setVersion("Multiple Pie Plot");
        basicProjectInfo4.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo11);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertNotNull(libraryArray6);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = categoryPlot21.getDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot21.getDomainAxis((-1));
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str26 = xYPlot25.getPlotType();
        boolean boolean27 = xYPlot25.isRangeZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation28 = xYPlot25.getRangeAxisLocation();
        categoryPlot21.setDomainAxisLocation(axisLocation28);
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot31 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset30);
        java.lang.String str32 = multiplePiePlot31.getPlotType();
        org.jfree.chart.plot.RingPlot ringPlot34 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font35 = ringPlot34.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle36 = new org.jfree.chart.title.TextTitle("ThreadContext", font35);
        java.awt.Color color37 = java.awt.Color.BLACK;
        textTitle36.setPaint((java.awt.Paint) color37);
        multiplePiePlot31.setAggregatedItemsPaint((java.awt.Paint) color37);
        org.jfree.chart.LegendItemCollection legendItemCollection40 = multiplePiePlot31.getLegendItems();
        categoryPlot21.setFixedLegendItems(legendItemCollection40);
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(categoryAxis22);
        org.junit.Assert.assertNull(categoryAxis24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "XY Plot" + "'", str26.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Multiple Pie Plot" + "'", str32.equals("Multiple Pie Plot"));
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(legendItemCollection40);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font3 = ringPlot2.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("ThreadContext", font3);
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        piePlot5.setLabelGap(0.0d);
        piePlot5.setCircular(true);
        java.awt.Shape shape10 = piePlot5.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("ThreadContext", font3, (org.jfree.chart.plot.Plot) piePlot5, false);
        jFreeChart12.removeLegend();
        boolean boolean14 = jFreeChart12.getAntiAlias();
        java.lang.Object obj15 = jFreeChart12.getTextAntiAlias();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(obj15);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = categoryPlot21.getDomainAxisForDataset((-165));
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.Layer layer27 = null;
        categoryPlot21.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker26, layer27);
        valueMarker26.setAlpha((float) 0L);
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(categoryAxis23);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str1 = xYPlot0.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        xYPlot0.setDataset(0, xYDataset3);
        java.lang.Class<?> wildcardClass5 = xYPlot0.getClass();
        xYPlot0.setRangeZeroBaselineVisible(true);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = xYPlot8.getRendererForDataset(xYDataset9);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        xYPlot8.setDomainAxis(valueAxis11);
        java.awt.Paint paint13 = xYPlot8.getRangeCrosshairPaint();
        java.lang.String str14 = xYPlot8.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset16 = xYPlot8.getDataset((int) (short) 10);
        boolean boolean18 = xYPlot8.equals((java.lang.Object) "TextBlockAnchor.BOTTOM_CENTER");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder19 = xYPlot8.getDatasetRenderingOrder();
        xYPlot0.setDatasetRenderingOrder(datasetRenderingOrder19);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "XY Plot" + "'", str1.equals("XY Plot"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(xYItemRenderer10);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "XY Plot" + "'", str14.equals("XY Plot"));
        org.junit.Assert.assertNull(xYDataset16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder19);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) textBlockAnchor0, jFreeChart1, (int) (byte) 10, (int) (byte) 100);
        chartProgressEvent4.setType(0);
        int int7 = chartProgressEvent4.getType();
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str1 = xYPlot0.getPlotType();
        xYPlot0.mapDatasetToRangeAxis((int) (short) -1, 0);
        org.jfree.chart.block.LineBorder lineBorder5 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = lineBorder5.getInsets();
        double double8 = rectangleInsets6.calculateRightInset((double) 0.5f);
        xYPlot0.setInsets(rectangleInsets6, true);
        org.jfree.chart.util.UnitType unitType11 = rectangleInsets6.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = new org.jfree.chart.util.RectangleInsets(unitType11, (double) 0, (double) 2.0f, 0.0d, (double) (short) 0);
        java.lang.String str17 = unitType11.toString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "XY Plot" + "'", str1.equals("XY Plot"));
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(unitType11);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "UnitType.ABSOLUTE" + "'", str17.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace1, false);
        java.awt.Paint paint4 = xYPlot0.getOutlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation6 = xYPlot0.getRangeAxisLocation((-16777216));
        org.jfree.chart.axis.AxisSpace axisSpace7 = xYPlot0.getFixedRangeAxisSpace();
        java.awt.geom.Point2D point2D8 = null;
        try {
            xYPlot0.setQuadrantOrigin(point2D8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'origin' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNull(axisSpace7);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = xYPlot0.getRendererForDataset(xYDataset1);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.util.List list5 = null;
        xYPlot0.drawDomainTickBands(graphics2D3, rectangle2D4, list5);
        xYPlot0.zoom(0.0d);
        java.awt.Color color10 = java.awt.Color.BLUE;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint) color10, stroke11);
        java.awt.Font font13 = valueMarker12.getLabelFont();
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker12);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = xYPlot0.getFixedLegendItems();
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str17 = xYPlot16.getPlotType();
        boolean boolean18 = xYPlot16.isRangeZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation19 = xYPlot16.getRangeAxisLocation();
        xYPlot0.setRangeAxisLocation(axisLocation19, true);
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str24 = xYPlot23.getPlotType();
        boolean boolean25 = xYPlot23.isRangeZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation26 = xYPlot23.getRangeAxisLocation();
        try {
            xYPlot0.setRangeAxisLocation((int) (byte) -1, axisLocation26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer2);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNull(legendItemCollection15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "XY Plot" + "'", str17.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "XY Plot" + "'", str24.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(axisLocation26);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setSectionDepth((double) 'a');
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        piePlot5.setLabelGap(0.0d);
        piePlot5.setCircular(true);
        org.jfree.chart.plot.RingPlot ringPlot10 = new org.jfree.chart.plot.RingPlot();
        ringPlot10.setSectionDepth((double) 'a');
        java.awt.Shape shape13 = ringPlot10.getLegendItemShape();
        org.jfree.chart.entity.ChartEntity chartEntity14 = new org.jfree.chart.entity.ChartEntity(shape13);
        piePlot5.setLegendItemShape(shape13);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        org.jfree.chart.plot.PiePlotState piePlotState18 = ringPlot0.initialise(graphics2D3, rectangle2D4, piePlot5, (java.lang.Integer) (-1), plotRenderingInfo17);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(piePlotState18);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Pie Plot");
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.lang.String str2 = multiplePiePlot1.getPlotType();
        java.lang.String str3 = multiplePiePlot1.getPlotType();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot5 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset4);
        java.lang.String str6 = multiplePiePlot5.getPlotType();
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font9 = ringPlot8.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("ThreadContext", font9);
        java.awt.Color color11 = java.awt.Color.BLACK;
        textTitle10.setPaint((java.awt.Paint) color11);
        multiplePiePlot5.setAggregatedItemsPaint((java.awt.Paint) color11);
        org.jfree.chart.LegendItemCollection legendItemCollection14 = multiplePiePlot5.getLegendItems();
        multiplePiePlot5.setLimit(0.0d);
        org.jfree.chart.JFreeChart jFreeChart17 = multiplePiePlot5.getPieChart();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D21 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand22 = null;
        numberAxis3D21.setMarkerBand(markerAxisBand22);
        org.jfree.data.time.DateRange dateRange24 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str25 = dateRange24.toString();
        boolean boolean28 = dateRange24.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange24, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint31 = rectangleConstraint30.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint33 = rectangleConstraint30.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range34 = rectangleConstraint30.getWidthRange();
        numberAxis3D21.setRangeWithMargins(range34, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) numberAxis3D21, categoryItemRenderer38);
        java.lang.Number[] numberArray43 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray45 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray47 = new java.lang.Number[] { 0L };
        java.lang.Number[] numberArray49 = new java.lang.Number[] { 0L };
        java.lang.Number[][] numberArray50 = new java.lang.Number[][] { numberArray43, numberArray45, numberArray47, numberArray49 };
        org.jfree.data.category.CategoryDataset categoryDataset51 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("VerticalAlignment.BOTTOM", "XY Plot", numberArray50);
        org.jfree.data.Range range53 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset51, false);
        java.lang.Number number54 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset51);
        categoryPlot39.setDataset(categoryDataset51);
        org.jfree.data.Range range56 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset51);
        multiplePiePlot5.setDataset(categoryDataset51);
        multiplePiePlot1.setDataset(categoryDataset51);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Multiple Pie Plot" + "'", str2.equals("Multiple Pie Plot"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Multiple Pie Plot" + "'", str3.equals("Multiple Pie Plot"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Multiple Pie Plot" + "'", str6.equals("Multiple Pie Plot"));
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(legendItemCollection14);
        org.junit.Assert.assertNotNull(jFreeChart17);
        org.junit.Assert.assertNotNull(dateRange24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str25.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint31);
        org.junit.Assert.assertNotNull(rectangleConstraint33);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(numberArray47);
        org.junit.Assert.assertNotNull(numberArray49);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(categoryDataset51);
        org.junit.Assert.assertNotNull(range53);
        org.junit.Assert.assertTrue("'" + number54 + "' != '" + 0.0d + "'", number54.equals(0.0d));
        org.junit.Assert.assertNull(range56);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setLabelGap(0.0d);
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        piePlot0.setBackgroundPaint((java.awt.Paint) color3);
        java.awt.Paint paint6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        piePlot0.setSectionPaint((java.lang.Comparable) '4', paint6);
        org.jfree.data.general.PieDataset pieDataset8 = piePlot0.getDataset();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(pieDataset8);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke1 = ringPlot0.getLabelLinkStroke();
        double double2 = ringPlot0.getOuterSeparatorExtension();
        java.awt.Paint paint3 = ringPlot0.getLabelShadowPaint();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = categoryPlot21.getDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot21.getDomainAxis((-1));
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str26 = xYPlot25.getPlotType();
        boolean boolean27 = xYPlot25.isRangeZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation28 = xYPlot25.getRangeAxisLocation();
        categoryPlot21.setDomainAxisLocation(axisLocation28);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        categoryPlot21.setRenderer(categoryItemRenderer30);
        java.awt.Paint paint32 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryPlot21.setDomainGridlinePaint(paint32);
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(categoryAxis22);
        org.junit.Assert.assertNull(categoryAxis24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "XY Plot" + "'", str26.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNotNull(paint32);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        boolean boolean2 = ringPlot1.getIgnoreZeroValues();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        piePlot5.setLabelGap(0.0d);
        piePlot5.setCircular(true);
        double double10 = piePlot5.getShadowYOffset();
        java.awt.Font font11 = piePlot5.getLabelFont();
        piePlot5.setIgnoreNullValues(true);
        boolean boolean14 = piePlot5.getSectionOutlinesVisible();
        java.awt.Stroke stroke16 = piePlot5.getSectionOutlineStroke((java.lang.Comparable) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        org.jfree.chart.plot.PiePlotState piePlotState19 = ringPlot1.initialise(graphics2D3, rectangle2D4, piePlot5, (java.lang.Integer) (-1), plotRenderingInfo18);
        piePlotState19.setPieCenterY(0.0d);
        piePlotState19.setPieCenterX((double) (-32640));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(stroke16);
        org.junit.Assert.assertNotNull(piePlotState19);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis3D3.setMarkerBand(markerAxisBand4);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.lang.String str7 = dateRange6.toString();
        boolean boolean10 = dateRange6.intersects(1.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toFixedWidth((double) 0.0f);
        org.jfree.data.Range range16 = rectangleConstraint12.getWidthRange();
        numberAxis3D3.setRangeWithMargins(range16, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = categoryPlot21.getDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot21.getDomainAxis((-1));
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot();
        java.lang.String str26 = xYPlot25.getPlotType();
        boolean boolean27 = xYPlot25.isRangeZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation28 = xYPlot25.getRangeAxisLocation();
        categoryPlot21.setDomainAxisLocation(axisLocation28);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        categoryPlot21.setRenderer(categoryItemRenderer30);
        categoryPlot21.setRangeCrosshairLockedOnData(true);
        boolean boolean34 = categoryPlot21.isRangeGridlinesVisible();
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(categoryAxis22);
        org.junit.Assert.assertNull(categoryAxis24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "XY Plot" + "'", str26.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (byte) 100);
    }
}

