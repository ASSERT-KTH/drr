import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.lang.Class class0 = null;
        java.util.Date date1 = null;
        java.util.TimeZone timeZone2 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date1, timeZone2);
        org.junit.Assert.assertNull(regularTimePeriod3);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Month month1 = new org.jfree.data.time.Month(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 100, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries(comparable0, "", "org.jfree.data.event.SeriesChangeEvent[source=-1.0]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        java.util.Locale locale2 = null;
        try {
            org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date0, timeZone1, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        java.util.Locale locale2 = null;
        try {
            org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date0, timeZone1, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        try {
            timeSeries1.update(1, (java.lang.Number) 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(10);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year5, (double) (byte) 1, true);
        java.util.Calendar calendar9 = null;
        try {
            long long10 = year5.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = null;
        try {
            timeSeries1.add(timeSeriesDataItem2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        try {
            org.jfree.data.time.TimeSeries timeSeries6 = timeSeries1.createCopy((-1), 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        try {
            timeSeries1.delete((int) '#', (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = timeSeries1.getDataItem(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        try {
            java.lang.Number number3 = timeSeries1.getValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 5");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        try {
            java.lang.Number number7 = timeSeries1.getValue((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(10);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year5, (double) (byte) 1, true);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate(timeSeriesDataItem9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = timeSeries1.addOrUpdate(timeSeriesDataItem4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.previous();
        boolean boolean4 = month0.equals((java.lang.Object) month2);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = month2.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        int int0 = org.jfree.data.time.Year.MAXIMUM_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        java.lang.String str6 = timeSeries1.getRangeDescription();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries1.addChangeListener(seriesChangeListener7);
        try {
            java.lang.Number number10 = timeSeries1.getValue((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = year0.getFirstMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int2 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries3 = null;
        try {
            java.util.Collection collection4 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int2 = year1.getYear();
        long long3 = year1.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year1.next();
        try {
            org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(0, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getMiddleMillisecond();
        long long2 = year0.getFirstMillisecond();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year0.getMiddleMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1562097599999L + "'", long1 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int2 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getMiddleMillisecond();
        long long5 = year3.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year3, (java.lang.Number) 2147483647);
        java.util.Calendar calendar8 = null;
        try {
            long long9 = year3.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1562097599999L + "'", long4 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1.0f), seriesChangeInfo1);
        java.lang.Class<?> wildcardClass3 = seriesChangeEvent2.getClass();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = seriesChangeEvent2.getSummary();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNull(seriesChangeInfo4);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        int int0 = org.jfree.data.time.Year.MINIMUM_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-9999) + "'", int0 == (-9999));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        java.lang.String str6 = timeSeries1.getRangeDescription();
        try {
            timeSeries1.update(7, (java.lang.Number) 8L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int2 = timeSeries1.getMaximumItemCount();
        java.lang.Object obj3 = timeSeries1.clone();
        timeSeries1.setKey((java.lang.Comparable) 1);
        try {
            timeSeries1.delete((int) (byte) 10, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int2 = year1.getYear();
        java.lang.String str3 = year1.toString();
        try {
            org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(2147483647, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(10);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year5, (double) (byte) 1, true);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        long long12 = month9.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (double) 1.0f);
        java.lang.Number number15 = timeSeriesDataItem14.getValue();
        timeSeriesDataItem14.setValue((java.lang.Number) 1559372400000L);
        try {
            timeSeries1.add(timeSeriesDataItem14, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1559372400000L + "'", long12 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 1.0d + "'", number15.equals(1.0d));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month8.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries11 = timeSeries1.createCopy(regularTimePeriod9, regularTimePeriod10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'end' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int2 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getMiddleMillisecond();
        long long5 = year3.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year3, (java.lang.Number) 2147483647);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries1.getDataItem(2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2147483647, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1562097599999L + "'", long4 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        int int7 = month6.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month6.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month6, (double) 10.0f);
        try {
            org.jfree.data.time.TimeSeries timeSeries13 = timeSeries1.createCopy((int) (short) 10, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        java.lang.String str3 = month0.toString();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = month0.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        long long3 = month0.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries5.removeChangeListener(seriesChangeListener6);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries5.removeChangeListener(seriesChangeListener8);
        java.lang.String str10 = timeSeries5.getRangeDescription();
        int int11 = month0.compareTo((java.lang.Object) timeSeries5);
        try {
            timeSeries5.update((int) (byte) 10, (java.lang.Number) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1559372400000L + "'", long3 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Value" + "'", str10.equals("Value"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 5");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1.0f), seriesChangeInfo1);
        java.lang.Class<?> wildcardClass3 = seriesChangeEvent2.getClass();
        java.lang.String str4 = seriesChangeEvent2.toString();
        java.lang.String str5 = seriesChangeEvent2.toString();
        java.lang.Class<?> wildcardClass6 = seriesChangeEvent2.getClass();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=-1.0]" + "'", str4.equals("org.jfree.data.event.SeriesChangeEvent[source=-1.0]"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=-1.0]" + "'", str5.equals("org.jfree.data.event.SeriesChangeEvent[source=-1.0]"));
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year0.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        java.lang.String str6 = timeSeries1.getRangeDescription();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries1.addChangeListener(seriesChangeListener7);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = timeSeries1.getTimePeriod((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(10);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year5, (double) (byte) 1, true);
        timeSeries1.setNotify(true);
        try {
            timeSeries1.delete((int) (short) 1, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        try {
            timeSeries1.delete(100, 2, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(class7);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo2 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1.0f), seriesChangeInfo2);
        boolean boolean4 = month0.equals((java.lang.Object) (-1.0f));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(10);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year5, (double) (byte) 1, true);
        java.lang.Object obj9 = null;
        boolean boolean10 = timeSeries1.equals(obj9);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(10);
        java.lang.String str13 = year12.toString();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year12, (double) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period 10 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "10" + "'", str13.equals("10"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(10);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year5, (double) (byte) 1, true);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = null;
        try {
            int int10 = timeSeries1.getIndex(regularTimePeriod9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year1.previous();
        try {
            org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) '4', year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(5, (int) (byte) -1);
        java.lang.String str3 = month2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "May -1" + "'", str3.equals("May -1"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int2 = timeSeries1.getMaximumItemCount();
        java.lang.Object obj3 = timeSeries1.clone();
        timeSeries1.setKey((java.lang.Comparable) 1);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        int int7 = month6.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month6.next();
        int int9 = month6.getMonth();
        int int10 = month6.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month6);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.next();
        timeSeries1.add(regularTimePeriod13, (-1.0d), true);
        try {
            java.lang.Number number18 = timeSeries1.getValue((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        timeSeries1.setMaximumItemAge((long) '#');
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        int int11 = year10.getYear();
        java.lang.String str12 = year10.toString();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        int int14 = month13.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month13.next();
        long long16 = month13.getFirstMillisecond();
        long long17 = month13.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year10, (org.jfree.data.time.RegularTimePeriod) month13);
        try {
            timeSeries1.update((int) (short) 10, (java.lang.Number) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1559372400000L + "'", long16 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1559372400000L + "'", long17 == 1559372400000L);
        org.junit.Assert.assertNotNull(timeSeries18);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        timeSeries1.setMaximumItemCount((int) '#');
        java.lang.Class class9 = timeSeries1.getTimePeriodClass();
        java.util.List list10 = timeSeries1.getItems();
        java.lang.Comparable comparable11 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) 8);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13);
        boolean boolean16 = fixedMillisecond13.equals((java.lang.Object) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(class9);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + 100L + "'", comparable11.equals(100L));
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener4);
        timeSeries1.setKey((java.lang.Comparable) "Time");
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int2 = year1.getYear();
        long long3 = year1.getSerialIndex();
        long long4 = year1.getMiddleMillisecond();
        try {
            org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(0, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1562097599999L + "'", long4 == 1562097599999L);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(10);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year5, (double) (byte) 1, true);
        java.lang.Object obj9 = timeSeries1.clone();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        int int11 = month10.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month10.next();
        long long13 = month10.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month10, (double) 1.0f);
        java.lang.Number number16 = timeSeriesDataItem15.getValue();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int19 = timeSeries18.getMaximumItemCount();
        java.lang.Object obj20 = timeSeries18.clone();
        timeSeries18.setKey((java.lang.Comparable) 1);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        int int24 = month23.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = month23.next();
        int int26 = month23.getMonth();
        int int27 = month23.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries18.getDataItem((org.jfree.data.time.RegularTimePeriod) month23);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year29.next();
        timeSeries18.add(regularTimePeriod30, (-1.0d), true);
        boolean boolean34 = timeSeriesDataItem15.equals((java.lang.Object) (-1.0d));
        java.lang.Number number35 = timeSeriesDataItem15.getValue();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries1.addOrUpdate(timeSeriesDataItem15);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1559372400000L + "'", long13 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 1.0d + "'", number16.equals(1.0d));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2147483647 + "'", int19 == 2147483647);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 6 + "'", int24 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 6 + "'", int26 == 6);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem28);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + number35 + "' != '" + 1.0d + "'", number35.equals(1.0d));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int4 = timeSeries3.getMaximumItemCount();
        java.lang.Object obj5 = timeSeries3.clone();
        timeSeries3.setKey((java.lang.Comparable) 1);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        int int9 = month8.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month8.next();
        int int11 = month8.getMonth();
        int int12 = month8.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) month8);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.next();
        timeSeries3.add(regularTimePeriod15, (-1.0d), true);
        boolean boolean19 = year0.equals((java.lang.Object) timeSeries3);
        java.util.Calendar calendar20 = null;
        try {
            year0.peg(calendar20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1.0f), seriesChangeInfo1);
        java.lang.Class<?> wildcardClass3 = seriesChangeEvent2.getClass();
        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
        java.util.Date date5 = null;
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date5, timeZone6);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        int int9 = month8.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month8.next();
        long long11 = month8.getFirstMillisecond();
        java.util.Date date12 = month8.getEnd();
        java.util.TimeZone timeZone13 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date12, timeZone13);
        java.util.TimeZone timeZone15 = null;
        java.util.Locale locale16 = null;
        try {
            org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date12, timeZone15, locale16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(class4);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1559372400000L + "'", long11 == 1559372400000L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(regularTimePeriod14);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        timeSeries1.setMaximumItemCount((int) '#');
        java.lang.Class class9 = timeSeries1.getTimePeriodClass();
        timeSeries1.setMaximumItemCount(2147483647);
        try {
            timeSeries1.update((int) '#', (java.lang.Number) 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(class9);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1.0f), seriesChangeInfo1);
        java.lang.Class<?> wildcardClass3 = seriesChangeEvent2.getClass();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent2.setSummary(seriesChangeInfo4);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        timeSeries1.setMaximumItemCount((int) '#');
        java.lang.Class class9 = timeSeries1.getTimePeriodClass();
        java.util.List list10 = timeSeries1.getItems();
        java.lang.Comparable comparable11 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) 8);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = null;
        try {
            timeSeries1.add(regularTimePeriod15, (java.lang.Number) 2019L, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(class9);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + 100L + "'", comparable11.equals(100L));
        org.junit.Assert.assertNull(timeSeriesDataItem14);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        timeSeries1.setMaximumItemCount((int) '#');
        try {
            timeSeries1.update((int) (byte) 100, (java.lang.Number) 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) 0, 0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) 8);
        long long8 = fixedMillisecond7.getSerialIndex();
        long long9 = fixedMillisecond7.getFirstMillisecond();
        int int10 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries1.getTimePeriod((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 8L + "'", long8 == 8L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 8L + "'", long9 == 8L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(3, (int) ' ', 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int2 = timeSeries1.getMaximumItemCount();
        java.lang.Object obj3 = timeSeries1.clone();
        timeSeries1.setKey((java.lang.Comparable) 1);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.addChangeListener(seriesChangeListener6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = null;
        try {
            int int9 = timeSeries1.getIndex(regularTimePeriod8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) 'a', (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int2 = timeSeries1.getMaximumItemCount();
        java.lang.Object obj3 = timeSeries1.clone();
        timeSeries1.setKey((java.lang.Comparable) 1);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries1.removeChangeListener(seriesChangeListener8);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int2 = year1.getYear();
        long long3 = year1.getSerialIndex();
        long long4 = year1.getMiddleMillisecond();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(4, year1);
        java.lang.String str6 = year1.toString();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year1.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1562097599999L + "'", long4 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        java.lang.String str8 = timeSeries1.getDescription();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        long long12 = month9.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (double) 1.0f);
        java.lang.Number number15 = timeSeriesDataItem14.getValue();
        timeSeries1.add(timeSeriesDataItem14, true);
        timeSeries1.setDomainDescription("2019");
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1559372400000L + "'", long12 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 1.0d + "'", number15.equals(1.0d));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        long long3 = month0.getFirstMillisecond();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = month0.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1559372400000L + "'", long3 == 1559372400000L);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(10);
        java.lang.String str2 = year1.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (java.lang.Number) 100);
        java.util.Date date5 = year1.getStart();
        java.util.TimeZone timeZone6 = null;
        try {
            org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5, timeZone6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10" + "'", str2.equals("10"));
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 9);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Value");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) 0);
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("Value");
        java.lang.Throwable[] throwableArray5 = seriesException4.getSuppressed();
        org.jfree.data.general.SeriesException seriesException7 = new org.jfree.data.general.SeriesException("Value");
        seriesException4.addSuppressed((java.lang.Throwable) seriesException7);
        boolean boolean9 = timeSeriesDataItem2.equals((java.lang.Object) seriesException4);
        java.lang.String str10 = seriesException4.toString();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.general.SeriesException: Value" + "'", str10.equals("org.jfree.data.general.SeriesException: Value"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int2 = timeSeries1.getMaximumItemCount();
        java.lang.Object obj3 = timeSeries1.clone();
        timeSeries1.setKey((java.lang.Comparable) 1);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = timeSeries1.getTimePeriod(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        timeSeries1.setMaximumItemCount((int) '#');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = null;
        try {
            timeSeries1.add(regularTimePeriod9, (double) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = month0.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        java.lang.String str6 = timeSeries1.getRangeDescription();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries1.addChangeListener(seriesChangeListener7);
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) 8);
        long long13 = fixedMillisecond12.getSerialIndex();
        long long14 = fixedMillisecond12.getFirstMillisecond();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (java.lang.Number) 2147483647);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) 8);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) 0);
        boolean boolean22 = timeSeriesDataItem21.isSelected();
        boolean boolean23 = fixedMillisecond18.equals((java.lang.Object) timeSeriesDataItem21);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries1.addOrUpdate(timeSeriesDataItem21);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.FixedMillisecond.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 8L + "'", long13 == 8L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 8L + "'", long14 == 8L);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 6);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo2 = null;
        seriesChangeEvent1.setSummary(seriesChangeInfo2);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent1.setSummary(seriesChangeInfo4);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo6 = seriesChangeEvent1.getSummary();
        org.junit.Assert.assertNull(seriesChangeInfo6);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        java.lang.String str8 = timeSeries1.getDescription();
        java.lang.String str9 = timeSeries1.getDomainDescription();
        timeSeries1.setNotify(true);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = null;
        try {
            timeSeries1.add(regularTimePeriod12, (java.lang.Number) 2147483647, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        timeSeries1.setMaximumItemAge((long) '#');
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        int int11 = year10.getYear();
        java.lang.String str12 = year10.toString();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        int int14 = month13.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month13.next();
        long long16 = month13.getFirstMillisecond();
        long long17 = month13.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year10, (org.jfree.data.time.RegularTimePeriod) month13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries18.getDataItem(regularTimePeriod19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1559372400000L + "'", long16 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1559372400000L + "'", long17 == 1559372400000L);
        org.junit.Assert.assertNotNull(timeSeries18);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = month0.getFirstMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = timeSeries1.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        java.lang.Class class0 = null;
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo2 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1.0f), seriesChangeInfo2);
        java.lang.Class<?> wildcardClass4 = seriesChangeEvent3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date6, timeZone7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        long long12 = month9.getFirstMillisecond();
        java.util.Date date13 = month9.getEnd();
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date13, timeZone14);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date13, timeZone16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.next();
        java.util.Calendar calendar20 = null;
        try {
            long long21 = day18.getFirstMillisecond(calendar20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1559372400000L + "'", long12 == 1559372400000L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        java.lang.String str6 = timeSeries1.getRangeDescription();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries1.addChangeListener(seriesChangeListener7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        long long12 = month9.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (double) 1.0f);
        java.lang.Number number15 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) month9);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries17.removeChangeListener(seriesChangeListener18);
        java.util.List list20 = timeSeries17.getItems();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
        int int22 = month21.getMonth();
        timeSeries17.setKey((java.lang.Comparable) int22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        int int25 = year24.getYear();
        long long26 = year24.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year24.next();
        timeSeries17.delete((org.jfree.data.time.RegularTimePeriod) year24);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year24, (java.lang.Number) 11);
        try {
            timeSeries1.delete(35, (int) (byte) 100, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1559372400000L + "'", long12 == 1559372400000L);
        org.junit.Assert.assertNull(number15);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2019 + "'", int25 == 2019);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 2019L + "'", long26 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int2 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        int int4 = month3.getMonth();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.previous();
        boolean boolean7 = month3.equals((java.lang.Object) month5);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month3, (java.lang.Number) 2147483647, false);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries12.removeChangeListener(seriesChangeListener13);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries12.removeChangeListener(seriesChangeListener15);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        int int18 = month17.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month17.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month17, (double) 10.0f);
        int int22 = month3.compareTo((java.lang.Object) 10.0f);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        int int24 = year23.getYear();
        long long25 = year23.getSerialIndex();
        long long26 = year23.getMiddleMillisecond();
        boolean boolean27 = month3.equals((java.lang.Object) long26);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 2019L + "'", long25 == 2019L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1562097599999L + "'", long26 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        java.lang.String str3 = month0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month0.next();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        int int6 = year5.getYear();
        java.lang.String str7 = year5.toString();
        long long8 = year5.getSerialIndex();
        int int9 = month0.compareTo((java.lang.Object) year5);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries2.removeChangeListener(seriesChangeListener3);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries2.removeChangeListener(seriesChangeListener5);
        java.lang.String str7 = timeSeries2.getRangeDescription();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries2.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        int int11 = month10.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month10.next();
        long long13 = month10.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month10, (double) 1.0f);
        java.lang.Number number16 = timeSeries2.getValue((org.jfree.data.time.RegularTimePeriod) month10);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries18.removeChangeListener(seriesChangeListener19);
        java.util.List list21 = timeSeries18.getItems();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        int int23 = month22.getMonth();
        timeSeries18.setKey((java.lang.Comparable) int23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        int int26 = year25.getYear();
        long long27 = year25.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year25.next();
        timeSeries18.delete((org.jfree.data.time.RegularTimePeriod) year25);
        timeSeries2.add((org.jfree.data.time.RegularTimePeriod) year25, (java.lang.Number) 11);
        try {
            org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(9999, year25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1559372400000L + "'", long13 == 1559372400000L);
        org.junit.Assert.assertNull(number16);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 2019L + "'", long27 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 8);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 8L + "'", long3 == 8L);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        java.lang.Class class0 = null;
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo2 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1.0f), seriesChangeInfo2);
        java.lang.Class<?> wildcardClass4 = seriesChangeEvent3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date6, timeZone7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        long long12 = month9.getFirstMillisecond();
        java.util.Date date13 = month9.getEnd();
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date13, timeZone14);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date13, timeZone16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date13);
        java.util.TimeZone timeZone19 = null;
        try {
            org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date13, timeZone19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1559372400000L + "'", long12 == 1559372400000L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNull(regularTimePeriod17);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1.0f), seriesChangeInfo1);
        java.lang.Class<?> wildcardClass3 = seriesChangeEvent2.getClass();
        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
        java.util.Date date5 = null;
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date5, timeZone6);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        int int9 = month8.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month8.next();
        long long11 = month8.getFirstMillisecond();
        java.util.Date date12 = month8.getEnd();
        java.util.TimeZone timeZone13 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date12, timeZone13);
        java.util.TimeZone timeZone15 = null;
        try {
            org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date12, timeZone15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(class4);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1559372400000L + "'", long11 == 1559372400000L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(regularTimePeriod14);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year0.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(10);
        java.lang.String str2 = year1.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (java.lang.Number) 100);
        java.util.Date date5 = year1.getStart();
        try {
            org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10" + "'", str2.equals("10"));
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int2 = timeSeries1.getMaximumItemCount();
        java.lang.Object obj3 = timeSeries1.clone();
        timeSeries1.setKey((java.lang.Comparable) 1);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        int int7 = month6.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month6.next();
        int int9 = month6.getMonth();
        int int10 = month6.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month6);
        long long12 = month6.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1561964399999L + "'", long12 == 1561964399999L);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        java.lang.String str6 = timeSeries1.getRangeDescription();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries1.addChangeListener(seriesChangeListener7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        long long12 = month9.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (double) 1.0f);
        java.lang.Number number15 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) month9);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = timeSeries1.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1559372400000L + "'", long12 == 1559372400000L);
        org.junit.Assert.assertNull(number15);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int2 = timeSeries1.getMaximumItemCount();
        java.lang.Object obj3 = timeSeries1.clone();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = timeSeries1.getDataItem((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int2 = timeSeries1.getMaximumItemCount();
        timeSeries1.setMaximumItemAge((long) 5);
        timeSeries1.setNotify(true);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(10);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year5, (double) (byte) 1, true);
        java.lang.Object obj9 = null;
        boolean boolean10 = timeSeries1.equals(obj9);
        java.lang.Object obj11 = null;
        boolean boolean12 = timeSeries1.equals(obj11);
        java.lang.Class class13 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries1.addOrUpdate(regularTimePeriod14, (java.lang.Number) 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(class13);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        java.lang.String str6 = timeSeries1.getRangeDescription();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries1.addChangeListener(seriesChangeListener7);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = timeSeries1.getTimePeriod(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1.0f), seriesChangeInfo1);
        java.lang.Class<?> wildcardClass3 = seriesChangeEvent2.getClass();
        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
        java.util.Date date5 = null;
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date5, timeZone6);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        int int9 = month8.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month8.next();
        long long11 = month8.getFirstMillisecond();
        java.util.Date date12 = month8.getEnd();
        java.util.TimeZone timeZone13 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date12, timeZone13);
        java.util.TimeZone timeZone15 = null;
        try {
            org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date12, timeZone15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(class4);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1559372400000L + "'", long11 == 1559372400000L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(regularTimePeriod14);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Time");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 5");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(10);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year5, (double) (byte) 1, true);
        java.lang.Object obj9 = timeSeries1.clone();
        java.lang.String str10 = timeSeries1.getDescription();
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(5, (int) (byte) -1);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = month2.getMiddleMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(10);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year5, (double) (byte) 1, true);
        java.lang.Object obj9 = null;
        boolean boolean10 = timeSeries1.equals(obj9);
        java.lang.Object obj11 = null;
        boolean boolean12 = timeSeries1.equals(obj11);
        java.lang.Class class13 = timeSeries1.getTimePeriodClass();
        java.util.Date date14 = null;
        java.util.TimeZone timeZone15 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date14, timeZone15);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNull(regularTimePeriod16);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = null;
        try {
            timeSeries1.add(timeSeriesDataItem7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        long long3 = month0.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) 1.0f);
        java.lang.Number number6 = timeSeriesDataItem5.getValue();
        java.lang.Number number7 = timeSeriesDataItem5.getValue();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        int int9 = month8.getMonth();
        int int10 = month8.getYearValue();
        int int11 = month8.getYearValue();
        int int12 = timeSeriesDataItem5.compareTo((java.lang.Object) month8);
        java.lang.Number number13 = null;
        timeSeriesDataItem5.setValue(number13);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1559372400000L + "'", long3 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1.0d + "'", number6.equals(1.0d));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 1.0d + "'", number7.equals(1.0d));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int5 = timeSeries4.getMaximumItemCount();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        int int7 = month6.getMonth();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month8.previous();
        boolean boolean10 = month6.equals((java.lang.Object) month8);
        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) 2147483647, false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month6.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) 0.0f);
        double double17 = timeSeries1.getMaxY();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "Time", "hi!");
        boolean boolean4 = timeSeries3.isEmpty();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Value");
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        timeSeries1.setMaximumItemAge((long) '#');
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        int int11 = year10.getYear();
        java.lang.String str12 = year10.toString();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        int int14 = month13.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month13.next();
        long long16 = month13.getFirstMillisecond();
        long long17 = month13.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year10, (org.jfree.data.time.RegularTimePeriod) month13);
        int int19 = timeSeries18.getItemCount();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1559372400000L + "'", long16 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1559372400000L + "'", long17 == 1559372400000L);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        int int2 = month0.getYearValue();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1.0f), seriesChangeInfo4);
        java.lang.Class<?> wildcardClass6 = seriesChangeEvent5.getClass();
        java.util.Date date7 = null;
        java.util.TimeZone timeZone8 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date7, timeZone8);
        int int10 = month0.compareTo((java.lang.Object) timeZone8);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo11 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) int10, seriesChangeInfo11);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int2 = timeSeries1.getMaximumItemCount();
        timeSeries1.setMaximumItemAge((long) 5);
        timeSeries1.fireSeriesChanged();
        double double6 = timeSeries1.getMinY();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries8.removeChangeListener(seriesChangeListener9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries8.removeChangeListener(seriesChangeListener11);
        java.lang.String str13 = timeSeries8.getRangeDescription();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries8.addChangeListener(seriesChangeListener14);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries8.removePropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) 8);
        long long20 = fixedMillisecond19.getSerialIndex();
        long long21 = fixedMillisecond19.getFirstMillisecond();
        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (java.lang.Number) 2147483647);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
        int int25 = month24.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month24.next();
        int int27 = fixedMillisecond19.compareTo((java.lang.Object) regularTimePeriod26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (double) (short) 100);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year30, (java.lang.Number) 0);
        try {
            timeSeries1.add(timeSeriesDataItem32, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.FixedMillisecond.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Value" + "'", str13.equals("Value"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 8L + "'", long20 == 8L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 8L + "'", long21 == 8L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("10");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("Value");
        java.lang.Throwable[] throwableArray4 = seriesException3.getSuppressed();
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("Value");
        seriesException3.addSuppressed((java.lang.Throwable) seriesException6);
        java.lang.Throwable[] throwableArray8 = seriesException6.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException6);
        java.lang.Throwable[] throwableArray10 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(throwableArray10);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        int int2 = month0.getYearValue();
        long long3 = month0.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) 1562097599999L);
        java.lang.String str6 = month0.toString();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 24234L + "'", long3 == 24234L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int2 = timeSeries1.getMaximumItemCount();
        java.lang.Object obj3 = timeSeries1.clone();
        timeSeries1.setKey((java.lang.Comparable) 1);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        int int7 = month6.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month6.next();
        int int9 = month6.getMonth();
        int int10 = month6.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month6);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getMiddleMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) year12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = null;
        try {
            timeSeries1.add(regularTimePeriod15, 0.0d, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1562097599999L + "'", long13 == 1562097599999L);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        timeSeries1.setMaximumItemAge((long) '#');
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        int int11 = year10.getYear();
        java.lang.String str12 = year10.toString();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        int int14 = month13.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month13.next();
        long long16 = month13.getFirstMillisecond();
        long long17 = month13.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year10, (org.jfree.data.time.RegularTimePeriod) month13);
        java.lang.String str19 = year10.toString();
        java.util.Calendar calendar20 = null;
        try {
            long long21 = year10.getLastMillisecond(calendar20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1559372400000L + "'", long16 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1559372400000L + "'", long17 == 1559372400000L);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2019" + "'", str19.equals("2019"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.lang.String str2 = year0.toString();
        long long3 = year0.getSerialIndex();
        java.lang.Object obj4 = null;
        boolean boolean5 = year0.equals(obj4);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        timeSeries1.setMaximumItemAge((long) '#');
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        int int11 = year10.getYear();
        java.lang.String str12 = year10.toString();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        int int14 = month13.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month13.next();
        long long16 = month13.getFirstMillisecond();
        long long17 = month13.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year10, (org.jfree.data.time.RegularTimePeriod) month13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = null;
        try {
            timeSeries1.update(regularTimePeriod19, (java.lang.Number) 35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1559372400000L + "'", long16 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1559372400000L + "'", long17 == 1559372400000L);
        org.junit.Assert.assertNotNull(timeSeries18);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.Year year2 = month0.getYear();
        long long3 = month0.getSerialIndex();
        java.util.Calendar calendar4 = null;
        try {
            month0.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 24234L + "'", long3 == 24234L);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries2.removeChangeListener(seriesChangeListener3);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries2.removeChangeListener(seriesChangeListener5);
        boolean boolean7 = timeSeries2.getNotify();
        java.lang.Class class8 = timeSeries2.getTimePeriodClass();
        timeSeries2.setMaximumItemAge((long) '#');
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        int int12 = year11.getYear();
        java.lang.String str13 = year11.toString();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        int int15 = month14.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = month14.next();
        long long17 = month14.getFirstMillisecond();
        long long18 = month14.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year11, (org.jfree.data.time.RegularTimePeriod) month14);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        long long21 = year20.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year20, (double) 100L);
        long long24 = year20.getSerialIndex();
        try {
            org.jfree.data.time.Month month25 = new org.jfree.data.time.Month((int) ' ', year20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1559372400000L + "'", long17 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1559372400000L + "'", long18 == 1559372400000L);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1562097599999L + "'", long21 == 1562097599999L);
        org.junit.Assert.assertNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 2019L + "'", long24 == 2019L);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        java.lang.Object obj0 = null;
        try {
            org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        long long3 = month0.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries5.removeChangeListener(seriesChangeListener6);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries5.removeChangeListener(seriesChangeListener8);
        java.lang.String str10 = timeSeries5.getRangeDescription();
        int int11 = month0.compareTo((java.lang.Object) timeSeries5);
        java.util.Collection collection12 = timeSeries5.getTimePeriods();
        java.lang.Comparable comparable13 = null;
        try {
            timeSeries5.setKey(comparable13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1559372400000L + "'", long3 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Value" + "'", str10.equals("Value"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(collection12);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        java.lang.String str3 = month0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month0.next();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = regularTimePeriod4.getMiddleMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int2 = timeSeries1.getMaximumItemCount();
        java.lang.Object obj3 = timeSeries1.clone();
        timeSeries1.setKey((java.lang.Comparable) 1);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        int int7 = month6.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month6.next();
        int int9 = month6.getMonth();
        int int10 = month6.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month6);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.next();
        timeSeries1.add(regularTimePeriod13, (-1.0d), true);
        long long17 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries19.removeChangeListener(seriesChangeListener20);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(10);
        timeSeries19.add((org.jfree.data.time.RegularTimePeriod) year23, (double) (byte) 1, true);
        int int27 = timeSeries19.getMaximumItemCount();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(10);
        timeSeries19.delete((org.jfree.data.time.RegularTimePeriod) year29);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) year29);
        java.util.Calendar calendar32 = null;
        try {
            year29.peg(calendar32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 9223372036854775807L + "'", long17 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2147483647 + "'", int27 == 2147483647);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int2 = timeSeries1.getMaximumItemCount();
        java.lang.Object obj3 = timeSeries1.clone();
        timeSeries1.setKey((java.lang.Comparable) 1);
        java.util.Collection collection6 = timeSeries1.getTimePeriods();
        int int7 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        int int12 = month11.getMonth();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month13.previous();
        boolean boolean15 = month11.equals((java.lang.Object) month13);
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) 2147483647, false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month11.previous();
        timeSeries1.add(regularTimePeriod19, (java.lang.Number) (-1), true);
        timeSeries1.setDescription("org.jfree.data.general.SeriesException: Value");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int2 = timeSeries1.getMaximumItemCount();
        java.lang.Object obj3 = timeSeries1.clone();
        timeSeries1.setKey((java.lang.Comparable) 1);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        int int7 = month6.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month6.next();
        int int9 = month6.getMonth();
        int int10 = month6.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month6);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.next();
        timeSeries1.add(regularTimePeriod13, (-1.0d), true);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = null;
        try {
            timeSeries1.add(regularTimePeriod17, (-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        java.lang.String str8 = timeSeries1.getDescription();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        long long12 = month9.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (double) 1.0f);
        java.lang.Number number15 = timeSeriesDataItem14.getValue();
        timeSeries1.add(timeSeriesDataItem14, true);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        long long19 = year18.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year18.next();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries1.addOrUpdate(regularTimePeriod20, (java.lang.Number) 6);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1559372400000L + "'", long12 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 1.0d + "'", number15.equals(1.0d));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1546329600000L + "'", long19 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int2 = timeSeries1.getMaximumItemCount();
        timeSeries1.setMaximumItemAge((long) 5);
        timeSeries1.fireSeriesChanged();
        double double6 = timeSeries1.getMinY();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries8.removeChangeListener(seriesChangeListener9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries8.removeChangeListener(seriesChangeListener11);
        java.lang.String str13 = timeSeries8.getRangeDescription();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries8.addChangeListener(seriesChangeListener14);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries8.removePropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) 8);
        long long20 = fixedMillisecond19.getSerialIndex();
        long long21 = fixedMillisecond19.getFirstMillisecond();
        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (java.lang.Number) 2147483647);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
        int int25 = month24.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month24.next();
        int int27 = fixedMillisecond19.compareTo((java.lang.Object) regularTimePeriod26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (double) (short) 100);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener32 = null;
        timeSeries31.removeChangeListener(seriesChangeListener32);
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        int int35 = month34.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = month34.next();
        timeSeries31.setKey((java.lang.Comparable) regularTimePeriod36);
        boolean boolean38 = timeSeries31.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) 8);
        long long41 = fixedMillisecond40.getSerialIndex();
        java.util.Calendar calendar42 = null;
        long long43 = fixedMillisecond40.getMiddleMillisecond(calendar42);
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener46 = null;
        timeSeries45.removeChangeListener(seriesChangeListener46);
        java.util.List list48 = timeSeries45.getItems();
        java.lang.String str49 = timeSeries45.getDescription();
        int int50 = fixedMillisecond40.compareTo((java.lang.Object) str49);
        timeSeries31.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, (java.lang.Number) 0);
        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries1.addAndOrUpdate(timeSeries31);
        try {
            timeSeries1.delete(3, 8, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Value" + "'", str13.equals("Value"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 8L + "'", long20 == 8L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 8L + "'", long21 == 8L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 6 + "'", int35 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 8L + "'", long41 == 8L);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 8L + "'", long43 == 8L);
        org.junit.Assert.assertNotNull(list48);
        org.junit.Assert.assertNull(str49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertNotNull(timeSeries53);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int2 = timeSeries1.getMaximumItemCount();
        timeSeries1.setMaximumItemAge((long) 5);
        timeSeries1.fireSeriesChanged();
        double double6 = timeSeries1.getMinY();
        org.jfree.data.time.TimeSeries timeSeries7 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        timeSeries1.setMaximumItemCount((int) '#');
        java.lang.Class class9 = timeSeries1.getTimePeriodClass();
        timeSeries1.setMaximumItemCount(2147483647);
        timeSeries1.setMaximumItemAge((long) 7);
        try {
            org.jfree.data.time.TimeSeries timeSeries16 = timeSeries1.createCopy((-1), (-9999));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(class9);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int4 = timeSeries3.getMaximumItemCount();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = month5.getMonth();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month7.previous();
        boolean boolean9 = month5.equals((java.lang.Object) month7);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month5, (java.lang.Number) 2147483647, false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month5.previous();
        int int14 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month5);
        java.lang.Object obj15 = null;
        boolean boolean16 = month5.equals(obj15);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2147483647, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int2 = year1.getYear();
        long long3 = year1.getSerialIndex();
        long long4 = year1.getMiddleMillisecond();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(4, year1);
        java.lang.Object obj6 = null;
        int int7 = month5.compareTo(obj6);
        long long8 = month5.getFirstMillisecond();
        java.util.Calendar calendar9 = null;
        try {
            month5.peg(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1562097599999L + "'", long4 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1554102000000L + "'", long8 == 1554102000000L);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int2 = timeSeries1.getMaximumItemCount();
        java.lang.Object obj3 = timeSeries1.clone();
        timeSeries1.setKey((java.lang.Comparable) 1);
        java.util.Collection collection6 = timeSeries1.getTimePeriods();
        int int7 = timeSeries1.getMaximumItemCount();
        long long8 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        int int10 = year9.getYear();
        java.lang.String str11 = year9.toString();
        try {
            timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) 0.0d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9223372036854775807L + "'", long8 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2019" + "'", str11.equals("2019"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int2 = timeSeries1.getMaximumItemCount();
        java.lang.Object obj3 = timeSeries1.clone();
        timeSeries1.setKey((java.lang.Comparable) 1);
        java.util.Collection collection6 = timeSeries1.getTimePeriods();
        timeSeries1.setDescription("10");
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = timeSeries1.getTimePeriod(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection6);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int2 = timeSeries1.getMaximumItemCount();
        java.lang.Object obj3 = timeSeries1.clone();
        timeSeries1.setKey((java.lang.Comparable) 1);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        int int7 = month6.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month6.next();
        int int9 = month6.getMonth();
        int int10 = month6.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month6);
        java.util.Calendar calendar12 = null;
        try {
            long long13 = month6.getFirstMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 8);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries6.removeChangeListener(seriesChangeListener7);
        java.util.List list9 = timeSeries6.getItems();
        java.lang.String str10 = timeSeries6.getDescription();
        int int11 = fixedMillisecond1.compareTo((java.lang.Object) str10);
        java.util.Date date12 = fixedMillisecond1.getStart();
        long long13 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Date date14 = fixedMillisecond1.getTime();
        java.util.TimeZone timeZone15 = null;
        try {
            org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date14, timeZone15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8L + "'", long2 == 8L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 8L + "'", long4 == 8L);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 8L + "'", long13 == 8L);
        org.junit.Assert.assertNotNull(date14);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("hi!");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int2 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getMiddleMillisecond();
        long long5 = year3.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year3, (java.lang.Number) 2147483647);
        int int8 = year3.getYear();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1562097599999L + "'", long4 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "Time", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries6 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries7 = timeSeries3.addAndOrUpdate(timeSeries6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int2 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        int int4 = month3.getMonth();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.previous();
        boolean boolean7 = month3.equals((java.lang.Object) month5);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month3, (java.lang.Number) 2147483647, false);
        int int11 = timeSeries1.getMaximumItemCount();
        timeSeries1.setDomainDescription("10");
        java.lang.Comparable comparable14 = timeSeries1.getKey();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2147483647 + "'", int11 == 2147483647);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + 100L + "'", comparable14.equals(100L));
    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test160");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        int int2 = day0.getDayOfMonth();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = day0.getFirstMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        java.lang.String str8 = timeSeries1.getDescription();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        long long12 = month9.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (double) 1.0f);
        java.lang.Number number15 = timeSeriesDataItem14.getValue();
        timeSeries1.add(timeSeriesDataItem14, true);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries19.removeChangeListener(seriesChangeListener20);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener22 = null;
        timeSeries19.removeChangeListener(seriesChangeListener22);
        boolean boolean24 = timeSeries19.getNotify();
        timeSeries19.setMaximumItemCount((int) '#');
        java.lang.Class class27 = timeSeries19.getTimePeriodClass();
        timeSeries19.setMaximumItemCount(2147483647);
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries1.addAndOrUpdate(timeSeries19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = timeSeries1.getNextTimePeriod();
        java.lang.String str32 = timeSeries1.getDomainDescription();
        try {
            org.jfree.data.time.TimeSeries timeSeries35 = timeSeries1.createCopy((int) (short) 100, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1559372400000L + "'", long12 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 1.0d + "'", number15.equals(1.0d));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(class27);
        org.junit.Assert.assertNotNull(timeSeries30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Time" + "'", str32.equals("Time"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) 8);
        long long8 = fixedMillisecond7.getSerialIndex();
        long long9 = fixedMillisecond7.getFirstMillisecond();
        int int10 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = null;
        try {
            timeSeries1.add(timeSeriesDataItem11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 8L + "'", long8 == 8L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 8L + "'", long9 == 8L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        java.lang.Class class0 = null;
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo2 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1.0f), seriesChangeInfo2);
        java.lang.Class<?> wildcardClass4 = seriesChangeEvent3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date6, timeZone7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        long long12 = month9.getFirstMillisecond();
        java.util.Date date13 = month9.getEnd();
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date13, timeZone14);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date13, timeZone16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date13);
        java.lang.Object obj19 = null;
        boolean boolean20 = day18.equals(obj19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) 8);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year23, (java.lang.Number) 0);
        boolean boolean26 = timeSeriesDataItem25.isSelected();
        boolean boolean27 = fixedMillisecond22.equals((java.lang.Object) timeSeriesDataItem25);
        java.lang.Object obj28 = timeSeriesDataItem25.clone();
        int int29 = day18.compareTo(obj28);
        java.util.Calendar calendar30 = null;
        try {
            day18.peg(calendar30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1559372400000L + "'", long12 == 1559372400000L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        int int7 = month6.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month6.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month6, (double) 10.0f);
        double double11 = timeSeries1.getMaxY();
        try {
            timeSeries1.update((int) (short) 1, (java.lang.Number) 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 10.0d + "'", double11 == 10.0d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, 30, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int2 = timeSeries1.getMaximumItemCount();
        timeSeries1.setMaximumItemAge((long) 5);
        timeSeries1.fireSeriesChanged();
        double double6 = timeSeries1.getMinY();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries8.removeChangeListener(seriesChangeListener9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries8.removeChangeListener(seriesChangeListener11);
        java.lang.String str13 = timeSeries8.getRangeDescription();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries8.addChangeListener(seriesChangeListener14);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries8.removePropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) 8);
        long long20 = fixedMillisecond19.getSerialIndex();
        long long21 = fixedMillisecond19.getFirstMillisecond();
        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (java.lang.Number) 2147483647);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
        int int25 = month24.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month24.next();
        int int27 = fixedMillisecond19.compareTo((java.lang.Object) regularTimePeriod26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (double) (short) 100);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener32 = null;
        timeSeries31.removeChangeListener(seriesChangeListener32);
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        int int35 = month34.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = month34.next();
        timeSeries31.setKey((java.lang.Comparable) regularTimePeriod36);
        boolean boolean38 = timeSeries31.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) 8);
        long long41 = fixedMillisecond40.getSerialIndex();
        java.util.Calendar calendar42 = null;
        long long43 = fixedMillisecond40.getMiddleMillisecond(calendar42);
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener46 = null;
        timeSeries45.removeChangeListener(seriesChangeListener46);
        java.util.List list48 = timeSeries45.getItems();
        java.lang.String str49 = timeSeries45.getDescription();
        int int50 = fixedMillisecond40.compareTo((java.lang.Object) str49);
        timeSeries31.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, (java.lang.Number) 0);
        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries1.addAndOrUpdate(timeSeries31);
        try {
            org.jfree.data.time.TimeSeries timeSeries56 = timeSeries31.createCopy((int) (short) 0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Value" + "'", str13.equals("Value"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 8L + "'", long20 == 8L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 8L + "'", long21 == 8L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 6 + "'", int35 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 8L + "'", long41 == 8L);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 8L + "'", long43 == 8L);
        org.junit.Assert.assertNotNull(list48);
        org.junit.Assert.assertNull(str49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertNotNull(timeSeries53);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.Year year2 = month0.getYear();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = month0.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(year2);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int2 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        int int4 = month3.getMonth();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.previous();
        boolean boolean7 = month3.equals((java.lang.Object) month5);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month3, (java.lang.Number) 2147483647, false);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries12.removeChangeListener(seriesChangeListener13);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries12.removeChangeListener(seriesChangeListener15);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        int int18 = month17.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month17.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month17, (double) 10.0f);
        int int22 = month3.compareTo((java.lang.Object) 10.0f);
        java.lang.String str23 = month3.toString();
        java.util.Calendar calendar24 = null;
        try {
            long long25 = month3.getFirstMillisecond(calendar24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "June 2019" + "'", str23.equals("June 2019"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year7.next();
        int int10 = timeSeries1.getIndex(regularTimePeriod9);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        int int12 = month11.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.next();
        long long14 = month11.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month11, (double) 1.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month11.next();
        try {
            timeSeries1.update((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) 2147483647);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1559372400000L + "'", long14 == 1559372400000L);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (short) 0);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        java.lang.String str8 = timeSeries1.getDescription();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        long long12 = month9.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (double) 1.0f);
        java.lang.Number number15 = timeSeriesDataItem14.getValue();
        timeSeries1.add(timeSeriesDataItem14, true);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries19.removeChangeListener(seriesChangeListener20);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener22 = null;
        timeSeries19.removeChangeListener(seriesChangeListener22);
        boolean boolean24 = timeSeries19.getNotify();
        timeSeries19.setMaximumItemCount((int) '#');
        java.lang.Class class27 = timeSeries19.getTimePeriodClass();
        timeSeries19.setMaximumItemCount(2147483647);
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries1.addAndOrUpdate(timeSeries19);
        try {
            timeSeries30.update((int) (short) 1, (java.lang.Number) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1559372400000L + "'", long12 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 1.0d + "'", number15.equals(1.0d));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(class27);
        org.junit.Assert.assertNotNull(timeSeries30);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = month5.getMonth();
        timeSeries1.setKey((java.lang.Comparable) int6);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        int int9 = month8.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month8.next();
        long long11 = month8.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month8, (double) 1.0f);
        java.lang.Number number14 = timeSeriesDataItem13.getValue();
        timeSeriesDataItem13.setValue((java.lang.Number) 1559372400000L);
        java.lang.Object obj17 = null;
        boolean boolean18 = timeSeriesDataItem13.equals(obj17);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries1.addOrUpdate(timeSeriesDataItem13);
        try {
            boolean boolean20 = timeSeriesDataItem19.isSelected();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1559372400000L + "'", long11 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 1.0d + "'", number14.equals(1.0d));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("10");
        org.junit.Assert.assertNotNull(year1);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getMiddleMillisecond();
        java.util.Date date2 = year0.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year3.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1562097599999L + "'", long1 == 1562097599999L);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        int int5 = month4.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.setKey((java.lang.Comparable) regularTimePeriod6);
        boolean boolean8 = timeSeries1.getNotify();
        java.lang.Comparable comparable9 = timeSeries1.getKey();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(comparable9);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = day0.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        java.lang.Class class0 = null;
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo2 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1.0f), seriesChangeInfo2);
        java.lang.Class<?> wildcardClass4 = seriesChangeEvent3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date6, timeZone7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        long long12 = month9.getFirstMillisecond();
        java.util.Date date13 = month9.getEnd();
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date13, timeZone14);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date13, timeZone16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date13);
        java.lang.Object obj19 = null;
        boolean boolean20 = day18.equals(obj19);
        java.util.Calendar calendar21 = null;
        try {
            day18.peg(calendar21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1559372400000L + "'", long12 == 1559372400000L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) -1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        timeSeries1.setMaximumItemAge((long) '#');
        java.util.List list10 = timeSeries1.getItems();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNotNull(list10);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year7.next();
        int int10 = timeSeries1.getIndex(regularTimePeriod9);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeries1.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        java.lang.Class class0 = null;
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo2 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1.0f), seriesChangeInfo2);
        java.lang.Class<?> wildcardClass4 = seriesChangeEvent3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date6, timeZone7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        long long12 = month9.getFirstMillisecond();
        java.util.Date date13 = month9.getEnd();
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date13, timeZone14);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date13, timeZone16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.next();
        long long20 = day18.getFirstMillisecond();
        java.util.Calendar calendar21 = null;
        try {
            long long22 = day18.getLastMillisecond(calendar21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1559372400000L + "'", long12 == 1559372400000L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1561878000000L + "'", long20 == 1561878000000L);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int2 = year1.getYear();
        long long3 = year1.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year1.next();
        try {
            org.jfree.data.time.Month month5 = new org.jfree.data.time.Month((int) '#', year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 8);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries6.removeChangeListener(seriesChangeListener7);
        java.util.List list9 = timeSeries6.getItems();
        java.lang.String str10 = timeSeries6.getDescription();
        int int11 = fixedMillisecond1.compareTo((java.lang.Object) str10);
        java.util.Date date12 = fixedMillisecond1.getStart();
        long long13 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Date date14 = fixedMillisecond1.getTime();
        java.util.TimeZone timeZone15 = null;
        java.util.Locale locale16 = null;
        try {
            org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date14, timeZone15, locale16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8L + "'", long2 == 8L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 8L + "'", long4 == 8L);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 8L + "'", long13 == 8L);
        org.junit.Assert.assertNotNull(date14);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int2 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        int int4 = month3.getMonth();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.previous();
        boolean boolean7 = month3.equals((java.lang.Object) month5);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month3, (java.lang.Number) 2147483647, false);
        int int11 = timeSeries1.getMaximumItemCount();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo12 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent13 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries1, seriesChangeInfo12);
        java.lang.String str14 = seriesChangeEvent13.toString();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2147483647 + "'", int11 == 2147483647);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int2 = timeSeries1.getMaximumItemCount();
        timeSeries1.setMaximumItemAge((long) 5);
        timeSeries1.fireSeriesChanged();
        double double6 = timeSeries1.getMinY();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries8.removeChangeListener(seriesChangeListener9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries8.removeChangeListener(seriesChangeListener11);
        java.lang.String str13 = timeSeries8.getRangeDescription();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries8.addChangeListener(seriesChangeListener14);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries8.removePropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) 8);
        long long20 = fixedMillisecond19.getSerialIndex();
        long long21 = fixedMillisecond19.getFirstMillisecond();
        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (java.lang.Number) 2147483647);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
        int int25 = month24.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month24.next();
        int int27 = fixedMillisecond19.compareTo((java.lang.Object) regularTimePeriod26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (double) (short) 100);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener32 = null;
        timeSeries31.removeChangeListener(seriesChangeListener32);
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        int int35 = month34.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = month34.next();
        timeSeries31.setKey((java.lang.Comparable) regularTimePeriod36);
        boolean boolean38 = timeSeries31.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) 8);
        long long41 = fixedMillisecond40.getSerialIndex();
        java.util.Calendar calendar42 = null;
        long long43 = fixedMillisecond40.getMiddleMillisecond(calendar42);
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener46 = null;
        timeSeries45.removeChangeListener(seriesChangeListener46);
        java.util.List list48 = timeSeries45.getItems();
        java.lang.String str49 = timeSeries45.getDescription();
        int int50 = fixedMillisecond40.compareTo((java.lang.Object) str49);
        timeSeries31.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, (java.lang.Number) 0);
        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries1.addAndOrUpdate(timeSeries31);
        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener56 = null;
        timeSeries55.removeChangeListener(seriesChangeListener56);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener58 = null;
        timeSeries55.removeChangeListener(seriesChangeListener58);
        java.lang.String str60 = timeSeries55.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond62 = new org.jfree.data.time.FixedMillisecond((long) 8);
        timeSeries55.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond62, (java.lang.Number) (-1.0d));
        long long65 = fixedMillisecond62.getSerialIndex();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond62, (double) (short) 0, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period Wed Dec 31 16:00:00 PST 1969 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Value" + "'", str13.equals("Value"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 8L + "'", long20 == 8L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 8L + "'", long21 == 8L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 6 + "'", int35 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 8L + "'", long41 == 8L);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 8L + "'", long43 == 8L);
        org.junit.Assert.assertNotNull(list48);
        org.junit.Assert.assertNull(str49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertNotNull(timeSeries53);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "Value" + "'", str60.equals("Value"));
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 8L + "'", long65 == 8L);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        timeSeries1.setMaximumItemAge((long) '#');
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        int int11 = year10.getYear();
        java.lang.String str12 = year10.toString();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        int int14 = month13.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month13.next();
        long long16 = month13.getFirstMillisecond();
        long long17 = month13.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year10, (org.jfree.data.time.RegularTimePeriod) month13);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        long long20 = year19.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year19, (double) 100L);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries24.removeChangeListener(seriesChangeListener25);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener27 = null;
        timeSeries24.removeChangeListener(seriesChangeListener27);
        boolean boolean29 = timeSeries24.getNotify();
        timeSeries24.setMaximumItemCount((int) '#');
        java.lang.Class class32 = timeSeries24.getTimePeriodClass();
        timeSeries24.setMaximumItemCount(2147483647);
        timeSeries24.setMaximumItemAge((long) 7);
        timeSeries24.setRangeDescription("");
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries1.addAndOrUpdate(timeSeries24);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries39.getDataItem((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1559372400000L + "'", long16 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1559372400000L + "'", long17 == 1559372400000L);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1562097599999L + "'", long20 == 1562097599999L);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNull(class32);
        org.junit.Assert.assertNotNull(timeSeries39);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int2 = year1.getYear();
        long long3 = year1.getSerialIndex();
        long long4 = year1.getMiddleMillisecond();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(4, year1);
        long long6 = month5.getFirstMillisecond();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = month5.getMiddleMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1562097599999L + "'", long4 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1554102000000L + "'", long6 == 1554102000000L);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        java.lang.Class class0 = null;
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo2 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1.0f), seriesChangeInfo2);
        java.lang.Class<?> wildcardClass4 = seriesChangeEvent3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date6, timeZone7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        long long12 = month9.getFirstMillisecond();
        java.util.Date date13 = month9.getEnd();
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date13, timeZone14);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date13, timeZone16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.next();
        org.jfree.data.time.SerialDate serialDate20 = day18.getSerialDate();
        java.lang.String str21 = day18.toString();
        long long22 = day18.getFirstMillisecond();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1559372400000L + "'", long12 == 1559372400000L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "30-June-2019" + "'", str21.equals("30-June-2019"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1561878000000L + "'", long22 == 1561878000000L);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        java.lang.String str8 = timeSeries1.getDescription();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        long long12 = month9.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (double) 1.0f);
        java.lang.Number number15 = timeSeriesDataItem14.getValue();
        timeSeries1.add(timeSeriesDataItem14, true);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries19.removeChangeListener(seriesChangeListener20);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener22 = null;
        timeSeries19.removeChangeListener(seriesChangeListener22);
        boolean boolean24 = timeSeries19.getNotify();
        timeSeries19.setMaximumItemCount((int) '#');
        java.lang.Class class27 = timeSeries19.getTimePeriodClass();
        timeSeries19.setMaximumItemCount(2147483647);
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries1.addAndOrUpdate(timeSeries19);
        boolean boolean31 = timeSeries19.isEmpty();
        timeSeries19.setNotify(true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1559372400000L + "'", long12 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 1.0d + "'", number15.equals(1.0d));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(class27);
        org.junit.Assert.assertNotNull(timeSeries30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        java.lang.String str8 = timeSeries1.getDescription();
        int int9 = timeSeries1.getMaximumItemCount();
        boolean boolean10 = timeSeries1.getNotify();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2147483647 + "'", int9 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        long long3 = month0.getFirstMillisecond();
        long long4 = month0.getFirstMillisecond();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = month0.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1559372400000L + "'", long3 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1559372400000L + "'", long4 == 1559372400000L);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int2 = timeSeries1.getMaximumItemCount();
        java.lang.Object obj3 = timeSeries1.clone();
        timeSeries1.setKey((java.lang.Comparable) 1);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = timeSeries1.getTimePeriod(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = month5.getMonth();
        timeSeries1.setKey((java.lang.Comparable) int6);
        try {
            timeSeries1.update(35, (java.lang.Number) 30);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Time");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        java.lang.Class class0 = null;
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo2 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1.0f), seriesChangeInfo2);
        java.lang.Class<?> wildcardClass4 = seriesChangeEvent3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date6, timeZone7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        long long12 = month9.getFirstMillisecond();
        java.util.Date date13 = month9.getEnd();
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date13, timeZone14);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date13, timeZone16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.next();
        org.jfree.data.time.SerialDate serialDate20 = day18.getSerialDate();
        java.util.Calendar calendar21 = null;
        try {
            long long22 = day18.getLastMillisecond(calendar21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1559372400000L + "'", long12 == 1559372400000L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(serialDate20);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries(comparable0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        timeSeries1.setMaximumItemAge((long) '#');
        boolean boolean10 = timeSeries1.isEmpty();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        timeSeries1.setMaximumItemCount((int) '#');
        org.jfree.data.time.TimeSeries timeSeries9 = null;
        try {
            java.util.Collection collection10 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        java.lang.String str6 = timeSeries1.getRangeDescription();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries1.addChangeListener(seriesChangeListener7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        long long12 = month9.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (double) 1.0f);
        java.lang.Number number15 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) month9);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries17.removeChangeListener(seriesChangeListener18);
        java.util.List list20 = timeSeries17.getItems();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
        int int22 = month21.getMonth();
        timeSeries17.setKey((java.lang.Comparable) int22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        int int25 = year24.getYear();
        long long26 = year24.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year24.next();
        timeSeries17.delete((org.jfree.data.time.RegularTimePeriod) year24);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year24, (java.lang.Number) 11);
        long long31 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        long long33 = year32.getFirstMillisecond();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year32, (java.lang.Number) 0, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period 2019 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1559372400000L + "'", long12 == 1559372400000L);
        org.junit.Assert.assertNull(number15);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2019 + "'", int25 == 2019);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 2019L + "'", long26 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 9223372036854775807L + "'", long31 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1546329600000L + "'", long33 == 1546329600000L);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(10);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year5, (double) (byte) 1, true);
        java.lang.Object obj9 = null;
        boolean boolean10 = timeSeries1.equals(obj9);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        int int12 = month11.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.next();
        long long14 = month11.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month11, (double) 1.0f);
        java.lang.Number number17 = timeSeriesDataItem16.getValue();
        java.lang.Number number18 = timeSeriesDataItem16.getValue();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        int int20 = month19.getMonth();
        int int21 = month19.getYearValue();
        int int22 = month19.getYearValue();
        int int23 = timeSeriesDataItem16.compareTo((java.lang.Object) month19);
        try {
            timeSeries1.add(timeSeriesDataItem16);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1559372400000L + "'", long14 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 1.0d + "'", number17.equals(1.0d));
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 1.0d + "'", number18.equals(1.0d));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        timeSeries1.setMaximumItemAge((long) '#');
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        int int11 = year10.getYear();
        java.lang.String str12 = year10.toString();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        int int14 = month13.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month13.next();
        long long16 = month13.getFirstMillisecond();
        long long17 = month13.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year10, (org.jfree.data.time.RegularTimePeriod) month13);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        long long20 = year19.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year19, (double) 100L);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries24.removeChangeListener(seriesChangeListener25);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener27 = null;
        timeSeries24.removeChangeListener(seriesChangeListener27);
        boolean boolean29 = timeSeries24.getNotify();
        timeSeries24.setMaximumItemCount((int) '#');
        java.lang.Class class32 = timeSeries24.getTimePeriodClass();
        timeSeries24.setMaximumItemCount(2147483647);
        timeSeries24.setMaximumItemAge((long) 7);
        timeSeries24.setRangeDescription("");
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries1.addAndOrUpdate(timeSeries24);
        try {
            timeSeries39.setMaximumItemAge((long) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'periods' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1559372400000L + "'", long16 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1559372400000L + "'", long17 == 1559372400000L);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1562097599999L + "'", long20 == 1562097599999L);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNull(class32);
        org.junit.Assert.assertNotNull(timeSeries39);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (double) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int2 = timeSeries1.getMaximumItemCount();
        timeSeries1.setMaximumItemAge((long) 5);
        timeSeries1.fireSeriesChanged();
        double double6 = timeSeries1.getMinY();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries8.removeChangeListener(seriesChangeListener9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries8.removeChangeListener(seriesChangeListener11);
        java.lang.String str13 = timeSeries8.getRangeDescription();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries8.addChangeListener(seriesChangeListener14);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries8.removePropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) 8);
        long long20 = fixedMillisecond19.getSerialIndex();
        long long21 = fixedMillisecond19.getFirstMillisecond();
        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (java.lang.Number) 2147483647);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
        int int25 = month24.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month24.next();
        int int27 = fixedMillisecond19.compareTo((java.lang.Object) regularTimePeriod26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (double) (short) 100);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener32 = null;
        timeSeries31.removeChangeListener(seriesChangeListener32);
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        int int35 = month34.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = month34.next();
        timeSeries31.setKey((java.lang.Comparable) regularTimePeriod36);
        boolean boolean38 = timeSeries31.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) 8);
        long long41 = fixedMillisecond40.getSerialIndex();
        java.util.Calendar calendar42 = null;
        long long43 = fixedMillisecond40.getMiddleMillisecond(calendar42);
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener46 = null;
        timeSeries45.removeChangeListener(seriesChangeListener46);
        java.util.List list48 = timeSeries45.getItems();
        java.lang.String str49 = timeSeries45.getDescription();
        int int50 = fixedMillisecond40.compareTo((java.lang.Object) str49);
        timeSeries31.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, (java.lang.Number) 0);
        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries1.addAndOrUpdate(timeSeries31);
        timeSeries1.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener58 = null;
        timeSeries57.removeChangeListener(seriesChangeListener58);
        org.jfree.data.time.Month month60 = new org.jfree.data.time.Month();
        int int61 = month60.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = month60.next();
        timeSeries57.setKey((java.lang.Comparable) regularTimePeriod62);
        boolean boolean64 = timeSeries57.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond66 = new org.jfree.data.time.FixedMillisecond((long) 8);
        long long67 = fixedMillisecond66.getSerialIndex();
        java.util.Calendar calendar68 = null;
        long long69 = fixedMillisecond66.getMiddleMillisecond(calendar68);
        org.jfree.data.time.TimeSeries timeSeries71 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener72 = null;
        timeSeries71.removeChangeListener(seriesChangeListener72);
        java.util.List list74 = timeSeries71.getItems();
        java.lang.String str75 = timeSeries71.getDescription();
        int int76 = fixedMillisecond66.compareTo((java.lang.Object) str75);
        timeSeries57.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond66, (java.lang.Number) 0);
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond66, (java.lang.Number) 10);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period Wed Dec 31 16:00:00 PST 1969 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Value" + "'", str13.equals("Value"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 8L + "'", long20 == 8L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 8L + "'", long21 == 8L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 6 + "'", int35 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 8L + "'", long41 == 8L);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 8L + "'", long43 == 8L);
        org.junit.Assert.assertNotNull(list48);
        org.junit.Assert.assertNull(str49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertNotNull(timeSeries53);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 6 + "'", int61 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 8L + "'", long67 == 8L);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 8L + "'", long69 == 8L);
        org.junit.Assert.assertNotNull(list74);
        org.junit.Assert.assertNull(str75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 1 + "'", int76 == 1);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getMiddleMillisecond();
        long long2 = year0.getFirstMillisecond();
        long long3 = year0.getSerialIndex();
        java.lang.String str4 = year0.toString();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year0.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1562097599999L + "'", long1 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        timeSeries1.setMaximumItemAge((long) '#');
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        int int11 = year10.getYear();
        java.lang.String str12 = year10.toString();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        int int14 = month13.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month13.next();
        long long16 = month13.getFirstMillisecond();
        long long17 = month13.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year10, (org.jfree.data.time.RegularTimePeriod) month13);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        long long20 = year19.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year19, (double) 100L);
        timeSeries1.setDomainDescription("2019");
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1559372400000L + "'", long16 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1559372400000L + "'", long17 == 1559372400000L);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1562097599999L + "'", long20 == 1562097599999L);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        long long3 = month0.getFirstMillisecond();
        java.util.Date date4 = month0.getEnd();
        int int5 = month0.getMonth();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = month0.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1559372400000L + "'", long3 == 1559372400000L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        long long3 = month0.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) 1.0f);
        java.lang.Number number6 = timeSeriesDataItem5.getValue();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int9 = timeSeries8.getMaximumItemCount();
        java.lang.Object obj10 = timeSeries8.clone();
        timeSeries8.setKey((java.lang.Comparable) 1);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        int int14 = month13.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month13.next();
        int int16 = month13.getMonth();
        int int17 = month13.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries8.getDataItem((org.jfree.data.time.RegularTimePeriod) month13);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year19.next();
        timeSeries8.add(regularTimePeriod20, (-1.0d), true);
        boolean boolean24 = timeSeriesDataItem5.equals((java.lang.Object) (-1.0d));
        java.lang.Object obj25 = timeSeriesDataItem5.clone();
        java.lang.Number number26 = timeSeriesDataItem5.getValue();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1559372400000L + "'", long3 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1.0d + "'", number6.equals(1.0d));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2147483647 + "'", int9 == 2147483647);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 1.0d + "'", number26.equals(1.0d));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = month5.getMonth();
        timeSeries1.setKey((java.lang.Comparable) int6);
        timeSeries1.setMaximumItemCount(0);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        java.lang.Class class0 = null;
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo2 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1.0f), seriesChangeInfo2);
        java.lang.Class<?> wildcardClass4 = seriesChangeEvent3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date6, timeZone7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        long long12 = month9.getFirstMillisecond();
        java.util.Date date13 = month9.getEnd();
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date13, timeZone14);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date13, timeZone16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.next();
        org.jfree.data.time.SerialDate serialDate20 = day18.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day18.previous();
        int int22 = day18.getMonth();
        int int23 = day18.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate24 = day18.getSerialDate();
        java.util.Calendar calendar25 = null;
        try {
            long long26 = day18.getFirstMillisecond(calendar25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1559372400000L + "'", long12 == 1559372400000L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 30 + "'", int23 == 30);
        org.junit.Assert.assertNotNull(serialDate24);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) 'a', 0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year0.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("10");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 5");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        int int2 = month0.getYearValue();
        org.jfree.data.time.Year year3 = month0.getYear();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year3.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(year3);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int5 = timeSeries4.getMaximumItemCount();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        int int7 = month6.getMonth();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month8.previous();
        boolean boolean10 = month6.equals((java.lang.Object) month8);
        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) 2147483647, false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month6.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) 0.0f);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent18 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 6);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo19 = null;
        seriesChangeEvent18.setSummary(seriesChangeInfo19);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo21 = null;
        seriesChangeEvent18.setSummary(seriesChangeInfo21);
        boolean boolean23 = timeSeries1.equals((java.lang.Object) seriesChangeInfo21);
        try {
            timeSeries1.delete((int) (short) 1, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int2 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        int int4 = month3.getMonth();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.previous();
        boolean boolean7 = month3.equals((java.lang.Object) month5);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month3, (java.lang.Number) 2147483647, false);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries12.removeChangeListener(seriesChangeListener13);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries12.removeChangeListener(seriesChangeListener15);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        int int18 = month17.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month17.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month17, (double) 10.0f);
        int int22 = month3.compareTo((java.lang.Object) 10.0f);
        int int23 = month3.getMonth();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(11, (int) (short) 10, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, 8);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = month2.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int2 = timeSeries1.getMaximumItemCount();
        java.lang.Object obj3 = timeSeries1.clone();
        timeSeries1.setKey((java.lang.Comparable) 1);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        int int7 = month6.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month6.next();
        int int9 = month6.getMonth();
        int int10 = month6.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month6);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.next();
        timeSeries1.add(regularTimePeriod13, (-1.0d), true);
        long long17 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries19.removeChangeListener(seriesChangeListener20);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(10);
        timeSeries19.add((org.jfree.data.time.RegularTimePeriod) year23, (double) (byte) 1, true);
        int int27 = timeSeries19.getMaximumItemCount();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(10);
        timeSeries19.delete((org.jfree.data.time.RegularTimePeriod) year29);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) year29);
        java.lang.String str32 = timeSeries1.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener35 = null;
        timeSeries34.removeChangeListener(seriesChangeListener35);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener37 = null;
        timeSeries34.removeChangeListener(seriesChangeListener37);
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month();
        int int40 = month39.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = month39.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries34.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month39, (double) 10.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries45 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month39, regularTimePeriod44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'end' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 9223372036854775807L + "'", long17 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2147483647 + "'", int27 == 2147483647);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Value" + "'", str32.equals("Value"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 6 + "'", int40 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNull(timeSeriesDataItem43);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        java.lang.String str8 = timeSeries1.getDescription();
        int int9 = timeSeries1.getItemCount();
        boolean boolean11 = timeSeries1.equals((java.lang.Object) "");
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getMiddleMillisecond();
        java.util.Date date2 = year0.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year3.previous();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1562097599999L + "'", long1 == 1562097599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("May -1");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int4 = timeSeries3.getMaximumItemCount();
        java.lang.Object obj5 = timeSeries3.clone();
        timeSeries3.setDescription("Time");
        boolean boolean8 = month1.equals((java.lang.Object) "Time");
        int int9 = month1.getYearValue();
        org.junit.Assert.assertNotNull(month1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Time");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        int int2 = month0.getYearValue();
        long long3 = month0.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) 1562097599999L);
        java.util.Calendar calendar6 = null;
        try {
            month0.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 24234L + "'", long3 == 24234L);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("May -1");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month1.previous();
        org.junit.Assert.assertNotNull(month1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        int int5 = month4.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.setKey((java.lang.Comparable) regularTimePeriod6);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries1.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int12 = timeSeries11.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        int int14 = month13.getMonth();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = month15.previous();
        boolean boolean17 = month13.equals((java.lang.Object) month15);
        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) month13, (java.lang.Number) 2147483647, false);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener23 = null;
        timeSeries22.removeChangeListener(seriesChangeListener23);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries22.removeChangeListener(seriesChangeListener25);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        int int28 = month27.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month27.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries22.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month27, (double) 10.0f);
        int int32 = month13.compareTo((java.lang.Object) 10.0f);
        java.lang.String str33 = month13.toString();
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int36 = timeSeries35.getMaximumItemCount();
        boolean boolean37 = month13.equals((java.lang.Object) int36);
        org.jfree.data.time.Year year38 = month13.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year38, (java.lang.Number) 12);
        timeSeries1.setDescription("May -1");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2147483647 + "'", int12 == 2147483647);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNull(timeSeriesDataItem31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "June 2019" + "'", str33.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2147483647 + "'", int36 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(year38);
        org.junit.Assert.assertNull(timeSeriesDataItem40);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        timeSeries1.setMaximumItemCount((int) '#');
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries10.removeChangeListener(seriesChangeListener11);
        java.util.List list13 = timeSeries10.getItems();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        int int15 = month14.getMonth();
        timeSeries10.setKey((java.lang.Comparable) int15);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        int int18 = month17.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month17.next();
        long long20 = month17.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month17, (double) 1.0f);
        java.lang.Number number23 = timeSeriesDataItem22.getValue();
        timeSeriesDataItem22.setValue((java.lang.Number) 1559372400000L);
        java.lang.Object obj26 = null;
        boolean boolean27 = timeSeriesDataItem22.equals(obj26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries10.addOrUpdate(timeSeriesDataItem22);
        try {
            timeSeries1.add(timeSeriesDataItem28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1559372400000L + "'", long20 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 1.0d + "'", number23.equals(1.0d));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem28);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        long long3 = month0.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries5.removeChangeListener(seriesChangeListener6);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries5.removeChangeListener(seriesChangeListener8);
        java.lang.String str10 = timeSeries5.getRangeDescription();
        int int11 = month0.compareTo((java.lang.Object) timeSeries5);
        double double12 = timeSeries5.getMaxY();
        boolean boolean13 = timeSeries5.isEmpty();
        java.lang.Class class14 = null;
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo16 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent17 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1.0f), seriesChangeInfo16);
        java.lang.Class<?> wildcardClass18 = seriesChangeEvent17.getClass();
        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass18);
        java.util.Date date20 = null;
        java.util.TimeZone timeZone21 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date20, timeZone21);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        int int24 = month23.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = month23.next();
        long long26 = month23.getFirstMillisecond();
        java.util.Date date27 = month23.getEnd();
        java.util.TimeZone timeZone28 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date27, timeZone28);
        java.util.TimeZone timeZone30 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date27, timeZone30);
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date27);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day32.next();
        org.jfree.data.time.SerialDate serialDate34 = day32.getSerialDate();
        java.lang.String str35 = day32.toString();
        int int36 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) day32);
        java.util.Calendar calendar37 = null;
        try {
            day32.peg(calendar37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1559372400000L + "'", long3 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Value" + "'", str10.equals("Value"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(class19);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 6 + "'", int24 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1559372400000L + "'", long26 == 1559372400000L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "30-June-2019" + "'", str35.equals("30-June-2019"));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 8);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries6.removeChangeListener(seriesChangeListener7);
        java.util.List list9 = timeSeries6.getItems();
        java.lang.String str10 = timeSeries6.getDescription();
        int int11 = fixedMillisecond1.compareTo((java.lang.Object) str10);
        long long12 = fixedMillisecond1.getLastMillisecond();
        long long13 = fixedMillisecond1.getMiddleMillisecond();
        java.lang.Object obj14 = null;
        boolean boolean15 = fixedMillisecond1.equals(obj14);
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond1.getFirstMillisecond(calendar16);
        long long18 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8L + "'", long2 == 8L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 8L + "'", long4 == 8L);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 8L + "'", long12 == 8L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 8L + "'", long13 == 8L);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 8L + "'", long17 == 8L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 8L + "'", long18 == 8L);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        java.lang.Class class0 = null;
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo2 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1.0f), seriesChangeInfo2);
        java.lang.Class<?> wildcardClass4 = seriesChangeEvent3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date6, timeZone7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        long long12 = month9.getFirstMillisecond();
        java.util.Date date13 = month9.getEnd();
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date13, timeZone14);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date13, timeZone16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.next();
        org.jfree.data.time.SerialDate serialDate20 = day18.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day18.previous();
        int int22 = day18.getMonth();
        int int23 = day18.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate24 = day18.getSerialDate();
        long long25 = day18.getFirstMillisecond();
        int int26 = day18.getDayOfMonth();
        java.util.Calendar calendar27 = null;
        try {
            long long28 = day18.getFirstMillisecond(calendar27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1559372400000L + "'", long12 == 1559372400000L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 30 + "'", int23 == 30);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1561878000000L + "'", long25 == 1561878000000L);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 30 + "'", int26 == 30);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        java.lang.Class class0 = null;
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo2 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1.0f), seriesChangeInfo2);
        java.lang.Class<?> wildcardClass4 = seriesChangeEvent3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date6, timeZone7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        long long12 = month9.getFirstMillisecond();
        java.util.Date date13 = month9.getEnd();
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date13, timeZone14);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date13, timeZone16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date13);
        java.lang.Object obj19 = null;
        boolean boolean20 = day18.equals(obj19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) 8);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year23, (java.lang.Number) 0);
        boolean boolean26 = timeSeriesDataItem25.isSelected();
        boolean boolean27 = fixedMillisecond22.equals((java.lang.Object) timeSeriesDataItem25);
        java.lang.Object obj28 = timeSeriesDataItem25.clone();
        int int29 = day18.compareTo(obj28);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day18.previous();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1559372400000L + "'", long12 == 1559372400000L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 8);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Date date3 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        java.util.Calendar calendar5 = null;
        try {
            year4.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8L + "'", long2 == 8L);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("10");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("10");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        timeSeries1.setMaximumItemAge((long) '#');
        timeSeries1.removeAgedItems(false);
        java.util.Collection collection12 = timeSeries1.getTimePeriods();
        timeSeries1.clear();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNotNull(collection12);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        int int7 = month6.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month6.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month6, (double) 10.0f);
        try {
            java.lang.Number number12 = timeSeries1.getValue(7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        java.lang.String str8 = timeSeries1.getDescription();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        long long12 = month9.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (double) 1.0f);
        java.lang.Number number15 = timeSeriesDataItem14.getValue();
        timeSeries1.add(timeSeriesDataItem14, true);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries19.removeChangeListener(seriesChangeListener20);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener22 = null;
        timeSeries19.removeChangeListener(seriesChangeListener22);
        boolean boolean24 = timeSeries19.getNotify();
        timeSeries19.setMaximumItemCount((int) '#');
        java.lang.Class class27 = timeSeries19.getTimePeriodClass();
        timeSeries19.setMaximumItemCount(2147483647);
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries1.addAndOrUpdate(timeSeries19);
        java.lang.String str31 = timeSeries1.getRangeDescription();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1559372400000L + "'", long12 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 1.0d + "'", number15.equals(1.0d));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(class27);
        org.junit.Assert.assertNotNull(timeSeries30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Value" + "'", str31.equals("Value"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        java.lang.String str6 = timeSeries1.getRangeDescription();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries1.addChangeListener(seriesChangeListener7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        long long12 = month9.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (double) 1.0f);
        java.lang.Number number15 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) month9);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries17.removeChangeListener(seriesChangeListener18);
        java.util.List list20 = timeSeries17.getItems();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
        int int22 = month21.getMonth();
        timeSeries17.setKey((java.lang.Comparable) int22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        int int25 = year24.getYear();
        long long26 = year24.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year24.next();
        timeSeries17.delete((org.jfree.data.time.RegularTimePeriod) year24);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year24, (java.lang.Number) 11);
        timeSeries1.setDescription("Time");
        try {
            java.lang.Number number34 = timeSeries1.getValue((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1559372400000L + "'", long12 == 1559372400000L);
        org.junit.Assert.assertNull(number15);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2019 + "'", int25 == 2019);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 2019L + "'", long26 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        long long3 = month0.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) 1.0f);
        java.lang.Number number6 = timeSeriesDataItem5.getValue();
        timeSeriesDataItem5.setValue((java.lang.Number) 1559372400000L);
        java.lang.Object obj9 = null;
        boolean boolean10 = timeSeriesDataItem5.equals(obj9);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries12.removeChangeListener(seriesChangeListener13);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries12.removeChangeListener(seriesChangeListener15);
        boolean boolean17 = timeSeries12.getNotify();
        java.lang.Class class18 = timeSeries12.getTimePeriodClass();
        int int19 = timeSeriesDataItem5.compareTo((java.lang.Object) timeSeries12);
        long long20 = timeSeries12.getMaximumItemAge();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1559372400000L + "'", long3 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1.0d + "'", number6.equals(1.0d));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(class18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 9223372036854775807L + "'", long20 == 9223372036854775807L);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        int int7 = month6.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month6.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month6, (double) 10.0f);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries12.removeChangeListener(seriesChangeListener13);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries12.removeChangeListener(seriesChangeListener15);
        boolean boolean17 = timeSeries12.getNotify();
        java.lang.Class class18 = timeSeries12.getTimePeriodClass();
        java.lang.String str19 = timeSeries12.getDescription();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        int int21 = month20.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month20.next();
        long long23 = month20.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month20, (double) 1.0f);
        java.lang.Number number26 = timeSeriesDataItem25.getValue();
        timeSeries12.add(timeSeriesDataItem25, true);
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener31 = null;
        timeSeries30.removeChangeListener(seriesChangeListener31);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener33 = null;
        timeSeries30.removeChangeListener(seriesChangeListener33);
        boolean boolean35 = timeSeries30.getNotify();
        timeSeries30.setMaximumItemCount((int) '#');
        java.lang.Class class38 = timeSeries30.getTimePeriodClass();
        timeSeries30.setMaximumItemCount(2147483647);
        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries12.addAndOrUpdate(timeSeries30);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        long long43 = year42.getMiddleMillisecond();
        timeSeries41.add((org.jfree.data.time.RegularTimePeriod) year42, (double) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = year42.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = year42.next();
        java.lang.Class class48 = null;
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo50 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent51 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1.0f), seriesChangeInfo50);
        java.lang.Class<?> wildcardClass52 = seriesChangeEvent51.getClass();
        java.lang.Class class53 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass52);
        java.util.Date date54 = null;
        java.util.TimeZone timeZone55 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass52, date54, timeZone55);
        org.jfree.data.time.Month month57 = new org.jfree.data.time.Month();
        int int58 = month57.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = month57.next();
        long long60 = month57.getFirstMillisecond();
        java.util.Date date61 = month57.getEnd();
        java.util.TimeZone timeZone62 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass52, date61, timeZone62);
        java.util.TimeZone timeZone64 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance(class48, date61, timeZone64);
        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day(date61);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = day66.next();
        org.jfree.data.time.SerialDate serialDate68 = day66.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = day66.previous();
        org.jfree.data.time.TimeSeries timeSeries70 = timeSeries1.createCopy(regularTimePeriod47, regularTimePeriod69);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(class18);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1559372400000L + "'", long23 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 1.0d + "'", number26.equals(1.0d));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNull(class38);
        org.junit.Assert.assertNotNull(timeSeries41);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1562097599999L + "'", long43 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(wildcardClass52);
        org.junit.Assert.assertNotNull(class53);
        org.junit.Assert.assertNull(regularTimePeriod56);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 6 + "'", int58 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod59);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1559372400000L + "'", long60 == 1559372400000L);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNull(regularTimePeriod63);
        org.junit.Assert.assertNull(regularTimePeriod65);
        org.junit.Assert.assertNotNull(regularTimePeriod67);
        org.junit.Assert.assertNotNull(serialDate68);
        org.junit.Assert.assertNotNull(regularTimePeriod69);
        org.junit.Assert.assertNotNull(timeSeries70);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        int int5 = month4.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.setKey((java.lang.Comparable) regularTimePeriod6);
        try {
            timeSeries1.setMaximumItemAge((long) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'periods' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        java.lang.Class class0 = null;
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo2 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1.0f), seriesChangeInfo2);
        java.lang.Class<?> wildcardClass4 = seriesChangeEvent3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date6, timeZone7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        long long12 = month9.getFirstMillisecond();
        java.util.Date date13 = month9.getEnd();
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date13, timeZone14);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date13, timeZone16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.next();
        org.jfree.data.time.SerialDate serialDate20 = day18.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day18.previous();
        int int22 = day18.getMonth();
        int int23 = day18.getDayOfMonth();
        long long24 = day18.getFirstMillisecond();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1559372400000L + "'", long12 == 1559372400000L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 30 + "'", int23 == 30);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1561878000000L + "'", long24 == 1561878000000L);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        timeSeries1.setMaximumItemAge((long) '#');
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        int int11 = year10.getYear();
        java.lang.String str12 = year10.toString();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        int int14 = month13.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month13.next();
        long long16 = month13.getFirstMillisecond();
        long long17 = month13.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year10, (org.jfree.data.time.RegularTimePeriod) month13);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener21 = null;
        timeSeries20.removeChangeListener(seriesChangeListener21);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener23 = null;
        timeSeries20.removeChangeListener(seriesChangeListener23);
        boolean boolean25 = timeSeries20.getNotify();
        java.lang.Class class26 = timeSeries20.getTimePeriodClass();
        java.lang.String str27 = timeSeries20.getDescription();
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
        int int29 = month28.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month28.next();
        long long31 = month28.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month28, (double) 1.0f);
        java.lang.Number number34 = timeSeriesDataItem33.getValue();
        timeSeries20.add(timeSeriesDataItem33, true);
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener39 = null;
        timeSeries38.removeChangeListener(seriesChangeListener39);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener41 = null;
        timeSeries38.removeChangeListener(seriesChangeListener41);
        boolean boolean43 = timeSeries38.getNotify();
        timeSeries38.setMaximumItemCount((int) '#');
        java.lang.Class class46 = timeSeries38.getTimePeriodClass();
        timeSeries38.setMaximumItemCount(2147483647);
        org.jfree.data.time.TimeSeries timeSeries49 = timeSeries20.addAndOrUpdate(timeSeries38);
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        long long51 = year50.getMiddleMillisecond();
        timeSeries49.add((org.jfree.data.time.RegularTimePeriod) year50, (double) 6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem55 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year50, (double) 4);
        java.util.Collection collection56 = timeSeries1.getTimePeriods();
        timeSeries1.setNotify(true);
        try {
            timeSeries1.delete(35, (int) (byte) 1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1559372400000L + "'", long16 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1559372400000L + "'", long17 == 1559372400000L);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNull(class26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1559372400000L + "'", long31 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + number34 + "' != '" + 1.0d + "'", number34.equals(1.0d));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNull(class46);
        org.junit.Assert.assertNotNull(timeSeries49);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1562097599999L + "'", long51 == 1562097599999L);
        org.junit.Assert.assertNull(timeSeriesDataItem55);
        org.junit.Assert.assertNotNull(collection56);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.getDataItem(5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        timeSeries1.clear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) 8);
        java.lang.Number number5 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4);
        long long6 = fixedMillisecond4.getSerialIndex();
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 8L + "'", long6 == 8L);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(10);
        java.lang.String str2 = year1.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (java.lang.Number) 100);
        java.util.Date date5 = year1.getStart();
        java.util.TimeZone timeZone6 = null;
        try {
            org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date5, timeZone6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10" + "'", str2.equals("10"));
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        int int2 = month0.getYearValue();
        int int3 = month0.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month0.previous();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        timeSeries1.setMaximumItemCount((int) '#');
        java.lang.Class class9 = timeSeries1.getTimePeriodClass();
        java.util.List list10 = timeSeries1.getItems();
        java.lang.Comparable comparable11 = timeSeries1.getKey();
        int int12 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = null;
        try {
            timeSeries1.add(regularTimePeriod13, (java.lang.Number) 1554102000000L, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(class9);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + 100L + "'", comparable11.equals(100L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 35 + "'", int12 == 35);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int2 = timeSeries1.getMaximumItemCount();
        java.lang.Object obj3 = timeSeries1.clone();
        java.lang.Class class4 = timeSeries1.getTimePeriodClass();
        timeSeries1.fireSeriesChanged();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.getDataItem(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(class4);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int2 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        int int4 = month3.getMonth();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.previous();
        boolean boolean7 = month3.equals((java.lang.Object) month5);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month3, (java.lang.Number) 2147483647, false);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries12.removeChangeListener(seriesChangeListener13);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries12.removeChangeListener(seriesChangeListener15);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        int int18 = month17.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month17.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month17, (double) 10.0f);
        int int22 = month3.compareTo((java.lang.Object) 10.0f);
        java.lang.String str23 = month3.toString();
        java.util.Calendar calendar24 = null;
        try {
            month3.peg(calendar24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "June 2019" + "'", str23.equals("June 2019"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.event.SeriesChangeEvent[source=-1.0]");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int2 = timeSeries1.getMaximumItemCount();
        java.lang.Object obj3 = timeSeries1.clone();
        timeSeries1.setKey((java.lang.Comparable) 1);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        int int7 = month6.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month6.next();
        int int9 = month6.getMonth();
        int int10 = month6.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month6);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.next();
        timeSeries1.add(regularTimePeriod13, (-1.0d), true);
        long long17 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries19.removeChangeListener(seriesChangeListener20);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(10);
        timeSeries19.add((org.jfree.data.time.RegularTimePeriod) year23, (double) (byte) 1, true);
        int int27 = timeSeries19.getMaximumItemCount();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(10);
        timeSeries19.delete((org.jfree.data.time.RegularTimePeriod) year29);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) year29);
        java.lang.String str32 = timeSeries1.getRangeDescription();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        int int34 = month33.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month33.next();
        try {
            timeSeries1.add(regularTimePeriod35, (java.lang.Number) 1546329600000L, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 9223372036854775807L + "'", long17 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2147483647 + "'", int27 == 2147483647);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Value" + "'", str32.equals("Value"));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        timeSeries1.setMaximumItemAge((long) '#');
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        int int11 = year10.getYear();
        java.lang.String str12 = year10.toString();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        int int14 = month13.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month13.next();
        long long16 = month13.getFirstMillisecond();
        long long17 = month13.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year10, (org.jfree.data.time.RegularTimePeriod) month13);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        long long20 = year19.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year19, (double) 100L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year19, (double) (byte) 0);
        timeSeriesDataItem24.setSelected(false);
        java.lang.Number number27 = timeSeriesDataItem24.getValue();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1559372400000L + "'", long16 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1559372400000L + "'", long17 == 1559372400000L);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1562097599999L + "'", long20 == 1562097599999L);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + number27 + "' != '" + 0.0d + "'", number27.equals(0.0d));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        java.lang.String str6 = timeSeries1.getRangeDescription();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries1.addChangeListener(seriesChangeListener7);
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) 8);
        long long13 = fixedMillisecond12.getSerialIndex();
        long long14 = fixedMillisecond12.getFirstMillisecond();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (java.lang.Number) 2147483647);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        int int18 = month17.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month17.next();
        int int20 = fixedMillisecond12.compareTo((java.lang.Object) regularTimePeriod19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = fixedMillisecond12.previous();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 8L + "'", long13 == 8L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 8L + "'", long14 == 8L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        long long3 = month0.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries5.removeChangeListener(seriesChangeListener6);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries5.removeChangeListener(seriesChangeListener8);
        java.lang.String str10 = timeSeries5.getRangeDescription();
        int int11 = month0.compareTo((java.lang.Object) timeSeries5);
        java.util.Calendar calendar12 = null;
        try {
            long long13 = month0.getFirstMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1559372400000L + "'", long3 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Value" + "'", str10.equals("Value"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int2 = year1.getYear();
        long long3 = year1.getSerialIndex();
        long long4 = year1.getMiddleMillisecond();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(4, year1);
        java.util.Calendar calendar6 = null;
        try {
            month5.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1562097599999L + "'", long4 == 1562097599999L);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int2 = timeSeries1.getMaximumItemCount();
        java.lang.Object obj3 = timeSeries1.clone();
        timeSeries1.setKey((java.lang.Comparable) 1);
        java.util.Collection collection6 = timeSeries1.getTimePeriods();
        int int7 = timeSeries1.getMaximumItemCount();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener8);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = regularTimePeriod1.getMiddleMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("10");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("Value");
        java.lang.Throwable[] throwableArray4 = seriesException3.getSuppressed();
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("Value");
        seriesException3.addSuppressed((java.lang.Throwable) seriesException6);
        java.lang.Throwable[] throwableArray8 = seriesException6.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException6);
        java.lang.Throwable[] throwableArray10 = seriesException6.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(throwableArray10);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) 0);
        boolean boolean3 = timeSeriesDataItem2.isSelected();
        timeSeriesDataItem2.setValue((java.lang.Number) 5);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(10);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (double) (byte) 1, true);
        java.lang.Object obj15 = timeSeries7.clone();
        boolean boolean16 = timeSeriesDataItem2.equals(obj15);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        java.lang.String str8 = timeSeries1.getDescription();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        long long12 = month9.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (double) 1.0f);
        java.lang.Number number15 = timeSeriesDataItem14.getValue();
        timeSeries1.add(timeSeriesDataItem14, true);
        timeSeries1.setDescription("June 2019");
        java.lang.Class class20 = null;
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo22 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent23 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1.0f), seriesChangeInfo22);
        java.lang.Class<?> wildcardClass24 = seriesChangeEvent23.getClass();
        java.lang.Class class25 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass24);
        java.util.Date date26 = null;
        java.util.TimeZone timeZone27 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date26, timeZone27);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
        int int30 = month29.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month29.next();
        long long32 = month29.getFirstMillisecond();
        java.util.Date date33 = month29.getEnd();
        java.util.TimeZone timeZone34 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date33, timeZone34);
        java.util.TimeZone timeZone36 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date33, timeZone36);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date33);
        java.lang.Object obj39 = null;
        boolean boolean40 = day38.equals(obj39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = day38.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = day38.next();
        timeSeries1.delete(regularTimePeriod42);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1559372400000L + "'", long12 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 1.0d + "'", number15.equals(1.0d));
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(class25);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1559372400000L + "'", long32 == 1559372400000L);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) 8);
        long long8 = fixedMillisecond7.getSerialIndex();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond7.getMiddleMillisecond(calendar9);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries12.removeChangeListener(seriesChangeListener13);
        java.util.List list15 = timeSeries12.getItems();
        java.lang.String str16 = timeSeries12.getDescription();
        int int17 = fixedMillisecond7.compareTo((java.lang.Object) str16);
        long long18 = fixedMillisecond7.getLastMillisecond();
        long long19 = fixedMillisecond7.getMiddleMillisecond();
        java.lang.Object obj20 = null;
        boolean boolean21 = fixedMillisecond7.equals(obj20);
        java.util.Calendar calendar22 = null;
        long long23 = fixedMillisecond7.getFirstMillisecond(calendar22);
        try {
            timeSeries1.setKey((java.lang.Comparable) calendar22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 8L + "'", long8 == 8L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 8L + "'", long10 == 8L);
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 8L + "'", long18 == 8L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 8L + "'", long19 == 8L);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 8L + "'", long23 == 8L);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        java.lang.String str8 = timeSeries1.getDescription();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        long long12 = month9.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (double) 1.0f);
        java.lang.Number number15 = timeSeriesDataItem14.getValue();
        timeSeries1.add(timeSeriesDataItem14, true);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries19.removeChangeListener(seriesChangeListener20);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener22 = null;
        timeSeries19.removeChangeListener(seriesChangeListener22);
        boolean boolean24 = timeSeries19.getNotify();
        timeSeries19.setMaximumItemCount((int) '#');
        java.lang.Class class27 = timeSeries19.getTimePeriodClass();
        timeSeries19.setMaximumItemCount(2147483647);
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries1.addAndOrUpdate(timeSeries19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = timeSeries1.getNextTimePeriod();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = null;
        java.lang.Number number33 = null;
        try {
            timeSeries1.add(regularTimePeriod32, number33, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1559372400000L + "'", long12 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 1.0d + "'", number15.equals(1.0d));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(class27);
        org.junit.Assert.assertNotNull(timeSeries30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        long long3 = month0.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) 1.0f);
        java.lang.Number number6 = timeSeriesDataItem5.getValue();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int9 = timeSeries8.getMaximumItemCount();
        java.lang.Object obj10 = timeSeries8.clone();
        timeSeries8.setKey((java.lang.Comparable) 1);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        int int14 = month13.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month13.next();
        int int16 = month13.getMonth();
        int int17 = month13.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries8.getDataItem((org.jfree.data.time.RegularTimePeriod) month13);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year19.next();
        timeSeries8.add(regularTimePeriod20, (-1.0d), true);
        boolean boolean24 = timeSeriesDataItem5.equals((java.lang.Object) (-1.0d));
        java.lang.Number number25 = timeSeriesDataItem5.getValue();
        timeSeriesDataItem5.setSelected(true);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo29 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent30 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1.0f), seriesChangeInfo29);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo31 = seriesChangeEvent30.getSummary();
        java.lang.String str32 = seriesChangeEvent30.toString();
        boolean boolean33 = timeSeriesDataItem5.equals((java.lang.Object) str32);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1559372400000L + "'", long3 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1.0d + "'", number6.equals(1.0d));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2147483647 + "'", int9 == 2147483647);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 1.0d + "'", number25.equals(1.0d));
        org.junit.Assert.assertNull(seriesChangeInfo31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=-1.0]" + "'", str32.equals("org.jfree.data.event.SeriesChangeEvent[source=-1.0]"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        int int3 = month2.getMonth();
        int int4 = month2.getYearValue();
        long long5 = month2.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) 1562097599999L);
        timeSeries1.add(timeSeriesDataItem7, true);
        timeSeries1.removeAgedItems((long) 10, true);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 24234L + "'", long5 == 24234L);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Time");
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        int int5 = month4.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.setKey((java.lang.Comparable) regularTimePeriod6);
        java.util.Collection collection8 = timeSeries1.getTimePeriods();
        java.lang.Class<?> wildcardClass9 = timeSeries1.getClass();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 100, 2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int4 = timeSeries3.getMaximumItemCount();
        java.lang.Object obj5 = timeSeries3.clone();
        timeSeries3.setKey((java.lang.Comparable) 1);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        int int9 = month8.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month8.next();
        int int11 = month8.getMonth();
        int int12 = month8.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) month8);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.next();
        timeSeries3.add(regularTimePeriod15, (-1.0d), true);
        boolean boolean19 = year0.equals((java.lang.Object) timeSeries3);
        try {
            timeSeries3.delete((int) (short) 0, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        timeSeries1.setMaximumItemAge((long) '#');
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        int int11 = year10.getYear();
        java.lang.String str12 = year10.toString();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        int int14 = month13.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month13.next();
        long long16 = month13.getFirstMillisecond();
        long long17 = month13.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year10, (org.jfree.data.time.RegularTimePeriod) month13);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        long long20 = year19.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year19, (double) 100L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year19, (double) (byte) 0);
        timeSeriesDataItem24.setSelected(false);
        java.lang.Number number27 = null;
        timeSeriesDataItem24.setValue(number27);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1559372400000L + "'", long16 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1559372400000L + "'", long17 == 1559372400000L);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1562097599999L + "'", long20 == 1562097599999L);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        long long3 = month0.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries5.removeChangeListener(seriesChangeListener6);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries5.removeChangeListener(seriesChangeListener8);
        java.lang.String str10 = timeSeries5.getRangeDescription();
        int int11 = month0.compareTo((java.lang.Object) timeSeries5);
        double double12 = timeSeries5.getMaxY();
        boolean boolean13 = timeSeries5.isEmpty();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        int int15 = month14.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = month14.next();
        long long17 = month14.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month14, (double) 1.0f);
        java.lang.Number number20 = timeSeriesDataItem19.getValue();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int23 = timeSeries22.getMaximumItemCount();
        java.lang.Object obj24 = timeSeries22.clone();
        timeSeries22.setKey((java.lang.Comparable) 1);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        int int28 = month27.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month27.next();
        int int30 = month27.getMonth();
        int int31 = month27.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries22.getDataItem((org.jfree.data.time.RegularTimePeriod) month27);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = year33.next();
        timeSeries22.add(regularTimePeriod34, (-1.0d), true);
        boolean boolean38 = timeSeriesDataItem19.equals((java.lang.Object) (-1.0d));
        java.lang.Number number39 = timeSeriesDataItem19.getValue();
        timeSeriesDataItem19.setSelected(true);
        timeSeries5.add(timeSeriesDataItem19, false);
        timeSeriesDataItem19.setSelected(true);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1559372400000L + "'", long3 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Value" + "'", str10.equals("Value"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1559372400000L + "'", long17 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 1.0d + "'", number20.equals(1.0d));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2147483647 + "'", int23 == 2147483647);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 6 + "'", int31 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem32);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + number39 + "' != '" + 1.0d + "'", number39.equals(1.0d));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        long long3 = month0.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries5.removeChangeListener(seriesChangeListener6);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries5.removeChangeListener(seriesChangeListener8);
        java.lang.String str10 = timeSeries5.getRangeDescription();
        int int11 = month0.compareTo((java.lang.Object) timeSeries5);
        long long12 = month0.getSerialIndex();
        java.lang.String str13 = month0.toString();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1559372400000L + "'", long3 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Value" + "'", str10.equals("Value"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 24234L + "'", long12 == 24234L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "June 2019" + "'", str13.equals("June 2019"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int5 = timeSeries4.getMaximumItemCount();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        int int7 = month6.getMonth();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month8.previous();
        boolean boolean10 = month6.equals((java.lang.Object) month8);
        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) 2147483647, false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month6.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) 0.0f);
        java.util.Calendar calendar17 = null;
        try {
            long long18 = month6.getFirstMillisecond(calendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        long long3 = month0.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) 1.0f);
        long long6 = month0.getFirstMillisecond();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = month0.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1559372400000L + "'", long3 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1559372400000L + "'", long6 == 1559372400000L);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        long long3 = month0.getFirstMillisecond();
        java.util.Date date4 = month0.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        java.util.TimeZone timeZone6 = null;
        try {
            org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date4, timeZone6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1559372400000L + "'", long3 == 1559372400000L);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        java.lang.Class class0 = null;
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo2 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1.0f), seriesChangeInfo2);
        java.lang.Class<?> wildcardClass4 = seriesChangeEvent3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date6, timeZone7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        long long12 = month9.getFirstMillisecond();
        java.util.Date date13 = month9.getEnd();
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date13, timeZone14);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date13, timeZone16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date13);
        java.lang.Object obj19 = null;
        boolean boolean20 = day18.equals(obj19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day18.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day18.next();
        int int24 = day18.compareTo((java.lang.Object) 0.0f);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1559372400000L + "'", long12 == 1559372400000L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        java.lang.Class class0 = null;
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo2 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1.0f), seriesChangeInfo2);
        java.lang.Class<?> wildcardClass4 = seriesChangeEvent3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date6, timeZone7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        long long12 = month9.getFirstMillisecond();
        java.util.Date date13 = month9.getEnd();
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date13, timeZone14);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date13, timeZone16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.next();
        org.jfree.data.time.SerialDate serialDate20 = day18.getSerialDate();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(serialDate20);
        java.util.Calendar calendar22 = null;
        try {
            long long23 = day21.getMiddleMillisecond(calendar22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1559372400000L + "'", long12 == 1559372400000L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(serialDate20);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        java.lang.Class class0 = null;
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo2 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1.0f), seriesChangeInfo2);
        java.lang.Class<?> wildcardClass4 = seriesChangeEvent3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date6, timeZone7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        long long12 = month9.getFirstMillisecond();
        java.util.Date date13 = month9.getEnd();
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date13, timeZone14);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date13, timeZone16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.next();
        org.jfree.data.time.SerialDate serialDate20 = day18.getSerialDate();
        java.lang.String str21 = day18.toString();
        java.util.Calendar calendar22 = null;
        try {
            long long23 = day18.getLastMillisecond(calendar22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1559372400000L + "'", long12 == 1559372400000L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "30-June-2019" + "'", str21.equals("30-June-2019"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int2 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getMiddleMillisecond();
        long long5 = year3.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year3, (java.lang.Number) 2147483647);
        try {
            java.lang.Number number9 = timeSeries1.getValue((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1562097599999L + "'", long4 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        int int3 = month0.getMonth();
        int int4 = month0.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) (byte) 1);
        int int8 = timeSeriesDataItem6.compareTo((java.lang.Object) (short) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        int int7 = month6.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month6.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month6, (double) 10.0f);
        double double11 = timeSeries1.getMaxY();
        boolean boolean12 = timeSeries1.getNotify();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries14.removeChangeListener(seriesChangeListener15);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries14.removeChangeListener(seriesChangeListener17);
        boolean boolean19 = timeSeries14.getNotify();
        java.lang.Class class20 = timeSeries14.getTimePeriodClass();
        java.lang.String str21 = timeSeries14.getDescription();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        int int23 = month22.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month22.next();
        long long25 = month22.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month22, (double) 1.0f);
        java.lang.Number number28 = timeSeriesDataItem27.getValue();
        timeSeries14.add(timeSeriesDataItem27, true);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener33 = null;
        timeSeries32.removeChangeListener(seriesChangeListener33);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener35 = null;
        timeSeries32.removeChangeListener(seriesChangeListener35);
        boolean boolean37 = timeSeries32.getNotify();
        timeSeries32.setMaximumItemCount((int) '#');
        java.lang.Class class40 = timeSeries32.getTimePeriodClass();
        timeSeries32.setMaximumItemCount(2147483647);
        org.jfree.data.time.TimeSeries timeSeries43 = timeSeries14.addAndOrUpdate(timeSeries32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = timeSeries14.getNextTimePeriod();
        java.util.Collection collection45 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        int int46 = timeSeries1.getMaximumItemCount();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 10.0d + "'", double11 == 10.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNull(class20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1559372400000L + "'", long25 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + 1.0d + "'", number28.equals(1.0d));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNull(class40);
        org.junit.Assert.assertNotNull(timeSeries43);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(collection45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2147483647 + "'", int46 == 2147483647);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        timeSeries1.setMaximumItemCount((int) '#');
        java.lang.Class class9 = timeSeries1.getTimePeriodClass();
        java.util.List list10 = timeSeries1.getItems();
        try {
            timeSeries1.delete(0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(class9);
        org.junit.Assert.assertNotNull(list10);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int6 = timeSeries5.getMaximumItemCount();
        java.lang.Object obj7 = timeSeries5.clone();
        timeSeries5.setKey((java.lang.Comparable) 1);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        int int11 = month10.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month10.next();
        int int13 = month10.getMonth();
        int int14 = month10.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries5.getDataItem((org.jfree.data.time.RegularTimePeriod) month10);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year16.next();
        timeSeries5.add(regularTimePeriod17, (-1.0d), true);
        long long21 = timeSeries5.getMaximumItemAge();
        int int22 = year0.compareTo((java.lang.Object) long21);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2147483647 + "'", int6 == 2147483647);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775807L + "'", long21 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int2 = year1.getYear();
        long long3 = year1.getSerialIndex();
        long long4 = year1.getMiddleMillisecond();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(4, year1);
        java.lang.Object obj6 = null;
        int int7 = month5.compareTo(obj6);
        long long8 = month5.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (double) (byte) 0);
        int int11 = month5.getMonth();
        int int12 = month5.getYearValue();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1562097599999L + "'", long4 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1554102000000L + "'", long8 == 1554102000000L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        java.lang.String str8 = timeSeries1.getDescription();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        long long12 = month9.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (double) 1.0f);
        java.lang.Number number15 = timeSeriesDataItem14.getValue();
        timeSeries1.add(timeSeriesDataItem14, true);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries19.removeChangeListener(seriesChangeListener20);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener22 = null;
        timeSeries19.removeChangeListener(seriesChangeListener22);
        boolean boolean24 = timeSeries19.getNotify();
        java.lang.Class class25 = timeSeries19.getTimePeriodClass();
        java.lang.Class<?> wildcardClass26 = timeSeries19.getClass();
        boolean boolean27 = timeSeriesDataItem14.equals((java.lang.Object) wildcardClass26);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1559372400000L + "'", long12 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 1.0d + "'", number15.equals(1.0d));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(class25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        long long3 = month0.getFirstMillisecond();
        java.util.Date date4 = month0.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, "30-June-2019", "Value");
        java.util.TimeZone timeZone8 = null;
        java.util.Locale locale9 = null;
        try {
            org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date4, timeZone8, locale9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1559372400000L + "'", long3 == 1559372400000L);
        org.junit.Assert.assertNotNull(date4);
    }

//    @Test
//    public void test288() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test288");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        java.lang.String str2 = day0.toString();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = day0.getLastMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        java.lang.String str8 = timeSeries1.getDescription();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        long long12 = month9.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (double) 1.0f);
        java.lang.Number number15 = timeSeriesDataItem14.getValue();
        timeSeries1.add(timeSeriesDataItem14, true);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries19.removeChangeListener(seriesChangeListener20);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener22 = null;
        timeSeries19.removeChangeListener(seriesChangeListener22);
        boolean boolean24 = timeSeries19.getNotify();
        timeSeries19.setMaximumItemCount((int) '#');
        java.lang.Class class27 = timeSeries19.getTimePeriodClass();
        timeSeries19.setMaximumItemCount(2147483647);
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries1.addAndOrUpdate(timeSeries19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) 8);
        long long33 = fixedMillisecond32.getSerialIndex();
        java.util.Date date34 = fixedMillisecond32.getTime();
        timeSeries19.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (java.lang.Number) (short) 1);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = timeSeries19.getTimePeriod(5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1559372400000L + "'", long12 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 1.0d + "'", number15.equals(1.0d));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(class27);
        org.junit.Assert.assertNotNull(timeSeries30);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 8L + "'", long33 == 8L);
        org.junit.Assert.assertNotNull(date34);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        java.lang.Class class0 = null;
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo2 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1.0f), seriesChangeInfo2);
        java.lang.Class<?> wildcardClass4 = seriesChangeEvent3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date6, timeZone7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        long long12 = month9.getFirstMillisecond();
        java.util.Date date13 = month9.getEnd();
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date13, timeZone14);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date13, timeZone16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.next();
        org.jfree.data.time.SerialDate serialDate20 = day18.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day18.previous();
        int int22 = day18.getMonth();
        int int23 = day18.getYear();
        int int24 = day18.getYear();
        int int25 = day18.getDayOfMonth();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1559372400000L + "'", long12 == 1559372400000L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 30 + "'", int25 == 30);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int2 = timeSeries1.getMaximumItemCount();
        timeSeries1.setMaximumItemAge((long) 5);
        timeSeries1.fireSeriesChanged();
        double double6 = timeSeries1.getMinY();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries8.removeChangeListener(seriesChangeListener9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries8.removeChangeListener(seriesChangeListener11);
        java.lang.String str13 = timeSeries8.getRangeDescription();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries8.addChangeListener(seriesChangeListener14);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries8.removePropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) 8);
        long long20 = fixedMillisecond19.getSerialIndex();
        long long21 = fixedMillisecond19.getFirstMillisecond();
        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (java.lang.Number) 2147483647);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
        int int25 = month24.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month24.next();
        int int27 = fixedMillisecond19.compareTo((java.lang.Object) regularTimePeriod26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (double) (short) 100);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener32 = null;
        timeSeries31.removeChangeListener(seriesChangeListener32);
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        int int35 = month34.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = month34.next();
        timeSeries31.setKey((java.lang.Comparable) regularTimePeriod36);
        boolean boolean38 = timeSeries31.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) 8);
        long long41 = fixedMillisecond40.getSerialIndex();
        java.util.Calendar calendar42 = null;
        long long43 = fixedMillisecond40.getMiddleMillisecond(calendar42);
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener46 = null;
        timeSeries45.removeChangeListener(seriesChangeListener46);
        java.util.List list48 = timeSeries45.getItems();
        java.lang.String str49 = timeSeries45.getDescription();
        int int50 = fixedMillisecond40.compareTo((java.lang.Object) str49);
        timeSeries31.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, (java.lang.Number) 0);
        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries1.addAndOrUpdate(timeSeries31);
        timeSeries1.removeAgedItems(false);
        java.lang.String str56 = timeSeries1.getDomainDescription();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Value" + "'", str13.equals("Value"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 8L + "'", long20 == 8L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 8L + "'", long21 == 8L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 6 + "'", int35 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 8L + "'", long41 == 8L);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 8L + "'", long43 == 8L);
        org.junit.Assert.assertNotNull(list48);
        org.junit.Assert.assertNull(str49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertNotNull(timeSeries53);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "Time" + "'", str56.equals("Time"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(10);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year5, (double) (byte) 1, true);
        int int9 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) 8);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (java.lang.Number) 0);
        boolean boolean15 = timeSeriesDataItem14.isSelected();
        boolean boolean16 = fixedMillisecond11.equals((java.lang.Object) boolean15);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (java.lang.Number) 9223372036854775807L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2147483647 + "'", int9 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) 0);
        java.lang.String str3 = year0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.previous();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        java.lang.String str6 = timeSeries1.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 8);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) (-1.0d));
        long long11 = fixedMillisecond8.getSerialIndex();
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond8.getFirstMillisecond(calendar12);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 8L + "'", long11 == 8L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 8L + "'", long13 == 8L);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int2 = timeSeries1.getMaximumItemCount();
        java.lang.Object obj3 = timeSeries1.clone();
        timeSeries1.setKey((java.lang.Comparable) 1);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        int int7 = month6.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month6.next();
        int int9 = month6.getMonth();
        int int10 = month6.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month6);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.next();
        timeSeries1.add(regularTimePeriod13, (-1.0d), true);
        try {
            timeSeries1.delete((int) '4', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        int int2 = month0.getYearValue();
        int int3 = month0.getYearValue();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = month0.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int2 = timeSeries1.getMaximumItemCount();
        java.lang.Object obj3 = timeSeries1.clone();
        timeSeries1.setKey((java.lang.Comparable) 1);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        int int7 = month6.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month6.next();
        int int9 = month6.getMonth();
        int int10 = month6.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month6);
        java.util.Calendar calendar12 = null;
        try {
            long long13 = month6.getLastMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        long long3 = month0.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) 1.0f);
        long long6 = month0.getFirstMillisecond();
        long long7 = month0.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1559372400000L + "'", long3 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1559372400000L + "'", long6 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 24234L + "'", long7 == 24234L);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int2 = year1.getYear();
        long long3 = year1.getSerialIndex();
        long long4 = year1.getMiddleMillisecond();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(4, year1);
        java.lang.String str6 = year1.toString();
        int int7 = year1.getYear();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = year1.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1562097599999L + "'", long4 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        long long3 = month0.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) 1.0f);
        org.jfree.data.general.SeriesException seriesException7 = new org.jfree.data.general.SeriesException("Value");
        java.lang.Throwable[] throwableArray8 = seriesException7.getSuppressed();
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("Value");
        seriesException7.addSuppressed((java.lang.Throwable) seriesException10);
        java.lang.Throwable[] throwableArray12 = seriesException10.getSuppressed();
        java.lang.Throwable[] throwableArray13 = seriesException10.getSuppressed();
        java.lang.Throwable[] throwableArray14 = seriesException10.getSuppressed();
        boolean boolean15 = month0.equals((java.lang.Object) throwableArray14);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1559372400000L + "'", long3 == 1559372400000L);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int5 = timeSeries4.getMaximumItemCount();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        int int7 = month6.getMonth();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month8.previous();
        boolean boolean10 = month6.equals((java.lang.Object) month8);
        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) 2147483647, false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month6.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) 0.0f);
        java.util.Calendar calendar17 = null;
        try {
            month6.peg(calendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(10);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year5, (double) (byte) 1, true);
        int int9 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(10);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) year11);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries1.addChangeListener(seriesChangeListener13);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2147483647 + "'", int9 == 2147483647);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int2 = year1.getYear();
        long long3 = year1.getSerialIndex();
        long long4 = year1.getMiddleMillisecond();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(4, year1);
        long long6 = month5.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1562097599999L + "'", long4 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1556693999999L + "'", long6 == 1556693999999L);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int3 = timeSeries2.getMaximumItemCount();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        int int5 = month4.getMonth();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month6.previous();
        boolean boolean8 = month4.equals((java.lang.Object) month6);
        timeSeries2.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 2147483647, false);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries13.removeChangeListener(seriesChangeListener14);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries13.removeChangeListener(seriesChangeListener16);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        int int19 = month18.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month18, (double) 10.0f);
        int int23 = month4.compareTo((java.lang.Object) 10.0f);
        java.lang.String str24 = month4.toString();
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int27 = timeSeries26.getMaximumItemCount();
        boolean boolean28 = month4.equals((java.lang.Object) int27);
        org.jfree.data.time.Year year29 = month4.getYear();
        try {
            org.jfree.data.time.Month month30 = new org.jfree.data.time.Month(2147483647, year29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "June 2019" + "'", str24.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2147483647 + "'", int27 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(year29);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        int int2 = year0.getYear();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.general.SeriesException: Value");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(10);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year5, (double) (byte) 1, true);
        java.lang.Object obj9 = null;
        boolean boolean10 = timeSeries1.equals(obj9);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        int int12 = month11.getMonth();
        int int13 = month11.getYearValue();
        org.jfree.data.time.Year year14 = month11.getYear();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month11, (double) 1577865599999L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNotNull(year14);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        timeSeries1.setMaximumItemAge((long) '#');
        timeSeries1.removeAgedItems(false);
        timeSeries1.fireSeriesChanged();
        try {
            org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.createCopy(4, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(class7);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(0, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Value");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("Value");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.Throwable[] throwableArray6 = seriesException4.getSuppressed();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year7, (java.lang.Number) 0);
        org.jfree.data.general.SeriesException seriesException11 = new org.jfree.data.general.SeriesException("Value");
        java.lang.Throwable[] throwableArray12 = seriesException11.getSuppressed();
        org.jfree.data.general.SeriesException seriesException14 = new org.jfree.data.general.SeriesException("Value");
        seriesException11.addSuppressed((java.lang.Throwable) seriesException14);
        boolean boolean16 = timeSeriesDataItem9.equals((java.lang.Object) seriesException11);
        seriesException4.addSuppressed((java.lang.Throwable) seriesException11);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo18 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) seriesException4, seriesChangeInfo18);
        java.lang.String str20 = seriesChangeEvent19.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo21 = seriesChangeEvent19.getSummary();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=org.jfree.data.general.SeriesException: Value]" + "'", str20.equals("org.jfree.data.event.SeriesChangeEvent[source=org.jfree.data.general.SeriesException: Value]"));
        org.junit.Assert.assertNull(seriesChangeInfo21);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int2 = timeSeries1.getMaximumItemCount();
        java.lang.Object obj3 = timeSeries1.clone();
        java.lang.Class class4 = timeSeries1.getTimePeriodClass();
        timeSeries1.fireSeriesChanged();
        timeSeries1.setDescription("10");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(class4);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("org.jfree.data.event.SeriesChangeEvent[source=-1.0]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the month.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        long long3 = month0.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) 1.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month0.next();
        long long7 = month0.getSerialIndex();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = month0.getMiddleMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1559372400000L + "'", long3 == 1559372400000L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 24234L + "'", long7 == 24234L);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        timeSeries1.setMaximumItemAge((long) '#');
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        int int11 = year10.getYear();
        java.lang.String str12 = year10.toString();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        int int14 = month13.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month13.next();
        long long16 = month13.getFirstMillisecond();
        long long17 = month13.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year10, (org.jfree.data.time.RegularTimePeriod) month13);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener21 = null;
        timeSeries20.removeChangeListener(seriesChangeListener21);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener23 = null;
        timeSeries20.removeChangeListener(seriesChangeListener23);
        boolean boolean25 = timeSeries20.getNotify();
        java.lang.Class class26 = timeSeries20.getTimePeriodClass();
        java.lang.String str27 = timeSeries20.getDescription();
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
        int int29 = month28.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month28.next();
        long long31 = month28.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month28, (double) 1.0f);
        java.lang.Number number34 = timeSeriesDataItem33.getValue();
        timeSeries20.add(timeSeriesDataItem33, true);
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener39 = null;
        timeSeries38.removeChangeListener(seriesChangeListener39);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener41 = null;
        timeSeries38.removeChangeListener(seriesChangeListener41);
        boolean boolean43 = timeSeries38.getNotify();
        timeSeries38.setMaximumItemCount((int) '#');
        java.lang.Class class46 = timeSeries38.getTimePeriodClass();
        timeSeries38.setMaximumItemCount(2147483647);
        org.jfree.data.time.TimeSeries timeSeries49 = timeSeries20.addAndOrUpdate(timeSeries38);
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        long long51 = year50.getMiddleMillisecond();
        timeSeries49.add((org.jfree.data.time.RegularTimePeriod) year50, (double) 6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem55 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year50, (double) 4);
        java.util.Collection collection56 = timeSeries1.getTimePeriods();
        org.jfree.data.time.Month month57 = new org.jfree.data.time.Month();
        int int58 = month57.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = month57.next();
        long long60 = month57.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries62 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener63 = null;
        timeSeries62.removeChangeListener(seriesChangeListener63);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener65 = null;
        timeSeries62.removeChangeListener(seriesChangeListener65);
        java.lang.String str67 = timeSeries62.getRangeDescription();
        int int68 = month57.compareTo((java.lang.Object) timeSeries62);
        double double69 = timeSeries62.getMaxY();
        boolean boolean70 = timeSeries62.isEmpty();
        java.lang.Class class71 = null;
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo73 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent74 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1.0f), seriesChangeInfo73);
        java.lang.Class<?> wildcardClass75 = seriesChangeEvent74.getClass();
        java.lang.Class class76 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass75);
        java.util.Date date77 = null;
        java.util.TimeZone timeZone78 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass75, date77, timeZone78);
        org.jfree.data.time.Month month80 = new org.jfree.data.time.Month();
        int int81 = month80.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = month80.next();
        long long83 = month80.getFirstMillisecond();
        java.util.Date date84 = month80.getEnd();
        java.util.TimeZone timeZone85 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod86 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass75, date84, timeZone85);
        java.util.TimeZone timeZone87 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = org.jfree.data.time.RegularTimePeriod.createInstance(class71, date84, timeZone87);
        org.jfree.data.time.Day day89 = new org.jfree.data.time.Day(date84);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod90 = day89.next();
        org.jfree.data.time.SerialDate serialDate91 = day89.getSerialDate();
        java.lang.String str92 = day89.toString();
        int int93 = timeSeries62.getIndex((org.jfree.data.time.RegularTimePeriod) day89);
        int int94 = day89.getMonth();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day89, (double) 1561964399999L, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1559372400000L + "'", long16 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1559372400000L + "'", long17 == 1559372400000L);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNull(class26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1559372400000L + "'", long31 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + number34 + "' != '" + 1.0d + "'", number34.equals(1.0d));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNull(class46);
        org.junit.Assert.assertNotNull(timeSeries49);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1562097599999L + "'", long51 == 1562097599999L);
        org.junit.Assert.assertNull(timeSeriesDataItem55);
        org.junit.Assert.assertNotNull(collection56);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 6 + "'", int58 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod59);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1559372400000L + "'", long60 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "Value" + "'", str67.equals("Value"));
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
        org.junit.Assert.assertEquals((double) double69, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNotNull(wildcardClass75);
        org.junit.Assert.assertNotNull(class76);
        org.junit.Assert.assertNull(regularTimePeriod79);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 6 + "'", int81 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod82);
        org.junit.Assert.assertTrue("'" + long83 + "' != '" + 1559372400000L + "'", long83 == 1559372400000L);
        org.junit.Assert.assertNotNull(date84);
        org.junit.Assert.assertNull(regularTimePeriod86);
        org.junit.Assert.assertNull(regularTimePeriod88);
        org.junit.Assert.assertNotNull(regularTimePeriod90);
        org.junit.Assert.assertNotNull(serialDate91);
        org.junit.Assert.assertTrue("'" + str92 + "' != '" + "30-June-2019" + "'", str92.equals("30-June-2019"));
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + (-1) + "'", int93 == (-1));
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 6 + "'", int94 == 6);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(10);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year5, (double) (byte) 1, true);
        timeSeries1.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries12.removeChangeListener(seriesChangeListener13);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries12.removeChangeListener(seriesChangeListener15);
        boolean boolean17 = timeSeries12.getNotify();
        java.lang.Class class18 = timeSeries12.getTimePeriodClass();
        timeSeries12.setMaximumItemAge((long) '#');
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        int int22 = year21.getYear();
        java.lang.String str23 = year21.toString();
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
        int int25 = month24.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month24.next();
        long long27 = month24.getFirstMillisecond();
        long long28 = month24.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) year21, (org.jfree.data.time.RegularTimePeriod) month24);
        java.lang.Number number30 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) year21);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(class18);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2019" + "'", str23.equals("2019"));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1559372400000L + "'", long27 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1559372400000L + "'", long28 == 1559372400000L);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNull(number30);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        int int3 = month0.getMonth();
        int int4 = month0.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) (byte) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month0.previous();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond((long) 8);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (java.lang.Number) 0);
        boolean boolean7 = timeSeriesDataItem6.isSelected();
        boolean boolean8 = fixedMillisecond3.equals((java.lang.Object) timeSeriesDataItem6);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (java.lang.Number) 2147483647, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries1.addChangeListener(seriesChangeListener12);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = timeSeries1.getTimePeriod((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        int int3 = month0.getMonth();
        int int4 = month0.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) (byte) 1);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        int int8 = month7.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month7.next();
        long long10 = month7.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month7, (double) 1.0f);
        java.lang.Number number13 = timeSeriesDataItem12.getValue();
        timeSeriesDataItem12.setValue((java.lang.Number) 1559372400000L);
        java.lang.Object obj16 = null;
        boolean boolean17 = timeSeriesDataItem12.equals(obj16);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries19.removeChangeListener(seriesChangeListener20);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener22 = null;
        timeSeries19.removeChangeListener(seriesChangeListener22);
        boolean boolean24 = timeSeries19.getNotify();
        java.lang.Class class25 = timeSeries19.getTimePeriodClass();
        int int26 = timeSeriesDataItem12.compareTo((java.lang.Object) timeSeries19);
        boolean boolean27 = timeSeriesDataItem12.isSelected();
        int int28 = month0.compareTo((java.lang.Object) boolean27);
        java.lang.Object obj29 = null;
        int int30 = month0.compareTo(obj29);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1559372400000L + "'", long10 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 1.0d + "'", number13.equals(1.0d));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(class25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        int int7 = month6.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month6.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month6, (double) 10.0f);
        double double11 = timeSeries1.getMaxY();
        boolean boolean12 = timeSeries1.getNotify();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries14.removeChangeListener(seriesChangeListener15);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries14.removeChangeListener(seriesChangeListener17);
        boolean boolean19 = timeSeries14.getNotify();
        java.lang.Class class20 = timeSeries14.getTimePeriodClass();
        java.lang.String str21 = timeSeries14.getDescription();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        int int23 = month22.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month22.next();
        long long25 = month22.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month22, (double) 1.0f);
        java.lang.Number number28 = timeSeriesDataItem27.getValue();
        timeSeries14.add(timeSeriesDataItem27, true);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener33 = null;
        timeSeries32.removeChangeListener(seriesChangeListener33);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener35 = null;
        timeSeries32.removeChangeListener(seriesChangeListener35);
        boolean boolean37 = timeSeries32.getNotify();
        timeSeries32.setMaximumItemCount((int) '#');
        java.lang.Class class40 = timeSeries32.getTimePeriodClass();
        timeSeries32.setMaximumItemCount(2147483647);
        org.jfree.data.time.TimeSeries timeSeries43 = timeSeries14.addAndOrUpdate(timeSeries32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = timeSeries14.getNextTimePeriod();
        java.util.Collection collection45 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener48 = null;
        timeSeries47.removeChangeListener(seriesChangeListener48);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener50 = null;
        timeSeries47.removeChangeListener(seriesChangeListener50);
        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month();
        int int53 = month52.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = month52.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = timeSeries47.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month52, (double) 10.0f);
        try {
            timeSeries14.add((org.jfree.data.time.RegularTimePeriod) month52, (double) (short) 1, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period June 2019 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 10.0d + "'", double11 == 10.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNull(class20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1559372400000L + "'", long25 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + 1.0d + "'", number28.equals(1.0d));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNull(class40);
        org.junit.Assert.assertNotNull(timeSeries43);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(collection45);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 6 + "'", int53 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod54);
        org.junit.Assert.assertNull(timeSeriesDataItem56);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        int int2 = month0.getYearValue();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1.0f), seriesChangeInfo4);
        java.lang.Class<?> wildcardClass6 = seriesChangeEvent5.getClass();
        java.util.Date date7 = null;
        java.util.TimeZone timeZone8 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date7, timeZone8);
        int int10 = month0.compareTo((java.lang.Object) timeZone8);
        java.util.Calendar calendar11 = null;
        try {
            long long12 = month0.getLastMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        java.lang.Class class0 = null;
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        long long2 = year1.getMiddleMillisecond();
        java.util.Date date3 = year1.getEnd();
        java.util.Date date4 = year1.getEnd();
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date4, timeZone5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date4);
        java.util.TimeZone timeZone8 = null;
        java.util.Locale locale9 = null;
        try {
            org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date4, timeZone8, locale9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(regularTimePeriod6);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int2 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        int int4 = month3.getMonth();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.previous();
        boolean boolean7 = month3.equals((java.lang.Object) month5);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month3, (java.lang.Number) 2147483647, false);
        java.lang.Comparable comparable11 = timeSeries1.getKey();
        java.lang.Class class12 = null;
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo14 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent15 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1.0f), seriesChangeInfo14);
        java.lang.Class<?> wildcardClass16 = seriesChangeEvent15.getClass();
        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass16);
        java.util.Date date18 = null;
        java.util.TimeZone timeZone19 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date18, timeZone19);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
        int int22 = month21.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month21.next();
        long long24 = month21.getFirstMillisecond();
        java.util.Date date25 = month21.getEnd();
        java.util.TimeZone timeZone26 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date25, timeZone26);
        java.util.TimeZone timeZone28 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date25, timeZone28);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day30.next();
        org.jfree.data.time.SerialDate serialDate32 = day30.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day30.previous();
        int int34 = day30.getMonth();
        boolean boolean36 = day30.equals((java.lang.Object) 100.0f);
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day30, (double) 0.0f);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + 100L + "'", comparable11.equals(100L));
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(class17);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1559372400000L + "'", long24 == 1559372400000L);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        long long3 = month0.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) 1.0f);
        java.lang.Number number6 = timeSeriesDataItem5.getValue();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int9 = timeSeries8.getMaximumItemCount();
        java.lang.Object obj10 = timeSeries8.clone();
        timeSeries8.setKey((java.lang.Comparable) 1);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        int int14 = month13.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month13.next();
        int int16 = month13.getMonth();
        int int17 = month13.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries8.getDataItem((org.jfree.data.time.RegularTimePeriod) month13);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year19.next();
        timeSeries8.add(regularTimePeriod20, (-1.0d), true);
        boolean boolean24 = timeSeriesDataItem5.equals((java.lang.Object) (-1.0d));
        java.lang.Number number25 = timeSeriesDataItem5.getValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = timeSeriesDataItem5.getPeriod();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1559372400000L + "'", long3 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1.0d + "'", number6.equals(1.0d));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2147483647 + "'", int9 == 2147483647);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 1.0d + "'", number25.equals(1.0d));
        org.junit.Assert.assertNotNull(regularTimePeriod26);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        long long3 = month0.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) 1.0f);
        java.lang.Number number6 = timeSeriesDataItem5.getValue();
        timeSeriesDataItem5.setValue((java.lang.Number) 1559372400000L);
        java.lang.Object obj9 = null;
        boolean boolean10 = timeSeriesDataItem5.equals(obj9);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries12.removeChangeListener(seriesChangeListener13);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries12.removeChangeListener(seriesChangeListener15);
        boolean boolean17 = timeSeries12.getNotify();
        java.lang.Class class18 = timeSeries12.getTimePeriodClass();
        int int19 = timeSeriesDataItem5.compareTo((java.lang.Object) timeSeries12);
        timeSeries12.setRangeDescription("10");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1559372400000L + "'", long3 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1.0d + "'", number6.equals(1.0d));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(class18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int2 = timeSeries1.getMaximumItemCount();
        java.lang.Object obj3 = timeSeries1.clone();
        timeSeries1.setKey((java.lang.Comparable) 1);
        java.util.Collection collection6 = timeSeries1.getTimePeriods();
        int int7 = timeSeries1.getMaximumItemCount();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = timeSeries1.getTimePeriod(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year7.next();
        int int10 = timeSeries1.getIndex(regularTimePeriod9);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(5);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year12, (double) 1559372400000L, true);
        timeSeries1.setDomainDescription("");
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(100, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 8);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) fixedMillisecond1);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getLastMillisecond(calendar4);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond1.getMiddleMillisecond(calendar6);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8L + "'", long2 == 8L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 8L + "'", long5 == 8L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 8L + "'", long7 == 8L);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        timeSeries1.setMaximumItemAge((long) '#');
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        int int11 = year10.getYear();
        java.lang.String str12 = year10.toString();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        int int14 = month13.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month13.next();
        long long16 = month13.getFirstMillisecond();
        long long17 = month13.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year10, (org.jfree.data.time.RegularTimePeriod) month13);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        long long20 = year19.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year19, (double) 100L);
        long long23 = year19.getSerialIndex();
        long long24 = year19.getLastMillisecond();
        java.lang.Object obj25 = null;
        int int26 = year19.compareTo(obj25);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1559372400000L + "'", long16 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1559372400000L + "'", long17 == 1559372400000L);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1562097599999L + "'", long20 == 1562097599999L);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 2019L + "'", long23 == 2019L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1577865599999L + "'", long24 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        java.lang.Class class0 = null;
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo2 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1.0f), seriesChangeInfo2);
        java.lang.Class<?> wildcardClass4 = seriesChangeEvent3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date6, timeZone7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        long long12 = month9.getFirstMillisecond();
        java.util.Date date13 = month9.getEnd();
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date13, timeZone14);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date13, timeZone16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date13);
        java.lang.Object obj19 = null;
        boolean boolean20 = day18.equals(obj19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day18.next();
        java.util.Calendar calendar22 = null;
        try {
            long long23 = day18.getLastMillisecond(calendar22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1559372400000L + "'", long12 == 1559372400000L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        timeSeries1.setMaximumItemCount((int) '#');
        java.lang.Class class9 = timeSeries1.getTimePeriodClass();
        timeSeries1.setMaximumItemCount(2147483647);
        timeSeries1.setMaximumItemAge((long) 7);
        try {
            java.lang.Number number15 = timeSeries1.getValue(2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2147483647, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(class9);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 8);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Date date3 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date3);
        java.util.TimeZone timeZone6 = null;
        java.util.Locale locale7 = null;
        try {
            org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date3, timeZone6, locale7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8L + "'", long2 == 8L);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 8);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) fixedMillisecond1);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8L + "'", long2 == 8L);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        int int2 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = regularTimePeriod3.getMiddleMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int3 = timeSeries2.getMaximumItemCount();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getMiddleMillisecond();
        long long6 = year4.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year4, (java.lang.Number) 2147483647);
        try {
            org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(0, year4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1562097599999L + "'", long5 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) ' ', (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(10);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year5, (double) (byte) 1, true);
        timeSeries1.setNotify(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries1.removeChangeListener(seriesChangeListener11);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 8);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries6.removeChangeListener(seriesChangeListener7);
        java.util.List list9 = timeSeries6.getItems();
        java.lang.String str10 = timeSeries6.getDescription();
        int int11 = fixedMillisecond1.compareTo((java.lang.Object) str10);
        long long12 = fixedMillisecond1.getLastMillisecond();
        long long13 = fixedMillisecond1.getMiddleMillisecond();
        java.lang.Object obj14 = null;
        boolean boolean15 = fixedMillisecond1.equals(obj14);
        long long16 = fixedMillisecond1.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond1.next();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8L + "'", long2 == 8L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 8L + "'", long4 == 8L);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 8L + "'", long12 == 8L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 8L + "'", long13 == 8L);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 8L + "'", long16 == 8L);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0);
        timeSeries1.add(timeSeriesDataItem7, true);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = timeSeries1.getNextTimePeriod();
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(100, 0, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        java.lang.String str8 = timeSeries1.getDescription();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        long long12 = month9.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (double) 1.0f);
        java.lang.Number number15 = timeSeriesDataItem14.getValue();
        timeSeries1.add(timeSeriesDataItem14, true);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries19.removeChangeListener(seriesChangeListener20);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener22 = null;
        timeSeries19.removeChangeListener(seriesChangeListener22);
        boolean boolean24 = timeSeries19.getNotify();
        timeSeries19.setMaximumItemCount((int) '#');
        java.lang.Class class27 = timeSeries19.getTimePeriodClass();
        timeSeries19.setMaximumItemCount(2147483647);
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries1.addAndOrUpdate(timeSeries19);
        boolean boolean31 = timeSeries30.isEmpty();
        try {
            timeSeries30.delete(8, (int) (short) -1, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1559372400000L + "'", long12 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 1.0d + "'", number15.equals(1.0d));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(class27);
        org.junit.Assert.assertNotNull(timeSeries30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Value");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int2 = timeSeries1.getMaximumItemCount();
        timeSeries1.setMaximumItemAge((long) 5);
        timeSeries1.fireSeriesChanged();
        java.lang.Object obj6 = timeSeries1.clone();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 8);
        long long9 = fixedMillisecond8.getSerialIndex();
        java.util.Date date10 = fixedMillisecond8.getTime();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year11, (double) 100, false);
        java.util.Calendar calendar15 = null;
        try {
            long long16 = year11.getFirstMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 8L + "'", long9 == 8L);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getMiddleMillisecond();
        long long2 = year0.getFirstMillisecond();
        long long3 = year0.getSerialIndex();
        long long4 = year0.getLastMillisecond();
        int int5 = year0.getYear();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year0.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1562097599999L + "'", long1 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int2 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        int int4 = month3.getMonth();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.previous();
        boolean boolean7 = month3.equals((java.lang.Object) month5);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month3, (java.lang.Number) 2147483647, false);
        int int11 = timeSeries1.getMaximumItemCount();
        timeSeries1.fireSeriesChanged();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        int int14 = month13.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month13.next();
        long long16 = month13.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month13, (double) 1.0f);
        java.lang.Number number19 = timeSeriesDataItem18.getValue();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int22 = timeSeries21.getMaximumItemCount();
        java.lang.Object obj23 = timeSeries21.clone();
        timeSeries21.setKey((java.lang.Comparable) 1);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        int int27 = month26.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = month26.next();
        int int29 = month26.getMonth();
        int int30 = month26.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries21.getDataItem((org.jfree.data.time.RegularTimePeriod) month26);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year32.next();
        timeSeries21.add(regularTimePeriod33, (-1.0d), true);
        boolean boolean37 = timeSeriesDataItem18.equals((java.lang.Object) (-1.0d));
        java.lang.Number number38 = timeSeriesDataItem18.getValue();
        timeSeriesDataItem18.setSelected(true);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = timeSeriesDataItem18.getPeriod();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries1.addOrUpdate(timeSeriesDataItem18);
        timeSeries1.clear();
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener46 = null;
        timeSeries45.removeChangeListener(seriesChangeListener46);
        java.util.List list48 = timeSeries45.getItems();
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year49, (java.lang.Number) 0);
        org.jfree.data.general.SeriesException seriesException53 = new org.jfree.data.general.SeriesException("Value");
        java.lang.Throwable[] throwableArray54 = seriesException53.getSuppressed();
        org.jfree.data.general.SeriesException seriesException56 = new org.jfree.data.general.SeriesException("Value");
        seriesException53.addSuppressed((java.lang.Throwable) seriesException56);
        boolean boolean58 = timeSeriesDataItem51.equals((java.lang.Object) seriesException53);
        java.lang.Object obj59 = timeSeriesDataItem51.clone();
        timeSeries45.add(timeSeriesDataItem51);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem61 = timeSeries1.addOrUpdate(timeSeriesDataItem51);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2147483647 + "'", int11 == 2147483647);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1559372400000L + "'", long16 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 1.0d + "'", number19.equals(1.0d));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2147483647 + "'", int22 == 2147483647);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem31);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + number38 + "' != '" + 1.0d + "'", number38.equals(1.0d));
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(timeSeriesDataItem42);
        org.junit.Assert.assertNotNull(list48);
        org.junit.Assert.assertNotNull(throwableArray54);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(obj59);
        org.junit.Assert.assertNull(timeSeriesDataItem61);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        long long3 = month0.getFirstMillisecond();
        int int4 = month0.getYearValue();
        long long5 = month0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1559372400000L + "'", long3 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1561964399999L + "'", long5 == 1561964399999L);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        java.lang.Object obj7 = timeSeries1.clone();
        boolean boolean8 = timeSeries1.getNotify();
        java.lang.Class class9 = timeSeries1.getTimePeriodClass();
        timeSeries1.setDescription("org.jfree.data.event.SeriesChangeEvent[source=-1.0]");
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(class9);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int2 = timeSeries1.getMaximumItemCount();
        java.lang.Object obj3 = timeSeries1.clone();
        timeSeries1.setKey((java.lang.Comparable) 1);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        int int7 = month6.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month6.next();
        int int9 = month6.getMonth();
        int int10 = month6.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month6);
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener12);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 8);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Date date3 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date3);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8L + "'", long2 == 8L);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 8);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries6.removeChangeListener(seriesChangeListener7);
        java.util.List list9 = timeSeries6.getItems();
        java.lang.String str10 = timeSeries6.getDescription();
        int int11 = fixedMillisecond1.compareTo((java.lang.Object) str10);
        java.util.Date date12 = fixedMillisecond1.getStart();
        java.util.TimeZone timeZone13 = null;
        try {
            org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date12, timeZone13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8L + "'", long2 == 8L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 8L + "'", long4 == 8L);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(date12);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond((long) 8);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (java.lang.Number) 0);
        boolean boolean7 = timeSeriesDataItem6.isSelected();
        boolean boolean8 = fixedMillisecond3.equals((java.lang.Object) timeSeriesDataItem6);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (java.lang.Number) 2147483647, false);
        java.util.Date date12 = fixedMillisecond3.getStart();
        java.util.TimeZone timeZone13 = null;
        try {
            org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date12, timeZone13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date12);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int2 = timeSeries1.getMaximumItemCount();
        timeSeries1.setMaximumItemAge((long) 5);
        timeSeries1.fireSeriesChanged();
        double double6 = timeSeries1.getMinY();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries8.removeChangeListener(seriesChangeListener9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries8.removeChangeListener(seriesChangeListener11);
        java.lang.String str13 = timeSeries8.getRangeDescription();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries8.addChangeListener(seriesChangeListener14);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries8.removePropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) 8);
        long long20 = fixedMillisecond19.getSerialIndex();
        long long21 = fixedMillisecond19.getFirstMillisecond();
        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (java.lang.Number) 2147483647);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
        int int25 = month24.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month24.next();
        int int27 = fixedMillisecond19.compareTo((java.lang.Object) regularTimePeriod26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (double) (short) 100);
        java.beans.PropertyChangeListener propertyChangeListener30 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener30);
        java.lang.Object obj32 = timeSeries1.clone();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Value" + "'", str13.equals("Value"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 8L + "'", long20 == 8L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 8L + "'", long21 == 8L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertNotNull(obj32);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond((long) 8);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (java.lang.Number) 0);
        boolean boolean7 = timeSeriesDataItem6.isSelected();
        boolean boolean8 = fixedMillisecond3.equals((java.lang.Object) timeSeriesDataItem6);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (java.lang.Number) 2147483647, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries1.addChangeListener(seriesChangeListener12);
        org.jfree.data.time.Month month15 = org.jfree.data.time.Month.parseMonth("May -1");
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int18 = timeSeries17.getMaximumItemCount();
        java.lang.Object obj19 = timeSeries17.clone();
        timeSeries17.setDescription("Time");
        boolean boolean22 = month15.equals((java.lang.Object) "Time");
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month15, (java.lang.Number) 1.0d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.FixedMillisecond.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(month15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2147483647 + "'", int18 == 2147483647);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        java.lang.Class class0 = null;
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo2 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1.0f), seriesChangeInfo2);
        java.lang.Class<?> wildcardClass4 = seriesChangeEvent3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date6, timeZone7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        long long12 = month9.getFirstMillisecond();
        java.util.Date date13 = month9.getEnd();
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date13, timeZone14);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date13, timeZone16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date13);
        java.util.TimeZone timeZone19 = null;
        java.util.Locale locale20 = null;
        try {
            org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(date13, timeZone19, locale20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1559372400000L + "'", long12 == 1559372400000L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNull(regularTimePeriod17);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        java.lang.Class class0 = null;
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo2 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1.0f), seriesChangeInfo2);
        java.lang.Class<?> wildcardClass4 = seriesChangeEvent3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date6, timeZone7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        long long12 = month9.getFirstMillisecond();
        java.util.Date date13 = month9.getEnd();
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date13, timeZone14);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date13, timeZone16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.next();
        org.jfree.data.time.SerialDate serialDate20 = day18.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day18.previous();
        int int22 = day18.getMonth();
        boolean boolean24 = day18.equals((java.lang.Object) 100.0f);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener27 = null;
        timeSeries26.removeChangeListener(seriesChangeListener27);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener29 = null;
        timeSeries26.removeChangeListener(seriesChangeListener29);
        boolean boolean31 = timeSeries26.getNotify();
        timeSeries26.setMaximumItemCount((int) '#');
        java.lang.Class class34 = timeSeries26.getTimePeriodClass();
        timeSeries26.setMaximumItemCount(2147483647);
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener39 = null;
        timeSeries38.removeChangeListener(seriesChangeListener39);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener41 = null;
        timeSeries38.removeChangeListener(seriesChangeListener41);
        java.lang.String str43 = timeSeries38.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond((long) 8);
        timeSeries38.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond45, (java.lang.Number) (-1.0d));
        long long48 = fixedMillisecond45.getSerialIndex();
        java.lang.Number number49 = null;
        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond45, number49, false);
        int int52 = day18.compareTo((java.lang.Object) fixedMillisecond45);
        java.util.Calendar calendar53 = null;
        long long54 = fixedMillisecond45.getLastMillisecond(calendar53);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1559372400000L + "'", long12 == 1559372400000L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNull(class34);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "Value" + "'", str43.equals("Value"));
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 8L + "'", long48 == 8L);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 8L + "'", long54 == 8L);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond((long) 8);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (java.lang.Number) 0);
        boolean boolean7 = timeSeriesDataItem6.isSelected();
        boolean boolean8 = fixedMillisecond3.equals((java.lang.Object) timeSeriesDataItem6);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (java.lang.Number) 2147483647, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries1.addChangeListener(seriesChangeListener12);
        timeSeries1.setRangeDescription("hi!");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        int int3 = year2.getYear();
        long long4 = year2.getSerialIndex();
        long long5 = year2.getMiddleMillisecond();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(4, year2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year2.previous();
        try {
            org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (short) -1, year2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1562097599999L + "'", long5 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(6, 100);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 8);
        long long2 = fixedMillisecond1.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8L + "'", long2 == 8L);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int2 = timeSeries1.getMaximumItemCount();
        timeSeries1.setMaximumItemAge((long) 5);
        timeSeries1.fireSeriesChanged();
        double double6 = timeSeries1.getMinY();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries8.removeChangeListener(seriesChangeListener9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries8.removeChangeListener(seriesChangeListener11);
        java.lang.String str13 = timeSeries8.getRangeDescription();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries8.addChangeListener(seriesChangeListener14);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries8.removePropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) 8);
        long long20 = fixedMillisecond19.getSerialIndex();
        long long21 = fixedMillisecond19.getFirstMillisecond();
        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (java.lang.Number) 2147483647);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
        int int25 = month24.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month24.next();
        int int27 = fixedMillisecond19.compareTo((java.lang.Object) regularTimePeriod26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (double) (short) 100);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener32 = null;
        timeSeries31.removeChangeListener(seriesChangeListener32);
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        int int35 = month34.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = month34.next();
        timeSeries31.setKey((java.lang.Comparable) regularTimePeriod36);
        boolean boolean38 = timeSeries31.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) 8);
        long long41 = fixedMillisecond40.getSerialIndex();
        java.util.Calendar calendar42 = null;
        long long43 = fixedMillisecond40.getMiddleMillisecond(calendar42);
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener46 = null;
        timeSeries45.removeChangeListener(seriesChangeListener46);
        java.util.List list48 = timeSeries45.getItems();
        java.lang.String str49 = timeSeries45.getDescription();
        int int50 = fixedMillisecond40.compareTo((java.lang.Object) str49);
        timeSeries31.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, (java.lang.Number) 0);
        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries1.addAndOrUpdate(timeSeries31);
        timeSeries1.removeAgedItems(false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = timeSeries1.getNextTimePeriod();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent57 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) regularTimePeriod56);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo58 = null;
        seriesChangeEvent57.setSummary(seriesChangeInfo58);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Value" + "'", str13.equals("Value"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 8L + "'", long20 == 8L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 8L + "'", long21 == 8L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 6 + "'", int35 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 8L + "'", long41 == 8L);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 8L + "'", long43 == 8L);
        org.junit.Assert.assertNotNull(list48);
        org.junit.Assert.assertNull(str49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertNotNull(timeSeries53);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int4 = timeSeries3.getMaximumItemCount();
        java.lang.Object obj5 = timeSeries3.clone();
        timeSeries3.setKey((java.lang.Comparable) 1);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        int int9 = month8.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month8.next();
        int int11 = month8.getMonth();
        int int12 = month8.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) month8);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.next();
        timeSeries3.add(regularTimePeriod15, (-1.0d), true);
        boolean boolean19 = year0.equals((java.lang.Object) timeSeries3);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener22 = null;
        timeSeries21.removeChangeListener(seriesChangeListener22);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener24 = null;
        timeSeries21.removeChangeListener(seriesChangeListener24);
        boolean boolean26 = timeSeries21.getNotify();
        java.lang.Class class27 = timeSeries21.getTimePeriodClass();
        timeSeries21.setMaximumItemAge((long) '#');
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        int int31 = year30.getYear();
        java.lang.String str32 = year30.toString();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        int int34 = month33.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month33.next();
        long long36 = month33.getFirstMillisecond();
        long long37 = month33.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries21.createCopy((org.jfree.data.time.RegularTimePeriod) year30, (org.jfree.data.time.RegularTimePeriod) month33);
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener41 = null;
        timeSeries40.removeChangeListener(seriesChangeListener41);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener43 = null;
        timeSeries40.removeChangeListener(seriesChangeListener43);
        boolean boolean45 = timeSeries40.getNotify();
        java.lang.Class class46 = timeSeries40.getTimePeriodClass();
        java.lang.String str47 = timeSeries40.getDescription();
        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month();
        int int49 = month48.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = month48.next();
        long long51 = month48.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month48, (double) 1.0f);
        java.lang.Number number54 = timeSeriesDataItem53.getValue();
        timeSeries40.add(timeSeriesDataItem53, true);
        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener59 = null;
        timeSeries58.removeChangeListener(seriesChangeListener59);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener61 = null;
        timeSeries58.removeChangeListener(seriesChangeListener61);
        boolean boolean63 = timeSeries58.getNotify();
        timeSeries58.setMaximumItemCount((int) '#');
        java.lang.Class class66 = timeSeries58.getTimePeriodClass();
        timeSeries58.setMaximumItemCount(2147483647);
        org.jfree.data.time.TimeSeries timeSeries69 = timeSeries40.addAndOrUpdate(timeSeries58);
        org.jfree.data.time.Year year70 = new org.jfree.data.time.Year();
        long long71 = year70.getMiddleMillisecond();
        timeSeries69.add((org.jfree.data.time.RegularTimePeriod) year70, (double) 6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem75 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year70, (double) 4);
        int int76 = year70.getYear();
        int int77 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) year70);
        org.jfree.data.time.Year year78 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = year78.next();
        org.jfree.data.time.Month month80 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = month80.previous();
        int int82 = year78.compareTo((java.lang.Object) month80);
        try {
            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month80, 10.0d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNull(class27);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "2019" + "'", str32.equals("2019"));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1559372400000L + "'", long36 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1559372400000L + "'", long37 == 1559372400000L);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNull(class46);
        org.junit.Assert.assertNull(str47);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 6 + "'", int49 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1559372400000L + "'", long51 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + number54 + "' != '" + 1.0d + "'", number54.equals(1.0d));
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNull(class66);
        org.junit.Assert.assertNotNull(timeSeries69);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 1562097599999L + "'", long71 == 1562097599999L);
        org.junit.Assert.assertNull(timeSeriesDataItem75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 2019 + "'", int76 == 2019);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-1) + "'", int77 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod79);
        org.junit.Assert.assertNotNull(regularTimePeriod81);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 0 + "'", int82 == 0);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        long long2 = month0.getLastMillisecond();
        long long3 = month0.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 24234L + "'", long3 == 24234L);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        timeSeries1.setMaximumItemCount((int) '#');
        java.lang.Class class9 = timeSeries1.getTimePeriodClass();
        java.util.List list10 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries12.removeChangeListener(seriesChangeListener13);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries12.removeChangeListener(seriesChangeListener15);
        boolean boolean17 = timeSeries12.getNotify();
        java.lang.Class class18 = timeSeries12.getTimePeriodClass();
        timeSeries12.setMaximumItemAge((long) '#');
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        int int22 = year21.getYear();
        java.lang.String str23 = year21.toString();
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
        int int25 = month24.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month24.next();
        long long27 = month24.getFirstMillisecond();
        long long28 = month24.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) year21, (org.jfree.data.time.RegularTimePeriod) month24);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        long long31 = year30.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year30, (double) 100L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year30, (double) (byte) 0);
        timeSeries1.add(timeSeriesDataItem35, true);
        java.lang.Class class38 = null;
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo40 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent41 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1.0f), seriesChangeInfo40);
        java.lang.Class<?> wildcardClass42 = seriesChangeEvent41.getClass();
        java.lang.Class class43 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass42);
        java.util.Date date44 = null;
        java.util.TimeZone timeZone45 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass42, date44, timeZone45);
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
        int int48 = month47.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = month47.next();
        long long50 = month47.getFirstMillisecond();
        java.util.Date date51 = month47.getEnd();
        java.util.TimeZone timeZone52 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass42, date51, timeZone52);
        java.util.TimeZone timeZone54 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance(class38, date51, timeZone54);
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(date51);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = day56.next();
        org.jfree.data.time.SerialDate serialDate58 = day56.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = day56.previous();
        int int60 = day56.getMonth();
        boolean boolean62 = day56.equals((java.lang.Object) 100.0f);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem64 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day56, (double) 2147483647);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(class9);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(class18);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2019" + "'", str23.equals("2019"));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1559372400000L + "'", long27 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1559372400000L + "'", long28 == 1559372400000L);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1562097599999L + "'", long31 == 1562097599999L);
        org.junit.Assert.assertNull(timeSeriesDataItem33);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertNotNull(class43);
        org.junit.Assert.assertNull(regularTimePeriod46);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 6 + "'", int48 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1559372400000L + "'", long50 == 1559372400000L);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNull(regularTimePeriod53);
        org.junit.Assert.assertNull(regularTimePeriod55);
        org.junit.Assert.assertNotNull(regularTimePeriod57);
        org.junit.Assert.assertNotNull(serialDate58);
        org.junit.Assert.assertNotNull(regularTimePeriod59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 6 + "'", int60 == 6);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        long long2 = month0.getSerialIndex();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = month0.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int2 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        int int4 = month3.getMonth();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.previous();
        boolean boolean7 = month3.equals((java.lang.Object) month5);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month3, (java.lang.Number) 2147483647, false);
        java.lang.Comparable comparable11 = timeSeries1.getKey();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        int int13 = year12.getYear();
        java.lang.String str14 = year12.toString();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year12, (double) '4');
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + 100L + "'", comparable11.equals(100L));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond((long) 8);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (java.lang.Number) 0);
        boolean boolean7 = timeSeriesDataItem6.isSelected();
        boolean boolean8 = fixedMillisecond3.equals((java.lang.Object) timeSeriesDataItem6);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (java.lang.Number) 2147483647, false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = fixedMillisecond3.previous();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod1, (java.lang.Number) 2147483647);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        java.lang.Class class0 = null;
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo2 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1.0f), seriesChangeInfo2);
        java.lang.Class<?> wildcardClass4 = seriesChangeEvent3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date6, timeZone7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        long long12 = month9.getFirstMillisecond();
        java.util.Date date13 = month9.getEnd();
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date13, timeZone14);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date13, timeZone16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.next();
        org.jfree.data.time.SerialDate serialDate20 = day18.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day18.previous();
        int int22 = day18.getMonth();
        int int23 = day18.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate24 = day18.getSerialDate();
        int int25 = day18.getDayOfMonth();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1559372400000L + "'", long12 == 1559372400000L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 30 + "'", int23 == 30);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 30 + "'", int25 == 30);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, 11, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = month5.getMonth();
        timeSeries1.setKey((java.lang.Comparable) int6);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        int int9 = month8.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month8.next();
        long long11 = month8.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month8, (double) 1.0f);
        java.lang.Number number14 = timeSeriesDataItem13.getValue();
        timeSeriesDataItem13.setValue((java.lang.Number) 1559372400000L);
        java.lang.Object obj17 = null;
        boolean boolean18 = timeSeriesDataItem13.equals(obj17);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries1.addOrUpdate(timeSeriesDataItem13);
        java.lang.String str20 = timeSeries1.getDescription();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries1.getDataItem((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1559372400000L + "'", long11 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 1.0d + "'", number14.equals(1.0d));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertNull(str20);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Value");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        java.lang.String str3 = seriesException1.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesException: Value" + "'", str3.equals("org.jfree.data.general.SeriesException: Value"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int5 = timeSeries4.getMaximumItemCount();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        int int7 = month6.getMonth();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month8.previous();
        boolean boolean10 = month6.equals((java.lang.Object) month8);
        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) 2147483647, false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month6.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries18.removeChangeListener(seriesChangeListener19);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener21 = null;
        timeSeries18.removeChangeListener(seriesChangeListener21);
        boolean boolean23 = timeSeries18.getNotify();
        java.lang.Class class24 = timeSeries18.getTimePeriodClass();
        java.lang.String str25 = timeSeries18.getDescription();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        int int27 = month26.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = month26.next();
        long long29 = month26.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month26, (double) 1.0f);
        java.lang.Number number32 = timeSeriesDataItem31.getValue();
        timeSeries18.add(timeSeriesDataItem31, true);
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener37 = null;
        timeSeries36.removeChangeListener(seriesChangeListener37);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener39 = null;
        timeSeries36.removeChangeListener(seriesChangeListener39);
        boolean boolean41 = timeSeries36.getNotify();
        timeSeries36.setMaximumItemCount((int) '#');
        java.lang.Class class44 = timeSeries36.getTimePeriodClass();
        timeSeries36.setMaximumItemCount(2147483647);
        org.jfree.data.time.TimeSeries timeSeries47 = timeSeries18.addAndOrUpdate(timeSeries36);
        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month();
        int int49 = month48.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = month48.next();
        int int51 = month48.getMonth();
        int int52 = month48.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month48, (double) (byte) 1);
        timeSeries18.delete((org.jfree.data.time.RegularTimePeriod) month48);
        org.jfree.data.time.TimeSeries timeSeries56 = timeSeries1.addAndOrUpdate(timeSeries18);
        timeSeries56.removeAgedItems(0L, false);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(class24);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1559372400000L + "'", long29 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + number32 + "' != '" + 1.0d + "'", number32.equals(1.0d));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNull(class44);
        org.junit.Assert.assertNotNull(timeSeries47);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 6 + "'", int49 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 6 + "'", int51 == 6);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 6 + "'", int52 == 6);
        org.junit.Assert.assertNotNull(timeSeries56);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1.0f), seriesChangeInfo1);
        java.lang.Class<?> wildcardClass3 = seriesChangeEvent2.getClass();
        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(class4);
        org.junit.Assert.assertNotNull(class5);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        long long2 = year1.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year1.next();
        try {
            org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(2147483647, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        java.lang.String str3 = month0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month0.next();
        org.jfree.data.time.Year year5 = month0.getYear();
        java.lang.String str6 = year5.toString();
        long long7 = year5.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        timeSeries1.setMaximumItemCount((int) '#');
        java.lang.Class class9 = timeSeries1.getTimePeriodClass();
        timeSeries1.setMaximumItemCount(2147483647);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries13.removeChangeListener(seriesChangeListener14);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries13.removeChangeListener(seriesChangeListener16);
        java.lang.String str18 = timeSeries13.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) 8);
        timeSeries13.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (java.lang.Number) (-1.0d));
        long long23 = fixedMillisecond20.getSerialIndex();
        java.lang.Number number24 = null;
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, number24, false);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year27, (java.lang.Number) 0);
        java.lang.Number number30 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) year27);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int33 = timeSeries32.getMaximumItemCount();
        java.lang.Object obj34 = timeSeries32.clone();
        timeSeries32.setKey((java.lang.Comparable) 1);
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        int int38 = month37.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = month37.next();
        int int40 = month37.getMonth();
        int int41 = month37.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries32.getDataItem((org.jfree.data.time.RegularTimePeriod) month37);
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = year43.next();
        timeSeries32.add(regularTimePeriod44, (-1.0d), true);
        long long48 = timeSeries32.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener51 = null;
        timeSeries50.removeChangeListener(seriesChangeListener51);
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year(10);
        timeSeries50.add((org.jfree.data.time.RegularTimePeriod) year54, (double) (byte) 1, true);
        int int58 = timeSeries50.getMaximumItemCount();
        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year(10);
        timeSeries50.delete((org.jfree.data.time.RegularTimePeriod) year60);
        timeSeries32.delete((org.jfree.data.time.RegularTimePeriod) year60);
        java.lang.String str63 = year60.toString();
        java.lang.Number number64 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) year60);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(class9);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Value" + "'", str18.equals("Value"));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 8L + "'", long23 == 8L);
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2147483647 + "'", int33 == 2147483647);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 6 + "'", int38 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 6 + "'", int40 == 6);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 6 + "'", int41 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem42);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 9223372036854775807L + "'", long48 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 2147483647 + "'", int58 == 2147483647);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "10" + "'", str63.equals("10"));
        org.junit.Assert.assertNull(number64);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 8);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        long long5 = fixedMillisecond1.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8L + "'", long2 == 8L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 8L + "'", long4 == 8L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 8L + "'", long5 == 8L);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        long long3 = month0.getFirstMillisecond();
        java.util.Date date4 = month0.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        java.lang.Class class6 = null;
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo8 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1.0f), seriesChangeInfo8);
        java.lang.Class<?> wildcardClass10 = seriesChangeEvent9.getClass();
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        java.util.Date date12 = null;
        java.util.TimeZone timeZone13 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date12, timeZone13);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        int int16 = month15.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month15.next();
        long long18 = month15.getFirstMillisecond();
        java.util.Date date19 = month15.getEnd();
        java.util.TimeZone timeZone20 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date19, timeZone20);
        java.util.TimeZone timeZone22 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date19, timeZone22);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date19);
        java.lang.Object obj25 = null;
        boolean boolean26 = day24.equals(obj25);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((long) 8);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year29, (java.lang.Number) 0);
        boolean boolean32 = timeSeriesDataItem31.isSelected();
        boolean boolean33 = fixedMillisecond28.equals((java.lang.Object) timeSeriesDataItem31);
        java.lang.Object obj34 = timeSeriesDataItem31.clone();
        int int35 = day24.compareTo(obj34);
        boolean boolean36 = year5.equals((java.lang.Object) day24);
        long long37 = year5.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1559372400000L + "'", long3 == 1559372400000L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1559372400000L + "'", long18 == 1559372400000L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1577865599999L + "'", long37 == 1577865599999L);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int2 = timeSeries1.getMaximumItemCount();
        timeSeries1.setMaximumItemAge((long) 5);
        timeSeries1.fireSeriesChanged();
        double double6 = timeSeries1.getMinY();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries8.removeChangeListener(seriesChangeListener9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries8.removeChangeListener(seriesChangeListener11);
        java.lang.String str13 = timeSeries8.getRangeDescription();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries8.addChangeListener(seriesChangeListener14);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries8.removePropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) 8);
        long long20 = fixedMillisecond19.getSerialIndex();
        long long21 = fixedMillisecond19.getFirstMillisecond();
        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (java.lang.Number) 2147483647);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
        int int25 = month24.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month24.next();
        int int27 = fixedMillisecond19.compareTo((java.lang.Object) regularTimePeriod26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (double) (short) 100);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener32 = null;
        timeSeries31.removeChangeListener(seriesChangeListener32);
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        int int35 = month34.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = month34.next();
        timeSeries31.setKey((java.lang.Comparable) regularTimePeriod36);
        boolean boolean38 = timeSeries31.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) 8);
        long long41 = fixedMillisecond40.getSerialIndex();
        java.util.Calendar calendar42 = null;
        long long43 = fixedMillisecond40.getMiddleMillisecond(calendar42);
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener46 = null;
        timeSeries45.removeChangeListener(seriesChangeListener46);
        java.util.List list48 = timeSeries45.getItems();
        java.lang.String str49 = timeSeries45.getDescription();
        int int50 = fixedMillisecond40.compareTo((java.lang.Object) str49);
        timeSeries31.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, (java.lang.Number) 0);
        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries1.addAndOrUpdate(timeSeries31);
        timeSeries1.removeAgedItems(false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = timeSeries1.getNextTimePeriod();
        try {
            timeSeries1.delete((int) (byte) -1, 7, true);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Value" + "'", str13.equals("Value"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 8L + "'", long20 == 8L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 8L + "'", long21 == 8L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 6 + "'", int35 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 8L + "'", long41 == 8L);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 8L + "'", long43 == 8L);
        org.junit.Assert.assertNotNull(list48);
        org.junit.Assert.assertNull(str49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertNotNull(timeSeries53);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        java.lang.Object obj7 = timeSeries1.clone();
        timeSeries1.clear();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        java.lang.Class class0 = null;
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo2 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1.0f), seriesChangeInfo2);
        java.lang.Class<?> wildcardClass4 = seriesChangeEvent3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date6, timeZone7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        long long12 = month9.getFirstMillisecond();
        java.util.Date date13 = month9.getEnd();
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date13, timeZone14);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date13, timeZone16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.next();
        org.jfree.data.time.SerialDate serialDate20 = day18.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day18.previous();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod21);
        double double23 = timeSeries22.getMinY();
        double double24 = timeSeries22.getMinY();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1559372400000L + "'", long12 == 1559372400000L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double24, Double.NaN, 0);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int2 = timeSeries1.getMaximumItemCount();
        java.lang.Object obj3 = timeSeries1.clone();
        timeSeries1.setKey((java.lang.Comparable) 1);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        int int7 = month6.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month6.next();
        int int9 = month6.getMonth();
        int int10 = month6.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month6);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.next();
        timeSeries1.add(regularTimePeriod13, (-1.0d), true);
        long long17 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries19.removeChangeListener(seriesChangeListener20);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(10);
        timeSeries19.add((org.jfree.data.time.RegularTimePeriod) year23, (double) (byte) 1, true);
        int int27 = timeSeries19.getMaximumItemCount();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(10);
        timeSeries19.delete((org.jfree.data.time.RegularTimePeriod) year29);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) year29);
        boolean boolean32 = timeSeries1.isEmpty();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 9223372036854775807L + "'", long17 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2147483647 + "'", int27 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        timeSeries1.setMaximumItemAge((long) '#');
        timeSeries1.removeAgedItems(false);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeries1.getTimePeriod(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(class7);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int2 = timeSeries1.getMaximumItemCount();
        timeSeries1.setMaximumItemAge((long) 5);
        timeSeries1.fireSeriesChanged();
        double double6 = timeSeries1.getMinY();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries8.removeChangeListener(seriesChangeListener9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries8.removeChangeListener(seriesChangeListener11);
        java.lang.String str13 = timeSeries8.getRangeDescription();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries8.addChangeListener(seriesChangeListener14);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries8.removePropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) 8);
        long long20 = fixedMillisecond19.getSerialIndex();
        long long21 = fixedMillisecond19.getFirstMillisecond();
        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (java.lang.Number) 2147483647);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
        int int25 = month24.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month24.next();
        int int27 = fixedMillisecond19.compareTo((java.lang.Object) regularTimePeriod26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (double) (short) 100);
        java.util.Calendar calendar30 = null;
        long long31 = fixedMillisecond19.getFirstMillisecond(calendar30);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Value" + "'", str13.equals("Value"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 8L + "'", long20 == 8L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 8L + "'", long21 == 8L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 8L + "'", long31 == 8L);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int2 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        int int4 = month3.getMonth();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.previous();
        boolean boolean7 = month3.equals((java.lang.Object) month5);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month3, (java.lang.Number) 2147483647, false);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries12.removeChangeListener(seriesChangeListener13);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries12.removeChangeListener(seriesChangeListener15);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        int int18 = month17.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month17.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month17, (double) 10.0f);
        int int22 = month3.compareTo((java.lang.Object) 10.0f);
        java.lang.String str23 = month3.toString();
        long long24 = month3.getFirstMillisecond();
        java.util.Calendar calendar25 = null;
        try {
            long long26 = month3.getFirstMillisecond(calendar25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "June 2019" + "'", str23.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1559372400000L + "'", long24 == 1559372400000L);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        java.lang.Class class0 = null;
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo2 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1.0f), seriesChangeInfo2);
        java.lang.Class<?> wildcardClass4 = seriesChangeEvent3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date6, timeZone7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        long long12 = month9.getFirstMillisecond();
        java.util.Date date13 = month9.getEnd();
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date13, timeZone14);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date13, timeZone16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.next();
        org.jfree.data.time.SerialDate serialDate20 = day18.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day18.previous();
        int int22 = day18.getMonth();
        int int23 = day18.getYear();
        int int24 = day18.getYear();
        java.util.Calendar calendar25 = null;
        try {
            long long26 = day18.getLastMillisecond(calendar25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1559372400000L + "'", long12 == 1559372400000L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        java.lang.String str3 = month0.toString();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        int int5 = month4.getMonth();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month6.previous();
        boolean boolean8 = month4.equals((java.lang.Object) month6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month6.previous();
        org.jfree.data.time.Year year10 = month6.getYear();
        boolean boolean11 = month0.equals((java.lang.Object) month6);
        long long12 = month0.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560668399999L + "'", long12 == 1560668399999L);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        java.lang.String str8 = timeSeries1.getDescription();
        java.lang.String str9 = timeSeries1.getDomainDescription();
        timeSeries1.setNotify(true);
        timeSeries1.setDescription("org.jfree.data.event.SeriesChangeEvent[source=org.jfree.data.general.SeriesException: Value]");
        long long14 = timeSeries1.getMaximumItemAge();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 9223372036854775807L + "'", long14 == 9223372036854775807L);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = month0.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) -1, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        timeSeries1.clear();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int2 = timeSeries1.getMaximumItemCount();
        java.lang.Object obj3 = timeSeries1.clone();
        timeSeries1.setKey((java.lang.Comparable) 1);
        java.util.Collection collection6 = timeSeries1.getTimePeriods();
        java.lang.String str7 = timeSeries1.getDescription();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries1.addChangeListener(seriesChangeListener8);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection6);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        timeSeries1.setMaximumItemAge((long) '#');
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        int int11 = year10.getYear();
        java.lang.String str12 = year10.toString();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        int int14 = month13.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month13.next();
        long long16 = month13.getFirstMillisecond();
        long long17 = month13.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year10, (org.jfree.data.time.RegularTimePeriod) month13);
        long long19 = month13.getSerialIndex();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int21 = year20.getYear();
        long long22 = year20.getSerialIndex();
        org.jfree.data.general.SeriesException seriesException24 = new org.jfree.data.general.SeriesException("Value");
        java.lang.Throwable[] throwableArray25 = seriesException24.getSuppressed();
        org.jfree.data.general.SeriesException seriesException27 = new org.jfree.data.general.SeriesException("Value");
        seriesException24.addSuppressed((java.lang.Throwable) seriesException27);
        boolean boolean29 = year20.equals((java.lang.Object) seriesException27);
        int int30 = month13.compareTo((java.lang.Object) boolean29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month13.next();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1559372400000L + "'", long16 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1559372400000L + "'", long17 == 1559372400000L);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 24234L + "'", long19 == 24234L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 2019L + "'", long22 == 2019L);
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        timeSeries1.setMaximumItemCount((int) '#');
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) 8);
        java.util.Calendar calendar11 = null;
        fixedMillisecond10.peg(calendar11);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (double) '#', false);
        java.lang.Class class16 = null;
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo18 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1.0f), seriesChangeInfo18);
        java.lang.Class<?> wildcardClass20 = seriesChangeEvent19.getClass();
        java.lang.Class class21 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass20);
        java.util.Date date22 = null;
        java.util.TimeZone timeZone23 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date22, timeZone23);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        int int26 = month25.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = month25.next();
        long long28 = month25.getFirstMillisecond();
        java.util.Date date29 = month25.getEnd();
        java.util.TimeZone timeZone30 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date29, timeZone30);
        java.util.TimeZone timeZone32 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date29, timeZone32);
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = day34.next();
        org.jfree.data.time.SerialDate serialDate36 = day34.getSerialDate();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(serialDate36);
        timeSeries1.setKey((java.lang.Comparable) serialDate36);
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(serialDate36);
        int int40 = day39.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(class21);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 6 + "'", int26 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1559372400000L + "'", long28 == 1559372400000L);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 30 + "'", int40 == 30);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        java.lang.Class class0 = null;
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo2 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1.0f), seriesChangeInfo2);
        java.lang.Class<?> wildcardClass4 = seriesChangeEvent3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date6, timeZone7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        long long12 = month9.getFirstMillisecond();
        java.util.Date date13 = month9.getEnd();
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date13, timeZone14);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date13, timeZone16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date13);
        java.util.TimeZone timeZone19 = null;
        try {
            org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date13, timeZone19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1559372400000L + "'", long12 == 1559372400000L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNull(regularTimePeriod17);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int2 = timeSeries1.getMaximumItemCount();
        timeSeries1.setMaximumItemAge((long) 5);
        timeSeries1.fireSeriesChanged();
        double double6 = timeSeries1.getMinY();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries8.removeChangeListener(seriesChangeListener9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries8.removeChangeListener(seriesChangeListener11);
        java.lang.String str13 = timeSeries8.getRangeDescription();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries8.addChangeListener(seriesChangeListener14);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries8.removePropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) 8);
        long long20 = fixedMillisecond19.getSerialIndex();
        long long21 = fixedMillisecond19.getFirstMillisecond();
        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (java.lang.Number) 2147483647);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
        int int25 = month24.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month24.next();
        int int27 = fixedMillisecond19.compareTo((java.lang.Object) regularTimePeriod26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (double) (short) 100);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener32 = null;
        timeSeries31.removeChangeListener(seriesChangeListener32);
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        int int35 = month34.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = month34.next();
        timeSeries31.setKey((java.lang.Comparable) regularTimePeriod36);
        boolean boolean38 = timeSeries31.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) 8);
        long long41 = fixedMillisecond40.getSerialIndex();
        java.util.Calendar calendar42 = null;
        long long43 = fixedMillisecond40.getMiddleMillisecond(calendar42);
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener46 = null;
        timeSeries45.removeChangeListener(seriesChangeListener46);
        java.util.List list48 = timeSeries45.getItems();
        java.lang.String str49 = timeSeries45.getDescription();
        int int50 = fixedMillisecond40.compareTo((java.lang.Object) str49);
        timeSeries31.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, (java.lang.Number) 0);
        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries1.addAndOrUpdate(timeSeries31);
        timeSeries1.removeAgedItems(false);
        org.jfree.data.time.Month month56 = new org.jfree.data.time.Month();
        int int57 = month56.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = month56.next();
        java.lang.String str59 = month56.toString();
        org.jfree.data.time.Month month60 = new org.jfree.data.time.Month();
        int int61 = month60.getMonth();
        org.jfree.data.time.Month month62 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = month62.previous();
        boolean boolean64 = month60.equals((java.lang.Object) month62);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = month62.previous();
        org.jfree.data.time.Year year66 = month62.getYear();
        boolean boolean67 = month56.equals((java.lang.Object) month62);
        long long68 = month62.getLastMillisecond();
        int int69 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month62);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Value" + "'", str13.equals("Value"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 8L + "'", long20 == 8L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 8L + "'", long21 == 8L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 6 + "'", int35 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 8L + "'", long41 == 8L);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 8L + "'", long43 == 8L);
        org.junit.Assert.assertNotNull(list48);
        org.junit.Assert.assertNull(str49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertNotNull(timeSeries53);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 6 + "'", int57 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "June 2019" + "'", str59.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 6 + "'", int61 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod65);
        org.junit.Assert.assertNotNull(year66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 1561964399999L + "'", long68 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int2 = timeSeries1.getMaximumItemCount();
        java.lang.Object obj3 = timeSeries1.clone();
        timeSeries1.setKey((java.lang.Comparable) 1);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        int int7 = month6.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month6.next();
        int int9 = month6.getMonth();
        int int10 = month6.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month6);
        timeSeries1.setDescription("");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        long long3 = month0.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) 1.0f);
        java.lang.Number number6 = timeSeriesDataItem5.getValue();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        int int8 = month7.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month7.next();
        long long10 = month7.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries12.removeChangeListener(seriesChangeListener13);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries12.removeChangeListener(seriesChangeListener15);
        java.lang.String str17 = timeSeries12.getRangeDescription();
        int int18 = month7.compareTo((java.lang.Object) timeSeries12);
        java.util.List list19 = timeSeries12.getItems();
        boolean boolean20 = timeSeriesDataItem5.equals((java.lang.Object) timeSeries12);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries12.getDataItem(6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1559372400000L + "'", long3 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1.0d + "'", number6.equals(1.0d));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1559372400000L + "'", long10 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Value" + "'", str17.equals("Value"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("June 2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        long long3 = month0.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries5.removeChangeListener(seriesChangeListener6);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries5.removeChangeListener(seriesChangeListener8);
        java.lang.String str10 = timeSeries5.getRangeDescription();
        int int11 = month0.compareTo((java.lang.Object) timeSeries5);
        double double12 = timeSeries5.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int15 = timeSeries14.getMaximumItemCount();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        int int17 = month16.getMonth();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month18.previous();
        boolean boolean20 = month16.equals((java.lang.Object) month18);
        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) month16, (java.lang.Number) 2147483647, false);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener26 = null;
        timeSeries25.removeChangeListener(seriesChangeListener26);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener28 = null;
        timeSeries25.removeChangeListener(seriesChangeListener28);
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
        int int31 = month30.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = month30.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries25.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month30, (double) 10.0f);
        int int35 = month16.compareTo((java.lang.Object) 10.0f);
        java.lang.String str36 = month16.toString();
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int39 = timeSeries38.getMaximumItemCount();
        boolean boolean40 = month16.equals((java.lang.Object) int39);
        org.jfree.data.time.Year year41 = month16.getYear();
        int int42 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) year41);
        int int43 = timeSeries5.getMaximumItemCount();
        timeSeries5.setNotify(false);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1559372400000L + "'", long3 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Value" + "'", str10.equals("Value"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2147483647 + "'", int15 == 2147483647);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 6 + "'", int31 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNull(timeSeriesDataItem34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "June 2019" + "'", str36.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2147483647 + "'", int39 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(year41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 2147483647 + "'", int43 == 2147483647);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        long long3 = month0.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries5.removeChangeListener(seriesChangeListener6);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries5.removeChangeListener(seriesChangeListener8);
        java.lang.String str10 = timeSeries5.getRangeDescription();
        int int11 = month0.compareTo((java.lang.Object) timeSeries5);
        java.util.List list12 = timeSeries5.getItems();
        java.lang.Comparable comparable13 = timeSeries5.getKey();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1559372400000L + "'", long3 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Value" + "'", str10.equals("Value"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + 100L + "'", comparable13.equals(100L));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        java.lang.String str8 = timeSeries1.getDescription();
        java.lang.String str9 = timeSeries1.getDomainDescription();
        timeSeries1.setNotify(true);
        timeSeries1.setDescription("May -1");
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        java.lang.Class class0 = null;
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo2 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1.0f), seriesChangeInfo2);
        java.lang.Class<?> wildcardClass4 = seriesChangeEvent3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date6, timeZone7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        long long12 = month9.getFirstMillisecond();
        java.util.Date date13 = month9.getEnd();
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date13, timeZone14);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date13, timeZone16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.SerialDate serialDate19 = day18.getSerialDate();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1559372400000L + "'", long12 == 1559372400000L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(serialDate19);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.previous();
        boolean boolean4 = month0.equals((java.lang.Object) month2);
        org.jfree.data.time.Year year5 = month2.getYear();
        java.util.Calendar calendar6 = null;
        try {
            year5.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(year5);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        java.lang.Class class0 = null;
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        long long2 = year1.getMiddleMillisecond();
        java.util.Date date3 = year1.getEnd();
        java.util.Date date4 = year1.getEnd();
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date4, timeZone5);
        java.util.TimeZone timeZone7 = null;
        try {
            org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date4, timeZone7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(regularTimePeriod6);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 8);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries6.removeChangeListener(seriesChangeListener7);
        java.util.List list9 = timeSeries6.getItems();
        java.lang.String str10 = timeSeries6.getDescription();
        int int11 = fixedMillisecond1.compareTo((java.lang.Object) str10);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries13.removeChangeListener(seriesChangeListener14);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries13.removeChangeListener(seriesChangeListener16);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        int int19 = month18.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month18, (double) 10.0f);
        double double23 = timeSeries13.getMaxY();
        boolean boolean24 = timeSeries13.getNotify();
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener27 = null;
        timeSeries26.removeChangeListener(seriesChangeListener27);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener29 = null;
        timeSeries26.removeChangeListener(seriesChangeListener29);
        boolean boolean31 = timeSeries26.getNotify();
        java.lang.Class class32 = timeSeries26.getTimePeriodClass();
        java.lang.String str33 = timeSeries26.getDescription();
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        int int35 = month34.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = month34.next();
        long long37 = month34.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month34, (double) 1.0f);
        java.lang.Number number40 = timeSeriesDataItem39.getValue();
        timeSeries26.add(timeSeriesDataItem39, true);
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener45 = null;
        timeSeries44.removeChangeListener(seriesChangeListener45);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener47 = null;
        timeSeries44.removeChangeListener(seriesChangeListener47);
        boolean boolean49 = timeSeries44.getNotify();
        timeSeries44.setMaximumItemCount((int) '#');
        java.lang.Class class52 = timeSeries44.getTimePeriodClass();
        timeSeries44.setMaximumItemCount(2147483647);
        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries26.addAndOrUpdate(timeSeries44);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = timeSeries26.getNextTimePeriod();
        java.util.Collection collection57 = timeSeries13.getTimePeriodsUniqueToOtherSeries(timeSeries26);
        int int58 = fixedMillisecond1.compareTo((java.lang.Object) collection57);
        java.util.Date date59 = fixedMillisecond1.getStart();
        java.util.TimeZone timeZone60 = null;
        try {
            org.jfree.data.time.Month month61 = new org.jfree.data.time.Month(date59, timeZone60);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8L + "'", long2 == 8L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 8L + "'", long4 == 8L);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 10.0d + "'", double23 == 10.0d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNull(class32);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 6 + "'", int35 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1559372400000L + "'", long37 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + number40 + "' != '" + 1.0d + "'", number40.equals(1.0d));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNull(class52);
        org.junit.Assert.assertNotNull(timeSeries55);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertNotNull(collection57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
        org.junit.Assert.assertNotNull(date59);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        java.lang.Class class0 = null;
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo2 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1.0f), seriesChangeInfo2);
        java.lang.Class<?> wildcardClass4 = seriesChangeEvent3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date6, timeZone7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        long long12 = month9.getFirstMillisecond();
        java.util.Date date13 = month9.getEnd();
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date13, timeZone14);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date13, timeZone16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.next();
        org.jfree.data.time.SerialDate serialDate20 = day18.getSerialDate();
        java.lang.String str21 = day18.toString();
        long long22 = day18.getMiddleMillisecond();
        long long23 = day18.getFirstMillisecond();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1559372400000L + "'", long12 == 1559372400000L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "30-June-2019" + "'", str21.equals("30-June-2019"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1561921199999L + "'", long22 == 1561921199999L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1561878000000L + "'", long23 == 1561878000000L);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 8);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries6.removeChangeListener(seriesChangeListener7);
        java.util.List list9 = timeSeries6.getItems();
        java.lang.String str10 = timeSeries6.getDescription();
        int int11 = fixedMillisecond1.compareTo((java.lang.Object) str10);
        java.util.Date date12 = fixedMillisecond1.getStart();
        long long13 = fixedMillisecond1.getFirstMillisecond();
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond1.getMiddleMillisecond(calendar14);
        long long16 = fixedMillisecond1.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8L + "'", long2 == 8L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 8L + "'", long4 == 8L);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 8L + "'", long13 == 8L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 8L + "'", long15 == 8L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 8L + "'", long16 == 8L);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int2 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        int int4 = month3.getMonth();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.previous();
        boolean boolean7 = month3.equals((java.lang.Object) month5);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month3, (java.lang.Number) 2147483647, false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month3.previous();
        java.lang.String str12 = month3.toString();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "June 2019" + "'", str12.equals("June 2019"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int2 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        int int4 = month3.getMonth();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.previous();
        boolean boolean7 = month3.equals((java.lang.Object) month5);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month3, (java.lang.Number) 2147483647, false);
        int int11 = timeSeries1.getMaximumItemCount();
        try {
            timeSeries1.update((int) (byte) -1, (java.lang.Number) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2147483647 + "'", int11 == 2147483647);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(10);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year5, (double) (byte) 1, true);
        java.lang.Object obj9 = null;
        boolean boolean10 = timeSeries1.equals(obj9);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries12.removeChangeListener(seriesChangeListener13);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries12.removeChangeListener(seriesChangeListener15);
        boolean boolean17 = timeSeries12.getNotify();
        timeSeries12.setMaximumItemCount((int) '#');
        java.lang.Class class20 = timeSeries12.getTimePeriodClass();
        timeSeries12.setMaximumItemCount(2147483647);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries24.removeChangeListener(seriesChangeListener25);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener27 = null;
        timeSeries24.removeChangeListener(seriesChangeListener27);
        java.lang.String str29 = timeSeries24.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) 8);
        timeSeries24.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31, (java.lang.Number) (-1.0d));
        long long34 = fixedMillisecond31.getSerialIndex();
        java.lang.Number number35 = null;
        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31, number35, false);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year38, (java.lang.Number) 0);
        java.lang.Number number41 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) year38);
        try {
            org.jfree.data.time.TimeSeries timeSeries42 = timeSeries1.addAndOrUpdate(timeSeries12);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(class20);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Value" + "'", str29.equals("Value"));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 8L + "'", long34 == 8L);
        org.junit.Assert.assertNull(number41);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        java.lang.String str3 = month0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month0.next();
        org.jfree.data.time.Year year5 = month0.getYear();
        java.util.Calendar calendar6 = null;
        try {
            year5.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(year5);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0);
        org.jfree.data.general.SeriesException seriesException9 = new org.jfree.data.general.SeriesException("Value");
        java.lang.Throwable[] throwableArray10 = seriesException9.getSuppressed();
        org.jfree.data.general.SeriesException seriesException12 = new org.jfree.data.general.SeriesException("Value");
        seriesException9.addSuppressed((java.lang.Throwable) seriesException12);
        boolean boolean14 = timeSeriesDataItem7.equals((java.lang.Object) seriesException9);
        java.lang.Object obj15 = timeSeriesDataItem7.clone();
        timeSeries1.add(timeSeriesDataItem7);
        timeSeriesDataItem7.setValue((java.lang.Number) (-1));
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int2 = timeSeries1.getMaximumItemCount();
        java.lang.Object obj3 = timeSeries1.clone();
        timeSeries1.setKey((java.lang.Comparable) 1);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        int int7 = month6.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month6.next();
        int int9 = month6.getMonth();
        int int10 = month6.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month6);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.next();
        timeSeries1.add(regularTimePeriod13, (-1.0d), true);
        long long17 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries19.removeChangeListener(seriesChangeListener20);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(10);
        timeSeries19.add((org.jfree.data.time.RegularTimePeriod) year23, (double) (byte) 1, true);
        int int27 = timeSeries19.getMaximumItemCount();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(10);
        timeSeries19.delete((org.jfree.data.time.RegularTimePeriod) year29);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) year29);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo32 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent33 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year29, seriesChangeInfo32);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo34 = null;
        seriesChangeEvent33.setSummary(seriesChangeInfo34);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 9223372036854775807L + "'", long17 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2147483647 + "'", int27 == 2147483647);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) 0);
        boolean boolean3 = timeSeriesDataItem2.isSelected();
        timeSeriesDataItem2.setValue((java.lang.Number) 9999);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        java.lang.Class class0 = null;
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo2 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1.0f), seriesChangeInfo2);
        java.lang.Class<?> wildcardClass4 = seriesChangeEvent3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date6, timeZone7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        long long12 = month9.getFirstMillisecond();
        java.util.Date date13 = month9.getEnd();
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date13, timeZone14);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date13, timeZone16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date13);
        int int19 = day18.getMonth();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        long long21 = year20.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year20.next();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent23 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year20);
        int int24 = day18.compareTo((java.lang.Object) year20);
        int int25 = day18.getYear();
        int int26 = day18.getMonth();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1559372400000L + "'", long12 == 1559372400000L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1546329600000L + "'", long21 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2019 + "'", int25 == 2019);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 6 + "'", int26 == 6);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        java.lang.String str8 = timeSeries1.getDescription();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        long long12 = month9.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (double) 1.0f);
        java.lang.Number number15 = timeSeriesDataItem14.getValue();
        timeSeries1.add(timeSeriesDataItem14, true);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries19.removeChangeListener(seriesChangeListener20);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener22 = null;
        timeSeries19.removeChangeListener(seriesChangeListener22);
        boolean boolean24 = timeSeries19.getNotify();
        timeSeries19.setMaximumItemCount((int) '#');
        java.lang.Class class27 = timeSeries19.getTimePeriodClass();
        timeSeries19.setMaximumItemCount(2147483647);
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries1.addAndOrUpdate(timeSeries19);
        java.util.List list31 = timeSeries30.getItems();
        java.lang.Comparable comparable32 = timeSeries30.getKey();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1559372400000L + "'", long12 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 1.0d + "'", number15.equals(1.0d));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(class27);
        org.junit.Assert.assertNotNull(timeSeries30);
        org.junit.Assert.assertNotNull(list31);
        org.junit.Assert.assertTrue("'" + comparable32 + "' != '" + "Overwritten values from: 100" + "'", comparable32.equals("Overwritten values from: 100"));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1.0f), seriesChangeInfo1);
        java.lang.Class<?> wildcardClass3 = seriesChangeEvent2.getClass();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries5.removeChangeListener(seriesChangeListener6);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries5.removeChangeListener(seriesChangeListener8);
        boolean boolean10 = timeSeries5.getNotify();
        java.lang.Class class11 = timeSeries5.getTimePeriodClass();
        java.lang.Class<?> wildcardClass12 = timeSeries5.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 8);
        long long15 = fixedMillisecond14.getSerialIndex();
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond14.getMiddleMillisecond(calendar16);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries19.removeChangeListener(seriesChangeListener20);
        java.util.List list22 = timeSeries19.getItems();
        java.lang.String str23 = timeSeries19.getDescription();
        int int24 = fixedMillisecond14.compareTo((java.lang.Object) str23);
        java.util.Date date25 = fixedMillisecond14.getStart();
        long long26 = fixedMillisecond14.getMiddleMillisecond();
        java.util.Date date27 = fixedMillisecond14.getTime();
        java.util.TimeZone timeZone28 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date27, timeZone28);
        java.util.TimeZone timeZone30 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date27, timeZone30);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(class11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 8L + "'", long15 == 8L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 8L + "'", long17 == 8L);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 8L + "'", long26 == 8L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertNull(regularTimePeriod31);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 8);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getFirstMillisecond(calendar5);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8L + "'", long2 == 8L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 8L + "'", long4 == 8L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 8L + "'", long6 == 8L);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        java.util.Calendar calendar3 = null;
        try {
            year0.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) 0);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo3 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 0, seriesChangeInfo3);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        java.lang.Class class0 = null;
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo2 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1.0f), seriesChangeInfo2);
        java.lang.Class<?> wildcardClass4 = seriesChangeEvent3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date6, timeZone7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        long long12 = month9.getFirstMillisecond();
        java.util.Date date13 = month9.getEnd();
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date13, timeZone14);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date13, timeZone16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.next();
        long long20 = day18.getFirstMillisecond();
        long long21 = day18.getSerialIndex();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1559372400000L + "'", long12 == 1559372400000L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1561878000000L + "'", long20 == 1561878000000L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 43646L + "'", long21 == 43646L);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        timeSeries1.setMaximumItemCount((int) '#');
        java.lang.Class class9 = timeSeries1.getTimePeriodClass();
        timeSeries1.setMaximumItemCount(2147483647);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries13.removeChangeListener(seriesChangeListener14);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries13.removeChangeListener(seriesChangeListener16);
        java.lang.String str18 = timeSeries13.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) 8);
        timeSeries13.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (java.lang.Number) (-1.0d));
        long long23 = fixedMillisecond20.getSerialIndex();
        java.lang.Number number24 = null;
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, number24, false);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        int int28 = month27.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month27.next();
        java.lang.String str30 = month27.toString();
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
        int int32 = month31.getMonth();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = month33.previous();
        boolean boolean35 = month31.equals((java.lang.Object) month33);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = month33.previous();
        org.jfree.data.time.Year year37 = month33.getYear();
        boolean boolean38 = month27.equals((java.lang.Object) month33);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) 8);
        long long41 = fixedMillisecond40.getSerialIndex();
        java.util.Calendar calendar42 = null;
        long long43 = fixedMillisecond40.getMiddleMillisecond(calendar42);
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener46 = null;
        timeSeries45.removeChangeListener(seriesChangeListener46);
        java.util.List list48 = timeSeries45.getItems();
        java.lang.String str49 = timeSeries45.getDescription();
        int int50 = fixedMillisecond40.compareTo((java.lang.Object) str49);
        java.util.Date date51 = fixedMillisecond40.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond(date51);
        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month33, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond52);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem55 = timeSeries1.getDataItem(0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(class9);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Value" + "'", str18.equals("Value"));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 8L + "'", long23 == 8L);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "June 2019" + "'", str30.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 6 + "'", int32 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(year37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 8L + "'", long41 == 8L);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 8L + "'", long43 == 8L);
        org.junit.Assert.assertNotNull(list48);
        org.junit.Assert.assertNull(str49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(timeSeries53);
        org.junit.Assert.assertNotNull(timeSeriesDataItem55);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 5);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        int int2 = month0.getYearValue();
        long long3 = month0.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) 1562097599999L);
        timeSeriesDataItem5.setValue((java.lang.Number) 10.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 24234L + "'", long3 == 24234L);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int2 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        int int4 = month3.getMonth();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.previous();
        boolean boolean7 = month3.equals((java.lang.Object) month5);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month3, (java.lang.Number) 2147483647, false);
        int int11 = timeSeries1.getMaximumItemCount();
        timeSeries1.fireSeriesChanged();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        int int14 = month13.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month13.next();
        long long16 = month13.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month13, (double) 1.0f);
        java.lang.Number number19 = timeSeriesDataItem18.getValue();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int22 = timeSeries21.getMaximumItemCount();
        java.lang.Object obj23 = timeSeries21.clone();
        timeSeries21.setKey((java.lang.Comparable) 1);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        int int27 = month26.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = month26.next();
        int int29 = month26.getMonth();
        int int30 = month26.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries21.getDataItem((org.jfree.data.time.RegularTimePeriod) month26);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year32.next();
        timeSeries21.add(regularTimePeriod33, (-1.0d), true);
        boolean boolean37 = timeSeriesDataItem18.equals((java.lang.Object) (-1.0d));
        java.lang.Number number38 = timeSeriesDataItem18.getValue();
        timeSeriesDataItem18.setSelected(true);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = timeSeriesDataItem18.getPeriod();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries1.addOrUpdate(timeSeriesDataItem18);
        timeSeries1.clear();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = timeSeries1.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2147483647 + "'", int11 == 2147483647);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1559372400000L + "'", long16 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 1.0d + "'", number19.equals(1.0d));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2147483647 + "'", int22 == 2147483647);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem31);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + number38 + "' != '" + 1.0d + "'", number38.equals(1.0d));
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(timeSeriesDataItem42);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        long long3 = month0.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries5.removeChangeListener(seriesChangeListener6);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries5.removeChangeListener(seriesChangeListener8);
        java.lang.String str10 = timeSeries5.getRangeDescription();
        int int11 = month0.compareTo((java.lang.Object) timeSeries5);
        int int12 = timeSeries5.getItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        int int14 = month13.getMonth();
        int int15 = month13.getYearValue();
        org.jfree.data.time.Year year16 = month13.getYear();
        org.jfree.data.time.Year year17 = month13.getYear();
        boolean boolean18 = timeSeries5.equals((java.lang.Object) year17);
        timeSeries5.fireSeriesChanged();
        boolean boolean20 = timeSeries5.isEmpty();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1559372400000L + "'", long3 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Value" + "'", str10.equals("Value"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(year16);
        org.junit.Assert.assertNotNull(year17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

//    @Test
//    public void test428() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test428");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        java.util.Calendar calendar2 = null;
//        fixedMillisecond0.peg(calendar2);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
//        timeSeries5.removeChangeListener(seriesChangeListener6);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries5.removeChangeListener(seriesChangeListener8);
//        boolean boolean10 = timeSeries5.getNotify();
//        timeSeries5.setMaximumItemCount((int) '#');
//        java.lang.Class class13 = timeSeries5.getTimePeriodClass();
//        java.util.List list14 = timeSeries5.getItems();
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener17 = null;
//        timeSeries16.removeChangeListener(seriesChangeListener17);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
//        timeSeries16.removeChangeListener(seriesChangeListener19);
//        boolean boolean21 = timeSeries16.getNotify();
//        java.lang.Class class22 = timeSeries16.getTimePeriodClass();
//        timeSeries16.setMaximumItemAge((long) '#');
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
//        int int26 = year25.getYear();
//        java.lang.String str27 = year25.toString();
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
//        int int29 = month28.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month28.next();
//        long long31 = month28.getFirstMillisecond();
//        long long32 = month28.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries16.createCopy((org.jfree.data.time.RegularTimePeriod) year25, (org.jfree.data.time.RegularTimePeriod) month28);
//        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
//        long long35 = year34.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year34, (double) 100L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year34, (double) (byte) 0);
//        timeSeries5.add(timeSeriesDataItem39, true);
//        java.lang.Class class42 = null;
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo44 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent45 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1.0f), seriesChangeInfo44);
//        java.lang.Class<?> wildcardClass46 = seriesChangeEvent45.getClass();
//        java.lang.Class class47 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass46);
//        java.util.Date date48 = null;
//        java.util.TimeZone timeZone49 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass46, date48, timeZone49);
//        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month();
//        int int52 = month51.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = month51.next();
//        long long54 = month51.getFirstMillisecond();
//        java.util.Date date55 = month51.getEnd();
//        java.util.TimeZone timeZone56 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass46, date55, timeZone56);
//        java.util.TimeZone timeZone58 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance(class42, date55, timeZone58);
//        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(date55);
//        java.lang.Object obj61 = null;
//        boolean boolean62 = day60.equals(obj61);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond64 = new org.jfree.data.time.FixedMillisecond((long) 8);
//        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem67 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year65, (java.lang.Number) 0);
//        boolean boolean68 = timeSeriesDataItem67.isSelected();
//        boolean boolean69 = fixedMillisecond64.equals((java.lang.Object) timeSeriesDataItem67);
//        java.lang.Object obj70 = timeSeriesDataItem67.clone();
//        int int71 = day60.compareTo(obj70);
//        int int72 = day60.getMonth();
//        boolean boolean73 = timeSeriesDataItem39.equals((java.lang.Object) day60);
//        boolean boolean74 = fixedMillisecond0.equals((java.lang.Object) boolean73);
//        org.jfree.data.general.SeriesException seriesException76 = new org.jfree.data.general.SeriesException("Value");
//        java.lang.Throwable[] throwableArray77 = seriesException76.getSuppressed();
//        org.jfree.data.general.SeriesException seriesException79 = new org.jfree.data.general.SeriesException("Value");
//        seriesException76.addSuppressed((java.lang.Throwable) seriesException79);
//        java.lang.Throwable[] throwableArray81 = seriesException79.getSuppressed();
//        org.jfree.data.time.Year year82 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem84 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year82, (java.lang.Number) 0);
//        org.jfree.data.general.SeriesException seriesException86 = new org.jfree.data.general.SeriesException("Value");
//        java.lang.Throwable[] throwableArray87 = seriesException86.getSuppressed();
//        org.jfree.data.general.SeriesException seriesException89 = new org.jfree.data.general.SeriesException("Value");
//        seriesException86.addSuppressed((java.lang.Throwable) seriesException89);
//        boolean boolean91 = timeSeriesDataItem84.equals((java.lang.Object) seriesException86);
//        seriesException79.addSuppressed((java.lang.Throwable) seriesException86);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo93 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent94 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) seriesException79, seriesChangeInfo93);
//        java.lang.String str95 = seriesChangeEvent94.toString();
//        boolean boolean96 = fixedMillisecond0.equals((java.lang.Object) seriesChangeEvent94);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560184898883L + "'", long1 == 1560184898883L);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNull(class13);
//        org.junit.Assert.assertNotNull(list14);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertNull(class22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "2019" + "'", str27.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1559372400000L + "'", long31 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1559372400000L + "'", long32 == 1559372400000L);
//        org.junit.Assert.assertNotNull(timeSeries33);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1562097599999L + "'", long35 == 1562097599999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem37);
//        org.junit.Assert.assertNotNull(wildcardClass46);
//        org.junit.Assert.assertNotNull(class47);
//        org.junit.Assert.assertNull(regularTimePeriod50);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 6 + "'", int52 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod53);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1559372400000L + "'", long54 == 1559372400000L);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertNull(regularTimePeriod57);
//        org.junit.Assert.assertNull(regularTimePeriod59);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
//        org.junit.Assert.assertNotNull(obj70);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1 + "'", int71 == 1);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 6 + "'", int72 == 6);
//        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
//        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
//        org.junit.Assert.assertNotNull(throwableArray77);
//        org.junit.Assert.assertNotNull(throwableArray81);
//        org.junit.Assert.assertNotNull(throwableArray87);
//        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
//        org.junit.Assert.assertTrue("'" + str95 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=org.jfree.data.general.SeriesException: Value]" + "'", str95.equals("org.jfree.data.event.SeriesChangeEvent[source=org.jfree.data.general.SeriesException: Value]"));
//        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
//    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        long long3 = month0.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) 1.0f);
        java.lang.Number number6 = timeSeriesDataItem5.getValue();
        timeSeriesDataItem5.setSelected(false);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1559372400000L + "'", long3 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1.0d + "'", number6.equals(1.0d));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0);
        timeSeries1.add(timeSeriesDataItem7, true);
        boolean boolean10 = timeSeries1.getNotify();
        timeSeries1.fireSeriesChanged();
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int2 = timeSeries1.getMaximumItemCount();
        timeSeries1.setMaximumItemAge((long) 5);
        timeSeries1.fireSeriesChanged();
        java.lang.Object obj6 = timeSeries1.clone();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 8);
        long long9 = fixedMillisecond8.getSerialIndex();
        java.util.Date date10 = fixedMillisecond8.getTime();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year11, (double) 100, false);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries16.removeChangeListener(seriesChangeListener17);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries16.removeChangeListener(seriesChangeListener19);
        boolean boolean21 = timeSeries16.getNotify();
        java.lang.Class class22 = timeSeries16.getTimePeriodClass();
        java.lang.String str23 = timeSeries16.getDescription();
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
        int int25 = month24.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month24.next();
        long long27 = month24.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month24, (double) 1.0f);
        java.lang.Number number30 = timeSeriesDataItem29.getValue();
        timeSeries16.add(timeSeriesDataItem29, true);
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener35 = null;
        timeSeries34.removeChangeListener(seriesChangeListener35);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener37 = null;
        timeSeries34.removeChangeListener(seriesChangeListener37);
        boolean boolean39 = timeSeries34.getNotify();
        timeSeries34.setMaximumItemCount((int) '#');
        java.lang.Class class42 = timeSeries34.getTimePeriodClass();
        timeSeries34.setMaximumItemCount(2147483647);
        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries16.addAndOrUpdate(timeSeries34);
        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond((long) 8);
        long long48 = fixedMillisecond47.getSerialIndex();
        java.util.Date date49 = fixedMillisecond47.getTime();
        timeSeries34.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47, (java.lang.Number) (short) 1);
        int int52 = timeSeries34.getMaximumItemCount();
        try {
            org.jfree.data.time.TimeSeries timeSeries53 = timeSeries1.addAndOrUpdate(timeSeries34);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 8L + "'", long9 == 8L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(class22);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1559372400000L + "'", long27 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + number30 + "' != '" + 1.0d + "'", number30.equals(1.0d));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNull(class42);
        org.junit.Assert.assertNotNull(timeSeries45);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 8L + "'", long48 == 8L);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2147483647 + "'", int52 == 2147483647);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1.0f), seriesChangeInfo1);
        java.lang.Class<?> wildcardClass3 = seriesChangeEvent2.getClass();
        java.lang.String str4 = seriesChangeEvent2.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo5 = seriesChangeEvent2.getSummary();
        java.lang.String str6 = seriesChangeEvent2.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo7 = null;
        seriesChangeEvent2.setSummary(seriesChangeInfo7);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=-1.0]" + "'", str4.equals("org.jfree.data.event.SeriesChangeEvent[source=-1.0]"));
        org.junit.Assert.assertNull(seriesChangeInfo5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=-1.0]" + "'", str6.equals("org.jfree.data.event.SeriesChangeEvent[source=-1.0]"));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = month5.getMonth();
        timeSeries1.setKey((java.lang.Comparable) int6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        int int9 = year8.getYear();
        long long10 = year8.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year8.next();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) year8);
        try {
            timeSeries1.update((int) ' ', (java.lang.Number) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        timeSeries1.setMaximumItemAge((long) '#');
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        int int11 = year10.getYear();
        java.lang.String str12 = year10.toString();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        int int14 = month13.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month13.next();
        long long16 = month13.getFirstMillisecond();
        long long17 = month13.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year10, (org.jfree.data.time.RegularTimePeriod) month13);
        long long19 = month13.getSerialIndex();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int21 = year20.getYear();
        long long22 = year20.getSerialIndex();
        org.jfree.data.general.SeriesException seriesException24 = new org.jfree.data.general.SeriesException("Value");
        java.lang.Throwable[] throwableArray25 = seriesException24.getSuppressed();
        org.jfree.data.general.SeriesException seriesException27 = new org.jfree.data.general.SeriesException("Value");
        seriesException24.addSuppressed((java.lang.Throwable) seriesException27);
        boolean boolean29 = year20.equals((java.lang.Object) seriesException27);
        int int30 = month13.compareTo((java.lang.Object) boolean29);
        java.util.Calendar calendar31 = null;
        try {
            long long32 = month13.getLastMillisecond(calendar31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1559372400000L + "'", long16 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1559372400000L + "'", long17 == 1559372400000L);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 24234L + "'", long19 == 24234L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 2019L + "'", long22 == 2019L);
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        int int5 = month4.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.setKey((java.lang.Comparable) regularTimePeriod6);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries1.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries1.addOrUpdate(regularTimePeriod10, (java.lang.Number) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("10-June-2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        java.lang.Comparable comparable5 = timeSeries1.getKey();
        timeSeries1.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener8);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries11.removeChangeListener(seriesChangeListener12);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries11.removeChangeListener(seriesChangeListener14);
        java.lang.String str16 = timeSeries11.getRangeDescription();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries11.addChangeListener(seriesChangeListener17);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries11.removePropertyChangeListener(propertyChangeListener19);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener23 = null;
        timeSeries22.removeChangeListener(seriesChangeListener23);
        java.util.List list25 = timeSeries22.getItems();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        int int27 = month26.getMonth();
        timeSeries22.setKey((java.lang.Comparable) int27);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        int int30 = year29.getYear();
        long long31 = year29.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = year29.next();
        timeSeries22.delete((org.jfree.data.time.RegularTimePeriod) year29);
        int int34 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) year29);
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int37 = timeSeries36.getMaximumItemCount();
        timeSeries36.setMaximumItemAge((long) 5);
        timeSeries36.fireSeriesChanged();
        double double41 = timeSeries36.getMinY();
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener44 = null;
        timeSeries43.removeChangeListener(seriesChangeListener44);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener46 = null;
        timeSeries43.removeChangeListener(seriesChangeListener46);
        java.lang.String str48 = timeSeries43.getRangeDescription();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener49 = null;
        timeSeries43.addChangeListener(seriesChangeListener49);
        java.beans.PropertyChangeListener propertyChangeListener51 = null;
        timeSeries43.removePropertyChangeListener(propertyChangeListener51);
        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond((long) 8);
        long long55 = fixedMillisecond54.getSerialIndex();
        long long56 = fixedMillisecond54.getFirstMillisecond();
        timeSeries43.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond54, (java.lang.Number) 2147483647);
        org.jfree.data.time.Month month59 = new org.jfree.data.time.Month();
        int int60 = month59.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = month59.next();
        int int62 = fixedMillisecond54.compareTo((java.lang.Object) regularTimePeriod61);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem64 = timeSeries36.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond54, (double) (short) 100);
        org.jfree.data.time.TimeSeries timeSeries66 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener67 = null;
        timeSeries66.removeChangeListener(seriesChangeListener67);
        org.jfree.data.time.Month month69 = new org.jfree.data.time.Month();
        int int70 = month69.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = month69.next();
        timeSeries66.setKey((java.lang.Comparable) regularTimePeriod71);
        boolean boolean73 = timeSeries66.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond75 = new org.jfree.data.time.FixedMillisecond((long) 8);
        long long76 = fixedMillisecond75.getSerialIndex();
        java.util.Calendar calendar77 = null;
        long long78 = fixedMillisecond75.getMiddleMillisecond(calendar77);
        org.jfree.data.time.TimeSeries timeSeries80 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener81 = null;
        timeSeries80.removeChangeListener(seriesChangeListener81);
        java.util.List list83 = timeSeries80.getItems();
        java.lang.String str84 = timeSeries80.getDescription();
        int int85 = fixedMillisecond75.compareTo((java.lang.Object) str84);
        timeSeries66.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond75, (java.lang.Number) 0);
        org.jfree.data.time.TimeSeries timeSeries88 = timeSeries36.addAndOrUpdate(timeSeries66);
        timeSeries36.removeAgedItems(false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod91 = timeSeries36.getNextTimePeriod();
        boolean boolean92 = year29.equals((java.lang.Object) regularTimePeriod91);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year29, (java.lang.Number) 1577865599999L, true);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + 100L + "'", comparable5.equals(100L));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Value" + "'", str16.equals("Value"));
        org.junit.Assert.assertNotNull(list25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 2019L + "'", long31 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2147483647 + "'", int37 == 2147483647);
        org.junit.Assert.assertEquals((double) double41, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "Value" + "'", str48.equals("Value"));
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 8L + "'", long55 == 8L);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 8L + "'", long56 == 8L);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 6 + "'", int60 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertNull(timeSeriesDataItem64);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 6 + "'", int70 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod71);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 8L + "'", long76 == 8L);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 8L + "'", long78 == 8L);
        org.junit.Assert.assertNotNull(list83);
        org.junit.Assert.assertNull(str84);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 1 + "'", int85 == 1);
        org.junit.Assert.assertNotNull(timeSeries88);
        org.junit.Assert.assertNotNull(regularTimePeriod91);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        int int7 = month6.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month6.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month6, (double) 10.0f);
        java.util.Collection collection11 = timeSeries1.getTimePeriods();
        boolean boolean12 = timeSeries1.isEmpty();
        boolean boolean13 = timeSeries1.getNotify();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        int int8 = timeSeries1.getMaximumItemCount();
        timeSeries1.removeAgedItems(true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2147483647 + "'", int8 == 2147483647);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) '#', (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) 0);
        java.lang.String str3 = year0.toString();
        long long4 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.previous();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        java.lang.String str8 = timeSeries1.getDescription();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        long long12 = month9.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (double) 1.0f);
        java.lang.Number number15 = timeSeriesDataItem14.getValue();
        timeSeries1.add(timeSeriesDataItem14, true);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries19.removeChangeListener(seriesChangeListener20);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener22 = null;
        timeSeries19.removeChangeListener(seriesChangeListener22);
        boolean boolean24 = timeSeries19.getNotify();
        timeSeries19.setMaximumItemCount((int) '#');
        java.lang.Class class27 = timeSeries19.getTimePeriodClass();
        timeSeries19.setMaximumItemCount(2147483647);
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries1.addAndOrUpdate(timeSeries19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) 8);
        long long33 = fixedMillisecond32.getSerialIndex();
        java.util.Date date34 = fixedMillisecond32.getTime();
        timeSeries19.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (java.lang.Number) (short) 1);
        int int37 = timeSeries19.getMaximumItemCount();
        java.util.List list38 = timeSeries19.getItems();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1559372400000L + "'", long12 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 1.0d + "'", number15.equals(1.0d));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(class27);
        org.junit.Assert.assertNotNull(timeSeries30);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 8L + "'", long33 == 8L);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2147483647 + "'", int37 == 2147483647);
        org.junit.Assert.assertNotNull(list38);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int4 = timeSeries3.getMaximumItemCount();
        java.lang.Object obj5 = timeSeries3.clone();
        timeSeries3.setKey((java.lang.Comparable) 1);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        int int9 = month8.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month8.next();
        int int11 = month8.getMonth();
        int int12 = month8.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) month8);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.next();
        timeSeries3.add(regularTimePeriod15, (-1.0d), true);
        boolean boolean19 = year0.equals((java.lang.Object) timeSeries3);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener22 = null;
        timeSeries21.removeChangeListener(seriesChangeListener22);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener24 = null;
        timeSeries21.removeChangeListener(seriesChangeListener24);
        boolean boolean26 = timeSeries21.getNotify();
        java.lang.Class class27 = timeSeries21.getTimePeriodClass();
        timeSeries21.setMaximumItemAge((long) '#');
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        int int31 = year30.getYear();
        java.lang.String str32 = year30.toString();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        int int34 = month33.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month33.next();
        long long36 = month33.getFirstMillisecond();
        long long37 = month33.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries21.createCopy((org.jfree.data.time.RegularTimePeriod) year30, (org.jfree.data.time.RegularTimePeriod) month33);
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener41 = null;
        timeSeries40.removeChangeListener(seriesChangeListener41);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener43 = null;
        timeSeries40.removeChangeListener(seriesChangeListener43);
        boolean boolean45 = timeSeries40.getNotify();
        java.lang.Class class46 = timeSeries40.getTimePeriodClass();
        java.lang.String str47 = timeSeries40.getDescription();
        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month();
        int int49 = month48.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = month48.next();
        long long51 = month48.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month48, (double) 1.0f);
        java.lang.Number number54 = timeSeriesDataItem53.getValue();
        timeSeries40.add(timeSeriesDataItem53, true);
        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener59 = null;
        timeSeries58.removeChangeListener(seriesChangeListener59);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener61 = null;
        timeSeries58.removeChangeListener(seriesChangeListener61);
        boolean boolean63 = timeSeries58.getNotify();
        timeSeries58.setMaximumItemCount((int) '#');
        java.lang.Class class66 = timeSeries58.getTimePeriodClass();
        timeSeries58.setMaximumItemCount(2147483647);
        org.jfree.data.time.TimeSeries timeSeries69 = timeSeries40.addAndOrUpdate(timeSeries58);
        org.jfree.data.time.Year year70 = new org.jfree.data.time.Year();
        long long71 = year70.getMiddleMillisecond();
        timeSeries69.add((org.jfree.data.time.RegularTimePeriod) year70, (double) 6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem75 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year70, (double) 4);
        int int76 = year70.getYear();
        int int77 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) year70);
        org.jfree.data.time.Year year78 = new org.jfree.data.time.Year();
        long long79 = year78.getMiddleMillisecond();
        long long80 = year78.getFirstMillisecond();
        long long81 = year78.getSerialIndex();
        int int82 = year70.compareTo((java.lang.Object) year78);
        java.util.Calendar calendar83 = null;
        try {
            long long84 = year70.getMiddleMillisecond(calendar83);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNull(class27);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "2019" + "'", str32.equals("2019"));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1559372400000L + "'", long36 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1559372400000L + "'", long37 == 1559372400000L);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNull(class46);
        org.junit.Assert.assertNull(str47);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 6 + "'", int49 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1559372400000L + "'", long51 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + number54 + "' != '" + 1.0d + "'", number54.equals(1.0d));
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNull(class66);
        org.junit.Assert.assertNotNull(timeSeries69);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 1562097599999L + "'", long71 == 1562097599999L);
        org.junit.Assert.assertNull(timeSeriesDataItem75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 2019 + "'", int76 == 2019);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-1) + "'", int77 == (-1));
        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 1562097599999L + "'", long79 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 1546329600000L + "'", long80 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long81 + "' != '" + 2019L + "'", long81 == 2019L);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 0 + "'", int82 == 0);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        try {
            timeSeries1.delete(11, 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(class7);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        java.lang.String str6 = timeSeries1.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 8);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) (-1.0d));
        long long11 = fixedMillisecond8.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries13.removeChangeListener(seriesChangeListener14);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries13.removeChangeListener(seriesChangeListener16);
        boolean boolean18 = timeSeries13.getNotify();
        java.lang.Class class19 = timeSeries13.getTimePeriodClass();
        timeSeries13.setMaximumItemAge((long) '#');
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        int int23 = year22.getYear();
        java.lang.String str24 = year22.toString();
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        int int26 = month25.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = month25.next();
        long long28 = month25.getFirstMillisecond();
        long long29 = month25.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries13.createCopy((org.jfree.data.time.RegularTimePeriod) year22, (org.jfree.data.time.RegularTimePeriod) month25);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        long long32 = year31.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year31, (double) 100L);
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener37 = null;
        timeSeries36.removeChangeListener(seriesChangeListener37);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener39 = null;
        timeSeries36.removeChangeListener(seriesChangeListener39);
        boolean boolean41 = timeSeries36.getNotify();
        timeSeries36.setMaximumItemCount((int) '#');
        java.lang.Class class44 = timeSeries36.getTimePeriodClass();
        timeSeries36.setMaximumItemCount(2147483647);
        timeSeries36.setMaximumItemAge((long) 7);
        timeSeries36.setRangeDescription("");
        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries13.addAndOrUpdate(timeSeries36);
        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener54 = null;
        timeSeries53.removeChangeListener(seriesChangeListener54);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener56 = null;
        timeSeries53.removeChangeListener(seriesChangeListener56);
        boolean boolean58 = timeSeries53.getNotify();
        java.lang.Class class59 = timeSeries53.getTimePeriodClass();
        timeSeries53.setMaximumItemAge((long) '#');
        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year();
        int int63 = year62.getYear();
        java.lang.String str64 = year62.toString();
        org.jfree.data.time.Month month65 = new org.jfree.data.time.Month();
        int int66 = month65.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = month65.next();
        long long68 = month65.getFirstMillisecond();
        long long69 = month65.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries70 = timeSeries53.createCopy((org.jfree.data.time.RegularTimePeriod) year62, (org.jfree.data.time.RegularTimePeriod) month65);
        long long71 = month65.getLastMillisecond();
        int int72 = timeSeries36.getIndex((org.jfree.data.time.RegularTimePeriod) month65);
        boolean boolean73 = fixedMillisecond8.equals((java.lang.Object) timeSeries36);
        org.jfree.data.time.TimeSeries timeSeries75 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener76 = null;
        timeSeries75.removeChangeListener(seriesChangeListener76);
        java.util.List list78 = timeSeries75.getItems();
        org.jfree.data.time.Year year79 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem81 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year79, (java.lang.Number) 0);
        timeSeries75.add(timeSeriesDataItem81, true);
        boolean boolean84 = timeSeriesDataItem81.isSelected();
        java.lang.Number number85 = timeSeriesDataItem81.getValue();
        timeSeries36.add(timeSeriesDataItem81);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 8L + "'", long11 == 8L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(class19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "2019" + "'", str24.equals("2019"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 6 + "'", int26 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1559372400000L + "'", long28 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1559372400000L + "'", long29 == 1559372400000L);
        org.junit.Assert.assertNotNull(timeSeries30);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1562097599999L + "'", long32 == 1562097599999L);
        org.junit.Assert.assertNull(timeSeriesDataItem34);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNull(class44);
        org.junit.Assert.assertNotNull(timeSeries51);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertNull(class59);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 2019 + "'", int63 == 2019);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "2019" + "'", str64.equals("2019"));
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 6 + "'", int66 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod67);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 1559372400000L + "'", long68 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 1559372400000L + "'", long69 == 1559372400000L);
        org.junit.Assert.assertNotNull(timeSeries70);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 1561964399999L + "'", long71 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-1) + "'", int72 == (-1));
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(list78);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertTrue("'" + number85 + "' != '" + 0 + "'", number85.equals(0));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = null;
        try {
            timeSeries1.add(timeSeriesDataItem4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        java.lang.Class class0 = null;
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo2 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1.0f), seriesChangeInfo2);
        java.lang.Class<?> wildcardClass4 = seriesChangeEvent3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date6, timeZone7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        long long12 = month9.getFirstMillisecond();
        java.util.Date date13 = month9.getEnd();
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date13, timeZone14);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date13, timeZone16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.next();
        long long20 = day18.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate21 = day18.getSerialDate();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1559372400000L + "'", long12 == 1559372400000L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1561964399999L + "'", long20 == 1561964399999L);
        org.junit.Assert.assertNotNull(serialDate21);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        int int7 = month6.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month6.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month6, (double) 10.0f);
        double double11 = timeSeries1.getMaxY();
        boolean boolean12 = timeSeries1.getNotify();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries14.removeChangeListener(seriesChangeListener15);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries14.removeChangeListener(seriesChangeListener17);
        boolean boolean19 = timeSeries14.getNotify();
        java.lang.Class class20 = timeSeries14.getTimePeriodClass();
        java.lang.String str21 = timeSeries14.getDescription();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        int int23 = month22.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month22.next();
        long long25 = month22.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month22, (double) 1.0f);
        java.lang.Number number28 = timeSeriesDataItem27.getValue();
        timeSeries14.add(timeSeriesDataItem27, true);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener33 = null;
        timeSeries32.removeChangeListener(seriesChangeListener33);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener35 = null;
        timeSeries32.removeChangeListener(seriesChangeListener35);
        boolean boolean37 = timeSeries32.getNotify();
        timeSeries32.setMaximumItemCount((int) '#');
        java.lang.Class class40 = timeSeries32.getTimePeriodClass();
        timeSeries32.setMaximumItemCount(2147483647);
        org.jfree.data.time.TimeSeries timeSeries43 = timeSeries14.addAndOrUpdate(timeSeries32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = timeSeries14.getNextTimePeriod();
        java.util.Collection collection45 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        boolean boolean46 = timeSeries14.getNotify();
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
        int int48 = month47.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = month47.next();
        long long50 = month47.getFirstMillisecond();
        long long51 = month47.getFirstMillisecond();
        int int52 = month47.getMonth();
        try {
            timeSeries14.add((org.jfree.data.time.RegularTimePeriod) month47, (java.lang.Number) 100L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period June 2019 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 10.0d + "'", double11 == 10.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNull(class20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1559372400000L + "'", long25 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + 1.0d + "'", number28.equals(1.0d));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNull(class40);
        org.junit.Assert.assertNotNull(timeSeries43);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(collection45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 6 + "'", int48 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1559372400000L + "'", long50 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1559372400000L + "'", long51 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 6 + "'", int52 == 6);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        java.lang.String str8 = timeSeries1.getDescription();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        long long12 = month9.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (double) 1.0f);
        java.lang.Number number15 = timeSeriesDataItem14.getValue();
        timeSeries1.add(timeSeriesDataItem14, true);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries19.removeChangeListener(seriesChangeListener20);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener22 = null;
        timeSeries19.removeChangeListener(seriesChangeListener22);
        boolean boolean24 = timeSeries19.getNotify();
        timeSeries19.setMaximumItemCount((int) '#');
        java.lang.Class class27 = timeSeries19.getTimePeriodClass();
        timeSeries19.setMaximumItemCount(2147483647);
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries1.addAndOrUpdate(timeSeries19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = timeSeries1.getNextTimePeriod();
        java.lang.String str32 = timeSeries1.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener35 = null;
        timeSeries34.removeChangeListener(seriesChangeListener35);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener37 = null;
        timeSeries34.removeChangeListener(seriesChangeListener37);
        boolean boolean39 = timeSeries34.getNotify();
        java.lang.Class class40 = timeSeries34.getTimePeriodClass();
        java.lang.String str41 = timeSeries34.getDescription();
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month();
        int int43 = month42.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = month42.next();
        long long45 = month42.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month42, (double) 1.0f);
        java.lang.Number number48 = timeSeriesDataItem47.getValue();
        timeSeries34.add(timeSeriesDataItem47, true);
        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener53 = null;
        timeSeries52.removeChangeListener(seriesChangeListener53);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener55 = null;
        timeSeries52.removeChangeListener(seriesChangeListener55);
        boolean boolean57 = timeSeries52.getNotify();
        timeSeries52.setMaximumItemCount((int) '#');
        java.lang.Class class60 = timeSeries52.getTimePeriodClass();
        timeSeries52.setMaximumItemCount(2147483647);
        org.jfree.data.time.TimeSeries timeSeries63 = timeSeries34.addAndOrUpdate(timeSeries52);
        org.jfree.data.time.FixedMillisecond fixedMillisecond65 = new org.jfree.data.time.FixedMillisecond((long) 8);
        long long66 = fixedMillisecond65.getSerialIndex();
        java.util.Date date67 = fixedMillisecond65.getTime();
        timeSeries52.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond65, (java.lang.Number) (short) 1);
        int int70 = timeSeries52.getMaximumItemCount();
        try {
            org.jfree.data.time.TimeSeries timeSeries71 = timeSeries1.addAndOrUpdate(timeSeries52);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1559372400000L + "'", long12 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 1.0d + "'", number15.equals(1.0d));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(class27);
        org.junit.Assert.assertNotNull(timeSeries30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Time" + "'", str32.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNull(class40);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 6 + "'", int43 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1559372400000L + "'", long45 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + number48 + "' != '" + 1.0d + "'", number48.equals(1.0d));
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNull(class60);
        org.junit.Assert.assertNotNull(timeSeries63);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 8L + "'", long66 == 8L);
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 2147483647 + "'", int70 == 2147483647);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        java.lang.String str8 = timeSeries1.getDescription();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        long long12 = month9.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (double) 1.0f);
        java.lang.Number number15 = timeSeriesDataItem14.getValue();
        timeSeries1.add(timeSeriesDataItem14, true);
        java.lang.Object obj18 = null;
        boolean boolean19 = timeSeries1.equals(obj18);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries1.addChangeListener(seriesChangeListener20);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1559372400000L + "'", long12 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 1.0d + "'", number15.equals(1.0d));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        long long3 = month0.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries5.removeChangeListener(seriesChangeListener6);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries5.removeChangeListener(seriesChangeListener8);
        java.lang.String str10 = timeSeries5.getRangeDescription();
        int int11 = month0.compareTo((java.lang.Object) timeSeries5);
        double double12 = timeSeries5.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int15 = timeSeries14.getMaximumItemCount();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        int int17 = month16.getMonth();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month18.previous();
        boolean boolean20 = month16.equals((java.lang.Object) month18);
        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) month16, (java.lang.Number) 2147483647, false);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener26 = null;
        timeSeries25.removeChangeListener(seriesChangeListener26);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener28 = null;
        timeSeries25.removeChangeListener(seriesChangeListener28);
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
        int int31 = month30.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = month30.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries25.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month30, (double) 10.0f);
        int int35 = month16.compareTo((java.lang.Object) 10.0f);
        java.lang.String str36 = month16.toString();
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int39 = timeSeries38.getMaximumItemCount();
        boolean boolean40 = month16.equals((java.lang.Object) int39);
        org.jfree.data.time.Year year41 = month16.getYear();
        int int42 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) year41);
        try {
            timeSeries5.delete(11, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1559372400000L + "'", long3 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Value" + "'", str10.equals("Value"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2147483647 + "'", int15 == 2147483647);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 6 + "'", int31 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNull(timeSeriesDataItem34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "June 2019" + "'", str36.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2147483647 + "'", int39 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(year41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        java.lang.Class class0 = null;
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo2 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1.0f), seriesChangeInfo2);
        java.lang.Class<?> wildcardClass4 = seriesChangeEvent3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date6, timeZone7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        long long12 = month9.getFirstMillisecond();
        java.util.Date date13 = month9.getEnd();
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date13, timeZone14);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date13, timeZone16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.next();
        int int20 = day18.getDayOfMonth();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1559372400000L + "'", long12 == 1559372400000L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 30 + "'", int20 == 30);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = month5.getMonth();
        timeSeries1.setKey((java.lang.Comparable) int6);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        int int9 = month8.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month8.next();
        long long11 = month8.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month8, (double) 1.0f);
        java.lang.Number number14 = timeSeriesDataItem13.getValue();
        timeSeriesDataItem13.setValue((java.lang.Number) 1559372400000L);
        java.lang.Object obj17 = null;
        boolean boolean18 = timeSeriesDataItem13.equals(obj17);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries1.addOrUpdate(timeSeriesDataItem13);
        java.lang.String str20 = timeSeries1.getDescription();
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener21);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1559372400000L + "'", long11 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 1.0d + "'", number14.equals(1.0d));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertNull(str20);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond((long) 8);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (java.lang.Number) 0);
        boolean boolean7 = timeSeriesDataItem6.isSelected();
        boolean boolean8 = fixedMillisecond3.equals((java.lang.Object) timeSeriesDataItem6);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (java.lang.Number) 2147483647, false);
        java.util.Date date12 = fixedMillisecond3.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond3.previous();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int4 = timeSeries3.getMaximumItemCount();
        java.lang.Object obj5 = timeSeries3.clone();
        timeSeries3.setKey((java.lang.Comparable) 1);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        int int9 = month8.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month8.next();
        int int11 = month8.getMonth();
        int int12 = month8.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) month8);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.next();
        timeSeries3.add(regularTimePeriod15, (-1.0d), true);
        boolean boolean19 = year0.equals((java.lang.Object) timeSeries3);
        java.util.Calendar calendar20 = null;
        try {
            long long21 = year0.getFirstMillisecond(calendar20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("June 2019");
        org.junit.Assert.assertNotNull(month1);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        timeSeries1.setMaximumItemCount((int) '#');
        java.lang.Class class9 = timeSeries1.getTimePeriodClass();
        timeSeries1.setMaximumItemCount(2147483647);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries13.removeChangeListener(seriesChangeListener14);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries13.removeChangeListener(seriesChangeListener16);
        java.lang.String str18 = timeSeries13.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) 8);
        timeSeries13.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (java.lang.Number) (-1.0d));
        long long23 = fixedMillisecond20.getSerialIndex();
        java.lang.Number number24 = null;
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, number24, false);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year27, (java.lang.Number) 0);
        java.lang.Number number30 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) year27);
        java.lang.Class<?> wildcardClass31 = timeSeries1.getClass();
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month();
        int int33 = month32.getMonth();
        org.jfree.data.time.Year year34 = month32.getYear();
        long long35 = month32.getSerialIndex();
        java.util.Date date36 = month32.getStart();
        java.util.TimeZone timeZone37 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass31, date36, timeZone37);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(class9);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Value" + "'", str18.equals("Value"));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 8L + "'", long23 == 8L);
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 6 + "'", int33 == 6);
        org.junit.Assert.assertNotNull(year34);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 24234L + "'", long35 == 24234L);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNull(regularTimePeriod38);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        long long3 = month0.getFirstMillisecond();
        java.util.Date date4 = month0.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        int int9 = month8.getMonth();
        int int10 = month8.getYearValue();
        long long11 = month8.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month8, (java.lang.Number) 1562097599999L);
        timeSeries7.add(timeSeriesDataItem13, true);
        java.util.List list16 = timeSeries7.getItems();
        int int17 = year5.compareTo((java.lang.Object) timeSeries7);
        timeSeries7.removeAgedItems((long) (short) 1, false);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1559372400000L + "'", long3 == 1559372400000L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 24234L + "'", long11 == 24234L);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        java.util.List list6 = timeSeries3.getItems();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        int int8 = month7.getMonth();
        timeSeries3.setKey((java.lang.Comparable) int8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        int int11 = year10.getYear();
        long long12 = year10.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year10.next();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) year10);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        long long16 = year15.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) year15);
        java.lang.Class class18 = null;
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo20 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent21 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1.0f), seriesChangeInfo20);
        java.lang.Class<?> wildcardClass22 = seriesChangeEvent21.getClass();
        java.lang.Class class23 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass22);
        java.util.Date date24 = null;
        java.util.TimeZone timeZone25 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date24, timeZone25);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        int int28 = month27.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month27.next();
        long long30 = month27.getFirstMillisecond();
        java.util.Date date31 = month27.getEnd();
        java.util.TimeZone timeZone32 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date31, timeZone32);
        java.util.TimeZone timeZone34 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date31, timeZone34);
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date31);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = day36.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries3.addOrUpdate(regularTimePeriod37, (java.lang.Number) (short) 0);
        int int40 = fixedMillisecond1.compareTo((java.lang.Object) (short) 0);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1562097599999L + "'", long16 == 1562097599999L);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(class23);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1559372400000L + "'", long30 == 1559372400000L);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNull(timeSeriesDataItem39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int4 = timeSeries3.getMaximumItemCount();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = month5.getMonth();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month7.previous();
        boolean boolean9 = month5.equals((java.lang.Object) month7);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month5, (java.lang.Number) 2147483647, false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month5.previous();
        int int14 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month5);
        timeSeries1.setDomainDescription("");
        java.lang.String str17 = timeSeries1.getDomainDescription();
        timeSeries1.removeAgedItems((long) (-1), false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        java.lang.Class class0 = null;
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo2 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1.0f), seriesChangeInfo2);
        java.lang.Class<?> wildcardClass4 = seriesChangeEvent3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date6, timeZone7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        long long12 = month9.getFirstMillisecond();
        java.util.Date date13 = month9.getEnd();
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date13, timeZone14);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date13, timeZone16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date13);
        java.util.TimeZone timeZone21 = null;
        try {
            org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date13, timeZone21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1559372400000L + "'", long12 == 1559372400000L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNull(regularTimePeriod17);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        java.lang.Class class0 = null;
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo2 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1.0f), seriesChangeInfo2);
        java.lang.Class<?> wildcardClass4 = seriesChangeEvent3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date6, timeZone7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        long long12 = month9.getFirstMillisecond();
        java.util.Date date13 = month9.getEnd();
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date13, timeZone14);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date13, timeZone16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date13);
        java.lang.Object obj19 = null;
        boolean boolean20 = day18.equals(obj19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day18.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day18.next();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        int int24 = year23.getYear();
        java.lang.String str25 = year23.toString();
        long long26 = year23.getSerialIndex();
        long long27 = year23.getLastMillisecond();
        int int28 = day18.compareTo((java.lang.Object) year23);
        java.util.Calendar calendar29 = null;
        try {
            day18.peg(calendar29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1559372400000L + "'", long12 == 1559372400000L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "2019" + "'", str25.equals("2019"));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 2019L + "'", long26 == 2019L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1577865599999L + "'", long27 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1.0f), seriesChangeInfo1);
        java.lang.Class<?> wildcardClass3 = seriesChangeEvent2.getClass();
        java.lang.String str4 = seriesChangeEvent2.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo5 = seriesChangeEvent2.getSummary();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo6 = null;
        seriesChangeEvent2.setSummary(seriesChangeInfo6);
        java.lang.Object obj8 = seriesChangeEvent2.getSource();
        java.lang.Object obj9 = seriesChangeEvent2.getSource();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=-1.0]" + "'", str4.equals("org.jfree.data.event.SeriesChangeEvent[source=-1.0]"));
        org.junit.Assert.assertNull(seriesChangeInfo5);
        org.junit.Assert.assertTrue("'" + obj8 + "' != '" + (-1.0f) + "'", obj8.equals((-1.0f)));
        org.junit.Assert.assertTrue("'" + obj9 + "' != '" + (-1.0f) + "'", obj9.equals((-1.0f)));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "Time", "hi!");
        timeSeries3.removeAgedItems(true);
        int int6 = timeSeries3.getMaximumItemCount();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries3.getDataItem(5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2147483647 + "'", int6 == 2147483647);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        long long3 = month0.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries5.removeChangeListener(seriesChangeListener6);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries5.removeChangeListener(seriesChangeListener8);
        java.lang.String str10 = timeSeries5.getRangeDescription();
        int int11 = month0.compareTo((java.lang.Object) timeSeries5);
        double double12 = timeSeries5.getMaxY();
        boolean boolean13 = timeSeries5.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int16 = timeSeries15.getMaximumItemCount();
        java.lang.Object obj17 = timeSeries15.clone();
        timeSeries15.setKey((java.lang.Comparable) 1);
        java.util.Collection collection20 = timeSeries15.getTimePeriods();
        int int21 = timeSeries15.getMaximumItemCount();
        long long22 = timeSeries15.getMaximumItemAge();
        timeSeries15.fireSeriesChanged();
        java.lang.Object obj24 = timeSeries15.clone();
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries5.addAndOrUpdate(timeSeries15);
        timeSeries5.setNotify(false);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1559372400000L + "'", long3 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Value" + "'", str10.equals("Value"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2147483647 + "'", int16 == 2147483647);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2147483647 + "'", int21 == 2147483647);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 9223372036854775807L + "'", long22 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNotNull(timeSeries25);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        timeSeries1.setMaximumItemCount((int) '#');
        java.lang.Class class9 = timeSeries1.getTimePeriodClass();
        timeSeries1.setMaximumItemCount(2147483647);
        timeSeries1.setMaximumItemAge((long) 7);
        timeSeries1.setRangeDescription("");
        timeSeries1.removeAgedItems((long) 7, false);
        java.lang.String str19 = timeSeries1.getRangeDescription();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent20 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) str19);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(class9);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        java.lang.String str8 = timeSeries1.getDescription();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        long long12 = month9.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (double) 1.0f);
        java.lang.Number number15 = timeSeriesDataItem14.getValue();
        timeSeries1.add(timeSeriesDataItem14, true);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries19.removeChangeListener(seriesChangeListener20);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener22 = null;
        timeSeries19.removeChangeListener(seriesChangeListener22);
        boolean boolean24 = timeSeries19.getNotify();
        timeSeries19.setMaximumItemCount((int) '#');
        java.lang.Class class27 = timeSeries19.getTimePeriodClass();
        timeSeries19.setMaximumItemCount(2147483647);
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries1.addAndOrUpdate(timeSeries19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = timeSeries1.getNextTimePeriod();
        java.lang.String str32 = timeSeries1.getDomainDescription();
        timeSeries1.fireSeriesChanged();
        try {
            timeSeries1.delete(0, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1559372400000L + "'", long12 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 1.0d + "'", number15.equals(1.0d));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(class27);
        org.junit.Assert.assertNotNull(timeSeries30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Time" + "'", str32.equals("Time"));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        java.lang.Class class0 = null;
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo2 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1.0f), seriesChangeInfo2);
        java.lang.Class<?> wildcardClass4 = seriesChangeEvent3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date6, timeZone7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        long long12 = month9.getFirstMillisecond();
        java.util.Date date13 = month9.getEnd();
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date13, timeZone14);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date13, timeZone16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.next();
        org.jfree.data.time.SerialDate serialDate20 = day18.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day18.previous();
        int int22 = day18.getMonth();
        int int23 = day18.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate24 = day18.getSerialDate();
        long long25 = day18.getFirstMillisecond();
        long long26 = day18.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day18, (double) 1560668399999L);
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener31 = null;
        timeSeries30.removeChangeListener(seriesChangeListener31);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        int int34 = month33.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month33.next();
        timeSeries30.setKey((java.lang.Comparable) regularTimePeriod35);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener37 = null;
        timeSeries30.addChangeListener(seriesChangeListener37);
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int41 = timeSeries40.getMaximumItemCount();
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month();
        int int43 = month42.getMonth();
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = month44.previous();
        boolean boolean46 = month42.equals((java.lang.Object) month44);
        timeSeries40.add((org.jfree.data.time.RegularTimePeriod) month42, (java.lang.Number) 2147483647, false);
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener52 = null;
        timeSeries51.removeChangeListener(seriesChangeListener52);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener54 = null;
        timeSeries51.removeChangeListener(seriesChangeListener54);
        org.jfree.data.time.Month month56 = new org.jfree.data.time.Month();
        int int57 = month56.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = month56.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem60 = timeSeries51.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month56, (double) 10.0f);
        int int61 = month42.compareTo((java.lang.Object) 10.0f);
        java.lang.String str62 = month42.toString();
        org.jfree.data.time.TimeSeries timeSeries64 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int65 = timeSeries64.getMaximumItemCount();
        boolean boolean66 = month42.equals((java.lang.Object) int65);
        org.jfree.data.time.Year year67 = month42.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem69 = timeSeries30.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year67, (java.lang.Number) 12);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo70 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent71 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries30, seriesChangeInfo70);
        int int72 = timeSeriesDataItem28.compareTo((java.lang.Object) seriesChangeInfo70);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1559372400000L + "'", long12 == 1559372400000L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 30 + "'", int23 == 30);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1561878000000L + "'", long25 == 1561878000000L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 43646L + "'", long26 == 43646L);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 2147483647 + "'", int41 == 2147483647);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 6 + "'", int43 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 6 + "'", int57 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertNull(timeSeriesDataItem60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "June 2019" + "'", str62.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 2147483647 + "'", int65 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(year67);
        org.junit.Assert.assertNull(timeSeriesDataItem69);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1 + "'", int72 == 1);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        java.lang.String str6 = timeSeries1.getRangeDescription();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries1.addChangeListener(seriesChangeListener7);
        try {
            java.lang.Number number10 = timeSeries1.getValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 8);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 8L + "'", long3 == 8L);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getMiddleMillisecond();
        long long2 = year0.getFirstMillisecond();
        long long3 = year0.getSerialIndex();
        java.lang.String str4 = year0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.previous();
        java.lang.String str6 = year0.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1562097599999L + "'", long1 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year7.next();
        int int10 = timeSeries1.getIndex(regularTimePeriod9);
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries14.removeChangeListener(seriesChangeListener15);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries14.removeChangeListener(seriesChangeListener17);
        boolean boolean19 = timeSeries14.getNotify();
        java.lang.Class class20 = timeSeries14.getTimePeriodClass();
        timeSeries14.setMaximumItemAge((long) '#');
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        int int24 = year23.getYear();
        java.lang.String str25 = year23.toString();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        int int27 = month26.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = month26.next();
        long long29 = month26.getFirstMillisecond();
        long long30 = month26.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries14.createCopy((org.jfree.data.time.RegularTimePeriod) year23, (org.jfree.data.time.RegularTimePeriod) month26);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        long long33 = year32.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year32, (double) 100L);
        long long36 = year32.getSerialIndex();
        try {
            timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year32, (java.lang.Number) (-1));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNull(class20);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "2019" + "'", str25.equals("2019"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1559372400000L + "'", long29 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1559372400000L + "'", long30 == 1559372400000L);
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1562097599999L + "'", long33 == 1562097599999L);
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 2019L + "'", long36 == 2019L);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        long long3 = month0.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) 1.0f);
        java.lang.Number number6 = timeSeriesDataItem5.getValue();
        timeSeriesDataItem5.setValue((java.lang.Number) 1559372400000L);
        java.lang.Object obj9 = null;
        boolean boolean10 = timeSeriesDataItem5.equals(obj9);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries12.removeChangeListener(seriesChangeListener13);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries12.removeChangeListener(seriesChangeListener15);
        boolean boolean17 = timeSeries12.getNotify();
        java.lang.Class class18 = timeSeries12.getTimePeriodClass();
        int int19 = timeSeriesDataItem5.compareTo((java.lang.Object) timeSeries12);
        java.lang.Object obj20 = timeSeriesDataItem5.clone();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1559372400000L + "'", long3 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1.0d + "'", number6.equals(1.0d));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(class18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(obj20);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) 10, (int) '#', 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Value");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("Value");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.Throwable[] throwableArray6 = seriesException1.getSuppressed();
        java.lang.String str7 = seriesException1.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.general.SeriesException: Value" + "'", str7.equals("org.jfree.data.general.SeriesException: Value"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        timeSeries1.setMaximumItemAge((long) '#');
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        int int11 = year10.getYear();
        java.lang.String str12 = year10.toString();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        int int14 = month13.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month13.next();
        long long16 = month13.getFirstMillisecond();
        long long17 = month13.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year10, (org.jfree.data.time.RegularTimePeriod) month13);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener21 = null;
        timeSeries20.removeChangeListener(seriesChangeListener21);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener23 = null;
        timeSeries20.removeChangeListener(seriesChangeListener23);
        boolean boolean25 = timeSeries20.getNotify();
        java.lang.Class class26 = timeSeries20.getTimePeriodClass();
        java.lang.String str27 = timeSeries20.getDescription();
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
        int int29 = month28.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month28.next();
        long long31 = month28.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month28, (double) 1.0f);
        java.lang.Number number34 = timeSeriesDataItem33.getValue();
        timeSeries20.add(timeSeriesDataItem33, true);
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener39 = null;
        timeSeries38.removeChangeListener(seriesChangeListener39);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener41 = null;
        timeSeries38.removeChangeListener(seriesChangeListener41);
        boolean boolean43 = timeSeries38.getNotify();
        timeSeries38.setMaximumItemCount((int) '#');
        java.lang.Class class46 = timeSeries38.getTimePeriodClass();
        timeSeries38.setMaximumItemCount(2147483647);
        org.jfree.data.time.TimeSeries timeSeries49 = timeSeries20.addAndOrUpdate(timeSeries38);
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        long long51 = year50.getMiddleMillisecond();
        timeSeries49.add((org.jfree.data.time.RegularTimePeriod) year50, (double) 6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem55 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year50, (double) 4);
        java.util.Collection collection56 = timeSeries1.getTimePeriods();
        timeSeries1.setMaximumItemAge((long) 8);
        timeSeries1.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1559372400000L + "'", long16 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1559372400000L + "'", long17 == 1559372400000L);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNull(class26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1559372400000L + "'", long31 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + number34 + "' != '" + 1.0d + "'", number34.equals(1.0d));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNull(class46);
        org.junit.Assert.assertNotNull(timeSeries49);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1562097599999L + "'", long51 == 1562097599999L);
        org.junit.Assert.assertNull(timeSeriesDataItem55);
        org.junit.Assert.assertNotNull(collection56);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        java.lang.Class class0 = null;
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo2 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1.0f), seriesChangeInfo2);
        java.lang.Class<?> wildcardClass4 = seriesChangeEvent3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date6, timeZone7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        long long12 = month9.getFirstMillisecond();
        java.util.Date date13 = month9.getEnd();
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date13, timeZone14);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date13, timeZone16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.next();
        org.jfree.data.time.SerialDate serialDate20 = day18.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day18.previous();
        int int22 = day18.getMonth();
        int int23 = day18.getDayOfMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day18.next();
        int int25 = day18.getMonth();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1559372400000L + "'", long12 == 1559372400000L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 30 + "'", int23 == 30);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int2 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getMiddleMillisecond();
        long long5 = year3.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year3, (java.lang.Number) 2147483647);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) 0);
        boolean boolean13 = timeSeriesDataItem12.isSelected();
        boolean boolean14 = fixedMillisecond9.equals((java.lang.Object) timeSeriesDataItem12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond9.previous();
        try {
            timeSeries1.add(regularTimePeriod15, (java.lang.Number) 1561921199999L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1562097599999L + "'", long4 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Value");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("Value");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.Throwable[] throwableArray6 = seriesException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException8 = new org.jfree.data.general.SeriesException("Value");
        java.lang.Throwable[] throwableArray9 = seriesException8.getSuppressed();
        org.jfree.data.general.SeriesException seriesException11 = new org.jfree.data.general.SeriesException("Value");
        seriesException8.addSuppressed((java.lang.Throwable) seriesException11);
        java.lang.Throwable[] throwableArray13 = seriesException11.getSuppressed();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year14, (java.lang.Number) 0);
        org.jfree.data.general.SeriesException seriesException18 = new org.jfree.data.general.SeriesException("Value");
        java.lang.Throwable[] throwableArray19 = seriesException18.getSuppressed();
        org.jfree.data.general.SeriesException seriesException21 = new org.jfree.data.general.SeriesException("Value");
        seriesException18.addSuppressed((java.lang.Throwable) seriesException21);
        boolean boolean23 = timeSeriesDataItem16.equals((java.lang.Object) seriesException18);
        seriesException11.addSuppressed((java.lang.Throwable) seriesException18);
        org.jfree.data.general.SeriesException seriesException26 = new org.jfree.data.general.SeriesException("Value");
        java.lang.Throwable[] throwableArray27 = seriesException26.getSuppressed();
        org.jfree.data.general.SeriesException seriesException29 = new org.jfree.data.general.SeriesException("Value");
        seriesException26.addSuppressed((java.lang.Throwable) seriesException29);
        java.lang.Throwable[] throwableArray31 = seriesException29.getSuppressed();
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year32, (java.lang.Number) 0);
        org.jfree.data.general.SeriesException seriesException36 = new org.jfree.data.general.SeriesException("Value");
        java.lang.Throwable[] throwableArray37 = seriesException36.getSuppressed();
        org.jfree.data.general.SeriesException seriesException39 = new org.jfree.data.general.SeriesException("Value");
        seriesException36.addSuppressed((java.lang.Throwable) seriesException39);
        boolean boolean41 = timeSeriesDataItem34.equals((java.lang.Object) seriesException36);
        seriesException29.addSuppressed((java.lang.Throwable) seriesException36);
        seriesException18.addSuppressed((java.lang.Throwable) seriesException29);
        seriesException1.addSuppressed((java.lang.Throwable) seriesException29);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(throwableArray27);
        org.junit.Assert.assertNotNull(throwableArray31);
        org.junit.Assert.assertNotNull(throwableArray37);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        long long3 = month0.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries5.removeChangeListener(seriesChangeListener6);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries5.removeChangeListener(seriesChangeListener8);
        java.lang.String str10 = timeSeries5.getRangeDescription();
        int int11 = month0.compareTo((java.lang.Object) timeSeries5);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries5.addChangeListener(seriesChangeListener12);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1559372400000L + "'", long3 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Value" + "'", str10.equals("Value"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int2 = timeSeries1.getMaximumItemCount();
        java.lang.Object obj3 = timeSeries1.clone();
        timeSeries1.setKey((java.lang.Comparable) 1);
        java.util.Collection collection6 = timeSeries1.getTimePeriods();
        int int7 = timeSeries1.getMaximumItemCount();
        long long8 = timeSeries1.getMaximumItemAge();
        java.lang.Object obj9 = timeSeries1.clone();
        timeSeries1.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries1.removeChangeListener(seriesChangeListener12);
        java.lang.Object obj14 = timeSeries1.clone();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9223372036854775807L + "'", long8 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        java.lang.Class class0 = null;
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        long long2 = year1.getMiddleMillisecond();
        java.util.Date date3 = year1.getEnd();
        java.util.Date date4 = year1.getEnd();
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date4, timeZone5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date4);
        java.util.TimeZone timeZone8 = null;
        try {
            org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date4, timeZone8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(regularTimePeriod6);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        long long2 = year0.getSerialIndex();
        int int3 = year0.getYear();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int2 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        int int4 = month3.getMonth();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.previous();
        boolean boolean7 = month3.equals((java.lang.Object) month5);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month3, (java.lang.Number) 2147483647, false);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries12.removeChangeListener(seriesChangeListener13);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries12.removeChangeListener(seriesChangeListener15);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        int int18 = month17.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month17.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month17, (double) 10.0f);
        int int22 = month3.compareTo((java.lang.Object) 10.0f);
        java.lang.String str23 = month3.toString();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int26 = timeSeries25.getMaximumItemCount();
        boolean boolean27 = month3.equals((java.lang.Object) int26);
        org.jfree.data.time.Year year28 = month3.getYear();
        java.lang.String str29 = month3.toString();
        long long30 = month3.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "June 2019" + "'", str23.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2147483647 + "'", int26 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(year28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "June 2019" + "'", str29.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1561964399999L + "'", long30 == 1561964399999L);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        java.lang.String str8 = timeSeries1.getDescription();
        java.lang.String str9 = timeSeries1.getDomainDescription();
        timeSeries1.setNotify(true);
        java.lang.String str12 = timeSeries1.getDomainDescription();
        timeSeries1.clear();
        java.lang.String str14 = timeSeries1.getDescription();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
        org.junit.Assert.assertNull(str14);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        int int7 = month6.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month6.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month6, (double) 10.0f);
        boolean boolean11 = timeSeries1.getNotify();
        try {
            timeSeries1.delete((int) '4', (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        timeSeries1.setMaximumItemCount((int) '#');
        java.lang.Class class9 = timeSeries1.getTimePeriodClass();
        timeSeries1.setMaximumItemCount(2147483647);
        timeSeries1.setMaximumItemAge((long) 7);
        timeSeries1.setRangeDescription("");
        double double16 = timeSeries1.getMinY();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(class9);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        timeSeries1.setMaximumItemCount((int) '#');
        java.lang.Class class9 = timeSeries1.getTimePeriodClass();
        timeSeries1.setMaximumItemCount(2147483647);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries13.removeChangeListener(seriesChangeListener14);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries13.removeChangeListener(seriesChangeListener16);
        java.lang.String str18 = timeSeries13.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) 8);
        timeSeries13.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (java.lang.Number) (-1.0d));
        long long23 = fixedMillisecond20.getSerialIndex();
        java.lang.Number number24 = null;
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, number24, false);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year27, (java.lang.Number) 0);
        java.lang.Number number30 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) year27);
        java.util.Calendar calendar31 = null;
        try {
            long long32 = year27.getFirstMillisecond(calendar31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(class9);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Value" + "'", str18.equals("Value"));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 8L + "'", long23 == 8L);
        org.junit.Assert.assertNull(number30);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        long long3 = month0.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) 1.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = timeSeriesDataItem5.getPeriod();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1559372400000L + "'", long3 == 1559372400000L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        long long3 = month0.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries5.removeChangeListener(seriesChangeListener6);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries5.removeChangeListener(seriesChangeListener8);
        java.lang.String str10 = timeSeries5.getRangeDescription();
        int int11 = month0.compareTo((java.lang.Object) timeSeries5);
        java.util.Collection collection12 = timeSeries5.getTimePeriods();
        timeSeries5.setMaximumItemAge((long) 35);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1559372400000L + "'", long3 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Value" + "'", str10.equals("Value"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(collection12);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) 0);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year3, (java.lang.Number) 0);
        org.jfree.data.general.SeriesException seriesException7 = new org.jfree.data.general.SeriesException("Value");
        java.lang.Throwable[] throwableArray8 = seriesException7.getSuppressed();
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("Value");
        seriesException7.addSuppressed((java.lang.Throwable) seriesException10);
        boolean boolean12 = timeSeriesDataItem5.equals((java.lang.Object) seriesException7);
        boolean boolean13 = timeSeriesDataItem2.equals((java.lang.Object) timeSeriesDataItem5);
        timeSeriesDataItem5.setValue((java.lang.Number) 12);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int2 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        int int4 = month3.getMonth();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.previous();
        boolean boolean7 = month3.equals((java.lang.Object) month5);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month3, (java.lang.Number) 2147483647, false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month3.next();
        long long12 = month3.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month3.next();
        java.util.Calendar calendar14 = null;
        try {
            month3.peg(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1559372400000L + "'", long12 == 1559372400000L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        java.lang.Class class0 = null;
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo2 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1.0f), seriesChangeInfo2);
        java.lang.Class<?> wildcardClass4 = seriesChangeEvent3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date6, timeZone7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        long long12 = month9.getFirstMillisecond();
        java.util.Date date13 = month9.getEnd();
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date13, timeZone14);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date13, timeZone16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.next();
        org.jfree.data.time.SerialDate serialDate20 = day18.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day18.next();
        long long22 = day18.getSerialIndex();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1559372400000L + "'", long12 == 1559372400000L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 43646L + "'", long22 == 43646L);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        int int9 = month8.getMonth();
        int int10 = month8.getYearValue();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo12 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent13 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1.0f), seriesChangeInfo12);
        java.lang.Class<?> wildcardClass14 = seriesChangeEvent13.getClass();
        java.util.Date date15 = null;
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date15, timeZone16);
        int int18 = month8.compareTo((java.lang.Object) timeZone16);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month8);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) 0);
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("Value");
        java.lang.Throwable[] throwableArray5 = seriesException4.getSuppressed();
        org.jfree.data.general.SeriesException seriesException7 = new org.jfree.data.general.SeriesException("Value");
        seriesException4.addSuppressed((java.lang.Throwable) seriesException7);
        boolean boolean9 = timeSeriesDataItem2.equals((java.lang.Object) seriesException4);
        java.lang.Object obj10 = timeSeriesDataItem2.clone();
        java.lang.Object obj11 = timeSeriesDataItem2.clone();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        java.lang.String str8 = timeSeries1.getDescription();
        java.lang.String str9 = timeSeries1.getDomainDescription();
        timeSeries1.setNotify(true);
        int int12 = timeSeries1.getItemCount();
        try {
            timeSeries1.setMaximumItemCount((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'maximum' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        timeSeries1.setMaximumItemCount((int) '#');
        java.lang.Class class9 = timeSeries1.getTimePeriodClass();
        java.util.List list10 = timeSeries1.getItems();
        java.lang.Comparable comparable11 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) 8);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13);
        long long15 = fixedMillisecond13.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond13.previous();
        java.util.Calendar calendar17 = null;
        long long18 = fixedMillisecond13.getLastMillisecond(calendar17);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(class9);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + 100L + "'", comparable11.equals(100L));
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 8L + "'", long15 == 8L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 8L + "'", long18 == 8L);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        java.lang.Object obj0 = null;
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        try {
            org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent(obj0, seriesChangeInfo1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        java.lang.Class class0 = null;
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo2 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1.0f), seriesChangeInfo2);
        java.lang.Class<?> wildcardClass4 = seriesChangeEvent3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date6, timeZone7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        long long12 = month9.getFirstMillisecond();
        java.util.Date date13 = month9.getEnd();
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date13, timeZone14);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date13, timeZone16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.next();
        org.jfree.data.time.SerialDate serialDate20 = day18.getSerialDate();
        java.lang.String str21 = day18.toString();
        long long22 = day18.getMiddleMillisecond();
        org.jfree.data.time.SerialDate serialDate23 = day18.getSerialDate();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1559372400000L + "'", long12 == 1559372400000L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "30-June-2019" + "'", str21.equals("30-June-2019"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1561921199999L + "'", long22 == 1561921199999L);
        org.junit.Assert.assertNotNull(serialDate23);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        java.lang.String str8 = timeSeries1.getDescription();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        long long12 = month9.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (double) 1.0f);
        java.lang.Number number15 = timeSeriesDataItem14.getValue();
        timeSeries1.add(timeSeriesDataItem14, true);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries19.removeChangeListener(seriesChangeListener20);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener22 = null;
        timeSeries19.removeChangeListener(seriesChangeListener22);
        boolean boolean24 = timeSeries19.getNotify();
        timeSeries19.setMaximumItemCount((int) '#');
        java.lang.Class class27 = timeSeries19.getTimePeriodClass();
        timeSeries19.setMaximumItemCount(2147483647);
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries1.addAndOrUpdate(timeSeries19);
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
        int int32 = month31.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = month31.next();
        int int34 = month31.getMonth();
        int int35 = month31.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month31, (double) (byte) 1);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month31);
        int int39 = month31.getMonth();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1559372400000L + "'", long12 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 1.0d + "'", number15.equals(1.0d));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(class27);
        org.junit.Assert.assertNotNull(timeSeries30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 6 + "'", int32 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 6 + "'", int35 == 6);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 6 + "'", int39 == 6);
    }
}

