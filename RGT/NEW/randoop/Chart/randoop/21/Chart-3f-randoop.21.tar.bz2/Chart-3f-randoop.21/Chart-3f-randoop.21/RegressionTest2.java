import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2, (int) (byte) 100);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test02");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        timeSeries1.setMaximumItemAge((long) '#');
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        int int11 = year10.getYear();
        java.lang.String str12 = year10.toString();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        int int14 = month13.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month13.next();
        long long16 = month13.getFirstMillisecond();
        long long17 = month13.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year10, (org.jfree.data.time.RegularTimePeriod) month13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year10.next();
        java.util.Date date20 = year10.getEnd();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1559372400000L + "'", long16 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1559372400000L + "'", long17 == 1559372400000L);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test03");
        java.lang.Class class0 = null;
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo2 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1.0f), seriesChangeInfo2);
        java.lang.Class<?> wildcardClass4 = seriesChangeEvent3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date6, timeZone7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        long long12 = month9.getFirstMillisecond();
        java.util.Date date13 = month9.getEnd();
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date13, timeZone14);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date13, timeZone16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date13);
        int int20 = day19.getDayOfMonth();
        int int21 = day19.getMonth();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1559372400000L + "'", long12 == 1559372400000L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 30 + "'", int20 == 30);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test04");
        java.lang.Class class0 = null;
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo2 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1.0f), seriesChangeInfo2);
        java.lang.Class<?> wildcardClass4 = seriesChangeEvent3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date6, timeZone7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        long long12 = month9.getFirstMillisecond();
        java.util.Date date13 = month9.getEnd();
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date13, timeZone14);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date13, timeZone16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date13);
        java.lang.Object obj19 = null;
        boolean boolean20 = day18.equals(obj19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day18.next();
        long long22 = day18.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long22, "October 8", "");
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        long long27 = year26.getMiddleMillisecond();
        long long28 = year26.getFirstMillisecond();
        long long29 = year26.getSerialIndex();
        java.lang.String str30 = year26.toString();
        boolean boolean31 = timeSeries25.equals((java.lang.Object) str30);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1559372400000L + "'", long12 == 1559372400000L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1561878000000L + "'", long22 == 1561878000000L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1562097599999L + "'", long27 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1546329600000L + "'", long28 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 2019L + "'", long29 == 2019L);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2019" + "'", str30.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test05");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int2 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        int int4 = month3.getMonth();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.previous();
        boolean boolean7 = month3.equals((java.lang.Object) month5);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month3, (java.lang.Number) 2147483647, false);
        int int11 = timeSeries1.getMaximumItemCount();
        java.lang.Class class12 = null;
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo14 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent15 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1.0f), seriesChangeInfo14);
        java.lang.Class<?> wildcardClass16 = seriesChangeEvent15.getClass();
        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass16);
        java.util.Date date18 = null;
        java.util.TimeZone timeZone19 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date18, timeZone19);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
        int int22 = month21.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month21.next();
        long long24 = month21.getFirstMillisecond();
        java.util.Date date25 = month21.getEnd();
        java.util.TimeZone timeZone26 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date25, timeZone26);
        java.util.TimeZone timeZone28 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date25, timeZone28);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day30.next();
        long long32 = day30.getLastMillisecond();
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) day30, (java.lang.Number) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries1.addOrUpdate(regularTimePeriod35, (java.lang.Number) 1560184921020L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2147483647 + "'", int11 == 2147483647);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(class17);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1559372400000L + "'", long24 == 1559372400000L);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1561964399999L + "'", long32 == 1561964399999L);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test06");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        int int5 = month4.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.setKey((java.lang.Comparable) regularTimePeriod6);
        boolean boolean8 = timeSeries1.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) 8);
        long long11 = fixedMillisecond10.getSerialIndex();
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond10.getMiddleMillisecond(calendar12);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries15.removeChangeListener(seriesChangeListener16);
        java.util.List list18 = timeSeries15.getItems();
        java.lang.String str19 = timeSeries15.getDescription();
        int int20 = fixedMillisecond10.compareTo((java.lang.Object) str19);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (java.lang.Number) 0);
        long long23 = fixedMillisecond10.getLastMillisecond();
        java.util.Calendar calendar24 = null;
        long long25 = fixedMillisecond10.getFirstMillisecond(calendar24);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 8L + "'", long11 == 8L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 8L + "'", long13 == 8L);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 8L + "'", long23 == 8L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 8L + "'", long25 == 8L);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test07");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        long long3 = month0.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries5.removeChangeListener(seriesChangeListener6);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries5.removeChangeListener(seriesChangeListener8);
        java.lang.String str10 = timeSeries5.getRangeDescription();
        int int11 = month0.compareTo((java.lang.Object) timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10);
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries13.removePropertyChangeListener(propertyChangeListener14);
        double double16 = timeSeries13.getMinY();
        boolean boolean17 = month0.equals((java.lang.Object) timeSeries13);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries19.removeChangeListener(seriesChangeListener20);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener22 = null;
        timeSeries19.removeChangeListener(seriesChangeListener22);
        boolean boolean24 = timeSeries19.getNotify();
        java.lang.Class class25 = timeSeries19.getTimePeriodClass();
        timeSeries19.setMaximumItemAge((long) '#');
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        int int29 = year28.getYear();
        java.lang.String str30 = year28.toString();
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
        int int32 = month31.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = month31.next();
        long long34 = month31.getFirstMillisecond();
        long long35 = month31.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries19.createCopy((org.jfree.data.time.RegularTimePeriod) year28, (org.jfree.data.time.RegularTimePeriod) month31);
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year();
        long long38 = year37.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries19.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year37, (double) 100L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year37, (double) (byte) 0);
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem42, "org.jfree.data.general.SeriesException: Value", "May -1");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries13.addOrUpdate(timeSeriesDataItem42);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1559372400000L + "'", long3 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Value" + "'", str10.equals("Value"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(class25);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2019 + "'", int29 == 2019);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2019" + "'", str30.equals("2019"));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 6 + "'", int32 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1559372400000L + "'", long34 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1559372400000L + "'", long35 == 1559372400000L);
        org.junit.Assert.assertNotNull(timeSeries36);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1562097599999L + "'", long38 == 1562097599999L);
        org.junit.Assert.assertNull(timeSeriesDataItem40);
        org.junit.Assert.assertNull(timeSeriesDataItem46);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test08");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year7.next();
        int int10 = timeSeries1.getIndex(regularTimePeriod9);
        java.lang.String str11 = timeSeries1.getDomainDescription();
        timeSeries1.setRangeDescription("May -1");
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Time" + "'", str11.equals("Time"));
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test09");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        int int2 = month0.getYearValue();
        org.jfree.data.time.Year year3 = month0.getYear();
        org.jfree.data.time.Year year4 = month0.getYear();
        long long5 = month0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1561964399999L + "'", long5 == 1561964399999L);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test10");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 8);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries6.removeChangeListener(seriesChangeListener7);
        java.util.List list9 = timeSeries6.getItems();
        java.lang.String str10 = timeSeries6.getDescription();
        int int11 = fixedMillisecond1.compareTo((java.lang.Object) str10);
        long long12 = fixedMillisecond1.getLastMillisecond();
        long long13 = fixedMillisecond1.getMiddleMillisecond();
        java.lang.Object obj14 = null;
        boolean boolean15 = fixedMillisecond1.equals(obj14);
        long long16 = fixedMillisecond1.getLastMillisecond();
        java.util.Date date17 = fixedMillisecond1.getEnd();
        long long18 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar19 = null;
        fixedMillisecond1.peg(calendar19);
        java.util.Date date21 = fixedMillisecond1.getTime();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date21);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8L + "'", long2 == 8L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 8L + "'", long4 == 8L);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 8L + "'", long12 == 8L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 8L + "'", long13 == 8L);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 8L + "'", long16 == 8L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 8L + "'", long18 == 8L);
        org.junit.Assert.assertNotNull(date21);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test11");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 8);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (java.lang.Number) 0);
        boolean boolean5 = timeSeriesDataItem4.isSelected();
        boolean boolean6 = fixedMillisecond1.equals((java.lang.Object) timeSeriesDataItem4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond1.previous();
        java.util.Date date8 = fixedMillisecond1.getEnd();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test12");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        long long3 = month0.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries5.removeChangeListener(seriesChangeListener6);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries5.removeChangeListener(seriesChangeListener8);
        java.lang.String str10 = timeSeries5.getRangeDescription();
        int int11 = month0.compareTo((java.lang.Object) timeSeries5);
        double double12 = timeSeries5.getMaxY();
        boolean boolean13 = timeSeries5.isEmpty();
        java.lang.Class class14 = null;
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo16 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent17 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1.0f), seriesChangeInfo16);
        java.lang.Class<?> wildcardClass18 = seriesChangeEvent17.getClass();
        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass18);
        java.util.Date date20 = null;
        java.util.TimeZone timeZone21 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date20, timeZone21);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        int int24 = month23.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = month23.next();
        long long26 = month23.getFirstMillisecond();
        java.util.Date date27 = month23.getEnd();
        java.util.TimeZone timeZone28 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date27, timeZone28);
        java.util.TimeZone timeZone30 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date27, timeZone30);
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date27);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day32.next();
        org.jfree.data.time.SerialDate serialDate34 = day32.getSerialDate();
        java.lang.String str35 = day32.toString();
        int int36 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) day32);
        int int37 = day32.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = day32.previous();
        int int39 = day32.getDayOfMonth();
        java.util.Calendar calendar40 = null;
        try {
            day32.peg(calendar40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1559372400000L + "'", long3 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Value" + "'", str10.equals("Value"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(class19);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 6 + "'", int24 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1559372400000L + "'", long26 == 1559372400000L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "30-June-2019" + "'", str35.equals("30-June-2019"));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 6 + "'", int37 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 30 + "'", int39 == 30);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test13");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries1.getNotify();
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        timeSeries1.setMaximumItemAge((long) '#');
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        int int11 = year10.getYear();
        java.lang.String str12 = year10.toString();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        int int14 = month13.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month13.next();
        long long16 = month13.getFirstMillisecond();
        long long17 = month13.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year10, (org.jfree.data.time.RegularTimePeriod) month13);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int21 = timeSeries20.getMaximumItemCount();
        java.lang.Object obj22 = timeSeries20.clone();
        java.lang.Class class23 = timeSeries20.getTimePeriodClass();
        java.lang.Class class24 = null;
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo26 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent27 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1.0f), seriesChangeInfo26);
        java.lang.Class<?> wildcardClass28 = seriesChangeEvent27.getClass();
        java.lang.Class class29 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass28);
        java.util.Date date30 = null;
        java.util.TimeZone timeZone31 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date30, timeZone31);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        int int34 = month33.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month33.next();
        long long36 = month33.getFirstMillisecond();
        java.util.Date date37 = month33.getEnd();
        java.util.TimeZone timeZone38 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date37, timeZone38);
        java.util.TimeZone timeZone40 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance(class24, date37, timeZone40);
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date37);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = day42.next();
        org.jfree.data.time.SerialDate serialDate44 = day42.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = day42.previous();
        timeSeries20.add(regularTimePeriod45, (java.lang.Number) 8L, false);
        long long49 = regularTimePeriod45.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener52 = null;
        timeSeries51.removeChangeListener(seriesChangeListener52);
        java.util.List list54 = timeSeries51.getItems();
        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year55, (java.lang.Number) 0);
        timeSeries51.add(timeSeriesDataItem57, true);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = timeSeriesDataItem57.getPeriod();
        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries1.createCopy(regularTimePeriod45, regularTimePeriod60);
        try {
            timeSeries1.delete(100, 30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1559372400000L + "'", long16 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1559372400000L + "'", long17 == 1559372400000L);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2147483647 + "'", int21 == 2147483647);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNull(class23);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNotNull(class29);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1559372400000L + "'", long36 == 1559372400000L);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1561834799999L + "'", long49 == 1561834799999L);
        org.junit.Assert.assertNotNull(list54);
        org.junit.Assert.assertNotNull(regularTimePeriod60);
        org.junit.Assert.assertNotNull(timeSeries61);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test14");
        java.lang.Class class0 = null;
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo2 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1.0f), seriesChangeInfo2);
        java.lang.Class<?> wildcardClass4 = seriesChangeEvent3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date6, timeZone7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        long long12 = month9.getFirstMillisecond();
        java.util.Date date13 = month9.getEnd();
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date13, timeZone14);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date13, timeZone16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.next();
        org.jfree.data.time.SerialDate serialDate20 = day18.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day18.previous();
        int int22 = day18.getMonth();
        java.util.Calendar calendar23 = null;
        try {
            long long24 = day18.getLastMillisecond(calendar23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1559372400000L + "'", long12 == 1559372400000L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test15");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.event.SeriesChangeEvent[source=-1.0]");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test16");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0);
        timeSeries1.add(timeSeriesDataItem7, true);
        boolean boolean10 = timeSeriesDataItem7.isSelected();
        timeSeriesDataItem7.setSelected(false);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries14.removeChangeListener(seriesChangeListener15);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries14.removeChangeListener(seriesChangeListener17);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        int int20 = month19.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month19.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month19, (double) 10.0f);
        boolean boolean24 = timeSeries14.getNotify();
        boolean boolean25 = timeSeriesDataItem7.equals((java.lang.Object) timeSeries14);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test17");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        java.lang.String str3 = month0.toString();
        java.lang.String str4 = month0.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) (-1L));
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries8.removeChangeListener(seriesChangeListener9);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        int int12 = month11.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.next();
        timeSeries8.setKey((java.lang.Comparable) regularTimePeriod13);
        boolean boolean15 = month0.equals((java.lang.Object) timeSeries8);
        int int16 = month0.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) (-62131852800001L));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month0.previous();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
    }
}

