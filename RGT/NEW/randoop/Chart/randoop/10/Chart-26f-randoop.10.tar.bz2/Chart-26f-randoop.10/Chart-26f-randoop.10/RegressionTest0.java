import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        float[] floatArray3 = new float[] {};
        try {
            float[] floatArray4 = java.awt.Color.RGBtoHSB((int) (short) -1, (int) (short) 0, (int) (short) 100, floatArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray3);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.awt.Shape shape0 = null;
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape0, (double) (short) 1, (float) 1L, (float) (short) 100);
        org.junit.Assert.assertNull(shape4);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int3 = java.awt.Color.HSBtoRGB((float) 1, 1.0f, (float) 100L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-6553600) + "'", int3 == (-6553600));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_SECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.CLASS_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ClassContext" + "'", str0.equals("ClassContext"));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = null;
        org.jfree.chart.text.TextMeasurer textMeasurer5 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock6 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font1, paint2, 100.0f, (int) (short) -1, textMeasurer5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator1 = null;
        try {
            ganttRenderer0.setLegendItemLabelGenerator(categorySeriesLabelGenerator1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'generator' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(2);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = null;
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType4 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition6 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1, textAnchor2, (double) 10, categoryLabelWidthType4, (float) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'labelAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textAnchor2);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions0, categoryLabelPosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.chart.plot.Plot plot1 = null;
        try {
            org.jfree.chart.JFreeChart jFreeChart2 = new org.jfree.chart.JFreeChart("hi!", plot1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        java.awt.Shape shape0 = null;
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        try {
            org.jfree.chart.title.LegendGraphic legendGraphic2 = new org.jfree.chart.title.LegendGraphic(shape0, (java.awt.Paint) color1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = null;
        try {
            org.jfree.chart.util.Size2D size2D4 = textTitle1.arrange(graphics2D2, rectangleConstraint3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (35) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.awt.Stroke stroke0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeStroke(stroke0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = null;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType2 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition4 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1, categoryLabelWidthType2, 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'labelAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_LOWER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(categoryLabelPositions0, categoryLabelPosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_UPPER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2958465 + "'", int0 == 2958465);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        boolean boolean2 = ganttRenderer0.equals((java.lang.Object) '#');
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        try {
            ganttRenderer0.drawItem(graphics2D3, categoryItemRendererState4, rectangle2D5, categoryPlot6, categoryAxis7, valueAxis8, categoryDataset9, 0, 10, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.25d + "'", double0 == 0.25d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        int int0 = org.jfree.data.time.SerialDate.SUNDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("hi!", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        java.awt.geom.Ellipse2D ellipse2D0 = null;
        java.awt.geom.Ellipse2D ellipse2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(ellipse2D0, ellipse2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.chart.axis.SegmentedTimeline.FIRST_MONDAY_AFTER_1900 = (short) 100;
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("ClassContext", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        java.text.AttributedString attributedString0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeAttributedString(attributedString0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) 10.0f, (double) 10L, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = null;
        try {
            org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("", font1, paint2, rectangleEdge3, horizontalAlignment4, verticalAlignment5, rectangleInsets6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'verticalAlignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(horizontalAlignment4);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairValue((double) (byte) 100, false);
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.event.ChartChangeListener chartChangeListener5 = null;
        try {
            jFreeChart4.removeChangeListener(chartChangeListener5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer3 = null;
        java.util.Collection collection4 = categoryPlot1.getRangeMarkers(3, layer3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot1.setRangeGridlinePaint((java.awt.Paint) color5);
        java.awt.Paint paint8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint8, stroke9);
        java.awt.Paint paint11 = null;
        try {
            org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer12 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color0, (java.awt.Paint) color5, paint8, paint11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'lastBarPaint' argument");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNull(collection4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (short) 0, 1, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator2 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("hi!", numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        boolean boolean2 = ganttRenderer0.equals((java.lang.Object) '#');
        java.awt.Stroke stroke5 = ganttRenderer0.getItemOutlineStroke(11, 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        int int0 = org.jfree.data.time.SerialDate.FOLLOWING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getText();
        java.awt.geom.Rectangle2D rectangle2D3 = textTitle1.getBounds();
        java.io.ObjectOutputStream objectOutputStream4 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeShape((java.awt.Shape) rectangle2D3, objectOutputStream4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D3);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str7 = textTitle6.getText();
        java.awt.geom.Rectangle2D rectangle2D8 = textTitle6.getBounds();
        java.awt.Paint paint11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint11, stroke12);
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 11, 0.0f);
        java.awt.Stroke stroke21 = null;
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        try {
            org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("", "hi!", "", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]", true, (java.awt.Shape) rectangle2D8, false, paint11, true, (java.awt.Paint) color15, stroke16, true, shape20, stroke21, (java.awt.Paint) color22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'lineStroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(color22);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, (double) 11);
        java.lang.String str3 = rectangleConstraint2.toString();
        org.jfree.chart.block.BlockContainer blockContainer4 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.util.Size2D size2D6 = blockContainer4.arrange(graphics2D5);
        try {
            org.jfree.chart.util.Size2D size2D7 = rectangleConstraint2.calculateConstrainedSize(size2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]" + "'", str3.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]"));
        org.junit.Assert.assertNotNull(size2D6);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        java.util.Date date1 = null;
        java.util.Date date2 = null;
        try {
            org.jfree.data.gantt.Task task3 = new org.jfree.data.gantt.Task("hi!", date1, date2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        java.lang.Class class1 = null;
        java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("hi!", class1);
        org.junit.Assert.assertNull(uRL2);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ganttRenderer0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = legendTitle1.getLegendItemGraphicLocation();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            legendTitle1.draw(graphics2D3, rectangle2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor2);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        int int1 = color0.getBlue();
        int int2 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 128 + "'", int1 == 128);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        java.lang.String str0 = org.jfree.chart.ui.Licences.GPL;
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Stroke stroke1 = org.jfree.chart.util.SerialUtilities.readStroke(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        stackedBarRenderer3D0.setBaseStroke(stroke1, false);
        double double4 = stackedBarRenderer3D0.getBase();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers(3, layer2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color4);
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot0.getRangeAxisForDataset((int) (short) -1);
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke10 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint9, stroke10);
        categoryPlot0.setRangeCrosshairStroke(stroke10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        try {
            categoryPlot0.handleClick((int) (byte) 1, (int) (short) 100, plotRenderingInfo15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        int int1 = shapeList0.size();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = categoryPlot3.getRangeMarkers(3, layer5);
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str9 = textTitle8.getText();
        java.awt.geom.Rectangle2D rectangle2D10 = textTitle8.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.axis.AxisSpace axisSpace12 = new org.jfree.chart.axis.AxisSpace();
        try {
            org.jfree.chart.axis.AxisSpace axisSpace13 = dateAxis1.reserveSpace(graphics2D2, (org.jfree.chart.plot.Plot) categoryPlot3, rectangle2D10, rectangleEdge11, axisSpace12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertNotNull(rectangleEdge11);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        ganttRenderer0.setSeriesPaint((int) (byte) 100, (java.awt.Paint) color2);
        java.awt.Paint paint4 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D5 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Paint paint6 = stackedBarRenderer3D5.getWallPaint();
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        try {
            org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer8 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color2, paint4, paint6, (java.awt.Paint) color7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'positiveBarPaint' argument");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        java.awt.Paint paint0 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        int int0 = org.jfree.data.time.SerialDate.PRECEDING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers(3, layer2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color4);
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot0.getRangeAxisForDataset((int) (short) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot8.getRangeMarkers(3, layer10);
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot8.setRangeGridlinePaint((java.awt.Paint) color12);
        org.jfree.chart.axis.ValueAxis valueAxis15 = categoryPlot8.getRangeAxisForDataset((int) (short) -1);
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint17, stroke18);
        categoryPlot8.setRangeCrosshairStroke(stroke18);
        categoryPlot0.setOutlineStroke(stroke18);
        org.jfree.chart.axis.AxisLocation axisLocation22 = null;
        try {
            categoryPlot0.setRangeAxisLocation(axisLocation22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Shape shape1 = org.jfree.chart.util.SerialUtilities.readShape(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator1 = new org.jfree.chart.urls.StandardCategoryURLGenerator("");
        java.lang.Number[] numberArray8 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[][] numberArray19 = new java.lang.Number[][] { numberArray8, numberArray13, numberArray18 };
        org.jfree.data.category.CategoryDataset categoryDataset20 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray19);
        try {
            java.lang.String str23 = standardCategoryURLGenerator1.generateURL(categoryDataset20, 10, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 3");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(categoryDataset20);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        int int0 = org.jfree.data.time.SerialDate.WEDNESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        java.lang.Class class0 = null;
        try {
            boolean boolean1 = org.jfree.chart.util.SerialUtilities.isSerializable(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        java.util.Date date2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double5 = dateAxis4.getFixedDimension();
        java.util.Date date6 = dateAxis4.getMaximumDate();
        try {
            dateAxis1.setRange(date2, date6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        double double0 = org.jfree.chart.plot.PiePlot.MAX_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.4d + "'", double0 == 0.4d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) 0.2d, (double) 3, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        double double1 = axisSpace0.getTop();
        axisSpace0.setRight((double) (-6553600));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((double) 12, numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createInsetRectangle(rectangle2D1, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        int int0 = org.jfree.data.time.SerialDate.TUESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        int int0 = org.jfree.data.time.SerialDate.MONDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        java.lang.String str0 = org.jfree.chart.labels.StandardCategoryToolTipGenerator.DEFAULT_TOOL_TIP_FORMAT_STRING;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "({0}, {1}) = {2}" + "'", str0.equals("({0}, {1}) = {2}"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean2 = stackedBarRenderer3D0.isSeriesVisibleInLegend(11);
        stackedBarRenderer3D0.setSeriesItemLabelsVisible((int) (short) 0, (java.lang.Boolean) false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double2 = dateAxis1.getFixedDimension();
        double double3 = dateAxis1.getLowerBound();
        dateAxis1.configure();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        java.awt.Color color0 = java.awt.Color.BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("java.awt.Color[r=128,g=128,b=255]", graphics2D1, (float) 0, (float) 0L, (double) (byte) 10, (float) (short) 10, (float) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setRangeCrosshairValue((double) (byte) 100, false);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot1);
        categoryPlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart5);
        java.awt.Font font7 = categoryPlot0.getNoDataMessageFont();
        categoryPlot0.setDrawSharedDomainAxis(false);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str13 = textTitle12.getText();
        java.awt.geom.Rectangle2D rectangle2D14 = textTitle12.getBounds();
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D14, (double) (short) 10, 100.0f, (float) (short) -1);
        try {
            categoryPlot0.drawBackground(graphics2D10, rectangle2D14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(shape18);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setRangeCrosshairValue((double) (byte) 100, false);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot2);
        categoryPlot1.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart6);
        java.awt.Font font8 = categoryPlot1.getNoDataMessageFont();
        java.awt.Paint paint9 = null;
        try {
            org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]", font8, paint9, (float) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font8);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        try {
            defaultKeyedValues2D1.removeRow(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("hi!");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer2 = new org.jfree.chart.renderer.category.GanttRenderer();
        boolean boolean4 = ganttRenderer2.equals((java.lang.Object) '#');
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer6 = new org.jfree.chart.renderer.category.GanttRenderer();
        boolean boolean8 = ganttRenderer6.equals((java.lang.Object) '#');
        ganttRenderer6.setSeriesVisibleInLegend(1, (java.lang.Boolean) false, false);
        java.awt.Stroke stroke14 = ganttRenderer6.getSeriesStroke(0);
        boolean boolean15 = itemLabelPosition5.equals((java.lang.Object) ganttRenderer6);
        double double16 = itemLabelPosition5.getAngle();
        ganttRenderer2.setBaseNegativeItemLabelPosition(itemLabelPosition5, false);
        boolean boolean19 = datasetGroup1.equals((java.lang.Object) false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_FINISHED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        int int0 = org.jfree.chart.axis.DateTickUnit.YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.text.AttributedString attributedString1 = org.jfree.chart.util.SerialUtilities.readAttributedString(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        java.awt.Paint paint0 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers(3, layer2);
        java.util.List list4 = categoryPlot0.getAnnotations();
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = null;
        categoryPlot0.setDrawingSupplier(drawingSupplier6);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = categoryPlot0.getDomainMarkers(layer8);
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNull(collection9);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.chart.axis.NumberAxis numberAxis1 = null;
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str8 = textTitle7.getText();
        java.awt.Font font9 = textTitle7.getFont();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand10 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis1, (double) 12, 300.0d, (double) 10.0f, 0.25d, font9);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean13 = stackedBarRenderer3D11.isSeriesVisibleInLegend(11);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer14 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        ganttRenderer14.setSeriesPaint((int) (byte) 100, (java.awt.Paint) color16);
        stackedBarRenderer3D11.setWallPaint((java.awt.Paint) color16);
        org.jfree.chart.block.LabelBlock labelBlock19 = new org.jfree.chart.block.LabelBlock("", font9, (java.awt.Paint) color16);
        java.lang.String str20 = labelBlock19.getToolTipText();
        java.lang.String str21 = labelBlock19.getURLText();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNull(str21);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        java.lang.ClassLoader classLoader0 = null;
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        java.awt.Color color1 = java.awt.Color.getColor("ClassContext");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        java.awt.Paint paint0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        java.util.TimeZone timeZone0 = null;
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone0;
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState2 = null;
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str5 = textTitle4.getText();
        java.awt.Font font6 = textTitle4.getFont();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str10 = textTitle9.getText();
        java.awt.geom.Rectangle2D rectangle2D11 = textTitle9.getBounds();
        textTitle4.draw(graphics2D7, rectangle2D11);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = categoryPlot15.getRangeMarkers(3, layer17);
        java.util.List list19 = categoryPlot15.getAnnotations();
        java.awt.Paint paint20 = categoryPlot15.getOutlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double24 = dateAxis23.getFixedDimension();
        boolean boolean25 = dateAxis23.isAutoTickUnitSelection();
        categoryPlot15.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis) dateAxis23, true);
        java.lang.Number[] numberArray34 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray44 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[][] numberArray45 = new java.lang.Number[][] { numberArray34, numberArray39, numberArray44 };
        org.jfree.data.category.CategoryDataset categoryDataset46 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray45);
        java.lang.Number number47 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset46);
        org.jfree.data.Range range49 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset46, false);
        try {
            boxAndWhiskerRenderer0.drawItem(graphics2D1, categoryItemRendererState2, rectangle2D11, categoryPlot13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis23, categoryDataset46, 12, 11, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: BoxAndWhiskerRenderer.drawItem() : the data should be of type BoxAndWhiskerCategoryDataset only.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(categoryDataset46);
        org.junit.Assert.assertTrue("'" + number47 + "' != '" + 300.0d + "'", number47.equals(300.0d));
        org.junit.Assert.assertNotNull(range49);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairValue((double) (byte) 100, false);
        categoryPlot0.setAnchorValue((double) 1);
        boolean boolean6 = categoryPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        try {
            categoryPlot0.setDomainAxisLocation(axisLocation7, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        java.lang.Number[] numberArray7 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray12 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[][] numberArray18 = new java.lang.Number[][] { numberArray7, numberArray12, numberArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray18);
        java.lang.Number number20 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset19);
        org.jfree.data.Range range22 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset19, false);
        org.jfree.data.Range range23 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset19);
        double double24 = range23.getLength();
        org.jfree.data.KeyedObject keyedObject25 = new org.jfree.data.KeyedObject((java.lang.Comparable) 5, (java.lang.Object) double24);
        java.lang.Object obj26 = keyedObject25.getObject();
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 300.0d + "'", number20.equals(300.0d));
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 303.0d + "'", double24 == 303.0d);
        org.junit.Assert.assertTrue("'" + obj26 + "' != '" + 303.0d + "'", obj26.equals(303.0d));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.FULL;
        org.junit.Assert.assertNotNull(rangeType0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addDays(2, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        polarPlot3.removeCornerTextItem("");
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str8 = textTitle7.getText();
        java.awt.Font font9 = textTitle7.getFont();
        polarPlot3.setAngleLabelFont(font9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint13, stroke14);
        java.awt.Paint paint16 = valueMarker15.getLabelPaint();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        int int18 = color17.getTransparency();
        valueMarker15.setLabelPaint((java.awt.Paint) color17);
        java.awt.image.ColorModel colorModel20 = null;
        java.awt.Rectangle rectangle21 = null;
        java.awt.Font font23 = null;
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer26 = null;
        org.jfree.chart.plot.PolarPlot polarPlot27 = new org.jfree.chart.plot.PolarPlot(xYDataset24, valueAxis25, polarItemRenderer26);
        polarPlot27.removeCornerTextItem("");
        org.jfree.chart.title.TextTitle textTitle31 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str32 = textTitle31.getText();
        java.awt.Font font33 = textTitle31.getFont();
        polarPlot27.setAngleLabelFont(font33);
        org.jfree.chart.JFreeChart jFreeChart36 = new org.jfree.chart.JFreeChart("", font23, (org.jfree.chart.plot.Plot) polarPlot27, true);
        java.awt.Graphics2D graphics2D37 = null;
        org.jfree.chart.title.TextTitle textTitle39 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str40 = textTitle39.getText();
        java.awt.Font font41 = textTitle39.getFont();
        java.awt.Graphics2D graphics2D42 = null;
        org.jfree.chart.title.TextTitle textTitle44 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str45 = textTitle44.getText();
        java.awt.geom.Rectangle2D rectangle2D46 = textTitle44.getBounds();
        textTitle39.draw(graphics2D42, rectangle2D46);
        java.awt.geom.Point2D point2D48 = null;
        org.jfree.chart.plot.PlotState plotState49 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo50 = null;
        polarPlot27.draw(graphics2D37, rectangle2D46, point2D48, plotState49, plotRenderingInfo50);
        java.awt.geom.AffineTransform affineTransform52 = null;
        java.awt.RenderingHints renderingHints53 = null;
        java.awt.PaintContext paintContext54 = color17.createContext(colorModel20, rectangle21, rectangle2D46, affineTransform52, renderingHints53);
        try {
            polarPlot3.drawBackground(graphics2D11, rectangle2D46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "" + "'", str32.equals(""));
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "" + "'", str40.equals(""));
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "" + "'", str45.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertNotNull(paintContext54);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        java.awt.Font font1 = null;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset2, valueAxis3, polarItemRenderer4);
        polarPlot5.removeCornerTextItem("");
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str10 = textTitle9.getText();
        java.awt.Font font11 = textTitle9.getFont();
        polarPlot5.setAngleLabelFont(font11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) polarPlot5, true);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str18 = textTitle17.getText();
        java.awt.Font font19 = textTitle17.getFont();
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str23 = textTitle22.getText();
        java.awt.geom.Rectangle2D rectangle2D24 = textTitle22.getBounds();
        textTitle17.draw(graphics2D20, rectangle2D24);
        java.awt.geom.Point2D point2D26 = null;
        org.jfree.chart.plot.PlotState plotState27 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        polarPlot5.draw(graphics2D15, rectangle2D24, point2D26, plotState27, plotRenderingInfo28);
        java.awt.Paint paint30 = null;
        try {
            org.jfree.chart.title.LegendGraphic legendGraphic31 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape) rectangle2D24, paint30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'fillPaint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D24);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.chart.util.UnitType unitType0 = null;
        try {
            org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, 100.0d, 0.2d, (double) (short) 0, 1.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unitType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0L, (double) (byte) 1, false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (short) 0, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        java.lang.String[] strArray0 = new java.lang.String[] {};
        java.lang.Number[][] numberArray1 = new java.lang.Number[][] {};
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset3 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray0, numberArray1, numberArray2);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double7 = dateAxis6.getFixedDimension();
        java.util.Date date8 = dateAxis6.getMaximumDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 'a');
        org.jfree.data.gantt.Task task15 = new org.jfree.data.gantt.Task("java.awt.Color[r=128,g=128,b=255]", (org.jfree.data.time.TimePeriod) simpleTimePeriod14);
        org.jfree.data.DefaultKeyedValue defaultKeyedValue17 = new org.jfree.data.DefaultKeyedValue((java.lang.Comparable) simpleTimePeriod14, (java.lang.Number) (short) 1);
        java.lang.Comparable[] comparableArray18 = new java.lang.Comparable[] { true, date8, "hi!", 100.0f, (short) 1 };
        try {
            defaultIntervalCategoryDataset3.setSeriesKeys(comparableArray18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of series keys does not match the data.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(numberArray1);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(comparableArray18);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        int int0 = org.jfree.data.time.SerialDate.FOURTH_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean2 = stackedBarRenderer3D0.equals((java.lang.Object) (short) 10);
        stackedBarRenderer3D0.setSeriesVisibleInLegend((int) (byte) 100, (java.lang.Boolean) true);
        boolean boolean8 = stackedBarRenderer3D0.isItemLabelVisible(3, 0);
        double double9 = stackedBarRenderer3D0.getMinimumBarLength();
        java.lang.Number[] numberArray16 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[][] numberArray27 = new java.lang.Number[][] { numberArray16, numberArray21, numberArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray27);
        java.lang.Number number29 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset28);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset28, false);
        org.jfree.data.Range range32 = stackedBarRenderer3D0.findRangeBounds(categoryDataset28);
        try {
            java.lang.Number number33 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset28);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 3");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + 300.0d + "'", number29.equals(300.0d));
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNotNull(range32);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        boxAndWhiskerRenderer0.setItemMargin((double) (short) -1);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset1, valueAxis2, polarItemRenderer3);
        polarPlot4.removeCornerTextItem("");
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str9 = textTitle8.getText();
        java.awt.Font font10 = textTitle8.getFont();
        polarPlot4.setAngleLabelFont(font10);
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) polarPlot4);
        jFreeChart12.setTextAntiAlias(true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(font10);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers(3, layer2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color4);
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot0.getRangeAxisForDataset((int) (short) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot8.getRangeMarkers(3, layer10);
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot8.setRangeGridlinePaint((java.awt.Paint) color12);
        org.jfree.chart.axis.ValueAxis valueAxis15 = categoryPlot8.getRangeAxisForDataset((int) (short) -1);
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint17, stroke18);
        categoryPlot8.setRangeCrosshairStroke(stroke18);
        categoryPlot0.setOutlineStroke(stroke18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        categoryPlot0.zoomRangeAxes((double) 'a', plotRenderingInfo23, point2D24);
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addMonths((int) (short) 10, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        boolean boolean2 = ganttRenderer0.equals((java.lang.Object) '#');
        ganttRenderer0.setSeriesVisibleInLegend(1, (java.lang.Boolean) false, false);
        java.awt.Shape shape8 = ganttRenderer0.getSeriesShape(5);
        ganttRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        ganttRenderer0.setSeriesVisibleInLegend(2, (java.lang.Boolean) false, true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(shape8);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = categoryPlot2.getRangeMarkers(3, layer4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot2.setRangeGridlinePaint((java.awt.Paint) color6);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot8.getRangeMarkers(3, layer10);
        java.util.List list12 = categoryPlot8.getAnnotations();
        categoryPlot8.clearRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer16 = null;
        org.jfree.chart.plot.PolarPlot polarPlot17 = new org.jfree.chart.plot.PolarPlot(xYDataset14, valueAxis15, polarItemRenderer16);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        polarPlot17.setRadiusGridlineStroke(stroke18);
        categoryPlot8.setDomainGridlineStroke(stroke18);
        java.awt.Paint paint22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke23 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint22, stroke23);
        java.awt.Paint paint25 = valueMarker24.getLabelPaint();
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        int int27 = color26.getTransparency();
        valueMarker24.setLabelPaint((java.awt.Paint) color26);
        java.awt.image.ColorModel colorModel29 = null;
        java.awt.Rectangle rectangle30 = null;
        java.awt.Font font32 = null;
        org.jfree.data.xy.XYDataset xYDataset33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer35 = null;
        org.jfree.chart.plot.PolarPlot polarPlot36 = new org.jfree.chart.plot.PolarPlot(xYDataset33, valueAxis34, polarItemRenderer35);
        polarPlot36.removeCornerTextItem("");
        org.jfree.chart.title.TextTitle textTitle40 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str41 = textTitle40.getText();
        java.awt.Font font42 = textTitle40.getFont();
        polarPlot36.setAngleLabelFont(font42);
        org.jfree.chart.JFreeChart jFreeChart45 = new org.jfree.chart.JFreeChart("", font32, (org.jfree.chart.plot.Plot) polarPlot36, true);
        java.awt.Graphics2D graphics2D46 = null;
        org.jfree.chart.title.TextTitle textTitle48 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str49 = textTitle48.getText();
        java.awt.Font font50 = textTitle48.getFont();
        java.awt.Graphics2D graphics2D51 = null;
        org.jfree.chart.title.TextTitle textTitle53 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str54 = textTitle53.getText();
        java.awt.geom.Rectangle2D rectangle2D55 = textTitle53.getBounds();
        textTitle48.draw(graphics2D51, rectangle2D55);
        java.awt.geom.Point2D point2D57 = null;
        org.jfree.chart.plot.PlotState plotState58 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo59 = null;
        polarPlot36.draw(graphics2D46, rectangle2D55, point2D57, plotState58, plotRenderingInfo59);
        java.awt.geom.AffineTransform affineTransform61 = null;
        java.awt.RenderingHints renderingHints62 = null;
        java.awt.PaintContext paintContext63 = color26.createContext(colorModel29, rectangle30, rectangle2D55, affineTransform61, renderingHints62);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D64 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Stroke stroke65 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        stackedBarRenderer3D64.setBaseStroke(stroke65, false);
        try {
            org.jfree.chart.plot.IntervalMarker intervalMarker69 = new org.jfree.chart.plot.IntervalMarker((double) (byte) 0, (double) (byte) -1, (java.awt.Paint) color6, stroke18, (java.awt.Paint) color26, stroke65, (float) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "" + "'", str41.equals(""));
        org.junit.Assert.assertNotNull(font42);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "" + "'", str49.equals(""));
        org.junit.Assert.assertNotNull(font50);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "" + "'", str54.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D55);
        org.junit.Assert.assertNotNull(paintContext63);
        org.junit.Assert.assertNotNull(stroke65);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        double double1 = axisSpace0.getTop();
        axisSpace0.setTop((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getText();
        java.awt.Font font3 = textTitle1.getFont();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str7 = textTitle6.getText();
        java.awt.geom.Rectangle2D rectangle2D8 = textTitle6.getBounds();
        textTitle1.draw(graphics2D4, rectangle2D8);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.util.RectangleEdge.LEFT;
        textTitle1.setPosition(rectangleEdge10);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = textTitle1.getHorizontalAlignment();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNotNull(horizontalAlignment12);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean2 = stackedBarRenderer3D0.isSeriesVisibleInLegend(11);
        java.awt.Stroke stroke3 = stackedBarRenderer3D0.getBaseStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot4.setRangeCrosshairValue((double) (byte) 100, false);
        stackedBarRenderer3D0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot4);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = stackedBarRenderer3D0.getBaseToolTipGenerator();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(categoryToolTipGenerator9);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition0 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer1 = new org.jfree.chart.renderer.category.GanttRenderer();
        boolean boolean3 = ganttRenderer1.equals((java.lang.Object) '#');
        ganttRenderer1.setSeriesVisibleInLegend(1, (java.lang.Boolean) false, false);
        java.awt.Stroke stroke9 = ganttRenderer1.getSeriesStroke(0);
        boolean boolean10 = itemLabelPosition0.equals((java.lang.Object) ganttRenderer1);
        int int11 = ganttRenderer1.getColumnCount();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers(3, layer2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color4);
        org.jfree.data.category.CategoryDataset categoryDataset7 = categoryPlot0.getDataset(128);
        org.jfree.chart.axis.AxisSpace axisSpace8 = new org.jfree.chart.axis.AxisSpace();
        double double9 = axisSpace8.getBottom();
        categoryPlot0.setFixedRangeAxisSpace(axisSpace8);
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator0 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
        java.lang.Object obj1 = intervalCategoryToolTipGenerator0.clone();
        java.lang.Object obj2 = intervalCategoryToolTipGenerator0.clone();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        java.lang.ClassLoader classLoader0 = null;
        try {
            java.util.ResourceBundle.clearCache(classLoader0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        java.util.TimeZone timeZone0 = null;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone0;
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        ganttRenderer0.setSeriesPaint((int) (byte) 100, (java.awt.Paint) color2);
        boolean boolean4 = ganttRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double2 = dateAxis1.getFixedDimension();
        java.util.Date date3 = dateAxis1.getMinimumDate();
        dateAxis1.setAutoRangeMinimumSize(49.5d, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double9 = rectangleInsets7.trimHeight((double) 1.0f);
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D11 = new org.jfree.chart.plot.PiePlot3D(pieDataset10);
        boolean boolean12 = rectangleInsets7.equals((java.lang.Object) pieDataset10);
        dateAxis1.setLabelInsets(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = org.jfree.chart.text.TextUtilities.drawAlignedString("java.awt.Color[r=128,g=128,b=255]", graphics2D1, (float) 0L, 0.0f, textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePaint((java.awt.Paint) color0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.TOP;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setRangeCrosshairValue((double) (byte) 100, false);
        boolean boolean6 = categoryPlot1.equals((java.lang.Object) (-1));
        boolean boolean7 = rectangleEdge0.equals((java.lang.Object) (-1));
        java.lang.String str8 = rectangleEdge0.toString();
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "RectangleEdge.TOP" + "'", str8.equals("RectangleEdge.TOP"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.resources.DataPackageResources dataPackageResources0 = new org.jfree.data.resources.DataPackageResources();
        try {
            java.lang.Object obj2 = dataPackageResources0.getObject("hi!");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.data.resources.DataPackageResources, key hi!");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        java.lang.String[] strArray0 = new java.lang.String[] {};
        java.lang.Number[][] numberArray1 = new java.lang.Number[][] {};
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset3 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray0, numberArray1, numberArray2);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset4, valueAxis5, polarItemRenderer6);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        polarPlot7.setRadiusGridlineStroke(stroke8);
        boolean boolean10 = defaultIntervalCategoryDataset3.hasListener((java.util.EventListener) polarPlot7);
        try {
            java.lang.Comparable comparable12 = defaultIntervalCategoryDataset3.getRowKey(11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(numberArray1);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        double double1 = axisSpace0.getTop();
        axisSpace0.setRight((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        polarPlot3.removeCornerTextItem("");
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str8 = textTitle7.getText();
        java.awt.Font font9 = textTitle7.getFont();
        polarPlot3.setAngleLabelFont(font9);
        java.awt.Paint paint11 = polarPlot3.getRadiusGridlinePaint();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        java.lang.String[] strArray0 = new java.lang.String[] {};
        java.lang.Number[][] numberArray1 = new java.lang.Number[][] {};
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset3 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray0, numberArray1, numberArray2);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset4, valueAxis5, polarItemRenderer6);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        polarPlot7.setRadiusGridlineStroke(stroke8);
        boolean boolean10 = defaultIntervalCategoryDataset3.hasListener((java.util.EventListener) polarPlot7);
        try {
            int int12 = defaultIntervalCategoryDataset3.getCategoryIndex((java.lang.Comparable) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(numberArray1);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        boolean boolean2 = ganttRenderer0.equals((java.lang.Object) '#');
        ganttRenderer0.setSeriesVisibleInLegend(1, (java.lang.Boolean) false, false);
        java.awt.Shape shape8 = ganttRenderer0.getSeriesShape(5);
        ganttRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        ganttRenderer0.setAutoPopulateSeriesStroke(true);
        boolean boolean13 = ganttRenderer0.getBaseSeriesVisibleInLegend();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        boolean boolean2 = ganttRenderer0.equals((java.lang.Object) '#');
        ganttRenderer0.setSeriesVisibleInLegend(1, (java.lang.Boolean) false, false);
        java.awt.Stroke stroke8 = ganttRenderer0.getSeriesStroke(0);
        java.lang.Boolean boolean10 = ganttRenderer0.getSeriesCreateEntities((int) '#');
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        ganttRenderer0.setIncompletePaint((java.awt.Paint) color11);
        java.awt.Paint paint13 = null;
        try {
            ganttRenderer0.setBaseFillPaint(paint13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(stroke8);
        org.junit.Assert.assertNull(boolean10);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ganttRenderer0);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean4 = stackedBarRenderer3D2.isSeriesVisibleInLegend(11);
        java.awt.Stroke stroke5 = stackedBarRenderer3D2.getBaseStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot6.setRangeCrosshairValue((double) (byte) 100, false);
        stackedBarRenderer3D2.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot6);
        int int11 = categoryPlot6.getWeight();
        ganttRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot6);
        java.awt.Image image13 = null;
        categoryPlot6.setBackgroundImage(image13);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Paint paint2 = ganttRenderer0.getSeriesFillPaint((int) ' ');
        try {
            ganttRenderer0.setSeriesVisible((-1), (java.lang.Boolean) false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(paint2);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) (-1), (double) (-1.0f));
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.data.Range range7 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint(range7, (double) 11);
        java.lang.String str10 = rectangleConstraint9.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = rectangleConstraint9.toUnconstrainedWidth();
        double double12 = rectangleConstraint9.getHeight();
        try {
            org.jfree.chart.util.Size2D size2D13 = blockContainer5.arrange(graphics2D6, rectangleConstraint9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]" + "'", str10.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]"));
        org.junit.Assert.assertNotNull(rectangleConstraint11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 11.0d + "'", double12 == 11.0d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("RectangleEdge.TOP");
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        java.awt.Font font1 = null;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset2, valueAxis3, polarItemRenderer4);
        polarPlot5.removeCornerTextItem("");
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str10 = textTitle9.getText();
        java.awt.Font font11 = textTitle9.getFont();
        polarPlot5.setAngleLabelFont(font11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) polarPlot5, true);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent15 = null;
        try {
            jFreeChart14.titleChanged(titleChangeEvent15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(font11);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean2 = stackedBarRenderer3D0.isSeriesVisibleInLegend(11);
        java.awt.Stroke stroke3 = stackedBarRenderer3D0.getBaseStroke();
        org.jfree.chart.axis.AxisSpace axisSpace4 = new org.jfree.chart.axis.AxisSpace();
        double double5 = axisSpace4.getBottom();
        boolean boolean6 = stackedBarRenderer3D0.equals((java.lang.Object) double5);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        java.awt.Color color1 = java.awt.Color.getColor("java.awt.Color[r=128,g=128,b=255]");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers(3, layer2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color4);
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot0.getRangeAxisForDataset((int) (short) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot8.getRangeMarkers(3, layer10);
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot8.setRangeGridlinePaint((java.awt.Paint) color12);
        org.jfree.chart.axis.ValueAxis valueAxis15 = categoryPlot8.getRangeAxisForDataset((int) (short) -1);
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint17, stroke18);
        categoryPlot8.setRangeCrosshairStroke(stroke18);
        categoryPlot0.setOutlineStroke(stroke18);
        java.lang.Number[] numberArray29 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray34 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[][] numberArray40 = new java.lang.Number[][] { numberArray29, numberArray34, numberArray39 };
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray40);
        java.lang.Number number42 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset41);
        org.jfree.data.Range range44 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset41, false);
        categoryPlot0.setDataset(2958465, categoryDataset41);
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertTrue("'" + number42 + "' != '" + 300.0d + "'", number42.equals(300.0d));
        org.junit.Assert.assertNotNull(range44);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[][] numberArray17 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16 };
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray17);
        java.lang.Number number19 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset18);
        org.jfree.data.Range range21 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset18, false);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot22 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset18);
        org.jfree.chart.JFreeChart jFreeChart23 = null;
        try {
            multiplePiePlot22.setPieChart(jFreeChart23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'pieChart' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(categoryDataset18);
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 300.0d + "'", number19.equals(300.0d));
        org.junit.Assert.assertNotNull(range21);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset1, valueAxis2, polarItemRenderer3);
        polarPlot4.removeCornerTextItem("");
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = polarPlot4.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation7);
        java.lang.String str9 = axisLocation0.toString();
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(plotOrientation7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "AxisLocation.TOP_OR_LEFT" + "'", str9.equals("AxisLocation.TOP_OR_LEFT"));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers(3, layer2);
        java.util.List list4 = categoryPlot0.getAnnotations();
        double double5 = categoryPlot0.getAnchorValue();
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        java.util.ResourceBundle.clearCache();
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        java.awt.Paint paint2 = dateAxis1.getTickLabelPaint();
        double double3 = dateAxis1.getUpperMargin();
        dateAxis1.resizeRange((double) (short) 1, 0.0d);
        boolean boolean7 = dateAxis1.isTickLabelsVisible();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str12 = textTitle11.getText();
        java.awt.geom.Rectangle2D rectangle2D13 = textTitle11.getBounds();
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D13, (double) (short) 10, 100.0f, (float) (short) -1);
        org.jfree.chart.entity.EntityCollection entityCollection18 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo19 = new org.jfree.chart.ChartRenderingInfo(entityCollection18);
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str22 = textTitle21.getText();
        java.awt.geom.Rectangle2D rectangle2D23 = textTitle21.getBounds();
        chartRenderingInfo19.setChartArea(rectangle2D23);
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        try {
            org.jfree.chart.axis.AxisState axisState27 = dateAxis1.draw(graphics2D8, 4.0d, rectangle2D13, rectangle2D23, rectangleEdge25, plotRenderingInfo26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(rectangleEdge25);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("RectangleEdge.TOP", graphics2D1, 11.0d, (float) 128, (float) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) paintArray0);
        java.lang.Object obj2 = chartChangeEvent1.getSource();
        org.jfree.chart.JFreeChart jFreeChart3 = chartChangeEvent1.getChart();
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNull(jFreeChart3);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.TickLabelEntity tickLabelEntity3 = new org.jfree.chart.entity.TickLabelEntity(shape0, "", "RectangleEdge.TOP");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        int int0 = org.jfree.data.time.SerialDate.FIRST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, (double) 11);
        java.lang.String str3 = rectangleConstraint2.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toUnconstrainedWidth();
        double double5 = rectangleConstraint2.getHeight();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = rectangleConstraint2.toUnconstrainedHeight();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]" + "'", str3.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]"));
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 11.0d + "'", double5 == 11.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint6);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double2 = dateAxis1.getFixedDimension();
        java.util.Date date3 = dateAxis1.getMaximumDate();
        java.lang.Comparable[] comparableArray5 = new java.lang.Comparable[] { date3, 'a' };
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double9 = dateAxis8.getFixedDimension();
        java.util.Date date10 = dateAxis8.getMinimumDate();
        java.lang.Comparable[] comparableArray11 = new java.lang.Comparable[] { (byte) 100, date10 };
        double[][] doubleArray12 = new double[][] {};
        try {
            org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray5, comparableArray11, doubleArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of row keys does not match the number of rows in the data array.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(comparableArray5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(comparableArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemLineVisible((int) (short) -1, 8);
        java.lang.Object obj4 = lineAndShapeRenderer0.clone();
        java.lang.Boolean boolean6 = lineAndShapeRenderer0.getSeriesLinesVisible((int) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNull(boolean6);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset1, valueAxis2, polarItemRenderer3);
        polarPlot4.removeCornerTextItem("");
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str9 = textTitle8.getText();
        java.awt.Font font10 = textTitle8.getFont();
        polarPlot4.setAngleLabelFont(font10);
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) polarPlot4);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D13 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean15 = stackedBarRenderer3D13.isSeriesVisibleInLegend(11);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer16 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        ganttRenderer16.setSeriesPaint((int) (byte) 100, (java.awt.Paint) color18);
        stackedBarRenderer3D13.setWallPaint((java.awt.Paint) color18);
        jFreeChart12.setBorderPaint((java.awt.Paint) color18);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str25 = textTitle24.getText();
        java.awt.geom.Rectangle2D rectangle2D26 = textTitle24.getBounds();
        java.awt.Shape shape30 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D26, (double) (short) 10, 100.0f, (float) (short) -1);
        org.jfree.chart.entity.EntityCollection entityCollection31 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo32 = new org.jfree.chart.ChartRenderingInfo(entityCollection31);
        try {
            jFreeChart12.draw(graphics2D22, rectangle2D26, chartRenderingInfo32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(shape30);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        boolean boolean2 = ganttRenderer0.equals((java.lang.Object) '#');
        ganttRenderer0.setSeriesVisibleInLegend(1, (java.lang.Boolean) false, false);
        java.awt.Stroke stroke8 = ganttRenderer0.getSeriesStroke(0);
        java.lang.Boolean boolean10 = ganttRenderer0.getSeriesCreateEntities((int) '#');
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        ganttRenderer0.setIncompletePaint((java.awt.Paint) color11);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator14 = ganttRenderer0.getSeriesToolTipGenerator(128);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean17 = stackedBarRenderer3D15.isSeriesVisibleInLegend(11);
        java.awt.Stroke stroke18 = stackedBarRenderer3D15.getBaseStroke();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator21 = stackedBarRenderer3D15.getItemLabelGenerator((int) (short) -1, 0);
        java.awt.Paint paint22 = stackedBarRenderer3D15.getBaseItemLabelPaint();
        ganttRenderer0.setIncompletePaint(paint22);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(stroke8);
        org.junit.Assert.assertNull(boolean10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(categoryToolTipGenerator14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNull(categoryItemLabelGenerator21);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        java.awt.Font font1 = null;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset2, valueAxis3, polarItemRenderer4);
        polarPlot5.removeCornerTextItem("");
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str10 = textTitle9.getText();
        java.awt.Font font11 = textTitle9.getFont();
        polarPlot5.setAngleLabelFont(font11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) polarPlot5, true);
        org.jfree.chart.plot.PlotOrientation plotOrientation15 = polarPlot5.getOrientation();
        boolean boolean16 = polarPlot5.isDomainZoomable();
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(plotOrientation15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairValue((double) (byte) 100, false);
        categoryPlot0.setAnchorValue((double) 1);
        boolean boolean6 = categoryPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        try {
            categoryPlot0.handleClick(0, (int) (byte) 10, plotRenderingInfo9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        try {
            java.awt.Color color1 = java.awt.Color.decode("ClassContext");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"ClassContext\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, 0.0d, (double) (byte) 100, 0, (java.lang.Comparable) 4.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getText();
        java.awt.Font font3 = textTitle1.getFont();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str7 = textTitle6.getText();
        java.awt.geom.Rectangle2D rectangle2D8 = textTitle6.getBounds();
        textTitle1.draw(graphics2D4, rectangle2D8);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.util.RectangleEdge.LEFT;
        textTitle1.setPosition(rectangleEdge10);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = textTitle1.getPosition();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNotNull(rectangleEdge12);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod3 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 'a');
        org.jfree.data.gantt.Task task4 = new org.jfree.data.gantt.Task("java.awt.Color[r=128,g=128,b=255]", (org.jfree.data.time.TimePeriod) simpleTimePeriod3);
        org.jfree.data.DefaultKeyedValue defaultKeyedValue6 = new org.jfree.data.DefaultKeyedValue((java.lang.Comparable) simpleTimePeriod3, (java.lang.Number) (short) 1);
        java.lang.Comparable comparable7 = defaultKeyedValue6.getKey();
        org.junit.Assert.assertNotNull(comparable7);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        int int0 = org.jfree.data.time.SerialDate.SATURDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            blockContainer0.draw(graphics2D1, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean2 = lineAndShapeRenderer0.equals((java.lang.Object) 12);
        java.lang.Object obj3 = lineAndShapeRenderer0.clone();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers(3, layer2);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        try {
            categoryPlot0.setDomainAxis((-1), categoryAxis5, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection3);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition0 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition3 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = new org.jfree.chart.axis.CategoryLabelPositions(categoryLabelPosition0, categoryLabelPosition1, categoryLabelPosition2, categoryLabelPosition3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'top' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.chart.axis.NumberAxis numberAxis1 = null;
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str8 = textTitle7.getText();
        java.awt.Font font9 = textTitle7.getFont();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand10 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis1, (double) 12, 300.0d, (double) 10.0f, 0.25d, font9);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean13 = stackedBarRenderer3D11.isSeriesVisibleInLegend(11);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer14 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        ganttRenderer14.setSeriesPaint((int) (byte) 100, (java.awt.Paint) color16);
        stackedBarRenderer3D11.setWallPaint((java.awt.Paint) color16);
        org.jfree.chart.block.LabelBlock labelBlock19 = new org.jfree.chart.block.LabelBlock("", font9, (java.awt.Paint) color16);
        java.lang.String str20 = labelBlock19.getToolTipText();
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.title.TextTitle textTitle23 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str24 = textTitle23.getText();
        java.awt.geom.Rectangle2D rectangle2D25 = textTitle23.getBounds();
        try {
            labelBlock19.draw(graphics2D21, rectangle2D25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D25);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        java.awt.Paint paint1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint1, stroke2);
        java.awt.Paint paint4 = valueMarker3.getLabelPaint();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        int int6 = color5.getTransparency();
        valueMarker3.setLabelPaint((java.awt.Paint) color5);
        float[] floatArray8 = null;
        float[] floatArray9 = color5.getRGBComponents(floatArray8);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(floatArray9);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double3 = dateAxis2.getFixedDimension();
        java.util.Date date4 = dateAxis2.getMinimumDate();
        try {
            org.jfree.data.general.PieDataset pieDataset7 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) date4, 0.0d, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator0 = new org.jfree.chart.urls.StandardCategoryURLGenerator();
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 100, (float) 128);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        boolean boolean2 = ganttRenderer0.equals((java.lang.Object) '#');
        ganttRenderer0.setSeriesVisibleInLegend(1, (java.lang.Boolean) false, false);
        ganttRenderer0.setIncludeBaseInRange(true);
        int int9 = ganttRenderer0.getPassCount();
        java.awt.Font font10 = null;
        ganttRenderer0.setBaseItemLabelFont(font10, true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        int int3 = color2.getBlue();
        paintList0.setPaint(10, (java.awt.Paint) color2);
        java.awt.Paint paint6 = paintList0.getPaint(1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 128 + "'", int3 == 128);
        org.junit.Assert.assertNull(paint6);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        boolean boolean2 = ganttRenderer0.equals((java.lang.Object) '#');
        ganttRenderer0.setSeriesVisibleInLegend(1, (java.lang.Boolean) false, false);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer7 = ganttRenderer0.getGradientPaintTransformer();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment8 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment9 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement12 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment8, verticalAlignment9, (double) (-1), (double) (-1.0f));
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment13 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment14 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement17 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment13, verticalAlignment14, (double) (-1), (double) (-1.0f));
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ganttRenderer0, (org.jfree.chart.block.Arrangement) columnArrangement12, (org.jfree.chart.block.Arrangement) columnArrangement17);
        org.jfree.chart.block.BlockContainer blockContainer19 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.util.Size2D size2D21 = blockContainer19.arrange(graphics2D20);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.data.Range range23 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint25 = new org.jfree.chart.block.RectangleConstraint(range23, (double) 11);
        java.lang.String str26 = rectangleConstraint25.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint27 = rectangleConstraint25.toUnconstrainedWidth();
        try {
            org.jfree.chart.util.Size2D size2D28 = columnArrangement17.arrange(blockContainer19, graphics2D22, rectangleConstraint25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(gradientPaintTransformer7);
        org.junit.Assert.assertNotNull(size2D21);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]" + "'", str26.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]"));
        org.junit.Assert.assertNotNull(rectangleConstraint27);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        try {
            java.lang.Comparable comparable2 = defaultKeyedValues0.getKey(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.chart.axis.NumberAxis numberAxis2 = null;
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str9 = textTitle8.getText();
        java.awt.Font font10 = textTitle8.getFont();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand11 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis2, (double) 12, 300.0d, (double) 10.0f, 0.25d, font10);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D12 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean14 = stackedBarRenderer3D12.isSeriesVisibleInLegend(11);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer15 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        ganttRenderer15.setSeriesPaint((int) (byte) 100, (java.awt.Paint) color17);
        stackedBarRenderer3D12.setWallPaint((java.awt.Paint) color17);
        org.jfree.chart.block.LabelBlock labelBlock20 = new org.jfree.chart.block.LabelBlock("", font10, (java.awt.Paint) color17);
        org.jfree.chart.text.TextFragment textFragment21 = new org.jfree.chart.text.TextFragment("hi!", font10);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.text.TextAnchor textAnchor25 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        try {
            textFragment21.draw(graphics2D22, 0.0f, 0.0f, textAnchor25, 100.0f, (float) (byte) 10, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(textAnchor25);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        double double0 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_X_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 12.0d + "'", double0 == 12.0d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean2 = stackedBarRenderer3D0.isSeriesVisibleInLegend(11);
        java.awt.Stroke stroke3 = stackedBarRenderer3D0.getBaseStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot4.setRangeCrosshairValue((double) (byte) 100, false);
        stackedBarRenderer3D0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot4);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getRangeMarkers(3, layer11);
        java.util.List list13 = categoryPlot9.getAnnotations();
        categoryPlot9.clearRangeAxes();
        boolean boolean15 = categoryPlot4.equals((java.lang.Object) categoryPlot9);
        org.jfree.chart.plot.CategoryMarker categoryMarker17 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 128);
        categoryMarker17.setDrawAsLine(true);
        org.jfree.chart.util.Layer layer20 = null;
        try {
            categoryPlot9.addDomainMarker(categoryMarker17, layer20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.chart.entity.EntityCollection entityCollection4 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = new org.jfree.chart.ChartRenderingInfo(entityCollection4);
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str8 = textTitle7.getText();
        java.awt.geom.Rectangle2D rectangle2D9 = textTitle7.getBounds();
        chartRenderingInfo5.setChartArea(rectangle2D9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem12 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]", "({0}, {1}) = {2}", "", "", (java.awt.Shape) rectangle2D9, (java.awt.Paint) color11);
        org.jfree.data.general.Dataset dataset13 = legendItem12.getDataset();
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer16 = null;
        org.jfree.chart.plot.PolarPlot polarPlot17 = new org.jfree.chart.plot.PolarPlot(xYDataset14, valueAxis15, polarItemRenderer16);
        polarPlot17.removeCornerTextItem("");
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str22 = textTitle21.getText();
        java.awt.Font font23 = textTitle21.getFont();
        polarPlot17.setAngleLabelFont(font23);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D25 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean27 = stackedBarRenderer3D25.isSeriesVisibleInLegend(11);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer28 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        ganttRenderer28.setSeriesPaint((int) (byte) 100, (java.awt.Paint) color30);
        stackedBarRenderer3D25.setWallPaint((java.awt.Paint) color30);
        polarPlot17.setNoDataMessagePaint((java.awt.Paint) color30);
        boolean boolean34 = legendItem12.equals((java.lang.Object) polarPlot17);
        try {
            polarPlot17.zoom(0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(dataset13);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.awt.Paint paint2 = null;
        textTitle1.setBackgroundPaint(paint2);
        java.lang.String str4 = textTitle1.getText();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.data.Range range6 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint(range6, (double) 11);
        java.lang.String str9 = rectangleConstraint8.toString();
        java.lang.Number[] numberArray16 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[][] numberArray27 = new java.lang.Number[][] { numberArray16, numberArray21, numberArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray27);
        java.lang.Number number29 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset28);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset28, false);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint32 = rectangleConstraint8.toRangeHeight(range31);
        try {
            org.jfree.chart.util.Size2D size2D33 = textTitle1.arrange(graphics2D5, rectangleConstraint8);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]" + "'", str9.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]"));
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + 300.0d + "'", number29.equals(300.0d));
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNotNull(rectangleConstraint32);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.SerialDate serialDate3 = null;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        try {
            boolean boolean6 = spreadsheetDate1.isInRange(serialDate3, (org.jfree.data.time.SerialDate) spreadsheetDate5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        double double1 = lineAndShapeRenderer0.getItemLabelAnchorOffset();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        lineAndShapeRenderer0.setSeriesPaint((int) (short) 10, (java.awt.Paint) color3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset1, valueAxis2, polarItemRenderer3);
        polarPlot4.removeCornerTextItem("");
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str9 = textTitle8.getText();
        java.awt.Font font10 = textTitle8.getFont();
        polarPlot4.setAngleLabelFont(font10);
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) polarPlot4);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D13 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean15 = stackedBarRenderer3D13.isSeriesVisibleInLegend(11);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer16 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        ganttRenderer16.setSeriesPaint((int) (byte) 100, (java.awt.Paint) color18);
        stackedBarRenderer3D13.setWallPaint((java.awt.Paint) color18);
        jFreeChart12.setBorderPaint((java.awt.Paint) color18);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo24 = null;
        try {
            jFreeChart12.handleClick((int) (short) 100, 0, chartRenderingInfo24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(color18);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        boxAndWhiskerRenderer0.setFillBox(true);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("RectangleEdge.TOP", graphics2D1, (float) 10, (float) ' ', textAnchor4, (-1.0d), (float) 86400000L, (float) 2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairValue((double) (byte) 100, false);
        categoryPlot0.setAnchorValue((double) 1);
        boolean boolean6 = categoryPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        try {
            categoryPlot0.handleClick((-1), 8, plotRenderingInfo9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        polarPlot3.removeCornerTextItem("");
        java.lang.Object obj6 = polarPlot3.clone();
        java.awt.Image image7 = polarPlot3.getBackgroundImage();
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(image7);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean2 = stackedBarRenderer3D0.isSeriesVisibleInLegend(11);
        java.awt.Stroke stroke3 = stackedBarRenderer3D0.getBaseStroke();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = stackedBarRenderer3D0.getItemLabelGenerator((int) (short) -1, 0);
        java.awt.Paint paint7 = stackedBarRenderer3D0.getBaseItemLabelPaint();
        double double8 = stackedBarRenderer3D0.getBase();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        polarPlot3.removeCornerTextItem("");
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str8 = textTitle7.getText();
        java.awt.Font font9 = textTitle7.getFont();
        polarPlot3.setAngleLabelFont(font9);
        org.jfree.chart.axis.ValueAxis valueAxis11 = polarPlot3.getAxis();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNull(valueAxis11);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        paintList0.clear();
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_FIRST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        java.awt.Stroke stroke4 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        polarPlot3.setRadiusGridlineStroke(stroke4);
        polarPlot3.setAngleLabelsVisible(false);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.lang.Class<?> wildcardClass1 = stackedBarRenderer3D0.getClass();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer4 = new org.jfree.chart.renderer.category.GanttRenderer();
        boolean boolean6 = ganttRenderer4.equals((java.lang.Object) '#');
        ganttRenderer4.setSeriesVisibleInLegend(1, (java.lang.Boolean) false, false);
        java.awt.Stroke stroke12 = ganttRenderer4.getSeriesStroke(0);
        boolean boolean13 = itemLabelPosition3.equals((java.lang.Object) ganttRenderer4);
        double double14 = itemLabelPosition3.getAngle();
        stackedBarRenderer3D0.setSeriesPositiveItemLabelPosition(0, itemLabelPosition3, true);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        double double0 = org.jfree.chart.renderer.category.LevelRenderer.DEFAULT_ITEM_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.lang.String str1 = rectangleInsets0.toString();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str1.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Paint paint1 = org.jfree.chart.util.SerialUtilities.readPaint(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_MINIMUM_ARC_ANGLE_TO_DRAW;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-5d + "'", double0 == 1.0E-5d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        java.awt.Paint paint1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint1, stroke2);
        java.awt.Paint paint4 = valueMarker3.getLabelPaint();
        java.lang.Object obj5 = valueMarker3.clone();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        int int7 = color6.getBlue();
        valueMarker3.setOutlinePaint((java.awt.Paint) color6);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer9 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        ganttRenderer9.setSeriesPaint((int) (byte) 100, (java.awt.Paint) color11);
        java.awt.Stroke stroke15 = ganttRenderer9.getItemOutlineStroke((int) (byte) 0, 5);
        valueMarker3.setOutlineStroke(stroke15);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 128 + "'", int7 == 128);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers(3, layer2);
        java.util.List list4 = categoryPlot0.getAnnotations();
        categoryPlot0.clearRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer8 = null;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot(xYDataset6, valueAxis7, polarItemRenderer8);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        polarPlot9.setRadiusGridlineStroke(stroke10);
        categoryPlot0.setDomainGridlineStroke(stroke10);
        boolean boolean13 = categoryPlot0.isRangeGridlinesVisible();
        categoryPlot0.clearRangeMarkers((int) (short) 10);
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = month0.getFirstMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, (double) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        double double3 = piePlot3D1.getExplodePercent((java.lang.Comparable) 0.2d);
        java.lang.Object obj4 = piePlot3D1.clone();
        piePlot3D1.setDepthFactor((double) (short) 100);
        java.awt.Image image7 = piePlot3D1.getBackgroundImage();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNull(image7);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean2 = stackedBarRenderer3D0.equals((java.lang.Object) (short) 10);
        stackedBarRenderer3D0.setSeriesVisibleInLegend((int) (byte) 100, (java.lang.Boolean) true);
        boolean boolean8 = stackedBarRenderer3D0.isItemLabelVisible(3, 0);
        double double9 = stackedBarRenderer3D0.getMinimumBarLength();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.setRangeCrosshairValue((double) (byte) 100, false);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot12);
        categoryPlot11.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart16);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double20 = dateAxis19.getFixedDimension();
        java.util.Date date21 = dateAxis19.getMinimumDate();
        org.jfree.chart.entity.EntityCollection entityCollection26 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo27 = new org.jfree.chart.ChartRenderingInfo(entityCollection26);
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str30 = textTitle29.getText();
        java.awt.geom.Rectangle2D rectangle2D31 = textTitle29.getBounds();
        chartRenderingInfo27.setChartArea(rectangle2D31);
        java.awt.Color color33 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem34 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]", "({0}, {1}) = {2}", "", "", (java.awt.Shape) rectangle2D31, (java.awt.Paint) color33);
        stackedBarRenderer3D0.drawRangeGridline(graphics2D10, categoryPlot11, (org.jfree.chart.axis.ValueAxis) dateAxis19, rectangle2D31, 300.0d);
        dateAxis19.setAutoTickUnitSelection(false);
        java.awt.Shape shape39 = dateAxis19.getUpArrow();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "" + "'", str30.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(shape39);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.geom.Point2D point2D1 = org.jfree.chart.util.SerialUtilities.readPoint2D(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        java.lang.String[] strArray0 = new java.lang.String[] {};
        java.lang.Number[][] numberArray1 = new java.lang.Number[][] {};
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset3 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray0, numberArray1, numberArray2);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset4, valueAxis5, polarItemRenderer6);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        polarPlot7.setRadiusGridlineStroke(stroke8);
        boolean boolean10 = defaultIntervalCategoryDataset3.hasListener((java.util.EventListener) polarPlot7);
        org.jfree.data.general.DatasetGroup datasetGroup12 = new org.jfree.data.general.DatasetGroup("ClassContext");
        defaultIntervalCategoryDataset3.setGroup(datasetGroup12);
        try {
            java.lang.Object obj14 = defaultIntervalCategoryDataset3.clone();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(numberArray1);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("RectangleEdge.TOP");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name RectangleEdge.TOP, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ganttRenderer0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = legendTitle1.getLegendItemGraphicLocation();
        java.awt.Paint paint3 = legendTitle1.getBackgroundPaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = legendTitle1.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        legendTitle1.setLegendItemGraphicEdge(rectangleEdge5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        try {
            legendTitle1.draw(graphics2D7, rectangle2D8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(rectangleEdge5);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean2 = stackedBarRenderer3D0.isSeriesVisibleInLegend(11);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer3 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        ganttRenderer3.setSeriesPaint((int) (byte) 100, (java.awt.Paint) color5);
        stackedBarRenderer3D0.setWallPaint((java.awt.Paint) color5);
        java.awt.Paint paint8 = stackedBarRenderer3D0.getWallPaint();
        boolean boolean10 = stackedBarRenderer3D0.equals((java.lang.Object) 1.0E-5d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        defaultKeyedValues2D1.setValue((java.lang.Number) 3.0d, (java.lang.Comparable) 100L, (java.lang.Comparable) (byte) 100);
        java.util.List list6 = defaultKeyedValues2D1.getColumnKeys();
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (5) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double2 = dateAxis1.getFixedDimension();
        java.util.Date date3 = dateAxis1.getMaximumDate();
        dateAxis1.setAutoRangeMinimumSize(3.0d);
        dateAxis1.setTickMarkOutsideLength((float) 2);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        org.jfree.chart.axis.TickUnitSource tickUnitSource10 = dateAxis9.getStandardTickUnits();
        dateAxis1.setStandardTickUnits(tickUnitSource10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(tickUnitSource10);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset1, valueAxis2, polarItemRenderer3);
        polarPlot4.removeCornerTextItem("");
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str9 = textTitle8.getText();
        java.awt.Font font10 = textTitle8.getFont();
        polarPlot4.setAngleLabelFont(font10);
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) polarPlot4);
        boolean boolean13 = jFreeChart12.isNotify();
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.END;
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.junit.Assert.assertNotNull(rectangleConstraint0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        java.lang.String str1 = basicProjectInfo0.getVersion();
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("java.awt.Color[r=128,g=128,b=255]", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[][] numberArray17 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16 };
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray17);
        java.lang.Number number19 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset18);
        org.jfree.data.Range range21 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset18, false);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot22 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset18);
        org.jfree.data.Range range23 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset18);
        org.jfree.data.Range range26 = org.jfree.data.Range.expand(range23, (double) 2958465, 0.05d);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(categoryDataset18);
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 300.0d + "'", number19.equals(300.0d));
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNotNull(range26);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(100);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        int int2 = defaultKeyedValues2D1.getRowCount();
        try {
            java.lang.Number number5 = defaultKeyedValues2D1.getValue((java.lang.Comparable) 49.5d, (java.lang.Comparable) 0);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: 0");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.data.Range range2 = new org.jfree.data.Range((double) 'a', (double) 'a');
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.trimHeight((double) 1.0f);
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D(pieDataset3);
        boolean boolean5 = rectangleInsets0.equals((java.lang.Object) pieDataset3);
        java.awt.Font font7 = null;
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot(xYDataset8, valueAxis9, polarItemRenderer10);
        polarPlot11.removeCornerTextItem("");
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str16 = textTitle15.getText();
        java.awt.Font font17 = textTitle15.getFont();
        polarPlot11.setAngleLabelFont(font17);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("", font7, (org.jfree.chart.plot.Plot) polarPlot11, true);
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.title.TextTitle textTitle23 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str24 = textTitle23.getText();
        java.awt.Font font25 = textTitle23.getFont();
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str29 = textTitle28.getText();
        java.awt.geom.Rectangle2D rectangle2D30 = textTitle28.getBounds();
        textTitle23.draw(graphics2D26, rectangle2D30);
        java.awt.geom.Point2D point2D32 = null;
        org.jfree.chart.plot.PlotState plotState33 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        polarPlot11.draw(graphics2D21, rectangle2D30, point2D32, plotState33, plotRenderingInfo34);
        java.awt.geom.Rectangle2D rectangle2D36 = rectangleInsets0.createInsetRectangle(rectangle2D30);
        java.lang.Number[] numberArray45 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray50 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray55 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[][] numberArray56 = new java.lang.Number[][] { numberArray45, numberArray50, numberArray55 };
        org.jfree.data.category.CategoryDataset categoryDataset57 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray56);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity60 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D36, "hi!", "({0}, {1}) = {2}", categoryDataset57, (java.lang.Comparable) 0.0f, (java.lang.Comparable) 0);
        org.jfree.data.Range range61 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset57);
        org.jfree.data.Range range62 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset57);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(numberArray55);
        org.junit.Assert.assertNotNull(numberArray56);
        org.junit.Assert.assertNotNull(categoryDataset57);
        org.junit.Assert.assertNotNull(range61);
        org.junit.Assert.assertNotNull(range62);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        boolean boolean2 = ganttRenderer0.equals((java.lang.Object) '#');
        ganttRenderer0.setSeriesVisibleInLegend(1, (java.lang.Boolean) false, false);
        ganttRenderer0.setIncludeBaseInRange(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = ganttRenderer0.getBaseURLGenerator();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(categoryURLGenerator9);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        boolean boolean2 = ganttRenderer0.equals((java.lang.Object) '#');
        ganttRenderer0.setSeriesVisibleInLegend(1, (java.lang.Boolean) false, false);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer7 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        ganttRenderer7.setSeriesPaint((int) (byte) 100, (java.awt.Paint) color9);
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator15 = new org.jfree.chart.urls.StandardCategoryURLGenerator("hi!", "ClassContext", "hi!");
        ganttRenderer7.setSeriesURLGenerator((int) '#', (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator15, false);
        ganttRenderer0.setBaseURLGenerator((org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator15);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers(3, layer2);
        java.util.List list4 = categoryPlot0.getAnnotations();
        categoryPlot0.clearRangeAxes();
        categoryPlot0.clearRangeAxes();
        categoryPlot0.setRangeCrosshairVisible(true);
        java.util.List list9 = categoryPlot0.getCategories();
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNull(list9);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        ganttRenderer0.setSeriesPaint((int) (byte) 100, (java.awt.Paint) color2);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = ganttRenderer0.getLegendItemURLGenerator();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        java.awt.Color color0 = java.awt.Color.magenta;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        java.awt.Stroke stroke0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers(3, layer2);
        java.util.List list4 = categoryPlot0.getAnnotations();
        java.awt.Paint paint5 = categoryPlot0.getOutlinePaint();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation6 = null;
        try {
            boolean boolean7 = categoryPlot0.removeAnnotation(categoryAnnotation6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        java.awt.Paint paint2 = dateAxis1.getTickLabelPaint();
        double double3 = dateAxis1.getUpperMargin();
        double double4 = dateAxis1.getLowerMargin();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean2 = stackedBarRenderer3D0.equals((java.lang.Object) (short) 10);
        stackedBarRenderer3D0.setSeriesVisibleInLegend((int) (byte) 100, (java.lang.Boolean) true);
        boolean boolean8 = stackedBarRenderer3D0.isItemLabelVisible(3, 0);
        double double9 = stackedBarRenderer3D0.getMinimumBarLength();
        java.lang.Number[] numberArray16 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[][] numberArray27 = new java.lang.Number[][] { numberArray16, numberArray21, numberArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray27);
        java.lang.Number number29 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset28);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset28, false);
        org.jfree.data.Range range32 = stackedBarRenderer3D0.findRangeBounds(categoryDataset28);
        java.lang.Number[] numberArray39 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray44 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray49 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[][] numberArray50 = new java.lang.Number[][] { numberArray39, numberArray44, numberArray49 };
        org.jfree.data.category.CategoryDataset categoryDataset51 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray50);
        org.jfree.data.Range range52 = stackedBarRenderer3D0.findRangeBounds(categoryDataset51);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + 300.0d + "'", number29.equals(300.0d));
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(numberArray49);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(categoryDataset51);
        org.junit.Assert.assertNotNull(range52);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        org.jfree.chart.text.TextFragment textFragment1 = null;
        textLine0.removeFragment(textFragment1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        textLine0.draw(graphics2D3, (float) 2, (float) (byte) 0, textAnchor6, (float) (short) 100, (float) (-6553600), (double) (-1L));
        org.jfree.chart.axis.NumberAxis numberAxis13 = null;
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str20 = textTitle19.getText();
        java.awt.Font font21 = textTitle19.getFont();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand22 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis13, (double) 12, 300.0d, (double) 10.0f, 0.25d, font21);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D23 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean25 = stackedBarRenderer3D23.isSeriesVisibleInLegend(11);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer26 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        ganttRenderer26.setSeriesPaint((int) (byte) 100, (java.awt.Paint) color28);
        stackedBarRenderer3D23.setWallPaint((java.awt.Paint) color28);
        org.jfree.chart.block.LabelBlock labelBlock31 = new org.jfree.chart.block.LabelBlock("", font21, (java.awt.Paint) color28);
        org.jfree.chart.text.TextFragment textFragment32 = new org.jfree.chart.text.TextFragment("hi!", font21);
        textLine0.removeFragment(textFragment32);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(color28);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        levelRenderer0.setMaximumItemWidth((double) '4');
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState4 = null;
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str9 = textTitle8.getText();
        java.awt.Font font10 = textTitle8.getFont();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str14 = textTitle13.getText();
        java.awt.geom.Rectangle2D rectangle2D15 = textTitle13.getBounds();
        textTitle8.draw(graphics2D11, rectangle2D15);
        java.awt.geom.Point2D point2D17 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) (byte) 10, (double) (-1L), rectangle2D15);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = categoryPlot18.getRangeMarkers(3, layer20);
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot18.setRangeGridlinePaint((java.awt.Paint) color22);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer27 = null;
        java.util.Collection collection28 = categoryPlot25.getRangeMarkers(3, layer27);
        java.util.List list29 = categoryPlot25.getAnnotations();
        java.awt.Paint paint30 = categoryPlot25.getOutlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double34 = dateAxis33.getFixedDimension();
        boolean boolean35 = dateAxis33.isAutoTickUnitSelection();
        categoryPlot25.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis) dateAxis33, true);
        dateAxis33.setRangeAboutValue((double) (short) 10, (double) 86400000L);
        double double41 = dateAxis33.getFixedDimension();
        java.lang.Number[] numberArray48 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray58 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[][] numberArray59 = new java.lang.Number[][] { numberArray48, numberArray53, numberArray58 };
        org.jfree.data.category.CategoryDataset categoryDataset60 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray59);
        java.lang.Number number61 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset60);
        org.jfree.data.Range range63 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset60, false);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot64 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset60);
        org.jfree.data.Range range65 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset60);
        try {
            levelRenderer0.drawItem(graphics2D3, categoryItemRendererState4, rectangle2D15, categoryPlot18, categoryAxis24, (org.jfree.chart.axis.ValueAxis) dateAxis33, categoryDataset60, 8, (int) (short) 100, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 3");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(point2D17);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNull(collection28);
        org.junit.Assert.assertNotNull(list29);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(numberArray48);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray58);
        org.junit.Assert.assertNotNull(numberArray59);
        org.junit.Assert.assertNotNull(categoryDataset60);
        org.junit.Assert.assertTrue("'" + number61 + "' != '" + 300.0d + "'", number61.equals(300.0d));
        org.junit.Assert.assertNotNull(range63);
        org.junit.Assert.assertNotNull(range65);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        java.awt.Paint paint1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint1, stroke2);
        java.awt.Paint paint4 = valueMarker3.getLabelPaint();
        java.lang.Object obj5 = valueMarker3.clone();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        int int7 = color6.getBlue();
        valueMarker3.setOutlinePaint((java.awt.Paint) color6);
        try {
            valueMarker3.setAlpha((float) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 128 + "'", int7 == 128);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        java.lang.String[] strArray0 = new java.lang.String[] {};
        java.lang.Number[][] numberArray1 = new java.lang.Number[][] {};
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset3 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray0, numberArray1, numberArray2);
        java.lang.String[] strArray4 = new java.lang.String[] {};
        java.lang.Number[][] numberArray5 = new java.lang.Number[][] {};
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] {};
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset7 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray4, numberArray5, numberArray6);
        try {
            defaultIntervalCategoryDataset3.setCategoryKeys((java.lang.Comparable[]) strArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(numberArray1);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double6 = dateAxis5.getFixedDimension();
        boolean boolean7 = dateAxis5.isAxisLineVisible();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot9.setRangeCrosshairValue((double) (byte) 100, false);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot9);
        categoryPlot8.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart13);
        java.awt.Font font15 = categoryPlot8.getNoDataMessageFont();
        dateAxis5.setLabelFont(font15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = dateAxis5.getTickLabelInsets();
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str22 = textTitle21.getText();
        java.awt.Font font23 = textTitle21.getFont();
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str27 = textTitle26.getText();
        java.awt.geom.Rectangle2D rectangle2D28 = textTitle26.getBounds();
        textTitle21.draw(graphics2D24, rectangle2D28);
        java.awt.geom.Point2D point2D30 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) (byte) 10, (double) (-1L), rectangle2D28);
        java.awt.geom.Rectangle2D rectangle2D31 = rectangleInsets17.createOutsetRectangle(rectangle2D28);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        try {
            java.util.List list33 = dateAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D28, rectangleEdge32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "" + "'", str27.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNotNull(point2D30);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(rectangleEdge32);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers(3, layer2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color4);
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot0.getRangeAxisForDataset((int) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double10 = dateAxis9.getFixedDimension();
        boolean boolean11 = dateAxis9.isAxisLineVisible();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot13.setRangeCrosshairValue((double) (byte) 100, false);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot13);
        categoryPlot12.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart17);
        java.awt.Font font19 = categoryPlot12.getNoDataMessageFont();
        dateAxis9.setLabelFont(font19);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = dateAxis9.getTickLabelInsets();
        org.jfree.chart.title.TextTitle textTitle25 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str26 = textTitle25.getText();
        java.awt.Font font27 = textTitle25.getFont();
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.title.TextTitle textTitle30 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str31 = textTitle30.getText();
        java.awt.geom.Rectangle2D rectangle2D32 = textTitle30.getBounds();
        textTitle25.draw(graphics2D28, rectangle2D32);
        java.awt.geom.Point2D point2D34 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) (byte) 10, (double) (-1L), rectangle2D32);
        java.awt.geom.Rectangle2D rectangle2D35 = rectangleInsets21.createOutsetRectangle(rectangle2D32);
        boolean boolean36 = categoryPlot0.equals((java.lang.Object) rectangle2D35);
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "" + "'", str31.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(point2D34);
        org.junit.Assert.assertNotNull(rectangle2D35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setRangeCrosshairValue((double) (byte) 100, false);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot1);
        categoryPlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart5);
        org.jfree.chart.title.LegendTitle legendTitle8 = jFreeChart5.getLegend((int) '#');
        java.awt.RenderingHints renderingHints9 = null;
        try {
            jFreeChart5.setRenderingHints(renderingHints9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: RenderingHints given are null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(legendTitle8);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        boolean boolean2 = ganttRenderer0.equals((java.lang.Object) '#');
        double double3 = ganttRenderer0.getItemLabelAnchorOffset();
        boolean boolean4 = ganttRenderer0.getBaseItemLabelsVisible();
        java.awt.Paint paint6 = ganttRenderer0.lookupSeriesFillPaint(4);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        try {
            java.lang.Object obj1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) "");
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((-6553600), 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("ClassContext");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer2 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Object obj3 = null;
        boolean boolean4 = boxAndWhiskerRenderer2.equals(obj3);
        java.awt.Paint paint6 = null;
        boxAndWhiskerRenderer2.setSeriesPaint((int) (short) 100, paint6, true);
        java.awt.Paint paint11 = boxAndWhiskerRenderer2.getItemFillPaint(10, 0);
        boolean boolean12 = datasetGroup1.equals((java.lang.Object) 10);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset1, valueAxis2, polarItemRenderer3);
        polarPlot4.removeCornerTextItem("");
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = polarPlot4.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation7);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge8);
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(plotOrientation7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(rectangleEdge9);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        java.awt.Font font1 = null;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset2, valueAxis3, polarItemRenderer4);
        polarPlot5.removeCornerTextItem("");
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str10 = textTitle9.getText();
        java.awt.Font font11 = textTitle9.getFont();
        polarPlot5.setAngleLabelFont(font11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) polarPlot5, true);
        java.awt.image.BufferedImage bufferedImage17 = jFreeChart14.createBufferedImage((int) '#', 1);
        java.awt.Paint paint18 = jFreeChart14.getBorderPaint();
        jFreeChart14.removeLegend();
        boolean boolean20 = jFreeChart14.getAntiAlias();
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(bufferedImage17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.chart.axis.NumberAxis numberAxis2 = null;
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str9 = textTitle8.getText();
        java.awt.Font font10 = textTitle8.getFont();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand11 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis2, (double) 12, 300.0d, (double) 10.0f, 0.25d, font10);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D12 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean14 = stackedBarRenderer3D12.isSeriesVisibleInLegend(11);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer15 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        ganttRenderer15.setSeriesPaint((int) (byte) 100, (java.awt.Paint) color17);
        stackedBarRenderer3D12.setWallPaint((java.awt.Paint) color17);
        org.jfree.chart.block.LabelBlock labelBlock20 = new org.jfree.chart.block.LabelBlock("", font10, (java.awt.Paint) color17);
        org.jfree.chart.text.TextFragment textFragment21 = new org.jfree.chart.text.TextFragment("hi!", font10);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.text.TextAnchor textAnchor25 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        try {
            textFragment21.draw(graphics2D22, (float) 0L, (float) (short) 1, textAnchor25, (float) 10L, (float) (-1), 49.5d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(textAnchor25);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.POSITIVE;
        org.junit.Assert.assertNotNull(rangeType0);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        java.text.DateFormat dateFormat4 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = new org.jfree.chart.axis.DateTickUnit(0, 12, 1, (int) (short) 1, dateFormat4);
        int int6 = dateTickUnit5.getUnit();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        double double0 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_Y_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 8.0d + "'", double0 == 8.0d);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean2 = lineAndShapeRenderer0.equals((java.lang.Object) 12);
        java.lang.Boolean boolean4 = lineAndShapeRenderer0.getSeriesShapesVisible((-1));
        boolean boolean7 = lineAndShapeRenderer0.getItemLineVisible(2958465, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double2 = dateAxis1.getFixedDimension();
        java.util.Date date3 = dateAxis1.getMaximumDate();
        dateAxis1.setAutoRangeMinimumSize(3.0d);
        dateAxis1.setTickMarksVisible(false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ganttRenderer0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = legendTitle1.getLegendItemGraphicLocation();
        java.awt.Paint paint3 = legendTitle1.getBackgroundPaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = legendTitle1.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        legendTitle1.setLegendItemGraphicEdge(rectangleEdge5);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer7 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ganttRenderer7);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = legendTitle8.getLegendItemGraphicLocation();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 'a');
        boolean boolean13 = rectangleAnchor9.equals((java.lang.Object) simpleTimePeriod12);
        legendTitle1.setLegendItemGraphicAnchor(rectangleAnchor9);
        org.jfree.chart.axis.TickUnitSource tickUnitSource15 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        boolean boolean16 = rectangleAnchor9.equals((java.lang.Object) tickUnitSource15);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(tickUnitSource15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double2 = dateAxis1.getFixedDimension();
        java.util.Date date3 = dateAxis1.getMinimumDate();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate4);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        int int3 = java.awt.Color.HSBtoRGB((float) (short) 100, (float) 1, (float) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-3407872) + "'", int3 == (-3407872));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("hi!");
        java.lang.String str2 = unknownKeyException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.UnknownKeyException: hi!" + "'", str2.equals("org.jfree.data.UnknownKeyException: hi!"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[][] numberArray17 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16 };
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray17);
        java.lang.Number number19 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset18);
        org.jfree.data.Range range21 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset18, false);
        org.jfree.data.Range range23 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset18, true);
        org.jfree.data.KeyToGroupMap keyToGroupMap24 = new org.jfree.data.KeyToGroupMap();
        org.jfree.data.Range range25 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset18, keyToGroupMap24);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(categoryDataset18);
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 300.0d + "'", number19.equals(300.0d));
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNotNull(range25);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        org.jfree.chart.ui.Library[] libraryArray1 = basicProjectInfo0.getLibraries();
        org.junit.Assert.assertNotNull(libraryArray1);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image1 = projectInfo0.getLogo();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(image1);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.MINUTE_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 60000L + "'", long0 == 60000L);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str7 = textTitle6.getText();
        java.awt.geom.Rectangle2D rectangle2D8 = textTitle6.getBounds();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D8, (double) (short) 10, 100.0f, (float) (short) -1);
        java.awt.Color color14 = java.awt.Color.white;
        java.awt.Color color16 = java.awt.Color.white;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str21 = textTitle20.getText();
        java.awt.geom.Rectangle2D rectangle2D22 = textTitle20.getBounds();
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D22, (double) (short) 10, 100.0f, (float) (short) -1);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D27 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean29 = stackedBarRenderer3D27.isSeriesVisibleInLegend(11);
        java.awt.Stroke stroke30 = stackedBarRenderer3D27.getBaseStroke();
        java.awt.Color color31 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.LegendItem legendItem32 = new org.jfree.chart.LegendItem("hi!", "java.awt.Color[r=128,g=128,b=255]", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]", "RectangleEdge.TOP", true, (java.awt.Shape) rectangle2D8, true, (java.awt.Paint) color14, false, (java.awt.Paint) color16, stroke17, true, (java.awt.Shape) rectangle2D22, stroke30, (java.awt.Paint) color31);
        int int33 = color16.getRGB();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ganttRenderer0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = legendTitle1.getLegendItemGraphicLocation();
        java.awt.Paint paint3 = legendTitle1.getBackgroundPaint();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double7 = rectangleInsets5.calculateBottomOutset(0.4d);
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str12 = textTitle11.getText();
        java.awt.Font font13 = textTitle11.getFont();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str17 = textTitle16.getText();
        java.awt.geom.Rectangle2D rectangle2D18 = textTitle16.getBounds();
        textTitle11.draw(graphics2D14, rectangle2D18);
        java.awt.geom.Point2D point2D20 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) (byte) 10, (double) (-1L), rectangle2D18);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType21 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType22 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.awt.geom.Rectangle2D rectangle2D23 = rectangleInsets5.createAdjustedRectangle(rectangle2D18, lengthAdjustmentType21, lengthAdjustmentType22);
        try {
            legendTitle1.draw(graphics2D4, rectangle2D18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.0d + "'", double7 == 3.0d);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(point2D20);
        org.junit.Assert.assertNotNull(lengthAdjustmentType21);
        org.junit.Assert.assertNotNull(lengthAdjustmentType22);
        org.junit.Assert.assertNotNull(rectangle2D23);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemLineVisible((int) (short) -1, 8);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        try {
            lineAndShapeRenderer0.setPlot(categoryPlot4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ganttRenderer0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = legendTitle1.getLegendItemGraphicLocation();
        java.awt.Paint paint3 = legendTitle1.getBackgroundPaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = legendTitle1.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        legendTitle1.setLegendItemGraphicEdge(rectangleEdge5);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        legendTitle1.setLegendItemGraphicAnchor(rectangleAnchor7);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers(3, layer6);
        java.util.List list8 = categoryPlot4.getAnnotations();
        categoryPlot4.clearRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer12 = null;
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot(xYDataset10, valueAxis11, polarItemRenderer12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        polarPlot13.setRadiusGridlineStroke(stroke14);
        categoryPlot4.setDomainGridlineStroke(stroke14);
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0.5f, (java.awt.Paint) color1, stroke2, (java.awt.Paint) color3, stroke14, (float) (short) 0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ganttRenderer0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = legendTitle1.getLegendItemGraphicLocation();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod5 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 'a');
        boolean boolean6 = rectangleAnchor2.equals((java.lang.Object) simpleTimePeriod5);
        java.util.Date date7 = simpleTimePeriod5.getStart();
        java.util.Date date8 = null;
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod(date7, date8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        try {
            java.lang.Number number2 = defaultKeyedValues0.getValue((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.entity.EntityCollection entityCollection0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo(entityCollection0);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean4 = stackedBarRenderer3D2.equals((java.lang.Object) (short) 10);
        stackedBarRenderer3D2.setSeriesVisibleInLegend((int) (byte) 100, (java.lang.Boolean) true);
        boolean boolean10 = stackedBarRenderer3D2.isItemLabelVisible(3, 0);
        double double11 = stackedBarRenderer3D2.getMinimumBarLength();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot14.setRangeCrosshairValue((double) (byte) 100, false);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot14);
        categoryPlot13.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart18);
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double22 = dateAxis21.getFixedDimension();
        java.util.Date date23 = dateAxis21.getMinimumDate();
        org.jfree.chart.entity.EntityCollection entityCollection28 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo29 = new org.jfree.chart.ChartRenderingInfo(entityCollection28);
        org.jfree.chart.title.TextTitle textTitle31 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str32 = textTitle31.getText();
        java.awt.geom.Rectangle2D rectangle2D33 = textTitle31.getBounds();
        chartRenderingInfo29.setChartArea(rectangle2D33);
        java.awt.Color color35 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem36 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]", "({0}, {1}) = {2}", "", "", (java.awt.Shape) rectangle2D33, (java.awt.Paint) color35);
        stackedBarRenderer3D2.drawRangeGridline(graphics2D12, categoryPlot13, (org.jfree.chart.axis.ValueAxis) dateAxis21, rectangle2D33, 300.0d);
        chartRenderingInfo1.setChartArea(rectangle2D33);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D40 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Stroke stroke41 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        stackedBarRenderer3D40.setBaseStroke(stroke41, false);
        boolean boolean44 = chartRenderingInfo1.equals((java.lang.Object) stroke41);
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer45 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Object obj46 = null;
        boolean boolean47 = boxAndWhiskerRenderer45.equals(obj46);
        java.awt.Paint paint49 = boxAndWhiskerRenderer45.getSeriesItemLabelPaint((int) (byte) 10);
        boolean boolean50 = chartRenderingInfo1.equals((java.lang.Object) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "" + "'", str32.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNull(paint49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("hi!2");
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        double double1 = levelRenderer0.getMaximumItemWidth();
        double double2 = levelRenderer0.getItemMargin();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor4 = itemLabelPosition3.getTextAnchor();
        levelRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition3, false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double2 = dateAxis1.getFixedDimension();
        java.util.Date date3 = dateAxis1.getMaximumDate();
        dateAxis1.setAutoRangeMinimumSize(3.0d);
        java.text.DateFormat dateFormat6 = dateAxis1.getDateFormatOverride();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(dateFormat6);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.Paint paint5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint5, stroke6);
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker7.setLabelTextAnchor(textAnchor8);
        try {
            java.awt.geom.Rectangle2D rectangle2D10 = org.jfree.chart.text.TextUtilities.drawAlignedString("", graphics2D1, (float) 100L, (float) 2958465, textAnchor8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(textAnchor8);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.chart.block.Arrangement arrangement0 = null;
        try {
            org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer(arrangement0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers(3, layer2);
        java.util.List list4 = categoryPlot0.getAnnotations();
        categoryPlot0.clearRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer8 = null;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot(xYDataset6, valueAxis7, polarItemRenderer8);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        polarPlot9.setRadiusGridlineStroke(stroke10);
        categoryPlot0.setDomainGridlineStroke(stroke10);
        java.awt.Image image13 = categoryPlot0.getBackgroundImage();
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNull(image13);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_STARTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ganttRenderer0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = legendTitle1.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = legendTitle1.getLegendItemGraphicLocation();
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        java.awt.Paint paint6 = legendTitle1.getBackgroundPaint();
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNull(paint6);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double7 = dateAxis6.getFixedDimension();
        boolean boolean8 = dateAxis6.isAxisLineVisible();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.setRangeCrosshairValue((double) (byte) 100, false);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot10);
        categoryPlot9.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart14);
        java.awt.Font font16 = categoryPlot9.getNoDataMessageFont();
        dateAxis6.setLabelFont(font16);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand18 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis) numberAxis3D0, (double) (short) 0, (double) ' ', 300.0d, (double) (short) 100, font16);
        java.text.NumberFormat numberFormat19 = numberAxis3D0.getNumberFormatOverride();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNull(numberFormat19);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod3 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 'a');
        org.jfree.data.gantt.Task task4 = new org.jfree.data.gantt.Task("java.awt.Color[r=128,g=128,b=255]", (org.jfree.data.time.TimePeriod) simpleTimePeriod3);
        try {
            org.jfree.data.gantt.Task task6 = task4.getSubtask(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getText();
        java.awt.Font font3 = textTitle1.getFont();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str7 = textTitle6.getText();
        java.awt.geom.Rectangle2D rectangle2D8 = textTitle6.getBounds();
        textTitle1.draw(graphics2D4, rectangle2D8);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.util.RectangleEdge.LEFT;
        textTitle1.setPosition(rectangleEdge10);
        textTitle1.setText("");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNotNull(rectangleEdge10);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        java.awt.Paint paint2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint2, stroke3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        int int6 = color5.getBlue();
        valueMarker4.setLabelPaint((java.awt.Paint) color5);
        java.awt.image.ColorModel colorModel8 = null;
        java.awt.Rectangle rectangle9 = null;
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str12 = textTitle11.getText();
        java.awt.geom.Rectangle2D rectangle2D13 = textTitle11.getBounds();
        java.awt.geom.AffineTransform affineTransform14 = null;
        java.awt.RenderingHints renderingHints15 = null;
        java.awt.PaintContext paintContext16 = color5.createContext(colorModel8, rectangle9, rectangle2D13, affineTransform14, renderingHints15);
        try {
            boolean boolean17 = org.jfree.chart.util.ShapeUtilities.contains(rectangle2D0, (java.awt.geom.Rectangle2D) rectangle9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 128 + "'", int6 == 128);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(paintContext16);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        try {
            java.lang.Number number3 = defaultBoxAndWhiskerCategoryDataset0.getMinOutlier((int) (short) 100, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.cursorRight((double) 10);
        axisState0.cursorUp((double) (byte) 10);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        java.awt.Font font1 = null;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset2, valueAxis3, polarItemRenderer4);
        polarPlot5.removeCornerTextItem("");
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str10 = textTitle9.getText();
        java.awt.Font font11 = textTitle9.getFont();
        polarPlot5.setAngleLabelFont(font11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) polarPlot5, true);
        org.jfree.chart.plot.PlotOrientation plotOrientation15 = polarPlot5.getOrientation();
        java.lang.String str16 = plotOrientation15.toString();
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(plotOrientation15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str16.equals("PlotOrientation.HORIZONTAL"));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.resources.DataPackageResources dataPackageResources0 = new org.jfree.data.resources.DataPackageResources();
        java.util.Enumeration<java.lang.String> strEnumeration1 = dataPackageResources0.getKeys();
        try {
            java.lang.String[] strArray3 = dataPackageResources0.getStringArray("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.data.resources.DataPackageResources, key RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(strEnumeration1);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        polarPlot3.removeCornerTextItem("");
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = categoryPlot6.getRangeMarkers(3, layer8);
        java.util.List list10 = categoryPlot6.getAnnotations();
        java.awt.Paint paint11 = categoryPlot6.getOutlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double15 = dateAxis14.getFixedDimension();
        boolean boolean16 = dateAxis14.isAutoTickUnitSelection();
        categoryPlot6.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis) dateAxis14, true);
        org.jfree.data.Range range19 = dateAxis14.getDefaultAutoRange();
        org.jfree.data.Range range20 = dateAxis14.getRange();
        org.jfree.data.Range range21 = polarPlot3.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis14);
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertNull(range21);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) paintArray0);
        java.lang.String str2 = chartChangeEvent1.toString();
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        java.util.Date date5 = spreadsheetDate4.toDate();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addMonths(4, (org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addDays(128, serialDate6);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(3, serialDate7);
        try {
            org.jfree.data.time.SerialDate serialDate10 = serialDate7.getPreviousDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        java.awt.Paint paint1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint1, stroke2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        int int5 = color4.getBlue();
        valueMarker3.setLabelPaint((java.awt.Paint) color4);
        java.awt.image.ColorModel colorModel7 = null;
        java.awt.Rectangle rectangle8 = null;
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str11 = textTitle10.getText();
        java.awt.geom.Rectangle2D rectangle2D12 = textTitle10.getBounds();
        java.awt.geom.AffineTransform affineTransform13 = null;
        java.awt.RenderingHints renderingHints14 = null;
        java.awt.PaintContext paintContext15 = color4.createContext(colorModel7, rectangle8, rectangle2D12, affineTransform13, renderingHints14);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity16 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D12);
        java.lang.Object obj17 = legendItemEntity16.clone();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 128 + "'", int5 == 128);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNotNull(paintContext15);
        org.junit.Assert.assertNotNull(obj17);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = month0.getMiddleMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        boolean boolean1 = ganttRenderer0.getAutoPopulateSeriesStroke();
        boolean boolean2 = ganttRenderer0.getBaseItemLabelsVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean2 = stackedBarRenderer3D0.isSeriesVisibleInLegend(11);
        java.awt.Stroke stroke3 = stackedBarRenderer3D0.getBaseStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot4.setRangeCrosshairValue((double) (byte) 100, false);
        stackedBarRenderer3D0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot4);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getRangeMarkers(3, layer11);
        java.util.List list13 = categoryPlot9.getAnnotations();
        categoryPlot9.clearRangeAxes();
        boolean boolean15 = categoryPlot4.equals((java.lang.Object) categoryPlot9);
        java.awt.Paint paint16 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_WALL_PAINT;
        categoryPlot4.setBackgroundPaint(paint16);
        java.io.ObjectOutputStream objectOutputStream18 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePaint(paint16, objectOutputStream18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double7 = dateAxis6.getFixedDimension();
        boolean boolean8 = dateAxis6.isAxisLineVisible();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.setRangeCrosshairValue((double) (byte) 100, false);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot10);
        categoryPlot9.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart14);
        java.awt.Font font16 = categoryPlot9.getNoDataMessageFont();
        dateAxis6.setLabelFont(font16);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand18 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis) numberAxis3D0, (double) (short) 0, (double) ' ', 300.0d, (double) (short) 100, font16);
        java.awt.Graphics2D graphics2D19 = null;
        double double20 = markerAxisBand18.getHeight(graphics2D19);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("ChartEntity: tooltip = ClassContext", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        java.util.List list1 = defaultKeyedValues0.getKeys();
        try {
            java.lang.Number number3 = defaultKeyedValues0.getValue((java.lang.Comparable) 11);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Key not found: 11");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        int int0 = org.jfree.chart.axis.DateTickUnit.HOUR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        java.util.Date date4 = spreadsheetDate3.toDate();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths(4, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addYears((int) '4', (org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        java.util.Date date10 = spreadsheetDate9.toDate();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addMonths(4, (org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean12 = spreadsheetDate3.isBefore(serialDate11);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        java.lang.String str0 = org.jfree.chart.labels.StandardCategorySeriesLabelGenerator.DEFAULT_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double2 = dateAxis1.getFixedDimension();
        java.util.Date date3 = dateAxis1.getMinimumDate();
        dateAxis1.setAutoRangeMinimumSize(49.5d, false);
        float float7 = dateAxis1.getTickMarkInsideLength();
        dateAxis1.centerRange(0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        java.awt.Paint paint1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint1, stroke2);
        java.awt.Paint paint4 = valueMarker3.getLabelPaint();
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        valueMarker3.setLabelTextAnchor(textAnchor5);
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("");
        java.awt.Paint paint9 = null;
        textTitle8.setBackgroundPaint(paint9);
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment13 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textTitle12.setTextAlignment(horizontalAlignment13);
        textTitle8.setTextAlignment(horizontalAlignment13);
        boolean boolean16 = textAnchor5.equals((java.lang.Object) textTitle8);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertNotNull(horizontalAlignment13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setRangeCrosshairValue((double) (byte) 100, false);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot1);
        categoryPlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart5);
        org.jfree.chart.title.LegendTitle legendTitle8 = jFreeChart5.getLegend((int) '#');
        boolean boolean9 = jFreeChart5.getAntiAlias();
        java.lang.Object obj10 = jFreeChart5.clone();
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer11 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ganttRenderer11);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = legendTitle12.getLegendItemGraphicLocation();
        jFreeChart5.addLegend(legendTitle12);
        org.junit.Assert.assertNull(legendTitle8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        java.lang.String[] strArray0 = new java.lang.String[] {};
        java.lang.Number[][] numberArray1 = new java.lang.Number[][] {};
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset3 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray0, numberArray1, numberArray2);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset4, valueAxis5, polarItemRenderer6);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        polarPlot7.setRadiusGridlineStroke(stroke8);
        boolean boolean10 = defaultIntervalCategoryDataset3.hasListener((java.util.EventListener) polarPlot7);
        int int11 = defaultIntervalCategoryDataset3.getCategoryCount();
        try {
            java.lang.Object obj12 = defaultIntervalCategoryDataset3.clone();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(numberArray1);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) (-1), (double) (-1.0f));
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4);
        java.awt.Paint[] paintArray6 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) paintArray6);
        java.lang.Object obj8 = chartChangeEvent7.getSource();
        boolean boolean9 = blockContainer5.equals(obj8);
        org.junit.Assert.assertNotNull(paintArray6);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        java.lang.String str0 = org.jfree.chart.labels.IntervalCategoryToolTipGenerator.DEFAULT_TOOL_TIP_FORMAT_STRING;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "({0}, {1}) = {3} - {4}" + "'", str0.equals("({0}, {1}) = {3} - {4}"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ganttRenderer0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = legendTitle1.getLegendItemGraphicLocation();
        java.awt.Paint paint3 = legendTitle1.getBackgroundPaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = legendTitle1.getLegendItemGraphicLocation();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str8 = textTitle7.getText();
        java.awt.Font font9 = textTitle7.getFont();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str13 = textTitle12.getText();
        java.awt.geom.Rectangle2D rectangle2D14 = textTitle12.getBounds();
        textTitle7.draw(graphics2D10, rectangle2D14);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer16 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ganttRenderer16);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = legendTitle17.getLegendItemGraphicLocation();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 'a');
        boolean boolean22 = rectangleAnchor18.equals((java.lang.Object) simpleTimePeriod21);
        java.awt.Shape shape25 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape) rectangle2D14, rectangleAnchor18, 4.0d, (double) 100L);
        try {
            legendTitle1.draw(graphics2D5, rectangle2D14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(rectangleAnchor18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(shape25);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod3 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 'a');
        org.jfree.data.gantt.Task task4 = new org.jfree.data.gantt.Task("java.awt.Color[r=128,g=128,b=255]", (org.jfree.data.time.TimePeriod) simpleTimePeriod3);
        int int5 = task4.getSubtaskCount();
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer6 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ganttRenderer6);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = legendTitle7.getLegendItemGraphicLocation();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 'a');
        boolean boolean12 = rectangleAnchor8.equals((java.lang.Object) simpleTimePeriod11);
        task4.setDuration((org.jfree.data.time.TimePeriod) simpleTimePeriod11);
        task4.setDescription("hi!");
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str19 = textTitle18.getText();
        java.awt.geom.Rectangle2D rectangle2D20 = textTitle18.getBounds();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean24 = lineAndShapeRenderer21.getItemLineVisible((int) (short) -1, 8);
        boolean boolean25 = textTitle18.equals((java.lang.Object) lineAndShapeRenderer21);
        org.jfree.data.KeyedObject keyedObject26 = new org.jfree.data.KeyedObject((java.lang.Comparable) 10L, (java.lang.Object) boolean25);
        boolean boolean27 = task4.equals((java.lang.Object) 10L);
        java.lang.String str28 = task4.getDescription();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "hi!" + "'", str28.equals("hi!"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[][] numberArray17 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16 };
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray17);
        java.lang.Number number19 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset18);
        org.jfree.data.Range range21 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset18, false);
        org.jfree.data.Range range22 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset18);
        org.jfree.data.Range range24 = org.jfree.data.Range.expandToInclude(range22, 300.0d);
        double double25 = range22.getUpperBound();
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(categoryDataset18);
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 300.0d + "'", number19.equals(300.0d));
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 300.0d + "'", double25 == 300.0d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("ChartEntity: tooltip = ClassContext");
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit(8.0d, numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.ASCENDING;
        org.junit.Assert.assertNotNull(sortOrder0);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.data.resources.DataPackageResources dataPackageResources0 = new org.jfree.data.resources.DataPackageResources();
        boolean boolean2 = dataPackageResources0.containsKey("RectangleEdge.TOP");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((-3407872));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D1, (float) (short) 1, (float) 2958465, 0.0d, (float) (short) 0, 0.0f);
        org.junit.Assert.assertNull(shape7);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        try {
            java.lang.Number number4 = defaultKeyedValues2D1.getValue((int) (short) 10, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setRangeCrosshairValue((double) (byte) 100, false);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot1);
        categoryPlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart5);
        org.jfree.chart.event.ChartChangeListener chartChangeListener7 = null;
        try {
            jFreeChart5.removeChangeListener(chartChangeListener7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setRangeCrosshairValue((double) (byte) 100, false);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot1);
        categoryPlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart5);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot0.setDomainAxis(categoryAxis7);
        org.jfree.chart.axis.NumberAxis numberAxis10 = null;
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str17 = textTitle16.getText();
        java.awt.Font font18 = textTitle16.getFont();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand19 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis10, (double) 12, 300.0d, (double) 10.0f, 0.25d, font18);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D20 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean22 = stackedBarRenderer3D20.isSeriesVisibleInLegend(11);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer23 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        ganttRenderer23.setSeriesPaint((int) (byte) 100, (java.awt.Paint) color25);
        stackedBarRenderer3D20.setWallPaint((java.awt.Paint) color25);
        org.jfree.chart.block.LabelBlock labelBlock28 = new org.jfree.chart.block.LabelBlock("", font18, (java.awt.Paint) color25);
        java.awt.Paint paint29 = labelBlock28.getPaint();
        categoryPlot0.setRangeCrosshairPaint(paint29);
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer31 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Object obj32 = null;
        boolean boolean33 = boxAndWhiskerRenderer31.equals(obj32);
        java.awt.Paint paint35 = null;
        boxAndWhiskerRenderer31.setSeriesPaint((int) (short) 100, paint35, true);
        boxAndWhiskerRenderer31.setFillBox(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent40 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) boxAndWhiskerRenderer31);
        categoryPlot0.rendererChanged(rendererChangeEvent40);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
        org.jfree.chart.LegendItem legendItem3 = stackedBarRenderer0.getLegendItem(8, 15);
        org.junit.Assert.assertNull(legendItem3);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.axis.NumberAxis numberAxis0 = null;
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str7 = textTitle6.getText();
        java.awt.Font font8 = textTitle6.getFont();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand9 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis0, (double) 12, 300.0d, (double) 10.0f, 0.25d, font8);
        org.jfree.chart.plot.IntervalMarker intervalMarker10 = null;
        markerAxisBand9.addMarker(intervalMarker10);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(font8);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getText();
        textTitle1.setMargin((double) 100.0f, (double) 11, (double) 0, 0.0d);
        java.lang.Object obj8 = textTitle1.clone();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        textTitle1.setPaint((java.awt.Paint) color9);
        java.awt.Graphics2D graphics2D11 = null;
        try {
            org.jfree.chart.util.Size2D size2D12 = textTitle1.arrange(graphics2D11);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.data.KeyToGroupMap keyToGroupMap0 = new org.jfree.data.KeyToGroupMap();
        java.util.List list1 = keyToGroupMap0.getGroups();
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setAxisLineVisible(true);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.chart.entity.EntityCollection entityCollection4 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = new org.jfree.chart.ChartRenderingInfo(entityCollection4);
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str8 = textTitle7.getText();
        java.awt.geom.Rectangle2D rectangle2D9 = textTitle7.getBounds();
        chartRenderingInfo5.setChartArea(rectangle2D9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem12 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]", "({0}, {1}) = {2}", "", "", (java.awt.Shape) rectangle2D9, (java.awt.Paint) color11);
        org.jfree.data.general.Dataset dataset13 = legendItem12.getDataset();
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer16 = null;
        org.jfree.chart.plot.PolarPlot polarPlot17 = new org.jfree.chart.plot.PolarPlot(xYDataset14, valueAxis15, polarItemRenderer16);
        polarPlot17.removeCornerTextItem("");
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str22 = textTitle21.getText();
        java.awt.Font font23 = textTitle21.getFont();
        polarPlot17.setAngleLabelFont(font23);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D25 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean27 = stackedBarRenderer3D25.isSeriesVisibleInLegend(11);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer28 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        ganttRenderer28.setSeriesPaint((int) (byte) 100, (java.awt.Paint) color30);
        stackedBarRenderer3D25.setWallPaint((java.awt.Paint) color30);
        polarPlot17.setNoDataMessagePaint((java.awt.Paint) color30);
        boolean boolean34 = legendItem12.equals((java.lang.Object) polarPlot17);
        boolean boolean35 = polarPlot17.isRangeZoomable();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(dataset13);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 10L);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity4 = new org.jfree.chart.entity.TickLabelEntity(shape1, "AxisLocation.TOP_OR_LEFT", "AxisLocation.TOP_OR_LEFT");
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator5 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator6 = null;
        try {
            java.lang.String str7 = tickLabelEntity4.getImageMapAreaTag(toolTipTagFragmentGenerator5, uRLTagFragmentGenerator6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ganttRenderer0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = legendTitle1.getLegendItemGraphicLocation();
        java.awt.Paint paint3 = legendTitle1.getBackgroundPaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = legendTitle1.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        legendTitle1.setLegendItemGraphicEdge(rectangleEdge5);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer7 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ganttRenderer7);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = legendTitle8.getLegendItemGraphicLocation();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 'a');
        boolean boolean13 = rectangleAnchor9.equals((java.lang.Object) simpleTimePeriod12);
        legendTitle1.setLegendItemGraphicAnchor(rectangleAnchor9);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer15 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ganttRenderer15);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = legendTitle16.getLegendItemGraphicLocation();
        java.awt.Paint paint18 = legendTitle16.getBackgroundPaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = legendTitle16.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        legendTitle16.setLegendItemGraphicEdge(rectangleEdge20);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer22 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.title.LegendTitle legendTitle23 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ganttRenderer22);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = legendTitle23.getLegendItemGraphicLocation();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 'a');
        boolean boolean28 = rectangleAnchor24.equals((java.lang.Object) simpleTimePeriod27);
        legendTitle16.setLegendItemGraphicAnchor(rectangleAnchor24);
        legendTitle1.setLegendItemGraphicAnchor(rectangleAnchor24);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean2 = stackedBarRenderer3D0.equals((java.lang.Object) (short) 10);
        stackedBarRenderer3D0.setSeriesVisibleInLegend((int) (byte) 100, (java.lang.Boolean) true);
        boolean boolean8 = stackedBarRenderer3D0.isItemLabelVisible(3, 0);
        double double9 = stackedBarRenderer3D0.getMinimumBarLength();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.setRangeCrosshairValue((double) (byte) 100, false);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot12);
        categoryPlot11.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart16);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double20 = dateAxis19.getFixedDimension();
        java.util.Date date21 = dateAxis19.getMinimumDate();
        org.jfree.chart.entity.EntityCollection entityCollection26 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo27 = new org.jfree.chart.ChartRenderingInfo(entityCollection26);
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str30 = textTitle29.getText();
        java.awt.geom.Rectangle2D rectangle2D31 = textTitle29.getBounds();
        chartRenderingInfo27.setChartArea(rectangle2D31);
        java.awt.Color color33 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem34 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]", "({0}, {1}) = {2}", "", "", (java.awt.Shape) rectangle2D31, (java.awt.Paint) color33);
        stackedBarRenderer3D0.drawRangeGridline(graphics2D10, categoryPlot11, (org.jfree.chart.axis.ValueAxis) dateAxis19, rectangle2D31, 300.0d);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent37 = null;
        categoryPlot11.datasetChanged(datasetChangeEvent37);
        org.jfree.chart.axis.AxisSpace axisSpace39 = categoryPlot11.getFixedRangeAxisSpace();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "" + "'", str30.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNull(axisSpace39);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean2 = stackedBarRenderer3D0.isSeriesVisibleInLegend(11);
        java.awt.Stroke stroke3 = stackedBarRenderer3D0.getBaseStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot4.setRangeCrosshairValue((double) (byte) 100, false);
        stackedBarRenderer3D0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot4);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getRangeMarkers(3, layer11);
        java.util.List list13 = categoryPlot9.getAnnotations();
        categoryPlot9.clearRangeAxes();
        boolean boolean15 = categoryPlot4.equals((java.lang.Object) categoryPlot9);
        org.jfree.chart.axis.AxisSpace axisSpace16 = new org.jfree.chart.axis.AxisSpace();
        categoryPlot4.setFixedDomainAxisSpace(axisSpace16);
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str20 = textTitle19.getText();
        java.awt.geom.Rectangle2D rectangle2D21 = textTitle19.getBounds();
        java.awt.Shape shape25 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D21, (double) (short) 10, 100.0f, (float) (short) -1);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double28 = rectangleInsets26.calculateBottomOutset(0.4d);
        org.jfree.chart.title.TextTitle textTitle32 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str33 = textTitle32.getText();
        java.awt.Font font34 = textTitle32.getFont();
        java.awt.Graphics2D graphics2D35 = null;
        org.jfree.chart.title.TextTitle textTitle37 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str38 = textTitle37.getText();
        java.awt.geom.Rectangle2D rectangle2D39 = textTitle37.getBounds();
        textTitle32.draw(graphics2D35, rectangle2D39);
        java.awt.geom.Point2D point2D41 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) (byte) 10, (double) (-1L), rectangle2D39);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType42 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType43 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.awt.geom.Rectangle2D rectangle2D44 = rectangleInsets26.createAdjustedRectangle(rectangle2D39, lengthAdjustmentType42, lengthAdjustmentType43);
        java.awt.geom.Rectangle2D rectangle2D45 = axisSpace16.shrink(rectangle2D21, rectangle2D44);
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot47.setRangeCrosshairValue((double) (byte) 100, false);
        org.jfree.chart.JFreeChart jFreeChart51 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot47);
        categoryPlot46.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart51);
        org.jfree.chart.axis.CategoryAxis categoryAxis53 = null;
        categoryPlot46.setDomainAxis(categoryAxis53);
        categoryPlot46.clearRangeMarkers((int) '4');
        boolean boolean57 = axisSpace16.equals((java.lang.Object) categoryPlot46);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 3.0d + "'", double28 == 3.0d);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "" + "'", str33.equals(""));
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "" + "'", str38.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertNotNull(point2D41);
        org.junit.Assert.assertNotNull(lengthAdjustmentType42);
        org.junit.Assert.assertNotNull(lengthAdjustmentType43);
        org.junit.Assert.assertNotNull(rectangle2D44);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str3 = textTitle2.getText();
        java.awt.geom.Rectangle2D rectangle2D4 = textTitle2.getBounds();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean8 = lineAndShapeRenderer5.getItemLineVisible((int) (short) -1, 8);
        boolean boolean9 = textTitle2.equals((java.lang.Object) lineAndShapeRenderer5);
        org.jfree.chart.block.LineBorder lineBorder10 = new org.jfree.chart.block.LineBorder();
        textTitle2.setFrame((org.jfree.chart.block.BlockFrame) lineBorder10);
        blockContainer0.setFrame((org.jfree.chart.block.BlockFrame) lineBorder10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        boolean boolean2 = ganttRenderer0.equals((java.lang.Object) '#');
        ganttRenderer0.setSeriesVisibleInLegend(1, (java.lang.Boolean) false, false);
        java.awt.Stroke stroke8 = ganttRenderer0.getSeriesStroke(0);
        double double9 = ganttRenderer0.getUpperClip();
        java.awt.Stroke stroke11 = ganttRenderer0.getSeriesOutlineStroke(4);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(stroke8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNull(stroke11);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.color.ColorSpace colorSpace1 = null;
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        float[] floatArray11 = new float[] { 4, (short) 1, (-1.0f), 128, 7 };
        float[] floatArray12 = color5.getColorComponents(floatArray11);
        float[] floatArray13 = java.awt.Color.RGBtoHSB((int) (short) 10, (int) '#', 0, floatArray12);
        try {
            float[] floatArray14 = color0.getComponents(colorSpace1, floatArray13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getYearValue();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double2 = dateAxis1.getFixedDimension();
        boolean boolean3 = dateAxis1.isAxisLineVisible();
        dateAxis1.setTickMarksVisible(false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairValue((double) (byte) 100, false);
        categoryPlot0.setAnchorValue((double) 1);
        boolean boolean6 = categoryPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot0.getRangeAxis(15);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(valueAxis8);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean2 = stackedBarRenderer3D0.isSeriesVisibleInLegend(11);
        java.awt.Stroke stroke3 = stackedBarRenderer3D0.getBaseStroke();
        double double4 = stackedBarRenderer3D0.getLowerClip();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.setRangeCrosshairValue((double) (byte) 100, false);
        boolean boolean10 = categoryPlot5.equals((java.lang.Object) (-1));
        boolean boolean11 = stackedBarRenderer3D0.equals((java.lang.Object) (-1));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        double double1 = levelRenderer0.getMaximumItemWidth();
        double double2 = levelRenderer0.getItemMargin();
        double double3 = levelRenderer0.getMaximumItemWidth();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.axis.NumberAxis numberAxis2 = null;
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str9 = textTitle8.getText();
        java.awt.Font font10 = textTitle8.getFont();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand11 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis2, (double) 12, 300.0d, (double) 10.0f, 0.25d, font10);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D12 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean14 = stackedBarRenderer3D12.isSeriesVisibleInLegend(11);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer15 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        ganttRenderer15.setSeriesPaint((int) (byte) 100, (java.awt.Paint) color17);
        stackedBarRenderer3D12.setWallPaint((java.awt.Paint) color17);
        org.jfree.chart.block.LabelBlock labelBlock20 = new org.jfree.chart.block.LabelBlock("", font10, (java.awt.Paint) color17);
        org.jfree.chart.text.TextFragment textFragment21 = new org.jfree.chart.text.TextFragment("hi!", font10);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        try {
            float float24 = textFragment21.calculateBaselineOffset(graphics2D22, textAnchor23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(textAnchor23);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo1 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo0.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo1);
        java.lang.String str3 = basicProjectInfo0.getInfo();
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ganttRenderer0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = legendTitle1.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = legendTitle1.getLegendItemGraphicLocation();
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_RED;
        legendTitle1.setBackgroundPaint((java.awt.Paint) color6);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot8.getRangeMarkers(3, layer10);
        boolean boolean12 = legendTitle1.equals((java.lang.Object) 3);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairValue((double) (byte) 100, false);
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("");
        java.awt.Paint paint7 = null;
        textTitle6.setBackgroundPaint(paint7);
        jFreeChart4.addSubtitle((org.jfree.chart.title.Title) textTitle6);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) (short) 1, 0, 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Blue");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        int int0 = org.jfree.data.time.SerialDate.THURSDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str3 = textTitle2.getText();
        java.awt.Font font4 = textTitle2.getFont();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str8 = textTitle7.getText();
        java.awt.geom.Rectangle2D rectangle2D9 = textTitle7.getBounds();
        textTitle2.draw(graphics2D5, rectangle2D9);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer11 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ganttRenderer11);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = legendTitle12.getLegendItemGraphicLocation();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 'a');
        boolean boolean17 = rectangleAnchor13.equals((java.lang.Object) simpleTimePeriod16);
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape) rectangle2D9, rectangleAnchor13, 4.0d, (double) 100L);
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str23 = textTitle22.getText();
        java.awt.Font font24 = textTitle22.getFont();
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.title.TextTitle textTitle27 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str28 = textTitle27.getText();
        java.awt.geom.Rectangle2D rectangle2D29 = textTitle27.getBounds();
        textTitle22.draw(graphics2D25, rectangle2D29);
        boolean boolean31 = org.jfree.chart.util.ShapeUtilities.contains(rectangle2D9, rectangle2D29);
        java.awt.geom.Rectangle2D rectangle2D32 = rectangleInsets0.createOutsetRectangle(rectangle2D29);
        double double34 = rectangleInsets0.trimHeight((double) 11);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "" + "'", str28.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 5.0d + "'", double34 == 5.0d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers(3, layer2);
        java.util.List list4 = categoryPlot0.getAnnotations();
        java.awt.Paint paint5 = categoryPlot0.getOutlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double9 = dateAxis8.getFixedDimension();
        boolean boolean10 = dateAxis8.isAutoTickUnitSelection();
        categoryPlot0.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis) dateAxis8, true);
        dateAxis8.setRangeAboutValue((double) 0, (double) (short) 100);
        java.util.TimeZone timeZone16 = dateAxis8.getTimeZone();
        dateAxis8.setTickLabelsVisible(true);
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(timeZone16);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        boolean boolean2 = ganttRenderer0.equals((java.lang.Object) '#');
        ganttRenderer0.setSeriesVisibleInLegend(1, (java.lang.Boolean) false, false);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer7 = ganttRenderer0.getGradientPaintTransformer();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment8 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment9 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement12 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment8, verticalAlignment9, (double) (-1), (double) (-1.0f));
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment13 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment14 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement17 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment13, verticalAlignment14, (double) (-1), (double) (-1.0f));
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ganttRenderer0, (org.jfree.chart.block.Arrangement) columnArrangement12, (org.jfree.chart.block.Arrangement) columnArrangement17);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        java.util.Date date23 = spreadsheetDate22.toDate();
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addMonths(4, (org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addYears((int) '4', (org.jfree.data.time.SerialDate) spreadsheetDate22);
        boolean boolean26 = columnArrangement17.equals((java.lang.Object) spreadsheetDate22);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(gradientPaintTransformer7);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator0 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer1 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Object obj2 = null;
        boolean boolean3 = boxAndWhiskerRenderer1.equals(obj2);
        java.awt.Paint paint5 = null;
        boxAndWhiskerRenderer1.setSeriesPaint((int) (short) 100, paint5, true);
        boxAndWhiskerRenderer1.setFillBox(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) boxAndWhiskerRenderer1);
        boolean boolean11 = standardCategorySeriesLabelGenerator0.equals((java.lang.Object) boxAndWhiskerRenderer1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.THREAD_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.renderer.category.LayeredBarRenderer layeredBarRenderer0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState2 = null;
        java.awt.Paint paint4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint4, stroke5);
        java.awt.Paint paint7 = valueMarker6.getLabelPaint();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        int int9 = color8.getTransparency();
        valueMarker6.setLabelPaint((java.awt.Paint) color8);
        java.awt.image.ColorModel colorModel11 = null;
        java.awt.Rectangle rectangle12 = null;
        java.awt.Font font14 = null;
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer17 = null;
        org.jfree.chart.plot.PolarPlot polarPlot18 = new org.jfree.chart.plot.PolarPlot(xYDataset15, valueAxis16, polarItemRenderer17);
        polarPlot18.removeCornerTextItem("");
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str23 = textTitle22.getText();
        java.awt.Font font24 = textTitle22.getFont();
        polarPlot18.setAngleLabelFont(font24);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("", font14, (org.jfree.chart.plot.Plot) polarPlot18, true);
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.title.TextTitle textTitle30 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str31 = textTitle30.getText();
        java.awt.Font font32 = textTitle30.getFont();
        java.awt.Graphics2D graphics2D33 = null;
        org.jfree.chart.title.TextTitle textTitle35 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str36 = textTitle35.getText();
        java.awt.geom.Rectangle2D rectangle2D37 = textTitle35.getBounds();
        textTitle30.draw(graphics2D33, rectangle2D37);
        java.awt.geom.Point2D point2D39 = null;
        org.jfree.chart.plot.PlotState plotState40 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = null;
        polarPlot18.draw(graphics2D28, rectangle2D37, point2D39, plotState40, plotRenderingInfo41);
        java.awt.geom.AffineTransform affineTransform43 = null;
        java.awt.RenderingHints renderingHints44 = null;
        java.awt.PaintContext paintContext45 = color8.createContext(colorModel11, rectangle12, rectangle2D37, affineTransform43, renderingHints44);
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot46.setRangeCrosshairValue((double) (byte) 100, false);
        boolean boolean51 = categoryPlot46.equals((java.lang.Object) (-1));
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer55 = null;
        java.util.Collection collection56 = categoryPlot53.getRangeMarkers(3, layer55);
        java.util.List list57 = categoryPlot53.getAnnotations();
        java.awt.Paint paint58 = categoryPlot53.getOutlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis61 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double62 = dateAxis61.getFixedDimension();
        boolean boolean63 = dateAxis61.isAutoTickUnitSelection();
        categoryPlot53.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis) dateAxis61, true);
        boolean boolean66 = dateAxis61.isVerticalTickLabels();
        double double67 = dateAxis61.getLowerMargin();
        dateAxis61.setTickMarkInsideLength((float) 10);
        org.jfree.data.category.CategoryDataset categoryDataset70 = null;
        try {
            layeredBarRenderer0.drawItem(graphics2D1, categoryItemRendererState2, (java.awt.geom.Rectangle2D) rectangle12, categoryPlot46, categoryAxis52, (org.jfree.chart.axis.ValueAxis) dateAxis61, categoryDataset70, 11, (-3407872), (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "" + "'", str31.equals(""));
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "" + "'", str36.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertNotNull(paintContext45);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNull(collection56);
        org.junit.Assert.assertNotNull(list57);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.05d + "'", double67 == 0.05d);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        java.awt.Paint paint1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint1, stroke2);
        java.awt.Paint paint4 = valueMarker3.getLabelPaint();
        java.lang.Object obj5 = valueMarker3.clone();
        java.awt.Paint paint6 = valueMarker3.getOutlinePaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj1 = defaultDrawingSupplier0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ganttRenderer0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = legendTitle1.getLegendItemGraphicLocation();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod5 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 'a');
        boolean boolean6 = rectangleAnchor2.equals((java.lang.Object) simpleTimePeriod5);
        java.util.Date date7 = simpleTimePeriod5.getStart();
        java.lang.Object obj8 = null;
        try {
            int int9 = simpleTimePeriod5.compareTo(obj8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        java.lang.String[] strArray0 = new java.lang.String[] {};
        java.lang.Number[][] numberArray1 = new java.lang.Number[][] {};
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset3 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray0, numberArray1, numberArray2);
        org.jfree.data.general.DatasetGroup datasetGroup5 = new org.jfree.data.general.DatasetGroup("hi!");
        defaultIntervalCategoryDataset3.setGroup(datasetGroup5);
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str9 = textTitle8.getText();
        java.awt.Font font10 = textTitle8.getFont();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str14 = textTitle13.getText();
        java.awt.geom.Rectangle2D rectangle2D15 = textTitle13.getBounds();
        textTitle8.draw(graphics2D11, rectangle2D15);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer17 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ganttRenderer17);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = legendTitle18.getLegendItemGraphicLocation();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 'a');
        boolean boolean23 = rectangleAnchor19.equals((java.lang.Object) simpleTimePeriod22);
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape) rectangle2D15, rectangleAnchor19, 4.0d, (double) 100L);
        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str29 = textTitle28.getText();
        java.awt.Font font30 = textTitle28.getFont();
        java.awt.Graphics2D graphics2D31 = null;
        org.jfree.chart.title.TextTitle textTitle33 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str34 = textTitle33.getText();
        java.awt.geom.Rectangle2D rectangle2D35 = textTitle33.getBounds();
        textTitle28.draw(graphics2D31, rectangle2D35);
        boolean boolean37 = org.jfree.chart.util.ShapeUtilities.contains(rectangle2D15, rectangle2D35);
        boolean boolean38 = datasetGroup5.equals((java.lang.Object) rectangle2D35);
        java.lang.Object obj39 = datasetGroup5.clone();
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(numberArray1);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "" + "'", str34.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(obj39);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.chart.entity.EntityCollection entityCollection4 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = new org.jfree.chart.ChartRenderingInfo(entityCollection4);
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str8 = textTitle7.getText();
        java.awt.geom.Rectangle2D rectangle2D9 = textTitle7.getBounds();
        chartRenderingInfo5.setChartArea(rectangle2D9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem12 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]", "({0}, {1}) = {2}", "", "", (java.awt.Shape) rectangle2D9, (java.awt.Paint) color11);
        org.jfree.data.general.Dataset dataset13 = legendItem12.getDataset();
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer16 = null;
        org.jfree.chart.plot.PolarPlot polarPlot17 = new org.jfree.chart.plot.PolarPlot(xYDataset14, valueAxis15, polarItemRenderer16);
        polarPlot17.removeCornerTextItem("");
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str22 = textTitle21.getText();
        java.awt.Font font23 = textTitle21.getFont();
        polarPlot17.setAngleLabelFont(font23);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D25 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean27 = stackedBarRenderer3D25.isSeriesVisibleInLegend(11);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer28 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        ganttRenderer28.setSeriesPaint((int) (byte) 100, (java.awt.Paint) color30);
        stackedBarRenderer3D25.setWallPaint((java.awt.Paint) color30);
        polarPlot17.setNoDataMessagePaint((java.awt.Paint) color30);
        boolean boolean34 = legendItem12.equals((java.lang.Object) polarPlot17);
        boolean boolean35 = polarPlot17.isRadiusGridlinesVisible();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(dataset13);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke1 = defaultDrawingSupplier0.getNextStroke();
        java.awt.Paint paint2 = defaultDrawingSupplier0.getNextPaint();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((double) 100, (double) 0.0f);
        java.lang.Number number3 = meanAndStandardDeviation2.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0.0d + "'", number3.equals(0.0d));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        boolean boolean2 = ganttRenderer0.equals((java.lang.Object) '#');
        double double3 = ganttRenderer0.getItemLabelAnchorOffset();
        boolean boolean4 = ganttRenderer0.getBaseItemLabelsVisible();
        java.awt.Paint paint6 = ganttRenderer0.getSeriesOutlinePaint((int) 'a');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(paint6);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setCircular(false);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator4 = null;
        piePlot3D1.setToolTipGenerator(pieToolTipGenerator4);
        try {
            double double6 = piePlot3D1.getMaximumExplodePercent();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str4 = textTitle3.getText();
        java.awt.Font font5 = textTitle3.getFont();
        java.awt.Font font7 = null;
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot(xYDataset8, valueAxis9, polarItemRenderer10);
        polarPlot11.removeCornerTextItem("");
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str16 = textTitle15.getText();
        java.awt.Font font17 = textTitle15.getFont();
        polarPlot11.setAngleLabelFont(font17);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("", font7, (org.jfree.chart.plot.Plot) polarPlot11, true);
        java.lang.Object obj21 = jFreeChart20.getTextAntiAlias();
        textTitle3.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart20);
        java.awt.Color color23 = org.jfree.chart.ChartColor.DARK_RED;
        jFreeChart20.setBorderPaint((java.awt.Paint) color23);
        boxAndWhiskerRenderer0.setSeriesFillPaint(10, (java.awt.Paint) color23, false);
        java.awt.Paint paint28 = boxAndWhiskerRenderer0.getSeriesFillPaint(8);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNull(obj21);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNull(paint28);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        boolean boolean2 = ganttRenderer0.equals((java.lang.Object) '#');
        ganttRenderer0.setSeriesVisibleInLegend(1, (java.lang.Boolean) false, false);
        java.awt.Stroke stroke8 = ganttRenderer0.getSeriesStroke(0);
        java.lang.Boolean boolean10 = ganttRenderer0.getSeriesCreateEntities((int) '#');
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer13 = null;
        java.util.Collection collection14 = categoryPlot11.getRangeMarkers(3, layer13);
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot11.setRangeGridlinePaint((java.awt.Paint) color15);
        org.jfree.chart.axis.ValueAxis valueAxis18 = categoryPlot11.getRangeAxisForDataset((int) (short) -1);
        java.awt.Paint paint20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint20, stroke21);
        categoryPlot11.setRangeCrosshairStroke(stroke21);
        boolean boolean24 = ganttRenderer0.hasListener((java.util.EventListener) categoryPlot11);
        double double25 = categoryPlot11.getAnchorValue();
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = categoryPlot11.getDomainAxis(7);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(stroke8);
        org.junit.Assert.assertNull(boolean10);
        org.junit.Assert.assertNull(collection14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(valueAxis18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNull(categoryAxis27);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.lang.Boolean boolean2 = lineRenderer3D0.getSeriesShapesFilled((int) ' ');
        org.junit.Assert.assertNull(boolean2);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        java.awt.Color color0 = java.awt.Color.RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        java.awt.Paint paint0 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers(3, layer2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color4);
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot0.getRangeAxisForDataset((int) (short) -1);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = categoryPlot0.getDomainMarkers(layer8);
        org.jfree.chart.axis.AxisLocation axisLocation11 = categoryPlot0.getRangeAxisLocation(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        try {
            categoryPlot0.setDomainAxis((-1), categoryAxis13, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNotNull(axisLocation11);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        double double1 = axisSpace0.getBottom();
        double double2 = axisSpace0.getLeft();
        java.lang.String str3 = axisSpace0.toString();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        java.util.Date date5 = spreadsheetDate4.toDate();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addMonths(4, (org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addDays(128, serialDate6);
        try {
            org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addDays((-6553600), serialDate7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Object obj1 = null;
        boolean boolean2 = boxAndWhiskerRenderer0.equals(obj1);
        java.awt.Paint paint4 = boxAndWhiskerRenderer0.getSeriesItemLabelPaint((int) (byte) 10);
        boolean boolean5 = boxAndWhiskerRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        boolean boolean2 = ganttRenderer0.equals((java.lang.Object) '#');
        double double3 = ganttRenderer0.getItemLabelAnchorOffset();
        double double4 = ganttRenderer0.getStartPercent();
        java.awt.Paint paint6 = ganttRenderer0.lookupSeriesPaint(100);
        java.awt.Paint paint8 = ganttRenderer0.lookupSeriesFillPaint(2958465);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.35d + "'", double4 == 0.35d);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.entity.EntityCollection entityCollection4 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = new org.jfree.chart.ChartRenderingInfo(entityCollection4);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D6 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean8 = stackedBarRenderer3D6.equals((java.lang.Object) (short) 10);
        stackedBarRenderer3D6.setSeriesVisibleInLegend((int) (byte) 100, (java.lang.Boolean) true);
        boolean boolean14 = stackedBarRenderer3D6.isItemLabelVisible(3, 0);
        double double15 = stackedBarRenderer3D6.getMinimumBarLength();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot18.setRangeCrosshairValue((double) (byte) 100, false);
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot18);
        categoryPlot17.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart22);
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double26 = dateAxis25.getFixedDimension();
        java.util.Date date27 = dateAxis25.getMinimumDate();
        org.jfree.chart.entity.EntityCollection entityCollection32 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo33 = new org.jfree.chart.ChartRenderingInfo(entityCollection32);
        org.jfree.chart.title.TextTitle textTitle35 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str36 = textTitle35.getText();
        java.awt.geom.Rectangle2D rectangle2D37 = textTitle35.getBounds();
        chartRenderingInfo33.setChartArea(rectangle2D37);
        java.awt.Color color39 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem40 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]", "({0}, {1}) = {2}", "", "", (java.awt.Shape) rectangle2D37, (java.awt.Paint) color39);
        stackedBarRenderer3D6.drawRangeGridline(graphics2D16, categoryPlot17, (org.jfree.chart.axis.ValueAxis) dateAxis25, rectangle2D37, 300.0d);
        chartRenderingInfo5.setChartArea(rectangle2D37);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer44 = new org.jfree.chart.renderer.category.GanttRenderer();
        boolean boolean46 = ganttRenderer44.equals((java.lang.Object) '#');
        ganttRenderer44.setSeriesVisibleInLegend(1, (java.lang.Boolean) false, false);
        java.awt.Shape shape52 = ganttRenderer44.getSeriesShape(5);
        ganttRenderer44.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator55 = ganttRenderer44.getLegendItemToolTipGenerator();
        java.awt.Paint paint56 = ganttRenderer44.getBasePaint();
        try {
            org.jfree.chart.LegendItem legendItem57 = new org.jfree.chart.LegendItem(attributedString0, "java.awt.Color[r=128,g=128,b=255]", "hi!2", "({0}, {1}) = {3} - {4}", (java.awt.Shape) rectangle2D37, paint56);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "" + "'", str36.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNull(shape52);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator55);
        org.junit.Assert.assertNotNull(paint56);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        boolean boolean2 = ganttRenderer0.equals((java.lang.Object) '#');
        ganttRenderer0.setSeriesVisibleInLegend(1, (java.lang.Boolean) false, false);
        java.awt.Shape shape8 = ganttRenderer0.getSeriesShape(5);
        ganttRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        ganttRenderer0.setAutoPopulateSeriesStroke(true);
        java.awt.Paint paint14 = ganttRenderer0.getSeriesFillPaint((int) (short) 10);
        ganttRenderer0.setBaseSeriesVisibleInLegend(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(shape8);
        org.junit.Assert.assertNull(paint14);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        polarPlot3.removeCornerTextItem("");
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str8 = textTitle7.getText();
        java.awt.Font font9 = textTitle7.getFont();
        polarPlot3.setAngleLabelFont(font9);
        org.jfree.chart.plot.PlotOrientation plotOrientation11 = polarPlot3.getOrientation();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        polarPlot3.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis12);
        dateAxis12.setAutoTickUnitSelection(false, false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(plotOrientation11);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.trimHeight((double) 1.0f);
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D(pieDataset3);
        boolean boolean5 = rectangleInsets0.equals((java.lang.Object) pieDataset3);
        double double6 = rectangleInsets0.getTop();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double2 = dateAxis1.getFixedDimension();
        java.util.Date date3 = dateAxis1.getMaximumDate();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = dateAxis1.getLabelInsets();
        java.awt.Paint paint6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint6, stroke7);
        java.awt.Paint paint9 = valueMarker8.getLabelPaint();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        int int11 = color10.getTransparency();
        valueMarker8.setLabelPaint((java.awt.Paint) color10);
        java.awt.image.ColorModel colorModel13 = null;
        java.awt.Rectangle rectangle14 = null;
        java.awt.Font font16 = null;
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot(xYDataset17, valueAxis18, polarItemRenderer19);
        polarPlot20.removeCornerTextItem("");
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str25 = textTitle24.getText();
        java.awt.Font font26 = textTitle24.getFont();
        polarPlot20.setAngleLabelFont(font26);
        org.jfree.chart.JFreeChart jFreeChart29 = new org.jfree.chart.JFreeChart("", font16, (org.jfree.chart.plot.Plot) polarPlot20, true);
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.title.TextTitle textTitle32 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str33 = textTitle32.getText();
        java.awt.Font font34 = textTitle32.getFont();
        java.awt.Graphics2D graphics2D35 = null;
        org.jfree.chart.title.TextTitle textTitle37 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str38 = textTitle37.getText();
        java.awt.geom.Rectangle2D rectangle2D39 = textTitle37.getBounds();
        textTitle32.draw(graphics2D35, rectangle2D39);
        java.awt.geom.Point2D point2D41 = null;
        org.jfree.chart.plot.PlotState plotState42 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = null;
        polarPlot20.draw(graphics2D30, rectangle2D39, point2D41, plotState42, plotRenderingInfo43);
        java.awt.geom.AffineTransform affineTransform45 = null;
        java.awt.RenderingHints renderingHints46 = null;
        java.awt.PaintContext paintContext47 = color10.createContext(colorModel13, rectangle14, rectangle2D39, affineTransform45, renderingHints46);
        try {
            java.awt.geom.Rectangle2D rectangle2D50 = rectangleInsets4.createOutsetRectangle((java.awt.geom.Rectangle2D) rectangle14, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "" + "'", str33.equals(""));
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "" + "'", str38.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertNotNull(paintContext47);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        boolean boolean2 = ganttRenderer0.equals((java.lang.Object) '#');
        double double3 = ganttRenderer0.getItemLabelAnchorOffset();
        java.lang.Boolean boolean5 = ganttRenderer0.getSeriesItemLabelsVisible((int) ' ');
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer7 = new org.jfree.chart.renderer.category.GanttRenderer();
        boolean boolean9 = ganttRenderer7.equals((java.lang.Object) '#');
        ganttRenderer7.setSeriesVisibleInLegend(1, (java.lang.Boolean) false, false);
        java.awt.Stroke stroke15 = ganttRenderer7.getSeriesStroke(0);
        boolean boolean16 = itemLabelPosition6.equals((java.lang.Object) ganttRenderer7);
        double double17 = itemLabelPosition6.getAngle();
        double double18 = itemLabelPosition6.getAngle();
        ganttRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition6);
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str27 = textTitle26.getText();
        java.awt.geom.Rectangle2D rectangle2D28 = textTitle26.getBounds();
        java.awt.Shape shape32 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D28, (double) (short) 10, 100.0f, (float) (short) -1);
        java.awt.Color color34 = java.awt.Color.white;
        java.awt.Color color36 = java.awt.Color.white;
        java.awt.Stroke stroke37 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.title.TextTitle textTitle40 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str41 = textTitle40.getText();
        java.awt.geom.Rectangle2D rectangle2D42 = textTitle40.getBounds();
        java.awt.Shape shape46 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D42, (double) (short) 10, 100.0f, (float) (short) -1);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D47 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean49 = stackedBarRenderer3D47.isSeriesVisibleInLegend(11);
        java.awt.Stroke stroke50 = stackedBarRenderer3D47.getBaseStroke();
        java.awt.Color color51 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.LegendItem legendItem52 = new org.jfree.chart.LegendItem("hi!", "java.awt.Color[r=128,g=128,b=255]", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]", "RectangleEdge.TOP", true, (java.awt.Shape) rectangle2D28, true, (java.awt.Paint) color34, false, (java.awt.Paint) color36, stroke37, true, (java.awt.Shape) rectangle2D42, stroke50, (java.awt.Paint) color51);
        ganttRenderer0.setBaseOutlineStroke(stroke37);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "" + "'", str27.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "" + "'", str41.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D42);
        org.junit.Assert.assertNotNull(shape46);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(color51);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double2 = dateAxis1.getFixedDimension();
        boolean boolean3 = dateAxis1.isAxisLineVisible();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.setRangeCrosshairValue((double) (byte) 100, false);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot5);
        categoryPlot4.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart9);
        java.awt.Font font11 = categoryPlot4.getNoDataMessageFont();
        dateAxis1.setLabelFont(font11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = dateAxis1.getTickLabelInsets();
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str18 = textTitle17.getText();
        java.awt.Font font19 = textTitle17.getFont();
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str23 = textTitle22.getText();
        java.awt.geom.Rectangle2D rectangle2D24 = textTitle22.getBounds();
        textTitle17.draw(graphics2D20, rectangle2D24);
        java.awt.geom.Point2D point2D26 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) (byte) 10, (double) (-1L), rectangle2D24);
        java.awt.geom.Rectangle2D rectangle2D27 = rectangleInsets13.createOutsetRectangle(rectangle2D24);
        org.jfree.chart.entity.EntityCollection entityCollection28 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo29 = new org.jfree.chart.ChartRenderingInfo(entityCollection28);
        org.jfree.chart.title.TextTitle textTitle31 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str32 = textTitle31.getText();
        java.awt.geom.Rectangle2D rectangle2D33 = textTitle31.getBounds();
        chartRenderingInfo29.setChartArea(rectangle2D33);
        java.awt.geom.Rectangle2D rectangle2D37 = rectangleInsets13.createOutsetRectangle(rectangle2D33, false, true);
        org.jfree.chart.axis.NumberAxis numberAxis39 = null;
        org.jfree.chart.title.TextTitle textTitle45 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str46 = textTitle45.getText();
        java.awt.Font font47 = textTitle45.getFont();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand48 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis39, (double) 12, 300.0d, (double) 10.0f, 0.25d, font47);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D49 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean51 = stackedBarRenderer3D49.isSeriesVisibleInLegend(11);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer52 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Color color54 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        ganttRenderer52.setSeriesPaint((int) (byte) 100, (java.awt.Paint) color54);
        stackedBarRenderer3D49.setWallPaint((java.awt.Paint) color54);
        org.jfree.chart.block.LabelBlock labelBlock57 = new org.jfree.chart.block.LabelBlock("", font47, (java.awt.Paint) color54);
        org.jfree.chart.util.RectangleInsets rectangleInsets58 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double60 = rectangleInsets58.calculateBottomOutset(0.4d);
        org.jfree.chart.title.TextTitle textTitle64 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str65 = textTitle64.getText();
        java.awt.Font font66 = textTitle64.getFont();
        java.awt.Graphics2D graphics2D67 = null;
        org.jfree.chart.title.TextTitle textTitle69 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str70 = textTitle69.getText();
        java.awt.geom.Rectangle2D rectangle2D71 = textTitle69.getBounds();
        textTitle64.draw(graphics2D67, rectangle2D71);
        java.awt.geom.Point2D point2D73 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) (byte) 10, (double) (-1L), rectangle2D71);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType74 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType75 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.awt.geom.Rectangle2D rectangle2D76 = rectangleInsets58.createAdjustedRectangle(rectangle2D71, lengthAdjustmentType74, lengthAdjustmentType75);
        labelBlock57.setBounds(rectangle2D76);
        boolean boolean78 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D37, rectangle2D76);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertNotNull(point2D26);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "" + "'", str32.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "" + "'", str46.equals(""));
        org.junit.Assert.assertNotNull(font47);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(rectangleInsets58);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 3.0d + "'", double60 == 3.0d);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "" + "'", str65.equals(""));
        org.junit.Assert.assertNotNull(font66);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "" + "'", str70.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D71);
        org.junit.Assert.assertNotNull(point2D73);
        org.junit.Assert.assertNotNull(lengthAdjustmentType74);
        org.junit.Assert.assertNotNull(lengthAdjustmentType75);
        org.junit.Assert.assertNotNull(rectangle2D76);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod3 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 'a');
        org.jfree.data.gantt.Task task4 = new org.jfree.data.gantt.Task("java.awt.Color[r=128,g=128,b=255]", (org.jfree.data.time.TimePeriod) simpleTimePeriod3);
        task4.setDescription("org.jfree.data.UnknownKeyException: hi!");
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        boolean boolean2 = ganttRenderer0.equals((java.lang.Object) '#');
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer4 = new org.jfree.chart.renderer.category.GanttRenderer();
        boolean boolean6 = ganttRenderer4.equals((java.lang.Object) '#');
        ganttRenderer4.setSeriesVisibleInLegend(1, (java.lang.Boolean) false, false);
        java.awt.Stroke stroke12 = ganttRenderer4.getSeriesStroke(0);
        boolean boolean13 = itemLabelPosition3.equals((java.lang.Object) ganttRenderer4);
        double double14 = itemLabelPosition3.getAngle();
        ganttRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition3, false);
        ganttRenderer0.setItemLabelAnchorOffset((double) 0.5f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit0 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer1 = new org.jfree.chart.renderer.category.GanttRenderer();
        boolean boolean3 = ganttRenderer1.equals((java.lang.Object) '#');
        ganttRenderer1.setSeriesVisibleInLegend(1, (java.lang.Boolean) false, false);
        java.awt.Stroke stroke9 = ganttRenderer1.getSeriesStroke(0);
        java.lang.Boolean boolean11 = ganttRenderer1.getSeriesCreateEntities((int) '#');
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = categoryPlot12.getRangeMarkers(3, layer14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot12.setRangeGridlinePaint((java.awt.Paint) color16);
        org.jfree.chart.axis.ValueAxis valueAxis19 = categoryPlot12.getRangeAxisForDataset((int) (short) -1);
        java.awt.Paint paint21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint21, stroke22);
        categoryPlot12.setRangeCrosshairStroke(stroke22);
        boolean boolean25 = ganttRenderer1.hasListener((java.util.EventListener) categoryPlot12);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent26 = null;
        categoryPlot12.datasetChanged(datasetChangeEvent26);
        java.awt.Paint paint29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke30 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker31 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint29, stroke30);
        java.awt.Paint paint32 = valueMarker31.getLabelPaint();
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        int int34 = color33.getTransparency();
        valueMarker31.setLabelPaint((java.awt.Paint) color33);
        valueMarker31.setAlpha(0.0f);
        double double38 = valueMarker31.getValue();
        boolean boolean39 = categoryPlot12.equals((java.lang.Object) valueMarker31);
        boolean boolean40 = numberTickUnit0.equals((java.lang.Object) valueMarker31);
        org.junit.Assert.assertNotNull(numberTickUnit0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(stroke9);
        org.junit.Assert.assertNull(boolean11);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(valueAxis19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + (-1.0d) + "'", double38 == (-1.0d));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers(3, layer2);
        java.util.List list4 = categoryPlot0.getAnnotations();
        java.awt.Paint paint5 = categoryPlot0.getOutlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double9 = dateAxis8.getFixedDimension();
        boolean boolean10 = dateAxis8.isAutoTickUnitSelection();
        categoryPlot0.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis) dateAxis8, true);
        boolean boolean13 = dateAxis8.isVerticalTickLabels();
        double double14 = dateAxis8.getLowerMargin();
        dateAxis8.setLowerBound(100.0d);
        java.awt.Paint paint17 = dateAxis8.getTickLabelPaint();
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean2 = stackedBarRenderer3D0.equals((java.lang.Object) (short) 10);
        stackedBarRenderer3D0.setSeriesVisibleInLegend((int) (byte) 100, (java.lang.Boolean) true);
        boolean boolean8 = stackedBarRenderer3D0.isItemLabelVisible(3, 0);
        double double9 = stackedBarRenderer3D0.getMinimumBarLength();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.setRangeCrosshairValue((double) (byte) 100, false);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot12);
        categoryPlot11.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart16);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double20 = dateAxis19.getFixedDimension();
        java.util.Date date21 = dateAxis19.getMinimumDate();
        org.jfree.chart.entity.EntityCollection entityCollection26 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo27 = new org.jfree.chart.ChartRenderingInfo(entityCollection26);
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str30 = textTitle29.getText();
        java.awt.geom.Rectangle2D rectangle2D31 = textTitle29.getBounds();
        chartRenderingInfo27.setChartArea(rectangle2D31);
        java.awt.Color color33 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem34 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]", "({0}, {1}) = {2}", "", "", (java.awt.Shape) rectangle2D31, (java.awt.Paint) color33);
        stackedBarRenderer3D0.drawRangeGridline(graphics2D10, categoryPlot11, (org.jfree.chart.axis.ValueAxis) dateAxis19, rectangle2D31, 300.0d);
        java.awt.Paint paint38 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke39 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker40 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint38, stroke39);
        java.awt.Color color41 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        int int42 = color41.getBlue();
        valueMarker40.setLabelPaint((java.awt.Paint) color41);
        dateAxis19.setAxisLinePaint((java.awt.Paint) color41);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent45 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis19);
        java.awt.Shape shape46 = dateAxis19.getUpArrow();
        java.io.ObjectOutputStream objectOutputStream47 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeShape(shape46, objectOutputStream47);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "" + "'", str30.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 128 + "'", int42 == 128);
        org.junit.Assert.assertNotNull(shape46);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        java.awt.Color color0 = java.awt.Color.BLACK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setRangeCrosshairValue((double) (byte) 100, false);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot1);
        categoryPlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart5);
        org.jfree.chart.title.LegendTitle legendTitle8 = jFreeChart5.getLegend((int) '#');
        org.jfree.chart.title.LegendTitle legendTitle9 = jFreeChart5.getLegend();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent10 = null;
        try {
            jFreeChart5.titleChanged(titleChangeEvent10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(legendTitle8);
        org.junit.Assert.assertNotNull(legendTitle9);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.axis.NumberAxis numberAxis1 = null;
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str8 = textTitle7.getText();
        java.awt.Font font9 = textTitle7.getFont();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand10 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis1, (double) 12, 300.0d, (double) 10.0f, 0.25d, font9);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean13 = stackedBarRenderer3D11.isSeriesVisibleInLegend(11);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer14 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        ganttRenderer14.setSeriesPaint((int) (byte) 100, (java.awt.Paint) color16);
        stackedBarRenderer3D11.setWallPaint((java.awt.Paint) color16);
        org.jfree.chart.block.LabelBlock labelBlock19 = new org.jfree.chart.block.LabelBlock("", font9, (java.awt.Paint) color16);
        java.lang.String str20 = labelBlock19.getURLText();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(str20);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod3 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 'a');
        org.jfree.data.gantt.Task task4 = new org.jfree.data.gantt.Task("java.awt.Color[r=128,g=128,b=255]", (org.jfree.data.time.TimePeriod) simpleTimePeriod3);
        int int5 = task4.getSubtaskCount();
        java.lang.Double double6 = task4.getPercentComplete();
        java.lang.Object obj7 = task4.clone();
        task4.setPercentComplete((double) 12);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(double6);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers(3, layer2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color4);
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot0.getRangeAxisForDataset((int) (short) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot8.getRangeMarkers(3, layer10);
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot8.setRangeGridlinePaint((java.awt.Paint) color12);
        org.jfree.chart.axis.ValueAxis valueAxis15 = categoryPlot8.getRangeAxisForDataset((int) (short) -1);
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint17, stroke18);
        categoryPlot8.setRangeCrosshairStroke(stroke18);
        categoryPlot0.setOutlineStroke(stroke18);
        java.lang.String str22 = categoryPlot0.getNoDataMessage();
        java.util.List list23 = categoryPlot0.getCategories();
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNull(list23);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers(3, layer2);
        java.util.List list4 = categoryPlot0.getAnnotations();
        java.awt.Paint paint5 = categoryPlot0.getOutlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double9 = dateAxis8.getFixedDimension();
        boolean boolean10 = dateAxis8.isAutoTickUnitSelection();
        categoryPlot0.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis) dateAxis8, true);
        org.jfree.chart.axis.DateTickUnit dateTickUnit13 = dateAxis8.getTickUnit();
        org.jfree.chart.entity.EntityCollection entityCollection14 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = new org.jfree.chart.ChartRenderingInfo(entityCollection14);
        int int16 = dateTickUnit13.compareTo((java.lang.Object) entityCollection14);
        int int17 = dateTickUnit13.getRollUnit();
        int int18 = dateTickUnit13.getCalendarField();
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(dateTickUnit13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
        stackedBarRenderer0.setRenderAsPercentages(false);
        java.awt.Paint paint3 = stackedBarRenderer0.getBaseOutlinePaint();
        int int4 = stackedBarRenderer0.getColumnCount();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers(3, layer2);
        java.util.List list4 = categoryPlot0.getAnnotations();
        categoryPlot0.clearRangeAxes();
        categoryPlot0.clearRangeAxes();
        int int7 = categoryPlot0.getWeight();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray8 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot0.setDomainAxes(categoryAxisArray8);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor10 = org.jfree.chart.axis.CategoryAnchor.START;
        categoryPlot0.setDomainGridlinePosition(categoryAnchor10);
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint13, stroke14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        int int17 = color16.getBlue();
        valueMarker15.setLabelPaint((java.awt.Paint) color16);
        java.awt.Paint paint19 = valueMarker15.getPaint();
        org.jfree.chart.util.Layer layer20 = null;
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker15, layer20);
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(categoryAxisArray8);
        org.junit.Assert.assertNotNull(categoryAnchor10);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 128 + "'", int17 == 128);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer3 = null;
        java.util.Collection collection4 = categoryPlot1.getRangeMarkers(3, layer3);
        java.util.List list5 = categoryPlot1.getAnnotations();
        java.awt.Paint paint6 = categoryPlot1.getOutlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double10 = dateAxis9.getFixedDimension();
        boolean boolean11 = dateAxis9.isAutoTickUnitSelection();
        categoryPlot1.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis) dateAxis9, true);
        org.jfree.chart.axis.DateTickUnit dateTickUnit14 = dateAxis9.getTickUnit();
        java.lang.Object obj15 = dateAxis9.clone();
        boolean boolean16 = lengthAdjustmentType0.equals((java.lang.Object) dateAxis9);
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertNull(collection4);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(dateTickUnit14);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        int int2 = month1.getMonth();
        org.jfree.data.gantt.Task task3 = new org.jfree.data.gantt.Task("", (org.jfree.data.time.TimePeriod) month1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers(3, layer2);
        java.util.List list4 = categoryPlot0.getAnnotations();
        java.awt.Paint paint5 = categoryPlot0.getOutlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double9 = dateAxis8.getFixedDimension();
        boolean boolean10 = dateAxis8.isAutoTickUnitSelection();
        categoryPlot0.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis) dateAxis8, true);
        org.jfree.chart.axis.DateTickUnit dateTickUnit13 = dateAxis8.getTickUnit();
        org.jfree.chart.entity.EntityCollection entityCollection14 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = new org.jfree.chart.ChartRenderingInfo(entityCollection14);
        int int16 = dateTickUnit13.compareTo((java.lang.Object) entityCollection14);
        int int17 = dateTickUnit13.getRollCount();
        int int18 = dateTickUnit13.getCount();
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(dateTickUnit13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Font font2 = dateAxis1.getTickLabelFont();
        org.jfree.chart.block.LabelBlock labelBlock3 = new org.jfree.chart.block.LabelBlock("hi!", font2);
        org.junit.Assert.assertNotNull(font2);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        java.util.Date date7 = spreadsheetDate6.toDate();
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addMonths(4, (org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addDays(128, serialDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        java.util.Date date13 = spreadsheetDate12.toDate();
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addMonths(4, (org.jfree.data.time.SerialDate) spreadsheetDate12);
        boolean boolean15 = spreadsheetDate2.isInRange(serialDate8, serialDate14);
        try {
            org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) 'a', (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        java.awt.Paint paint0 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str5 = textTitle4.getText();
        java.awt.Font font6 = textTitle4.getFont();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str10 = textTitle9.getText();
        java.awt.geom.Rectangle2D rectangle2D11 = textTitle9.getBounds();
        textTitle4.draw(graphics2D7, rectangle2D11);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer13 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ganttRenderer13);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = legendTitle14.getLegendItemGraphicLocation();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 'a');
        boolean boolean19 = rectangleAnchor15.equals((java.lang.Object) simpleTimePeriod18);
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape) rectangle2D11, rectangleAnchor15, 4.0d, (double) 100L);
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str25 = textTitle24.getText();
        java.awt.Font font26 = textTitle24.getFont();
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str30 = textTitle29.getText();
        java.awt.geom.Rectangle2D rectangle2D31 = textTitle29.getBounds();
        textTitle24.draw(graphics2D27, rectangle2D31);
        boolean boolean33 = org.jfree.chart.util.ShapeUtilities.contains(rectangle2D11, rectangle2D31);
        java.awt.geom.Rectangle2D rectangle2D34 = rectangleInsets2.createOutsetRectangle(rectangle2D31);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = org.jfree.chart.util.RectangleEdge.TOP;
        double double36 = numberAxis3D0.java2DToValue(30.0d, rectangle2D31, rectangleEdge35);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "" + "'", str30.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + Double.POSITIVE_INFINITY + "'", double36 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((double) (byte) 10, 0.0d);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        java.lang.String[] strArray0 = new java.lang.String[] {};
        java.lang.Number[][] numberArray1 = new java.lang.Number[][] {};
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset3 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray0, numberArray1, numberArray2);
        org.jfree.data.general.DatasetGroup datasetGroup4 = defaultIntervalCategoryDataset3.getGroup();
        try {
            java.lang.Number number7 = defaultIntervalCategoryDataset3.getStartValue((int) (byte) -1, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset.getValue(): series index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(numberArray1);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(datasetGroup4);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo1 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo0.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo1);
        java.lang.String str3 = basicProjectInfo0.getVersion();
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers(3, layer2);
        java.util.List list4 = categoryPlot0.getAnnotations();
        java.awt.Paint paint5 = categoryPlot0.getOutlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double9 = dateAxis8.getFixedDimension();
        boolean boolean10 = dateAxis8.isAutoTickUnitSelection();
        categoryPlot0.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis) dateAxis8, true);
        try {
            categoryPlot0.zoom(0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        boolean boolean1 = ganttRenderer0.getAutoPopulateSeriesStroke();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str4 = textTitle3.getText();
        java.awt.Font font5 = textTitle3.getFont();
        java.awt.Font font7 = null;
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot(xYDataset8, valueAxis9, polarItemRenderer10);
        polarPlot11.removeCornerTextItem("");
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str16 = textTitle15.getText();
        java.awt.Font font17 = textTitle15.getFont();
        polarPlot11.setAngleLabelFont(font17);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("", font7, (org.jfree.chart.plot.Plot) polarPlot11, true);
        java.lang.Object obj21 = jFreeChart20.getTextAntiAlias();
        textTitle3.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart20);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent23 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) boolean1, jFreeChart20);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNull(obj21);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        java.awt.Color color0 = java.awt.Color.GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        java.lang.String[] strArray0 = new java.lang.String[] {};
        java.lang.Number[][] numberArray1 = new java.lang.Number[][] {};
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset3 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray0, numberArray1, numberArray2);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset4, valueAxis5, polarItemRenderer6);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        polarPlot7.setRadiusGridlineStroke(stroke8);
        boolean boolean10 = defaultIntervalCategoryDataset3.hasListener((java.util.EventListener) polarPlot7);
        org.jfree.data.general.DatasetGroup datasetGroup12 = new org.jfree.data.general.DatasetGroup("ClassContext");
        defaultIntervalCategoryDataset3.setGroup(datasetGroup12);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer14 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ganttRenderer14);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = legendTitle15.getLegendItemGraphicLocation();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 'a');
        boolean boolean20 = rectangleAnchor16.equals((java.lang.Object) simpleTimePeriod19);
        try {
            int int21 = defaultIntervalCategoryDataset3.getColumnIndex((java.lang.Comparable) simpleTimePeriod19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(numberArray1);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo0.setCopyright("SerialDate.weekInMonthToString(): invalid code.");
        projectInfo0.setLicenceName("{0}");
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        double double1 = lineAndShapeRenderer0.getItemLabelAnchorOffset();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset2, valueAxis3, polarItemRenderer4);
        polarPlot5.removeCornerTextItem("");
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = polarPlot5.getOrientation();
        lineAndShapeRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot5);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer12 = null;
        java.util.Collection collection13 = categoryPlot10.getRangeMarkers(3, layer12);
        java.util.List list14 = categoryPlot10.getAnnotations();
        java.awt.Paint paint15 = categoryPlot10.getOutlinePaint();
        lineAndShapeRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot10);
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = categoryPlot10.getDomainMarkers(2, layer18);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(collection19);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        java.awt.Paint paint2 = dateAxis1.getTickLabelPaint();
        double double3 = dateAxis1.getUpperMargin();
        double double4 = dateAxis1.getAutoRangeMinimumSize();
        org.jfree.chart.event.AxisChangeListener axisChangeListener5 = null;
        dateAxis1.addChangeListener(axisChangeListener5);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer7 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ganttRenderer7);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = legendTitle8.getLegendItemGraphicLocation();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 'a');
        boolean boolean13 = rectangleAnchor9.equals((java.lang.Object) simpleTimePeriod12);
        java.util.Date date14 = simpleTimePeriod12.getStart();
        dateAxis1.setMinimumDate(date14);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 2.0d + "'", double4 == 2.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(date14);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairValue((double) (byte) 100, false);
        boolean boolean5 = categoryPlot0.equals((java.lang.Object) (-1));
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot0.zoomRangeAxes((double) 0.0f, (double) (byte) 10, plotRenderingInfo8, point2D9);
        org.jfree.data.category.CategoryDataset categoryDataset12 = categoryPlot0.getDataset(0);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = categoryPlot0.getRenderer();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(categoryDataset12);
        org.junit.Assert.assertNull(categoryItemRenderer13);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(8, 12);
        int int3 = month2.getMonth();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 8 + "'", int3 == 8);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor2 = piePlot3D1.getLabelDistributor();
        piePlot3D1.setIgnoreZeroValues(true);
        boolean boolean5 = piePlot3D1.getSectionOutlinesVisible();
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        defaultKeyedValues2D1.setValue((java.lang.Number) 3.0d, (java.lang.Comparable) 100L, (java.lang.Comparable) (byte) 100);
        try {
            defaultKeyedValues2D1.removeColumn((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairValue((double) (byte) 100, false);
        org.jfree.chart.axis.AxisSpace axisSpace4 = categoryPlot0.getFixedRangeAxisSpace();
        categoryPlot0.configureRangeAxes();
        org.junit.Assert.assertNull(axisSpace4);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        double double1 = lineAndShapeRenderer0.getItemLabelAnchorOffset();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset2, valueAxis3, polarItemRenderer4);
        polarPlot5.removeCornerTextItem("");
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = polarPlot5.getOrientation();
        lineAndShapeRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot5);
        boolean boolean10 = lineAndShapeRenderer0.getUseOutlinePaint();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        java.awt.Paint paint2 = dateAxis1.getTickLabelPaint();
        double double3 = dateAxis1.getUpperMargin();
        double double4 = dateAxis1.getAutoRangeMinimumSize();
        org.jfree.chart.event.AxisChangeListener axisChangeListener5 = null;
        dateAxis1.addChangeListener(axisChangeListener5);
        dateAxis1.setUpperMargin(0.0d);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 2.0d + "'", double4 == 2.0d);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 60000L, 0.0f);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, (double) 11);
        java.lang.String str3 = rectangleConstraint2.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toUnconstrainedWidth();
        double double5 = rectangleConstraint4.getWidth();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]" + "'", str3.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]"));
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        int int0 = org.jfree.data.time.SerialDate.THIRD_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[][] numberArray17 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16 };
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray17);
        java.lang.Number number19 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset18);
        org.jfree.data.Range range21 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset18, false);
        org.jfree.data.Range range23 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset18, true);
        java.lang.Number number24 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset18);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(categoryDataset18);
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 300.0d + "'", number19.equals(300.0d));
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + (-1.0d) + "'", number24.equals((-1.0d)));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("");
        java.lang.String str2 = taskSeries1.getDescription();
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke1 = defaultDrawingSupplier0.getNextStroke();
        java.awt.Stroke stroke2 = defaultDrawingSupplier0.getNextStroke();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        java.awt.Paint paint1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint1, stroke2);
        java.awt.Paint paint4 = valueMarker3.getLabelPaint();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        int int6 = color5.getTransparency();
        valueMarker3.setLabelPaint((java.awt.Paint) color5);
        valueMarker3.setAlpha(0.0f);
        double double10 = valueMarker3.getValue();
        valueMarker3.setLabel("");
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(true);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str3 = textTitle2.getText();
        java.awt.geom.Rectangle2D rectangle2D4 = textTitle2.getBounds();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean8 = lineAndShapeRenderer5.getItemLineVisible((int) (short) -1, 8);
        boolean boolean9 = textTitle2.equals((java.lang.Object) lineAndShapeRenderer5);
        org.jfree.data.KeyedObject keyedObject10 = new org.jfree.data.KeyedObject((java.lang.Comparable) 10L, (java.lang.Object) boolean9);
        org.jfree.chart.block.BlockContainer blockContainer11 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.LabelBlock labelBlock13 = new org.jfree.chart.block.LabelBlock("java.awt.Color[r=128,g=128,b=255]");
        blockContainer11.add((org.jfree.chart.block.Block) labelBlock13);
        keyedObject10.setObject((java.lang.Object) blockContainer11);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.junit.Assert.assertNotNull(blockBorder0);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        java.awt.Paint paint2 = dateAxis1.getTickLabelPaint();
        double double3 = dateAxis1.getUpperMargin();
        dateAxis1.resizeRange((double) (short) 1, 0.0d);
        dateAxis1.setLabelURL("");
        org.jfree.chart.axis.AxisLocation axisLocation9 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer12 = null;
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot(xYDataset10, valueAxis11, polarItemRenderer12);
        polarPlot13.removeCornerTextItem("");
        org.jfree.chart.plot.PlotOrientation plotOrientation16 = polarPlot13.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation9, plotOrientation16);
        boolean boolean18 = dateAxis1.equals((java.lang.Object) axisLocation9);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double21 = rectangleInsets19.calculateBottomOutset(0.4d);
        dateAxis1.setLabelInsets(rectangleInsets19);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(plotOrientation16);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 3.0d + "'", double21 == 3.0d);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ganttRenderer0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = legendTitle1.getLegendItemGraphicLocation();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod5 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 'a');
        boolean boolean6 = rectangleAnchor2.equals((java.lang.Object) simpleTimePeriod5);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor7 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType8 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition10 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor2, textBlockAnchor7, categoryLabelWidthType8, (float) (-6553600));
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str13 = textTitle12.getText();
        java.awt.Font font14 = textTitle12.getFont();
        java.awt.Font font16 = null;
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot(xYDataset17, valueAxis18, polarItemRenderer19);
        polarPlot20.removeCornerTextItem("");
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str25 = textTitle24.getText();
        java.awt.Font font26 = textTitle24.getFont();
        polarPlot20.setAngleLabelFont(font26);
        org.jfree.chart.JFreeChart jFreeChart29 = new org.jfree.chart.JFreeChart("", font16, (org.jfree.chart.plot.Plot) polarPlot20, true);
        java.lang.Object obj30 = jFreeChart29.getTextAntiAlias();
        textTitle12.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart29);
        boolean boolean32 = textBlockAnchor7.equals((java.lang.Object) textTitle12);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor7);
        org.junit.Assert.assertNotNull(categoryLabelWidthType8);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNull(obj30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 11, 0.0f);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape2, "ClassContext", "");
        java.lang.Object obj6 = chartEntity5.clone();
        java.lang.String str7 = chartEntity5.toString();
        java.awt.Shape shape8 = null;
        try {
            chartEntity5.setArea(shape8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ChartEntity: tooltip = ClassContext" + "'", str7.equals("ChartEntity: tooltip = ClassContext"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        boolean boolean2 = ganttRenderer0.equals((java.lang.Object) '#');
        ganttRenderer0.setSeriesVisibleInLegend(1, (java.lang.Boolean) false, false);
        java.awt.Stroke stroke8 = ganttRenderer0.getSeriesStroke(0);
        ganttRenderer0.setSeriesVisible(0, (java.lang.Boolean) false, true);
        java.lang.Boolean boolean14 = ganttRenderer0.getSeriesItemLabelsVisible(128);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(stroke8);
        org.junit.Assert.assertNull(boolean14);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        try {
            java.lang.Comparable comparable3 = defaultKeyedValues2D1.getRowKey(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.axis.NumberAxis numberAxis0 = null;
        java.awt.Font font5 = null;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis0, (-1.0d), (double) (short) 0, (double) (byte) 0, (double) (byte) 0, font5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str10 = textTitle9.getText();
        java.awt.Font font11 = textTitle9.getFont();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str15 = textTitle14.getText();
        java.awt.geom.Rectangle2D rectangle2D16 = textTitle14.getBounds();
        textTitle9.draw(graphics2D12, rectangle2D16);
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        markerAxisBand6.draw(graphics2D7, rectangle2D16, rectangle2D18, (double) 10, 100.0d);
        java.awt.Graphics2D graphics2D22 = null;
        double double23 = markerAxisBand6.getHeight(graphics2D22);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 1, 1.0E-5d);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        double double3 = piePlot3D1.getExplodePercent((java.lang.Comparable) 0.2d);
        piePlot3D1.setForegroundAlpha((float) 100L);
        java.awt.Paint paint6 = piePlot3D1.getLabelLinkPaint();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(paint6);
    }
}

